"""Double-click to open the RoleplayEngine dashboard: the Discord bot, the graph browser and the numbers, one window.

The dashboard's local server lives only while its window is open; the bot it starts keeps running on its own.
(Same as `python -m roleplay.dashboard` - see roleplay/dashboard/__init__.py.)
"""
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
PYTHONW = VENV / "Scripts" / "pythonw.exe"


def main() -> None:
    # a double-click runs whichever Python Windows associates with .pyw; the game lives in the project's venv
    if PYTHONW.exists() and Path(sys.prefix).resolve() != VENV.resolve():
        subprocess.Popen([str(PYTHONW), str(Path(__file__).resolve()), *sys.argv[1:]], cwd=str(ROOT))
        return
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    try:
        from roleplay.dashboard.__main__ import main as run
        run(sys.argv[1:])
    except SystemExit:
        raise
    except BaseException as exc:                          # no console to print to: say it in a box
        import traceback
        log = ROOT / "campaigns" / ".run" / "dashboard.log"
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            with open(log, "a", encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
        except OSError:
            pass
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, f"The dashboard couldn't start:\n\n{exc}\n\nDetails are in {log}",
                                             "RoleplayEngine", 0x10)


main()
