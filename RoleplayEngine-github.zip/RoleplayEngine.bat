@echo off
rem RoleplayEngine - double-click to open the dashboard (the Discord bot, the graph browser, the numbers).
rem
rem   RoleplayEngine.bat            the dashboard in its own window (start/stop the bot from its Bot page)
rem   RoleplayEngine.bat serve      just the dashboard server, for a browser tab: http://127.0.0.1:8770
rem   RoleplayEngine.bat bot        start the Discord bot in the background (it keeps running after this closes)
rem   RoleplayEngine.bat stop       stop the bot (a turn in progress finishes first)
rem   RoleplayEngine.bat restart    stop it, then start it again on the current code
rem   RoleplayEngine.bat status     is the bot up?

setlocal
cd /d "%~dp0"
set "PY=%~dp0.venv\Scripts\python.exe"
rem (no ( ) block around this: a ")" in the folder's path - "RoleplayEngine-main (1)" - would end it early)
if exist "%PY%" goto have_py
echo No Python environment found in "%~dp0.venv"
echo Set it up once with:  python -m venv .venv  then  .venv\Scripts\python.exe -m pip install -r requirements.txt
pause
exit /b 1

:have_py

if "%~1"=="" goto window
if /i "%~1"=="serve" goto serve
if /i "%~1"=="bot" goto bot
if /i "%~1"=="start" goto bot
if /i "%~1"=="stop" goto botctl
if /i "%~1"=="restart" goto botctl
if /i "%~1"=="status" goto botctl
echo Unknown option "%~1". Try: serve, bot, stop, restart or status (or nothing, for the dashboard).
pause
exit /b 1

:window
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0RoleplayEngine.pyw"
exit /b 0

:serve
echo RoleplayEngine dashboard server - leave this window open; Ctrl+C stops it.
"%PY%" -m roleplay.dashboard --serve
exit /b %errorlevel%

:bot
"%PY%" -m roleplay.dashboard.botctl start %2
set "RC=%errorlevel%"
goto done

:botctl
"%PY%" -m roleplay.dashboard.botctl %1
set "RC=%errorlevel%"

:done
rem double-clicked from Explorer (cmd /c): keep the window open long enough to read it
setlocal EnableDelayedExpansion
set "CL=!cmdcmdline!"
if /i not "!CL:/c =!"=="!CL!" pause
exit /b %RC%
