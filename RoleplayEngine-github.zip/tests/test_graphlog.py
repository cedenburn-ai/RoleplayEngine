"""The per-turn graph log (roleplay/graphlog, DESIGN.md §8f): a file a turn, the touches and what was surfaced, undo,
a writer that fails without costing the turn, backfill from history, and the analysis - no network."""
import gzip
import json

import pytest

from roleplay import graphlog
from roleplay.graphlog import fmt, record
from roleplay.graphlog.__main__ import main as cli
from roleplay.graphlog.analyze import analyze, jaccard, largest_component
from roleplay.graphlog.backfill import backfill
from roleplay.engine.dice import ScriptedDice
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool

BAR = [{"name": "counter", "cover": "hard"}, {"name": "booths", "cover": "light"}, {"name": "front door"},
       {"name": "street", "near": ["front door"]}]

TALK = {"summary": "Razor asked Kaz for a buyer; Kaz named Tanaka.",
        "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"},
                    {"id": "tanaka", "role": "mentioned"}],
        "recalled": ["T2"], "facts": [{"text": "Kaz recommended Tanaka to Razor.", "about": ["kaz", "tanaka"]}],
        "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}}
REAL_BUILD = record.build


def _demo(make_game, script=None, extraction=TALK):
    g = make_game(FakeLLM(script, extraction), dice=ScriptedDice([5] * 60))
    setup_demo(g)
    return g


def _nodes(doc) -> dict:
    return {n["id"]: n for n in fmt.rows_of(doc["nodes"])}


def test_every_turn_writes_its_graph_and_what_made_it(make_game):
    g = _demo(make_game, [([tool("recall", ids=["T1"])], "tool_use"), ([text("Kaz shrugs. \"Tanaka.\"")], "end_turn")])
    d = graphlog.log_dir(g.path)
    assert graphlog.turns_on_file(d) == [1, 2, 3]                       # the demo's seeded past is turns too
    res = g.run_turn([("razor", "Kaz, who buys hot Renraku data? Tanaka?")])
    assert graphlog.turns_on_file(d) == [1, 2, 3, res.turn_id]
    doc = graphlog.read_turn(d, res.turn_id)
    meta, pr = doc["meta"], doc["process"]
    assert doc["schema"] == fmt.SCHEMA and doc["reconstructed"] is False
    assert meta["turn"] == res.turn_id and meta["slice_id"] == res.slice_id and meta["fight"] is None
    assert meta["citizens"] == g.conn.execute("SELECT COUNT(*) FROM energy").fetchone()[0]
    assert meta["mean"] == pytest.approx(g.sub.system_mean()) and meta["diff_since"] == 3
    nodes = _nodes(doc)
    t = nodes[res.slice_id]
    assert t["energy"] == pytest.approx(g.sub.energy_of(res.slice_id)) and t["ratio"] == pytest.approx(
        g.sub.ratio(res.slice_id), rel=1e-5)
    hist = dict(g.conn.execute("SELECT node_id, ratio FROM energy_history WHERE turn=?", (res.turn_id,)).fetchall())
    assert all(nodes[i]["ratio"] == pytest.approx(r, rel=1e-5) for i, r in hist.items())   # the snapshot, exactly
    links = {(r["a"], r["b"]): r for r in fmt.rows_of(doc["links"])}
    assert links[tuple(sorted((res.slice_id, "razor")))]["kind"] == "member"
    # the process: the slice's deposit, then the retrieval touch - and why each origin got it
    slice_touch, retrieval = pr["touches"]
    assert slice_touch["why"] == "slice" and slice_touch["origins"] == [res.slice_id] and slice_touch["phase"] == "turn"
    assert slice_touch["by"] == "dm.commit:commit_turn" and slice_touch["stats"]["energy_minted"] > 0
    assert retrieval["why"] == "retrieval" and retrieval["origin_why"] == {"T2": "recalled", "T1": "looked-up",
                                                                           "tanaka": "mentioned"}
    deps = [r for r in fmt.rows_of(pr["deposits"]) if r["touch"] == 0]
    first = next(r for r in deps if r["node"] == res.slice_id)
    q = slice_touch["mean_before"]                    # the full quantum (x the mean), and what came back round a cycle
    assert q * (1 - 1e-5) <= first["amount"] < 1.5 * q
    assert sum(r["amount"] for r in deps) == pytest.approx(slice_touch["stats"]["energy_minted"], rel=1e-4)
    assert t["deposited"] == pytest.approx(sum(r["amount"] for r in fmt.rows_of(pr["deposits"])
                                               if r["node"] == res.slice_id), rel=1e-4)
    # what the GM was shown and what it looked up
    assert "razor" in pr["surfaced"]["present"] and "kaz" in pr["surfaced"]["present"]
    assert "tanaka" in pr["surfaced"]["mentioned_but_not_here"]
    assert pr["looked_up"]["expanded"] == ["T1"] and pr["looked_up"]["tools"] == ["recall"]
    fact = next(f["id"] for f in g.sub.facts_for("tanaka", 5) if "recommended" in f["text"])
    assert {res.slice_id, fact} <= set(pr["new_nodes"])
    assert {"a": fact, "b": "kaz", "kind": "about", "strength": 1.0} in fmt.rows_of(pr["new_links"])
    # the catalog has the text (once), the CSV the quick look
    cat = fmt.catalog_at(fmt.read_catalog(d))
    assert cat[res.slice_id]["text"] == g.sub.node(res.slice_id)["text"]
    assert ["razor", "actor"] in cat[res.slice_id]["members"] and cat["razor"]["ekind"] == "pc"
    assert "text" not in doc["nodes"]["columns"]
    row = fmt.read_csv(d)[res.turn_id]
    assert row["slice_id"] == res.slice_id and int(row["touches"]) == 2 and int(row["bytes"]) > 0
    assert (d / "FORMAT.txt").exists()


def test_undo_takes_the_turns_file_with_it(make_game):
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.run_turn([("razor", "Kaz?")])
    t5 = g.run_turn([("razor", "Tanaka?")]).turn_id
    assert graphlog.turns_on_file(d)[-1] == t5
    g.undo()
    assert t5 not in graphlog.turns_on_file(d) and t5 not in fmt.read_csv(d)
    assert all(e["since"] < t5 for e in fmt.read_catalog(d))
    again = g.run_turn([("razor", "Tanaka, then.")])
    assert again.turn_id == t5
    doc = graphlog.read_turn(d, t5)
    assert doc["meta"]["diff_since"] == t5 - 1 and again.slice_id in doc["process"]["new_nodes"]
    assert sorted(fmt.read_csv(d)) == graphlog.turns_on_file(d)


def test_touches_between_turns_ride_into_the_next_file_and_survive_an_undo(make_game):
    """The offscreen world (and !askdm) touch between turns: their deposits belong to the next snapshot's file - and
    an undo of that next turn restores a record they're still in, so they wait for its replacement."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.sub.touch(["kaz"], g.turn_no(), 0.5)                    # (between turns, at the last turn's number)
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    between = [x for x in graphlog.read_turn(d, t)["process"]["touches"] if x["phase"] == "between"]
    assert len(between) == 1 and between[0]["origins"] == ["kaz"] and between[0]["turn"] == t - 1
    g.undo()
    g.run_turn([("razor", "Kaz, again.")])
    again = [x for x in graphlog.read_turn(d, t)["process"]["touches"] if x["phase"] == "between"]
    assert len(again) == 1 and again[0]["origins"] == ["kaz"]
    deps = [r for r in fmt.rows_of(graphlog.read_turn(d, t)["process"]["deposits"]) if r["touch"] == again[0]["i"]]
    assert any(r["node"] == "kaz" for r in deps)


def test_a_failing_log_never_costs_the_turn(make_game, monkeypatch):
    said = []
    g = _demo(make_game)
    g.out = said.append
    d = graphlog.log_dir(g.path)

    def boom(*a, **k):
        raise OSError("disk full")
    status = lambda t: g.conn.execute("SELECT status FROM turns WHERE id=?", (t,)).fetchone()[0]   # noqa: E731
    monkeypatch.setattr(record, "build", boom)
    res = g.run_turn([("razor", "Kaz?")])
    assert res.slice_id and status(res.turn_id) == "committed" and g.sub.exists(res.slice_id)
    assert res.turn_id not in graphlog.turns_on_file(d)
    assert any("graph log" in s and "disk full" in s for s in said)
    monkeypatch.setattr(record, "build", REAL_BUILD)
    monkeypatch.setattr(fmt, "write_turn", boom)              # (and a disk that refuses the write)
    res2 = g.run_turn([("razor", "Kaz, please.")])
    assert status(res2.turn_id) == "committed" and res2.turn_id not in graphlog.turns_on_file(d)
    monkeypatch.undo()
    n = len(g.sub.recorder.touches)
    g.sub.recorder.touched(["razor"], 0, 1.0, True, None, None)   # a broken touch hook: swallowed, nothing recorded
    assert len(g.sub.recorder.touches) == n
    res3 = g.run_turn([("razor", "Fine.")])
    assert res3.turn_id in graphlog.turns_on_file(d)          # (and the log picks up again)


def test_the_log_switches_off(make_game, tmp_path):
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.ledger.set_meta("graphlog", "off")
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    assert t not in graphlog.turns_on_file(d)
    g.ledger.set_meta("graphlog", "on")
    assert g.run_turn([("razor", "Kaz.")]).turn_id in graphlog.turns_on_file(d)
    from roleplay.art import ArtDirector, NullArtProvider
    from roleplay.config import Settings
    from roleplay.game import Game
    off = Settings()
    off.graph_log = False
    g2 = Game(tmp_path / "quiet.db", settings=off, llm=FakeLLM(extraction=TALK),
              art=ArtDirector(tmp_path / "qart", "t", provider=NullArtProvider(), out=lambda s: None), out=lambda s: None)
    try:
        assert g2.sub.recorder is None                        # off: not even attached - it costs nothing
        setup_demo(g2)
        g2.run_turn([("razor", "Kaz?")])
        assert not graphlog.log_dir(g2.path).exists()
    finally:
        g2.close()


def test_a_fight_round_is_a_turn_without_a_slice(make_game):
    script = [([tool("fight", action="start", zones=BAR, positions=[{"id": "joey-two-knives", "zone": "front door"}]),
                tool("attack", attacker_id="razor", target_id="joey-two-knives", reason="he drew first")], "tool_use"),
              ([text("Razor fires across the bar.")], "end_turn"),
              ([text("Joey bolts.\n<dm>\nbattle end: Joey ran into the street\n</dm>")], "end_turn")]
    fight = dict(TALK, members=[{"id": "razor", "role": "actor"}, {"id": "joey-two-knives", "role": "target"}],
                 recalled=[], facts=[], combat={"moves": [], "zones": [], "over": False, "how": ""})
    g = _demo(make_game, script, fight)
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    d = graphlog.log_dir(g.path)
    r1 = g.run_turn([("razor", "I draw on Joey.")])
    doc = graphlog.read_turn(d, r1.turn_id)
    assert doc["meta"]["slice_id"] is None and doc["meta"]["fight"]["status"] == "active"
    assert all(x["why"] != "slice" for x in doc["process"]["touches"])
    r2 = g.run_turn([("razor", "After him.")])
    doc2 = graphlog.read_turn(d, r2.turn_id)
    assert doc2["meta"]["fight"]["status"] == "ended"
    assert any(x["why"] == "fight-memory" and x["by"] == "encounters:end" for x in doc2["process"]["touches"])


def test_surfaced_reads_the_packet_by_section():
    packet = ("=== SCENE S3: The Bar ===\nLocation: The Lucky Shot [the-lucky-shot]\n\n=== PRESENT ===\n"
              "Kaz [kaz] - NPC\n    [T2] (S1, heat 1.2x) the bar fight\n[GUARD] not a node\n"
              "\n=== FACTS IN PLAY (canon about who/what is here, hottest first) ===\n[F2] Kaz owes Razor  (about Kaz)\n"
              "Current picture (GM-only) [C1, t5]: ...\n=== RECENTLY (this scene, oldest first) ===\n[T5] (see above)")
    known = {"the-lucky-shot", "kaz", "T2", "F2", "C1", "T5"}
    # (the picture's ", t5" is the turn it was made - a date, not a memory shown: only C1 counts)
    assert fmt.surfaced(packet, known) == {"scene": ["the-lucky-shot"], "present": ["kaz", "T2"],
                                           "facts_in_play": ["F2", "C1"], "recently": ["T5"]}
    assert fmt.section_key("CANON (the story's reconciled record as of T12 - it outranks") == "canon"
    assert fmt.section_key("FIGHT - round 2 (the engine tracks the battlefield) ===") == "fight"


def test_backfill_rebuilds_the_log_from_history(make_game, tmp_path):
    g = _demo(make_game, [([tool("recall", ids=["T1"])], "tool_use"), ([text("Kaz shrugs.")], "end_turn")])
    for line in ("Kaz?", "Tanaka?", "Fine."):
        g.run_turn([("razor", line)])
    d = graphlog.log_dir(g.path)
    out = tmp_path / "rebuilt"
    res = backfill(g.path, out, say=lambda s: None)
    assert res["written"] == graphlog.turns_on_file(d) == graphlog.turns_on_file(out)
    for t in res["written"]:
        fwd, back = graphlog.read_turn(d, t), graphlog.read_turn(out, t)
        assert back["reconstructed"] is True and back["exactness"]["nodes.ratio"].startswith("exact")
        assert back["exactness"]["process.deposits"] == "missing"
        fn, bn = _nodes(fwd), _nodes(back)
        assert {i for i, n in fn.items() if n["energy"] is not None} == {i for i, n in bn.items()
                                                                         if n["energy"] is not None}
        for i, n in fn.items():                                # heat, exactly; existence of every citizen, exactly
            if n["ratio"] is not None:
                assert bn[i]["ratio"] == pytest.approx(n["ratio"], rel=1e-5)
                assert bn[i]["energy"] == pytest.approx(n["energy"], rel=1e-5)
                assert bn[i]["superseded_by"] == n["superseded_by"]
        assert back["meta"]["mean"] == pytest.approx(fwd["meta"]["mean"])
        assert back["metrics"]["warm"] == fwd["metrics"]["warm"] and back["metrics"]["hot"] == fwd["metrics"]["hot"]
        fl = {(r["a"], r["b"]) for r in fmt.rows_of(fwd["links"])}
        bl = {(r["a"], r["b"]) for r in fmt.rows_of(back["links"])}
        assert fl <= bl                                       # (no earlier than both ends: never late, at worst early)
        assert back["process"]["surfaced"] == fwd["process"]["surfaced"]   # turns.packet is the packet itself
        if fwd["meta"]["slice_id"]:
            assert back["meta"]["slice_id"] == fwd["meta"]["slice_id"]
            assert back["process"]["touches"][0]["origins"] == [fwd["meta"]["slice_id"]]
    assert fmt.read_csv(out)[res["written"][-1]]["reconstructed"] == "1"
    # into the live folder: the forward (exact) files are kept, never replaced by a reconstruction
    again = backfill(g.path, None, say=lambda s: None)
    assert again["written"] == [] and again["skipped"] == res["written"]
    assert graphlog.read_turn(d, res["written"][-1])["reconstructed"] is False


def test_backfill_never_writes_the_campaign_file(make_game, tmp_path):
    g = _demo(make_game)
    g.run_turn([("razor", "Kaz?")])
    before = g.conn.execute("SELECT COUNT(*) FROM meta").fetchone()[0], g.turn_no()
    g.close()
    stamp = g.path.stat().st_mtime_ns
    backfill(g.path, tmp_path / "b", say=lambda s: None)
    assert g.path.stat().st_mtime_ns == stamp
    import sqlite3
    c = sqlite3.connect(str(g.path))
    try:
        assert (c.execute("SELECT COUNT(*) FROM meta").fetchone()[0], c.execute("SELECT MAX(id) FROM turns")
                .fetchone()[0]) == before
    finally:
        c.close()


def test_analyze_a_small_log(make_game, tmp_path):
    g = _demo(make_game, [([tool("recall", ids=["T1"])], "tool_use"), ([text("Kaz shrugs.")], "end_turn")])
    for i in range(6):
        g.run_turn([("razor", f"Kaz, question {i}?")])
    d = graphlog.log_dir(g.path)
    res = analyze(d, tmp_path / "an")
    assert res["turns"] == len(graphlog.turns_on_file(d))
    rows = (tmp_path / "an" / "measures.csv").read_text().splitlines()
    assert rows[0].startswith("turn,reconstructed,scene_id") and len(rows) == res["turns"] + 1
    page = (tmp_path / "an" / "report.html").read_text(encoding="utf-8")
    assert "<title>Graph Log Report</title>" in page and "const ROWS = [" in page and "</script>" in page
    s = json.loads((tmp_path / "an" / "summary.json").read_text())
    assert s["criticality"]["regime"] and s["criticality"]["caveats"]
    assert s["exact_turns"] == res["turns"] and s["reconstructed_turns"] == 0
    lk = s["lakes"]
    assert lk["touches_measured"] > 0 and 1.5 < lk["mint_ratio_by_why"]["slice"]["median"] <= 2.0   # the honest mint
    assert lk["books_unexplained_median"] is not None and lk["books_unexplained_median"] < 0.05   # the books close
    assert s["echo_all_sections"]["turns"] == res["turns"] - 3     # (the seeded turns had no packet)
    assert [a for a, _, _ in lk["forgetting_curve"]][:2] == [0, 1]


def test_measure_helpers():
    assert jaccard({1, 2}, {2, 3}) == pytest.approx(1 / 3) and jaccard(set(), set()) is None
    assert largest_component({"a", "b", "c", "d"}, [("a", "b"), ("b", "c"), ("x", "d")]) == 3


def test_the_cli(make_game, tmp_path, capsys):
    g = _demo(make_game)
    g.run_turn([("razor", "Kaz?")])
    assert cli(["status", str(g.path)]) == 0
    assert "graph log on; 4 turn file(s) T1..T4" in capsys.readouterr().out
    assert cli(["analyze", "--log", str(graphlog.log_dir(g.path)), "--out", str(tmp_path / "x")]) == 0
    assert (tmp_path / "x" / "report.html").exists()
    raw = gzip.decompress(fmt.turn_file(graphlog.log_dir(g.path), 4).read_bytes())
    assert json.loads(raw)["meta"]["turn"] == 4


# ── review fixes (2026-10-27) ──────────────────────────────────────────
def _reopen(g, tmp_path, script=None, extraction=TALK, tag="2"):
    """The same world in a new process - a bot restart: the old Game closed, a fresh one on the same file."""
    from roleplay.art import ArtDirector, NullArtProvider
    from roleplay.game import Game
    path = g.path
    g.close()
    return Game(path, llm=FakeLLM(script, extraction), dice=ScriptedDice([5] * 60),
                art=ArtDirector(tmp_path / f"art{tag}", "t", provider=NullArtProvider(), out=lambda s: None),
                out=lambda s: None)


def _books(d) -> dict:
    """{turn: |change in total - minted - born| / change} for every turn the books were measured on."""
    from roleplay.graphlog.analyze import measure
    return {r["turn"]: abs(r["energy_unexplained"]) / abs(r["delta_total"]) for r in measure(d)["rows"]
            if r["energy_unexplained"] is not None and r["delta_total"]}


def test_a_restart_between_turns_keeps_the_offscreen_worlds_touches(make_game, tmp_path):
    """Live: the world pass runs right after every turn and the bot restarts between turns (botctl, a crash). The
    buffer was only in memory: those deposits were gone from the next file, which still said exact."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.run_turn([("razor", "Kaz?")])
    g.sub.touch(["kaz"], g.turn_no(), 0.5)                     # (the offscreen world, as world.apply touches)
    assert (d / fmt.PENDING).exists()
    g2 = _reopen(g, tmp_path)
    try:
        assert [x["origins"] for x in g2.sub.recorder.touches] == [["kaz"]]
        t = g2.run_turn([("razor", "Tanaka?")]).turn_id
        doc = graphlog.read_turn(d, t)
        between = [x for x in doc["process"]["touches"] if x["phase"] == "between"]
        assert [x["origins"] for x in between] == [["kaz"]] and doc["exactness"] == {"*": "exact"}
        assert _books(d)[t] < 1e-9                             # (the books close across the restart)
        head, items = fmt.read_pending(d)
        assert head["turn"] == t and items == [] and not g2.sub.recorder.touches   # (taken by the file: a fresh start)
    finally:
        g2.close()


def test_a_recorder_that_cant_vouch_for_the_buffer_says_partial(make_game, tmp_path):
    """Files on disk but no buffer for them - a log backfilled before the recorder started, an older recorder that kept
    its buffer in memory: what came after the newest file was never recorded, and the next file says so."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.run_turn([("razor", "Kaz?")])
    g.sub.touch(["kaz"], g.turn_no(), 0.5)
    (d / fmt.PENDING).unlink()                                 # (as if that buffer had only been in memory)
    g2 = _reopen(g, tmp_path)
    try:
        t = g2.run_turn([("razor", "Tanaka?")]).turn_id
        ex = graphlog.read_turn(d, t)["exactness"]
        assert ex["process.touches"].startswith("partial: touches after T4's file") and ex["*"] == "exact"
        assert fmt.exact(graphlog.read_turn(d, t), "nodes.ratio") and not fmt.exact(graphlog.read_turn(d, t),
                                                                                     "process.deposits")
        assert t not in _books(d)                              # (a residual from missing touches isn't a books error)
        t2 = g2.run_turn([("razor", "Fine.")]).turn_id         # (and the file after it is whole again)
        assert graphlog.read_turn(d, t2)["exactness"] == {"*": "exact"} and _books(d)[t2] < 1e-9
        s = analyze(d, tmp_path / "an")["summary"]
        assert list(s["partial_turns"]) == [t] and "partial" in (tmp_path / "an" / "report.html").read_text("utf-8")
    finally:
        g2.close()


def test_a_touch_the_recorder_never_saw_shows_in_the_books(make_game):
    """Belt and braces: energy is only minted by a touch and born at a node's creation, so a change in total the
    buffer doesn't account for (another process on the world, a path no hook covers) marks the file partial."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    g.run_turn([("razor", "Kaz?")])
    rec, g.sub.recorder = g.sub.recorder, None
    g.sub.touch(["kaz"], g.turn_no(), 0.5)                     # (unseen)
    g.sub.recorder = rec
    t = g.run_turn([("razor", "Tanaka?")]).turn_id
    assert graphlog.read_turn(d, t)["exactness"]["process.touches"].startswith("partial: the books don't close: +")
    assert t not in _books(d)
    t2 = g.run_turn([("razor", "Fine.")]).turn_id
    assert graphlog.read_turn(d, t2)["exactness"] == {"*": "exact"}


def test_an_undo_puts_the_buffer_right_even_when_turns_csv_is_locked(make_game, monkeypatch):
    """Windows refuses to replace turns.csv while a spreadsheet holds it open. The undo's rewrite of it raised and,
    all in one try, skipped the buffer's fix-up: the replayed turn logged a touch the undo had rolled back as its own
    and lost the between-turns one the restored record still had."""
    said = []
    g = _demo(make_game)
    g.out = said.append
    d = graphlog.log_dir(g.path)
    g.sub.touch(["kaz"], g.turn_no(), 0.5)                     # between turns: stays in the restored record
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    g.sub.touch(["tanaka"], g.turn_no(), 0.5)                  # after the turn: the undo rolls it back

    def locked(*a, **k):
        raise PermissionError(13, "The process cannot access the file", "turns.csv")
    monkeypatch.setattr(fmt, "write_csv", locked)
    g.undo()
    assert any("turns.csv not updated" in s for s in said)
    assert [x["origins"] for x in g.sub.recorder.touches] == [["kaz"]] and t not in graphlog.turns_on_file(d)
    g.run_turn([("razor", "Kaz, again.")])
    touches = graphlog.read_turn(d, t)["process"]["touches"]
    assert [x["origins"] for x in touches if x["phase"] == "between"] == [["kaz"]]
    assert not any(x["origins"] == ["tanaka"] for x in touches)
    assert _books(d)[t] < 1e-3                                 # (the restored touch's deposits are the file's, rounded)


def test_portraits_shown_after_the_turn_land_in_the_next_file(make_game):
    """The Discord table posts a portrait big after run_turn returns - after that turn's file - stamped with its
    number. `WHERE turn=?` on the next file never found it: table_presented was always empty in Discord play."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    g.conn.execute("INSERT OR IGNORE INTO presented(entity_id, turn) VALUES(?, ?)",     # (as _dialogue_card does)
                   ("kaz", g.turn_no()))
    t2 = g.run_turn([("razor", "Tanaka?")]).turn_id
    t3 = g.run_turn([("razor", "Fine.")]).turn_id
    assert graphlog.read_turn(d, t)["process"]["table_presented"] == []
    assert graphlog.read_turn(d, t2)["process"]["table_presented"] == ["kaz"]
    assert graphlog.read_turn(d, t3)["process"]["table_presented"] == []      # (once)


def test_a_fresh_world_under_the_same_name_starts_its_own_log(make_game, tmp_path):
    """console/autoplay --new and multisim delete the .db and start over under the same name: the new world's files
    overwrote the old ones a turn at a time and the old world's later turns read as the new world's."""
    g = _demo(make_game)
    for line in ("Kaz?", "Tanaka?"):
        g.run_turn([("razor", line)])
    d, path = graphlog.log_dir(g.path), g.path
    assert graphlog.turns_on_file(d) == [1, 2, 3, 4, 5]
    g.close()
    for suffix in ("", "-wal", "-shm"):                        # (console.main --new)
        path.with_name(path.name + suffix).unlink(missing_ok=True)
    from roleplay.art import ArtDirector, NullArtProvider
    from roleplay.game import Game
    g2 = Game(path, llm=FakeLLM(extraction=TALK), dice=ScriptedDice([5] * 60),
              art=ArtDirector(tmp_path / "art2", "t", provider=NullArtProvider(), out=lambda s: None),
              out=lambda s: None)
    try:
        g2.wipe_undo()
        setup_demo(g2)
        g2.run_turn([("razor", "Kaz?")])
        assert graphlog.turns_on_file(d) == [1, 2, 3, 4] and sorted(fmt.read_csv(d)) == [1, 2, 3, 4]
        assert all(e["since"] <= 4 for e in fmt.read_catalog(d))
        old = list((path.parent / "archive").glob(f"{path.stem}-*{fmt.DIR_SUFFIX}"))
        assert len(old) == 1 and graphlog.turns_on_file(old[0]) == [1, 2, 3, 4, 5]   # (moved aside, never deleted)
        assert analyze(d, tmp_path / "an")["turns"] == 4
    finally:
        g2.close()


def test_a_backfill_after_forward_logging_catalogues_the_backfilled_turns(make_game):
    """Deploy, a turn, then backfill: the first forward file catalogued every node from its own turn, and the backfill
    skipped every id the catalog had - so catalog_at(t) found nothing for any backfilled turn."""
    g = make_game(FakeLLM(extraction=TALK), dice=ScriptedDice([5] * 60))
    g.ledger.set_meta("graphlog", "off")                      # (played before the log existed)
    setup_demo(g)
    g.run_turn([("razor", "Kaz?")])
    g.ledger.set_meta("graphlog", "on")
    first = g.run_turn([("razor", "Tanaka?")]).turn_id
    d = graphlog.log_dir(g.path)
    assert graphlog.turns_on_file(d) == [first]
    res = backfill(g.path, None, say=lambda s: None)
    assert res["written"] == list(range(1, first)) and res["skipped"] == [first]
    cat = fmt.read_catalog(d)
    for t in res["written"]:
        on = fmt.catalog_at(cat, t)
        ids = {n["id"] for n in fmt.rows_of(graphlog.read_turn(d, t)["nodes"])}
        assert ids <= set(on) and on[f"T{t}"]["members"]      # (every node's text, kind and a slice's members)
    assert backfill(g.path, None, say=lambda s: None)["written"] == res["written"]
    assert len(fmt.read_catalog(d)) == len(cat)                # (run again: nothing added twice)


def test_backfill_takes_renormalizations_from_the_scene_closes(make_game, tmp_path):
    """Back-to-back scene closes leave the mean at 1.0 both times: inferring a renormalization from a falling mean
    missed 6 of 21 live, and their ~0 growth went into the half-life. close_scene logs scene_closed right before it."""
    cut = lambda title: [([tool("cut_scene", title=title, bring_ids=["razor", "ghost"])], "tool_use"),   # noqa: E731
                         ([text(f"{title}.")], "end_turn")]
    g = _demo(make_game, cut("The street") + cut("The van") + [([text("The van rolls.")], "end_turn")])
    for line in ("We leave.", "Into the van.", "Drive."):
        g.run_turn([("razor", line)])
    d, out = graphlog.log_dir(g.path), tmp_path / "rebuilt"
    backfill(g.path, out, say=lambda s: None)
    fwd = [t for t in graphlog.turns_on_file(d) if graphlog.read_turn(d, t)["process"]["renormalized"]]
    back = [t for t in graphlog.turns_on_file(out) if graphlog.read_turn(out, t)["process"]["renormalized"]]
    assert fwd == back == [4, 5]                               # (two closes in a row: both found)
    assert graphlog.read_turn(out, 5)["exactness"]["process.renormalized"].startswith("exact")


def test_the_books_price_each_birth_at_the_mean_it_met(make_game):
    """A node is born at the mean in force when it's made; a touch before it (the offscreen world between turns)
    has raised that above the last snapshot's mean. Pricing every birth at the old mean read as missing energy."""
    g = _demo(make_game)
    for i in range(4):
        g.sub.touch(["kaz", "razor"], g.turn_no(), 0.5)        # (between turns, before each turn's births)
        g.run_turn([("razor", f"Kaz, question {i}?")])
    books = _books(graphlog.log_dir(g.path))
    assert len(books) >= 4 and max(books.values()) < 1e-9      # (was 1.7-2.4% of the change)


def _synthetic(d, n_turns: int, energies, scene_every: int = 10) -> None:
    """A log written straight to disk: `energies(t)` -> {id: (energy, created_turn)} each turn."""
    for t in range(1, n_turns + 1):
        es = energies(t)
        mean = sum(e for e, _ in es.values()) / len(es)
        nodes = [[i, "slice", c, None, "public", e, e / mean, None, None, None, None] for i, (e, c) in es.items()]
        fmt.write_turn(d, {"schema": fmt.SCHEMA, "reconstructed": False, "exactness": {"*": "exact"},
                           "meta": {"turn": t, "scene_id": 1 + (t - 1) // scene_every, "slice_id": None,
                                    "mean": mean, "total": mean * len(es), "knobs": {},
                                    "diff_since": t - 1 if t > 1 else None},
                           "metrics": {}, "nodes": fmt.table(fmt.NODE_COLUMNS, nodes),
                           "links": fmt.table(fmt.LINK_COLUMNS, []), "process": {"touches": [], "surfaced": {}}})


def _regime(d) -> dict:
    from roleplay.graphlog.analyze import measure, reading
    return reading(measure(d))


def test_a_lump_is_supercritical_not_subcritical(tmp_path):
    """Warm and hot are measured against the mean, so 50 of 2,000 nodes holding 80% of the energy leaves a 2.5% warm
    set - and the 'empty' test, checked first, called the lump V5 §7 worries about subcritical."""
    lump = {f"L{i}": (32.0, 0) for i in range(50)}
    rest = {f"N{i}": (400 / 1950, 0) for i in range(1950)}
    _synthetic(tmp_path / "lump", 30, lambda t: {**lump, **rest})
    r = _regime(tmp_path / "lump")
    assert r["regime"] == "supercritical" and "stays put" in r["why"]
    assert r["evidence"]["top5pct_share"] > 0.8
    flat = {f"N{i}": (1.0 + 0.01 * (i % 7), 0) for i in range(2000)}        # (nothing above 2x: really empty)
    _synthetic(tmp_path / "flat", 30, lambda t: flat)
    assert _regime(tmp_path / "flat")["regime"] == "subcritical"


def test_a_conveyor_of_births_isnt_a_working_set_turning_over(tmp_path):
    """Nearly all entry into the warm set is newborn nodes: a frozen core plus one hot newborn a turn (none ever
    re-warms) passed 'turning' on births alone and read critical."""
    def conveyor(t):
        es = {f"K{i}": (3.0, 0) for i in range(120)}
        es.update({f"C{i}": (0.3, 0) for i in range(1300)})
        es.update({f"B{b}": (3.0 if t - b < 10 else 0.3, b) for b in range(1, t + 1)})
        return es
    _synthetic(tmp_path / "conv", 60, conveyor)
    r = _regime(tmp_path / "conv")
    assert r["evidence"]["j10_hot"] < r["evidence"]["j1_hot"] - 0.02        # (plain turnover: 'turning')
    assert r["evidence"]["reentry10_hot"] == 0 and r["evidence"]["born10_hot"] > 0.05
    assert r["regime"] == "stable but frozen" and "conveyor" in r["why"]
    _synthetic(tmp_path / "still", 30, lambda t: {f"K{i}": (3.0 if i < 50 else 0.5, 0) for i in range(500)})
    assert _regime(tmp_path / "still")["regime"] == "stable but frozen"     # (a CV of exactly 0 isn't "missing")


def test_the_topic_test_wants_more_than_noise():
    """+1.6 points with 13 of 20 changes above their neighbourhood read as tracking; the placebo says such a mean
    comes up by chance one time in ten. The test now reports an interval and a placebo p, and runs count once."""
    import random
    from roleplay.graphlog.analyze import topic_test
    rng = random.Random(7)
    changes = set(range(12, 400, 19)) | {13, 14}               # (a run: three changes in a row count once)
    rows = [{"turn": t, "boundary": int(t in changes)} for t in range(1, 401)]
    noise = {t: rng.gauss(0.1, 0.03) for t in range(1, 401)}
    res = topic_test(rows, noise)
    assert res["events"] == len(changes) - 2 and res["placebos"] >= 19
    assert res["p"] > 0.05 and res["ci"][0] < 0 < res["ci"][1]
    lead = {t: v + (0.08 if t - 4 in changes else 0) for t, v in noise.items()}   # (the change's window runs high)
    hit = topic_test(rows, lead)
    assert hit["p"] < 0.05 and hit["ci"][0] > 0 and hit["mean"] > 0.05


def test_the_mint_ratio_divides_by_each_origins_own_quantum(make_game, tmp_path):
    """touch_all re-reads the mean before each origin, so origins x the first mean undercounts the deposit: on a small
    graph honest multi-origin retrievals read 2.1-2.2x and looked like a broken 2x rule."""
    g = _demo(make_game, [([tool("recall", ids=["T1", "T2", "T3"])], "tool_use"), ([text("Kaz shrugs.")], "end_turn")]
              * 4)
    for i in range(4):
        g.run_turn([("razor", f"Kaz, question {i}?")])
    d = graphlog.log_dir(g.path)
    doc = graphlog.read_turn(d, g.turn_no())
    r = next(x for x in doc["process"]["touches"] if x["why"] == "retrieval")
    assert r["stats"]["origins"] >= 3 and r["stats"]["deposit"] > r["stats"]["origins"] * r["mean_before"] * 0.5
    lk = analyze(d, tmp_path / "an")["summary"]["lakes"]
    assert lk["mint_ratio_by_why"]["retrieval"]["max"] <= 2.0 and lk["mint_over_2"] == 0


def test_a_fact_the_gm_wrote_isnt_a_lookup(make_game):
    """The engine puts the facts the GM writes with what it opened (for their retrieval touch); the log called them
    looked-up - mixing the GM's own words into what it chose to open."""
    g = _demo(make_game, [([tool("establish_fact", text="Kaz keeps a shotgun under the counter.", about_ids=["kaz"])],
                           "tool_use"), ([text("Kaz leans on the counter.")], "end_turn")])
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    pr = graphlog.read_turn(graphlog.log_dir(g.path), t)["process"]
    fid = next(n for n in pr["new_nodes"]
               if (g.sub.node(n) or {}).get("text") == "Kaz keeps a shotgun under the counter.")
    retrieval = next(x for x in pr["touches"] if x["why"] == "retrieval")
    assert retrieval["origin_why"][fid] == "authored"
    assert pr["looked_up"]["authored"] == [fid] and fid not in pr["looked_up"]["expanded"]


def test_a_gap_in_the_log_is_not_a_turn(make_game, tmp_path):
    """`graphlog off` then on: lags were counted in files, so '1 turn back' spanned four and four turns' growth and
    mint read as one turn's."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    for i in range(2):
        g.run_turn([("razor", f"on {i}")])
    g.ledger.set_meta("graphlog", "off")
    for i in range(3):
        g.run_turn([("razor", f"off {i}")])
    g.ledger.set_meta("graphlog", "on")
    after = [g.run_turn([("razor", f"back {i}")]).turn_id for i in range(2)]
    assert graphlog.turns_on_file(d) == [1, 2, 3, 4, 5] + after
    assert graphlog.read_turn(d, after[0])["exactness"]["process.touches"].startswith("partial: the log was off")
    from roleplay.graphlog.analyze import measure
    rows = {r["turn"]: r for r in measure(d)["rows"]}
    first = rows[after[0]]
    assert first["consecutive"] == 0 and first["j1_warm"] is None and first["reentry1_hot"] is None
    assert first["mean_growth"] is None and first["energy_unexplained"] is None and first["rehydrated"] is None
    assert rows[after[1]]["consecutive"] == 1 and rows[after[1]]["mean_growth"] is not None
    assert rows[after[1]]["j5_warm"] is not None                # (T10 against T5: five turns back, by turn number)
    assert rows[after[1]]["j1_warm"] is not None and _books(d)[after[1]] < 1e-9


def test_slice_and_retrieval_are_told_apart_by_their_origins(make_game):
    """retrieval_quantum is a knob: at 1.0 the quantum test called every retrieval a slice touch."""
    g = _demo(make_game, [([tool("recall", ids=["T1"])], "tool_use"), ([text("Kaz shrugs.")], "end_turn")])
    g.settings.knobs.retrieval_quantum = 1.0
    res = g.run_turn([("razor", "Kaz, who buys hot Renraku data? Tanaka?")])
    slice_touch, retrieval = graphlog.read_turn(graphlog.log_dir(g.path), res.turn_id)["process"]["touches"]
    assert slice_touch["why"] == "slice" and slice_touch["origins"] == [res.slice_id]
    assert retrieval["why"] == "retrieval" and retrieval["origin_why"]["T1"] == "looked-up"
