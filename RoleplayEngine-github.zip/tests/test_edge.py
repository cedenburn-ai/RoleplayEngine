"""Edge: pushed rolls explode; a called second chance (reroll) is spent whenever more hits can still count, insurance
(if_short) only when the roll falls short - on any roll (tests, attacks, dodges, soaks, spells, drain, the Matrix);
neither goes past a spell's Force or undoes a glitch; burning Edge cheats death; points come back each session."""
import json

import pytest

from roleplay.dm.tools import TurnContext, run_tool
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import explosives, magic, matrix, sr_lite
from roleplay.setup import setup_demo

from types import SimpleNamespace


def _pc(make_game, faces, edge=3):
    g = make_game(dice=ScriptedDice(faces))
    setup_demo(g)
    for pc in ("razor", "ghost"):
        g.ledger.set_stat(pc, "edge", edge)
        g.ledger.set_stat(pc, "edge_points", edge)
    return g


def test_sixes_explode_when_pushed():
    r = sr_lite.roll(ScriptedDice([6, 6, 2, 1, 6, 3, 5]), 4, explode=True)
    assert r.dice == [6, 6, 2, 1] and r.extra == [6, 3, 5] and r.hits == 4      # 6 6 then 6 3, then the 6 gives a 5
    assert "+ 6 3 5 (sixes exploded)" in r.faces()
    assert not r.glitch                                                          # (glitches count the first dice only)
    assert sr_lite.roll(ScriptedDice([6, 6]), 2).hits == 2                        # unpushed: no explosion


def test_insurance_is_spent_only_when_the_roll_falls_short(make_game):
    g = _pc(make_game, [])
    n, _ = sr_lite.build_pool(g.ledger, "razor", "perception")
    g.dice = ScriptedDice([2] * n + [5] * n)                  # all misses, then the reroll lands
    res = sr_lite.request_test(g.ledger, g.dice, 1, "razor", "perception", threshold=2, reason="look", edge="if_short")
    assert res["success"] and "second chance" in res["card"] and int(g.ledger.stat("razor", "edge_points")) == 2
    g.dice = ScriptedDice([5] * 2 + [2] * (n - 2))            # made it on its own: the point stays
    res = sr_lite.request_test(g.ledger, g.dice, 2, "razor", "perception", threshold=2, reason="look", edge="if_short")
    assert res["success"] and "held in reserve" in res["card"] and int(g.ledger.stat("razor", "edge_points")) == 2
    g.ledger.set_stat("razor", "edge_points", 0)
    with pytest.raises(LedgerError, match="no Edge points"):
        sr_lite.request_test(g.ledger, g.dice, 3, "razor", "perception", threshold=2, reason="look", edge="push")


def test_a_plain_tests_row_keeps_its_edge(make_game):
    """Review 2026-10-28: a plain test's row never said Edge rode it - only the 'edge' event did, so read_turn couldn't
    say which roll the point went on. A Matrix row has kept it since flag #25; a test's row keeps the push and the
    second chance now, and read_turn's line says them."""
    from roleplay.dm.research import roll_line
    g = _pc(make_game, [])
    n, _ = sr_lite.build_pool(g.ledger, "razor", "perception")
    g.dice = ScriptedDice([5] * (n + 10))
    sr_lite.request_test(g.ledger, g.dice, 1, "razor", "perception", threshold=2, reason="look", edge="push")
    g.dice = ScriptedDice([2] * n + [5] * n)
    sr_lite.request_test(g.ledger, g.dice, 2, "razor", "perception", threshold=2, reason="look", edge="reroll")
    g.dice = ScriptedDice([5] * n)
    sr_lite.request_test(g.ledger, g.dice, 3, "razor", "perception", threshold=2, reason="look")
    rows = [dict(r) for r in g.conn.execute("SELECT * FROM tests ORDER BY id")]
    specs = [json.loads(r["spec"]) for r in rows]
    assert specs[0]["edge"] == "pushed - 6s explode (2 left)"
    assert specs[1]["edge"].startswith("second chance:") and specs[1]["edge"].endswith("(1 left)")
    assert "edge" not in specs[2]
    assert "· Edge: pushed - 6s explode (2 left)" in roll_line(g.ledger, rows[0])
    assert "· Edge: second chance:" in roll_line(g.ledger, rows[1]) and "Edge" not in roll_line(g.ledger, rows[2])


def test_if_short_is_insurance_and_reroll_is_binding(make_game):
    """Flag #64: "uses edge to reroll fails" is a call, not insurance - the misses go again even on a roll that made
    it, because more hits still count (net hits)."""
    g = _pc(make_game, [])
    n, _ = sr_lite.build_pool(g.ledger, "razor", "perception")
    made_it = [5] * 2 + [2] * (n - 2)
    g.dice = ScriptedDice(list(made_it))
    res = sr_lite.request_test(g.ledger, g.dice, 1, "razor", "perception", threshold=2, reason="look", edge="if_short")
    assert "held in reserve - the roll didn't need" in res["card"] and int(g.ledger.stat("razor", "edge_points")) == 3
    g.dice = ScriptedDice(made_it + [5] * (n - 2))
    res = sr_lite.request_test(g.ledger, g.dice, 2, "razor", "perception", threshold=2, reason="look", edge="reroll")
    assert f"second chance: {n - 2} misses rerolled" in res["card"] and res["hits"] == n and res["net"] == n - 2
    assert int(g.ledger.stat("razor", "edge_points")) == 2
    spent = [e["payload"] for e in g.ledger.events(2) if e["kind"] == "edge"]
    assert spent == [{"use": "reroll", "left": 2, "on": "test"}]                    # (which roll it went on)
    g.dice = ScriptedDice([5] * n)                                                   # nothing to reroll: kept
    res = sr_lite.request_test(g.ledger, g.dice, 3, "razor", "perception", threshold=2, reason="look", edge="reroll")
    assert "held in reserve - no misses" in res["card"] and int(g.ledger.stat("razor", "edge_points")) == 2


def test_a_second_chance_cant_undo_a_glitch(make_game):
    """SR5 p. 56: the 1s go again, the glitch stays - the reroll used to erase it."""
    g = _pc(make_game, [])
    n, _ = sr_lite.build_pool(g.ledger, "razor", "perception")
    g.dice = ScriptedDice([1] * n + [5] * n)                  # a critical glitch, then every reroll a hit
    res = sr_lite.request_test(g.ledger, g.dice, 1, "razor", "perception", threshold=2, reason="look", edge="reroll")
    assert res["hits"] == n and res["glitch"] and res["critical_glitch"]
    assert "the glitch stands" in res["card"] and "CRITICAL GLITCH" in res["card"].split("second chance")[1]


def test_a_dodge_reroll_waits_for_a_hit(make_game):
    """More dodge hits change nothing against a shot that already missed - the called reroll holds."""
    g = _pc(make_game, [])
    joey = "joey-two-knives"
    a_n = sum(v for _, v in sr_lite.build_pool(g.ledger, joey, "close_combat", "agility", use_gear=False)[1])
    d_n = int(g.ledger.stat("razor", "reaction")) + int(g.ledger.stat("razor", "intuition"))
    g.dice = ScriptedDice([2] * a_n + [5] + [2] * (d_n - 1))                       # Joey whiffs; one dodge hit
    res = sr_lite.attack(g.ledger, g.dice, 1, joey, "razor", reason="knife", defense_edge="reroll")
    assert not res["hit"] and "held in reserve - more hits couldn't change" in res["card"]
    assert int(g.ledger.stat("razor", "edge_points")) == 3


def test_a_deckers_called_reroll_goes_on_a_winning_roll(make_game):
    """In the Matrix the margin counts, so a called reroll is spent even when the hack already wins; insurance isn't."""
    cards = {}
    for use in ("if_short", "reroll"):
        g = _pc(make_game, [])
        hid, _ = g.introduce("host", "Renraku Host", "white gravel", rating=4, turn=1)
        matrix.act(g.ledger, g.dice, 1, "ghost", "jack_in", hid, mode="ar")
        n = sr_lite.build_pool(g.ledger, "ghost", "hacking")[0]
        wins = [6] * 5 + [2] * (n - 5) + [5, 5, 2, 2]                               # 5 hits against the node's 2
        cards[use] = matrix.act(g.ledger, ScriptedDice(wins + [2] * n), 2, "ghost", "hack", edge=use)["card"]
        assert int(g.ledger.stat("ghost", "edge_points")) == (3 if use == "if_short" else 2), use
    assert "held in reserve - the roll didn't need" in cards["if_short"]
    assert f"second chance: {n - 5} misses rerolled" in cards["reroll"]
    assert [e["payload"]["on"] for e in g.ledger.events(2) if e["kind"] == "edge"] == ["matrix"]


def test_edge_use_aliases():
    assert sr_lite.edge_use("second chance") == "reroll" and sr_lite.edge_use("Reroll misses") == "reroll"
    for words in ("if I miss", "insurance", "if needed", "just in case", "IF_SHORT"):
        assert sr_lite.edge_use(words) == "if_short", words
    for words in ("reroll 6s", "reroll 6's", "exploding sixes", "rule of six", "push the limit", True):
        assert sr_lite.edge_use(words) == "push", words
    assert sr_lite.edge_use("none") is None and sr_lite.edge_use("None") is None and sr_lite.edge_use(False) is None
    with pytest.raises(LedgerError, match="if_short"):
        sr_lite.edge_use("lucky")


def _barrier_mage(make_game, faces):
    g = _pc(make_game, faces)
    mage = g.create_pc("Finch", "mage", "finch")
    ent = g.ledger.get(mage)
    g.ledger.update_entity(mage, props={**ent["props"], "spells": magic.known(g.ledger, mage) + ["physical barrier"]})
    n, _ = sr_lite.build_pool(g.ledger, mage, "sorcery")
    return g, mage, n


def test_a_called_reroll_rerolls_a_cast_under_the_force(make_game):
    """Live T164 (flag #64): Force 8 Physical Barrier, "uses edge to reroll fails", 4 hits on 13 dice - held in reserve,
    because 4 hits wasn't 'short' by the pool's measure, though 4 more could still count under the Force."""
    g, mage, n = _barrier_mage(make_game, [])
    g.dice = ScriptedDice([5] * 4 + [2] * (n - 4) + [5] * (n - 4))
    res = magic.cast(g.ledger, g.dice, 1, mage, "physical barrier", 8, [], "the bikes", edge="reroll")
    cast_line = next(x for x in res["card"].splitlines() if x.startswith("  Cast"))
    edge_line = next(x for x in res["card"].splitlines() if "second chance" in x)
    assert "limit" not in cast_line and "(limit: Force 8 -> 8)" in edge_line   # (the note sits on the final roll)
    assert int(g.ledger.stat(mage, "edge_points")) == 2
    ev = next(e["payload"] for e in g.ledger.events(1) if e["kind"] == "cast")
    assert 4 < ev["hits"] <= 8
    spent = [e["payload"] for e in g.ledger.events(1) if e["kind"] == "edge"]
    assert {"use": "reroll", "left": 2, "on": "cast"} in spent                     # (the casting's, not the drain's)


def test_a_reroll_is_held_at_the_force_limit(make_game):
    """Live T165: Force 3, a first roll of 3 hits - a second chance can't add a hit that counts (SR5 p. 56), so it's
    held, called or insurance."""
    for use in ("reroll", "if_short"):
        g, mage, n = _barrier_mage(make_game, [])
        g.dice = ScriptedDice([5] * 3 + [2] * (n - 3))
        res = magic.cast(g.ledger, g.dice, 1, mage, "physical barrier", 3, [], "again", edge=use)
        assert "already at the limit (Force 3)" in res["card"], use
        assert int(g.ledger.stat(mage, "edge_points")) == 3
        assert next(e["payload"] for e in g.ledger.events(1) if e["kind"] == "cast")["hits"] == 3


def test_a_casts_row_keeps_what_its_edge_did(make_game):
    """Review 2026-10-28: a cast's row kept the mode asked for, so read_turn said "· Edge: reroll" beside a casting
    whose card held the point in reserve at the Force - flag #64's very dispute. It keeps what happened now, as a
    test's row does: held, a second chance, a push."""
    from roleplay.dm.research import roll_line
    said = []
    for use, faces in (("reroll", [5] * 3 + [2] * 40), ("reroll", [5] * 2 + [2] * 40 + [5] * 40), ("push", [5] * 60)):
        g, mage, n = _barrier_mage(make_game, [])
        g.dice = ScriptedDice(faces)
        magic.cast(g.ledger, g.dice, 1, mage, "physical barrier", 3, [], "again", edge=use)
        row = dict(g.conn.execute("SELECT * FROM tests WHERE json_extract(spec, '$.kind')='cast'").fetchone())
        said.append(roll_line(g.ledger, row))
    assert "· Edge: held in reserve - already at the limit (Force 3)" in said[0] and "Edge: reroll" not in said[0]
    assert "· Edge: second chance:" in said[1]
    assert "· Edge: pushed - 6s explode" in said[2]


def test_no_second_chance_on_a_critically_glitched_cast(make_game):
    """Review: a critical glitch stands whatever a Second Chance rolls (p. 56) and the spell goes wild on any hits -
    yet a called reroll spent the point, and its 14 rerolled hits made Finch's drain 7P. Held now, called or insurance,
    and the drain stays Stun."""
    for use in ("reroll", "if_short"):
        g, mage, n = _barrier_mage(make_game, [])
        g.dice = ScriptedDice([1] * n + [5] * n + [2] * 40)
        res = magic.cast(g.ledger, g.dice, 1, mage, "physical barrier", 8, [], "the bikes", edge=use)
        assert "the spell goes wild" in res["card"] and "a critical glitch stands" in res["card"], use
        assert "second chance" not in res["card"] and int(g.ledger.stat(mage, "edge_points")) == 3
        ev = next(e["payload"] for e in g.ledger.events(1) if e["kind"] == "cast")
        assert ev["hits"] == 0 and ev["drain_type"] == "stun"
        assert not [e for e in g.ledger.events(1) if e["kind"] == "edge"]


def test_a_search_and_a_repair_take_the_deckers_edge(make_game):
    """A Matrix search and a deck repair rolled bare whatever Edge the GM passed - the point the player called went
    nowhere, with nothing on the card to say so. Now the Edge rides them like any roll."""
    g = _pc(make_game, [])
    L = g.ledger
    hid, _ = g.introduce("host", "Renraku Host", "white gravel", rating=4, turn=1)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="ar")
    n = sr_lite.build_pool(L, "ghost", "electronics", "intuition")[0]
    card = matrix.act(L, ScriptedDice([2] * n + [5] * n), 2, "ghost", "search", edge="reroll")["card"]
    assert f"second chance: {n} misses rerolled" in card and "FOUND" in card
    assert int(L.stat("ghost", "edge_points")) == 2
    matrix.act(L, g.dice, 2, "ghost", "jack_out")
    n = sr_lite.build_pool(L, "ghost", "electronics", "logic")[0]
    for faces, held in (([5] * 3 + [2] * (n - 3), True), ([2] * n + [5] * n, False)):
        matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "deck_damage": 3})
        card = matrix.act(L, ScriptedDice(faces), 3, "ghost", "repair", edge="if_short")["card"]
        assert "3 boxes fixed" in card and ("held in reserve" in card if held else "second chance" in card)
    assert int(L.stat("ghost", "edge_points")) == 1                  # (insurance spent only on the short repair)


def test_edge_on_a_gas_grenades_soak(make_game):
    """A target's Edge on a CS gas cloud was dropped - the Body + Willpower roll went bare. It rides it now, as on a
    blast's soak."""
    from roleplay import chargen
    g = _pc(make_game, [])
    L = g.ledger
    can = L.create_entity("item", "Joey's CS gas grenade", "", props=dict(chargen.CATALOG["gas-grenade"]["props"]),
                          turn=1)
    L.give("joey-two-knives", can, 1)
    n = int(L.stat("razor", "body")) + int(L.stat("razor", "willpower"))
    g.dice = ScriptedDice([2] * n + [5] * n)
    res = explosives.explode(L, g.dice, 1, can, "joey-two-knives", [{"id": "razor", "range": "close", "edge": "reroll"}])
    assert f"second chance: {n} misses rerolled" in res["card"] and int(L.stat("razor", "edge_points")) == 2
    assert res["results"][0]["boxes"] == max(0, 5 - n)


def test_edge_on_the_dodge_and_the_soak(make_game):
    g = _pc(make_game, [])
    joey = "joey-two-knives"
    a_n = sum(v for _, v in sr_lite.build_pool(g.ledger, joey, "close_combat", "agility", use_gear=False)[1])
    d_n = int(g.ledger.stat("razor", "reaction")) + int(g.ledger.stat("razor", "intuition"))
    # Joey lands 4 hits, Razor's dodge whiffs - and the second chance on it turns the hit into a miss
    g.dice = ScriptedDice([5] * 4 + [1] * (a_n - 4) + [1] * d_n + [5] * d_n)
    res = sr_lite.attack(g.ledger, g.dice, 1, joey, "razor", reason="knife", defense_edge="reroll", soak_edge="push")
    assert "second chance" in res["card"] and not res["hit"]
    assert int(g.ledger.stat("razor", "edge_points")) == 2                       # the soak's push never came up
    # a hit that gets through: the soak is pushed - Edge dice added, the point spent
    g.dice = ScriptedDice([5] * a_n + [1] * d_n)
    res = sr_lite.attack(g.ledger, g.dice, 2, joey, "razor", reason="again", soak_edge="push")
    assert res["hit"] and "Edge, pushed - 6s explode (1 left)" in res["card"]
    # out of points: a dodge or soak just goes without, and the attack still happens
    g.ledger.set_stat("razor", "edge_points", 0)
    g.ledger.set_stat("razor", "stun_damage", 0)               # (that one knocked him out - patch him up first)
    g.ledger.set_stat("razor", "physical_damage", 0)
    g.dice = ScriptedDice([])
    res = sr_lite.attack(g.ledger, g.dice, 3, joey, "razor", reason="third", defense_edge="push")
    assert "no Edge points left" in res["card"]


def test_edge_on_a_spell_and_its_drain(make_game):
    g = _pc(make_game, [])
    mage = g.create_pc("Finch", "mage", "finch")
    g.ledger.set_stat(mage, "edge", 2)
    g.ledger.set_stat(mage, "edge_points", 2)
    target = g.introduce("npc", "Buzzcut", "a guard", "ganger", present=True, turn=1)[0]
    g.dice = ScriptedDice([6] * 3 + [1] * 40)
    res = magic.cast(g.ledger, g.dice, 1, mage, "manabolt", 4, [{"id": target}], "kill him", edge="push",
                     drain_edge="reroll")
    assert "Edge, pushed - 6s explode" in res["card"] and "sixes exploded" in res["card"]
    assert "second chance" in res["card"]                                        # the drain would have hurt
    assert int(g.ledger.stat(mage, "edge_points")) == 0


def test_burning_edge_cheats_death_and_points_come_back(make_game):
    g = _pc(make_game, [])
    with pytest.raises(LedgerError, match="cheating death"):
        sr_lite.burn_edge(g.ledger, 1, "razor")
    pmax, _ = sr_lite.monitor_max(g.ledger, "razor")
    g.ledger.set_stat("razor", "physical_damage", pmax + 2)
    assert sr_lite.condition(g.ledger, "razor") == "dying"
    res = sr_lite.burn_edge(g.ledger, 1, "razor", "the Colt to the head")
    assert "not dead yet" in res["card"] and sr_lite.condition(g.ledger, "razor") == "unconscious"
    assert int(g.ledger.stat("razor", "edge")) == 2 and int(g.ledger.stat("razor", "edge_points")) == 2
    g.ledger.set_stat("razor", "edge_points", 0)
    assert "(1/2)" in sr_lite.regain_edge(g.ledger, 2, "razor", "saved the kid")["card"]
    g.ledger.new_session()
    assert int(g.ledger.stat("razor", "edge_points")) == 2 and int(g.ledger.stat("ghost", "edge_points")) == 3


def test_the_gm_passes_edge_through_its_tools(make_game):
    g = _pc(make_game, [1] * 40 + [5] * 40)
    ctx = TurnContext(g, 5, g.current_scene_id())
    card = run_tool(ctx, SimpleNamespace(name="request_test", id="t1", input={
        "actor_id": "ghost", "skill": "perception", "threshold": 1, "reason": "spot", "edge": "reroll"}))
    assert "second chance" in str(card)
    card = run_tool(ctx, SimpleNamespace(name="request_test", id="t2", input={
        "actor_id": "ghost", "skill": "perception", "threshold": 1, "reason": "spot", "use_edge": True}))   # the old flag
    assert "Edge, pushed" in str(card)
    g.ledger.set_stat("ghost", "physical_damage", 30)
    card = run_tool(ctx, SimpleNamespace(name="edge", id="t3", input={"action": "burn", "character_id": "ghost"}))
    assert "not dead yet" in str(card) and "[EDGE] Ghost burns Edge" in ctx.cards[-1]
