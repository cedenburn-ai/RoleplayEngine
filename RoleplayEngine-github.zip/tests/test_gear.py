"""Gear at the book's values (2026-10-24): drones as SR5's frames with weapon mounts and autosoft slots, a grenade
matcher that doesn't turn flashlights into flash-bangs, smoke that the engine applies, and character creation at the
book's prices."""
import pytest

from roleplay import chargen as C
from roleplay import encounters
from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError, RulesRefusal
from roleplay.engine.rules import explosives, machines, sr_lite
from roleplay.setup import setup_demo


def _item(L, holder, key, name=None):
    """A catalog item in someone's hands."""
    it = C.CATALOG[key]
    iid = L.create_entity("item", name or f"{L.require(holder)['name']}'s {it['name']}", it["name"], tier=0,
                          props=dict(it["props"]), turn=1)
    L.give(holder, iid, 1, {"loaded": it["props"]["ammo_capacity"]} if "ammo_capacity" in it["props"] else {})
    return iid


@pytest.mark.parametrize("name, kind", [
    ("flashlight", None), ("flash drive", None), ("camera flash", None), ("fragment of the ledger", None),
    ("Grenade launcher", None), ("explosive rounds", None), ("Explosives detector", None), ("grenade pod", None),
    ("Flash-pak", None), ("frag rounds", None), ("explosive ammo", None), ("smoke detector", None),
    ("smoke grenade", "smoke grenade"), ("smoke bomb", "smoke grenade"), ("thermal smoke grenade", "thermal smoke grenade"),
    ("gas grenade", "CS gas grenade"), ("tear gas grenade", "CS gas grenade"),
    ("a frag", "frag grenade"), ("fragmentation grenade", "frag grenade"),
    ("flashbang", "flash-bang"), ("flash bang", "flash-bang"), ("flash-bang", "flash-bang"),
    ("concussion grenade", "flash-bang"), ("stun grenade", "flash-bang"),
    ("grenade", "HE grenade"), ("minigrenade", "HE grenade"), ("minigrenades", "HE grenade"), ("HE", "HE grenade"),
    ("plastic explosive", "HE grenade"),
])
def test_grenade_matcher_word_boundaries(name, kind):
    """Live T184: 'smoke grenade' was a 10P HE grenade and 'flashlight' a flash-bang (plain substring tests) - and every
    introduced item goes through this (game.introduce)."""
    got = explosives.catalog(name)
    assert (got[0] if got else None) == kind


def test_drone_models_match_the_book():
    M = machines.MODELS
    assert M["steel lynx"]["stats"]["armor"] == 4 and M["roto-drone"]["stats"]["armor"] == 1     # a third of 12 / 4
    assert M["crawler"]["stats"]["pilot"] == 4 and M["fly-spy"]["stats"]["accel"] == 2
    assert all({"handling", "speed", "accel", "pilot", "sensor"} <= set(m["stats"]) for m in M.values())
    assert "tracked" in M["doberman"]["desc"] and "four wheeled legs" in M["steel lynx"]["desc"]
    assert {k: m["slots"] for k, m in M.items() if m["kind"] == "drone"} == {
        "fly-spy": 0, "roto-drone": 2, "doberman": 1, "steel lynx": 2, "crawler": 1}
    assert M["doberman"]["mounts"] == ("standard",) and M["steel lynx"]["mounts"] == ("heavy",)


def test_frames_and_fitted_drones(make_game):
    """Sold, a drone is the book's frame; introduced for an NPC, it comes fitted - its usual gun and no more autosofts
    than its slots (live T188: 3-4 free ones on a Pilot 3 that runs 2)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    frame = L.require(machines.build_machine(L, "Kaz's Doberman", "doberman", "kaz", 1, equipped=False))
    assert frame["props"]["autosofts"] == {} and not L.holdings(frame["id"]) and machines.mounts(L, frame) == ["standard"]
    fitted = L.require(machines.build_machine(L, "Guard Roto", "roto-drone", "kaz", 1))
    assert fitted["props"]["autosofts"] == {"targeting": 3, "evasion": 3}
    assert machines.mounts(L, fitted) == ["standard"] and "fitted with a drone SMG" in fitted["description"]


def test_weapon_mounts_follow_body(make_game):
    """SR5 p. 461: Body / 3 mounts (the Roto-drone counts as Body 7, p. 466); a standard mount holds an assault rifle or
    smaller, a heavy one (two slots) anything. Live T184: the dealer told Filament a Roto-drone 'can't lift' a machine
    gun - by the book it takes a heavy mount."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    spy = machines.build_machine(L, "Razor's Fly-Spy", "fly-spy", "razor", 1, equipped=False)
    roto = machines.build_machine(L, "Razor's Roto-drone", "roto-drone", "razor", 1, equipped=False)
    dog = machines.build_machine(L, "Razor's Doberman", "doberman", "razor", 1, equipped=False)
    lynx = machines.build_machine(L, "Razor's Steel Lynx", "steel lynx", "razor", 1, equipped=False)
    alpha, lmg = _item(L, "razor", "assault-rifle"), _item(L, "razor", "lmg")
    mount, heavy = _item(L, "razor", "weapon-mount"), _item(L, "razor", "heavy-mount")
    with pytest.raises(RulesRefusal, match="room for 0 weapon mounts"):
        machines.mount_weapon(L, 1, spy, mount, "razor")
    with pytest.raises(RulesRefusal, match="no weapon mount"):
        machines.mount_weapon(L, 1, roto, alpha, "razor")
    assert "1 of 2 slots" in machines.mount_weapon(L, 1, roto, mount, "razor")
    assert "on a weapon mount" in machines.mount_weapon(L, 1, roto, alpha, "razor")
    with pytest.raises(RulesRefusal, match="no heavy mount"):
        machines.mount_weapon(L, 1, roto, lmg, "razor")
    with pytest.raises(RulesRefusal, match="no room for a heavy mount"):
        machines.mount_weapon(L, 1, roto, heavy, "razor")
    with pytest.raises(RulesRefusal, match="A gun is on that mount"):
        machines.mount_weapon(L, 1, roto, mount, "razor", unmount=True)
    machines.mount_weapon(L, 1, roto, alpha, "razor", unmount=True)
    machines.mount_weapon(L, 1, roto, mount, "razor", unmount=True)
    machines.mount_weapon(L, 1, roto, heavy, "razor")
    assert "on a heavy mount" in machines.mount_weapon(L, 1, roto, lmg, "razor")
    assert "Mounts 2 of 2 slots: heavy - Razor's Ingram Valiant" in sr_lite.sheet(L, roto)
    with pytest.raises(RulesRefusal, match="no heavy mount"):
        machines.mount_weapon(L, 1, dog, _item(L, "razor", "lmg", "Razor's second Valiant"), "razor")
    machines.mount_weapon(L, 1, dog, alpha, "razor")
    machines.mount_weapon(L, 1, roto, lmg, "razor", unmount=True)
    machines.mount_weapon(L, 1, lynx, lmg, "razor")                             # the Lynx's own heavy mount
    with pytest.raises(RulesRefusal, match="no say over"):
        machines.mount_weapon(L, 1, lynx, lmg, "ghost", unmount=True)
    sniper = _item(L, "razor", "sniper-rifle")
    with pytest.raises(LedgerError, match="won't go on Razor's Fly-Spy"):
        dispatch(TurnContext(g, 2, g.current_scene_id()), "transfer_item",
                 {"item_id": sniper, "from_id": "razor", "to_id": spy})


def test_a_van_carries_cargo_and_a_drone_keeps_its_mounts(make_game):
    """Review E2: transfer_item ran check_load on everything going into a machine - a medkit couldn't go in the
    Bulldog, a paydata chip onto a courier drone, a spare rifle into the van's trunk ('no weapon mount'). Now what
    isn't fitted rides as cargo (never on a mount, never fired); a gun handed to a drone still needs a free mount; and
    a mount with a gun on it can't be carried off (mount_weapon's rule - transfer_item left an HK-227 on 0 mounts)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = machines.build_machine(L, "The Renton cargo van", "bulldog", "razor", 1)
    roto = machines.build_machine(L, "Razor's Roto-drone", "roto-drone", "razor", 1, equipped=False)
    ctx = TurnContext(g, 2, g.current_scene_id())
    kit, rifle = _item(L, "razor", "medkit"), _item(L, "razor", "assault-rifle")
    assert "(stowed aboard as cargo)" in dispatch(ctx, "transfer_item", {"item_id": kit, "from_id": "razor",
                                                                           "to_id": van})
    out = dispatch(ctx, "transfer_item", {"item_id": rifle, "from_id": "razor", "to_id": van})
    assert "stowed aboard as cargo - not on a mount (mount_weapon fits it)" in out
    chip = L.create_entity("item", "Paydata chip", "hot", props={"file": True}, turn=1)
    L.give("razor", chip)
    dispatch(ctx, "transfer_item", {"item_id": chip, "from_id": "razor", "to_id": roto})
    assert L.holds(van, kit) and L.holds(van, rifle) and L.holds(roto, chip)
    assert machines._weapons(L, L.require(van)) == [] and f"[{rifle}]" in machines.cargo_line(L, L.require(van))
    sheet = sr_lite.sheet(L, van)                                               # (no gun on its mounts)
    assert "  Mounts 0 of 5 slots: none fitted\n  Cargo: Razor's Ares Alpha" in sheet
    with pytest.raises(LedgerError, match="stowed in The Renton cargo van as cargo"):
        sr_lite.check_attack(L, van, rifle)                                     # (the trunk doesn't shoot)
    dispatch(ctx, "transfer_item", {"item_id": rifle, "from_id": van, "to_id": "razor"})
    assert L.item_state("razor", rifle).get("cargo") is None                    # back in hand: a gun again
    with pytest.raises(RulesRefusal, match="won't go on Razor's Roto-drone: no weapon mount"):
        dispatch(ctx, "transfer_item", {"item_id": rifle, "from_id": "razor", "to_id": roto})
    mount, smg = _item(L, "razor", "weapon-mount"), _item(L, "razor", "smg")
    machines.mount_weapon(L, 2, roto, mount, "razor")
    machines.mount_weapon(L, 2, roto, smg, "razor")
    with pytest.raises(RulesRefusal, match="A gun is on that mount"):
        dispatch(ctx, "transfer_item", {"item_id": mount, "from_id": roto, "to_id": "razor"})
    assert machines.mounts(L, L.require(roto)) == ["standard"] and machines._weapons(L, L.require(roto))


def test_an_old_bundled_drone_keeps_its_mount(make_game):
    """A drone built before mounts were counted (its gun bundled, no props.mounts) has a mount for its gun - and keeps
    it when the gun comes off; the mount can come off too, to make room for a heavy one (live: Filament's Roto-drone
    carries its 'drone SMG' in one of its two slots, and he wanted a machine gun)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    roto = machines.build_machine(L, "Ghost's Roto-drone", "roto-drone", "ghost", 1)
    L.update_entity(roto, props={k: v for k, v in L.require(roto)["props"].items() if k != "mounts"})
    smg = next(i for i in L.holdings(roto) if "dv" in i["props"])
    assert machines.mounts(L, L.require(roto)) == ["standard"]
    machines.mount_weapon(L, 1, roto, smg["id"], "ghost", unmount=True)
    assert machines.mounts(L, L.require(roto)) == ["standard"] and L.holds("ghost", smg["id"])
    old = next(i for i in L.holdings(roto) if i["props"].get("mount"))
    machines.mount_weapon(L, 1, roto, old["id"], "ghost", unmount=True)
    assert machines.mounts(L, L.require(roto)) == []
    assert "2 of 2 slots" in machines.mount_weapon(L, 1, roto, _item(L, "ghost", "heavy-mount"), "ghost")


def test_autosoft_slots_are_half_the_pilot(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    roto = machines.build_machine(L, "Razor's Roto-drone", "roto-drone", "razor", 1, equipped=False)
    for kind in ("targeting", "evasion"):
        machines.mount_weapon(L, 1, roto, _item(L, "razor", f"autosoft-{kind}"), "razor")
    with pytest.raises(RulesRefusal, match="runs 2 autosofts at most"):
        machines.mount_weapon(L, 1, roto, _item(L, "razor", "autosoft-clearsight"), "razor")
    assert sr_lite.machine_pool(L, L.require(roto), "evasion")[0] == 6          # Pilot 3 + Evasion 3


def test_smoke_fills_a_zone_and_the_engine_takes_it_off(make_game):
    """Heavy smoke is -6 (SR5 p. 175) - past what a GM modifier can say (-4 each) - so the engine keeps the cloud on the
    fight's zone and puts it on every attack into, out of or inside it; thermographic eyes see ordinary smoke at -3,
    never thermal smoke."""
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    L = g.ledger
    encounters.start(g, 1, [{"name": "bar"}, {"name": "back room", "near": ["bar"]}],
                     {"razor": "bar", "kaz": "back room"}, hostile=["kaz"])
    can = _item(L, "razor", "smoke-grenade")
    out = dispatch(TurnContext(g, 2, g.current_scene_id()), "explode",
                   {"item_id": can, "holder_id": "razor", "thrown": True, "zone": "back room"})
    assert "a 10 m cloud of smoke" in out and "back room fills with smoke" in out and not L.holds("razor", can)
    assert L.stat("kaz", "physical_damage") == 0 and L.stat("kaz", "stun_damage") == 0      # a cloud hurts nobody
    atk, _, _ = encounters.attack_mods(g, "razor", "kaz", "firearms")      # (the next zone: near range, -1)
    assert atk == [("Heavy smoke (back room; near range doesn't add, p. 173)", -6)]
    L.update_entity("razor", props={**L.require("razor")["props"], "metatype": "dwarf"})   # thermographic eyes
    assert encounters.attack_mods(g, "razor", "kaz", "firearms")[0] == [
        ("Smoke (back room; thermographic; near range doesn't add, p. 173)", -3)]
    assert "heavy smoke" in "\n".join(encounters.packet_lines(g, encounters.active(g)))


def _smoked_street(g, kaz_at: str, cloud: str):
    """street - lobby - stairs - roof in a chain, Razor in the street, Kaz where asked, a cloud on one zone."""
    encounters.start(g, 1, [{"name": "street"}, {"name": "lobby"}, {"name": "stairs"}, {"name": "roof"}],
                     {"razor": "street", "kaz": kaz_at}, hostile=["kaz"])
    encounters.smoke(g, cloud, None, "smoke")
    return encounters.attack_mods(g, "razor", "kaz", "firearms")[0]


def test_a_shot_through_a_smoked_zone_takes_the_smoke(make_game):
    """Review E2: the card says -6 'into, out of or through it', but a shot from the street across a smoked lobby to
    the stairs took only the range. SR5 p. 174: smoke blocks line of sight - between the two, it's in the way. A way
    round the cloud as short as the straight one sees past it."""
    g = make_game(dice=ScriptedDice([2] * 50))
    setup_demo(g)
    assert _smoked_street(g, "stairs", "lobby") == [("Heavy smoke (lobby, between; far range doesn't add, p. 173)", -6)]
    enc = encounters.active(g)
    encounters.set_zones(enc, enc["zones"] + [{"name": "alley", "near": ["street", "stairs"]}])    # a way round it
    encounters.save(g, enc)
    assert encounters.attack_mods(g, "razor", "kaz", "firearms")[0] == [("Range: far (stairs)", -3)]
    atk = encounters.attack_mods(g, "kaz", "razor", "close_combat")[0]         # (a blow walks through it: no smoke)
    assert atk == []


def test_smoke_and_range_are_one_environmental_modifier(make_game):
    """SR5 p. 173: take only the most severe environmental condition, a row worse when two tie - and Range is one.
    Review E2: heavy smoke and extreme range came to -12 (book: -10), and -7/-9 at near and far (book: -6)."""
    g = make_game(dice=ScriptedDice([2] * 50))
    setup_demo(g)
    assert _smoked_street(g, "roof", "roof") == [
        ("Heavy smoke (roof; with extreme range, two at -6: a row worse, p. 173)", -10)]
    L = g.ledger
    L.update_entity("razor", props={**L.require("razor")["props"], "metatype": "dwarf"})   # smoke -3 to him
    assert encounters.attack_mods(g, "razor", "kaz", "firearms")[0] == [
        ("Range: extreme (roof; the smoke doesn't add, p. 173)", -6)]
    enc = encounters.active(g)
    enc["positions"]["kaz"] = "stairs"
    enc["zones"][2]["smoke"] = dict(enc["zones"][3]["smoke"])                   # the stairs smoked too: -3 and far -3
    encounters.save(g, enc)
    assert encounters.attack_mods(g, "razor", "kaz", "firearms")[0] == [
        ("Smoke (stairs; thermographic; with far range, two at -3: a row worse, p. 173)", -6)]


def test_smoke_at_a_zone_the_fight_hasnt_got_is_refused(make_game):
    """Review E2: 'the loading dock' in a fight of bar/door/street fell back to the thrower's own zone - -6 on his own
    shots, the grenade gone and nothing to clear the cloud. Refused before the can is spent, with the zones."""
    g = make_game(dice=ScriptedDice([2] * 50))
    setup_demo(g)
    L = g.ledger
    encounters.start(g, 1, [{"name": "bar"}, {"name": "door"}, {"name": "street"}], {"razor": "bar", "kaz": "street"},
                     hostile=["kaz"])
    can = _item(L, "razor", "smoke-grenade")
    with pytest.raises(RulesRefusal, match="No zone 'the loading dock' in this fight - zones: bar, door, street"):
        dispatch(TurnContext(g, 2, g.current_scene_id()), "explode",
                 {"item_id": can, "holder_id": "razor", "thrown": True, "zone": "the loading dock"})
    assert L.holds("razor", can) and not any(z.get("smoke") for z in encounters.active(g)["zones"])
    out = dispatch(TurnContext(g, 2, g.current_scene_id()), "explode",
                   {"item_id": can, "holder_id": "razor", "thrown": True, "targets": [{"id": "kaz", "range": "far"}]})
    assert "street fills with smoke" in out                                    # (no zone named: the target's)


def test_a_gas_grenade_is_breathed_not_dodged(make_game):
    g = make_game(dice=ScriptedDice([2] * 40))
    setup_demo(g)
    L = g.ledger
    can = _item(L, "razor", "gas-grenade")
    res = explosives.explode(L, g.dice, 1, can, "razor", [{"id": "kaz", "range": "close"}])
    assert "Power 5 Stun" in res["card"] and res["results"][0]["boxes"] == 5 and L.stat("kaz", "stun_damage") == 5


def test_a_dwarf_resists_gas_with_two_more_dice(make_game):
    """SR5 p. 66: a dwarf has '+2 dice for pathogen and toxin resistance', and CS is a toxin (p. 409) - chargen gave
    the trait, and nothing read it (review E2: 'Kaz: Body 3 + Willpower 4 = 7d6')."""
    g = make_game(dice=ScriptedDice([2] * 40))
    setup_demo(g)
    L = g.ledger
    L.update_entity("kaz", props={**L.require("kaz")["props"], "metatype": "dwarf"})
    body, will = int(L.stat("kaz", "body")), int(L.stat("kaz", "willpower"))
    res = explosives.explode(L, g.dice, 1, _item(L, "razor", "gas-grenade"), "razor", [{"id": "kaz", "range": "close"}])
    assert (f"Kaz: Body {body} + Willpower {will} + Toxin resistance (dwarf) 2 = {body + will + 2}d6"
            in res["card"])


def test_deliveries_are_told_coarsely():
    """A delivery lands on a part of day and is said the way a person would - never a countdown (§12)."""
    from roleplay.engine import clock
    D, h = clock.DAY, 60
    assert clock.snap(3 * D + 2 * h + 30) == 3 * D + 6 * h                     # due 02:30: it comes at dawn
    now = 3 * D + 15 * h                                                        # Day 4, afternoon
    assert [clock.ahead(clock.snap(now + x * h), now) for x in (3, 9, 18, 44, 70, 170, 400)] == [
        "this evening", "tonight", "tomorrow morning", "in two days", "in a few days", "in about a week",
        "in a couple of weeks"]


def test_character_creation_at_the_books_prices(make_game):
    """Priority B for most, D for the gifted; drones come bare, so a rigger's kit carries the autosofts and the mount,
    and they go onto the drones; nothing over Availability 12 at creation (SR5 p. 62)."""
    d = C.new_draft("rigger")
    d["name"] = "Lugnut"
    assert C.problems(d) == [] and C.budget(d) == 275_000
    assert C.shop(d, "buy", "sniper") == ["Ranger Arms SM-5 is Availability 16F - nothing over 12 at creation "
                                          "(find it in play)"]
    m = C.new_draft("mage")
    assert C.budget(m) == 50_000
    assert "none of yours has room" in C.shop(m, "buy", "autosoft-targeting")[0]
    assert "buy the drone first" in C.shop(m, "buy", "autosoft-targeting")[0]
    g = make_game()
    setup_demo(g)
    eid = C.build(g, d, "lugnut", 1)
    L = g.ledger
    roto, spy = sorted(machines.owned_by(L, eid), key=lambda x: x["name"], reverse=True)
    assert sr_lite.autosofts(L, roto) == {"targeting": 3, "evasion": 3} and machines.mounts(L, roto) == ["standard"]
    assert sr_lite.autosofts(L, spy) == {"clearsight": 3, "stealth": 3}
    assert any(i["name"] == "Lugnut's HK-227" for i in L.holdings(eid))         # (mounted in play: mount_weapon)


def test_a_second_autosoft_never_bumps_one_already_placed():
    """Review E2: the rigger's four autosofts fill the Roto-drone and the Fly-Spy; a second Targeting was accepted
    with no note - the plan places in the order bought, so it took the Fly-Spy's slot and the Stealth after it was
    left with nowhere to go, and the draft failed for an item the player never touched."""
    d = C.new_draft("rigger", "human")
    d["name"] = "Lugnut"
    assert C.problems(d) == [] and C.kit_plan(d)[1] == []
    have = dict(d["gear"])
    notes = C.shop(d, "buy", "autosoft-targeting")
    assert len(notes) == 1 and "none of yours has room for it - sell some of their kit first, or buy another drone" \
        in notes[0]
    assert d["gear"] == have and C.problems(d) == []
