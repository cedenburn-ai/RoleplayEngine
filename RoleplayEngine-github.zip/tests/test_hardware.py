"""Explosives and machines: the GM makes plain calls (who's how close, what space, who drives),
the engine does the math and enforces who may take a drone."""
import pytest

from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import explosives, machines, sr_lite
from roleplay.setup import setup_demo


def _guard(g, armor=2):
    eid, _ = g.introduce("npc", "Hallway Guard", "a bored guard", "civilian", turn=1)
    for a in ("body", "agility", "reaction", "strength", "willpower", "logic", "intuition", "charisma"):
        g.ledger.set_stat(eid, a, 3)
    vest, _ = g.introduce("item", "basic armor vest", "", owner_id=eid, turn=1)
    g.ledger.update_entity(vest, props={"armor": armor})
    return eid


# ── explosives ───────────────────────────────────────────────────────────

def test_the_chunky_salsa_hallway(make_game):
    g = make_game(dice=ScriptedDice([6, 3, 3]))                    # the guard's soak: 3 dice, one hit
    setup_demo(g)
    guard = _guard(g)
    g.ledger.give(guard, next(i["id"] for i in g.ledger.holdings("razor") if i["props"].get("explosive")), 1)
    nade = next(i for i in g.ledger.holdings(guard) if i["props"].get("explosive"))
    res = explosives.explode(g.ledger, g.dice, 1, nade["id"], guard,
                             [{"id": guard, "range": "point_blank", "aware": False}], space="tight")
    card = res["card"]
    assert "a tight space (+4, chunky salsa)" in card and "Blast  10P +4 (tight), AP -2" in card
    assert "Hallway Guard: point blank - 14P" in card                # 10 + 4, no dive: it was at his feet
    assert res["results"][0]["boxes"] == 13                          # Body 3 + armor (2 - 2 AP) = 3 dice, 1 hit
    assert sr_lite.condition(g.ledger, guard) == "dying"             # monitor 10, dead past 13: barely alive
    assert not any(i["props"].get("explosive") for i in g.ledger.holdings(guard))   # the grenade is spent


def test_bands_dives_and_space(make_game):
    g = make_game(dice=ScriptedDice([6, 6, 6, 6, 1, 1, 1] + [1] * 20))   # Kaz dives with 4 hits, then soaks badly
    setup_demo(g)
    nade = next(i for i in g.ledger.holdings("razor") if i["props"].get("explosive"))
    res = explosives.explode(g.ledger, g.dice, 1, nade["id"], "razor", [{"id": "kaz", "range": "close", "aware": True}],
                             space="open")
    r = res["results"][0]
    assert r["band"] == "far" and r["dv"] == 0 and r["boxes"] == 0   # close -> 2 bands clear -> far: out of it
    assert "Kaz: far · dives 7d6 -> 4 hits, 2 band(s) clear - out of the blast" in res["card"]
    assert "dives 7d6 -> 4 hits, 2 band(s) clear" in res["card"]                # Reaction 3 + Intuition 4
    assert next(i for i in g.ledger.holdings("razor") if i["props"].get("explosive"))["qty"] == 1   # one used


def test_the_confined_bonus_fades_and_cover_counts(make_game):
    g = make_game(dice=ScriptedDice([1] * 60))
    setup_demo(g)
    a = g.introduce("npc", "Near Guard", "", "civilian", turn=1)[0]
    b = g.introduce("npc", "Far Guard", "", "civilian", turn=1)[0]
    nade = next(i for i in g.ledger.holdings("razor") if i["props"].get("explosive"))
    res = explosives.explode(g.ledger, g.dice, 1, nade["id"], "razor",
                             [{"id": a, "range": "near", "aware": False}, {"id": b, "range": "far", "aware": False},
                              {"id": "razor", "range": "near", "aware": False, "cover": True}], space="tight")
    dv = {r["id"]: r["dv"] for r in res["results"]}
    assert dv[a] == 10 + 2 - 3 and dv[b] == 10 + 0 - 6                 # half the bonus at near, none far
    assert dv["razor"] == 10 + 2 - 3 - 6 and "Razor: near, behind cover" in res["card"]


def test_a_fumbled_throw_lands_at_your_feet(make_game):
    g = make_game(dice=ScriptedDice([1] * 40))                      # all ones: critical glitch, no soak hits
    setup_demo(g)
    nade = next(i for i in g.ledger.holdings("razor") if i["props"].get("explosive"))
    res = explosives.explode(g.ledger, g.dice, 1, nade["id"], "razor", [{"id": "kaz", "range": "near"}],
                             space="room", thrown=True)
    assert "CRITICAL GLITCH" in res["card"]
    me = next(x for x in res["results"] if x["id"] == "razor")
    assert me["band"] == "point_blank" and me["dv"] == 12              # 10 + 2 (room), at his own feet


def test_grenades_are_gear_and_not_guns(make_game):
    g = make_game()
    setup_demo(g)
    frag, _ = g.introduce("item", "frag grenade", "", owner_id="kaz", turn=1)
    assert g.ledger.get(frag)["props"]["dv"] == 11 and g.ledger.get(frag)["props"]["explosive"]
    with pytest.raises(LedgerError, match="use the explode tool"):
        sr_lite.attack(g.ledger, g.dice, 1, "kaz", "razor", frag)
    with pytest.raises(LedgerError, match="range must be one of"):
        explosives.explode(g.ledger, g.dice, 1, frag, "kaz", [{"id": "razor", "range": "6 feet"}])


# ── machines ─────────────────────────────────────────────────────────────

def test_a_drone_three_ways(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    drone, _ = g.introduce("drone", "Ghost's Roto-drone", "", owner_id="ghost", model="roto-drone", turn=1)
    d = L.get(drone)
    assert d["kind"] == "drone" and d["props"]["owner"] == "ghost" and L.stat(drone, "armor") == 1   # (book 4 / 3)
    assert any("drone SMG" in i["name"] for i in L.holdings(drone))
    assert "Ghost's Roto-drone [ghost-s-roto-drone] (ok)" in sr_lite.sheet(L, "ghost")    # (+ the decker's Fly-Spy)
    assert sr_lite.build_pool(L, drone, "firearms")[0] == 6            # Pilot 3 + Targeting 3
    assert sr_lite.build_pool(L, drone, "hacking")[0] == 6             # Device 3 doubled, against hackers
    machines.set_control(L, 1, drone, "ghost", "remote")
    n, parts = sr_lite.build_pool(L, drone, "firearms")
    assert n == 2 + 6 and parts[1][0] == "Ghost's Logic"               # Ghost's Firearms 2 + Logic 6
    with pytest.raises(LedgerError, match="no control rig"):
        machines.set_control(L, 1, drone, "ghost", "jumped")
    with pytest.raises(LedgerError, match="Win an opposed Hacking test"):
        machines.set_control(L, 1, drone, "kaz")
    assert machines.set_control(L, 1, drone, "autonomous").endswith("running on its own Pilot now")


def test_the_gm_sees_drones_and_a_gunless_drone_rams(make_game):
    from roleplay.substrate.packet import build_packet
    g = make_game(dice=ScriptedDice([6] * 6 + [1] * 40))
    setup_demo(g)
    dog, _ = g.introduce("drone", "Security Doberman", "", model="doberman", present=True, turn=1)
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], 9)
    assert "Security Doberman [security-doberman] - DRONE" in packet and "turret SMG" in packet
    crawler, _ = g.introduce("drone", "Crawler", "", model="crawler", present=True, turn=1)
    res = sr_lite.attack(g.ledger, g.dice, 1, crawler, "kaz")
    assert "with ramming" in res["card"] and "Pilot 4" in res["card"]       # (the book's Crawler: Pilot 4, p. 466)


def test_machines_take_no_stun_and_get_destroyed(make_game):
    g = make_game(dice=ScriptedDice([1] * 40))
    setup_demo(g)
    L = g.ledger
    drone, _ = g.introduce("drone", "Fly-Spy", "", model="fly-spy", turn=1)
    boxes, lines = sr_lite.resist_damage(L, g.dice, 1, drone, 6, "stun")
    assert boxes == 0 and "stun damage does nothing" in lines[0]
    sr_lite.resist_damage(L, g.dice, 1, drone, 20, "physical")
    assert sr_lite.condition(L, drone) == "destroyed" and "Structure 20/9" in sr_lite.condition_line(L, drone)
    with pytest.raises(LedgerError, match="destroyed and can't act"):
        sr_lite.request_test(L, g.dice, 1, drone, "perception", threshold=1)


def test_a_decker_steals_a_drone_only_by_winning_the_hack(make_game):
    g = make_game(dice=ScriptedDice([6] * 13 + [1] * 6))             # Ghost's 13 hacking dice vs the drone's 6
    setup_demo(g)
    drone, _ = g.introduce("drone", "Security Doberman", "", owner_id="kaz", model="doberman", turn=1)
    ctx = TurnContext(g, 9, g.current_scene_id())
    ctx.posted = {"ghost"}                                           # (Ghost takes the controls on his player's word)
    with pytest.raises(LedgerError, match="no control"):
        dispatch(ctx, "control_drone", {"drone_id": drone, "controller_id": "ghost"})
    card = dispatch(ctx, "request_test", {"actor_id": "ghost", "skill": "hacking", "reason": "seize the Doberman",
                                          "opposed_by": {"entity_id": drone}})
    assert "Device (Pilot 3 doubled) 6" in card and "SUCCESS" in card
    card = dispatch(ctx, "control_drone", {"drone_id": drone, "controller_id": "ghost"})
    assert card.splitlines()[0] == "[GEAR] Security Doberman: Ghost takes the controls (remote control)"
    # (the card's second line: Ghost's Firearms 2 + Logic 6 against the turret's Pilot 3 + Targeting 3)
    assert "Pools  Ghost (remote) vs its own Pilot: shoots 8 vs 6" in card.splitlines()[1]
    assert g.ledger.get(drone)["props"]["controller"] == "ghost" and g.ledger.get(drone)["props"]["owner"] == "kaz"


def test_new_characters_come_equipped():
    from roleplay.engine.rules import sr_lite as R
    assert R.ARCHETYPES["rigger"]["drones"] == ["roto-drone", "fly-spy", "bulldog"]
    assert R.ARCHETYPES["decker"]["drones"] == ["fly-spy"]
    assert any(name == "HE grenade" and qty == 2 for name, _, *rest in R.ARCHETYPES["street_samurai"]["gear"]
               for qty in rest)
