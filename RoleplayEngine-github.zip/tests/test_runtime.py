"""The bot as a background program: one copy at a time, a heartbeat file, and a stop that lets the turn finish."""
import asyncio
import json
from types import SimpleNamespace

from roleplay.discord_bot import runtime


def test_one_copy_at_a_time(tmp_path):
    first, second = runtime.InstanceLock(tmp_path), runtime.InstanceLock(tmp_path)
    assert not runtime.running(tmp_path)
    assert first.acquire() and not second.acquire()
    assert runtime.running(tmp_path)
    first.release()
    assert not runtime.running(tmp_path) and second.acquire()
    second.release()


class Director:
    def __init__(self, queue, resolving=False):
        self.queue, self.resolving, self._task = list(queue), resolving, None

    def waiting_on(self):
        return {"ghost"}


class Table:
    def __init__(self, campaign, queue=(), resolving=False):
        self.director = Director(queue, resolving)
        self.game = SimpleNamespace(path=SimpleNamespace(stem=campaign), _llm=None,
                                    art=SimpleNamespace(_pool=None),
                                    character_for=lambda h: {"name": h.title()})
        self.expected, self.last_active, self.handles, self.chargens = {"razor", "ghost"}, {"razor": 100.0}, {"1": "razor"}, {}
        self.world_task, self.sent, self.closed = None, [], False
        self.ch = SimpleNamespace(send=self._send)

    async def _send(self, text):
        self.sent.append(text)

    async def run(self, fn, *a):
        return fn(*a)

    async def drain(self):
        pass

    async def close(self):
        self.closed = True


class Bot:
    def __init__(self, tables):
        self.tables, self.bindings, self.stopping, self.closed = tables, {"11": {"campaign": "rage", "owner": "9"}}, False, False
        self.user, self.latency, self.guilds = "GM#0001", 0.052, [SimpleNamespace(id=5, name="The Table", member_count=4)]

    def get_channel(self, cid):
        return SimpleNamespace(name="general", guild=SimpleNamespace(name="The Table"))

    async def close(self):
        self.closed = True


def test_the_heartbeat_says_what_the_bot_is_doing(tmp_path):
    bot = Bot({11: Table("rage", queue=[("razor", "I draw.")])})
    rt = runtime.Runtime(bot, tmp_path)
    rt.set("online")
    s = json.loads((tmp_path / runtime.STATUS).read_text())
    assert s["state"] == "online" and s["latency_ms"] == 52 and s["guilds"][0]["name"] == "The Table"
    assert s["channels"] == {"11": {"name": "general", "guild": "The Table"}}      # every bound channel, open or not
    t = s["tables"][0]
    assert (t["campaign"], t["channel"], t["queued"], t["waiting_on"], t["active"]) == \
        ("rage", "general", ["razor"], ["ghost"], {"razor": 100.0})


def test_a_stop_request_lets_the_turn_finish_and_tells_whoever_got_dropped(tmp_path):
    busy, idle = Table("rage", queue=[("razor", "I run."), ("ghost", "Me too.")], resolving=True), Table("demo")
    bot = Bot({11: busy, 12: idle})
    rt = runtime.Runtime(bot, tmp_path)

    async def scenario():
        rt.start()
        runtime.request_stop(tmp_path, why="restart")
        await asyncio.sleep(1.5)
        assert bot.stopping and rt.state == "stopping" and "finishing the turn" in rt.detail
        busy.director.resolving = False                 # ...the turn in flight finishes
        for _ in range(40):
            if bot.closed:
                break
            await asyncio.sleep(0.25)

    asyncio.run(scenario())
    assert bot.closed and busy.closed and idle.closed and rt.state == "stopped"
    assert busy.sent == ["🔧 The GM is back in a minute - Razor, Ghost: your last action wasn't resolved, post it again "
                         "when I'm back."] and idle.sent == []
    assert json.loads((tmp_path / runtime.STATUS).read_text())["state"] == "stopped"
    assert not (tmp_path / runtime.CONTROL).exists()


def test_the_token_comes_from_the_old_project_and_never_shows(tmp_path, monkeypatch):
    monkeypatch.delenv("DISCORD_BOT_TOKEN", raising=False)
    monkeypatch.setenv("ROLEPLAY_CONFIG", str(tmp_path / "config.toml"))   # (no config.toml: the order is keys.py's)
    monkeypatch.setattr(runtime.sys, "platform", "linux")          # (skip the Windows user environment)
    cs = tmp_path / "Program.cs"
    cs.write_text('const string DISCORD_TOKEN = "abc.def";\n', encoding="utf-8")
    monkeypatch.setenv("ROLEPLAY_TOKEN_FILE", str(cs))
    assert runtime.find_token() == "abc.def" and runtime.token_source() == str(cs)
    monkeypatch.setenv("DISCORD_BOT_TOKEN", "from-env")
    assert runtime.find_token() == "from-env" and runtime.token_source() == "environment"
