"""Dying, finishing, recovering (DESIGN.md §7g, 2026-10-24): the dying bleed a box every Body minutes until someone
stabilizes them, an NPC left dying alone bleeds out when the scene moves on, a coup de grace kills the helpless
outright, and story time heals the hurt by itself."""
import pytest

from roleplay import encounters, flags
from roleplay.dm.tools import TurnContext, dispatch, run_tool
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool

JOEY = "joey-two-knives"          # a ganger: Body 4, monitor 10 - dying from 11, dead past 14
EXTRACTION = {"summary": "The crew waited it out.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}


def _game(make_game, llm=None, dice=None):
    g = make_game(llm or FakeLLM(), dice=dice)
    setup_demo(g)
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    return g


# ── bleeding and stabilizing ────────────────────────────────────────────
def test_the_dying_bleed_a_box_every_body_minutes(make_game):
    """SR5 p. 170: a box every (Body) minutes until stabilized - the minutes short of a box carry over. Live: Hollow
    Joe lay dying at exactly monitor + Body for eleven story hours, and the world paid a clinic for his care."""
    g = _game(make_game)
    L = g.ledger
    L.set_stat(JOEY, "physical_damage", 11)
    assert sr_lite.bleed(L, 2, JOEY, 3) is None and L.stat(JOEY, "bleed_minutes") == 3
    card = sr_lite.bleed(L, 2, JOEY, 5)                                     # 8 minutes in all: 2 boxes
    assert card.startswith("[DAMAGE] Joey Two-Knives is bleeding out: 2 boxes in 5 minutes (a box every Body 4 "
                           "minutes until someone stabilizes them, SR5 p. 170)")
    assert L.stat(JOEY, "physical_damage") == 13 and L.stat(JOEY, "bleed_minutes") == 0
    card = sr_lite.bleed(L, 2, JOEY, 600)
    assert card.startswith("[DAMAGE] Joey Two-Knives bleeds to death: 2 boxes")                # (no further than dead)
    assert sr_lite.condition(L, JOEY) == "dead" and L.stat(JOEY, "physical_damage") == 15
    assert sr_lite.bleed(L, 2, JOEY, 600) is None
    ev = L.events(2)[-1]
    assert ev["kind"] == "damage" and ev["payload"]["how"] == "bleeding" and ev["payload"]["status"] == "dead"
    L.set_stat("razor", "physical_damage", 12)                              # a dying PC: their player hears of Edge
    L.set_stat("razor", "bleed_minutes", 0)
    assert "burn Edge to live" in sr_lite.bleed(L, 2, "razor", 600)


def test_stabilizing_stops_the_bleeding(make_game):
    """First aid on someone dying is the stabilization test, First Aid + Logic (3), each retry at a cumulative -2
    (p. 209); it doesn't use up first aid, and new damage starts the bleeding again."""
    g = _game(make_game)
    L = g.ledger
    L.set_stat("ghost", "first_aid", 3)
    L.set_stat(JOEY, "physical_damage", 11)
    card = sr_lite.first_aid(L, ScriptedDice([2] * 30), 2, "ghost", JOEY, "physical")["card"]
    assert card.startswith("[HEAL] Ghost tries to stabilize Joey Two-Knives (dying; First Aid + Logic, threshold 3)")
    assert "NOT STABILIZED: still losing a box every 4 minutes - the next try is at -2" in card
    card = sr_lite.first_aid(L, ScriptedDice([6] * 30), 2, "ghost", JOEY, "physical")["card"]
    assert "- Tried before 2 =" in card and "STABILIZED: the bleeding stops" in card
    assert "dying, stabilized" in sr_lite.condition_line(L, JOEY)
    assert sr_lite.bleed(L, 2, JOEY, 60) is None and L.stat(JOEY, "physical_damage") == 11
    sr_lite._apply_boxes(L, JOEY, 1, "physical")                            # cut again: bleeding again
    assert not L.stat(JOEY, "stabilized") and sr_lite.bleed(L, 2, JOEY, 4)
    with pytest.raises(LedgerError, match="is dying - stabilize them first"):
        sr_lite.rest(L, g.dice, 2, JOEY, "physical", 3)
    sr_lite.first_aid(L, ScriptedDice([6] * 30), 2, "ghost", JOEY, "physical")
    card = sr_lite.first_aid(L, ScriptedDice([6] * 30), 2, "ghost", JOEY, "physical")["card"]
    assert "gives Joey Two-Knives first aid" in card and "recovers 3 physical" in card   # then first aid proper


def test_a_medic_has_to_be_awake(make_game, tmp_path):
    """Review: heal first_aid with no healer_id had dying Joey try to stabilize himself - and his failed try put Kaz's
    real one at -2. An unconscious Kaz could try too. Neither can act (OUT), so neither tries, and nothing counts
    against the next medic."""
    g = _game(make_game, dice=ScriptedDice([2] * 100))
    L = g.ledger
    L.set_stat(JOEY, "physical_damage", 11)                                 # dying
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = run_tool(ctx, tool("heal", target_id=JOEY, how="first_aid", damage_type="physical", reason="pressure"))
    assert out["is_error"] and out["content"].startswith(
        "Refused: Joey Two-Knives is dying and can't treat themselves - name who does (healer_id)")
    L.set_stat("kaz", "stun_damage", 12)                                    # out cold
    out = run_tool(ctx, tool("heal", target_id=JOEY, healer_id="kaz", how="first_aid", damage_type="physical",
                             reason="pressure"))
    assert out["content"].startswith("Refused: Kaz is unconscious and can't give first aid")
    assert not L.stat(JOEY, "stabilize_tries") and ctx.tool_errors == 0 and not flags.listing(tmp_path)
    L.set_stat("kaz", "stun_damage", 0)
    card = dispatch(ctx, "heal", {"target_id": JOEY, "healer_id": "kaz", "how": "first_aid", "damage_type": "physical",
                                  "reason": "pressure"})
    assert card.startswith("[HEAL] Kaz tries to stabilize Joey Two-Knives") and "Tried before" not in card


def test_rest_is_an_extended_test(make_game):
    """SR5 p. 207 is an Extended Test: a die fewer each roll after the first (p. 48)."""
    g = _game(make_game)
    L = g.ledger
    L.set_stat("razor", "stun_damage", 9)
    dice = ScriptedDice([2] * (8 + 7 + 6))                                  # Body 5 + Willpower 3, then 7, then 6
    card = sr_lite.rest(L, dice, 1, "razor", "stun", 3)["card"]
    assert "rests 3 hours (8d6 the first hour, a die fewer each after" in card and not dice.faces


def test_a_long_rest_goes_on_past_one_test_s_dice(make_game):
    """Review: a rest test runs dry after Body + Willpower hours, and recover dropped the rest of the skip - after '2
    weeks later' a quarter of the hurt still carried Stun and their Physical never healed, while thirty days healed
    everyone. The healing doesn't stop because one test did: a fresh test starts at the full pool."""
    g = _game(make_game, dice=ScriptedDice([1] * 28 + [6] * 100))          # Joey's first test (7d6 down to 1d6) misses
    L = g.ledger
    L.set_stat(JOEY, "stun_damage", 8)
    L.set_stat(JOEY, "physical_damage", 3)
    cards = sr_lite.recover(L, g.dice, 2, JOEY, 14 * 24 * 60, "14 days went by")
    assert cards[0].startswith("[HEAL] Joey Two-Knives rests 9 hours (7d6 the first hour, a die fewer each after, "
                               "afresh each time the dice ran out; 14 days went by): recovers 8 stun")
    assert cards[1].startswith("[HEAL] Joey Two-Knives rests 1 day (8d6 a day; 14 days went by): recovers 3 physical")
    assert sr_lite.condition(L, JOEY) == "ok" and not L.stat(JOEY, "rest_minutes")


# ── time passing in a turn ──────────────────────────────────────────────
def test_time_heals_the_hurt_and_bleeds_the_dying(make_game):
    """Live T175-T178: eleven story hours passed and Magic still carried 7 boxes of drain (-2 to every pool), and
    Hollow Joe still lay dying. Now a turn that moves the clock does both - outside a fight."""
    script = [([text("Three quiet hours in the back booth.\n<dm>\ntime: 3 hours later\n</dm>")], "end_turn")]
    g = _game(make_game, FakeLLM(script, EXTRACTION), dice=ScriptedDice([6] * 300))
    L = g.ledger
    L.set_stat("razor", "stun_damage", 6)
    L.set_stat(JOEY, "physical_damage", 11)
    res = g.run_turn([("razor", "We lie low.")])
    assert any(c.startswith("[HEAL] Razor rests 1 hour (8d6 an hour; 3 hours went by)") for c in res.cards)
    assert L.stat("razor", "stun_damage") == 0
    assert any(c.startswith("[DAMAGE] Joey Two-Knives bleeds to death") for c in res.cards)
    script = [([text("They trade fire for hours.\n<dm>\ntime: 2 hours later\n</dm>")], "end_turn")]
    g = _game(make_game, FakeLLM(script, EXTRACTION), dice=ScriptedDice([6] * 300))
    g.ledger.set_stat("razor", "stun_damage", 6)
    encounters.start(g, 1)
    encounters.note_attack(g, "razor", JOEY, False)                          # a fight on: nobody rests
    res = g.run_turn([("razor", "I keep shooting.")])
    assert not any(c.startswith("[HEAL]") for c in res.cards) and g.ledger.stat("razor", "stun_damage") == 6


def _skip(g, minutes, hurt=()):
    """One turn's story time through commit.time_passes, as commit runs it; hurt: who takes a wound that turn."""
    from roleplay.dm import commit
    t = g.turn_no() + 1
    ctx = TurnContext(g, t, g.current_scene_id(), clock_start=g.clock())
    for who in hurt:
        sr_lite.apply_damage(g.ledger, g.dice, t, who, 2, "stun", "none", reason="a stray kick")
    g.set_clock(g.clock() + minutes)
    g.conn.execute("INSERT INTO turns(id) VALUES(?)", (t,))
    return commit.time_passes(g, ctx, g.ledger.roster(g.current_scene_id()))


def test_rest_adds_up_across_turns(make_game):
    """Review: a story week told a morning and an evening at a time - no single skip a whole day - never healed a box
    of Physical, and no card said so (and the prompt told the GM not to call heal rest). What a skip leaves short of an
    hour or a day now waits for the next one, the way bleeding does; a new wound starts it over."""
    g = _game(make_game, dice=ScriptedDice([6] * 400))
    L = g.ledger
    L.set_stat("razor", "physical_damage", 4)
    assert _skip(g, 12 * 60) == [] and L.stat("razor", "rest_minutes") == 720
    cards = _skip(g, 12 * 60)
    assert cards == ["[HEAL] Razor rests 1 day (10d6 a day; 12 hours went by - 24 hours of rest in all): recovers 4 "
                     "physical -> Physical 0/11, Stun 0/10 (ok)"]
    assert not L.stat("razor", "rest_minutes")
    L.set_stat("razor", "stun_damage", 3)
    assert _skip(g, 30) == [] and L.stat("razor", "rest_minutes") == 30
    assert _skip(g, 30)[0].startswith("[HEAL] Razor rests 1 hour (8d6 an hour; 30 minutes went by - an hour of rest "
                                      "in all): recovers 3 stun")
    L.set_stat("razor", "physical_damage", 2)
    _skip(g, 10 * 60)
    assert L.stat("razor", "rest_minutes") == 600
    sr_lite.apply_damage(L, g.dice, g.turn_no(), "razor", 2, "stun", "none", reason="cut again")
    assert not L.stat("razor", "rest_minutes")                              # (a new wound: the rest starts over)
    assert _skip(g, 60)[0].startswith("[HEAL] Razor rests 1 hour (8d6 an hour; an hour went by)")   # (not '1 hours')


def test_a_wound_this_turn_sits_out_this_turn_s_clock(make_game):
    """Review: 'three hours later the Ancients come through the door; Razor cuts Joey down' - the time: line lands after
    the tools, so the engine bled Joey to death for the three hours before the cut, the fight still on, with nobody
    given a chance to stabilize him. Anyone hurt this turn sits its clock out, bleeding and resting alike; their time
    starts with the next turn's."""
    ex = {**EXTRACTION, "summary": "Three hours later the Ancients came; Razor cut Joey down.",
          "members": [{"id": "razor", "role": "actor"}, {"id": JOEY, "role": "target"}], "combat": {"over": False}}
    script = [([tool("fight", action="start", hostile=[JOEY]),
                tool("apply_damage", target_id=JOEY, dv=12, damage_type="physical", resist="none", source_id="razor",
                     reason="Razor's katana")], "tool_use"),
              ([text("Three hours of waiting, then the Ancients come through the door. Razor cuts Joey down.\n<dm>\n"
                     "time: 3 hours later\n</dm>")], "end_turn"),
              ([text("Joey gurgles on the floor.\n<dm>\ntime: 10 minutes later\n</dm>")], "end_turn")]
    g = _game(make_game, FakeLLM(script, ex), dice=ScriptedDice([3] * 600))
    L = g.ledger
    res = g.run_turn([("razor", "We wait for them, then I go for Joey.")])
    assert sr_lite.condition(L, JOEY) == "dying" and not any("bleed" in c for c in res.cards)
    res = g.run_turn([("razor", "I watch him.")])
    assert any(c.startswith("[DAMAGE] Joey Two-Knives is bleeding out: 2 boxes in 10 minutes") for c in res.cards)
    g = _game(make_game, dice=ScriptedDice([6] * 300))                      # resting too: only the old wounds mend
    g.ledger.set_stat("razor", "stun_damage", 4)
    cards = _skip(g, 120, hurt=["ghost"])
    assert cards and all(c.startswith("[HEAL] Razor") for c in cards) and g.ledger.stat("ghost", "stun_damage") == 2


def test_a_month_heals_everyone(make_game):
    g = _game(make_game)
    L = g.ledger
    L.set_stat("razor", "physical_damage", 9)
    L.set_stat("razor", "stun_damage", 4)
    assert sr_lite.recover(L, g.dice, 2, "razor", 40 * 24 * 60, "40 days went by") == [
        "[HEAL] Razor has weeks to mend (40 days went by): fully healed -> Physical 0/11, Stun 0/10 (ok)"]
    L.set_stat(JOEY, "physical_damage", 12)                                 # still bleeding: no mending
    assert sr_lite.recover(L, g.dice, 2, JOEY, 40 * 24 * 60) == []
    script = [([text("Two months go by.\n<dm>\ntime: 2 months later\n</dm>")], "end_turn")]
    g = _game(make_game, FakeLLM(script, EXTRACTION))
    L = g.ledger
    for who in ("razor", "tanaka"):                                         # (Tanaka's offscreen in Chinatown)
        L.set_stat(who, "physical_damage", 5)
    res = g.run_turn([("razor", "We lie low for the summer.")])
    assert any(c.startswith("[HEAL] Razor has weeks to mend (60 days went by)") for c in res.cards)
    assert not any("Tanaka" in c for c in res.cards) and L.stat("tanaka", "physical_damage") == 0


def test_the_dying_left_alone_bleed_out_when_the_scene_moves_on(make_game):
    """Fights don't move the story clock, so this is where bleeding out happens: the crew walks away from Joey dying
    on the floor with nobody awake beside him. Left with Kaz, he's the offscreen world's to decide."""
    def leave(bring):
        script = [([tool("cut_scene", title="Out in the rain", bring_ids=bring)], "tool_use"),
                  ([text("You step out into the rain.")], "end_turn")]
        g = _game(make_game, FakeLLM(script, EXTRACTION), dice=ScriptedDice([2] * 100))
        g.ledger.set_stat(JOEY, "physical_damage", 11)
        g.run_turn([("razor", "We leave him there.")])
        return g
    g = leave(["razor", "ghost", "kaz"])
    assert sr_lite.condition(g.ledger, JOEY) == "dead"
    kinds = [(e["kind"], e["payload"].get("how")) for e in g.ledger.events(g.turn_no())]
    assert kinds.index(("damage", "left to die")) < kinds.index(("scene_closed", None))
    g = leave(["razor", "ghost"])                                            # Kaz stays behind with him
    assert sr_lite.condition(g.ledger, JOEY) == "dying"


# ── the coup de grace ───────────────────────────────────────────────────
def test_a_coup_de_grace_kills_the_helpless(make_game, tmp_path):
    """Live T170/T171 (flag #65): 'kill the survivors' went to Magic's 1-die knife, which missed twice against men
    who couldn't move. The table's ruling (2026-10-24): a coup de grace on a helpless living target, with nobody left
    standing against the attacker, is certain - no roll."""
    g = _game(make_game, dice=ScriptedDice([2] * 100))
    L = g.ledger
    L.set_stat(JOEY, "stun_damage", 10)                                     # out cold
    ctx = TurnContext(g, 2, g.current_scene_id())
    ctx.edge_asks = {"razor": ("Razor", "push", "push it")}                  # (no roll: nothing for Edge to ride)
    out = dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": JOEY, "weapon_id": "razor-s-katana",
                                   "finish": True, "reason": "makes sure"})
    assert out.startswith("[ROLL] Razor finishes Joey Two-Knives - a coup de grace on a helpless target")
    assert "With Razor's Katana, no roll: Joey Two-Knives was unconscious and nobody stands against Razor" in out
    assert sr_lite.condition(L, JOEY) == "dead" and encounters.active(g) is None
    assert [e["kind"] for e in L.events(2)][-2:] == ["damage", "finish"]
    refused = lambda **kw: run_tool(ctx, tool("attack", attacker_id="razor", reason="finish", finish=True, **kw))  # noqa: E731
    out = refused(target_id="kaz")
    assert out["is_error"] and out["content"].startswith("Refused: Kaz can still fight back (ok) - finish is only for")
    assert refused(target_id=JOEY)["content"] == "Refused: Joey Two-Knives is already dead."
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", present=True, turn=2)
    assert "is a machine - a coup de grace is for the living" in refused(target_id=dog)["content"]
    assert ctx.tool_errors == 0 and not flags.listing(tmp_path)


def test_no_coup_de_grace_while_someone_still_stands(make_game):
    """Nobody stands against you, or no fight at all: mopping up the downed. A PC finished can still burn Edge, and a
    decker's limp body in VR is helpless too."""
    g = _game(make_game, dice=ScriptedDice([2] * 200))
    L = g.ledger
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=True, turn=1)
    encounters.start(g, 1)
    encounters.note_attack(g, "razor", JOEY, True)
    encounters.note_attack(g, "razor", "pastor-garvey", False)
    L.set_stat(JOEY, "physical_damage", 12)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = run_tool(ctx, tool("attack", attacker_id="razor", target_id=JOEY, reason="finish", finish=True))
    assert out["content"].startswith("Refused: Not while Pastor Garvey still stands against Razor")
    L.set_stat("pastor-garvey", "stun_damage", 10)
    assert "finishes Joey Two-Knives" in dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": JOEY,
                                                                  "finish": True, "reason": "now"})
    assert encounters.active(g)["attacks"][-1] == {"round": 1, "from": "razor", "to": JOEY, "hit": True}
    g = _game(make_game, dice=ScriptedDice([2] * 200))                      # no fight on: Joey finds Ghost jacked in
    L = g.ledger
    L.update_entity("ghost", props={**L.get("ghost")["props"], "matrix": {"host": "h", "mode": "vr"}})
    assert sr_lite.helpless(L, "ghost") and not sr_lite.helpless(L, "razor")
    out = dispatch(TurnContext(g, 2, g.current_scene_id()), "attack",
                   {"attacker_id": JOEY, "target_id": "ghost", "finish": True, "reason": "the decker's limp body"})
    assert "Bare-handed, no roll: Ghost was in hot-sim VR (body limp) and nobody stands against Joey Two-Knives" in out
    assert "Not dead yet? Ghost's player can burn Edge to live" in out and sr_lite.condition(L, "ghost") == "dead"


def test_kill_the_survivors_finishes_every_one_named(make_game):
    """Review: an attack with finish and `more` - the shape the tool asks for several strikes - killed the first and
    silently left the second unconscious, with nothing on the card. Each one named dies, every one checked (and a
    gun's rounds counted) before anyone does; one that costs an Action Phase - a player's character - goes alone."""
    g = _game(make_game, dice=ScriptedDice([2] * 200))
    L = g.ledger
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=True, turn=1)
    for who in (JOEY, "pastor-garvey"):
        L.set_stat(who, "stun_damage", 10)
    ctx = TurnContext(g, 2, g.current_scene_id())
    kill = lambda first, *rest, **kw: run_tool(ctx, tool("attack", attacker_id=kw.pop("by", "razor"), target_id=first,  # noqa: E731
                                                          finish=True, more=[{"target_id": x} for x in rest],
                                                          reason="kill the survivors", **kw))
    out = kill(JOEY, "kaz")
    assert out["content"].startswith("Refused: Kaz can still fight back") and sr_lite.condition(L, JOEY) == "unconscious"
    gun = "razor-s-ares-predator-v"
    L.set_item_state("razor", gun, {"loaded": 1})
    out = kill(JOEY, "pastor-garvey", weapon_id=gun)
    assert "has 1 round loaded - 2 coups de grace take 2" in out["content"] and sr_lite.condition(L, JOEY) == "unconscious"
    out = kill(JOEY, "pastor-garvey", weapon_id="razor-s-katana")["content"]
    assert out.startswith("[ROLL] Razor finishes Joey Two-Knives and Pastor Garvey - a coup de grace on each")
    assert out.count("no roll:") == 2 and "Pastor Garvey is dead" in out
    assert sr_lite.condition(L, JOEY) == sr_lite.condition(L, "pastor-garvey") == "dead"
    assert [e["payload"]["target"] for e in L.events(2) if e["kind"] == "finish"] == [JOEY, "pastor-garvey"]
    g = _game(make_game, dice=ScriptedDice([2] * 200))                      # Joey over two downed runners: one a call
    encounters.start(g, 1, hostile=[JOEY])
    for who in ("razor", "ghost"):
        g.ledger.set_stat(who, "stun_damage", 12)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = kill("razor", "ghost", by=JOEY)
    assert out["content"].startswith("Refused: A coup de grace on a player's character costs an Action Phase")
    assert sr_lite.condition(g.ledger, "razor") == "unconscious"
