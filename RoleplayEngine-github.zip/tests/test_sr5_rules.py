"""The SR5 gap fixes (DESIGN.md §7g): the rules brought back in line with the Shadowrun 5th Edition core rulebook -
magic's Force limit, armor and Stun, the smartlink, surprise, healing, thresholds, karma, the Matrix host, riggers
and speed."""
import pytest

from roleplay import encounters
from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import machines, magic, matrix, resonance, sr_lite
from roleplay.setup import setup_demo

from .test_magic import _mage


def _give(g, who, name, props):
    iid = g.ledger.create_entity("item", name, name, tier=0, props=props, turn=1)
    g.ledger.give(who, iid, 1)
    return iid


# ── magic ───────────────────────────────────────────────────────────────
def test_direct_spells_do_net_hits_and_the_force_limits_them(make_game):
    g = make_game(dice=ScriptedDice([6] * 14 + [2] * 4 + [2] * 10))          # 14 hits; Kaz resists 0; no soak
    setup_demo(g)
    sable = _mage(g)
    res = magic.cast(g.ledger, g.dice, 1, sable, "Manabolt", 3, [{"id": "kaz"}])
    assert "(limit: Force 3 -> 3)" in res["card"] and "takes 3P (no armor)" in res["card"]      # p. 281, 283
    assert "Drain  2S" in res["card"]                                       # 3 hits, under Magic 6: Stun


def test_mana_spells_dont_touch_machines(make_game):
    g = make_game(dice=ScriptedDice([6] * 80))
    setup_demo(g)
    sable = _mage(g)
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", turn=1)
    res = magic.cast(g.ledger, g.dice, 1, sable, "Stunbolt", 2, [{"id": dog}])
    assert "no mind, no aura - Stunbolt passes through" in res["card"]
    res = magic.cast(g.ledger, g.dice, 1, sable, "Invisibility", 2, [{"id": dog}])
    assert "a machine - Invisibility can't take hold on it" in res["card"]
    assert g.ledger.stat(dog, "physical_damage") == 0


def test_heal_works_once_per_set_of_wounds(make_game):
    g = make_game(dice=ScriptedDice([6] * 200))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    sr_lite._apply_boxes(L, "razor", 6, "physical")
    assert "Razor heals 4" in magic.cast(L, g.dice, 1, sable, "Heal", 4, [{"id": "razor"}])["card"]
    assert "already been healed by magic" in magic.cast(L, g.dice, 1, sable, "Heal", 4, [{"id": "razor"}])["card"]
    L.set_stat("ghost", "first_aid", 2)
    with pytest.raises(LedgerError, match="healed by magic"):
        sr_lite.first_aid(L, g.dice, 1, "ghost", "razor", "physical")
    sr_lite._apply_boxes(L, "razor", 1, "physical")                         # a new wound: magic can try again
    assert "Razor heals 2" in magic.cast(L, g.dice, 1, sable, "Heal", 2, [{"id": "razor"}])["card"]


def test_speed_is_initiative_dice(make_game):
    """Initiative dice raise the Initiative Score - the Action Phases come from the score (every 10 is one), not one
    action a die. Increase Reflexes is +1 Initiative a hit and a die every 2 hits (SR5 p. 288)."""
    g = make_game(dice=ScriptedDice([6] * 120))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"],
                                  "spells": list(L.get(sable)["props"]["spells"]) + ["increase reflexes"]})
    magic.cast(L, g.dice, 1, sable, "Increase Reflexes", 4, [{"id": "razor"}])             # 4 hits: +4, 2 dice
    assert sr_lite.initiative_dice(L, "razor") == (2, ["Increase Reflexes"])
    assert L.stat("razor", "spell_init_bonus") == 4
    assert sr_lite.initiative_rating(L, "razor") == (13, 3, ["Reaction + Intuition + 4 (Increase Reflexes)",
                                                            "Increase Reflexes"])       # R 5 + I 4 + 4, 1 + 2 dice
    _give(g, "ghost", "Wired reflexes", {"augmentation": True})
    assert sr_lite.initiative_rating(L, "ghost")[1:] == (2, ["Reaction + Intuition", "Wired reflexes 1"])
    enc, _ = encounters.start(g, 1)
    lines = "\n".join(encounters.packet_lines(g, encounters.get(g, enc["id"])))
    assert "Initiative, round 1" in lines and "Speed" not in lines
    assert "Razor 31 - 4 actions" in lines                                  # 13 + 3 sixes: 31, four passes
    magic.end_spell(L, sable, "Increase Reflexes")
    assert sr_lite.initiative_dice(L, "razor")[0] == 0 and L.stat("razor", "spell_init_bonus") == 0


# ── combat and healing ──────────────────────────────────────────────────
def test_armor_turns_light_hits_into_stun_and_positive_ap_counts(make_game):
    g = make_game(dice=ScriptedDice([2] * 60))
    setup_demo(g)
    L = g.ledger
    _, lines = sr_lite.resist_damage(L, g.dice, 1, "razor", 6, "physical", ap=-1)    # jacket 4, AP -1 counts -1
    assert "lands as Stun" in "\n".join(lines)
    assert (L.stat("razor", "stun_damage"), L.stat("razor", "physical_damage")) == (6, 0)
    _, lines = sr_lite.resist_damage(L, g.dice, 1, "ghost", 13, "physical", ap=5)    # frag: +5 counts +2
    assert "Lined coat 3 AP+2" in "\n".join(lines) and "lands as Stun" not in "\n".join(lines)
    assert sr_lite.scaled_ap(-2) == -1 and sr_lite.scaled_ap(-5) == -2 and sr_lite.scaled_ap(0) == 0


def test_the_smartlink_and_an_unaware_target(make_game):
    g = make_game(dice=ScriptedDice([2] * 120))
    setup_demo(g)
    L = g.ledger
    _give(g, "razor", "Smartlink", {"bonus": {"firearms": 2}, "augmentation": True, "essence": 0.2})
    assert "Smartlink 2" in sr_lite.attack(L, g.dice, 1, "razor", "kaz", "razor-s-ares-predator-v", reason="x")["card"]
    assert "Smartlink" not in sr_lite.attack(L, g.dice, 1, "razor", "kaz", "razor-s-katana", reason="x")["card"]
    res = sr_lite.attack(L, g.dice, 1, "razor", "kaz", "razor-s-ares-predator-v", reason="x", unaware=True)
    assert "Defend Unaware - no dodge 0 = 0d6" in res["card"]


def test_an_ambush_leaves_the_flat_footed_without_a_dodge(make_game):
    g = make_game(dice=ScriptedDice([2] * 300))
    setup_demo(g)
    _, card = encounters.start(g, 1, ambushers=["kaz"])
    assert "can't dodge it" in card and encounters.unaware(g, "razor") and not encounters.unaware(g, "kaz")
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": "kaz", "target_id": "razor", "weapon_id": "kaz-s-hold-out-pistol",
                                   "reason": "the ambush"})
    assert "Unaware - no dodge" in out
    encounters.note_attack(g, "razor", "kaz", False)                        # Razor acts: no longer flat-footed
    assert not encounters.unaware(g, "razor")


def test_first_aid_rest_and_care(make_game):
    g = make_game(dice=ScriptedDice([6] * 300))
    setup_demo(g)
    L = g.ledger
    L.set_stat("ghost", "first_aid", 3)
    sr_lite._apply_boxes(L, "razor", 6, "physical")
    card = sr_lite.first_aid(L, g.dice, 1, "ghost", "razor", "physical")["card"]
    assert "No medkit 2" in card and "recovers 3 physical" in card and "capped at First Aid 3" in card
    with pytest.raises(LedgerError, match="had first aid"):
        sr_lite.first_aid(L, g.dice, 1, "ghost", "razor", "physical")
    sr_lite._apply_boxes(L, "razor", 4, "stun")
    with pytest.raises(LedgerError, match="Stun damage - it heals first"):
        sr_lite.rest(L, g.dice, 1, "razor", "physical", 2)
    assert "rests 1 hour" in sr_lite.rest(L, g.dice, 1, "razor", "stun", 3)["card"]          # 8 hits the first hour
    assert "recovers 3 physical" in sr_lite.rest(L, g.dice, 1, "razor", "physical", 2)["card"]
    sr_lite._apply_boxes(L, "razor", 2, "stun")
    assert "(stim patch)" in sr_lite.heal(L, 1, "razor", "stun", 2, "stim patch")["card"]
    with pytest.raises(LedgerError, match="Physical damage only"):
        sr_lite.heal(L, 1, "razor", "stun", 2, "Heal", how="magic")


def test_thresholds_run_on_the_books_scale(make_game):
    g = make_game()
    setup_demo(g)
    res = sr_lite.request_test(g.ledger, ScriptedDice([2] * 20), 1, "razor", "perception", threshold=9)
    assert "(threshold 9)" in res["card"]


# ── karma ───────────────────────────────────────────────────────────────
def test_karma_buys_the_natural_rating(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    _give(g, "razor", "Razor's Muscle replacement", {"augmentation": True})          # (as chargen names it)
    assert sr_lite.advance_cost(L, "razor", "agility") == (7, 30, None)       # 6 = 5 natural + 1 chrome
    L.set_stat("razor", "agility", 7)
    assert "6 natural + 1 chrome" in sr_lite.advance_cost(L, "razor", "agility")[2]
    sable = _mage(g)
    L.set_stat(sable, "essence", 4.5)                                        # 1.5 lost: 2 points of Magic gone
    L.set_stat(sable, "magic", 4)
    assert "the chrome took the rest" in sr_lite.advance_cost(L, sable, "magic")[2]
    assert resonance.LEARN_COST == 4
    encounters.start(g, 1)
    with pytest.raises(LedgerError, match="mid-fight"):
        g.advance("razor", "perception")


# ── the Matrix ──────────────────────────────────────────────────────────
def test_the_host_answers_like_the_book(make_game):
    g = make_game(dice=ScriptedDice([2] * 400))
    setup_demo(g)
    L = g.ledger
    hid, _ = g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=4, turn=1)
    payroll, _ = g.introduce("item", "Payroll file", "the lab's payroll", turn=1)
    L.give(hid, payroll, 1)
    card = matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, access="admin")["card"]
    assert "Login: admin" in card
    st = matrix.state(L, "ghost")
    st["overwatch"] = 26
    matrix._save(L, "ghost", st)
    card = matrix.act(L, g.dice, 2, "ghost", "data", target=payroll, effect="copy")["card"]
    assert "(+0) - legal, inside their access" in card                      # legal work feeds nothing
    assert "HOST ALERT: launches Patrol IC in Hub A (3 more IC still dormant)" in card     # one IC a beat (flag #31)
    assert "attacks" not in card
    card = matrix.act(L, g.dice, 3, "ghost", "search")["card"]
    assert "HOST ALERT: launches Track IC in Comms (2 more IC still dormant)" in card and "moves" not in card
    card = matrix.act(L, g.dice, 4, "ghost", "search")["card"]
    assert "launches Killer IC" in card and "Track IC moves to" in card     # last beat's IC comes for them
    track = next(ic for ic in L.get(hid)["props"]["ic"] if ic["type"] == "track")
    hit = matrix._ic_attack(L, ScriptedDice([6] * 8 + [2] * 9), 3, "ghost", track, {})
    assert "not enough marks to follow it home (0/2)" in hit[0] and not matrix.state(L, "ghost").get("traced")
    with pytest.raises(LedgerError, match="Admin happens in the Core"):
        matrix.act(L, g.dice, 3, "ghost", "admin", effect="stand down the IC")
    matrix.act(L, g.dice, 3, "ghost", "jack_out")
    st, hp = matrix.state(L, "ghost"), L.get(hid)["props"]
    assert hid not in (st.get("creds") or {}) and hid not in (st.get("cleared") or {}) and hp["alert"] == 1
    assert not any(ic["active"] for ic in hp["ic"] if ic["type"] != "patrol")       # the IC stands down
    card = matrix.act(L, g.dice, 10, "ghost", "jack_in", hid)["card"]       # days later: a quiet host, from outside
    assert "At Entry (blue, open)" in card and "Login" not in card and L.get(hid)["props"]["alert"] == 0
    matrix.act(L, g.dice, 10, "ghost", "jack_out")
    st = matrix.state(L, "ghost")
    st["deck_damage"] = matrix.deck_monitor(4)
    matrix._save(L, "ghost", st)
    with pytest.raises(LedgerError, match="bricked"):
        matrix.act(L, g.dice, 11, "ghost", "jack_in", hid)
    card = matrix.act(L, ScriptedDice([6] * 20), 11, "ghost", "repair")["card"]
    assert "fixed" in card and matrix.state(L, "ghost")["deck_damage"] < matrix.deck_monitor(4)


# ── riggers ─────────────────────────────────────────────────────────────
def test_a_rigger_rides_one_machine_and_feels_it(make_game):
    g = make_game(dice=ScriptedDice([2] * 300))
    setup_demo(g)
    L = g.ledger
    _give(g, "razor", "Control rig", {"control_rig": 2, "augmentation": True})
    roto = machines.build_machine(L, "Razor's Roto-drone", "roto-drone", "razor", 1)
    dog = machines.build_machine(L, "Razor's Doberman", "doberman", "razor", 1)
    machines.set_control(L, 1, roto, "razor", "jumped")
    assert "Roto-drone drops back to remote control" in machines.set_control(L, 1, dog, "razor", "jumped")
    assert L.get(roto)["props"]["control"] == "remote"
    assert ("Also running 1 other machine", -2) in sr_lite.build_pool(L, dog, "firearms")[1]
    res = sr_lite.attack(L, g.dice, 1, "kaz", "razor", "kaz-s-hold-out-pistol", reason="x")
    assert "Jumped into Razor's Doberman, body limp" in res["card"]
    _, lines = sr_lite.resist_damage(L, g.dice, 1, dog, 6, "physical")
    assert any("Biofeedback: Razor is jumped in - 3S" in x for x in lines) and L.stat("razor", "stun_damage") == 3
    n, parts = sr_lite.build_pool(L, dog, "hacking")
    assert n == 7 and "Razor jumped in" in parts[0][0]                       # Logic 2 + Willpower 3 + rig 2 > Pilot x2
