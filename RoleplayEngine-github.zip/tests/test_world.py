"""The offscreen world: personas, triggers, agendas, real dice and money, hidden truth, hooks."""
from types import SimpleNamespace

from roleplay.dm import world
from roleplay.dm.turn import recap
from roleplay.engine.dice import ScriptedDice
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool

PERSONA = {"temperament": "Gruff and watchful; slow to anger, slower to forgive.",
           "motivations": "Keep the Lucky Shot open and stay useful to everyone.", "lines": "Never kills in his bar.",
           "prejudices": "Distrusts corp suits and elves who talk fast.", "voice": "Gravel, few words, ork slang.",
           "backstory": "Ex-Lone Star beat cop who bought the bar with his pension.",
           "hooks": ["Still owes a sergeant at Lone Star"], "connections": "Lone Star contacts, Ancients runners.",
           "secret": "He sells tips to Lone Star."}


class WorldLLM(FakeLLM):
    """Scripted DM and extractor, plus personas and per-NPC agent decisions."""

    def __init__(self, dm_script=None, extraction=None, agent=None):
        super().__init__(dm_script, extraction)
        self.agent = agent or {}
        self.world_calls, self.texts = [], []

    def text(self, model, system, user, **kw):
        self.texts.append(user)
        return "scene summary"

    def structured(self, model, system, user, schema, **kw):
        if system is world.PERSONA_SYSTEM:
            self.world_calls.append(("persona", user))
            return PERSONA
        if system is world.AGENT_SYSTEM:
            self.world_calls.append(("agent", user))
            npc = user.split("[", 1)[1].split("]", 1)[0]
            return self.agent.get(npc) or {**NONE}
        return super().structured(model, system, user, schema, **kw)


NONE = {"decision": "none", "agenda_id": "", "goal": "", "targets": [], "action": "", "test_skill": "",
        "test_threshold": 0, "on_success": "", "on_failure": "", "learns_on_success": [], "spend": 0,
        "new_people": [], "hook": "", "hook_about": [], "hook_replaces": [], "feeling_about": "", "feeling_attitude": 0,
        "feeling_belief": "", "wait_minutes": 30, "contacts": []}


def _personas(g):
    for e in g.ledger.entities(kind="npc"):
        g.ledger.update_entity(e["id"], props={**e["props"], "persona": PERSONA})


def test_personas_are_written_and_reach_the_packet(make_game):
    llm = WorldLLM()
    g = make_game(llm)
    setup_demo(g)
    lines = g.world_pass()
    assert len([c for c in llm.world_calls if c[0] == "persona"]) == 2            # a few per pass
    assert any("persona for" in x for x in lines)
    while any(not world.persona(e) for e in g.ledger.entities(kind="npc") if e["tier"] >= 1):
        g.world_pass()
    assert "GM NOTES (their secrets" in next(u for k, u in llm.world_calls if "Kaz [kaz]" in u)  # fits his secret
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hi")], g.turn_no() + 1)
    assert "Persona (GM-only, play them true to it): Gruff and watchful" in packet


def _commlink_story(dice_faces, kaz_move):
    """Razor whispers and lifts Kaz's commlink; then the party leaves the bar."""
    dm = [([tool("transfer_item", item_id="kaz-s-commlink", from_id="kaz", to_id="razor")], "tool_use"),
          ([text("It slides into your sleeve. Kaz never looks up.")], "end_turn"),
          ([SimpleNamespace(type="tool_use", name="introduce", id="tu_loc",
                            input={"kind": "location", "name": "Redmond Street", "description": "rain and neon"}),
            tool("cut_scene", title="Out in the rain", location_id="redmond-street", bring_ids=["razor", "ghost"])],
           "tool_use"),
          ([text("You step out into the rain.")], "end_turn")]
    extractions = iter([
        {"summary": "Razor secretly lifted Kaz's commlink from behind the bar.", "recalled": [], "facts": [],
         "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
         "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "mentioned"}]},
        {"summary": "Razor and Ghost left the Lucky Shot for the street.", "recalled": [], "facts": [],
         "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
         "members": [{"id": "razor", "role": "actor"}, {"id": "ghost", "role": "actor"}]}])
    return WorldLLM(dm, lambda user: next(extractions), {"kaz": kaz_move}), ScriptedDice(dice_faces)


KAZ_INVESTIGATES = {**NONE, "decision": "start", "goal": "Find out who took my commlink",
                    "targets": ["kaz-s-commlink"], "action": "Kaz pulls the bar's camera footage",
                    "test_skill": "perception", "test_threshold": 2,
                    "on_success": "Kaz scrubbed the camera footage and saw Razor palm his commlink.",
                    "on_failure": "Kaz scrubbed the footage but the angle was useless.",
                    "learns_on_success": ["T4"], "spend": 300,
                    "new_people": [{"name": "Mako", "description": "ork ganger who owes Kaz", "template": "ganger"}],
                    "hook": "Mako and two friends will be waiting for Razor at his next stop.", "hook_about": ["razor"],
                    "feeling_about": "razor", "feeling_attitude": -3,
                    "feeling_belief": "Kaz thinks Razor robbed him under his own roof.", "wait_minutes": 40}


def _play_story(make_game, faces, move):
    llm, dice = _commlink_story(faces, move)
    g = make_game(llm, dice=dice)
    setup_demo(g)
    _personas(g)
    g.introduce("item", "Kaz's commlink", "battered orange commlink", owner_id="kaz", turn=g.turn_no())
    g.run_turn([("razor", "I lift Kaz's commlink while he's busy.")], private="razor")      # T4
    assert world.plan(g) == [] or all(j.npc != "kaz" for j in world.plan(g))   # on screen: the DM plays him
    g.run_turn([("razor", "We head out.")])                                                 # T5: the party leaves
    return g, llm


def test_kaz_notices_investigates_and_sends_someone(make_game):
    g, llm = _play_story(make_game, [6] * 8, KAZ_INVESTIGATES)
    L, S = g.ledger, g.sub
    lines = g.world_pass()
    user = next(u for k, u in llm.world_calls if k == "agent" and "Kaz [kaz]" in u)
    assert "Your Kaz's commlink is gone" in user and "you didn't see it go" in user        # he noticed
    assert "left \"Selling the chip\"" in user                                                # the party left him
    assert "HIDDEN TRUTH" in user and "[T4]" in user                                       # fair resolution
    assert any("learns T4" in x and "hook H1" in x for x in lines)

    a = world.agendas_of(g, "kaz")[0]
    assert a["goal"] == "Find out who took my commlink" and a["steps"] == 1 and a["next_time"] == g.clock() + 40
    assert g.conn.execute("SELECT how FROM knows WHERE holder='kaz' AND node_id='T4'").fetchone()["how"] == "discovered"
    assert L.stat("kaz", "nuyen") == 2000 - 300 and L.find("Mako")
    assert int(L.stat("kaz", "attitude:razor")) == -3
    w = S.node("W1")
    assert w["visibility"] == "offscreen" and "saw Razor palm" in w["text"]
    assert dict(S.members_of("W1")) == {"kaz": "actor", "mako": "actor", "kaz-s-commlink": "mentioned"}
    assert "W1" not in {r["id"] for r in S.witnessed_slices("razor")}                     # no PC saw it
    recap(g)
    assert "Kaz" in llm.texts[-1] and "palm" not in llm.texts[-1]                       # recaps stay public

    # the DM sees it where Razor is: the agenda, its latest step, and the hook ready to land
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "Where to?")], 6)
    assert "THE WORLD IN MOTION" in packet and "wants: Find out who took my commlink" in packet
    assert "[A1] Kaz (now: The Lucky Shot (where they were last seen) - " in packet and " from here)" in packet
    assert "OFFSCREEN, no PC saw it - only Kaz, Mako know" in packet
    assert "[H1] READY HOOK (from Kaz" in packet and "Mako and two friends" in packet

    # the DM lands it
    g.llm.dm_script = [([text("Three orks peel off the wall.\n<dm>\nlanded H1: Mako's crew jumped Razor.\n</dm>")],
                        "end_turn")]
    g.llm.extraction = {**NONE, "summary": "Mako's crew jumped Razor.", "recalled": [], "facts": [], "told": [],
                        "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                        "members": [{"id": "razor", "role": "target"}]}
    g.run_turn([("razor", "I keep walking.")])
    assert g.conn.execute("SELECT status FROM hooks WHERE id='H1'").fetchone()["status"] == "landed"


def test_a_failed_roll_learns_nothing_and_costs_nothing(make_game):
    g, _ = _play_story(make_game, [1, 2, 2, 3, 3, 4, 4, 4], KAZ_INVESTIGATES)
    lines = g.world_pass()
    assert any("failure" in x for x in lines) and not any("learns" in x or "hook" in x for x in lines)
    assert g.conn.execute("SELECT 1 FROM knows WHERE holder='kaz' AND how='discovered'").fetchone() is None
    assert g.ledger.stat("kaz", "nuyen") == 2000 and not g.ledger.find("Mako")
    assert "useless" in g.sub.node("W1")["text"] and world.agendas_of(g, "kaz")[0]["status"] == "active"


def test_money_is_real(make_game):
    g, _ = _play_story(make_game, [6] * 8, {**KAZ_INVESTIGATES, "spend": 50000})
    lines = g.world_pass()
    assert any("couldn't raise 50,000 nuyen" in x for x in lines)
    assert g.ledger.stat("kaz", "nuyen") == 2000 and not g.ledger.find("Mako")


def test_agenda_from_the_dm_block_and_due_turns(make_game):
    llm = WorldLLM([([text("Kaz watches you go.\n<dm>\nagenda kaz: find out who Razor really works for\n</dm>")],
                     "end_turn")],
                   {**NONE, "summary": "Kaz watched Razor.", "recalled": [], "facts": [], "told": [], "minutes_elapsed": 0,
                    "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                    "members": [{"id": "kaz", "role": "actor"}]})
    g = make_game(llm)
    setup_demo(g)
    _personas(g)
    res = g.run_turn([("razor", "I leave a tip.")])
    a = world.agendas_of(g, "kaz")[0]
    assert a["by"] == "dm" and a["next_time"] == g.clock() + 10 and "Kaz watches you go." == res.narration
    g.ledger.leave(g.current_scene_id(), ["kaz"])                   # Kaz is offscreen now
    g.conn.execute("UPDATE agendas SET next_time=0")
    assert [j.npc for j in world.plan(g) if j.kind == "agent"] == ["kaz"]
    g.set_world(False)
    assert world.plan(g) == []


def test_waiting_is_not_a_step_hooks_stay_few_and_the_dying_rest(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    g.ledger.leave(g.current_scene_id(), ["kaz"])                        # offscreen
    aid = world.add_agenda(g, "kaz", "find the thief", ["razor"], g.turn_no(), by="dm")

    def step(**kw):
        llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, **kw}
        g.conn.execute("UPDATE agendas SET next_time=0")
        return g.world_pass()

    moves = ["Kaz leaned on an old Lone Star sergeant for gossip.", "Kaz bribed the night clerk at the Hotel Seville.",
             "Kaz traced a credstick transfer through a Tacoma fence."]
    for i, move in enumerate(moves):
        step(action=move, on_success=move, hook=f"hook {i}", hook_about=["razor"])
    ready = lambda: [r["id"] for r in g.conn.execute("SELECT id FROM hooks WHERE status='ready' ORDER BY rowid")]  # noqa: E731
    assert ready() == ["H2", "H3"]                                        # at most two live threads per NPC
    step(action="Kaz staked out a rooftop over the docks.", on_success="Kaz staked out a rooftop over the docks.",
         hook="hook 3", hook_about=["razor"], hook_replaces=["H2"])
    lines = step(action="Kaz staked out the docks from a rooftop.", on_success="Kaz staked out the docks from a rooftop.")
    assert any("nothing new" in x for x in lines)                        # the same move again is waiting
    assert ready() == ["H3", "H4"]
    assert "YOUR PENDING HOOKS" in llm.world_calls[-2][1] and "[H2] hook 1" in llm.world_calls[-2][1]

    events = g.conn.execute("SELECT COUNT(*) FROM nodes WHERE visibility='offscreen'").fetchone()[0]
    step(action="", wait_minutes=90)                                     # waiting: no step, just later
    assert g.conn.execute("SELECT COUNT(*) FROM nodes WHERE visibility='offscreen'").fetchone()[0] == events
    assert world.agendas_of(g, "kaz")[0]["next_time"] == g.clock() + 90

    g.ledger.set_stat("kaz", "physical_damage", 11)                      # past his monitor: dying
    g.conn.execute("UPDATE agendas SET next_time=0")
    assert all(j.npc != "kaz" for j in world.plan(g) if j.kind == "agent")
