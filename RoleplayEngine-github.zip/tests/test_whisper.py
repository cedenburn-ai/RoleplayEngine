"""Whispers: private turns. Same rules and authority, but only whoever perceived it remembers it."""
import asyncio

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm.turn import recap
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool
from .test_discord import FakeChannel

WHISPER_EXTRACTION = {"summary": "Razor quietly palmed Kaz's spare maglock keycard from behind the bar.",
                      "recalled": [], "told": [], "new_entities": [],
                      "facts": [{"text": "Razor has Kaz's spare maglock keycard.", "about": ["razor", "kaz"],
                                 "replaces": ""}],
                      "moved_to": {"location": "The Back Alley", "description": "", "who": ["razor"]},
                      "members": [{"id": "razor", "role": "actor"}]}


class RecordingLLM(FakeLLM):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.texts = []

    def text(self, model, system, user, **kw):
        self.texts.append(user)
        return "scene summary"


def _whisper_script():
    return [([tool("request_test", actor_id="razor", skill="stealth", threshold=2, reason="palm the keycard"),
              tool("cut_scene", title="Alley", location="The Back Alley")], "tool_use"),
            ([text("You lean on the bar and the keycard slides into your sleeve. Nobody looks up.")], "end_turn")]


def test_private_turn_is_remembered_only_by_who_saw_it(make_game):
    llm = RecordingLLM(_whisper_script(), WHISPER_EXTRACTION)
    g = make_game(llm)
    setup_demo(g)
    res = g.run_turn([("razor", "I palm Kaz's spare keycard while he's busy.")], private="razor")
    t = res.turn_id
    assert "WHISPER: this turn is private. Razor sent it" in llm.dm_requests[0]
    assert g.current_scene_id() == 3                              # the scene can't cut, even though the DM tried
    assert res.info["auto_cut"] is None                           # ...or be moved by the extractor
    assert g.conn.execute("SELECT private FROM turns WHERE id=?", (t,)).fetchone()["private"] == "razor"
    assert g.sub.node(f"T{t}")["visibility"] == "private"
    assert g.sub.node(res.info["facts"][0])["visibility"] == "private"
    assert f"T{t}" in {r["id"] for r in g.sub.witnessed_slices("razor")}
    assert f"T{t}" not in {r["id"] for r in g.sub.witnessed_slices("ghost")}   # Ghost was in the room, didn't see
    assert f"T{t}" not in {r["id"] for r in g.sub.witnessed_slices("kaz")}

    # the next public turn: the GM sees it, tagged, but its narration isn't "your last narration"
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "So, Tanaka?")], t + 1)
    assert "WHISPER, private - only Razor knows: Razor quietly palmed" in packet
    assert "keycard slides into your sleeve" not in packet
    recap(g)
    assert "palmed" not in llm.texts[-1]                          # public recaps never repeat a whisper
    assert g.undo_target() == {"id": t, "private": "razor"}


def test_failed_extraction_does_not_hand_the_room_a_whisper(make_game):
    g = make_game(FakeLLM([([text("You slip it into your sleeve.")], "end_turn")], extraction=None))
    setup_demo(g)
    res = g.run_turn([("razor", "I pocket the keycard.")], private="razor")
    assert {e for e, r in res.info["members"].items() if r != "location"} == {"razor"}


def test_discord_whisper_goes_to_dms_only(make_game):
    g = make_game(FakeLLM(_whisper_script(), WHISPER_EXTRACTION))
    setup_demo(g)

    async def go():
        public, private = FakeChannel(), FakeChannel()
        t = CampaignTable(g, public, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.whisper("2", "I palm the keycard.", private)
        assert "not playing anyone" in private.sent[-1]["text"]
        await t.handle("2", "Alice", "!join razor", False, react)
        n_public = len(public.sent)
        await t.whisper("2", "I palm Kaz's spare keycard while he's busy.", private)
        await t.drain()
        assert len(public.sent) == n_public                         # nothing at all reaches the table
        texts = [m["text"] or "" for m in private.sent]
        assert any(x.startswith("```") and "Stealth" in x for x in texts)          # the roll, privately
        story = [m for m in private.sent if m.get("description") and "sleeve" in m["description"]]
        assert story and story[-1]["footer"].startswith("🤫 Whisper ·") and "nobody else knows" in story[-1]["footer"]

        await t.handle("1", "Owner", "!undo", True, react)          # the table's undo won't eat a whisper blind
        assert "private one" in public.sent[-1]["text"]
        await t.whisper("3", "!undo", private)                       # someone else can't take it back
        await t.whisper("2", "!undo", private)
        assert "Undid turn" in private.sent[-1]["text"]
        await t.close()
    asyncio.run(go())


def test_a_whispered_rules_question_stays_out_of_the_story(make_game):
    from roleplay.dm.prompts import ASKDM_SYSTEM, DM_SYSTEM
    assert "!advance <#>" in DM_SYSTEM and "!advance <#>" in ASKDM_SYSTEM      # the GM knows how karma is spent
    extraction = {"summary": "Razor asked how karma works.", "recalled": [], "told": [], "new_entities": [],
                  "facts": [], "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}]}
    llm = FakeLLM([([text("Spend it with `!advance <#>` - a skill costs its new rating x 2.\n<dm>\nooc\n</dm>")],
                    "end_turn")], extraction)
    g = make_game(llm)
    setup_demo(g)
    turn0, clock0 = g.turn_no(), g.clock()

    async def go():
        ch, dm = FakeChannel(), FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("2", "Al", "!join razor", False, react)
        await t.whisper("2", "how does karma spending work?", dm)
        assert dm.sent[-1]["title"] == "Out of character" and "!advance" in dm.sent[-1]["description"]
        assert "<dm>" not in dm.sent[-1]["description"]
        assert g.turn_no() == turn0 and g.clock() == clock0                    # taken back: no turn, no time
        g.ledger.set_stat("razor", "karma", 30)
        await t.whisper("2", "!advance firearms", dm)
        assert dm.sent[-1]["text"].startswith("📈 Razor")                       # spending works from DMs too
        await t.whisper("2", "!karma", dm)
        assert "karma" in dm.sent[-1]["text"]
        await t.close()
    asyncio.run(go())
