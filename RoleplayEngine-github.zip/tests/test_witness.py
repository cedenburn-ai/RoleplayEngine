"""!askdm looks things up (DESIGN.md §8e, 2026-10-26) - in what the asking character witnessed or heard, never the
GM's notebook: notes, pictures, minds, goals, hooks, tensions, doubts, the offscreen world, other players' whispers."""
from roleplay.dm import dmblock, doubts, research, tensions, witness, world
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool

BAR = ("Kaz leans on the counter. **Kaz [kaz]:** \"Five hundred by Friday and I'll tell you who's behind the blue "
       "door on Fifth.\" The jukebox hums.\n<dm>\nfact kaz, razor: Kaz's price for the blue door is five hundred "
       "nuyen by Friday.\n</dm>")
WHISPER = "You slip the tracker into Razor's coat pocket. He never notices."
SECRETS = ("sells information", "sold Razor's name", "soft touch", "informant for Lone Star", "come for Razor",
           "Two versions", "Ghost slipped", "You slip the tracker", "wants: ", "rat him out", "R&D files")


def _extract(user):
    members = ([{"id": "ghost", "role": "actor"}, {"id": "razor", "role": "target"}] if "tracker" in user else
               [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"}])
    return {"summary": "Ghost slipped a tracker into Razor's coat." if "tracker" in user else
            "Kaz named his price for the blue door: five hundred by Friday.", "members": members, "recalled": [],
            "facts": [], "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}}


def _world(make_game):
    """The demo, a public turn at the bar (Razor and Kaz), Ghost's whisper with Razor as its unknowing target, an
    offscreen moment, and one of every GM-only kind."""
    llm = FakeLLM([([text(BAR)], "end_turn"), ([text(WHISPER)], "end_turn")], _extract)
    g = make_game(llm)
    setup_demo(g)
    bar = g.run_turn([("razor", "What's behind the blue door, Kaz?")]).turn_id
    slip = g.run_turn([("ghost", "I slip a tracker into Razor's coat.")], private="ghost").turn_id
    t = g.turn_no()
    away = g.sub.write_offscreen(t, "Kaz sold Razor's name to Lone Star for the rent.", [("kaz", "actor")])
    g.sub.add_belief("kaz", "razor", "Kaz thinks Razor is a soft touch who will pay anything.", t)
    g.sub.clarify("kaz", "Kaz: an informant for Lone Star, scared for his bar.", t)
    tensions.open_tension(g, "Will Lone Star come for Razor?", ["razor"], t)
    doubts.raise_(g, "Two versions of what Kaz owes Razor", ["kaz", "F2"], t)
    aid = world.add_agenda(g, "kaz", "keep the bar open whatever it costs", ["razor"], t, "test")
    world.add_hook(g, "kaz", aid, "Lone Star asks Kaz to rat him out", ["razor"], t)
    return g, llm, bar, slip, away


def _results(llm) -> list[str]:
    """Every tool result the last loop sent back, in order."""
    out = []
    for m in llm.consults[-1]["messages"]:
        if m["role"] == "user" and isinstance(m["content"], list):
            out += [b["content"] for b in m["content"] if b.get("type") == "tool_result"]
    return out


def test_the_scope_is_what_they_were_there_for(make_game):
    g, _, bar, slip, away = _world(make_game)
    razor, ghost, kaz = (witness.Scope(g, x) for x in ("razor", "ghost", "kaz"))
    assert {"T1", "T2", "T3", f"T{bar}"} <= razor.witnessed and f"T{slip}" not in razor.witnessed   # (Ghost's whisper)
    assert f"T{slip}" in ghost.witnessed and "T1" not in ghost.witnessed and slip in ghost.turns
    assert away in kaz.witnessed and away not in razor.witnessed            # an inhabited NPC's own offscreen moment
    assert {"F1", "F2", "F3", "F4"} <= razor.facts                          # the bar fight's canon, and the setup's
    assert {"F3", "F4"} <= ghost.facts and not {"F1", "F2"} & ghost.facts   # (F1, F2 came out of T2 - not there)
    price = g.conn.execute("SELECT id FROM nodes WHERE kind='fact' AND text LIKE 'Kaz''s price%'").fetchone()[0]
    assert price in razor.facts and price not in ghost.facts               # (set down in T4, which Ghost wasn't in)
    assert "joey-two-knives" in razor.known() and "joey-two-knives" not in ghost.known()
    g.sub.write_slice(g.turn_no() + 1, g.current_scene_id(), "Kaz brought up the favor he owes Razor.",
                      [("ghost", "present"), ("kaz", "actor")], ["F2"])
    assert "F2" in witness.Scope(g, "ghost").facts                         # it came up in front of him


def test_a_fight_rounds_facts_reach_only_who_fought_it(make_game):
    """Review (2026-10-26): a fight round writes no slice, so "set down during a turn" read a round's facts as the
    campaign's setup - the GM's and the memory pass's alike - and Sable, across town in no scene, "remembered" them."""
    from roleplay import encounters
    from roleplay.engine.dice import ScriptedDice
    extract = {"summary": "Shots in the bar.", "members": [{"id": "razor", "role": "actor"},
                                                           {"id": "kaz", "role": "target"}],
               "recalled": [], "facts": [{"text": "Kaz keeps a holdout pistol under the bar.", "about": ["kaz"]}],
               "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}}
    llm = FakeLLM([([text("Glass everywhere.\n<dm>\nfact kaz: Kaz took a bullet in the gut and is hiding it.\n</dm>")],
                    "end_turn")], extract)
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    sable = g.create_pc("Sable", "street_samurai", player="sable", description="across town", turn=3)
    setup = g.sub.add_fact("The Lucky Shot never closes, not even for the Ancients.", ["kaz"], 0)   # (before play)
    encounters.start(g, g.turn_no(), [{"name": "bar", "cover": "light"}])
    t = g.run_turn([("razor", "I dive behind the counter.")]).turn_id
    assert not g.sub.exists(f"T{t}")                                     # a round: no slice of its own
    gut, holdout = (g.conn.execute("SELECT id FROM nodes WHERE kind='fact' AND text LIKE ?", (f"%{w}%",)).fetchone()[0]
                    for w in ("bullet", "holdout"))
    razor, away = witness.Scope(g, "razor"), witness.Scope(g, sable)
    assert t in razor.turns and {gut, holdout} <= razor.facts               # he fought it
    assert not away.turns and not {gut, holdout} & away.facts               # she wasn't in it
    assert setup in away.facts and setup in razor.facts                     # (the setup's canon is everyone's)
    assert "Nothing Sable remembers matches" in witness.search(away, {"query": "bullet gut holdout"})


def test_a_fix_written_between_turns_reaches_only_the_moment_it_names(make_game):
    """Review (2026-10-26): the canon's and the aside's fixes land on the last turn's number - so "Razor holds Kaz's
    keycard", from Razor's whisper, reached Ghost, who was at the last public turn, as his own memory."""
    from roleplay.dm import aside, canon
    llm = FakeLLM([([text("You palm the keycard.")], "end_turn"), ([text("Kaz pours.")], "end_turn")], _extract)
    g = make_game(llm)
    setup_demo(g)
    tw = g.run_turn([("razor", "I palm Kaz's maglock keycard.")], private="razor").turn_id
    g.run_turn([("ghost", "I order a drink.")])
    canon._fix(g, canon._last_turn(g), ["fact razor, kaz: Razor holds Kaz's maglock keycard.",
                                        f"fact razor, kaz, T{tw}: Razor lifted the keycard off Kaz's counter."])
    llm.extraction = lambda user: ({"answer": "Fixed.", "direction": "", "is_move": False,
                                    "fixes": ["fact razor, ghost: Razor and Ghost split the courier money evenly."]}
                                   if "SAYS TO YOU" in user else _extract(user))
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, we split the courier money evenly", "razor")
    held, lifted, split = (g.conn.execute("SELECT id FROM nodes WHERE kind='fact' AND text LIKE ?",
                                          (f"%{w}%",)).fetchone()[0] for w in ("holds Kaz", "lifted", "split"))
    assert {held, split} <= dmblock.between_turns(g.conn) and lifted in dmblock.between_turns(g.conn)
    razor, ghost = witness.Scope(g, "razor"), witness.Scope(g, "ghost")
    assert lifted in razor.facts and lifted not in ghost.facts            # the moment it names: Razor's whisper
    assert g.sub.node(lifted)["visibility"] == "private" and f"T{tw}" in {x["other"] for x in g.sub.links_of(lifted)}
    assert held not in ghost.facts and split not in ghost.facts           # set down in front of no one
    assert held not in razor.facts and split not in razor.facts
    found = witness.search(ghost, {"query": "keycard maglock"})
    assert f"[{held}]" not in found and f"[{lifted}]" not in found and "Nothing Ghost remembers matches" in found
    assert f"[{lifted}]" in witness.search(razor, {"query": "keycard"})


def test_askdm_looks_things_up_and_never_reaches_the_gms_notebook(make_game):
    """Every tool, aimed at every GM-only kind, from the PC on the wrong side of each."""
    g, llm, bar, slip, away = _world(make_game)
    llm.consult_script = [
        ([tool("search_memory", query="Lone Star"), tool("search_memory", query="tracker coat"),
          tool("search_memory", query="Lone Star rent Razor", in_narration=True),
          tool("search_memory", query="Secret Kaz", about=["N1"])], "tool_use"),
        ([tool("read_turn", turn_ids=[f"T{slip}", away, f"T{bar}"]), tool("timeline", ids=["Kaz"]),
          tool("search_memory", query="soft touch informant wants hook")], "tool_use"),
        ([text(f"Kaz asked five hundred by Friday (T{bar}).")], "end_turn")]
    answer = g.askdm("razor", "What did Kaz want for the blue door?")
    assert answer == f"Kaz asked five hundred by Friday (T{bar})."
    first = llm.consults[0]
    assert first["tools"] == ["search_memory", "read_turn", "timeline", "doubt"] and first["purpose"] == "askgm"
    assert "They reach only what Razor was there for or heard about" in first["system"]
    assert "WHAT YOUR CHARACTER REMEMBERS" in first["messages"][0]["content"]
    out = _results(llm)
    said = "\n".join(out)
    assert "[F4]" in out[0] and "Lone Star days" in out[0]                 # public canon from a moment he was at
    assert "Nothing Razor remembers matches" in out[1]                     # Ghost's whisper: he was only its target
    assert "Razor knows nobody by N1" in out[3]
    assert f"[T{slip}] isn't a turn Razor was in" in out[4] and f"[{away}] isn't a moment Razor was in" in out[4]
    assert "blue door on Fifth" in out[4] and "Razor [razor] posted: What's behind the blue door, Kaz?" in out[4]
    assert f"[T{bar}]" in out[5] and "[T2]" in out[5] and away not in out[5]
    for secret in SECRETS:                         # not through any tool - nor in the question's own context
        assert secret not in said, secret
        assert secret not in first["messages"][0]["content"], secret


def test_askdm_reads_your_own_whisper_and_nothing_you_werent_at(make_game):
    g, llm, bar, slip, away = _world(make_game)
    llm.consult_script = [
        ([tool("read_turn", turn_ids=[f"T{slip}", "T1"]), tool("timeline", ids=["Joey"]),
          tool("timeline", ids=["Nobody McFake"]), tool("search_memory", query="tracker")], "tool_use"),
        ([text("You slipped it in his coat.")], "end_turn")]
    g.askdm("ghost", "Where did I put the tracker?")
    out = _results(llm)
    assert "(Ghost's whisper - private" in out[0] and WHISPER in out[0]
    assert "[T1] isn't a turn Ghost was in" in out[0]                      # the bar fight was before his time
    assert out[1] == out[2].replace("Nobody McFake", "Joey")               # someone he never met reads as no one
    assert f"[T{slip}]" in out[3] and "Ghost's whisper" in out[3]
    before = g.conn.execute("SELECT touch_count FROM energy WHERE node_id=?", (f"T{slip}",)).fetchone()[0]
    llm.consult_script = [([tool("read_turn", turn_ids=[f"T{slip}"])], "tool_use"), ([text("ok")], "end_turn")]
    g.askdm("ghost", "What exactly did I do?")
    assert g.conn.execute("SELECT touch_count FROM energy WHERE node_id=?", (f"T{slip}",)).fetchone()[0] > before


def test_a_correction_they_hold_counts_though_a_later_one_is_hidden(make_game):
    """Review (2026-10-26): "since corrected" looked only at the end of the chain. F5 -> F6 -> F7, with F7 out of
    Ghost's whisper: Razor holds F5 and its correction F6, but not F7 - and he "remembered" both prices as current."""
    g, llm, bar, slip, away = _world(make_game)
    S = g.sub
    a = S.add_fact("Kaz's price is five hundred.", ["kaz"], 0)
    b = S.add_fact("Kaz's price is a thousand.", ["kaz"], 0, replaces=a, confidence=0.99)
    c = S.add_fact("Kaz's price is two thousand.", ["kaz"], slip, f"T{slip}", replaces=b, confidence=0.99)
    S.set_visibility(c, "private")
    razor, ghost = witness.Scope(g, "razor"), witness.Scope(g, "ghost")
    assert razor.holds(a) and razor.holds(b) and not razor.holds(c) and S.newest(a) == c
    assert (razor.latest(a), razor.latest(b), ghost.latest(a), ghost.latest(b)) == (b, None, c, c)
    lines = {x.split("]")[0] + "]": x for x in witness.search(razor, {"query": "Kaz price"}).splitlines()[1:]}
    assert lines[f"[{a}]"].endswith(f"(since corrected: [{b}] is the current version)")
    assert "since corrected" not in lines[f"[{b}]"] and f"[{c}]" not in "\n".join(lines.values())
    assert f"(since corrected: [{c}] is the current version)" in witness.search(ghost, {"query": "Kaz price"})
    for f in (a, b):                                     # ... and the question's own FACTS YOU LEARNED says so too
        S.link(f, f"T{bar}", "about", 1.0, bar)
    llm.consult_script = [([text("A thousand.")], "end_turn")]
    g.askdm("razor", "What's Kaz's price?")
    asked = llm.consults[-1]["messages"][0]["content"]
    assert f"[{a}] Kaz's price is five hundred.  (since corrected: [{b}])" in asked
    assert f"[{b}] Kaz's price is a thousand.\n" in asked + "\n" and f"[{c}]" not in asked


def test_askdm_sets_down_what_doesnt_add_up(make_game):
    """Review (2026-10-26): !askdm read the bar turn's "Five hundred by Friday" beside a fact of a thousand, told one
    player so in a DM, and kept nothing - the only research loop that saw the record disagree and let it go. Its doubt
    tool puts it on the GM's DOUBTS list, linked only to what the character holds (and the character), and answers
    the same whatever is on file; it reopens nothing, and it isn't cut off by the lookup cap."""
    from roleplay.dm import prompts
    g, llm, bar, slip, away = _world(make_game)
    old = g.conn.execute("SELECT id FROM nodes WHERE kind='fact' AND text LIKE 'Kaz''s price%'").fetchone()[0]
    fid = g.sub.add_fact("Kaz's price for the blue door is a thousand nuyen.", ["kaz", "razor"], bar, f"T{bar}")
    before = {d["id"] for d in doubts.listing(g.conn, g.turn_no())["open"]}
    say = (f"T{bar} has Kaz asking five hundred by Friday; [{fid}] says a thousand.")
    raise_it = tool("doubt", ids=[f"T{bar}", fid, old, "Kaz", f"T{slip}", away, "N1", "X1", "Nobody McFake"], text=say)
    llm.consult_script = [([tool("read_turn", turn_ids=[f"T{bar}"]), tool("search_memory", query="blue door price")],
                           "tool_use"), ([raise_it], "tool_use"),
                          ([text("Two versions: five hundred by Friday at the bar, a thousand in what you learned.")],
                           "end_turn")]
    g.askdm("razor", "What did Kaz want for the blue door?")
    assert "Five hundred by Friday" in _results(llm)[0] and _results(llm)[2] == witness.NOTED
    assert "set it down with the doubt tool" in llm.consults[0]["system"]
    assert "set it down with the doubt tool" in prompts.ASKDM_RESEARCH
    new = [d for d in doubts.listing(g.conn, g.turn_no())["open"] if d["id"] not in before]
    assert len(new) == 1 and new[0]["raised_by"] == "askdm" and new[0]["raised_turn"] == g.turn_no()
    assert new[0]["text"] == f"Razor's memory: {say}" and doubts.NAMED["askdm"] == "a player's !askdm"
    assert [a["id"] for a in new[0]["about"]] == ["razor", f"T{bar}", fid, old, "kaz"]   # (only what Razor holds)
    xid = new[0]["id"]
    for _ in range(2):                                   # again: bumped - then, dismissed, it stays dismissed
        llm.consult_script = [([raise_it], "tool_use"), ([text("Two versions.")], "end_turn")]
        g.askdm("razor", "What did Kaz want for the blue door?")
        assert _results(llm)[0] == witness.NOTED       # (the same words, whatever happened)
        if doubts.get(g, xid)["status"] == "open":
            assert doubts.get(g, xid)["times"] == 2
            doubts.dismiss(g, xid, g.turn_no(), "The thousand was Kaz's opening bid.")
    assert doubts.get(g, xid)["status"] == "dismissed"
    sc = witness.Scope(g, "razor")
    sc.calls = g.settings.models.askdm_research_calls    # (the looking up is done - a doubt still lands)
    outs = [witness.run(sc, "doubt", {"ids": ["kaz"], "text": f"Kaz's price, take {i}: {w}."})
            for i, w in enumerate(("elephants", "submarines", "zeppelins"))]
    assert outs[:2] == [witness.NOTED] * 2 and outs[2].startswith("(a question sets down 2 doubts at most")
    assert witness.run(sc, "doubt", {"ids": ["kaz"], "text": " "}).startswith("Say what doesn't add up")


def test_askdm_lookups_stay_within_their_budget(make_game):
    """askdm_research_steps rounds, askdm_research_calls lookups, then an answer with the tools off."""
    g, llm, *_ = _world(make_game)
    many = [tool("search_memory", query=f"Kaz {i}") for i in range(10)]
    llm.consult_script = [(many, "tool_use")] + [([tool("search_memory", query="Kaz")], "tool_use")] * 3 + [
        ([text("Kaz runs the Lucky Shot.")], "end_turn"), ([tool("search_memory", query="never")], "tool_use")]
    m = g.settings.models
    assert (m.askdm_research_steps, m.askdm_research_calls) == (4, 8)
    assert g.askdm("razor", "Who's Kaz?") == "Kaz runs the Lucky Shot."
    assert len(llm.consults) == m.askdm_research_steps + 1 and len(llm.consult_script) == 1   # (the last never ran)
    assert [c["tool_choice"] for c in llm.consults] == [None] * 4 + [{"type": "none"}]
    out = _results(llm)
    assert len(out) == 13 and all("That's all the looking up" in x for x in out[8:]) and "[T" in out[7]
    assert llm.consults[-1]["messages"][-1]["content"][-1] == {"type": "text", "text": research.LAST_LOOK}


def test_an_empty_answer_with_the_tools_off_is_asked_for_again(make_game):
    """Live check (Haiku, 2026-10-26): told to answer with its tools off, a model that still wanted to look said
    nothing at all. It's told once more."""
    g, llm, *_ = _world(make_game)
    llm.consult_script = [([tool("search_memory", query="Kaz")], "tool_use")] * 4 + [
        ([text("")], "end_turn"), ([text("Kaz runs the Lucky Shot.")], "end_turn")]
    assert g.askdm("razor", "Who's Kaz?") == "Kaz runs the Lucky Shot."
    assert len(llm.consults) == 6 and llm.consults[-1]["tool_choice"] == {"type": "none"}
    assert llm.consults[-1]["messages"][-1] == {"role": "user", "content": research.ANSWER_NOW}
    # (final check, 2026-10-26: the one retry came back empty too about one time in ten, and the player got nothing)
    assert research.ANSWER_TRIES == 2 and "you can't look anything up now" in research.ANSWER_NOW
    llm.consult_script = [([text("")], "end_turn")] * 2 + [([text("Kaz runs the Lucky Shot.")], "end_turn")]
    llm.consults.clear()
    g.settings.models.askdm_research_steps = 0
    assert g.askdm("razor", "Who's Kaz?") == "Kaz runs the Lucky Shot." and len(llm.consults) == 3
    llm.consult_script = [([text("")], "end_turn")] * 4
    llm.consults.clear()
    assert g.askdm("razor", "Who's Kaz?") == "" and len(llm.consults) == 1 + research.ANSWER_TRIES   # (then it stops)


def test_askdm_without_a_character_answers_as_before(make_game):
    class Echo(FakeLLM):
        def text(self, model, system, user, **kw):
            self.asked = user
            return "ok"
    g = make_game(Echo())
    setup_demo(g)
    assert g.askdm("stranger", "how do hits work?") == "ok" and g.llm.consults == []
    assert "No character found for player 'stranger'" in g.llm.asked
