"""The session recap: a pirate-trid 'previously on', where things stand, and NPC dossiers - public record only."""
import asyncio

from PIL import Image

from roleplay import dossier, recap
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel

PACKAGE = {"broadcast": "This is Sally Calloway, Shadow Beat. Razor broke Joey Two-Knives' arm... Stay frosty, "
                        "Seattle.",
           "standing": ["The crew is back at the Lucky Shot, Day 1 22:00.", "Ghost has a hot Renraku chip."],
           "dossiers": [{"id": "kaz", "alias": "", "affiliation": "The Lucky Shot", "status": "CONTACT",
                         "who": "Ork bartender with brass-capped tusks.", "lately": "Banned the Ancients; owes Razor."},
                        {"id": "nobody", "alias": "", "affiliation": "", "status": "", "who": "", "lately": ""}]}


class RecapLLM(FakeLLM):
    def __init__(self):
        super().__init__()
        self.prompts = []

    def structured(self, model, system, user, schema, **kw):
        self.prompts.append((system, user))
        return PACKAGE


def test_the_recap_reads_only_the_public_record(make_game):
    g = make_game()
    setup_demo(g)
    S = g.sub
    S.add_note(["kaz"], "SECRET-NOTE: Kaz is a Lone Star informant.", 3)
    tid = g.ledger.begin_turn(g.current_scene_id(), [])
    sl = S.write_slice(tid, g.current_scene_id(), "Ghost PALMED the chip under the table.", [("ghost", "actor")], [])
    S.set_visibility(sl, "private")
    gathered = recap.gather(g)
    text = recap._user(gathered)
    assert "Joey Two-Knives" in text and "SECRET-NOTE" not in text and "PALMED" not in text
    assert {p["id"] for p in gathered["people"]} == {"kaz", "joey-two-knives"}           # the NPCs they dealt with
    assert "Secret:" not in text                                       # (the demo's GM note on Kaz stays GM-only)


def test_build_renders_a_dossier_per_npc(make_game):
    llm = RecapLLM()
    g = make_game(llm)
    setup_demo(g)
    rec = recap.build(g)
    assert rec["broadcast"].startswith("This is Sally Calloway") and rec["anchor_image"] is None   # (no art provider)
    assert [d["id"] for d in rec["dossiers"]] == ["kaz"]                 # an id it wasn't asked about is dropped
    assert Image.open(rec["dossiers"][0]["image"]).size == (dossier.W, dossier.H)
    assert "Shadow Beat" in llm.prompts[0][0] and "[kaz] Kaz" in llm.prompts[0][1]


def test_recap_command_posts_the_segment_and_the_files(make_game):
    g = make_game(RecapLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!recap", False, react)
        titles = [m["title"] for m in ch.sent]
        assert "📺 Shadow Beat - previously on..." in titles and "📍 Where things stand" in titles
        card = next(m for m in ch.sent if m["title"] == "🗂️ Kaz")
        assert card["image"].endswith("_kaz.png")
        await t.close()
    asyncio.run(go())


def test_stamp_colors():
    assert dossier.stamp_ink("DECEASED") != dossier.stamp_ink("CONTACT") != dossier.stamp_ink("UNKNOWN")
    assert dossier.stamp_ink("AT LARGE") == dossier.RED_INK
