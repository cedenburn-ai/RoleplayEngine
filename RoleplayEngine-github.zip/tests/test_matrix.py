"""The Matrix: one roll per beat, the host answers every action, and it all bleeds into the room."""
import pytest

from roleplay.dm.tools import TurnContext, dispatch, run_tool
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import matrix, sr_lite
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

H2 = [2] * 30          # filler: no hits, no ones (no glitches)


def _host(g, rating=4):
    hid, _ = g.introduce("host", "Renraku Corridor Host", "a zen garden of white gravel; the IC are paper samurai",
                         rating=rating, turn=1)
    return hid


def _n(L, skill, attribute=None):
    """Ghost's dice for a Matrix roll (AR)."""
    return sr_lite.build_pool(L, "ghost", skill, attribute)[0]


def test_jack_in_crack_nodes_and_the_meter(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    with pytest.raises(LedgerError, match="no cyberdeck"):
        matrix.act(L, g.dice, 1, "razor", "jack_in", hid)
    res = matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="ar")
    assert "jacks into Renraku Corridor Host (rating 4) - AR" in res["card"] and "!matrixhelp" in res["card"]
    assert "At Entry (blue, open) · next: Hub A (green, locked)" in res["card"]
    assert [ic["type"] for ic in L.get(hid)["props"]["ic"]] == ["patrol", "track", "killer", "tar baby"]
    n = _n(L, "hacking")                                    # Hub A is green: rating 4 - 2 = 2, so 4 dice resist
    res = matrix.act(L, ScriptedDice([6] * 5 + [2] * (n - 5) + [5, 5, 2, 2]), 1, "ghost", "hack")
    assert "Logic 6 + Hacking 6 + Ghost's Cyberdeck 2 = 14d6" in res["card"] and "SUCCESS: cracks Hub A" in res["card"]
    assert matrix.state(L, "ghost")["node"] == "n2" and matrix.state(L, "ghost")["overwatch"] == 2 and "(+2)" in res["card"]
    m = _n(L, "cybercombat")                                # Hub B is orange: the host's own 4, so 8 dice - loud
    res = matrix.act(L, ScriptedDice([6] * 4 + [2] * (m - 4) + [5, 5, 5] + [2] * 5), 1, "ghost", "brute_force",
                     node="Hub B")
    assert "SUCCESS: cracks Hub B" in res["card"] and "loud" in res["card"]
    assert matrix.state(L, "ghost")["overwatch"] == 2 + 3 + 4
    with pytest.raises(LedgerError, match="already open"):
        matrix.act(L, g.dice, 1, "ghost", "hack", node="Hub A")
    res = matrix.act(L, g.dice, 1, "ghost", "move", node="Entry")       # free through what's open: legal
    assert "Moves Hub B -> Hub A -> Entry" in res["card"] and "(+0)" in res["card"]
    res = matrix.act(L, g.dice, 1, "ghost", "move", node="Core")
    assert "Moves Entry -> Hub A -> Hub B" in res["card"] and "STOPS: Core (red" in res["card"]


def test_the_host_notices_then_alerts(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    st = matrix.state(L, "ghost")
    st["overwatch"] = 11
    matrix._save(L, "ghost", st)
    n = _n(L, "hacking")
    res = matrix.act(L, ScriptedDice([2] * n + [5, 2, 2, 2]), 1, "ghost", "hack")      # fails: +1 +3 = 15, noticed
    assert "HOST NOTICED: launches Patrol IC in Hub A" in res["card"] and "FAILED: Hub A holds" in res["card"]
    assert matrix.state(L, "ghost")["overwatch"] == 15
    res = matrix.act(L, ScriptedDice([2] * n + [5, 2, 2, 2]), 1, "ghost", "hack")      # +4, and Patrol watches: +2
    assert matrix.state(L, "ghost")["overwatch"] == 15 + 4 + 2


def test_ic_bites(make_game):
    """The owner's call (2026-10-27, flags #29/#32 - a player's model): IC damages the deck, soaked by Device Rating +
    Firewall; the deck takes it up to its full monitor and the rest is the decker's Stun."""
    g = make_game(dice=ScriptedDice([6] * 8 + H2[:9]                     # Track: 8 hits vs 0
                                    + [6] * 8 + H2[:9]                   # Tar Baby: 8 vs 0
                                    + [6] * 8 + H2[:9] + H2[:8]))        # Killer: 8 vs 0, the deck soaks 0 of 8
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    ics = {ic["type"]: {**ic, "active": True} for ic in L.get(hid)["props"]["ic"]}
    st = matrix.state(L, "ghost")
    st["marks"] = matrix.TRACE_MARKS                                      # (two failed hacks earlier this dive)
    matrix._save(L, "ghost", st)
    out = {}
    assert "TRACED" in matrix._ic_attack(L, g.dice, 1, "ghost", ics["track"], out)[0] and out["traced"]
    assert matrix.state(L, "ghost")["traced"] == hid and matrix.traced_in(matrix.state(L, "ghost"))
    assert "STUCK" in matrix._ic_attack(L, g.dice, 1, "ghost", ics["tar baby"], out)[0]
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", ics["killer"], out)
    assert ("12 Matrix damage, soaks Device Rating 4 + Firewall 4 = 8d6 -> 0 hits: deck takes 10 -> Deck 10/10"
            in lines[0])                                                  # rating 4 + net 8 = 12; the monitor's 10
    assert "2 past the full deck: Ghost takes 2S" in lines[1] and "  BRICKED: the deck dies" in lines
    st = matrix.state(L, "ghost")
    assert st["deck_damage"] == matrix.deck_monitor(4) and L.stat("ghost", "stun_damage") == 2
    assert not st.get("host") and not st["traced"] and not st["tarred"] and out["out"]     # bricked: out, run over
    assert "DUMPSHOCK" not in "\n".join(lines)                            # (AR: a forced exit doesn't dumpshock)
    hurt = [e["payload"] for e in L.events(1) if e["kind"] == "damage"]
    assert hurt == [{"boxes": 2, "type": "stun", "status": "wounded", "source": "killer", "overflow": "deck"}]


def test_the_deck_soak_counts_the_firewall(make_game):
    """Flag #29 (a player, T110): the deck resists with its device rating plus Firewall - without it the decker kept
    getting one-shot - and the deck soaked with its rating alone. Infusion of Firewall's firewall_bonus is
    the Firewall's too; overflow and a VR dumpshock both land when a hit bricks a hot-sim deck."""
    g = make_game(dice=ScriptedDice([6] * 8 + H2[:11] + [5] * 3 + H2[:7]  # Killer 8 vs 0; soak 10 dice, 3 hits
                                    + [2] * 10))                         # the dumpshock's soak: none
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    L.set_stat("ghost", "firewall_bonus", 2)
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "deck_damage": 6})
    out = {}
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", {"type": "killer", "rating": 4, "damage": 0, "active": True}, out)
    card = "\n".join(lines)
    assert "Intuition + Firewall 11d6" in lines[0]                        # Intuition 5 + deck 4 + 2
    assert "12 Matrix damage, soaks Device Rating 4 + Firewall 6 = 10d6 -> 3 hits: deck takes 4 -> Deck 10/10" in card
    assert "5 past the full deck: Ghost takes 5S" in card and card.index("past the full deck") < card.index("DUMPSHOCK")
    assert L.stat("ghost", "stun_damage") == 10 and matrix.state(L, "ghost")["deck_damage"] == 10   # 5 + 6: full


def test_the_tar_baby_holds(make_game):
    g = make_game(dice=ScriptedDice([2] * 16 + [5] * 12                  # VR: 16 dice to cut free vs 12 - fails
                                    + [2] * 12 + [2] * 9))               # the Tar Baby's own attack misses
    setup_demo(g)
    L = g.ledger
    hid = _host(g, rating=6)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    hp = L.get(hid)["props"]
    for ic in hp["ic"]:
        ic["active"] = ic["type"] == "tar baby"
    L.update_entity(hid, props=hp)
    st = matrix.state(L, "ghost")
    st["tarred"] = True
    matrix._save(L, "ghost", st)
    res = matrix.act(L, g.dice, 1, "ghost", "jack_out")
    assert "Hot-sim VR 2 = 16d6" in res["card"] and "STUCK: the Tar Baby holds" in res["card"]
    assert matrix.state(L, "ghost")["host"] == hid


def test_black_ic_gets_one_emergency_jack_out(make_game):
    g = make_game(dice=ScriptedDice([6] * 12 + [2] * 9 + [2] * 8          # 12 hits vs 0, soak 0: 18P - lethal
                                    + [6] * 10                           # Willpower + Logic: made it out
                                    + [2] * 10))                         # dumpshock 6S, no soak hits
    setup_demo(g)
    L = g.ledger
    hid = _host(g, rating=6)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    out = {}
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", {"type": "black ic", "rating": 6, "damage": 0, "active": True}, out)
    assert ("BIOFEEDBACK 18P (the deck's untouched), soaks Willpower 4 + Firewall 4 = 8d6 -> 0 hits: 18 would drop "
            "Ghost - emergency jack-out 10d6 -> 10 hits, made it") in lines[0] and out["out"]
    assert "DUMPSHOCK" in "\n".join(lines) and not matrix.state(L, "ghost").get("host")
    assert L.stat("ghost", "physical_damage") == 0 and L.stat("ghost", "stun_damage") == 6
    assert matrix.state(L, "ghost")["deck_damage"] == 0


def test_black_ic_hits_the_decker_never_the_deck(make_game):
    """Flags #30/#32 (a player): Black IC is resisted with Willpower + Firewall and doesn't harm the deck - in AR
    too, where it used to fry the deck like a Killer. In AR its biofeedback is Stun."""
    g = make_game(dice=ScriptedDice([6] * 10 + H2[:11] + [5] * 6 + H2[:4]))   # 10 vs 0: 15S; soak 10 dice, 6 hits
    setup_demo(g)
    L = g.ledger
    hid = _host(g, rating=5)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="ar")
    L.set_stat("ghost", "firewall_bonus", 2)
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", {"type": "black ic", "rating": 5, "damage": 0, "active": True}, {})
    assert "BIOFEEDBACK 15S (the deck's untouched), soaks Willpower 4 + Firewall 6 = 10d6 -> 6 hits" in lines[0]
    assert "Ghost takes 9 -> Physical 0/10, Stun 9/10" in lines[0]
    assert matrix.state(L, "ghost")["deck_damage"] == 0 and matrix.state(L, "ghost")["host"] == hid


def test_reaching_into_the_room(make_game):
    g = make_game(dice=ScriptedDice([2] * 60))
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    g.ledger.update_entity(hid, props={**L.get(hid)["props"]})
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", present=True, turn=1)
    payroll, _ = g.introduce("item", "Renraku payroll", "salary data for the arcology's guards", owner_id=hid, turn=1)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    with pytest.raises(LedgerError, match="crack it first"):                 # behind Hub A, still locked to Ghost
        matrix.act(L, g.dice, 1, "ghost", "control", target=dog)
    st = matrix.state(L, "ghost")
    st.setdefault("creds", {})[hid] = "admin"                               # a stolen admin login
    matrix._save(L, "ghost", st)
    res = matrix.act(L, g.dice, 1, "ghost", "control", target=dog)
    assert "a real login - it just opens, no roll" in res["card"] and "(+0)" in res["card"]
    assert "Doberman answers to Ghost now" in res["card"] and L.get(dog)["props"]["controller"] == "ghost"
    res = matrix.act(L, g.dice, 1, "ghost", "data", target=payroll, effect="copy")
    assert "Records" in res["card"] and any(i["name"] == "Copy of Renraku payroll" for i in L.holdings("ghost"))
    res = matrix.act(L, g.dice, 1, "ghost", "control", node="Cameras", effect="looped")
    assert "SUCCESS: Cameras - looped" in res["card"]
    L.update_entity(hid, props={**L.get(hid)["props"], "site": g.ledger.current_scene()["location_id"]})
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], 9)
    assert "THIS BUILDING'S SYSTEMS" in packet and "Cameras: looped (by Ghost in the Matrix" in packet
    shot = sr_lite.attack(L, g.dice, 1, "kaz", "ghost", next(i["id"] for i in L.holdings("kaz") if "dv" in i["props"]))
    assert "In hot-sim VR, body limp 0" in shot["card"]                   # the body can't dodge
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], 9)
    assert "=== THE MATRIX" in packet and "hot-sim VR: their body is LIMP" in packet and "zen garden" in packet


def test_a_trace_becomes_a_hook(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    ctx = TurnContext(g, 9, g.current_scene_id())
    dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "jack_in", "host_id": hid})
    st = matrix.state(L, "ghost")
    st["overwatch"] = 20
    matrix._save(L, "ghost", st)
    hp = L.get(hid)["props"]
    hp["ic"] = [ic for ic in hp["ic"] if ic["type"] in ("patrol", "track")]
    L.update_entity(hid, props=hp)
    n = _n(L, "hacking")
    g.dice = ScriptedDice([2] * n + [5] * 4)                                # a failed crack: the host alerts, marks Ghost
    card = dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "hack", "reason": "push deeper"})
    assert "HOST ALERT: launches Patrol IC in Hub A (1 more IC still dormant)" in card and "TRACED" not in card
    assert "marks Ghost (2/2)" not in card and "marks Ghost (1/2)" in card    # (one IC a beat: Patrol first)
    ctx.turn_id = 10
    g.dice = ScriptedDice([2] * n + [2] * 4)                                # another: a second mark; Track launches
    card = dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "hack", "reason": "again"})
    assert "marks Ghost (2/2)" in card and "HOST ALERT: launches Track IC in Comms" in card and "moves" not in card
    ctx.turn_id = 11
    s = _n(L, "electronics", "intuition")
    g.dice = ScriptedDice([2] * s)                                          # Track comes for Ghost...
    card = dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "search"})
    assert "Track IC moves to Hub A - 1 node from Ghost" in card
    g.dice = ScriptedDice([2] * s)                                          # (the same turn's next beat: it hunts on)
    card = dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "search"})
    assert "Track IC moves to Entry - it's on Ghost now" in card
    ctx.turn_id = 12
    g.dice = ScriptedDice([2] * s + [6] * 8 + H2[:9])                       # ...and follows the signal home
    card = dispatch(ctx, "matrix", {"decker_id": "ghost", "action": "search"})
    assert "TRACED" in card
    hook = g.conn.execute("SELECT n.text FROM hooks h JOIN nodes n ON n.id=h.id WHERE h.npc_id=?", (hid,)).fetchone()
    assert hook and "traced Ghost's physical location" in hook["text"]


def test_the_overwatch_score_belongs_to_one_run(make_game):
    """Live: a KD-4 dive the table retconned in the story left Overwatch at 33/40, and the next dive, forty turns
    later, walked in one step from convergence. The score dies with the session; a stale jack-in starts clean."""
    g = make_game(dice=ScriptedDice([6] * 5 + [2] * 9 + [5, 5] + [2] * 6))     # a hack: the host sees 2
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="ar")
    matrix.act(L, g.dice, 1, "ghost", "hack")
    assert matrix.state(L, "ghost")["overwatch"] > 0
    matrix.act(L, g.dice, 2, "ghost", "jack_in", hid, mode="ar")              # (the same run, picked up again)
    assert matrix.state(L, "ghost")["overwatch"] > 0
    st = matrix.state(L, "ghost")
    L.update_entity("ghost", props={**L.get("ghost")["props"], "matrix": {**st, "overwatch": 33}})
    matrix.act(L, g.dice, 45, "ghost", "jack_in", hid, mode="ar")             # never jacked out - turns ago
    assert matrix.state(L, "ghost")["overwatch"] == 0
    matrix.act(L, g.dice, 45, "ghost", "hack")
    matrix.act(L, g.dice, 46, "ghost", "jack_out")
    assert matrix.state(L, "ghost")["overwatch"] == 0 and matrix.state(L, "ghost")["host"] is None


def _hot_dive(g, rating=6):
    """Ghost deep in a hot-sim dive, the way the T45/46 KD-4 run left Filament: Overwatch 33, traced, stuck, the host
    on alert with every IC awake."""
    L = g.ledger
    hid = _host(g, rating=rating)
    t = g.turn_no()
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid, mode="vr")
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "overwatch": 33, "traced": hid, "tarred": True})
    hp = L.get(hid)["props"]
    L.update_entity(hid, props={**hp, "alert": 2, "ic": [{**ic, "active": True} for ic in hp["ic"]]})
    return hid, t


def _turns_go_by(g, n: int) -> int:
    """n committed turns in the current scene with no Matrix move in them; returns the last one's id."""
    sid, t = g.current_scene_id(), g.turn_no()
    for i in range(1, n + 1):
        g.conn.execute("INSERT INTO turns(id, scene_id, status) VALUES(?,?,'committed')", (t + i, sid))
    return t + n


def test_a_run_the_story_left_is_over_everywhere(make_game):
    """Flag #11 (live T46-T88): Filament never jacked out of the KD-4 dive, and for forty turns the packet had him in
    it - LIMP in hot-sim VR, Overwatch 33/40, TRACED, the host ON ALERT - while every beat but a jack-in played from
    there. A run is over once the story leaves it behind - IDLE turns with no Matrix move and nothing of it in the
    story: every reader says so, and the engine closes it quietly."""
    from roleplay import charsheet, netmap
    g = make_game(dice=ScriptedDice([2] * 60))
    setup_demo(g)
    L = g.ledger
    hid, t = _hot_dive(g)
    assert matrix.live(L, "ghost") == hid and sr_lite.limp(L, L.get("ghost")) == "In hot-sim VR"
    now = _turns_go_by(g, matrix.IDLE + 1)                                # the story moves on; nobody jacked out
    why = f"no Matrix move since T{t}"
    assert matrix.over(L, "ghost") == why and matrix.live(L, "ghost") is None
    assert matrix.summary_lines(L, "ghost") == [] and not matrix.in_vr(L, "ghost")
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], now)
    assert "=== THE MATRIX" not in packet and "LIMP" not in packet
    assert sr_lite.limp(L, L.get("ghost")) is None and not sr_lite.helpless(L, "ghost")
    assert "hot-sim VR" not in sr_lite.initiative_text(L, "ghost")
    card = charsheet.matrix_card(g, "ghost", 0)["description"]
    assert "Jacked in" not in card and "33/40" not in card
    assert netmap.personas_in(g, hid) == [] and not matrix.edge_rides(L, "ghost", "search")
    with pytest.raises(LedgerError, match=f"{why} - so the engine closed it quietly"):
        matrix.act(L, g.dice, now, "ghost", "search")
    st, hp = matrix.state(L, "ghost"), L.get(hid)["props"]
    assert (st["host"], st["overwatch"], st["traced"], st["tarred"], st["last_host"]) == (None, 0, False, False, hid)
    assert hp["alert"] == 1 and [ic["type"] for ic in hp["ic"] if ic["active"]] == ["patrol"]   # stood down
    assert L.stat("ghost", "stun_damage") == 0                            # quietly: no dumpshock
    assert any(e["payload"] == {"action": "jack_out", "host": hid, "stale": why}
               for e in L.events(now) if e["kind"] == "matrix")
    card = matrix.act(L, g.dice, now, "ghost", "jack_in", hid)["card"]    # a new run, from nothing
    assert "0/40 (quiet)" in card and "TRACED" not in "\n".join(matrix.summary_lines(L, "ghost"))
    assert "ended" not in matrix.state(L, "ghost")


def test_a_run_from_before_the_story_moved_on_from_is_over(make_game):
    """A run kept before 2026-10-27 has no st.scene: its scene is its last move's turn's, and a decker in another scene
    now (the T45 dive was S5, the T88 jack-in S6) is out of it - the record the live world carried."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    t = _turns_go_by(g, 1)
    sid = g.current_scene_id()
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid)
    matrix._save(L, "ghost", {k: v for k, v in matrix.state(L, "ghost").items() if k != "scene"})
    other = L.create_scene("Elsewhere", None, t)                         # (moved the old build's way: no carry)
    L.leave(sid, ["ghost"])
    L.enter(other, ["ghost"], t)
    assert matrix.over(L, "ghost") == f"the story left S{sid} behind" and matrix.live(L, "ghost") is None


def test_jacking_out_of_a_run_thats_over_is_quiet(make_game):
    """The T88 replay: `jack_out forced=true` - the cleanup the prompt asks for - dumpshocked Filament out of a dive
    the story had left forty turns before. It's out already; the card says so, and nobody takes a dumpshock."""
    g = make_game(dice=ScriptedDice([2] * 60))
    setup_demo(g)
    L = g.ledger
    hid, t = _hot_dive(g)
    now = _turns_go_by(g, matrix.IDLE + 1)
    res = matrix.act(L, g.dice, now, "ghost", "jack_out", forced=True)
    assert res["out"] and res["card"] == (f"[MATRIX] Ghost is out of the Matrix - the run on Renraku Corridor Host was "
                                          f"already over (no Matrix move since T{t}), so it closed quietly: no "
                                          "dumpshock")
    assert L.stat("ghost", "stun_damage") == 0 and matrix.state(L, "ghost")["host"] is None
    with pytest.raises(LedgerError, match="isn't jacked in - start with action 'jack_in' and a host.$"):
        matrix.act(L, g.dice, now, "ghost", "jack_out")


T47 = ("**GM (out of character):** Rewound - run it as if Ghost never jacked in. Nothing on the Renraku host, no "
       "alarm, no trace, no headache. Ghost is fine.\n\nThe safehouse kitchen, a minute earlier. Ghost has the deck "
       "on the table beside a cold soykaf, its cable looped around two fingers. He doesn't plug it in.")


def test_a_dive_the_story_took_back_is_closed_by_the_story(make_game):
    """Review of flag #11 (live T47): the table took the T45 dive back in the story - the GM, out of character, played
    it as if Filament had never jacked in - with no jack_out or correct. The memory pass had Filament an actor and the
    host mentioned, so keep() held the run live ten more turns: the packet had him LIMP in VR, Overwatch 33, TRACED,
    while the story had him in the nap room. The narration's word closes it now - quietly, no dumpshock - and the host the
    dive never happened to goes quiet. A might-be ("could pull the plug if...") closes nothing."""
    from .conftest import FakeLLM, text
    g = make_game(FakeLLM([([text(T47)], "end_turn")],
                          _extraction("The dive is taken back.", ("ghost", "actor"), ("renraku-corridor-host", "mentioned"))),
                  dice=ScriptedDice([2] * 200))
    setup_demo(g)
    L = g.ledger
    hid, t = _hot_dive(g)
    assert hid == "renraku-corridor-host"
    res = g.run_turn([("razor", "Can we say Ghost never tried that one?")])
    assert matrix.live(L, "ghost") is None and not sr_lite.helpless(L, "ghost") and L.stat("ghost", "stun_damage") == 0
    hp = L.get(hid)["props"]
    assert hp["alert"] == 0 and not [ic for ic in hp["ic"] if ic["active"]]
    assert any(e["payload"].get("stale", "").startswith(f"the story logged them off at T{res.turn_id}")
               for e in L.events(res.turn_id) if e["kind"] == "matrix")
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], res.turn_id + 1)
    assert "LIMP" not in packet and "33/40" not in packet
    assert "closed it quietly at the end of" in matrix.act(L, g.dice, res.turn_id + 1, "ghost", "jack_out")["card"]
    g2 = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g2)
    hid, t = _hot_dive(g2)
    _turns_go_by(g2, 1)
    assert matrix.story_out(g2.ledger, t + 1, "Ghost could pull the plug if it goes wrong. He doesn't.") == []
    assert matrix.story_out(g2.ledger, t + 1, "Razor jacks out of the conversation.") == []    # (not the decker)
    assert matrix.live(g2.ledger, "ghost") == hid


def test_the_gms_tidy_up_after_the_story_is_quiet(make_game):
    """Review of flag #11, path 1: a cut carried the taken-back dive into the next scene, and its note said "If the
    story logged them off, call matrix jack_out" - which played the stale run: the Tar Baby contest on Overwatch 33,
    convergence, 6 Stun of dumpshock, TRACED and a ready hook, forced or not. With no sign of the run for STALE turns,
    the GM's jack_out closes it the way the engine would: no contest, no host answer, no dumpshock."""
    from .conftest import tool as tool_
    for forced in (False, True):
        g = make_game(dice=ScriptedDice([6] * 400))                      # (dice the Tar Baby would win with)
        setup_demo(g)
        L = g.ledger
        hid, t = _hot_dive(g)
        now = _turns_go_by(g, matrix.STALE)
        ctx = TurnContext(g, now, g.current_scene_id())
        out = run_tool(ctx, tool_("cut_scene", title="Outside the corridor", bring_ids=["ghost", "razor"]))
        assert "it closes quietly, no dumpshock" in out["content"]
        out = run_tool(ctx, tool_("matrix", decker_id="ghost", action="jack_out", forced=forced, reason="tidy"))
        assert "closed quietly: no dumpshock" in out["content"] and "Tar Baby" not in out["content"], forced
        assert L.stat("ghost", "stun_damage") == 0 and L.stat("ghost", "physical_damage") == 0
        assert matrix.state(L, "ghost")["host"] is None and not g.conn.execute("SELECT 1 FROM hooks").fetchone()
    g = make_game(dice=ScriptedDice([2] * 400))                          # (two turns on: it still plays the contest)
    setup_demo(g)
    hid, t = _hot_dive(g)
    now = _turns_go_by(g, matrix.STALE - 1)
    assert "Tar Baby" in matrix.act(g.ledger, g.dice, now, "ghost", "jack_out")["card"]


def test_a_redive_after_a_story_turn_is_a_new_run(make_game):
    """Review of flag #11, path 2: a re-dive into the same host three turns after a dive the table took back (and the
    turn that took it back "kept", the host named in it) picked the run up - Overwatch 33, TRACED, the alert with all
    five IC awake. A jack-in picks a run up only from a Matrix move this turn or the last; later it's a new run."""
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    L = g.ledger
    hid, t = _hot_dive(g)
    _turns_go_by(g, 2)
    matrix.keep(L, t + 1, {"ghost": "actor", hid: "mentioned"})          # (the retcon turn, as the memory pass had it)
    card = matrix.act(L, g.dice, t + 2, "ghost", "jack_in", hid, mode="ar")["card"]
    st, hp = matrix.state(L, "ghost"), L.get(hid)["props"]
    assert (st["overwatch"], st["traced"], st["tarred"], st["marks"]) == (0, False, False, 0) and "0/40" in card
    assert hp["alert"] <= 1 and [ic["type"] for ic in hp["ic"] if ic["active"]] in ([], ["patrol"])


def test_a_dive_can_sit_idle_a_while(make_game):
    """Live T101-T105: four turns of talk inside a KD-4 dive that was still going - a run in its own scene stays live
    until IDLE turns go by without a Matrix move. A split party's decker, left behind in the van, stays in."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    t = g.turn_no()
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid)
    assert matrix.live(L, "ghost", t + 4) == hid and matrix.over(L, "ghost", t + matrix.IDLE) is None
    assert matrix.over(L, "ghost", t + matrix.IDLE + 1) == f"no Matrix move since T{t}"
    g.new_scene("Razor goes in alone", None, ["razor"], t + 1)            # Ghost stays in the van, jacked in
    assert matrix.live(L, "ghost", t + 2) == hid
    assert matrix.end_stale_runs(L, t + 2) == []
    assert matrix.end_stale_runs(L, t + matrix.IDLE + 1) == [
        f"Ghost's Matrix run on Renraku Corridor Host is over (no Matrix move since T{t}) - closed quietly, no dumpshock"]
    assert matrix.state(L, "ghost")["host"] is None and matrix.end_stale_runs(L, t + 30) == []


def _extraction(summary: str, *members) -> dict:
    return {"summary": summary, "recalled": [], "facts": [], "told": [], "new_entities": [],
            "moved_to": {"location": "", "description": "", "who": []},
            "members": [{"id": i, "role": r} for i, r in members]}


def test_the_turn_end_closes_a_run_the_story_left(make_game):
    """The engine closes a run that's over at the turn's end too, so the record says what the story did."""
    from .conftest import FakeLLM
    llm = FakeLLM([], _extraction("Razor makes tea.", ("razor", "actor")))
    g = make_game(llm, dice=ScriptedDice([2] * 200))
    setup_demo(g)
    L = g.ledger
    hid, t = _hot_dive(g)
    _turns_go_by(g, matrix.IDLE)                                          # the next turn is IDLE + 1 on
    g.run_turn([("razor", "I put the kettle on.")])
    assert "=== THE MATRIX" not in llm.dm_requests[0] and "LIMP" not in llm.dm_requests[0]
    assert matrix.state(L, "ghost")["host"] is None and L.stat("ghost", "stun_damage") == 0
    assert any(e["kind"] == "matrix" and e["payload"].get("stale") for e in L.events(g.turn_no()))


def test_a_cut_that_takes_the_decker_along_takes_the_run(make_game):
    """Review 2026-10-27, live T126: Filament jacked into the Bellevue Arcade host and looped its cameras, then the same
    turn cut to S12 with him along - T127-T130 narrate the loop holding. Reading the scene change as the end closed that
    run at T126's end: no MATRIX in the next packet, every beat refused. A cut that brings the decker brings the run,
    whichever order the turn's calls came in; only a decker the story leaves behind somewhere goes stale."""
    from .conftest import FakeLLM, text, tool
    g0 = make_game()
    setup_demo(g0)
    hid = _host(g0)
    script = [([tool("matrix", decker_id="ghost", action="jack_in", host_id=hid, reason="in"),
                tool("matrix", decker_id="ghost", action="search", reason="look"),
                tool("cut_scene", title="The P2-P3 curve", bring_ids=["ghost", "razor"])], "tool_use"),
              ([text("The van pulls out; Ghost's loop holds.")], "end_turn"),
              ([tool("matrix", decker_id="ghost", action="search", reason="still in")], "tool_use"),
              ([text("Ghost watches the feed.")], "end_turn")]
    llm = FakeLLM(script, _extraction("Ghost works the host as the van rolls.", ("ghost", "actor"), ("razor", "actor")))
    g = make_game(llm, dice=ScriptedDice([2] * 300))
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    g.run_turn([("ghost", "I jack in and look around, then we drive.")])
    st = matrix.state(L, "ghost")
    assert st["host"] == hid and st["scene"] == g.current_scene_id() == L.scene_of("ghost")
    assert not any(e["kind"] == "matrix" and e["payload"].get("stale") for e in L.events(g.turn_no()))
    g.run_turn([("ghost", "I keep watching.")])
    assert "=== THE MATRIX" in llm.dm_requests[-1] and "Ghost is in Renraku Corridor Host" in llm.dm_requests[-1]
    assert [e["payload"]["action"] for e in L.events(g.turn_no()) if e["kind"] == "matrix"] == ["search"]

    ctx = TurnContext(g0, g0.turn_no(), g0.current_scene_id())             # (the other order, and what the GM's told)
    run_tool(ctx, tool("cut_scene", title="The van", bring_ids=["ghost"]))
    van = ctx.scene_id
    run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_in", host_id=hid, reason="in"))
    out = run_tool(ctx, tool("cut_scene", title="The garage", bring_ids=["ghost", "razor"]))
    assert (f"(still jacked in - the run goes with them: Ghost in Renraku Corridor Host (AR, last Matrix move "
            f"T{g0.turn_no()}). If the story logged them off, call matrix jack_out - 3 turns on from the run's last "
            "sign of life it closes quietly, no dumpshock; if the table took the dive back, call correct "
            "what=jack_out instead - no roll)") in out["content"]           # (review 2026-10-28 of flag #11)
    assert matrix.live(g0.ledger, "ghost") == hid and matrix.end_stale_runs(g0.ledger, g0.turn_no()) == []
    out = run_tool(ctx, tool("cut_scene", title="The van", resume_scene_id=van, bring_ids=["ghost"]))
    assert "still jacked in" in out["content"] and matrix.state(g0.ledger, "ghost")["scene"] == van
    assert "still jacked in" not in run_tool(ctx, tool("cut_scene", title="Out", bring_ids=["razor"]))["content"]
    assert matrix.live(g0.ledger, "ghost") == hid                         # (left in the van, still in)


def test_the_story_keeps_a_watch_going(make_game):
    """Review 2026-10-27, live T180-T188: Filament sat in Lim's garage host on the gate camera, narrated every turn
    (a line back in the host, its camera still on the gate) with no Matrix move since T180 - IDLE
    alone would have closed it at T191, mid-stakeout, unannounced. A turn whose memory pass has the decker and the host
    keeps the run going; the packet counts the quiet turns down where the GM can see them."""
    from .conftest import FakeLLM
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    t = _turns_go_by(g, 1)
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid)
    assert matrix.idle_line(L, "ghost", t + matrix.STALE - 1) is None
    line = matrix.idle_line(L, "ghost", t + matrix.STALE)
    assert line == (f"  No Matrix move since T{t} - the run ends quietly after T{t + matrix.IDLE} unless a matrix beat "
                    "keeps it going, or the narration keeps Ghost in the host (name it). If the story logged them off, "
                    "call matrix jack_out - it closes quietly now, no dumpshock")
    assert matrix.summary_lines(L, "ghost", t + matrix.STALE)[1] == line   # (right under where they are)
    assert matrix.keep(L, t + 8, {"ghost": "mentioned", hid: "mentioned"}) == []     # only talked about: no
    assert matrix.keep(L, t + 8, {"ghost": "actor"}) == []                            # the host not in it: no
    assert matrix.keep(L, t + 8, {"ghost": "actor", hid: "mentioned"}) == ["ghost"]
    assert matrix.live(L, "ghost", t + 8 + matrix.IDLE) == hid
    assert matrix.over(L, "ghost", t + 9 + matrix.IDLE) == (f"no Matrix move since T{t}, and nothing of it in the story "
                                                             f"since T{t + 8}")
    assert f"(the story last had Ghost in the host at T{t + 8}) - the run ends quietly after T{t + 8 + matrix.IDLE}" in (
        matrix.idle_line(L, "ghost", t + 11))
    assert matrix.keep(L, t + 9 + matrix.IDLE, {"ghost": "actor", hid: "mentioned"}) == []   # (over: not reopened)

    llm = FakeLLM([], _extraction("Ghost watches the gate camera.", ("ghost", "actor"), (hid, "mentioned")))
    g = make_game(llm)                                                    # (through a turn: commit keeps it first)
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    t = _turns_go_by(g, 1)
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid)
    _turns_go_by(g, matrix.IDLE - 1)
    g.run_turn([("ghost", "I keep my eyes on the gate feed.")])
    assert g.turn_no() == t + matrix.IDLE and f"the run ends quietly after T{t + matrix.IDLE}" in llm.dm_requests[0]
    assert matrix.state(L, "ghost")["kept"] == t + matrix.IDLE and matrix.live(L, "ghost", t + 2 * matrix.IDLE) == hid


def test_the_gm_jacks_out_of_a_run_the_engine_closed(make_game, tmp_path):
    """Review 2026-10-27: the engine closed a run at one turn's end, the next turn's story logged the decker off, and
    the GM's jack_out got "isn't jacked in - start with action 'jack_in'" - and an engine tool-error flag. It gets the
    quiet card once; any other beat hears why; none of it lands on the flag log."""
    from roleplay import flags

    from .conftest import tool
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    t = _turns_go_by(g, 1)
    matrix.act(L, g.dice, t, "ghost", "jack_in", hid)
    end = _turns_go_by(g, matrix.IDLE + 1)
    assert matrix.end_stale_runs(L, end)                                  # (a turn's end: closed quietly)
    now = _turns_go_by(g, 1)
    ctx = TurnContext(g, now, g.current_scene_id())
    why = f"no Matrix move since T{t}"
    out = run_tool(ctx, tool("matrix", decker_id="ghost", action="search", reason="look"))
    assert out["is_error"] and out["content"] == (
        f"Refused: Ghost isn't jacked in - start with action 'jack_in' and a host. (Their last run was over - {why} - so "
        f"the engine closed it quietly at the end of T{end}, no dumpshock; a new jack-in starts clean.)")
    out = run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_out", reason="he logs off"))
    assert not out.get("is_error") and (
        f"[MATRIX] Ghost is out of the Matrix - the run on Renraku Corridor Host was already over ({why}), so the engine "
        f"closed it quietly at the end of T{end}: no dumpshock") in out["content"]
    out = run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_out", reason="again"))
    assert out["content"] == "Refused: Ghost isn't jacked in - start with action 'jack_in' and a host."
    assert flags.listing(tmp_path) == [] and ctx.tool_errors == 0 and L.stat("ghost", "stun_damage") == 0


def test_a_trace_is_the_runs(make_game):
    """Flags #17/#26: Filament's T105 KD-4 trace showed as TRACED on every host he went into after - Mothlight at
    T117, Bellevue Arcade, Lim's at T188 - and survived a fresh jack-in. A trace is the run's (the READY hook carries
    it into the world): not on the next run, on the same host or another."""
    g = make_game(dice=ScriptedDice([6] * 8 + H2[:9] + [6] * 8 + H2[:9]))   # two Track hits, 8 vs 0
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    other, _ = g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=3, turn=1)
    t = g.turn_no()
    track = {"type": "track", "rating": 4, "damage": 0, "active": True}

    def traced_by_track(turn, host):
        matrix.act(L, g.dice, turn, "ghost", "jack_in", host)
        matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "marks": matrix.TRACE_MARKS})
        matrix._ic_attack(L, g.dice, turn, "ghost", track, {})
        assert " · TRACED" in "\n".join(matrix.summary_lines(L, "ghost"))
    traced_by_track(t, hid)
    matrix.act(L, g.dice, t, "ghost", "jack_out")
    assert not matrix.state(L, "ghost")["traced"]
    matrix.act(L, g.dice, t + 1, "ghost", "jack_in", other)               # the next run, another host: clean
    assert "TRACED" not in "\n".join(matrix.summary_lines(L, "ghost"))
    traced_by_track(t + 2, hid)                                           # never jacked out of, then a stale
    matrix.act(L, g.dice, t + 2 + matrix.STALE + 1, "ghost", "jack_in", hid)   # jack-in on the same host: clean
    assert "TRACED" not in "\n".join(matrix.summary_lines(L, "ghost"))
    for h in (hid, other):                                                # an older record's plain True never shows
        matrix.act(L, g.dice, t + 9, "ghost", "jack_in", h)
        matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "traced": True})
        assert "TRACED" not in "\n".join(matrix.summary_lines(L, "ghost"))


def test_jacking_into_another_host_leaves_the_first(make_game):
    """Live: Filament went from the Horizon host (T18, on alert) into KD-4 (T45) without a jack-out, and at T188
    Horizon still sat at alert 2 with all four IC awake."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    other, _ = g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=3, turn=1)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    hp = L.get(hid)["props"]
    L.update_entity(hid, props={**hp, "alert": 2, "ic": [{**ic, "active": True} for ic in hp["ic"]]})
    matrix.act(L, g.dice, 2, "ghost", "jack_in", other)
    hp = L.get(hid)["props"]
    assert hp["alert"] == 1 and [ic["type"] for ic in hp["ic"] if ic["active"]] == ["patrol"]
    assert matrix.state(L, "ghost")["host"] == other and matrix.state(L, "ghost")["last_host"] == hid


def test_a_dump_isnt_written_over(make_game):
    """Live: KD-4 sat at alert 2 with every IC awake long after Filament was out. The IC that bricked his deck threw
    him out - and the jack-out stood the IC down - then the host's answer saved its own copy of the beat over it."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    at = matrix.state(L, "ghost")["node"]
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "deck_damage": 9})
    hp = L.get(hid)["props"]
    ics = [{**ic, "active": True} | ({"node": at} if ic["type"] == "killer" else {}) for ic in hp["ic"]]
    L.update_entity(hid, props={**hp, "alert": 2, "ic": ics})                # (the Killer on Ghost, the rest hunting)
    s = _n(L, "electronics", "intuition")
    card = matrix.act(L, ScriptedDice([2] * s + [6] * 8 + H2[:9] + H2[:8]), 2, "ghost", "search")["card"]
    assert "Track IC moves to" in card and "BRICKED: the deck dies" in card and "Tar Baby IC (4) attacks" not in card
    hp = L.get(hid)["props"]
    assert hp["alert"] == 1 and [ic["type"] for ic in hp["ic"] if ic["active"]] == ["patrol"]
    assert all(ic["node"] == ic["home"] for ic in hp["ic"] if ic["type"] != "patrol")


def test_one_ic_a_turn(make_game):
    """Flag #31 (a player, T110: one IC a turn from a host, no more): an alert that jumped two stages in one beat
    launched Patrol and the suite's next together, and a failed hack at alert 2 woke the node's guard and the next IC
    too. The build then held it to one a beat - but a GM turn (one Combat Turn) holds any number of beats, and six
    legal searches in one turn woke a rating-6 host's whole suite. At most one IC launches a turn now; a failed
    hack's guard wake is the turn's one; an IC that woke on a turn's first beat still hunts on its second."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "overwatch": 14})
    m, s = _n(L, "cybercombat"), _n(L, "electronics", "intuition")
    card = matrix.act(L, ScriptedDice([2] * m + [6] * 4), 1, "ghost", "brute_force")["card"]   # 14 -> 25: two stages
    assert matrix.state(L, "ghost")["overwatch"] == 25
    assert "HOST ALERT: launches Patrol IC in Hub A (3 more IC still dormant)" in card
    card = matrix.act(L, ScriptedDice([2] * s), 1, "ghost", "search")["card"]                  # same turn: nothing new
    assert "launches" not in card
    card = matrix.act(L, ScriptedDice([2] * s), 2, "ghost", "search")["card"]                  # the next turn: the next
    assert "HOST ALERT: launches Track IC in Comms (2 more IC still dormant)" in card
    hp = L.get(hid)["props"]                                              # a guard in Hub A, dormant: a failed hack
    for ic in hp["ic"]:                                                   # there wakes it - the turn's one IC
        if ic["type"] == "killer":
            ic.update(node="n2", home="n2")
    L.update_entity(hid, props=hp)
    n = _n(L, "hacking")
    card = matrix.act(L, ScriptedDice([2] * n + [2] * 4), 3, "ghost", "hack")["card"]
    assert "Killer IC in Hub A wakes" in card and "launches" not in card
    card = matrix.act(L, ScriptedDice([2] * s), 3, "ghost", "search")["card"]                  # same turn, next beat
    assert "launches" not in card and "Killer IC moves to Entry - it's on Ghost now" in card
    assert "Track IC moves to" in card
    card = matrix.act(L, ScriptedDice([2] * s + [2] * 40), 4, "ghost", "search")["card"]
    assert "launches Tar Baby IC" in card


def test_a_turn_of_many_beats_wakes_one_ic(make_game):
    """Review of flag #31: six legal searches in one turn at alert woke Patrol, Track, Killer, Tar Baby and Black IC
    - the rating-6 host's whole suite. One a turn: Patrol only. A failed hack's guard wake blocks a later beat's
    launch the same way."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid, _ = g.introduce("host", "KD-4 Host", "a pediatric ward", rating=6, turn=1)
    matrix.act(L, g.dice, 5, "ghost", "jack_in", hid)
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "overwatch": 26})
    s = _n(L, "electronics", "intuition")
    cards = [matrix.act(L, ScriptedDice([2] * s + [2] * 60), 5, "ghost", "search")["card"] for _ in range(6)]
    launched = [c.split("launches ")[1].split(" in ")[0] for c in cards if "launches " in c]
    assert launched == ["Patrol IC"]
    hp = L.get(hid)["props"]
    assert [ic["type"] for ic in hp["ic"] if ic["active"]] == ["patrol"] and hp["ic_launched_turn"] == 5
    for ic in hp["ic"]:                                                   # (a guard sleeping next door)
        if ic["type"] == "killer":
            ic.update(node="n2", home="n2")
    L.update_entity(hid, props=hp)
    n = _n(L, "hacking")
    card = matrix.act(L, ScriptedDice([2] * n + [2] * 12), 6, "ghost", "hack", node="Hub A")["card"]
    assert "Killer IC in Hub A wakes" in card
    card = matrix.act(L, ScriptedDice([2] * s + [2] * 60), 6, "ghost", "search")["card"]
    assert "launches" not in card
    matrix.act(L, g.dice, 6, "ghost", "jack_out")                         # (stood down: the count starts over)
    assert "ic_launched_turn" not in L.get(hid)["props"]


def test_a_bricked_deck_gives_nothing(make_game):
    """Flag #24 (T105): Filament's Cyber-5 sat at Deck 14/10, bricked, still adding +2 to his Hacking, and his gear
    said nothing of it. A bricked deck gives no bonuses and says BRICKED until it's repaired."""
    from roleplay import charsheet
    g = make_game(dice=ScriptedDice([6] * 30))
    setup_demo(g)
    L = g.ledger
    deck = next(i for i in L.holdings("ghost") if i["props"].get("deck"))
    assert (deck["name"], 2) in sr_lite.build_pool(L, "ghost", "hacking")[1] and not matrix.bricked(L, "ghost")
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "deck_damage": 14})         # (an older record's 14/10)
    assert matrix.bricked(L, "ghost") == deck["id"]
    for skill in ("hacking", "cybercombat", "electronics"):
        assert deck["name"] not in [label for label, _ in sr_lite.build_pool(L, "ghost", skill)[1]]
    assert "BRICKED (Deck 14/10) - no bonuses until repaired" in sr_lite.sheet(L, "ghost")
    assert "**BRICKED**" in charsheet.matrix_card(g, "ghost", 0)["description"]
    gear = next(c for c in charsheet.cards(g, "ghost") if c["title"] == "Gear")["description"]
    assert "BRICKED (Deck 14/10) - no bonuses until repaired" in gear
    with pytest.raises(LedgerError, match="bricked"):
        matrix.act(L, g.dice, 1, "ghost", "jack_in", _host(g))
    matrix.act(L, g.dice, 1, "ghost", "repair")
    assert not matrix.bricked(L, "ghost") and (deck["name"], 2) in sr_lite.build_pool(L, "ghost", "hacking")[1]


def test_convergence_is_matrix_damage_too(make_game):
    """Convergence's own hit goes the same way as an IC's: soaked by Device Rating + Firewall, onto the deck up to its
    monitor, the rest Stun - and the trace it leaves is the hook's, not the next run's."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    matrix._save(L, "ghost", {**matrix.state(L, "ghost"), "overwatch": 36, "deck_damage": 7})
    n = _n(L, "hacking")
    res = matrix.act(L, ScriptedDice([2] * n + [6] * 4 + H2[:8]), 1, "ghost", "hack")   # fails: +4 +3 = 43
    assert "CONVERGENCE" in res["card"] and res["traced"] and res["out"]
    assert ("The grid's own hit: 6 Matrix damage, soaks Device Rating 4 + Firewall 4 = 8d6 -> 0 hits: deck takes 3 "
            "-> Deck 10/10") in res["card"] and "3 past the full deck: Ghost takes 3S" in res["card"]
    st = matrix.state(L, "ghost")
    assert (st["host"], st["traced"], st["deck_damage"]) == (None, False, 10) and L.stat("ghost", "stun_damage") == 3
