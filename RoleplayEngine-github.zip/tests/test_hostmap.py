"""Host maps: a host is a network of nodes the decker moves through (Genesis-style) - drawn by the engine, tied to
the building, colored by security, explored as you go, and owned once you take the Core."""
import asyncio

from roleplay import netmap
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import hostmap, matrix
from roleplay.setup import setup_demo

from .test_discord import FakeChannel


def test_maps_are_drawn_by_the_engine_and_scale_with_the_host():
    small, big = hostmap.generate("corner-store", 2), hostmap.generate("arcology", 9)
    assert hostmap.generate("corner-store", 2) == small                       # the same host, the same map, every time
    assert len(small) == 6 and len(big) == 12
    for nodes in (small, big):
        hp = {"nodes": nodes}
        ent = hostmap.entry(hp)
        assert ent["color"] == "blue"                                         # you always walk in at an open node
        assert all(len(hostmap.path(hp, ent["id"], n["id"])) >= 1 and hostmap.path(hp, ent["id"], n["id"])[-1] == n["id"]
                   for n in nodes)                                            # every node is reachable
    assert next(n for n in big if n["kind"] == "core")["color"] == "red"
    assert {n.get("system") for n in big if n["kind"] == "devices"} == {"cameras", "locks", "alarms", "elevators"}


def test_explore_and_take_the_core(make_game):
    g = make_game(dice=ScriptedDice([6] * 400))
    setup_demo(g)
    L = g.ledger
    hid, _ = g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=5, turn=1)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    hp, st = L.get(hid)["props"], matrix.state(L, "ghost")
    seen = set(st["seen"][hid])
    assert seen == {"n1", "n2"} and st["node"] == "n1"                       # the Entry and what's next to it
    matrix.act(L, g.dice, 1, "ghost", "hack")                                 # cracks Hub A
    card = matrix.act(L, g.dice, 1, "ghost", "search")["card"]
    assert "FOUND:" in card and len(matrix.state(L, "ghost")["scanned"][hid]) > 1
    st = matrix.state(L, "ghost")
    st.setdefault("creds", {})[hid] = "admin"                                 # (a sysop's login, lifted mid-run)
    matrix._save(L, "ghost", st)
    card = matrix.act(L, g.dice, 1, "ghost", "move", node="Core")["card"]
    assert "In Core (red, your login opens it)" in card
    hp = L.get(hid)["props"]
    for ic in hp["ic"]:
        ic["active"] = True
    hp["alert"] = 2
    L.update_entity(hid, props=hp)
    card = matrix.act(L, g.dice, 2, "ghost", "admin", effect="shut the agents off and kill the alarm")["card"]
    assert "every IC in the host stands down" in card and "the alert is cancelled" in card
    hp = L.get(hid)["props"]
    assert hp["alert"] == 0 and not any(ic["active"] for ic in hp["ic"])
    assert all(ic["node"] == ic["home"] for ic in hp["ic"])
    card = matrix.act(L, g.dice, 2, "ghost", "admin", effect="pull the whole map")["card"]
    assert "the whole map" in card and len(matrix.state(L, "ghost")["seen"][hid]) == len(hp["nodes"])
    assert netmap.render(g, "ghost").exists()


def test_old_hosts_get_a_map_mid_dive(make_game):
    g = make_game(dice=ScriptedDice([6] * 100))
    setup_demo(g)
    L = g.ledger
    hid, _ = g.introduce("host", "Old Host", "a host from before maps", rating=5, turn=1)
    L.update_entity(hid, props={**L.get(hid)["props"], "alert": 2,
                                "ic": [{"type": "patrol", "rating": 5, "damage": 0, "active": True}]})
    st = matrix.state(L, "ghost")
    st.update(host=hid, mode="ar", overwatch=12, last_turn=1)                 # jacked in before maps existed
    matrix._save(L, "ghost", st)
    card = matrix.act(L, g.dice, 2, "ghost", "search")["card"]
    assert "Old Host" in card and matrix.state(L, "ghost")["node"] == "n1"
    hp = L.get(hid)["props"]
    assert hp["nodes"] and hp["ic"][0]["home"] and hp["alert"] == 2           # the old state kept, a map added
    assert any("Old Host" in x for x in matrix.summary_lines(L, "ghost")) and "Map (yours to narrate" in "\n".join(
        matrix.summary_lines(L, "ghost"))


def test_matrixhelp_says_what_a_decker_can_do(make_game):
    g = make_game()
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        for cmd in ("!matrixhelp", "!mhelp"):
            await t.handle("1", "Alice", cmd, False, react)
            assert ch.sent[-1]["title"] == "🕸️ In the Matrix" and "Core" in ch.sent[-1]["description"]
        await t.close()
    asyncio.run(go())
