"""Geography: places on the map, and the engine doing the distance math for the DM."""
from types import SimpleNamespace

from roleplay.dm import world
from roleplay.engine import geo
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text
from .test_world import NONE, WorldLLM, _personas


def test_math_and_names():
    barrens, arc = geo.district_geo("Redmond Barrens"), geo.district_geo("Renraku Arcology")
    d = geo.distance_m(barrens, arc)
    assert 15_000 < d < 18_000 and geo.bearing(barrens, arc) == "W"
    t = geo.travel_minutes(d)
    assert 25 <= t["car"] <= 35 and t["walk"] > 200                       # across the lake: drive it
    assert geo.describe(barrens, arc) == "16.6 km W · across town"           # how far, in words - no minutes
    near = dict(zip(("lat", "lon"), geo.offset(barrens["lat"], barrens["lon"], "E", 600)))
    assert abs(geo.distance_m(barrens, near) - 600) < 2 and geo.bearing(barrens, near) == "E"
    assert geo.describe(barrens, near) == "600 m E · a walk, or a quick drive"
    assert [geo.how_far(m) for m in (30, 300, 900, 4000, 12000, 50000)] == [
        "right here", "a short walk", "a walk, or a quick drive", "a short drive", "across town",
        "the far side of the metroplex"]
    assert geo.best_trip(barrens, near) == ("walk", 10) and geo.best_trip(barrens, arc)[0] == "car"
    assert geo.districts_in("We drive out of the Redmond Barrens to Tacoma") == ["Redmond Barrens", "Tacoma"]
    assert geo.district("the arcology") == "Renraku Arcology" and geo.district("Narnia") is None


def test_places_get_positions_from_hints(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    bar = L.get("the-lucky-shot")["props"]["geo"]
    assert bar["district"] == "Redmond Barrens" and "from its description" in bar["how"]
    cart, _ = g.introduce("location", "Papa Oyo's noodle cart", "a trike with a tarp", turn=1,
                          where={"near": "the-lucky-shot", "bearing": "E", "distance_m": 600})
    c = L.get(cart)["props"]["geo"]
    assert abs(geo.distance_m(bar, c) - 600) < 2 and geo.bearing(bar, c) == "E"
    tac, _ = g.introduce("location", "Dockside warehouse", "rusting warehouse", turn=1, where={"district": "Tacoma"})
    assert L.get(tac)["props"]["geo"]["district"] == "Tacoma"
    lost, _ = g.introduce("location", "A back room", "smells of mold", turn=1)       # no hints: near the scene
    assert geo.distance_m(bar, L.get(lost)["props"]["geo"]) < 600
    L.update_entity("the-lucky-shot", props={})                                       # an old campaign...
    assert geo.ensure_all(g) == ["the-lucky-shot"] and L.get("the-lucky-shot")["props"]["geo"]   # ...backfilled


def test_the_dm_sees_distances_not_math(make_game):
    g = make_game()
    setup_demo(g)
    g.introduce("location", "Papa Oyo's noodle cart", "a trike", turn=1,
                where={"near": "the-lucky-shot", "bearing": "E", "distance_m": 600})
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "We should drive down to Tacoma tonight.")], 9)
    assert "Location: The Lucky Shot [the-lucky-shot] (Redmond Barrens)" in packet
    assert "=== WHERE THINGS ARE" in packet
    assert "Papa Oyo's noodle cart [papa-oyo-s-noodle-cart] (Redmond Barrens) - 600 m E · a walk, or a quick drive" \
        in packet
    tacoma = next(x for x in packet.splitlines() if x.startswith("Tacoma (district)"))
    assert "km S" in tacoma and tacoma.endswith("the far side of the metroplex") and " min" not in tacoma


def test_a_drive_is_a_distance_not_a_clock_and_the_table_hears_how_far(make_game):
    cut = SimpleNamespace(type="tool_use", name="introduce", id="tu_geo",
                          input={"kind": "location", "name": "Renraku Arcology Plaza", "description": "glass and guards",
                                 "district": "Renraku Arcology"})
    move = SimpleNamespace(type="tool_use", name="cut_scene", id="tu_cut",
                           input={"title": "At the arcology", "location_id": "renraku-arcology-plaza",
                                  "bring_ids": ["razor", "ghost"]})
    extraction = {**NONE, "summary": "Razor and Ghost drove to the arcology.", "recalled": [], "facts": [],
                  "told": [], "new_entities": [], "minutes_elapsed": 5,
                  "moved_to": {"location": "", "description": "", "who": [],
                               "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
                  "members": [{"id": "razor", "role": "actor"}]}
    g = make_game(FakeLLM([([cut, move], "tool_use"), ([text("You drive west over the 520.")], "end_turn")], extraction))
    setup_demo(g)
    start = g.clock()
    res = g.run_turn([("razor", "We drive to the Renraku Arcology.")])
    assert g.clock() == start                          # story time is narrative: the GM moves it, not the trip
    assert res.info["trip"] == "across town from The Lucky Shot"


def test_offscreen_people_are_on_the_map(make_game):
    llm = WorldLLM()
    g = make_game(llm)
    setup_demo(g)
    _personas(g)
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    world.move(g, "kaz", "a noodle bar in Tacoma", "Tacoma")
    assert geo.geo_of(g, "kaz")["district"] == "Tacoma"
    aid = world.add_agenda(g, "kaz", "get to the docks", ["the-lucky-shot"], g.turn_no(), by="dm")
    job = next(j for j in world.plan(g) if j.npc == "kaz")
    assert "PLACES FROM WHERE YOU ARE (how far, in words):" in job.user and "The Lucky Shot [the-lucky-shot]" in job.user
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], g.turn_no() + 1)
    line = next(x for x in packet.splitlines() if x.startswith(f"[{aid}] Kaz (now: a noodle bar in Tacoma"))
    assert " km SW · the far side of the metroplex from here)" in line and " min" not in line   # Kaz, in Tacoma


def test_askdm_answers_distance_questions_with_engine_numbers(make_game):
    class Echo(FakeLLM):
        def text(self, model, system, user, **kw):
            self.asked = user
            return "ok"
    llm = Echo()
    g = make_game(llm)
    setup_demo(g)
    g.askdm("razor", "How long would it take us to drive to Tacoma?")
    assert "DISTANCES FROM HERE (engine-computed - quote these):" in llm.asked
    assert next(x for x in llm.asked.splitlines() if x.startswith("Tacoma (district) - ")).endswith(
        "the far side of the metroplex")


def test_places_stay_out_of_the_water(make_game):
    from types import SimpleNamespace
    from roleplay.engine import coast
    assert coast.in_water(47.599, -122.347) and not coast.in_water(47.6097, -122.3422)    # Elliott Bay / Pike Place
    assert not coast.in_water(47.57, -122.23)                                            # Council Island is land
    lat, lon, moved = coast.ashore(47.599, -122.347)
    assert not coast.in_water(lat, lon) and 0 < moved < 1500
    assert coast.ashore(47.6097, -122.3422) == (47.6097, -122.3422, 0.0)
    g = make_game()
    for i in range(12):                              # "somewhere on the waterfront" never means in the bay
        eid, _ = g.introduce("location", f"Pier shack {i}", "a shack on the Elliott Bay waterfront", turn=1)
        pos = g.ledger.get(eid)["props"]["geo"]
        assert not coast.in_water(pos["lat"], pos["lon"]), pos
    eid, _ = g.introduce("location", "Wet spot", "", turn=1)
    g.ledger.update_entity(eid, props={"geo": {"lat": 47.599, "lon": -122.347, "district": "Elliott Bay Docks",
                                               "how": "near the docks"}})
    assert eid in geo.ensure_all(SimpleNamespace(ledger=g.ledger))                       # an old one comes ashore
    pos = g.ledger.get(eid)["props"]["geo"]
    assert not coast.in_water(pos["lat"], pos["lon"]) and "moved ashore" in pos["how"]
    assert geo.ensure_all(SimpleNamespace(ledger=g.ledger)) == []                         # once


def test_the_real_map_decides_and_pilings_dont_count(monkeypatch):
    """OpenStreetMap paints water one blue: a point is ashore only on solid ground, not on a piling in the bay."""
    import math
    from PIL import Image
    from roleplay.engine import coast
    tile = Image.new("RGB", (256, 256), (242, 239, 233))          # land...
    tile.paste(coast.WATER, (0, 0, 128, 256))                      # ...with water on the west half
    tile.paste((150, 150, 150), (40, 120, 46, 126))                # and a ferry-slip piling out in it
    monkeypatch.setattr(coast, "_tile", lambda x, y, z=coast.TILE_Z: tile)

    def at(px, py, tx=10_000, ty=20_000):                          # a pixel of the tile -> lat, lon
        n = 2 ** coast.TILE_Z * 256
        lon = (tx * 256 + px) / n * 360 - 180
        lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (ty * 256 + py) / n))))
        return lat, lon
    assert coast.water_share(*at(200, 128)) == 0 and coast.water_share(*at(20, 128)) == 1
    lat, lon = at(43, 123)                                          # right on the piling
    assert coast.water_share(lat, lon) > 0.9                        # ...still the bay
    s = coast.shore_check(lat, lon)
    assert s["by"] == "map" and s["moved"] > 0 and coast.water_share(s["lat"], s["lon"]) <= 0.08
    assert coast.shore_check(*at(200, 128)) == {"lat": at(200, 128)[0], "lon": at(200, 128)[1], "moved": 0.0, "by": "map"}
    monkeypatch.setattr(coast, "_tile", lambda x, y, z=coast.TILE_Z: None)            # offline: the traced shores
    assert coast.shore_check(47.599, -122.347)["by"] == "trace"
