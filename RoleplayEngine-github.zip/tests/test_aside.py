"""The GM aside: "Hey DM ..." is answered out of character - the story doesn't move, mistakes get fixed, and a request
for the story waits for the next turn."""
import asyncio
import json

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import aside, doubts, research
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool
from .test_discord import FakeChannel

COMMIT = {"summary": "The crew skipped ahead to the office.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}


def _llm(reply):
    asked = []

    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            asked.append(user)
            return reply
        return COMMIT
    llm = FakeLLM([([text("The office door opens on Brask.")], "end_turn")], structured)
    return llm, asked


def test_an_aside_answers_fixes_and_queues_the_next_turn(make_game):
    llm, asked = _llm({"answer": "You're right - you told T you'd be there before 7. I'll fix it.",
                       "direction": "Open with the crew already in T's office before the nurse arrives.",
                       "fixes": ["fact razor, ghost: The crew promised T they'd be at her office before 7."],
                       "is_move": False})
    g = make_game(llm)
    setup_demo(g)
    t0, clock0 = g.turn_no(), g.clock()
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM you forgot we told T we'd be there before 7", "razor")
    assert res["answer"].startswith("You're right") and res["fixed"] == ["a fact"] and not res["is_move"]
    assert g.turn_no() == t0 and g.clock() == clock0                         # the story didn't move
    assert any("before 7" in f["text"] for f in g.sub.facts_for("razor"))
    assert "THE LAST TURNS" in asked[0] and "Hey DM you forgot" in asked[0]
    assert aside.directions(g) == ["Open with the crew already in T's office before the nurse arrives."]
    g.run_turn([("razor", "We wait for the nurse.")])
    assert "FROM THE TABLE, OUT OF CHARACTER" in llm.dm_requests[-1] and "T's office" in llm.dm_requests[-1]
    assert aside.directions(g) == []                                          # acted on, cleared


def test_an_aside_never_claims_a_fix_it_did_not_make(make_game):
    """Live T83: an aside's note with space-separated ids was skipped, and the reply still said "Fixed in the record".
    Now those ids land - and a line naming no one on file, or a time the clock can't read, isn't reported fixed (the
    unread time is shown to the GM next turn instead)."""
    llm, _ = _llm({"answer": "Fixed.", "direction": "", "fixes": ["note nobody-here: x", "time: teatime"],
                   "is_move": False})
    g = make_game(llm)
    setup_demo(g)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, Kaz and Razor made up", "razor")
    assert res["fixed"] == []
    assert "your last `time: teatime` wasn't read" in build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0]
    llm, _ = _llm({"answer": "Fixed.", "direction": "", "fixes": ["note kaz razor: they made up"], "is_move": False})
    g = make_game(llm)
    setup_demo(g)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, Kaz and Razor made up", "razor")
    assert res["fixed"] == ["the GM's notes"]
    assert g.sub.notes_for("kaz", 1)[0]["id"] == g.sub.notes_for("razor", 1)[0]["id"]


def test_an_aside_karma_line_that_awards_nothing_isnt_claimed(make_game):
    """Review (2026-10-24): `karma razor: three for ...` (no digits) and karma for an NPC awarded nothing, never
    reached ctx.unplaced, and the card still said it fixed karma."""
    for bad in ("karma razor: three for the clean extraction", "karma kaz: +3 for the tip"):
        llm, _ = _llm({"answer": "Done.", "direction": "", "fixes": [bad], "is_move": False})
        g = make_game(llm)
        setup_demo(g)
        logged = []
        g.out = logged.append
        res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, we never got karma for the extraction", "razor")
        assert res["fixed"] == [] and g.ledger.stat("razor", "karma") == 0, bad
        assert any("no karma awarded" in x for x in logged), bad
    llm, _ = _llm({"answer": "Done.", "direction": "", "fixes": ["karma razor: +3 for the clean extraction"],
                   "is_move": False})
    g = make_game(llm)
    setup_demo(g)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, we never got karma for the extraction", "razor")
    assert res["fixed"] == ["karma"] and g.ledger.stat("razor", "karma") == 3


def test_a_hey_dm_at_the_table_is_an_aside_not_a_move(make_game):
    llm, asked = _llm({"answer": "Quiet Lou's a companion - I play them.", "direction": "", "fixes": [],
                       "is_move": False})
    g = make_game(llm)
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()
        reacts = []

        async def react(e):
            reacts.append(e)
        await t.handle("1", "Alice", "!join razor", False, react)
        await t.handle("1", "Alice", "Hey DM, who plays Quiet Lou?", False, react)
        assert ch.sent[-1]["title"] == "🎙️ GM aside - to Alice" and "companion" in ch.sent[-1]["description"]
        assert t.director.queue == [] and "🎙️" in reacts and "Alice (plays Razor [razor])" in asked[-1]
        await t.handle("1", "Alice", "!gm is the teamwork rule on?", False, react)
        assert ch.sent[-1]["title"] == "🎙️ GM aside - to Alice" and t.director.queue == []
        await t.handle("1", "Alice", "!dm can I analyze the host first?", False, react)    # (what people type)
        assert ch.sent[-1]["title"] == "🎙️ GM aside - to Alice"
        await t.close()
    asyncio.run(go())


DEAL = ("**Kaz [kaz]:** \"Five hundred by Friday, and I name the buyer. Not a word to Lone Star.\" He slides the "
        "glass over.")


def _played(reply, script):
    """The demo plus one turn where Kaz names his price; the aside's lookups scripted, then its reply."""
    llm = FakeLLM([([text(DEAL)], "end_turn")], lambda user: reply if "SAYS TO YOU, OUT OF CHARACTER" in user else
                  dict(COMMIT, summary="Kaz agreed to name the buyer."), script)
    return llm


def _results(llm) -> list[str]:
    return [b["content"] for m in llm.consults[-1]["messages"] if m["role"] == "user" and isinstance(m["content"], list)
            for b in m["content"] if b.get("type") == "tool_result"]


def test_an_aside_reads_the_turn_before_it_answers(make_game):
    """2026-10-26 (DESIGN.md §8e): "didn't we agree at T4..." was answered from the packet's summaries - the turn
    itself, word for word, never reached the aside."""
    answer = {"answer": "T4 has Kaz at five hundred by Friday, not a thousand.", "direction": "", "fixes": [],
              "is_move": False}
    llm = _played(None, [])
    g = make_game(llm)
    setup_demo(g)
    t = g.run_turn([("razor", "What's your price, Kaz?")]).turn_id
    llm.consult_script = [([tool("read_turn", turn_ids=[f"T{t}"], around="Friday")], "tool_use"),
                          ([text(json.dumps(answer))], "end_turn")]
    touched = g.conn.execute("SELECT touch_count FROM energy WHERE node_id=?", (f"T{t}",)).fetchone()[0]
    res = aside.ask(g, "Alice (plays Razor [razor])", f"Hey DM, didn't Kaz say a thousand at T{t}?", "razor")
    assert res["answer"] == answer["answer"] and res["checked"] == [f"T{t}"] and not res["is_move"]
    assert g.turn_no() == t                                                  # the story didn't move
    first = llm.consults[0]
    assert first["tools"] == ["recall", "read_turn", "search_memory", "timeline"] and first["schema"] == aside.schema()
    assert "Check the record before you answer a question about what happened" in first["system"]
    # (final check on a copy of the live world: "when was that?" was answered "around T150-T153" with no lookup - the
    # stamp on Juno's picture [C83, T153]; the record has it at T31, retconned to Magic at T33)
    assert "never from a stamp in the packet" in first["system"] and 'Asked "when was that?"' in first["system"]
    assert first["purpose"] == "aside" and first["tool_choice"] is None
    assert "Five hundred by Friday, and I name the buyer" in _results(llm)[0]   # the words, not the summary
    assert g.conn.execute("SELECT touch_count FROM energy WHERE node_id=?", (f"T{t}",)).fetchone()[0] > touched


def test_an_aside_only_looks_and_answers_within_its_budget(make_game):
    """A few rounds of lookups (models.aside_research_steps), then the answer with the tools off. Anything but a
    lookup is turned away - what it would change goes in fixes, where the table hears what landed."""
    answer = {"answer": "Nothing on file about a discount.", "direction": "", "fixes": [], "is_move": False}
    script = [([tool("establish_fact", text="Kaz gave the crew a discount.", about=["kaz"]),
                tool("search_memory", query="discount")], "tool_use")] + [
        ([tool("search_memory", query="Kaz discount")], "tool_use")] * 3 + [
        ([text(json.dumps(answer))], "end_turn"), ([tool("recall", ids=["kaz"])], "tool_use")]
    llm = _played(None, script)
    g = make_game(llm)
    setup_demo(g)
    facts = g.conn.execute("SELECT COUNT(*) FROM nodes WHERE kind='fact'").fetchone()[0]
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, didn't Kaz give us a discount?", "razor")
    assert res["answer"] == answer["answer"]
    steps = g.settings.models.aside_research_steps
    assert steps == 4 and len(llm.consults) == steps + 1 and len(llm.consult_script) == 1
    assert [c["tool_choice"] for c in llm.consults] == [None] * steps + [{"type": "none"}]
    out = _results(llm)
    assert out[0].startswith("No establish_fact in an aside - only lookups")
    assert g.conn.execute("SELECT COUNT(*) FROM nodes WHERE kind='fact'").fetchone()[0] == facts   # nothing written
    assert llm.consults[-1]["messages"][-1]["content"][-1] == {"type": "text", "text": research.LAST_LOOK}


def test_an_aside_that_cant_tell_who_is_right_raises_a_doubt(make_game):
    reply = {"answer": "I can't find that on file - I'll look into it before it matters.", "direction": "",
             "fixes": ["doubt kaz, razor: Alice remembers Kaz promising a discount; nothing on file says so."],
             "is_move": False}
    llm = _played(reply, [([tool("search_memory", query="Kaz discount", in_narration=True)], "tool_use")])
    g = make_game(llm)
    setup_demo(g)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, Kaz promised us a discount, remember?", "razor")
    assert res["fixed"] == ["a doubt the GM will look into"] and res["checked"] == []
    d = doubts.listing(g.conn, g.turn_no())["open"][0]
    assert d["raised_by"] == "aside" and "discount" in d["text"]


def test_the_aside_card_says_which_public_turns_it_checked(make_game):
    reply = {"answer": "Checked - five hundred.", "direction": "", "fixes": [], "is_move": False}
    llm = _played(reply, [])
    g = make_game(llm)
    setup_demo(g)
    t = g.run_turn([("razor", "What's your price, Kaz?")]).turn_id
    w = g.run_turn([("razor", "I pocket a coaster.")], private="razor").turn_id   # (a whisper bore on it - unsaid)
    llm.consult_script = [([tool("read_turn", turn_ids=[f"T{t}", f"T{w}"])], "tool_use")]

    async def go():
        ch = FakeChannel()
        table = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await table.refresh()

        async def react(e):
            pass
        await table.handle("1", "Alice", "!join razor", False, react)
        await table.handle("1", "Alice", "Hey DM, what was Kaz's price?", False, react)
        card = ch.sent[-1]
        assert card["title"] == "🎙️ GM aside - to Alice" and f"-# Checked the record: T{t}" in card["description"]
        assert f"T{w}" not in card["description"]
        await table.close()
    asyncio.run(go())


def test_the_aside_looks_up_only_what_the_table_has_seen(make_game):
    """Review (2026-10-26): the aside's answer is posted to the whole table, and its notebook read Razor's whisper word
    for word for Ghost's player - and every DM note, persona and mind in the campaign. At the table its lookups reach
    public turns and canon and the asker's own whispers; never another player's whisper, the offscreen world or the
    GM's private notebook."""
    from roleplay.dm import world
    palm = "You palm the maglock keycard off the counter. Kaz never looks up."
    reply = {"answer": "Nothing on file.", "direction": "", "fixes": [], "is_move": False}
    llm = FakeLLM([([text(DEAL)], "end_turn"), ([text(palm)], "end_turn")],
                  lambda user: reply if "SAYS TO YOU, OUT OF CHARACTER" in user else
                  dict(COMMIT, summary="Razor palmed Kaz's maglock keycard." if "palm" in user else
                       "Kaz agreed to name the buyer.", members=[{"id": "razor", "role": "actor"}]))
    g = make_game(llm)
    setup_demo(g)
    deal = g.run_turn([("razor", "What's your price, Kaz?")]).turn_id
    tw = g.run_turn([("razor", "I palm Kaz's maglock keycard.")], private="razor").turn_id
    t = g.turn_no()
    away = g.sub.write_offscreen(t, "Kaz sold the crew's names to Lone Star for the rent.", [("kaz", "actor")])
    g.sub.add_belief("kaz", "razor", "Kaz thinks Razor is a soft touch.", t)
    g.sub.clarify("kaz", "Kaz: an informant for Lone Star, scared for his bar.", t)
    world.add_agenda(g, "kaz", "keep the bar open whatever it costs", ["razor"], t, "test")
    lookups = [tool("read_turn", turn_ids=[f"T{tw}", away, f"T{deal}"]), tool("recall", ids=["kaz", f"T{tw}", "N1"]),
               tool("search_memory", query="maglock keycard Lone Star", in_narration=True),
               tool("search_memory", query="Kaz", kinds=["note", "belief", "picture", "agenda", "offscreen"]),
               tool("timeline", ids=["razor"])]
    llm.consult_script = [(lookups, "tool_use"), ([text(json.dumps(reply))], "end_turn")]
    aside.ask(g, "Bob (plays Ghost [ghost])", "Hey DM, what has Razor been up to lately?", "ghost")
    said = "\n".join(_results(llm))
    assert "Five hundred by Friday, and I name the buyer" in said          # the table's turn, word for word
    for secret in ("palm", "sold the crew's names", "Secret: Kaz sells", "soft touch",
                   "informant for Lone Star", "Persona (GM-only)", "keep the bar open", "Mind - what they think"):
        assert secret not in said, secret
    assert f"[T{tw}] can't be looked up in an aside" in said and f"[{away}] can't be looked up in an aside" in said
    system = llm.consults[0]["system"]
    assert "posted in the open channel" in system and "another player's whisper" in system
    llm.consult_script = [([tool("read_turn", turn_ids=[f"T{tw}"]), tool("timeline", ids=["razor"])], "tool_use"),
                          ([text(json.dumps(reply))], "end_turn")]
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, did I get the keycard?", "razor")
    read, line = _results(llm)
    assert palm in read and f"[T{tw}]" in line                              # their own whisper is theirs to read
    assert res["checked"] == []                                             # (and the table's card never names it)


def test_a_whisper_done_to_the_askers_character_is_not_theirs(make_game):
    """Review (2026-10-26): Ghost slips a tracker into Razor's coat ("He never notices"); the memory pass lists Razor as
    its target, and the whisper's label named every witness-role member as knowing - "only Ghost, Razor know". When
    Razor's player asked the aside "did anyone mess with my coat?", the record told it Razor knew. Who sent it knows
    (and who heard of it since); anyone else in it, only if they noticed - in the label, in what the aside may look up,
    and in the prompt."""
    from roleplay.substrate.packet import _whisper
    from .test_witness import WHISPER, _world
    g, llm, bar, slip, away = _world(make_game)
    node = g.sub.node(f"T{slip}")
    assert _whisper(g, node) == "WHISPER, private - only Ghost knows (Razor too, only if they noticed it): "
    g.sub.add_knows("kaz", f"T{slip}", "told", "ghost", g.turn_no())
    assert _whisper(g, node) == "WHISPER, private - only Ghost, Kaz know (Razor too, only if they noticed it): "
    xid = doubts.raise_(g, "Did the tracker land in the coat or the bag?", [f"T{slip}", "razor"], g.turn_no())["id"]
    assert doubts.secret(g, doubts.get(g, xid))["who"] == {"ghost", "kaz"}  # (Razor, its unknowing target, isn't in)
    reply = {"answer": "Nothing at the table says so.", "direction": "", "fixes": [], "is_move": False}
    llm.consult_script = [([tool("search_memory", query="tracker coat", in_narration=True),
                            tool("read_turn", turn_ids=[f"T{slip}"]), tool("recall", ids=[xid, "razor"]),
                            tool("timeline", ids=["razor", "ghost"])], "tool_use"),
                          ([text(json.dumps(reply))], "end_turn")]
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, did anyone mess with my coat?", "razor")
    said = "\n".join(_results(llm))
    for secret in (WHISPER, "Ghost slipped", "tracker land", "Ghost, Razor know"):
        assert secret not in said, secret
    assert f"[T{slip}] can't be looked up in an aside" in said and f"[{xid}] can't be looked up in an aside" in said
    first = llm.consults[0]
    assert "Ghost, Razor know" not in first["messages"][0]["content"]       # (the packet's label: Razor doesn't know)
    assert "one done to their character is the sender's" in first["system"]


def test_an_aside_lookup_slip_is_retried_not_flagged(make_game, tmp_path):
    """Review (2026-10-26): the aside's lookups ran through tools.run_tool on the next turn's context, so `recall` with
    no ids filed an engine 'tool error' flag against T4 - a turn not played yet. A lookup writes nothing: its slip is
    the model's to retry, as !askdm's are."""
    from roleplay import flags
    answer = {"answer": "Kaz likes you fine.", "direction": "", "fixes": [], "is_move": False}
    llm = _played(answer, [([tool("recall"), tool("read_turn", turn_ids=["T99999999999999999999"])], "tool_use"),
                           ([text(json.dumps(answer))], "end_turn")])
    g = make_game(llm)
    setup_demo(g)
    before = len(flags.listing(tmp_path, status=None))
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, what does Kaz think of us?", "razor")
    assert res["answer"] == answer["answer"]
    blocks = [b for m in llm.consults[-1]["messages"] if m["role"] == "user" and isinstance(m["content"], list)
              for b in m["content"] if b.get("type") == "tool_result"]
    assert blocks[0]["is_error"] and blocks[0]["content"] == "Error: missing field 'ids'"
    assert "Couldn't read: T99999999999999999999" in blocks[1]["content"]
    assert len(flags.listing(tmp_path, status=None)) == before              # nothing pinned on a turn not played


def test_an_aside_out_of_lookups_is_told_to_answer_not_narrate(make_game):
    """Review (2026-10-26): past the lookup cap the aside heard the turn's words - "narrate with what you have ... the
    doubt tool, or `doubt` in your <dm> block". It has no narration, no doubt tool and no <dm> block: it answers, and
    what it couldn't check goes in fixes."""
    reply = {"answer": "Nothing on file.", "direction": "", "fixes": [], "is_move": False}
    six = [tool("search_memory", query=f"Kaz {i}") for i in range(6)]
    llm = _played(reply, [(six, "tool_use")] * 3 + [([text(json.dumps(reply))], "end_turn")])
    g = make_game(llm)
    setup_demo(g)
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, what did Kaz say about the Ancients?", "razor")
    cap = g.settings.models.dm_research_calls
    out = _results(llm)
    assert len(out) == 18 and cap == 16
    assert out[16:] == [research.ASIDE_SPENT.format(cap=cap)] * 2
    assert "narrate" not in out[16] and "<dm>" not in out[16] and "fixes" in out[16]


def test_a_move_that_starts_with_dm_goes_into_the_turn(make_game):
    llm, _ = _llm({"answer": "", "direction": "", "fixes": [], "is_move": True})
    g = make_game(llm)
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()
        reacts = []

        async def react(e):
            reacts.append(e)
        await t.handle("1", "Alice", "!join razor", False, react)
        await t.handle("1", "Alice", "DM: Razor kicks the door in.", False, react)
        assert t.director.queue == [("razor", "DM: Razor kicks the door in.")] and reacts[-1] == "📝"
        await t.close()
    asyncio.run(go())
