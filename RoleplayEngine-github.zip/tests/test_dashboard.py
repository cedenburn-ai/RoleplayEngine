"""The dashboard: read-only views of a world, a local server that only answers its own page, the bot's log tail."""
import http.client
import json

import pytest

from roleplay import jobs, spend
from roleplay.dashboard import botctl, data, server
from roleplay.discord_bot import runtime
from roleplay.setup import setup_demo

from .conftest import FakeLLM

EXTRACTION = {"summary": "Razor asked Kaz about work.", "members": [{"id": "razor", "role": "actor"},
              {"id": "kaz", "role": "target"}], "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []}, "job_moved": True,
              "jobs": [{"id": "", "change": "active", "title": "Courier run uptown", "client": "kaz",
                        "objective": "Carry the chip to Bellevue", "pay": "3,000 nuyen", "deadline": "by dawn",
                        "progress": "Razor took the chip"}]}


@pytest.fixture
def world(make_game, tmp_path, monkeypatch):
    monkeypatch.setattr(runtime, "RUN_DIR", tmp_path / ".run")
    g = make_game(FakeLLM(extraction=EXTRACTION))
    setup_demo(g)
    g.conn.execute("INSERT INTO players(discord_id, handle, name) VALUES('42', 'razor', 'Mo')")
    g.run_turn([("razor", "Kaz, got anything for me?")])
    return g


def test_the_overview_reads_a_world_without_touching_it(world, tmp_path):
    name = world.path.stem
    before = world.path.stat().st_mtime
    o = data.overview(name, None, tmp_path)
    assert o["turns"]["total"] == 1 and o["scene"]["title"] and o["clock"].startswith("Day 1")
    assert o["job"]["title"] == "Courier run uptown" and o["job"]["client"]["name"] == "Kaz"
    razor = next(p for p in o["party"] if p["id"] == "razor")
    assert razor["discord_name"] == "Mo" and razor["physical"][1] >= 8 and razor["role"]
    assert o["players"][0]["name"] == "Mo" and o["players"][0]["character"]["name"] == "Razor" and o["players"][0]["turns"] == 1
    assert o["recent"][0]["inputs"][0]["name"] == "Razor" and o["recent"][0]["narration"]
    assert world.path.stat().st_mtime == before                          # read-only
    with pytest.raises(data.NotFound):
        data.overview("../secrets", None, tmp_path)
    s = data.story(name, folder=tmp_path)
    assert s["scene"] == world.current_scene_id() and s["turns"][-1]["inputs"][0]["text"] == "Kaz, got anything for me?"
    p = data.people(name, None, tmp_path)
    assert any(n["name"] == "Kaz" for n in p["npcs"]) and p["players"][0]["handle"] == "razor"
    names = [c["name"] for c in data.campaign_list(tmp_path)]
    assert name in names and "usage" not in names


def _request(port, method, path, headers=None, body=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    c.request(method, path, body=json.dumps(body) if body is not None else None, headers=headers or {})
    r = c.getresponse()
    out = r.status, r.read()
    c.close()
    return out


def test_the_server_only_answers_its_own_page(world, tmp_path):
    dash = server.Dashboard(0, "serve", tmp_path)
    dash.start()
    try:
        host = {"Host": f"127.0.0.1:{dash.port}"}
        code, page = _request(dash.port, "GET", "/", host)
        assert code == 200 and dash.key.encode() in page
        assert _request(dash.port, "GET", "/", {"Host": "evil.example:80"})[0] == 403          # DNS rebinding
        code, body = _request(dash.port, "GET", f"/api/dash/overview?c={world.path.stem}", host)
        assert code == 200 and json.loads(body)["turns"]["total"] == 1
        code, body = _request(dash.port, "GET", "/api/dash/status", host)
        st = json.loads(body)
        assert st["bot"]["state"] == "offline" and world.path.stem in st["stamp"]
        assert _request(dash.port, "POST", "/api/dash/hello", host, {})[0] == 403                # no key, no buttons
        assert _request(dash.port, "POST", "/api/dash/hello", {**host, "X-RP-Key": "nope"}, {})[0] == 403
        assert _request(dash.port, "POST", "/api/dash/hello", {**host, "X-RP-Key": dash.key}, {})[0] == 200
        assert dash.last_hello is not None
        code, body = _request(dash.port, "GET", f"/api/graph?c={world.path.stem}", host)     # the graph browser
        assert code == 200 and json.loads(body)["nodes"]
        assert _request(dash.port, "GET", "/graph", host)[0] == 200
        assert _request(dash.port, "GET", "/static/../server.py", host)[0] == 404
        code, body = _request(dash.port, "POST", "/api/dash/prefs", {**host, "X-RP-Key": dash.key},
                              {"autostart_bot": True, "evil": 1})
        assert json.loads(body) == {"autostart_bot": True, "announce": False}
    finally:
        dash.shutdown()


def test_a_refused_post_leaves_the_connection_clean(world, tmp_path):
    """A page with a stale key gets a 403 - and the next request on the same kept-alive connection still works."""
    dash = server.Dashboard(0, "serve", tmp_path)
    dash.start()
    try:
        c = http.client.HTTPConnection("127.0.0.1", dash.port, timeout=10)
        host = {"Host": f"127.0.0.1:{dash.port}", "Content-Type": "application/json"}
        c.request("POST", "/api/dash/hello", body=json.dumps({"some": "body"}), headers={**host, "X-RP-Key": "old"})
        r = c.getresponse()
        assert r.status == 403 and json.loads(r.read())["reload"]
        c.request("GET", "/static/app.js", headers=host)
        r = c.getresponse()
        assert r.status == 200 and b"RoleplayEngine dashboard" in r.read()
        c.close()
    finally:
        dash.shutdown()


class Window:
    """Stands in for the Edge app window's process."""

    def __init__(self):
        self.code = None

    def poll(self):
        return self.code


def test_the_window_decides_when_the_dashboard_stops(tmp_path, monkeypatch):
    shown = {"open": True}
    monkeypatch.setattr(server.app_window, "app_window_open", lambda: shown["open"])
    dash = server.Dashboard(0, "window", tmp_path)
    dash.httpd.server_close()
    t0 = dash.started
    # minimized for an hour, or the PC asleep overnight: no hellos at all, and the dashboard stays - this used to be
    # the bug (a hidden page's timers wake about once a minute, and 25 quiet seconds shut the server down)
    assert dash.should_close(t0 + 3600) is None and dash.should_close(t0 + 12 * 3600) is None
    shown["open"] = False                                # the last window closes...
    assert dash.should_close(t0 + 3600) is None          # ...a few seconds' grace (a reload, another tab)...
    assert dash.should_close(t0 + 3600 + server.WINDOW_GRACE + 1) == "the window closed"
    dash.last_hello = t0 + 3600 + server.WINDOW_GRACE      # ...unless something is still checking in
    assert dash.should_close(t0 + 3600 + server.WINDOW_GRACE + 2) is None
    fresh = server.Dashboard(0, "window", tmp_path)       # just launched: the window gets a minute to appear
    fresh.httpd.server_close()
    assert fresh.should_close(fresh.started + 30) is None

    monkeypatch.setattr(server.app_window, "app_window_open", lambda: None)     # (not Windows: watch the process)
    elsewhere = server.Dashboard(0, "window", tmp_path)
    elsewhere.httpd.server_close()
    elsewhere.window = Window()
    assert elsewhere.should_close(elsewhere.started + 3600) is None
    elsewhere.window.code = 0
    assert elsewhere.should_close(elsewhere.started + 3600) is None
    assert elsewhere.should_close(elsewhere.started + 3600 + server.WINDOW_GRACE + 1) == "the window closed"

    tab = server.Dashboard(0, "browser", tmp_path)        # a plain tab: hellos (once a minute when hidden)
    tab.httpd.server_close()
    t1 = tab.started
    tab.last_hello = t1 + 300
    assert tab.should_close(t1 + 800) is None            # a hidden tab, quiet for minutes: still there
    assert tab.should_close(t1 + 300 + server.TAB_SILENCE + 1).startswith("no page has checked in")
    tab.bye_at = t1 + 310                                # it said goodbye...
    assert tab.should_close(t1 + 320) is None and tab.should_close(t1 + 331) == "the page said goodbye"
    tab.last_hello = t1 + 311                            # ...or it was a reload, which says hello again at once
    assert tab.should_close(t1 + 331) is None
    tab.mode = "serve"
    assert tab.should_close(t1 + 10 ** 6) is None         # --serve stays up until Ctrl+C


def test_shutdown_tidies_up_before_it_lets_go(tmp_path):
    dash = server.Dashboard(0, "window", tmp_path)
    dash.start()
    dash.window = Window()                               # (already closed: nothing to terminate)
    dash.window.code = 0
    instance = tmp_path / ".run" / server.INSTANCE
    assert instance.exists()
    dash.shutdown("the window closed")
    assert dash.stopped.is_set() and not instance.exists()      # the instance file is gone before the exit signal
    assert "stopping: the window closed" in (tmp_path / ".run" / "dashboard.log").read_text()     # (and why)


def test_the_bot_log_tails_and_follows(tmp_path, monkeypatch):
    log = tmp_path / "discord_bot.log"
    monkeypatch.setattr(botctl, "LOG", log)
    assert botctl.log_since(None) == {"offset": 0, "text": "", "reset": True}
    log.write_bytes(b"line one\nline two\n")
    first = botctl.log_since(None)
    assert first["text"] == "line one\nline two\n" and first["reset"]
    with open(log, "ab") as f:
        f.write(b"[runtime] stop requested\n")
    nxt = botctl.log_since(first["offset"])
    assert nxt["text"] == "[runtime] stop requested\n" and not nxt["reset"]
    log.write_bytes(b"rotated\n")         # shorter than the last offset: start over
    assert botctl.log_since(nxt["offset"])["reset"]


def test_the_bot_reads_offline_without_its_lock_and_starting_with_it(tmp_path, monkeypatch):
    monkeypatch.setattr(runtime, "RUN_DIR", tmp_path)
    runtime.write_json(tmp_path / runtime.STATUS, {"pid": 1, "state": "online", "started": 100, "beat": 200, "code": 0})
    assert botctl.status()["state"] == "offline" and botctl.status()["last"]["state"] == "online"
    lock = runtime.InstanceLock(tmp_path)
    assert lock.acquire()
    try:
        runtime.write_json(tmp_path / botctl.SPAWN, {"pid": 2, "at": 1000})       # we just started a new one
        assert botctl.status()["state"] == "starting"                          # (the heartbeat is the old run's)
        import time
        runtime.write_json(tmp_path / runtime.STATUS, {"pid": 2, "state": "online", "started": 1001,
                                                       "beat": time.time(), "code": 1e12})
        s = botctl.status()
        assert s["state"] == "online" and s["pid"] == 2 and not s["code_changed"]
        with pytest.raises(botctl.BotError):
            botctl.start()
    finally:
        lock.release()


def test_jobs_show_as_the_current_run(world):
    j = jobs.current(world.conn)
    assert j["status"] == "active" and j["client_id"] == "kaz"
    assert spend.campaign_total(world.path.parent, world.path.stem) == 0.0       # (a FakeLLM spends nothing)


def test_the_atlas_puts_the_story_on_the_map(world, tmp_path):
    from roleplay.dashboard import atlas
    from roleplay.engine import coast
    name = world.path.stem
    world.introduce("location", "Renraku Black Site", "somewhere in Redmond", turn=1)      # nobody's been there
    a = atlas.atlas(name, tmp_path)
    places = {p["name"]: p for p in a["places"]}
    bar = next(p for p in a["places"] if p["current"])
    assert bar["visited"] and bar["scenes"] and not bar["gm"]
    assert places["Renraku Black Site"]["gm"] and not places["Renraku Black Site"]["visited"]   # GM eyes only
    assert all(not coast.in_water(p["lat"], p["lon"]) for p in a["places"])
    razor = next(p for p in a["party"] if p["id"] == "razor")
    assert razor["place"] == bar["id"] and razor["player"] == "Mo" and (razor["lat"], razor["lon"]) == (bar["lat"], bar["lon"])
    assert a["trail"] and a["trail"][-1]["place"] == bar["id"]
    assert {d["name"] for d in a["districts"]} >= {"Downtown", "Tacoma"} and a["base"]["url"] == "/api/dash/atlas-base"
    img, bounds = atlas.base_image(tmp_path)
    assert img.exists() and bounds["north"] > bounds["south"]
    assert atlas.base_image(tmp_path)[0] == img                                                 # cached


def test_the_atlas_is_served(world, tmp_path):
    dash = server.Dashboard(0, "serve", tmp_path)
    dash.start()
    try:
        host = {"Host": f"127.0.0.1:{dash.port}"}
        code, body = _request(dash.port, "GET", f"/api/dash/atlas?c={world.path.stem}", host)
        assert code == 200 and json.loads(body)["places"]
        code, body = _request(dash.port, "GET", "/api/dash/atlas-base", host)
        assert code == 200 and body[:8] == b"\x89PNG\r\n\x1a\n"
    finally:
        dash.shutdown()


def test_a_fresh_launch_stops_the_old_server(world, tmp_path):
    """Opening the app restarts it: the old server (maybe days old - its new pages 404) is asked to quit with the key
    its own page carries. (Live: a server from Oct 16 answered the Canon and Flags pages with 'not found'.)"""
    from roleplay.dashboard.__main__ import stop_instance
    dash = server.Dashboard(0, "serve", tmp_path)
    dash.start()
    try:
        stop_instance({"port": dash.port, "pid": None}, wait=0)         # (pid None: nothing to end by force)
        assert dash.stopped.wait(5)
    finally:
        dash.shutdown()


def test_the_page_knows_when_the_engine_is_newer(world, tmp_path, monkeypatch):
    dash = server.Dashboard(0, "serve", tmp_path)
    assert not dash.stale()
    monkeypatch.setattr(server, "code_stamp", lambda: dash.code + 60)   # someone changed the engine since
    dash._code_seen = (0.0, dash.code)
    assert dash.stale()
    dash.httpd.server_close()


def test_starting_the_bot_says_why_the_config_was_not_read(tmp_path, monkeypatch):
    """Review 2026-10-28: an unquoted token in config.toml (the commonest slip) got 'put discord_token in config.toml'
    from `RoleplayEngine.bat bot` and the Start button - the place it already was. The parse error comes first now."""
    from roleplay import keys
    monkeypatch.setattr(runtime, "RUN_DIR", tmp_path / ".run")
    for var in keys.ENV.values():
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("ROLEPLAY_CONFIG", str(tmp_path / "config.toml"))
    monkeypatch.setenv("ROLEPLAY_TOKEN_FILE", str(tmp_path / "Program.cs"))
    monkeypatch.setattr(keys, "_user_env", lambda var: None)
    (tmp_path / "config.toml").write_text("[keys]\ndiscord_token = unquoted-token\n", encoding="utf-8")
    with pytest.raises(botctl.BotError) as exc:
        botctl.start(check_strays=False)
    said = str(exc.value)
    assert said.startswith("No bot token found - config.toml isn't valid TOML") and "line 2" in said
    assert "put discord_token in config.toml" in said and "unquoted-token" not in said


def test_another_installs_bot_is_not_a_stray(tmp_path, monkeypatch):
    """Review 2026-10-28: on the machine the table plays on, the public copy's Start refused while the live install's
    bot ran - any python with roleplay.discord_bot on its command line was a stray. A python inside another copy of
    the project (and the base interpreter its venv launcher runs) is that copy's; one in this project, or a python
    belonging to no copy, still is."""
    from roleplay.config import ROOT
    other = tmp_path / "RoleplayEngine-main"
    (other / "roleplay" / "discord_bot").mkdir(parents=True)
    line = "python.exe -u -m roleplay.discord_bot"
    rows = [{"ProcessId": 11, "ParentProcessId": 1, "ExecutablePath": str(other / ".venv/Scripts/python.exe"),
             "CommandLine": line},
            {"ProcessId": 12, "ParentProcessId": 11, "ExecutablePath": r"C:\Python311\python.exe", "CommandLine": line},
            {"ProcessId": 21, "ParentProcessId": 1, "ExecutablePath": str(ROOT / ".venv/Scripts/python.exe"),
             "CommandLine": line},
            {"ProcessId": 31, "ParentProcessId": 1, "ExecutablePath": r"C:\Python311\python.exe", "CommandLine": line}]
    monkeypatch.setattr(botctl.sys, "platform", "win32")
    monkeypatch.setattr(botctl.subprocess, "CREATE_NO_WINDOW", 0, raising=False)
    monkeypatch.setattr(botctl.subprocess, "run", lambda *a, **kw: type("R", (), {"stdout": json.dumps(rows)})())
    monkeypatch.setattr(runtime, "RUN_DIR", tmp_path / ".run")
    assert [s["pid"] for s in botctl.stray_bots()] == [21, 31]


def test_opening_the_app_closes_only_its_own_old_windows(tmp_path, monkeypatch):
    """Review 2026-10-28: every window-mode launch sent WM_CLOSE to every window titled RoleplayEngine - opening the
    public copy closed the live install's dashboard. The old windows are closed only when there's an old server of
    this folder's to go with them."""
    from roleplay.dashboard import __main__ as app, window
    closed, opened = [], []

    class Dash:
        def __init__(self, port, mode):
            self.url, self.window = "http://127.0.0.1:1/", None

        def start(self):
            pass

        def wait(self):
            pass
    monkeypatch.setattr(app.server, "Dashboard", Dash)
    monkeypatch.setattr(app.runtime, "running", lambda folder=None: False)
    monkeypatch.setattr(window, "close_app_windows", lambda *a, **kw: closed.append(1) or 0)
    monkeypatch.setattr(window, "open_window", lambda url: opened.append(url))
    monkeypatch.setattr(app, "stop_instance", lambda info: None)
    monkeypatch.setattr(app, "running_instance", lambda: None)
    app.main([])
    assert opened and not closed                          # nothing of ours was running: another install's, maybe
    monkeypatch.setattr(app, "running_instance", lambda: {"port": 1, "pid": 2})
    app.main([])
    assert closed == [1]
