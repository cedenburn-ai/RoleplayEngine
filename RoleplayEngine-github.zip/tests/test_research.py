"""The GM's notebook (DESIGN.md §8d, 2026-10-26): read_turn, recall, search_memory, timeline - and the latitude to
use them (research steps don't spend the tool budget)."""
from roleplay.dm import research, world
from roleplay.dm.prompts import DM_SYSTEM
from roleplay.dm.tools import TOOLS, TurnContext, dispatch
from roleplay.dm.turn import _tool_label
from roleplay.engine.dice import ScriptedDice
from roleplay.setup import setup_demo
from roleplay.substrate.store import search_terms

from .conftest import FakeLLM, text, tool

COMMIT = {"summary": "Razor asked Kaz about the blue door.", "members": [{"id": "razor", "role": "actor"},
                                                                       {"id": "kaz", "role": "target"}],
          "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}}

DEAL = ("Kaz wipes the counter for a long time before he answers. The neon over the door buzzes and the jukebox "
        "with the bullet hole hums to itself. Rain ticks on the window. A drunk in the corner booth snores. "
        "Somewhere out back a dumpster lid bangs in the wind, and Kaz waits until it stops. "
        "**Kaz [kaz]:** \"Five hundred nuyen by Friday, and I tell you who's behind the blue door on Fifth. Not a "
        "word to Lone Star.\" He slides the glass across. Outside, a car alarm starts and stops. The night drags on "
        "and nobody else comes in for an hour, and the ork keeps his eyes on the street the whole time. What do you "
        "say, Razor?")


class LoopLLM(FakeLLM):
    """Records every message list the GM's loop sends."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.calls = []

    def dm_step(self, system, tools, messages, progress=None):
        self.calls.append([m for m in messages])
        return super().dm_step(system, tools, messages, progress)


def _engine_notes(llm) -> list[str]:
    """Every '(Engine: ...)' text the loop added to tool results."""
    out = []
    for m in llm.calls[-1]:
        if m["role"] == "user" and isinstance(m["content"], list):
            out += [b["text"] for b in m["content"] if isinstance(b, dict) and b.get("type") == "text"]
    return out


def _demo(make_game, llm=None):
    g = make_game(llm=llm or FakeLLM(extraction=COMMIT), dice=ScriptedDice([5, 5, 5, 6] + [2] * 60))
    setup_demo(g)
    return g


def _ctx(g):
    return TurnContext(g, g.turn_no() + 1, g.current_scene_id())


def _played(make_game):
    """The demo plus one real turn: a roll, Razor's post, Kaz's terms in the narration."""
    llm = FakeLLM([([tool("request_test", actor_id="razor", skill="negotiation", threshold=2,
                          reason="get Kaz to name the buyer")], "tool_use"),
                   ([text(DEAL)], "end_turn")], COMMIT)
    g = _demo(make_game, llm)
    res = g.run_turn([("razor", "I promise Kaz the money by Friday if he names the buyer.")])
    return g, res.turn_id


# ── read_turn ───────────────────────────────────────────────────────────

def test_read_turn_gives_the_words_the_rolls_and_the_scene(make_game):
    """Live T150: the summaries had lost that Juno already had Bo; the turns had it word for word."""
    g, t = _played(make_game)
    ctx = _ctx(g)
    out = dispatch(ctx, "read_turn", {"turn_ids": [f"T{t}"]})
    assert f"=== T{t} · S3 Selling the chip" in out and "Day" in out             # the scene and story time
    assert "Razor [razor] posted: I promise Kaz the money by Friday if he names the buyer." in out
    assert "Five hundred nuyen by Friday, and I tell you who's behind the blue door on Fifth" in out   # verbatim
    roll = next(x for x in out.splitlines() if x.startswith("  - Razor: Negotiation (2) -> "))
    assert "Rolls:" in out and " hit" in roll and ("success" in roll or "failure" in roll) and "(net " in roll
    assert "get Kaz to name the buyer" in out
    assert f"Summary: {COMMIT['summary']}" in out
    assert f"T{t}" in ctx.expanded                                       # opened by id: it gets the retrieval touch
    assert dispatch(ctx, "read_turn", {"turn_ids": [str(t)]}) == out    # a bare number reads the same turn


def test_read_turn_around_a_phrase_returns_the_passage(make_game):
    g, t = _played(make_game)
    out = dispatch(_ctx(g), "read_turn", {"turn_ids": [f"T{t}"], "around": "blue door"})
    assert "Narration around \"blue door\" (1 passage" in out
    assert "the blue door on Fifth" in out
    assert "Narration (verbatim)" not in out and "wipes the counter for a long time" not in out   # not the whole turn
    assert "Razor [razor] posted:" in out                                # the posts still come whole
    missing = dispatch(_ctx(g), "read_turn", {"turn_ids": [f"T{t}"], "around": "Ares Predator"})
    assert "nothing like \"Ares Predator\" in this turn's narration" in missing


def test_read_turn_ranges_caps_and_odd_ids(make_game):
    g, t = _played(make_game)
    out = dispatch(_ctx(g), "read_turn", {"turn_ids": ["T1-T3", "nonsense", "T999", f"T{t + 1}"]})
    assert "=== T1 · S1 Bar fight at the Lucky Shot" in out and "=== T3 · S2" in out
    assert "(seeded history - no narration on file)" in out
    assert "couldn't read nonsense" in out
    assert "[T999] no such turn on file" in out
    assert f"[T{t + 1}] is this turn" in out
    capped = dispatch(_ctx(g), "read_turn", {"turn_ids": ["T1-T9"]})
    assert f"reads {research.READ_MAX} turns a call - left out: T7, T8, T9" in capped
    assert research.turn_refs(["T150", "151", "t152", "T148-T150", "148..149", "W617", "T1, T2"]) == (
        ["T150", "T151", "T152", "T148", "T149", "W617", "T1", "T2"], [])
    assert research.turn_refs("T10-T8") == (["T8", "T9", "T10"], [])


def test_read_turn_tags_a_whisper(make_game):
    llm = FakeLLM([([text("You palm the keycard. Nobody looks up.")], "end_turn")],
                  dict(COMMIT, members=[{"id": "razor", "role": "actor"}]))
    g = _demo(make_game, llm)
    t = g.run_turn([("razor", "I palm Kaz's keycard.")], private="razor").turn_id
    out = dispatch(_ctx(g), "read_turn", {"turn_ids": [f"T{t}"]})
    assert "(WHISPER from Razor - private: only they and whoever noticed know it)" in out
    assert "You palm the keycard." in out


def test_read_turn_reads_an_offscreen_moment(make_game):
    g = _demo(make_game)
    S = g.sub
    wid = S.write_offscreen(3, "Kaz called Tanaka and asked what a Renraku chip fetches these days.",
                            [("kaz", "actor"), ("tanaka", "target")], story_time=g.clock())
    S.add_knows("joey-two-knives", wid, "told", "kaz", 3)
    out = dispatch(_ctx(g), "read_turn", {"turn_ids": [wid]})
    assert f"=== {wid} · offscreen, no PC saw it · after T3" in out
    assert "Who: Kaz (actor), Tanaka (target)" in out
    assert "asked what a Renraku chip fetches" in out
    assert "Heard of it second-hand since: Joey Two-Knives (T3, told by Kaz)" in out


# ── recall ──────────────────────────────────────────────────────────────

def test_recall_marks_supersession_both_ways(make_game):
    g = _demo(make_game)
    S = g.sub
    old = S.add_fact("Kaz charges Razor nothing for drinks.", ["kaz", "razor"], 3)
    new = S.add_fact("Kaz charges Razor double since the jukebox.", ["kaz", "razor"], 3, replaces=old)
    newest = S.add_fact("Kaz and Razor are square again; drinks are on the house.", ["kaz", "razor"], 4,
                        replaces=new)
    ctx = _ctx(g)
    out = dispatch(ctx, "recall", {"ids": [old]})
    assert f"SUPERSEDED by [{new}], since by [{newest}] (T4) - that's the current version: Kaz and Razor are square" \
        in out
    mid = dispatch(ctx, "recall", {"ids": [new]})
    assert f"SUPERSEDED by [{newest}]" in mid and f"Replaces [{old}] (T3): Kaz charges Razor nothing" in mid
    assert "about Kaz, Razor" in mid
    top = dispatch(ctx, "recall", {"ids": [newest]})
    assert "\n  SUPERSEDED by" not in top and f"Replaces [{new}]" in top
    linked = next(x for x in top.splitlines() if x.startswith(f"  Linked: [{new}]"))
    assert linked.endswith(f"(SUPERSEDED by [{newest}] - that's the current version)")   # linked history, marked


def test_recall_shows_a_persons_mind(make_game):
    """Live: recalling an NPC returned their sheet and none of their mind."""
    g = _demo(make_game)
    L, S = g.ledger, g.sub
    S.add_belief("kaz", "razor", "Kaz thinks Razor is trouble for the bar.", 3)
    b2 = S.add_belief("kaz", "razor", "Kaz thinks Razor is the only one keeping the Ancients off his back.", 4)
    L.set_stat("kaz", "attitude:razor", 2)
    L.set_stat("kaz", "attitude:ghost", -1)
    aid = world.add_agenda(g, "kaz", "Make rent before Lone Star comes calling", ["razor"], 4, "test")
    S.add_knows("kaz", "T3", "told", "ghost", 4)                         # the courier job Kaz never saw
    out = dispatch(_ctx(g), "recall", {"ids": ["kaz"]})
    assert "Mind - what they think of people now" in out
    assert f"Razor [razor] +2 ([{b2}], since T4): Kaz thinks Razor is the only one keeping" in out
    assert "Kaz thinks Razor is trouble for the bar" not in out          # superseded: history, not his mind
    assert "Ghost [ghost] -1 (no view on file)" in out
    assert f"Goals (active): [{aid}] Make rent before Lone Star comes calling" in out
    assert "Heard lately" in out and "[T3] (T4, told by Ghost) Razor and Ghost ambushed a Renraku courier" in out
    assert "Where: here, in this scene" in out
    assert "Lone Star when rent is short" in out                         # his DM note still rides along
    razor = dispatch(_ctx(g), "recall", {"ids": ["Razor"]})
    assert "Toward them: Kaz +2" in razor


def test_recall_ranks_linked_memories_by_strength_then_recency(make_game):
    """The old cut took the six strongest links of any kind and then kept only memories: a hub of strong
    person-to-person links came back with none."""
    g = _demo(make_game)
    S = g.sub
    for i in range(8):                                                   # eight strong ties to other people
        eid = g.introduce("npc", f"Regular {i}", "a Lucky Shot regular", turn=3)[0]
        S.ensure_entity(g.ledger.get(eid), 3)
        S.link("kaz", eid, "assoc", 9.0, 3)
    out = dispatch(_ctx(g), "recall", {"ids": ["kaz"]})
    linked = [line for line in out.splitlines() if line.startswith("  Linked: ")]
    assert linked and linked[0].startswith("  Linked: [T2]") and linked[1].startswith("  Linked: [T1]")
    assert any("Kaz owes Razor a favor" in line for line in linked)       # the facts come after the turns
    assert len(linked) <= research.LINKED


def test_recall_of_a_turn_points_at_its_words(make_game):
    g, t = _played(make_game)
    out = dispatch(_ctx(g), "recall", {"ids": [f"T{t}", "S1", "nobody-at-all"]})
    assert f"(read_turn T{t} for what was said, word for word)" in out
    assert "Turns: T1-T2 (2 on file)" in out
    assert "[nobody-at-all] unknown id" in out


# ── search_memory ───────────────────────────────────────────────────────

def test_search_keeps_short_names_and_matches_whole_words(make_game):
    """Live: 'Bo' - the boy the whole storyline turned on - was too short to search for, and a substring would find
    him in 'about' and 'boat'."""
    g = _demo(make_game)
    S = g.sub
    bo = g.introduce("npc", "Bo", "a quiet ork kid with his mother's eyes", turn=3)[0]
    S.ensure_entity(g.ledger.get(bo), 3)
    fid = S.add_fact("Bo stays with his mother; nobody signs his transport.", [bo], 3)
    noise = S.add_fact("The bouncer talked about the boat for an hour.", ["kaz"], 3)
    assert search_terms("Is Bo safe?") == ["bo", "safe"]                 # 'Is' is a word, 'Bo' a name
    assert search_terms("is bo safe") == ["safe"]                        # lowercase 'bo' isn't one
    assert search_terms("Juno's deal with KD-4 and F45") == ["juno", "deal", "kd", "f45"]
    assert search_terms("the 2,410 loan") == ["2,410", "loan"]           # a sum is one word
    out = dispatch(_ctx(g), "search_memory", {"query": "Bo"})
    assert f"[{fid}]" in out and f"[{bo}]" in out
    assert f"[{noise}]" not in out


def test_search_ranks_every_word_first_and_marks_superseded(make_game):
    g = _demo(make_game)
    S = g.sub
    one = S.add_fact("Tanaka pays fair for anything corporate.", ["tanaka"], 3)
    both = S.add_fact("Tanaka pays double for Renraku prototypes.", ["tanaka"], 3)
    for _ in range(4):
        S.touch([one], 3)                                                # hotter - and still second
    old = S.add_fact("The Renraku chip is worth 5,000 to Tanaka.", ["tanaka"], 3)
    new = S.add_fact("The Renraku chip is worth 14,000 to Tanaka now.", ["tanaka"], 4, replaces=old)
    out = dispatch(_ctx(g), "search_memory", {"query": "Tanaka Renraku"})
    lines = out.splitlines()
    assert lines[0] == "(words: tanaka, renraku)"
    ids = [line.split("]")[0].lstrip("[") for line in lines[1:]]
    assert ids.index(both) < ids.index(one) and ids.index(new) < ids.index(old)
    assert f"[{old}] (fact, T3) The Renraku chip is worth 5,000 to Tanaka.  (SUPERSEDED by [{new}] - that's the " \
           "current version)" in out


def test_search_snippets_sit_around_the_words(make_game):
    g = _demo(make_game)
    long = ("Kaz keeps a ledger. " * 30) + "The spare maglock keycard is taped under the third stool."
    nid = g.sub.add_note(["kaz"], long, 3)
    out = dispatch(_ctx(g), "search_memory", {"query": "maglock keycard", "kinds": ["note"]})
    line = next(x for x in out.splitlines() if x.startswith(f"[{nid}]"))
    assert "(note on Kaz, T3) ..." in line and "taped under the third stool" in line
    assert len(line) < 400
    assert research.snippet("short text", ["text"]) == "short text"


def test_search_filters_by_who_kind_and_turn(make_game):
    g = _demo(make_game)
    S = g.sub
    late = S.add_fact("Kaz and Razor drank to the Ancients' ban.", ["kaz", "razor"], 9)
    ctx = _ctx(g)
    both = dispatch(ctx, "search_memory", {"query": "Kaz", "about": ["kaz", "Razor"]})
    assert "(words: kaz; involving all of Kaz, Razor)" in both
    assert "[T2]" in both and "Kaz owes Razor a favor" in both and f"[{late}]" in both
    assert "Kaz knows Tanaka the fence" not in both                     # about Kaz and Tanaka, not Razor
    facts = dispatch(ctx, "search_memory", {"query": "Kaz", "about": ["kaz", "razor"], "kinds": ["fact", "bogus"]})
    assert "[T2]" not in facts and "Kaz owes Razor a favor" in facts
    assert "unknown kinds left out: bogus" in facts
    early = dispatch(ctx, "search_memory", {"query": "Kaz", "about": ["kaz", "razor"], "kinds": ["fact"],
                                            "to_turn": 5})
    assert "Kaz owes Razor a favor" in early and f"[{late}]" not in early
    assert "Nobody on file as Mr. Nobody" in dispatch(ctx, "search_memory", {"query": "x", "about": ["Mr. Nobody"]})
    listing = dispatch(ctx, "search_memory", {"query": "", "about": ["kaz", "razor"], "kinds": ["fact"]})
    assert listing.splitlines()[1].startswith(f"[{late}]")              # no words: what involves them, newest first
    assert "give it words" in dispatch(ctx, "search_memory", {"query": "a of"})
    assert "T1" in ctx.seen and "T1" not in ctx.expanded                # shown, not touched


def test_search_in_narration_finds_what_was_said(make_game):
    g, t = _played(make_game)
    ctx = _ctx(g)
    out = dispatch(ctx, "search_memory", {"query": "blue door", "in_narration": True})
    said = out.split("In what was said (your narration and the players' posts):")[1]
    assert f"[T{t}] (S3, Day" in said and "narration: \"" in said and "the blue door on Fifth" in said
    post = dispatch(ctx, "search_memory", {"query": "Friday names", "in_narration": True})
    assert "Razor [razor]'s post: \"I promise Kaz the money by Friday if he names the buyer.\"" in post
    plain = dispatch(ctx, "search_memory", {"query": "Fifth"})
    assert "in_narration: true also searches what was actually said" in plain   # (the summary never said it)
    assert f"T{t}" in ctx.seen


# ── timeline ────────────────────────────────────────────────────────────

def test_timeline_lists_what_happened_between_people(make_game):
    g = _demo(make_game)
    ctx = _ctx(g)
    out = dispatch(ctx, "timeline", {"ids": ["kaz", "Razor"]})
    lines = out.splitlines()
    assert lines[0] == "Kaz & Razor: 2 moments on file, oldest first:"
    assert lines[1].startswith("[T1] (S1, ") and "(Kaz: target, Razor: present)" in lines[1]
    assert lines[2].startswith("[T2] (S1, ") and "threw him through the jukebox" in lines[2]
    last = dispatch(ctx, "timeline", {"ids": ["kaz", "razor"], "limit": 1})
    assert "2 moments on file - the last 1, oldest first" in last and "[T2]" in last and "[T1]" not in last
    assert "Nothing on file involving Kaz & Ghost." == dispatch(ctx, "timeline", {"ids": ["kaz", "ghost"]})
    early = dispatch(ctx, "timeline", {"ids": ["razor"], "to_turn": 1})
    assert "in T1-T1" in early and "[T1]" in early and "[T3]" not in early
    assert "Whose timeline?" in dispatch(ctx, "timeline", {"ids": ["Mr. Nobody"]})
    assert {"T1", "T2"} <= set(ctx.seen)


# ── latitude: research doesn't spend the tool budget ────────────────────

def test_research_steps_do_not_spend_the_tool_budget(make_game):
    """Live, 188 turns used recall in 6: each lookup cost one of the 8 steps the turn's rolls needed."""
    script = [([tool("recall", ids=["kaz"])], "tool_use"),
              ([tool("timeline", ids=["kaz", "razor"]), tool("search_memory", query="jukebox")], "tool_use"),
              ([tool("read_turn", turn_ids=["T2"])], "tool_use"),
              ([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="press Kaz")],
               "tool_use"),
              ([text("Kaz shrugs. \"Ask me tomorrow.\"")], "end_turn")]
    llm = LoopLLM(script, COMMIT)
    g = _demo(make_game, llm)
    g.settings.models.dm_max_steps = 2                                  # two steps: research would have eaten them
    res = g.run_turn([("razor", "Kaz, who's buying?")])
    assert res.narration.startswith("Kaz shrugs.")
    assert res.cards and "Negotiation" in res.cards[0]
    assert not any("tool budget for this turn is spent" in n for n in _engine_notes(llm))
    metrics = g.conn.execute("SELECT dm_steps, tools FROM turn_metrics WHERE turn=?", (res.turn_id,)).fetchone()
    assert metrics["dm_steps"] == 5 and "read_turn" in metrics["tools"]


def test_the_research_allowance_runs_out_then_lookups_count(make_game):
    script = [([tool("recall", ids=["kaz"])], "tool_use") for _ in range(4)] + [([text("Done.")], "end_turn")]
    llm = LoopLLM(script, COMMIT)
    g = _demo(make_game, llm)
    g.settings.models.dm_research_steps = 2
    g.settings.models.dm_max_steps = 2
    assert g.run_turn([("razor", "Kaz?")]).narration == "Done."
    notes = _engine_notes(llm)
    assert any("that was the last free research step this turn" in n and "(2 left)" in n for n in notes)
    assert any("tool budget for this turn is spent" in n for n in notes)  # lookups 3 and 4 spent both steps


def test_a_step_that_also_acts_spends_the_budget(make_game):
    script = [([tool("recall", ids=["kaz"]), tool("request_test", actor_id="razor", skill="negotiation",
                                                 threshold=2, reason="press Kaz")], "tool_use"),
              ([text("Kaz talks.")], "end_turn")]
    llm = LoopLLM(script, COMMIT)
    g = _demo(make_game, llm)
    g.settings.models.dm_max_steps = 1
    assert g.run_turn([("razor", "Kaz?")]).narration == "Kaz talks."
    assert any("tool budget for this turn is spent" in n for n in _engine_notes(llm))


def test_research_calls_are_capped_per_turn(make_game):
    g = _demo(make_game)
    g.settings.models.dm_research_calls = 3
    ctx = _ctx(g)
    outs = [dispatch(ctx, "recall", {"ids": ["kaz"]}) for _ in range(4)]
    assert all("Kaz" in o for o in outs[:3])
    assert outs[3].startswith("Research budget for this turn is spent (3 lookups)")
    # review (2026-10-26): it said to leave a note - which comes back only with its target. A doubt stays listed.
    assert "raise it as a doubt" in outs[3] and "DOUBTS list" in outs[3] and "annotate" not in outs[3]
    assert dispatch(ctx, "timeline", {"ids": ["kaz"]}).startswith("Research budget")   # every lookup counts


def test_lookups_are_memory_pass_candidates_but_not_touches(make_game):
    """What a search showed the GM can be 'recalled' by the memory pass (the turn may draw on it); only what the
    turn used - or the GM opened by id - gets the retrieval touch (§8: touch what was used)."""
    seen = {}

    def extraction(user):
        if "KNOWN ENTITIES" in user:                                     # (the memory pass)
            seen.setdefault("prompt", user)
        return COMMIT

    script = [([tool("search_memory", query="noodle cart")], "tool_use"), ([text("Kaz nods.")], "end_turn")]
    g = _demo(make_game, FakeLLM(script, extraction))
    fid = g.sub.add_fact("Joey's sister runs a noodle cart in Redmond.", ["joey-two-knives"], 3)
    g.run_turn([("razor", "Kaz?")])
    memories = seen["prompt"].split("EARLIER MEMORIES THE GM COULD SEE")[1].split("FACTS ALREADY KNOWN")[0]
    assert f"[{fid}] Joey's sister runs a noodle cart" in memories
    ctx = _ctx(g)
    dispatch(ctx, "search_memory", {"query": "noodle cart"})
    assert fid in ctx.seen and fid not in ctx.expanded
    dispatch(ctx, "recall", {"ids": [fid]})
    assert fid in ctx.expanded
    for i in range(research.CANDIDATES + 5):
        ctx.seen[f"T{1000 + i}"] = None
    assert len(research.candidates(ctx)) == research.CANDIDATES and "T1000" not in research.candidates(ctx)


def test_a_hit_seen_again_is_the_newest_candidate(make_game):
    """Review (2026-10-26): ctx.seen kept a hit where it first went in, so one the GM looked at early and again on its
    last lookup - when the narration is likeliest to draw on it - fell out of the newest CANDIDATES."""
    g = _demo(make_game)
    ctx = _ctx(g)
    dispatch(ctx, "timeline", {"ids": ["kaz", "razor"]})                 # T1, T2
    for i in range(research.CANDIDATES):
        ctx.seen[f"F{900 + i}"] = None
    dispatch(ctx, "timeline", {"ids": ["kaz", "razor"]})                 # the same two, last of all
    assert {"T1", "T2"} <= research.candidates(ctx) and list(ctx.seen)[-2:] == ["T1", "T2"]
    for i in range(research.CANDIDATES):
        ctx.seen[f"F{2000 + i}"] = None
    assert "T2" not in research.candidates(ctx)
    dispatch(ctx, "search_memory", {"query": "jukebox"})                 # (a search hit moves up the same way)
    assert "T2" in research.candidates(ctx)


def test_a_huge_turn_number_is_unreadable_not_a_lost_turn(make_game):
    """Review (2026-10-26): a twenty-digit turn number bound into SQLite raised OverflowError - not caught by run_tool -
    and run_turn undid the whole turn over one bad lookup argument."""
    from roleplay.dm import witness
    from roleplay.dm.tools import run_tool
    huge = "T99999999999999999999"
    assert research.turn_refs([huge, "T1-T99999999999999999999", str(2 ** 63)]) == (
        [], [huge, "T1-T99999999999999999999", str(2 ** 63)])
    assert research._int(10 ** 20) == research.TURN_MAX and research._int(f"T-{10 ** 20}") == -research.TURN_MAX
    g = _demo(make_game)
    ctx = _ctx(g)
    for name, args in [("read_turn", {"turn_ids": [huge]}), ("search_memory", {"query": "Kaz", "from_turn": huge}),
                       ("search_memory", {"query": "Kaz", "to_turn": 10 ** 20, "in_narration": True}),
                       ("timeline", {"ids": ["kaz"], "to_turn": 10 ** 20})]:
        res = run_tool(ctx, tool(name, **args))
        assert not res.get("is_error"), (name, res["content"])
    assert "Couldn't read: T99999999999999999999" in run_tool(ctx, tool("read_turn", turn_ids=[huge]))["content"]
    sc = witness.Scope(g, "razor")
    for name, args in [("read_turn", {"turn_ids": [huge]}), ("timeline", {"ids": ["kaz"], "from_turn": huge}),
                       ("search_memory", {"query": "Kaz", "to_turn": 10 ** 20})]:
        assert not witness.tool_result(sc, tool(name, **args)).get("is_error"), name
    llm = FakeLLM([([tool("read_turn", turn_ids=[huge])], "tool_use"), ([text("Kaz shrugs.")], "end_turn")], COMMIT)
    g2 = _demo(make_game, llm)
    t = g2.turn_no()
    assert g2.run_turn([("razor", "What happened at T99999999999999999999?")]).narration == "Kaz shrugs."
    assert g2.turn_no() == t + 1                                          # the turn stands


def test_short_words_find_their_plurals_and_still_not_inside_others(make_game):
    """Review (2026-10-26): the whole-word rule for short words (so 'Bo' isn't in 'about') cost every three-letter
    word its plural - 'ork' missed 'orks', 'cop' 'cops' - which the old substring search had found."""
    from roleplay.substrate.store import term_re
    for term, text_ in [("ork", "Two orks at the door"), ("cop", "The cops showed up"), ("gun", "guns drawn"),
                        ("box", "three boxes of ammo"), ("bo", "Bo's inhaler"), ("job", "two jobs")]:
        assert term_re(term).search(text_), term
    for term, text_ in [("bo", "a boring night"), ("bo", "talked about it"), ("bo", "the boss"), ("ork", "a fork"),
                        ("f4", "F45 says"), ("f4", "F4s")]:
        assert not term_re(term).search(text_), (term, text_)
    g = _demo(make_game)
    orks = g.sub.add_fact("Two orks were waiting at the door of the Lucky Shot.", ["kaz"], 3)
    cops = g.sub.add_fact("The cops showed up at the docks after midnight.", ["kaz"], 3)
    assert f"[{orks}]" in dispatch(_ctx(g), "search_memory", {"query": "ork"})
    assert f"[{cops}]" in dispatch(_ctx(g), "search_memory", {"query": "cop"})
    assert [t for _, _, t in research._spans("Later, two orks walked in.", "two ork")] == [""]   # (the phrase)


# ── what the GM is told ─────────────────────────────────────────────────

def test_the_gm_is_told_to_look_it_up(make_game):
    g = _demo(make_game)
    assert "## Your notes: look it up" in DM_SYSTEM
    for name in ("read_turn", "timeline", "search_memory", "recall", "in_narration"):
        assert name in DM_SYSTEM.split("## Your notes: look it up")[1].split("## Rules")[0]
    assert "never in the narration" in DM_SYSTEM
    tools = {t["name"]: t for t in TOOLS}
    assert set(research.RESEARCH) <= set(tools)
    assert set(tools["search_memory"]["input_schema"]["properties"]) == {
        "query", "about", "kinds", "from_turn", "to_turn", "in_narration", "limit"}
    assert tools["read_turn"]["input_schema"]["required"] == ["turn_ids"]
    assert _tool_label(g, tool("read_turn", turn_ids=["T2"])) == "📚 checking the record"
    assert _tool_label(g, tool("timeline", ids=["kaz"])) == "📚 checking the record"
