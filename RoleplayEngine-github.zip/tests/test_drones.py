"""Drones lent, rigged and crashed (DESIGN.md §7a, 2026-10-24). Live T188 (flags #67-#69): the crew bought a Doberman
and a Steel Lynx for Filament to run, and control_drone told the GM to hack them; his Fly-Spy, left under his remote
control in a scene the story had left, took 2 dice off every drone he drove; and riders hit Magic's barrier for
whatever damage the GM picked (T164: 10P, 8P, 9P where the book's crash is the bike's Body, 5)."""
import pytest

from roleplay import encounters
from roleplay.dm.tools import TurnContext, _rollers, dispatch, run_tool
from roleplay.dm.turn import hands_off, posted
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError, RulesRefusal
from roleplay.engine.rules import machines, magic, sr_lite
from roleplay.setup import setup_demo

from .conftest import tool


def _dog(g, owner="razor", name="Razor's Doberman", model="doberman"):
    return g.introduce("drone", name, "", owner_id=owner, model=model, present=True, turn=1)[0]


def _seat(g, handle, afk=0):
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES(?, ?, ?, ?)",
                   (f"id-{handle}", handle, handle.title(), afk))


def _ctx(g, *posters):
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx.posted = posted(g, [(h, "...") for h in posters])
    return ctx


def _barrier(g, caster, hits=4):
    """A held Physical Barrier with the book's numbers (magic.cast stores the same entry)."""
    _walls(g, caster, (hits, caster))


def _walls(g, caster, *walls):
    """Held Physical Barriers, one per (hits, who it's on), in that order - each its own wall."""
    ent = g.ledger.require(caster)
    held = [{"spell": "physical barrier", "target": on, "force": hits, "hits": hits, "armor": hits, "structure": hits}
            for hits, on in walls]
    g.ledger.update_entity(caster, props={**ent["props"], "sustained": held})
    g.ledger.set_stat(caster, "sustaining", len(held))


# ── lending: the owner hands over the keys ──────────────────────────────

def test_an_owner_hands_a_drone_to_a_crewmate(make_game):
    """T188's Doberman: Quiet Lou (a companion the GM plays) hands his dog to Filament. Razor stands in - a companion,
    so the GM speaks for him - and Ghost, whose player posted, drives it on his own Firearms 2 + Logic 6. (Until
    2026-10-24 Razor was left parked, and a parked PC counted as the GM's word; it's hands-off now, _their_word.)"""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    g.set_control("razor", "gm")
    dog = _dog(g)
    with pytest.raises(RulesRefusal, match="Win an opposed Hacking test.*owner_hands_over: true"):
        dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost"})
    card = dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost",
                                                        "owner_hands_over": True})
    assert card.splitlines()[0] == ("[GEAR] Razor's Doberman: Ghost takes the controls (remote control) (Razor hands "
                                    "over the keys)")
    p = L.get(dog)["props"]
    assert p["owner"] == "razor" and p["delegates"] == ["ghost"] and p["controller"] == "ghost"
    assert sr_lite.build_pool(L, dog, "firearms")[0] == 8
    assert any(e["kind"] == "grant" for e in L.events(g.turn_no() + 1))
    assert "keys: Ghost" in sr_lite.sheet(L, dog)                            # the GM sees who holds the keys
    assert "Driving: Razor's Doberman [razor-s-doberman] (remote)" in sr_lite.sheet(L, "ghost")
    # the keys stand: back on its own Pilot, Ghost takes it again a turn later with no handover
    dispatch(_ctx(g), "control_drone", {"drone_id": dog, "controller_id": "autonomous"})
    assert L.get(dog)["props"]["delegates"] == ["ghost"]
    assert "Keys to: Razor's Doberman" in sr_lite.sheet(L, "ghost")
    dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost"})
    # ...until the owner takes the controls back
    card = dispatch(_ctx(g), "control_drone", {"drone_id": dog, "controller_id": "razor"})
    assert "(the keys come back from Ghost)" in card.splitlines()[0] and L.get(dog)["props"]["delegates"] == []
    with pytest.raises(RulesRefusal, match="no control"):
        dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost"})


def test_a_quiet_players_drone_isnt_handed_over_for_them(make_game):
    """T188's Lynx: only Filament had posted, and the GM gave Magic's drone away. A player's character lends only on
    their player's word this turn - wherever they are, in the scene or not. A companion the GM plays lends on its."""
    g = make_game()
    setup_demo(g)
    _seat(g, "razor")
    _seat(g, "ghost")
    dog = _dog(g)
    hands = {"drone_id": dog, "controller_id": "ghost", "owner_hands_over": True}
    with pytest.raises(RulesRefusal, match="Razor's player hasn't handed Razor's Doberman over"):
        dispatch(_ctx(g, "ghost"), "control_drone", hands)
    g.leave_scene(["razor"])                                                 # (off screen is no way round it)
    with pytest.raises(RulesRefusal, match="Razor's player hasn't handed"):
        dispatch(_ctx(g, "ghost"), "control_drone", hands)
    g.conn.execute("UPDATE players SET afk=1 WHERE handle='razor'")          # away, and the GM plays the companions
    g.set_companions(True)
    assert "Razor hands over the keys" in dispatch(_ctx(g, "ghost"), "control_drone", hands)


def test_t188_replayed(make_game, tmp_path):
    """The turn as it went live: only Filament's player posts, the GM hands him the companion's Doberman and the quiet
    player's Lynx. The dog changes hands; the Lynx comes back 'Refused' - no engine flag filed - and stays Magic's."""
    from roleplay import flags
    from .conftest import FakeLLM, text, tool
    commit = {"summary": "The crew readies the drones.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "ghost", "role": "actor"}]}
    llm = FakeLLM([([tool("control_drone", drone_id="razor-s-doberman", controller_id="ghost", owner_hands_over=True),
                     tool("control_drone", drone_id="tanaka-s-steel-lynx", controller_id="ghost",
                          owner_hands_over=True)], "tool_use"),
                   ([text("Ghost takes the dog's feed; the Lynx's key plate stays dark.")], "end_turn")], commit)
    g = make_game(llm)
    setup_demo(g)
    _seat(g, "ghost")
    g.set_control("razor", "gm")                                              # Razor plays Quiet Lou's part
    tanaka = g.create_pc("Tanaka Runner", "street_samurai", "tanaka-runner", "", 1)   # ...and this one Magic's
    _seat(g, "tanaka-runner")
    _dog(g)
    lynx = g.introduce("drone", "Tanaka's Steel Lynx", "", owner_id=tanaka, model="steel lynx", present=True,
                       turn=1)[0]
    assert lynx == "tanaka-s-steel-lynx"
    res = g.run_turn([("ghost", "My drones are all ready to go.")])
    assert any("Razor hands over the keys" in c for c in res.cards)
    assert g.ledger.get(lynx)["props"]["controller"] is None and not g.ledger.get(lynx)["props"].get("delegates")
    assert not any("control_drone" in f["text"] for f in flags.listing(tmp_path) if f["kind"] == "tool error")


def test_a_silent_player_gets_the_keys_not_the_controls(make_game):
    """The owner's word with the taker's player away: the keys change hands, the controls wait for the taker's own
    word - next turn, with no second handover, though the owner isn't there to say it again."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    _seat(g, "razor")
    _seat(g, "ghost")
    dog = _dog(g)
    card = dispatch(_ctx(g, "razor"), "control_drone", {"drone_id": dog, "controller_id": "ghost",
                                                         "owner_hands_over": True})
    assert card == ("[GEAR] Razor's Doberman: Razor lends Ghost the keys (they stand until Razor takes the controls "
                    "back) - Ghost takes the controls when their player says so")
    assert L.get(dog)["props"]["controller"] is None and L.get(dog)["props"]["delegates"] == ["ghost"]
    with pytest.raises(RulesRefusal, match="Ghost's player hasn't taken the controls"):
        dispatch(_ctx(g, "razor"), "control_drone", {"drone_id": dog, "controller_id": "ghost"})
    assert "Ghost takes the controls" in dispatch(_ctx(g, "ghost"), "control_drone", {
        "drone_id": dog, "controller_id": "ghost", "owner_hands_over": True})     # (a redundant flag is fine)


def test_npc_drones_change_hands_only_by_a_hack(make_game):
    """The verifiers' case A: with no fight on, 'Kaz hands over the keys' took his Security Doberman with no roll."""
    g = make_game()
    setup_demo(g)
    dog = _dog(g, "kaz", "Security Doberman")
    with pytest.raises(RulesRefusal, match="Kaz isn't one of the crew"):
        dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost",
                                                     "owner_hands_over": True})
    with pytest.raises(RulesRefusal, match="no control of Security Doberman - it answers to Kaz. Win an opposed "
                                           r"Hacking test against it this turn first\.$"):     # (no handover hint)
        dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": dog, "controller_id": "ghost"})
    stray = _dog(g, None, "Stray Doberman")
    with pytest.raises(RulesRefusal, match="no owner on file"):
        dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": stray, "controller_id": "ghost",
                                                     "owner_hands_over": True})


def test_lending_across_a_fight(make_game):
    """Mid-fight the owner lends nothing to the other side; a bystander (neutral) can still be lent one."""
    g = make_game()
    setup_demo(g)
    dog = _dog(g)
    encounters.start(g, 1, hostile=["joey-two-knives"])
    g.enter_scene(["joey-two-knives"], 1)
    with pytest.raises(RulesRefusal, match="other side of this fight"):
        dispatch(_ctx(g, "razor"), "control_drone", {"drone_id": dog, "controller_id": "joey-two-knives",
                                                     "owner_hands_over": True})
    assert "Razor hands over the keys" in dispatch(_ctx(g, "razor"), "control_drone", {
        "drone_id": dog, "controller_id": "kaz", "owner_hands_over": True})


def test_hijacked_knocked_out_and_jumped_in(make_game):
    """A hijacker blocks a handover and the keys alike; an owner who's out lends nothing; the one already driving
    changes mode with no new hack; and nobody takes a drone from under a jumped-in rigger without beating them."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    dog = _dog(g)
    machines.set_control(L, 1, dog, "ghost", handed_over=True)
    L.update_entity(dog, props={**L.get(dog)["props"], "controller": "kaz", "control": "remote"})   # (matrix.py's seizure)
    with pytest.raises(RulesRefusal, match="Kaz has hijacked Razor's Doberman"):
        machines.set_control(L, 2, dog, "ghost")
    with pytest.raises(RulesRefusal, match="Kaz has hijacked"):
        machines.set_control(L, 2, dog, "tanaka", handed_over=True)
    iid = L.create_entity("item", "Kaz's control rig", "", tier=0, props={"control_rig": 1}, turn=1)
    L.give("kaz", iid, 1)
    assert "jumped in" in machines.set_control(L, 2, dog, "kaz", "jumped")     # the hijacker's mode change
    with pytest.raises(RulesRefusal, match="Kaz is jumped into Razor's Doberman"):
        machines.set_control(L, 2, dog, "razor")
    assert "Razor takes the controls" in machines.set_control(L, 2, dog, "razor", hacked={("razor", dog)})
    L.set_stat("razor", "stun_damage", 20)                                     # out cold
    with pytest.raises(RulesRefusal, match="Razor is unconscious and can't hand anything over"):
        machines.lend(L, 3, dog, "tanaka")


# ── rigging: what remote control costs, and where the drones are ────────

def test_the_penalty_counts_only_machines_running_here(make_game):
    """Live T188: the Fly-Spy, parked in S12 under Filament's remote control since T132, cost his Roto-drone 2 dice in
    S22. Only the live machines a driver runs where they are count."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    here = g.current_scene_id()
    roto = _dog(g, "ghost", "Ghost's Roto-drone", "roto-drone")
    spy = machines.build_machine(L, "Ghost's Fly-Spy", "fly-spy", "ghost", 1)
    elsewhere = L.create_scene("The old safehouse", None, 1)
    L.activate_scene(here)
    L.enter(elsewhere, [spy], 1)
    machines.set_control(L, 1, roto, "ghost")
    machines.set_control(L, 1, spy, "ghost")
    assert not any("Also running" in p for p, _ in sr_lite.build_pool(L, roto, "firearms")[1])
    g.enter_scene([spy], 1)
    assert ("Also running 1 other machine", -2) in sr_lite.build_pool(L, roto, "firearms")[1]
    L.set_stat(spy, "physical_damage", 20)                                    # shot down
    assert not any("Also running" in p for p, _ in sr_lite.build_pool(L, roto, "firearms")[1])


def test_drones_go_where_their_driver_goes(make_game):
    """A cut brings the drones the crew are running along; one on its own Pilot, or left in another scene, stays."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    roto = _dog(g, "ghost", "Ghost's Roto-drone", "roto-drone")
    lynx = _dog(g, "ghost", "Ghost's Steel Lynx", "steel lynx")
    machines.set_control(L, 1, roto, "ghost")
    out = dispatch(_ctx(g), "cut_scene", {"title": "The drive", "bring_ids": ["ghost", "razor"]})
    sid = g.current_scene_id()
    assert roto in L.roster(sid) and lynx not in L.roster(sid)
    assert "came along with whoever runs them: Ghost's Roto-drone (remote: Ghost)" in out


def test_the_control_card_says_when_the_autopilot_rolls_more(make_game):
    """Live T132: the Fly-Spy went to Filament's untrained remote control just before a stealth test its own Pilot
    rolled more for. The card now compares, job by job."""
    g = make_game()
    setup_demo(g)
    roto = _dog(g, "ghost", "Ghost's Roto-drone", "roto-drone")
    card = machines.set_control(g.ledger, 1, roto, "ghost")
    # (since 2026-10-24 a fitted Roto-drone runs the two autosofts Pilot 3 has room for - Targeting and Evasion - so
    # it spots and drives on Pilot - 1, and its own Evasion 3 dodges better than Ghost's Piloting + Logic)
    assert card.splitlines()[1] == ("  Pools  Ghost (remote) vs its own Pilot: shoots 8 vs 6 · spots 9 vs 2 · "
                                    "drives 5 vs 2 · dodges 5 vs 6 - on its own Pilot it dodges better")


# ── crashes and rams (SR5 p. 201-203) ───────────────────────────────────

def test_a_crash_does_the_vehicles_body(make_game):
    """T164's riders took 10P, 8P and 9P from the GM; the book's crash is the bike's Body, 5, at -6 AP - and Stun for
    someone whose armor is over it."""
    g = make_game(dice=ScriptedDice([1] * 40))
    setup_demo(g)
    L = g.ledger
    vest = L.create_entity("item", "Kaz's armor vest", "", tier=0, props={"armor": 4}, turn=1)
    L.give("kaz", vest, 1)
    res = machines.crash(L, g.dice, 1, model_key="scorpion", riders=["joey-two-knives", {"id": "kaz"}],
                         reason="lost it on the wet ramp")
    card = res["card"]
    assert card.startswith("[DAMAGE] Joey Two-Knives's Harley-Davidson Scorpion crashes - its Body (5)")
    assert "Joey Two-Knives: crash 5P" in card and "Kaz: crash 5S - under what their armor vest (4) stops" in card
    got = {r["id"]: r["boxes"] for r in res["results"]}
    assert got == {"joey-two-knives": 5, "kaz": 5}                            # all 1s: nothing soaked
    assert L.stat("joey-two-knives", "physical_damage") == 5 and L.stat("kaz", "stun_damage") == 5


def test_a_vehicle_on_file_crashes_with_its_riders(make_game):
    g = make_game(dice=ScriptedDice([1] * 60))
    setup_demo(g)
    L = g.ledger
    bike = g.introduce("vehicle", "Joey's Scorpion", "", owner_id="joey-two-knives", model="scorpion", turn=1)[0]
    res = machines.crash(L, g.dice, 1, bike, riders=["joey-two-knives"])
    assert {r["id"] for r in res["results"]} == {bike, "joey-two-knives"}
    assert L.stat(bike, "physical_damage") == 5                               # Body 5 + Armor (2 - 2 AP), all 1s


def test_a_barrier_holds_or_breaks(make_game):
    """A 4-hit barrier (Armor 4, Structure 4): a bike at 64 km/h (53 m a turn: Body x 2 = 10) breaks it when it
    soaks nothing, and the spell ends; at 30 km/h (Body, 5) a good soak holds it, and the rider stops dead - a crash;
    a Fly-Spy's 1 doesn't beat its Armor at all. Its Structure comes back the next Combat Turn."""
    g = make_game(dice=ScriptedDice([1] * 8))
    setup_demo(g)
    L = g.ledger
    _barrier(g, "ghost")
    res = machines.crash(L, g.dice, 1, model_key="scorpion", riders=["joey-two-knives"], kph=64, barrier_of="ghost")
    assert "at 64 km/h (53 m a Combat Turn) - Body x 2 = 10" in res["card"]
    assert "Structure 0: it collapses and the spell ends" in res["card"] and "tears through" in res["card"]
    assert res["broken"] and magic.barrier(L, "ghost") is None and res["results"] == []
    _barrier(g, "ghost")
    g.dice = ScriptedDice([6] * 8 + [1] * 10)
    res = machines.crash(L, g.dice, 2, model_key="scorpion", riders=["joey-two-knives"], kph=30, barrier_of="ghost")
    assert "The wall holds" in res["card"] and res["broken"] is False and magic.barrier(L, "ghost")["structure"] == 4
    assert res["results"] == [{"id": "joey-two-knives", "boxes": 5, "status": "wounded"}]
    spy = machines.build_machine(L, "Fly-Spy", "fly-spy", None, 1)
    res = machines.crash(L, g.dice, 3, spy, kph=30, barrier_of="ghost")
    assert "doesn't beat its Armor 4" in res["card"]
    magic.damage_barrier(L, 3, "ghost", 3)
    assert magic.barrier(L, "ghost")["structure"] == 1
    magic.regrow_barriers(L, 3)
    assert magic.barrier(L, "ghost")["structure"] == 4


def test_a_crash_hits_one_wall_of_several(make_game):
    """Live review: with two barriers held, every crash hit the first, wrote its numbers onto the other, and one
    collapse ended both. barrier names the wall (asked for when there are two); the other isn't touched; end_spell's
    which drops one."""
    g = make_game(dice=ScriptedDice([1] * 8))
    setup_demo(g)
    L = g.ledger
    _walls(g, "ghost", (4, "ghost"), (2, "razor"))
    with pytest.raises(LedgerError, match=r"Which Physical Barrier\? Ghost holds 2: #1 on Ghost; #2 on Razor"):
        machines.crash(L, g.dice, 1, model_key="scorpion", riders=["joey-two-knives"], kph=64, barrier_of="ghost")
    res = machines.crash(L, g.dice, 1, model_key="scorpion", riders=["joey-two-knives"], kph=64, barrier_of="ghost",
                         which="Razor")
    assert "hits Ghost's Physical Barrier #2 (on Razor) at 64 km/h" in res["card"]
    assert "The Physical Barrier #2 (on Razor) takes 10 - Structure 0: it collapses" in res["card"] and res["broken"]
    assert [(b["target"], b["armor"], b["structure"]) for b in magic.barriers(L, "ghost")] == [("ghost", 4, 4)]
    assert L.stat("ghost", "sustaining") == 1                                  # the other wall still stands
    _walls(g, "ghost", (4, "ghost"), (3, "razor"))
    ctx = _ctx(g)
    dispatch(ctx, "fight", {"action": "start", "hostile": ["joey-two-knives"]})   # (its Initiative rolled first)
    g.dice = ScriptedDice([6] * 3)                                             # 3 hits of 8: 5 - 3 = 2 boxes on #1
    dispatch(ctx, "crash", {"model": "scorpion", "riders": [{"id": "joey-two-knives"}], "speed_kph": 30,
                            "barrier_of": "ghost", "barrier": "#1", "reason": "into the first wall"})
    assert [(b["armor"], b["structure"]) for b in magic.barriers(L, "ghost")] == [(4, 2), (3, 3)]
    dispatch(ctx, "end_spell", {"caster_id": "ghost", "spell": "Physical Barrier", "which": "Razor"})
    assert [h["target"] for h in L.get("ghost")["props"]["sustained"]] == ["ghost"]
    assert L.stat("ghost", "sustaining") == 1


def test_a_ram_is_an_attack(make_game):
    """A van rams a ganger at 50 km/h (42 m a turn: Body 12): the driver's Piloting + Reaction against his dodge, the
    Body plus net hits to him at -6 AP, and half the table's 12 to the van."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    n = sr_lite.build_pool(L, "razor", "piloting")[0]
    g.dice = ScriptedDice([6] * n + [1] * 80)
    res = machines.crash(L, g.dice, 1, van, kph=50, into="joey-two-knives", driver="razor")
    card = res["card"]
    assert card.startswith("[ROLL] The van rams Joey Two-Knives at 50 km/h (42 m a Combat Turn) - Body, Razor driving")
    assert res["hit"] and f"Damage Body 12+{n} = {min(15, 12 + n)}P, AP -6" in card
    assert "The van: half the ram's damage, 6P (p. 203)" in card and L.stat(van, "physical_damage") == 6
    assert "Keeping control" in card
    row = L.conn.execute("SELECT spec FROM tests ORDER BY rowid DESC LIMIT 1").fetchone()
    assert '"kind": "ram"' in row["spec"]


def test_the_crash_tool_counts_who_did_it(make_game):
    """The barrier's magician is the attacker (live T171: the crash left Garvey on nobody's side, and the fight ended
    itself with him standing); a ram opens the fight and spends the driver's Action Phase; riders must be on file."""
    g = make_game(dice=ScriptedDice([3] * 300))
    setup_demo(g)
    L = g.ledger
    _barrier(g, "ghost")
    ctx = _ctx(g)
    with pytest.raises(LedgerError, match="introduce the rider first"):
        dispatch(ctx, "crash", {"model": "scorpion", "riders": [{"id": "Crows rider three"}], "speed_kph": 60,
                                "barrier_of": "ghost", "reason": "into the wall"})
    out = dispatch(ctx, "crash", {"model": "scorpion", "riders": [{"id": "joey-two-knives"}], "speed_kph": 60,
                                  "barrier_of": "ghost", "reason": "into the wall"})
    enc = encounters.active(g)
    assert out.startswith("[FIGHT]") and encounters.side(g, enc, "joey-two-knives") == "hostile"
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    out = dispatch(ctx, "crash", {"vehicle_id": van, "driver_id": "razor", "into_id": "joey-two-knives",
                                  "speed_kph": 40, "reason": "run him down", "defense": ["parry"]})
    assert "Action Complex: Ram - action 1 of" in out
    assert _rollers("crash", {"driver_id": "razor", "into_id": "joey", "riders": [{"id": "kaz"}]}) == \
        ["razor", "joey"]                     # (a called roll is answered by it - not a rider's: a ram doesn't hit them)
    assert _rollers("crash", {"riders": [{"id": "kaz"}], "barrier_of": "ghost"}) == ["kaz"]


def test_gangers_ride(make_game):
    """Live T164: Biker Two's Piloting test rolled no dice - the ganger template had no Piloting."""
    g = make_game()
    setup_demo(g)
    assert g.ledger.stat("joey-two-knives", "piloting") == 2


# ── the review of all this (2026-10-24) ─────────────────────────────────

def _fight(g, *hostile):
    """A fight on before the dice that matter (its Initiative is rolled on 6s: everyone has a phase)."""
    g.dice = ScriptedDice([6] * 60)
    dispatch(_ctx(g), "fight", {"action": "start", "hostile": list(hostile)})


def test_a_drone_sent_out_of_the_scene_stays_behind(make_game):
    """The T188 bug again, by the engine's own advice: a cut brings a rigger's drones along, and the along note says
    to send one back out with scene_presence leave if the story left it behind - which dropped its roster row, and no
    row read as 'never placed': the Fly-Spy kept its -2 on the Roto-drone and came along on the next cut. Out is out;
    one put back in a scene is beside him again, and one never placed anywhere (just bought) rides along."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    roto = _dog(g, "ghost", "Ghost's Roto-drone", "roto-drone")
    spy = _dog(g, "ghost", "Ghost's Fly-Spy", "fly-spy")
    for m in (roto, spy):
        machines.set_control(L, 1, m, "ghost")
    out = dispatch(_ctx(g), "cut_scene", {"title": "The bar", "bring_ids": ["ghost"]})
    assert "Ghost's Fly-Spy (remote: Ghost)" in out and "scene_presence leave it" in out
    dispatch(_ctx(g), "scene_presence", {"leave": [spy]})                    # on overwatch outside
    assert L.scene_of(spy) is None and L.ever_placed(spy)
    assert not any("Also running" in p for p, _ in sr_lite.build_pool(L, roto, "firearms")[1])
    out = dispatch(_ctx(g), "cut_scene", {"title": "The docks", "bring_ids": ["ghost"]})
    docks = g.current_scene_id()
    assert roto in L.roster(docks) and spy not in L.roster(docks) and "Fly-Spy" not in out
    g.enter_scene([spy], 2)                                                  # it catches up
    assert ("Also running 1 other machine", -2) in sr_lite.build_pool(L, roto, "firearms")[1]
    crawler = machines.build_machine(L, "Ghost's Crawler", "crawler", "ghost", 2, equipped=False)
    machines.set_control(L, 2, crawler, "ghost")
    assert ("Also running 2 other machines", -4) in sr_lite.build_pool(L, roto, "firearms")[1]
    dispatch(_ctx(g), "cut_scene", {"title": "The van", "bring_ids": ["ghost"]})
    assert {roto, spy, crawler} <= set(L.roster(g.current_scene_id()))


def test_a_ram_hits_someone_not_something(make_game):
    """Review: into_id took any entity - the Lucky Shot (a location), a dumpster (an item) and a host were 'rammed': a
    fight opened, the driver's phase went, the bar took 13 boxes and stood as a foe. A ram is at a person, drone or
    vehicle; a wall or a thing is a plain crash - refused before anything opens or rolls."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "Razor's van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    dumpster = g.introduce("item", "A dumpster", "rusted green steel", turn=1)[0]
    host = g.introduce("host", "Renraku host", "a zen garden", rating=4, turn=1)[0]
    for what in ("the-lucky-shot", dumpster, host):
        with pytest.raises(LedgerError, match="isn't a person, drone or vehicle - a wall, a pole, a dumpster or "
                                              "anything else that's no one is a crash: leave out into_id"):
            dispatch(_ctx(g), "crash", {"vehicle_id": van, "driver_id": "razor", "into_id": what, "speed_kph": 60,
                                        "reason": "rams it"})
        assert not L.stats(what).get("physical_damage")
    with pytest.raises(LedgerError, match="introduce whoever is rammed first .* leave out into_id"):
        dispatch(_ctx(g), "crash", {"vehicle_id": van, "driver_id": "razor", "into_id": "the alley wall",
                                    "speed_kph": 60, "reason": "rams it"})
    assert not encounters.active(g) and not L.stats(van).get("physical_damage")


def test_a_rammed_runners_called_edge_rides_their_dodge(make_game):
    """Review: the ram's target dodges and soaks, but the crash tool had no Edge for them - the called Edge was never
    asked for, the roll guard counted the roll made, and Ghost's 9d6 dodge came up all ones with 3 Edge unspent. Now
    the tool asks, as attack does, and the Edge rides the dodge (a second chance while the ram still lands)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "Kaz's van", "", owner_id="kaz", model="bulldog", present=True, turn=1)[0]
    _fight(g, "kaz")
    ctx = _ctx(g, "ghost")
    ctx.edge_asks = {"ghost": ("Ghost", "reroll", "dives aside and uses edge to reroll the dodge")}
    ram = {"vehicle_id": van, "driver_id": "kaz", "into_id": "ghost", "speed_kph": 50, "reason": "runs him down"}
    out = run_tool(ctx, tool("crash", **ram))
    assert out.get("is_error") and "defense_edge='reroll' for the dodge or soak_edge='reroll' for the soak" in \
        out["content"] and "Nothing was rolled" in out["content"]
    g.dice = ScriptedDice([6, 6] + [1] * 9 + [1] * 9 + [1] * 60)          # Kaz's 2 dice hit, Ghost's 9 miss twice
    out = run_tool(ctx, tool("crash", **ram, defense_edge="reroll"))
    assert "Edge   second chance: 9 misses rerolled" in out["content"] and L.stat("ghost", "edge_points") == 2
    with pytest.raises(LedgerError, match="defense_edge and soak_edge are the rammed one's"):
        machines.check_crash(L, van, riders=["kaz"], soak_edge="push")     # (a plain crash: no one's rammed)


def test_the_drivers_called_edge_rides_the_ram(make_game):
    """Review: 'I floor it and ram Joey, pushing my Edge on the ram' was refused with 'edge=push', the GM put it on
    Razor's rider entry, and it was accepted there - on a soak a ram never rolls (the rammer's riders aren't hit): no
    push, nothing on the card, 3 Edge -> 3. The ram's roll takes Edge now, and a rider's soak Edge in a ram is
    refused."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    g.enter_scene(["joey-two-knives"], 1)
    _fight(g, "joey-two-knives")
    ctx = _ctx(g, "razor")
    ctx.edge_asks = {"razor": ("Razor", "push", "pushing my Edge on the ram")}
    ram = {"vehicle_id": van, "driver_id": "razor", "riders": [{"id": "razor"}], "into_id": "joey-two-knives",
           "speed_kph": 50, "reason": "floors it"}
    out = run_tool(ctx, tool("crash", **ram))
    assert out.get("is_error") and "(edge='push')" in out["content"] and "riders" not in out["content"]
    out = run_tool(ctx, tool("crash", **dict(ram, riders=[{"id": "razor", "edge": "push"}])))
    assert out.get("is_error") and "In a ram the riders aren't hit" in out["content"]
    assert L.stat("razor", "edge_points") == 3 and not L.stats(van).get("physical_damage")
    out = run_tool(ctx, tool("crash", **ram, edge="push"))
    assert "Edge, pushed - 6s explode (2 left) 3" in out["content"] and L.stat("razor", "edge_points") == 2
    L.set_stat("razor", "edge_points", 0)                                    # (a push with none left: before any dice)
    with pytest.raises(LedgerError, match="Razor has no Edge points left"):
        machines.check_crash(L, van, riders=[{"id": "razor"}], kph=50, into="joey-two-knives", driver="razor",
                             edge="push")
    with pytest.raises(LedgerError, match="runs on its own Pilot - a machine has no Edge"):
        spy = machines.build_machine(L, "A Fly-Spy", "fly-spy", None, 1)
        machines.check_crash(L, spy, kph=40, into="joey-two-knives", edge="push")


def test_a_won_hack_or_the_controls_need_no_handover(make_game):
    """Review: owner_hands_over on a drone Ghost had just out-hacked put him through the lending checks - 'Kaz isn't
    one of the crew - only by a won opposed Hacking test', and mid-fight 'win an opposed Hacking test against it' -
    the hack just won. A taker with a claim of their own (a won hack, the controls already) is lent nothing."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    dog = _dog(g, "kaz", "Security Doberman")
    flagged = {"drone_id": dog, "controller_id": "ghost", "owner_hands_over": True}
    ctx = _ctx(g, "ghost")
    ctx.hacks.add(("ghost", dog))
    assert "Ghost takes the controls (remote control)" in dispatch(ctx, "control_drone", flagged)
    assert not L.get(dog)["props"].get("delegates")                          # a hack takes the controls, no keys
    assert "Ghost takes the controls" in dispatch(_ctx(g, "ghost"), "control_drone", flagged)   # (already driving)
    machines.set_control(L, 1, dog, "autonomous")
    encounters.start(g, 1, hostile=["kaz"])
    ctx = _ctx(g, "ghost")
    ctx.hacks.add(("ghost", dog))
    assert "Ghost takes the controls" in dispatch(ctx, "control_drone", flagged)
    mine = _dog(g)                                                           # Razor's, hijacked, and won back
    L.update_entity(mine, props={**L.get(mine)["props"], "controller": "kaz", "control": "remote"})
    ctx = _ctx(g, "ghost", "razor")
    ctx.hacks.add(("ghost", mine))
    assert "Ghost takes the controls" in dispatch(ctx, "control_drone", dict(flagged, drone_id=mine))
    with pytest.raises(RulesRefusal, match="Kaz is on the other side of this fight"):   # (no claim: checked still)
        dispatch(_ctx(g, "razor"), "control_drone", dict(flagged, controller_id="razor"))


def test_a_vehicle_still_with_the_courier_cant_crash_or_ram(make_game):
    """Review: set_control and mount_weapon refused a van still on its way from the dealer, and crash didn't - it
    rammed Kaz, opened a fight and spent Razor's Action Phase."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "Razor's new van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    now = int(L.meta("clock", "0") or 0)
    L.update_entity(van, props={**L.require(van)["props"], "in_transit": {"until": now + 20 * 3600, "from": "kaz"}})
    for call in ({"into_id": "kaz", "driver_id": "razor", "speed_kph": 60}, {"riders": [{"id": "razor"}]}):
        with pytest.raises(LedgerError, match="Razor's new van is on its way from kaz - .* nobody can run it yet"):
            dispatch(_ctx(g), "crash", {"vehicle_id": van, "reason": "floors it", **call})
    assert not encounters.active(g) and not L.stats("kaz").get("physical_damage")


def test_a_drones_ram_is_its_riggers_roll(make_game):
    """Review: the Roto-drone's ram rolled Ghost's Piloting + Logic and spent Ghost's action, but the roll guard never
    counted Ghost as having rolled - it filed 'skipped a roll' and sent the GM back for a second one. A machine
    someone runs brings its driver into ctx.rolled - a ram, a shot, a test. Naming the rigger as driver_id rolls
    through the drone the same (not as if they sat aboard)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    roto = _dog(g, "ghost", "Ghost's Roto-drone", "roto-drone")
    machines.set_control(L, 1, roto, "ghost")
    g.enter_scene(["joey-two-knives"], 1)
    _fight(g, "joey-two-knives")
    ctx = _ctx(g, "ghost")
    out = run_tool(ctx, tool("crash", vehicle_id=roto, into_id="joey-two-knives", speed_kph=60, reason="slams it"))
    assert "Ghost's Logic" in out["content"] and "Ghost's action 1 of" in out["content"]
    assert {"ghost", "joey-two-knives"} <= ctx.rolled
    assert "ghost" in _rollers("attack", {"attacker_id": roto, "target_id": "joey-two-knives"}, L)
    res = machines.crash(L, g.dice, 2, roto, kph=60, into="joey-two-knives", driver="ghost")
    assert "Ghost's Logic" in res["card"] and "Reaction" not in res["card"].splitlines()[1]


def test_an_idle_runner_lends_nothing_on_the_gms_word(make_game):
    """Review: an away player's PC (companions idle) was the GM's to decide - the GM lent Razor's Doberman in the same
    turn the packet listed Razor hands-off ('the GM writes none of their words or choices'). An idle PC, away or
    parked with nobody playing them, decides for themselves like a player's; a companion (mode gm) is the GM's."""
    g = make_game()
    setup_demo(g)
    _seat(g, "razor", afk=1)
    _seat(g, "ghost")
    g.set_companions(False)
    assert g.control_of("razor") == "idle" and hands_off(g, g.current_scene_id(), [("ghost", "...")]) == ["Razor"]
    dog = _dog(g)
    hands = {"drone_id": dog, "controller_id": "ghost", "owner_hands_over": True}
    with pytest.raises(RulesRefusal, match="Razor's player hasn't handed Razor's Doberman over"):
        dispatch(_ctx(g, "ghost"), "control_drone", hands)
    ghosts = _dog(g, "ghost", "Ghost's Doberman")                            # nor seated at someone else's drone:
    card = dispatch(_ctx(g, "ghost"), "control_drone", {"drone_id": ghosts, "controller_id": "razor",
                                                        "owner_hands_over": True})
    assert "Razor takes the controls when their player says so" in card     # the keys, not the controls
    assert g.ledger.get(ghosts)["props"]["controller"] is None
    g.conn.execute("DELETE FROM players WHERE handle='razor'")               # parked: nobody holds him at all
    assert g.control_of("razor") == "idle"
    with pytest.raises(RulesRefusal, match="Razor's player hasn't handed"):
        dispatch(_ctx(g, "ghost"), "control_drone", hands)
    g.set_control("razor", "gm")                                              # a companion the GM plays
    assert "Razor hands over the keys" in dispatch(_ctx(g, "ghost"), "control_drone", hands)


def test_a_barrier_rammed_on_purpose_adds_the_drivers_hits(make_game):
    """Review (SR5 p. 197, Destroying Barriers): a deliberate attack on a wall is resolved normally - unopposed, its
    hits added to the DV, and only a critical glitch misses. The van floored into a 12-hit wall (Armor 12) did its bare
    Body 12: not a scratch. With driver_id it's rammed on purpose; riders who couldn't stop still roll nothing."""
    g = make_game(dice=ScriptedDice([6] * 4 + [1] * 200))                   # Razor's 4 dice: 4 hits
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    _walls(g, "joey-two-knives", (12, "joey-two-knives"))
    res = machines.crash(L, g.dice, 1, van, riders=["razor"], kph=50, barrier_of="joey-two-knives", driver="razor",
                         reason="Razor floors it to smash through the wall")
    card = res["card"]
    assert "Ram    Reaction 5 - Untrained 1 = 4d6 -> 6 6 6 6 -> 4 hits (Razor's Piloting + Reaction, on purpose" in card
    assert "Damage Body 12+4 = 15" in card and res["broken"] and "tears through" in card
    _walls(g, "joey-two-knives", (12, "joey-two-knives"))
    res = machines.crash(L, g.dice, 2, van, riders=["razor"], kph=50, barrier_of="joey-two-knives")
    assert "Ram " not in res["card"] and "doesn't beat its Armor 12 - not a scratch" in res["card"]
    assert "The wall holds" in res["card"] and res["results"][-1]["id"] == "razor"   # (stopped dead: a crash)
    L.set_stat("razor", "physical_damage", 0)
    g.dice = ScriptedDice([1] * 4)                                            # a critical glitch: it misses the wall
    res = machines.crash(L, g.dice, 3, van, riders=["razor"], kph=50, barrier_of="joey-two-knives", driver="razor")
    assert "CRITICAL GLITCH" in res["card"] and "misses the wall altogether" in res["card"]
    assert res["results"] == [] and magic.barrier(L, "joey-two-knives")["structure"] == 12
    _fight(g, "joey-two-knives")                                             # in a fight: the driver's phase
    out = dispatch(_ctx(g, "razor"), "crash", {"vehicle_id": van, "riders": [{"id": "razor"}], "speed_kph": 50,
                                                "barrier_of": "joey-two-knives", "driver_id": "razor",
                                                "reason": "again"})
    assert "Action Complex: Ram - action 1 of" in out


def test_the_crews_van_in_the_crews_wall_is_no_fight(make_game):
    """Review: Razor misjudged Ghost's wall with a client aboard, and the magician counted as attacking everyone not a
    runner - Dr. Calloway came out of it hostile, a foe still standing in a fight nobody started. The riders are one
    party: one of the caster's side aboard makes it the crew's accident. A stranger's bike is still the wall's doing
    (live T171 - test_the_crash_tool_counts_who_did_it)."""
    g = make_game(dice=ScriptedDice([3] * 400))
    setup_demo(g)
    _barrier(g, "ghost")
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    calloway = g.introduce("npc", "Dr. Calloway", "the extraction target", present=True, turn=1)[0]
    out = dispatch(_ctx(g), "crash", {"vehicle_id": van, "riders": [{"id": "razor"}, {"id": calloway}],
                                      "speed_kph": 30, "barrier_of": "ghost", "reason": "Razor misjudges the wall"})
    assert not out.startswith("[FIGHT]") and not encounters.active(g)
