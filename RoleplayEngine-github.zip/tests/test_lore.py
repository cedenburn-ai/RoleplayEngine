"""Clarifications (the GM's current picture of a node) and tensions (the story's open questions)."""
from roleplay.dm import dmblock, tensions
from roleplay.dm.clarify import fold_scene
from roleplay.dm.tools import TurnContext, dispatch
from roleplay.setup import setup_demo, setup_rage
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM


def _apply(g, text, turn=5):
    ctx = TurnContext(g, turn, g.current_scene_id())
    _, entries = dmblock.split(f"Narration.\n<dm>\n{text}\n</dm>")
    made = dmblock.apply(ctx, entries)
    return ctx, made


def test_a_clarification_folds_the_notes_before_it(make_game):
    g = make_game()
    setup_demo(g)
    S = g.sub
    n1 = S.add_note(["kaz"], "Kaz owes Razor a favor.", 2)
    S.add_note(["kaz"], "Kaz sold a name to Lone Star once.", 3)
    c1 = S.clarify("kaz", "Kaz: owes Razor a favor; sells names to Lone Star when rent is short.", 4)
    assert S.notes_for("kaz", 10, unfolded=True) == [] and len(S.notes_for("kaz", 10)) >= 2
    n3 = S.add_note(["kaz", "razor"], "Kaz promised Razor a buyer by midnight.", 5)
    assert [n["id"] for n in S.notes_for("kaz", 10, unfolded=True)] == [n3]
    assert [n["id"] for n in S.notes_for("razor", 10, unfolded=True)][0] == n3      # folded per target
    packet, _ = build_packet(g, g.current_scene_id(), [], 6)
    assert f"Current picture (GM-only) [{c1}" in packet and "promised Razor a buyer" in packet
    assert "sold a name to Lone Star once" not in packet                            # folded: not repeated
    c2 = S.clarify("kaz", "Kaz: owes Razor; promised a buyer by midnight.", 6)
    assert S.clarification("kaz")["id"] == c2 and S.superseded_by(c1) == c2
    assert g.conn.execute("SELECT status FROM clarifications WHERE id=?", (c1,)).fetchone()[0] == "superseded"
    assert n1 in {n["id"] for n in S.notes_for("kaz", 10)}                          # history is kept


def test_the_gm_clarifies_by_tool_or_dm_block(make_game):
    g = make_game()
    setup_demo(g)
    ctx = TurnContext(g, 5, g.current_scene_id())
    out = dispatch(ctx, "clarify", {"id": "Kaz", "text": "Kaz is scared of the Ancients now."})
    cid = out.split("]")[0].strip("[")
    assert g.sub.clarification("kaz")["id"] == cid
    assert "Current picture" in dispatch(ctx, "recall", {"ids": ["kaz"]})
    _, made = _apply(g, "clarify kaz: Kaz will sell Razor out if the bar burns.")
    assert g.sub.clarification("kaz")["text"] == "Kaz will sell Razor out if the bar burns." and made


def test_the_scene_end_pass_folds_busy_nodes(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)
    S, sid = g.sub, g.current_scene_id()
    assert len(S.notes_for("kaz", 10)) == 1                    # (the demo's secret)
    S.add_note(["kaz"], "note 1", 3)
    assert fold_scene(g, sid, 4) == []                          # two notes: not worth a pass yet
    S.add_note(["kaz"], "note 2", 3)
    made = fold_scene(g, sid, 4)
    assert len(made) == 1 and S.clarification("kaz")["text"] == "scene summary"   # (FakeLLM.text)
    assert S.notes_for("kaz", 10, unfolded=True) == []


def test_tension_pressure_rises_when_ignored_and_eases_when_played(make_game):
    g = make_game()
    setup_demo(g)
    now = g.clock()
    _, made = _apply(g, "tension kaz, razor: Will Kaz sell Razor out? | stakes 2 | due +2h | next: Lone Star calls "
                        "| public: Kaz is twitchy about Lone Star")
    q = made[0]
    t = tensions.get(g, q)
    assert (t["stakes"], t["due_time"], t["next"], t["public"]) == (2, now + 120, "Lone Star calls",
                                                                    "Kaz is twitchy about Lone Star")
    assert set(tensions.about(g, q)) == {"kaz", "razor"}
    tensions.step(g, 6, {}, set())
    assert tensions.get(g, q)["pressure"] == 0.24                      # left alone: 0.12 x stakes
    for _ in range(10):
        tensions.step(g, 7, {}, set())
    assert tensions.get(g, q)["pressure"] == 2.64
    tensions.step(g, 8, {"kaz": "actor"}, set())                       # play brushed it
    assert tensions.get(g, q)["pressure"] == 2.29
    g.set_clock(now + 150)
    assert tensions.step(g, 9, {}, set()) == [f"TENSION {q} is due: Will Kaz sell Razor out?"]
    assert tensions.get(g, q)["pressure"] == 3.0                       # (capped)
    lines = tensions.packet_lines(g)
    assert f"[{q}] pressure 3.0 HIGH" in lines[1] and "DUE NOW" in lines[1]
    ctx, _ = _apply(g, f"tension {q}: Kaz made a call to his old precinct | next: a patrol rolls by")
    t = tensions.get(g, q)
    assert t["pressure"] == 1.5 and t["next"] == "a patrol rolls by" and q in ctx.tensions_touched
    assert any("old precinct" in n["text"] for n in g.sub.notes_for(q, 5))
    assert tensions.public_lines(g)[0].startswith("Kaz is twitchy about Lone Star")


def test_shelve_and_resolve(make_game):
    g = make_game()
    setup_demo(g)
    _, (q1,) = _apply(g, "tension: Who hired the Renraku courier?")
    _, (q2,) = _apply(g, "tension joey: Will the Ancients come back for Razor? | stakes 3")
    assert tensions.about(g, q1) == [] and tensions.get(g, q2)["stakes"] == 3
    _apply(g, f"shelve {q1}: the table chased the money instead")
    tensions.step(g, 6, {}, set())
    assert tensions.get(g, q1)["status"] == "shelved" and tensions.get(g, q1)["pressure"] == 0.12   # simmers at half
    assert "Also simmering" in "\n".join(tensions.packet_lines(g))
    _apply(g, f"resolve {q2}: Razor made peace with Joey.")
    t = tensions.get(g, q2)
    assert t["status"] == "resolved" and t["resolution"] == "Razor made peace with Joey."
    tensions.step(g, 7, {}, set())
    assert tensions.get(g, q2)["pressure"] == 0
    _apply(g, f"tension {q1}: a name surfaces")                       # touching a shelved one reopens it
    assert tensions.get(g, q1)["status"] == "open"


def test_the_rage_world_opens_with_tensions(make_game):
    g = make_game()
    setup_rage(g)
    rows = g.conn.execute("SELECT id, stakes, due_time FROM tensions ORDER BY id").fetchall()
    assert [r["id"] for r in rows] == ["Q1", "Q2", "Q3"] and rows[0]["due_time"] == 1800
    packet, _ = build_packet(g, g.current_scene_id(), [], 1)
    assert "OPEN TENSIONS" in packet and "06:00 purge" in packet


# ── who a <dm> line is about ─────────────────────────────────────────────

def _on(g, nid):
    return {r[0] for r in g.conn.execute("SELECT target_id FROM annotates WHERE note_id=?", (nid,))}


def test_dm_lines_take_ids_by_comma_space_or_bracket(make_game):
    """Live T181/T188: the canon pass wrote `note quiet-lou filament: ...` and `note pastor-garvey crows-biker-fenn:
    ...` - each read as one name nobody had, and both fixes were lost. Ids come by comma, by space, in [brackets]
    and as `Name [id]` now."""
    g = make_game()
    setup_demo(g)
    for ids in ("kaz, razor", "kaz razor", "[kaz] [razor]", "Kaz [kaz], Razor [razor]", "kaz and razor", "kaz; razor",
                "Kaz [kaz] razor", "kaz. razor"):
        ctx, made = _apply(g, f"note {ids}: Square, for now.")
        assert len(made) == 1 and not ctx.unplaced and _on(g, made[0]) == {"kaz", "razor"}, ids
    ctx, made = _apply(g, "note T1 kaz: the bar fight started over a debt")                   # node ids too
    assert _on(g, made[0]) == {"T1", "kaz"}
    ctx, made = _apply(g, "fact kaz razor (replaces F2): Kaz and Razor are square now.")
    assert len(made) == 1 and g.sub.superseded_by("F2") == made[0]


def test_a_name_is_one_person_never_its_words(make_game):
    """Words split only into exact ids: a name is read whole or not at all (live: 'anton' beside 'Anton Salgado',
    'crows' beside 'Crows Biker Fenn'). A line naming no one on file lands on ctx.unplaced, as written."""
    g = make_game()
    setup_demo(g)
    for name in ("Lou", "Quiet Lou", "Anton", "Desmond", "Pembrook", "Sergeant P."):
        g.introduce("npc", name, "x", template="civilian", present=False, turn=1)
    _, made = _apply(g, "note Quiet Lou: alive after all")
    assert _on(g, made[0]) == {"quiet-lou"}                                  # not Lou
    _, made = _apply(g, "note Quiet Lou [quiet-lou], Sergeant P.: both alive")
    assert _on(g, made[0]) == {"quiet-lou", "sergeant-p"}                    # (a name ending in a dot)
    for ids in ("Anton Salgado", "Desmond Pembrook", "Kaz Razor", "Quiet Lou razor"):
        before = {x: len(g.sub.notes_for(x, 50)) for x in ("anton", "desmond", "pembrook", "kaz", "razor", "quiet-lou")}
        ctx, made = _apply(g, f"note {ids}: x")
        assert made == [] and [e["line"] for e in ctx.unplaced] == [f"note {ids}: x"], ids
        assert {x: len(g.sub.notes_for(x, 50)) for x in before} == before, ids
    ctx, made = _apply(g, "note kaz, Anton Salgado: owes Kaz")                 # the known part lands
    assert _on(g, made[0]) == {"kaz"} and not ctx.unplaced
    ctx, made = _apply(g, "clarify kaz, razor: they're square")               # one picture can't be two people's
    assert g.sub.clarification("kaz") is None and _on(g, made[0]) == {"kaz", "razor"}


def test_ids_in_front_of_a_bracket_are_read_too(make_game):
    """Review (2026-10-24): everything before a `[bracket]` that resolved was taken for its label and dropped - not
    resolved, not reported - so `note T165 Quiet Lou [quiet-lou], ...` lost T165, the node the fix was about, and
    `note nobody-here Razor [razor]: ...` landed on Razor alone with no word in the log."""
    g = make_game()
    setup_demo(g)
    g.introduce("npc", "Quiet Lou", "x", template="civilian", present=False, turn=1)
    for raw, want in (("kaz Razor [razor]", (["kaz", "razor"], [])),
                      ("T1 Quiet Lou [quiet-lou]", (["T1", "quiet-lou"], [])),
                      ("kaz, Quiet Lou and Razor [razor]", (["kaz", "quiet-lou", "razor"], [])),
                      ("nobody-here Razor [razor]", (["razor"], ["nobody-here"])),
                      ("Quiet Lou [quiet-lou]", (["quiet-lou"], [])), ("Lou [quiet-lou]", (["quiet-lou"], [])),
                      ("Kaz [kaz] razor", (["kaz", "razor"], []))):
        assert dmblock.resolve_ids(g, raw) == want, raw
    ctx = TurnContext(g, g.turn_no(), g.current_scene_id())
    logged = []
    g.out = logged.append
    dmblock.apply(ctx, dmblock.split("<dm>\nnote nobody-here Razor [razor]: owes the Ancients\n</dm>")[1], quiet=True)
    assert [e["kind"] for e in ctx.held] == ["note"] and not logged           # waits for the memory pass, whole
    dmblock.apply(ctx, ctx.held)
    assert any("nobody-here" in x for x in logged)                            # ...then lands, and says what it lost
    assert any(n["text"] == "owes the Ancients" for n in g.sub.notes_for("razor", 5))


def test_a_line_in_no_form_is_reported_not_dropped(make_game):
    """Review (2026-10-24): split kept only lines it could read - `note: ...` with no ids, a dash for the colon - so
    a canon fix in either form vanished before apply, and nothing said it couldn't be placed. They come back UNREAD
    now and land on ctx.unplaced, logged; blank lines and fences aren't lines."""
    g = make_game()
    setup_demo(g)
    _, entries = dmblock.split("<dm>\nnote: Kaz is alive after all\nnote kaz - alive after all\n\n```\n"
                               "fact Kaz — alive\nnote kaz: alive\n</dm>")
    assert [e["kind"] for e in entries] == ["unread", "unread", "unread", "note"]
    ctx = TurnContext(g, g.turn_no(), g.current_scene_id())
    logged = []
    g.out = logged.append
    made = dmblock.apply(ctx, entries)
    assert len(made) == 1 and [e["line"] for e in ctx.unplaced] == [
        "note: Kaz is alive after all", "note kaz - alive after all", "fact Kaz — alive"]
    assert sum("can't read" in x for x in logged) == 3


def test_space_separated_tension_ids_and_a_close_with_none(make_game):
    g = make_game()
    setup_demo(g)
    _, (q1,) = _apply(g, "tension kaz: Will Kaz pay?")
    _, (q2,) = _apply(g, "tension razor: Will Razor talk?")
    _apply(g, f"resolve {q1} {q2}: both settled at the bar")
    assert tensions.get(g, q1)["status"] == tensions.get(g, q2)["status"] == "resolved"
    ctx, _ = _apply(g, "resolve kaz: settled")
    assert [e["kind"] for e in ctx.unplaced] == ["resolve"]


def test_name_takes_a_bracketed_id_or_a_name(make_game):
    g = make_game()
    setup_demo(g)
    _apply(g, "name [kaz]: Kazimir Volkov")
    _apply(g, "name Joey Two-Knives: Joey Calloway")
    assert g.ledger.get("kaz")["name"] == "Kazimir Volkov"
    assert g.ledger.get("joey-two-knives")["name"] == "Joey Calloway"
    ctx, _ = _apply(g, "name Nobody Here: Someone")
    assert [e["kind"] for e in ctx.unplaced] == ["name"]
