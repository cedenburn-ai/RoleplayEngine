"""Perspective: nobody knows more than they could perceive.

A voice on the line heard what was said and saw nothing; someone taken down mid-escape didn't surrender; a fight's
memory reports what happened and leaves the judging to the people who were there."""
from roleplay import encounters
from roleplay.dm.minds import reflect_scene
from roleplay.dm.prompts import COMMIT_SYSTEM, DM_SYSTEM, commit_schema
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text


def _extraction(members):
    return {"summary": "Razor phoned Joey and asked where Kaz keeps the chip, while Ghost palmed a keycard.",
            "recalled": [], "facts": [], "told": [], "new_entities": [],
            "moved_to": {"location": "", "description": "", "who": []}, "members": members}


def test_a_voice_on_the_line_heard_it_and_never_walks_in(make_game):
    members = [{"id": "razor", "role": "actor"}, {"id": "ghost", "role": "actor"},
               {"id": "joey-two-knives", "role": "remote"}]
    g = make_game(FakeLLM([([text('**Joey Two-Knives [joey-two-knives]:** "Behind the bar."')], "end_turn")],
                          _extraction(members)))
    setup_demo(g)
    sid = g.current_scene_id()
    assert "joey-two-knives" not in g.ledger.roster(sid)
    res = g.run_turn([("razor", "I call Joey.")])
    assert "joey-two-knives" not in g.ledger.roster(sid)                         # never walked into the room
    roles = dict(g.sub.members_of(res.info["slice_id"]))
    assert roles["joey-two-knives"] == "remote"
    known = g.conn.execute("SELECT how FROM knows WHERE holder='joey-two-knives' AND node_id=?",
                           (res.info["slice_id"],)).fetchone()
    assert known["how"] == "on the line"                                          # heard it, didn't see it


def test_the_rules_say_so(make_game):
    assert "remote" in commit_schema()["properties"]["members"]["items"]["properties"]["role"]["enum"]
    assert "Anyone on a phone, commlink, radio or comm channel is remote" in COMMIT_SYSTEM
    assert "Someone stunned, knocked out, killed or dragged down didn't yield" in COMMIT_SYSTEM
    assert "a muted line carries nothing" in DM_SYSTEM


def test_a_voice_on_the_line_reflects_on_what_it_heard(make_game):
    asked = []

    def think(user):
        if user.startswith("CHARACTER: Joey"):
            asked.append(user)
            return {"beliefs": [{"about": "razor", "attitude": 1, "belief": "Joey thinks Razor is fishing.",
                                 "changed": True}]}
        return {"beliefs": []}
    g = make_game(FakeLLM(extraction=think))
    setup_demo(g)
    sid = g.current_scene_id()
    for t in (20, 21):
        s = g.sub.write_slice(t, sid, f"Razor called Joey and pressed him about the chip (call {t}).",
                              [("razor", "actor"), ("joey-two-knives", "remote")], [])
        g.sub.add_knows("joey-two-knives", s, "on the line", None, t)
    reflect_scene(g, sid, 22)
    witnessed, heard = asked[0].split("WHAT THEY HEARD")
    assert "(call 20)" not in witnessed and "(call 20)" in heard                  # heard it - never saw it
    assert "on the line (heard, didn't see)" in heard


def test_taken_down_mid_escape_is_not_a_surrender(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    g.enter_scene(["joey-two-knives"], g.turn_no())                             # (a fight takes in only who's here)
    enc, _ = encounters.start(g, g.turn_no(), reason="test")
    L.set_stat("kaz", "stun_damage", 99)                                          # stunned out cold as he ran
    encounters.step(g, enc, g.turn_no(), "Kaz broke for the door and Razor dropped him.", [],
                    {"razor": "actor", "kaz": "target"}, yields=[{"id": "kaz", "how": "surrendered"}])
    assert enc["sides"].get("kaz") not in encounters.GAVE_UP
    encounters.step(g, enc, g.turn_no(), "Joey threw down his knife.", [], {"joey-two-knives": "actor"},
                    yields=[{"id": "joey-two-knives", "how": "surrendered"}])
    assert enc["sides"]["joey-two-knives"] == "surrendered"                     # a real one still counts
    seen = {}

    class Writer(FakeLLM):
        def text(self, model, system, user, **kw):
            seen["system"], seen["user"] = system, user
            return "It was over fast."
    g._llm = Writer()
    encounters.end(g, enc, g.turn_no(), "it was over")
    assert "Joey Two-Knives (by the end: surrendered)" in seen["user"]
    assert "Report, don't judge" in seen["system"]


def test_who_rolls_for_what():
    """The messenger's reputation counts only when persuading; the judge judges, the doer does (a brother's lockbox)."""
    from roleplay.dm.tools import TOOLS
    assert "Who rolls, for what." in DM_SYSTEM and "Telling isn't testing" not in DM_SYSTEM
    for q in ("1. Will they engage at all?", "2. Does the thing hold up on its own?", "3. Will they act on it?"):
        assert q in DM_SYSTEM
    assert "The messenger's charm, reputation and attitude never touch that roll" in DM_SYSTEM
    assert "a locksmith \\nopening a lockbox rolls Locksmith" not in DM_SYSTEM and "rolls Locksmith" in DM_SYSTEM
    assert "use the attitude for modifiers on persuading them (never on judging evidence or doing a task" in DM_SYSTEM
    test = next(t for t in TOOLS if t["name"] == "request_test")
    assert "never the messenger's" in test["description"]
