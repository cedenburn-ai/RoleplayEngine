"""NPC gear and the engine's deadlines (2026-10-27).

Flags #33/#47: the old "professional" template gave a civilian virologist (Dr. Torvald Engstrom, T113) and a corporate
liaison (D. Adeyemi-Ross, T131) the operative block's rifle, grenade and heavy armor - and the offscreen world still sent
any template word it didn't know to that block. Now no path arms anyone by accident, and the GM can set a wrong block
right (`fix <npc>: template expert - why`).

Flag #42 (T147): R11 had locked the timeline, and the engine still pressed a Day 5 08:00 meeting and a noon deadline
(Q1, Liesl's draw).
The offscreen minds and the scene frame never saw the table's rulings, and a tension's deadline couldn't be lifted
without closing the question. Now they read TABLE RULES, `due off` lifts a deadline, `fix A#: agenda` drops a goal, and
the canon read-back lifts a deadline a ruling ruled out.
"""
import pytest

from roleplay import flags, rulings
from roleplay.dm import canon, corrections, dmblock, frame, tensions, world
from roleplay.dm.tools import TOOLS, TurnContext
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool
from .test_world import NONE, WorldLLM, _personas

EXTRACTION = {"summary": "Razor waited at the bar.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}
NOON_DAY_5 = 6480                                  # Day 5, midday (live Q1's due time)


def _block(g, *lines: str) -> TurnContext:
    ctx = TurnContext(g, g.turn_no(), g.current_scene_id())
    _, entries = dmblock.split("<dm>\n" + "\n".join(lines) + "\n</dm>")
    ctx.made = dmblock.apply(ctx, entries)
    return ctx


def _kit(L, eid) -> list[str]:
    """What they carry that hurts or protects: weapons, armor, grenades."""
    return [i["name"] for i in L.holdings(eid) if {"dv", "armor", "blast", "dv_close"} & set(i["props"])]


# ── #33/#47: no path arms a civilian ────────────────────────────────────

def test_no_template_word_hands_out_combat_kit(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    for word in (None, "", "virologist", "doctor", "professional", "PROFESSIONAL "):
        eid = sr_lite.build_npc(L, f"Someone {word!r}", word, "a person")
        assert _kit(L, eid) == [] and L.stat(eid, "firearms") == 0, word
        assert L.get(eid)["props"]["template"] in ("civilian", "expert")
    assert sr_lite.npc_template("professional") == "expert"         # (the old name reads as the word does)
    doc, _ = g.introduce("npc", "Dr. Torvald Engstrom", "gaunt human virologist", "professional", turn=1)
    assert L.get(doc)["props"]["template"] == "expert" and L.stat(doc, "logic") == 6 and _kit(L, doc) == []
    nobody, _ = g.introduce("npc", "Nurse Ama", "night nurse", turn=1)
    assert L.get(nobody)["props"]["template"] == "civilian" and _kit(L, nobody) == []
    merc, _ = g.introduce("npc", "Old Hire", "hired gun", "operative", turn=1)
    assert len(_kit(L, merc)) == 3                                    # (asked for by name, it's still the war kit)
    intro = next(t for t in TOOLS if t["name"] == "introduce")["input_schema"]["properties"]["template"]
    assert intro["enum"] == list(sr_lite.NPC_TEMPLATES) and "professional" not in intro["enum"]


def test_the_offscreen_world_never_arms_who_it_brings_in(make_game):
    """world.py fell back to the operative block for any word it didn't know (flag #33's triage: world.py:849)."""
    person = world.agent_schema()["properties"]["new_people"]["items"]["properties"]["template"]
    assert person["enum"] == list(sr_lite.NPC_TEMPLATES)             # (the model can only name a real template)
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 20))
    setup_demo(g)
    _personas(g)
    L = g.ledger
    L.leave(g.current_scene_id(), ["kaz"])
    aid = world.add_agenda(g, "kaz", "get Joey's arm looked at quietly", ["joey-two-knives"], g.turn_no(), by="dm")
    g.conn.execute("UPDATE agendas SET next_time=0")
    llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz called in some help.",
                        "on_success": "Kaz called in a virologist, a corporate liaison and a night nurse.",
                        "new_people": [
                            {"name": "Dr. Torvald Engstrom", "description": "gaunt virologist", "template": "virologist"},
                            {"name": "D. Adeyemi-Ross", "description": "corporate liaison", "template": "professional"},
                            {"name": "Nurse Ama", "description": "night nurse", "template": ""}]}
    lines = g.world_pass()
    got = {L.find(n)["id"]: L.find(n)["props"]["template"] for n in ("Dr. Torvald Engstrom", "D. Adeyemi-Ross",
                                                                    "Nurse Ama")}
    assert sorted(got.values()) == ["civilian", "civilian", "expert"]
    assert all(_kit(L, x) == [] for x in got)
    assert any("brings in Dr. Torvald Engstrom" in x and "(civilian)" in x for x in lines)
    assert "only operative comes armed" in world.AGENT_SYSTEM.lower()


def _armed_virologist(g) -> str:
    """The live record (T113): the old block's stats and kit under template 'professional', plus his own lanyard."""
    L = g.ledger
    eid = sr_lite.build_npc(L, "Dr. Torvald Engstrom", "operative", "gaunt human virologist", turn=1)
    L.update_entity(eid, props={**L.get(eid)["props"], "template": "professional"})
    lanyard = L.create_entity("item", "Dunkelzahn Institute lanyard", "a lanyard", turn=2)
    L.give(eid, lanyard)
    L.set_stat(eid, "nuyen", 4200)
    return eid


def test_the_gm_sets_a_wrong_block_right(make_game, tmp_path):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    doc = _armed_virologist(g)
    assert sr_lite.template_of(L.get(doc)) == "operative" and len(_kit(L, doc)) == 3
    with pytest.raises(LedgerError, match=r"already operative \(on file as 'professional'\)"):
        corrections.correct(g, 3, doc, "template", "operative", "x")
    ctx = _block(g, "fix dr-torvald-engstrom: template expert - a virologist, not a merc")
    assert ctx.cards == ["[FIX] Dr. Torvald Engstrom: expert, not operative (" + sr_lite.TEMPLATE_TEXT["expert"]
                         + ") - took off the assault rifle, frag grenade, full body armor - a virologist, not a merc"]
    assert [i["name"] for i in L.holdings(doc)] == ["Dunkelzahn Institute lanyard"]       # (his own things stay)
    assert L.get("dr-torvald-engstrom-s-assault-rifle")["status"] == "departed"
    s = L.stats(doc)
    assert (s["firearms"], s["close_combat"], s["stealth"], s["athletics"]) == (0, 0, 0, 0)
    assert (s["logic"], s["first_aid"], s["nuyen"]) == (6, 4, 4200) and L.get(doc)["props"]["template"] == "expert"
    assert "Assault Rifle" not in sr_lite.sheet(L, doc) and "assault rifle" not in sr_lite.sheet(L, doc)
    assert [f["kind"] for f in flags.listing(tmp_path)][-1] == "correction"
    for target, value, msg in ((doc, "expert", "already expert"), (doc, "virologist", "template: value is one of"),
                               ("razor", "expert", "isn't an NPC")):
        with pytest.raises(LedgerError, match=msg):
            corrections.correct(g, 3, target, "template", value, "x")
    guard = sr_lite.retemplate(L, sr_lite.build_npc(L, "Gate Guard", "civilian", "a gate guard"), "security")
    assert guard["from"] == "civilian" and len(guard["gave"]) == 4          # (the right block's own kit comes on)


# ── #42: the engine's deadlines answer to the table ─────────────────────

def test_due_off_lifts_a_deadline_and_keeps_the_question(make_game):
    assert tensions.parse("Will Dutch pay? | due off", 0)["due"] == tensions.LIFT
    assert tensions.parse("due none", 0) == {"main": "", "stakes": None, "due": tensions.LIFT, "next": None,
                                             "public": None, "why": "", "bad_due": ""}
    assert tensions.parse("Will Dutch pay? | due day 5 midday", 0)["due"] == NOON_DAY_5
    assert tensions.parse("due diligence pays off", 0)["main"] == "due diligence pays off"    # (story words)
    g = make_game()
    setup_demo(g)
    q = _block(g, "tension kaz, razor: Will Kaz's buyer pay by noon? | stakes 2 | due day 5 midday | "
                  "public: Kaz's buyer pays by noon on Day 5").made[0]
    g.set_clock(NOON_DAY_5 + 60)
    assert tensions.step(g, g.turn_no(), {}, set()) == [f"TENSION {q} is due: Will Kaz's buyer pay by noon?"]
    fired = tensions.get(g, q)
    assert fired["due_fired"] == 1 and fired["pressure"] == pytest.approx(tensions.RISE * 2 + tensions.DUE_JUMP)
    tensions.shelve(g, q, g.turn_no(), "the table moved on")
    ctx = _block(g, f"tension {q}: due off")
    t = tensions.get(g, q)
    assert (t["due_time"], t["due_fired"], t["status"]) == (None, 0, "shelved")     # (lifted - nothing else moved)
    assert t["pressure"] == pytest.approx(tensions.RISE * 2) and "deadline lifted" in ctx.events[-1]
    assert "DUE" not in "\n".join(tensions.packet_lines(g)) and "due" not in "".join(tensions.public_lines(g))
    assert [e["line"] for e in _block(g, f"tension {q}: due off").unplaced] == [f"tension {q}: due off"]
    q2 = _block(g, "tension kaz: Will Kaz sell the tip? | due off").made[0]       # (opened with none)
    assert tensions.get(g, q2)["due_time"] is None
    q3 = _block(g, "tension kaz: Will the Ancients come back? | due day 6 evening").made[0]
    _block(g, f"tension {q3}: Joey called it off | due off")                    # (a move that also lifts it)
    assert tensions.get(g, q3)["due_time"] is None and tensions.get(g, q3)["updated_turn"] == g.turn_no()


@pytest.mark.parametrize("line", ["due off - R11 locks the timeline", "due off (R11)", "due off per R11",
                                  "due off: R11 locks the timeline", "due none - the table ruled it out"])
def test_a_lift_with_its_reason_is_a_lift(make_game, line):
    """Review of flag #42: `tension Q1: due off - R11 locks the timeline` - the two forms the prompt shows side by side,
    combined - was read as a move: the shelved Q1 reopened, its Day 5 noon kept its place at the top of OPEN TENSIONS
    as DUE NOW, and nothing said so. It's a lift, the reason kept; the question stays shelved. So is the same lift after
    a move, and a due nothing can read is reported, never dropped in silence."""
    g = make_game()
    setup_demo(g)
    q = _block(g, "tension kaz: Will Kaz's buyer pay by noon? | due day 5 midday").made[0]
    g.set_clock(NOON_DAY_5 + 60)
    tensions.step(g, g.turn_no(), {}, set())
    tensions.shelve(g, q, g.turn_no(), "the table moved on")
    ctx = _block(g, f"tension {q}: {line}")
    t = tensions.get(g, q)
    assert (t["due_time"], t["due_fired"], t["status"]) == (None, 0, "shelved"), line
    assert "deadline lifted" in ctx.events[-1] and not ctx.unplaced
    assert "DUE" not in "\n".join(tensions.packet_lines(g))
    q2 = _block(g, "tension kaz: Will the Ancients come back? | due day 6 evening").made[0]
    _block(g, f"tension {q2}: Joey called it off | {line}")
    assert tensions.get(g, q2)["due_time"] is None
    q3 = _block(g, "tension kaz: Will the fixer call? | due day 6 evening").made[0]
    said = []
    g.out = said.append
    ctx = _block(g, f"tension {q3}: he calls | due whenever Kaz feels like it")
    assert tensions.get(g, q3)["due_time"] is not None and "due whenever" in ctx.unplaced[0]["line"]
    assert any("can't read the due 'whenever Kaz feels like it'" in s for s in said)


@pytest.mark.parametrize("line", ["tension {q}: no deadline now - R11", "tension {q}: no deadline any more (R11)",
                                  "tension {q}: deadline lifted - R11 locks the timeline",
                                  "fix {q}: due off — R11 locks the timeline", "fix {q}: due off – R11",
                                  "fix {q}: due — R11"])
def test_the_lift_in_the_cards_own_words_or_with_a_long_dash(make_game, line):
    """Review of flag #42 (2026-10-28): the `fix` card says "no deadline now", and a GM echoing it back - `tension Q1:
    no deadline now - R11` - moved the tension instead; a `fix` line whose why came after an en or em dash was
    unplaced. Each is the lift; the question stays as it was."""
    g = make_game()
    setup_demo(g)
    q = _block(g, "tension kaz: Will Kaz's buyer pay by noon? | due day 5 midday").made[0]
    ctx = _block(g, line.format(q=q))
    t = tensions.get(g, q)
    assert t["due_time"] is None and t["status"] == "open" and not ctx.unplaced, line
    assert "R11" in " ".join(ctx.events)
    assert tensions.get(g, _block(g, "tension kaz: Will the buyer show? No deadline on it yet.").made[0])["question"] \
        .startswith("Will the buyer show")                                 # (a new question saying so is still opened)


def test_the_gm_lifts_a_deadline_the_table_ruled_out(make_game, tmp_path):
    llm = FakeLLM([([tool("correct", target_id="Q2", what="due", value="off",
                         reason="R1 locks the timeline - no meeting at 08:00")], "tool_use"),
                   ([text("Nobody's watching the clock.")], "end_turn")], EXTRACTION)
    g = make_game(llm)
    setup_demo(g)
    q1 = tensions.open_tension(g, "Will Bo's mother sell him before Friday noon?", ["kaz"], 1, due=NOON_DAY_5,
                               public="Bo's mother has until Friday to answer")
    q2 = tensions.open_tension(g, "Will Rook make the 08:00 meeting?", ["kaz"], 1, due=NOON_DAY_5 - 240)
    assert (q1, q2) == ("Q1", "Q2")
    ctx = _block(g, f"fix {q1}: due off - R1 locks the timeline")
    assert ctx.cards == [f"[FIX] {q1} (Bo's mother has until Friday to answer): no deadline now (it was Day 5, "
                         "midday) - the question stays open - R1 locks the timeline"]
    assert tensions.get(g, q1)["due_time"] is None and tensions.get(g, q1)["status"] == "open"
    assert _block(g, f"fix {q1}: due off - again").unplaced                  # (nothing to lift: no card)
    res = g.run_turn([("razor", "I wait at the bar.")])                       # the correct tool, in a turn
    assert any(c.startswith(f"[FIX] {q2}: no deadline now (it was Day 5, morning)") for c in res.cards)
    tensions.resolve(g, q1, g.turn_no(), "settled")
    for args, msg in (((q1, "due", "off"), "resolved"), (("Q9", "due", "off"), "No tension Q9"),
                      ((q2, "due", "day 6"), "value off lifts")):
        with pytest.raises(LedgerError, match=msg):
            corrections.correct(g, 9, *args, "x")
    lever = next(t for t in TOOLS if t["name"] == "correct")["input_schema"]["properties"]["what"]
    assert {"due", "agenda", "template"} <= set(lever["enum"])


def test_the_gm_drops_a_goal_the_table_ruled_out(make_game):
    g = make_game()
    setup_demo(g)
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    aid = world.add_agenda(g, "kaz", "Meet Magic at Low Wharf at 08:00 on Day 5", ["razor"], 1, by="world")
    ctx = _block(g, f"fix {aid}: agenda - R1 rules out the 08:00 meeting")
    assert ctx.cards == [f"[FIX] {aid} dropped - nobody pursues it offscreen now - R1 rules out the 08:00 meeting"]
    assert g.conn.execute("SELECT status FROM agendas WHERE id=?", (aid,)).fetchone()[0] == "dropped"
    g.conn.execute("UPDATE agendas SET next_time=0")
    assert world.agendas_of(g, "kaz") == []
    with pytest.raises(LedgerError, match="already dropped"):
        corrections.correct(g, 3, aid, "agenda", None, "x")


def test_the_offscreen_minds_and_the_frame_read_the_table_rules(make_game):
    llm = WorldLLM()
    g = make_game(llm)
    setup_demo(g)
    _personas(g)
    sid = g.current_scene_id()
    assert rulings.table_rules(g) == [] and "TABLE RULES" not in frame.gather(g, sid)["text"]
    rulings.add(g, "Timeline lock: no deadlines but the GM's own - there is no 08:00 meeting at Low Wharf.", "gm")
    g.ledger.leave(sid, ["kaz"])
    world.add_agenda(g, "kaz", "Get Magic to Low Wharf by 08:00", ["razor"], g.turn_no(), by="world")
    g.conn.execute("UPDATE agendas SET next_time=0")
    job = next(j for j in world.plan(g) if j.kind == "agent" and j.npc == "kaz")
    assert "=== TABLE RULES" in job.user and "[R1] Timeline lock: no deadlines" in job.user
    assert job.user.index("TABLE RULES") < job.user.index("YOUR AGENDAS")    # (above what it outranks)
    assert "never plan around a time or deadline they rule out" in world.AGENT_SYSTEM.lower()
    text_ = frame.gather(g, sid)["text"]
    assert "=== TABLE RULES" in text_ and "[R1] Timeline lock" in text_
    assert text_.index("TABLE RULES") < text_.index("EVERYONE IN THE ROOM")
    assert "TABLE RULES ruled out" in frame.SYSTEM


def test_the_read_back_lifts_a_deadline_a_ruling_ruled_out(make_game):
    g = make_game()
    setup_demo(g)
    q = tensions.open_tension(g, "Will Juno answer Osprey by Friday noon?", ["kaz"], 1, due=NOON_DAY_5)
    open_q = tensions.open_tension(g, "Who is Kaz's buyer?", ["kaz"], 1)
    rulings.add(g, "Timeline lock: no other deadlines.", "gm")
    gathered = canon.gather(g)
    assert "DEADLINES THE ENGINE HOLDS" in gathered["text"] and f"[{q}] due Day 5, midday: Will Juno" in gathered["text"]
    assert q in gathered["items"] and open_q not in gathered["items"]
    data = {k: [] for k in ("settled", "people", "holdings", "timeline", "upcoming", "open_threads", "closed_threads",
                            "conflicts", "rulings")}
    data["over"] = [{"id": q, "why": "R1 locks the timeline"}, {"id": open_q, "why": "(no deadline - not shown)"}]
    res = canon.apply(g, gathered, data)
    assert res["retired"] == [f"{q}'s deadline (R1 locks the timeline)"]
    t = tensions.get(g, q)
    assert t["due_time"] is None and t["status"] == "open"                   # (the question stays)
    logged = g.conn.execute("SELECT payload FROM events WHERE kind='retired' ORDER BY seq DESC LIMIT 1").fetchone()[0]
    assert '"what": "deadline"' in logged and f'"id": "{q}"' in logged
    assert "due off" in canon.ENGINE_RULES and "timeline lock" in canon.ENGINE_RULES
    assert "DEADLINE a table ruling ruled out" in canon.SYSTEM


# ── review 2026-10-27: the package's own gaps ───────────────────────────

def _empty_canon(**over) -> dict:
    data = {k: [] for k in ("settled", "people", "holdings", "timeline", "upcoming", "open_threads", "closed_threads",
                            "conflicts", "rulings", "over")}
    return {**data, **over}


def test_a_goal_closed_while_the_world_thought_stays_closed(make_game):
    """Discord runs plan on the game thread, think off it, then apply: a turn that runs in between can drop the goal
    (`fix A71: agenda`, the live R27 case), and the apply set it back to 'active' and ran its step and hook."""
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 20))
    setup_demo(g)
    _personas(g)
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    aid = world.add_agenda(g, "kaz", "Find Bo a safe place before Thursday", ["razor"], g.turn_no(), by="world")
    g.conn.execute("UPDATE agendas SET next_time=0")
    jobs = [j for j in world.plan(g) if j.kind == "agent" and j.npc == "kaz"]
    assert jobs and jobs[0].agendas == [aid]
    assert corrections.correct(g, g.turn_no(), aid, "agenda", None, "R27 closed Osprey").startswith(f"[FIX] {aid}")
    step = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz asked around for a safe house.",
            "on_success": "Kaz found a room above the noodle bar.", "hook": "Kaz will call Razor about the room.",
            "hook_about": ["razor"], "contacts": [{"who": "Benny Farrow", "kind": "npc", "says": "Got a room?",
                                                   "shares": [], "description": "a landlord", "template": "civilian"}]}
    out = world.apply_all(g, jobs, [step])
    row = g.conn.execute("SELECT status, steps FROM agendas WHERE id=?", (aid,)).fetchone()
    assert (row["status"], row["steps"]) == ("dropped", 0)                        # (no step ran)
    assert out == [f"[WORLD] Kaz: {aid} was dropped while they thought - left alone"]
    assert g.conn.execute("SELECT COUNT(*) FROM hooks").fetchone()[0] == 0 and g.ledger.find("Benny Farrow") is None
    # a read-back retiring it meanwhile (status done) keeps it done too - a "drop" or a wait never rewrites it
    aid2 = world.add_agenda(g, "kaz", "Meet Rook at 08:00", ["razor"], g.turn_no(), by="world")
    g.conn.execute("UPDATE agendas SET next_time=0")
    jobs = [j for j in world.plan(g) if j.kind == "agent" and j.npc == "kaz"]
    assert jobs and jobs[0].agendas == [aid2]
    world.retire(g, [{"id": aid2, "why": "R20: no 08:00"}], g.turn_no())
    for d in ({**NONE, "decision": "drop", "agenda_id": aid2}, {**NONE, "decision": "continue", "agenda_id": aid2}):
        world.apply_all(g, jobs, [d])
        assert tuple(g.conn.execute("SELECT status, next_time FROM agendas WHERE id=?", (aid2,)).fetchone()) == (
            "done", 0)


def test_a_retemplate_keeps_how_hurt_they_are(make_game):
    """The monitor follows Body: kept box for box, the operative block's wounded virologist (10 of 11) read dying on the
    expert's 9 and bled out, and 12 boxes (dying) read dead - from a paperwork fix, with nothing on the card."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    op, ex = (5, 5), (2, 4)                                     # (Body, Willpower): operative, expert
    assert sr_lite.carry_wounds(0, 0, op, ex) == (0, 0) and sr_lite.carry_wounds(10, 3, op, ex) == (8, 3)
    assert sr_lite.carry_wounds(11, 0, op, ex) == (9, 0)                           # full: still out
    assert sr_lite.carry_wounds(12, 0, op, ex) == (10, 0) and sr_lite.carry_wounds(16, 0, op, ex) == (11, 0)  # dying
    assert sr_lite.carry_wounds(17, 0, op, ex) == (17, 0)                          # dead stays dead
    assert sr_lite.carry_wounds(10, 9, (2, 2), op) == (12, 11)                     # a dying, stunned civilian: still so
    assert sr_lite.carry_wounds(5, 4, (2, 2), op) == (5, 4)                        # (a bigger monitor heals nothing)
    for boxes, state in ((10, "wounded"), (11, "unconscious"), (12, "dying"), (17, "dead")):
        doc = sr_lite.build_npc(L, f"Dr. Hurt {boxes}", "operative", "a virologist")
        L.update_entity(doc, props={**L.get(doc)["props"], "template": "professional"})
        L.set_stat(doc, "physical_damage", boxes)
        assert sr_lite.condition(L, doc) == state
        line = corrections.correct(g, 5, doc, "template", "expert", "a virologist")
        assert sr_lite.condition(L, doc) == state, boxes
        assert f" - still {state} (Physical {int(L.stat(doc, 'physical_damage'))}/9, Stun 0/10) - a virologist" in line
    res = sr_lite.retemplate(L, sr_lite.build_npc(L, "Unhurt Guard", "civilian", "a guard"), "security")
    assert (res["condition"], res["wounds"]) == ("ok", None)


def test_a_retemplate_leaves_what_they_picked_up_off_someone_else(make_game):
    """The match was any "<someone>'s <block gear>": a rifle looted off another merc went too (the live Sprocket carries
    Pastor Garvey's armor vest and nine Crows' pistols). Block gear carries who it was made for now; an older item
    goes by its owner's name, or one they had before (a rename keeps it as an alias)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    a = sr_lite.build_npc(L, "Merc A", "operative", "a merc")
    b = sr_lite.build_npc(L, "Merc B", "operative", "a merc")
    rifle_b = next(i for i in L.holdings(b) if i["description"] == "assault rifle")
    assert rifle_b["props"]["made_for"] == b and "made_for" not in sr_lite.sheet(L, rifle_b["id"])
    L.take(b, rifle_b["id"], 1)
    L.give(a, rifle_b["id"], 1)                                # A picked it up in the story
    res = sr_lite.retemplate(L, a, "expert", 3)
    assert res["took"] == ["Merc A's assault rifle", "Merc A's frag grenade", "Merc A's full body armor"]
    assert [i["id"] for i in L.holdings(a)] == [rifle_b["id"]] and L.get(rifle_b["id"])["status"] == "active"
    line = corrections.correct(g, 3, b, "template", "expert", "not a merc")
    assert "Merc A" not in line and "frag grenade" in line
    # an older record: block items with no mark, one of them looted off another NPC, and a renamed owner
    c = sr_lite.build_npc(L, "Old Merc", "security", "a guard")
    for i in L.holdings(c):
        L.update_entity(i["id"], props={k: v for k, v in i["props"].items() if k != "made_for"})
    loot = L.create_entity("item", "Pastor Garvey's armor vest", "armor vest", tier=0, props={"armor": 4})
    L.give(c, loot)
    from roleplay.dm import speakers
    speakers.rename(g, c, "Sergeant Danjuma")
    took = sr_lite.retemplate(L, c, "civilian")["took"]
    assert sorted(took) == ["Old Merc's armor vest", "Old Merc's flash-bang", "Old Merc's security pistol",
                            "Old Merc's stun baton"] and [i["id"] for i in L.holdings(c)] == [loot]


def test_someone_new_the_world_reaches_is_built_for_who_they_are(make_game):
    """`contacts` brought every new person in on the armed 'contact' block - 24 live, a night nurse and a legal-aid
    advocate among them, each with a hold-out pistol. Now a new contact has a template like new_people."""
    contact = world.agent_schema()["properties"]["contacts"]["items"]
    assert contact["properties"]["template"]["enum"] == list(sr_lite.NPC_TEMPLATES) and "template" in contact["required"]
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 20))
    setup_demo(g)
    _personas(g)
    L = g.ledger
    L.leave(g.current_scene_id(), ["kaz"])
    aid = world.add_agenda(g, "kaz", "find out who's sick", [], g.turn_no(), by="world")
    g.conn.execute("UPDATE agendas SET next_time=0")

    def reach(who, description, template):
        return {"who": who, "kind": "npc", "says": f"Kaz asked {who} about the fever.", "shares": [],
                "description": description, "template": template}
    llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz made some calls.",
                        "on_success": "Kaz called around about the fever.",
                        "contacts": [reach("Dr. Mara Wen", "hospital virologist", "expert"),
                                     reach("Noor Hallett", "night nurse", "medic"),
                                     reach("Benny Farrow", "a fixer who brokers clinic beds", "contact")]}
    lines = g.world_pass()
    got = {n: L.find(n)["props"]["template"] for n in ("Dr. Mara Wen", "Noor Hallett", "Benny Farrow")}
    assert got == {"Dr. Mara Wen": "expert", "Noor Hallett": "civilian", "Benny Farrow": "contact"}
    assert _kit(L, L.find("Dr. Mara Wen")["id"]) == [] and _kit(L, L.find("Noor Hallett")["id"]) == []
    assert any("reaches someone new: Dr. Mara Wen [dr-mara-wen] (expert)" in x for x in lines)
    job = next(u for k, u in llm.world_calls if k == "agent" and "Kaz [kaz]" in u)
    assert "TEMPLATES for new_people and someone new you contact" in job
    assert "contact is only a fixer, informant or broker" in world.AGENT_SYSTEM


def test_a_timeline_lock_is_never_called_built_in(make_game):
    """ENGINE_RULES told the read-back a timeline lock "is built in", and `!rulings tidy` drops what it calls built in -
    but the engine keeps no list of ruled-out times: the ruling, read as TABLE RULES, is the only thing that holds it."""
    g = make_game()
    setup_demo(g)
    narrative_time = canon.ENGINE_RULES.split("- Narrative time:")[1].split("\n- ")[0]
    assert "is built in" not in narrative_time and "never built_in" in narrative_time
    assert "keep it while its times are still ahead" in narrative_time and "stale once" in narrative_time
    assert "A timeline lock or a closed storyline is never built_in" in canon.SYSTEM
    rulings.add(g, "There is no 08:00 Low Wharf deadline on Day 5.", "gm")
    assert "never built_in" in canon.gather(g)["text"]                  # (what the read-back is shown)


def test_the_read_back_leaves_a_deadline_moved_while_it_read(make_game):
    """canon runs gather, then minutes of think while turns go on, then apply: a deadline the GM moved in between was
    lifted by the stale verdict - and after an undo, a Q# handed out again for another question would be too."""
    g = make_game()
    setup_demo(g)
    q = tensions.open_tension(g, "Will Juno answer by Friday noon?", ["kaz"], 1, due=NOON_DAY_5)
    q2 = tensions.open_tension(g, "Will Rook make the 08:00?", ["kaz"], 1, due=NOON_DAY_5 - 240)
    rulings.add(g, "Timeline lock: no other deadlines.", "gm")
    gathered = canon.gather(g)
    assert gathered["deadlines"] == {q: ["Will Juno answer by Friday noon?", NOON_DAY_5],
                                     q2: ["Will Rook make the 08:00?", NOON_DAY_5 - 240]}
    _block(g, f"tension {q}: Juno called - she answers at the Day 6 meet | due day 6 evening")
    new_due = tensions.get(g, q)["due_time"]
    assert new_due not in (None, NOON_DAY_5)
    res = canon.apply(g, gathered, _empty_canon(over=[{"id": q, "why": "R1"}, {"id": q2, "why": "R1"}]))
    assert tensions.get(g, q)["due_time"] == new_due and tensions.get(g, q2)["due_time"] is None
    assert res["retired"] == [f"{q2}'s deadline (R1)"] and res["deadlines_moved"] == [f"{q}'s deadline"]
    assert f"DEADLINES MOVED WHILE IT READ (not lifted - the GM's move stands)\n- {q}'s deadline" in canon.render(
        canon.current(g))
    g.conn.execute("UPDATE tensions SET question='Will Lim fold?', due_time=? WHERE id=?", (NOON_DAY_5, q))
    assert canon.apply(g, gathered, _empty_canon(over=[{"id": q, "why": "R1"}]))["retired"] == []
    assert tensions.get(g, q)["due_time"] == NOON_DAY_5                          # (another question by that Q#)


def test_a_jobs_deadline_can_be_lifted(make_game, tmp_path):
    """THE JOB's deadline is one the engine holds - the packet tells the GM to keep deadlines consistent with it - and
    nothing reached it: no lever, an update's "" keeps it, and the read-back never saw the jobs table."""
    from roleplay import jobs
    g = make_game()
    setup_demo(g)
    t = g.turn_no()
    job = {"id": "", "client": "kaz", "objective": "get the chip to Kaz", "pay": "2,000", "progress": "",
           "title": "The Low Wharf drop"}
    jobs.apply(g, t, [{**job, "change": "active", "deadline": "deliver by Day 5 08:00"},
                      {**job, "change": "new", "title": "Bo's white-room transport", "deadline": "Day 4 23:00"}])
    assert [j["deadline"] for j in jobs.open_jobs(g)] == ["deliver by Day 5 08:00", "Day 4 23:00"]
    rulings.add(g, "Timeline lock: no 08:00 deadline, no other deadlines.", "gm")
    ctx = _block(g, "fix J1: due off - R1 rules out the 08:00")
    assert ctx.cards == ['[FIX] J1 (The Low Wharf drop): no deadline now (it was "deliver by Day 5 08:00") - the '
                         "job stays active - R1 rules out the 08:00"]
    assert jobs.get(g, "J1")["deadline"] == "" and jobs.get(g, "J1")["status"] == "active"
    assert "deadline:" not in jobs.packet_lines(g)[1] and [f["kind"] for f in flags.listing(tmp_path)][-1] == "correction"
    assert _block(g, "fix J1: due off - again").unplaced                     # (nothing to lift: no card)
    for args, msg in ((("J9", "due", "off"), "No job J9"), (("J2", "due", "day 6"), "value off lifts")):
        with pytest.raises(LedgerError, match=msg):
            corrections.correct(g, t, *args, "x")
    gathered = canon.gather(g)
    assert '[J2] the job "Bo\'s white-room transport" - deadline: Day 4 23:00' in gathered["text"]
    assert "J2" in gathered["items"] and "J1" not in gathered["items"]
    res = canon.apply(g, gathered, _empty_canon(over=[{"id": "J2", "why": "R1 locks the timeline"}]))
    assert res["retired"] == ["J2's deadline (R1 locks the timeline)"] and jobs.get(g, "J2")["deadline"] == ""
    jobs.apply(g, t, [{**job, "id": "J1", "change": "done", "deadline": "", "title": ""}])
    with pytest.raises(LedgerError, match="J1 is done"):
        corrections.correct(g, t, "J1", "due", "off", "x")
    lever = next(x for x in TOOLS if x["name"] == "correct")["input_schema"]["properties"]["target_id"]["description"]
    assert "J#" in lever and "J#" in corrections.WHAT["due"]
