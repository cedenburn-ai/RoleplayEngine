"""A roll the player calls is a roll; talk about the GM isn't a move; a turn redone again and again gets flagged; NPC
templates say what they are. (Live, T151-T158: the GM had Brask roll - or rolled nothing - for Magic's declared pitch
five times running; a remark about the DM was played as Magic speaking; a virologist got an assault rifle.)"""
import asyncio

from roleplay import chargen as C
from roleplay import flags
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import aside, tools
from roleplay.dm.turn import edge_asks, roll_asks
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import magic, matrix, sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool
from .test_discord import FakeChannel

COMMIT = {"summary": "Razor bluffed Kaz.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}


def test_a_roll_the_player_calls_gets_made(make_game, tmp_path):
    llm = FakeLLM([([text("Kaz buys it without a second look.")], "end_turn"),          # no roll: sent back
                   ([tool("request_test", actor_id="razor", skill="con", threshold=2, reason="the bluff",
                          edge="if_short")], "tool_use"),                              # (their Edge, as they said it)
                   ([text("Kaz squints, then buys it.")], "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    res = g.run_turn([("razor", "Razor bluffs Kaz about the chip. I roll Con, Edge if I miss.")])
    assert res.narration == "Kaz squints, then buys it." and any(c.startswith("[ROLL] Razor: Con") for c in res.cards)
    assert any(f["kind"] == "skipped a roll" for f in flags.listing(tmp_path))


def test_an_npc_in_the_room_doesnt_take_the_roll(make_game):
    llm = FakeLLM([([tool("request_test", actor_id="kaz", skill="negotiation", threshold=2, reason="Kaz pitches")],
                    "tool_use"),
                   ([text("Kaz makes the pitch for him.")], "end_turn"),                 # Razor never rolled: back
                   ([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="Razor's pitch",
                          helpers=[{"id": "kaz"}])], "tool_use"),
                   ([text("Razor makes the pitch, Kaz backing him.")], "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    res = g.run_turn([("razor", "Razor makes this roll to convince the fixer, Kaz helping (teamwork).")])
    assert res.narration == "Razor makes the pitch, Kaz backing him."
    assert any(c.startswith("[ROLL] Razor: Negotiation") and "Team" in c for c in res.cards)


def test_only_asked_for_rolls_count(make_game):
    g = make_game()
    setup_demo(g)
    assert roll_asks(g, [("razor", "I walk to the bar and order a drink.")]) == {}
    assert roll_asks(g, [("razor", "((I'll roll later))")]) == {}
    asked = roll_asks(g, [("razor", "Razor pushes the limit on the shot.")])
    assert list(asked) == ["razor"] and "pushes the limit" in asked["razor"][1]
    assert "attack" in tools.ROLLERS and "target_id" in tools.ROLLERS["attack"]       # (a dodge counts as their roll)


def test_talk_about_the_gm_is_an_aside(make_game):
    asked = []

    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            asked.append(user)
            return {"answer": "Fair - I'll keep Juno's custody settled.", "direction": "", "fixes": [], "is_move": False}
        return COMMIT
    g = make_game(FakeLLM([], structured))
    setup_demo(g)
    assert aside.ABOUT_GM.search("That's what I meant - the DM ignored it again") and not aside.ABOUT_GM.search(
        "I hack the security system")

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "Alice", "!join razor", False, react)
        await t.handle("1", "Alice", "That is what I was talking about. The DM basically ignored it.", False, react)
        assert ch.sent[-1]["title"] == "🎙️ GM aside - to Alice" and t.director.queue == [] and asked
        await t.close()
    asyncio.run(go())


def test_a_turn_redone_again_and_again_gets_flagged(make_game, tmp_path):
    g = make_game(FakeLLM([], COMMIT))
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        for i in range(3):
            g.run_turn([("razor", f"Razor tries the pitch, take {i + 1}.")])
            await t.handle("9", "Owner", "!undo", True, react)
        flagged = [f for f in flags.listing(tmp_path) if f["kind"] == "redo loop"]
        assert len(flagged) == 1 and "undone 3 times" in flagged[0]["text"] and "take 3" in flagged[0]["text"]
        await t.close()
    asyncio.run(go())


def test_npc_templates_say_what_they_are(make_game):
    g = make_game()
    setup_demo(g)
    doc, _ = g.introduce("npc", "Dr. Marit Vandermeer", "elderly virologist", "expert", turn=1)
    assert not [i for i in g.ledger.holdings(doc) if "dv" in i["props"] or i["props"].get("armor")]
    assert g.ledger.stat(doc, "logic") == 6
    # the old name reads as the word does - a professional person (flags #33/#47: it armed a virologist again)
    pro, _ = g.introduce("npc", "Dr. Torvald Engstrom", "gaunt human virologist", "professional", turn=1)
    assert g.ledger.get(pro)["props"]["template"] == "expert" and not g.ledger.holdings(pro)
    merc, _ = g.introduce("npc", "Old Hire", "hired gun", "operative", turn=1)
    assert g.ledger.get(merc)["props"]["template"] == "operative"
    assert "professional" not in sr_lite.NPC_TEMPLATES and "expert" in sr_lite.TEMPLATE_TEXT


class SeeingLLM(FakeLLM):
    """A FakeLLM that keeps the conversation, so a test can read the tool results the GM got back."""

    def dm_step(self, system, tools, messages, progress=None):
        self.seen = messages
        return super().dm_step(system, tools, messages, progress)

    def results(self):
        return [b for m in self.seen if m["role"] == "user" and isinstance(m["content"], list)
                for b in m["content"] if b.get("type") == "tool_result"]


def _finch(g):
    """A mage with a player ('finch') who knows Physical Barrier."""
    mage = g.create_pc("Finch", "mage", "finch")
    ent = g.ledger.get(mage)
    g.ledger.update_entity(mage, props={**ent["props"], "spells": magic.known(g.ledger, mage) + ["physical barrier"]})
    return mage, sr_lite.build_pool(g.ledger, mage, "sorcery")[0]


def test_a_called_edge_rides_on_the_roll(make_game, tmp_path):
    """Live T164 (flag #64): "uses edge to reroll fails" - nothing checked that the Edge reached the cast. A roll that
    leaves it out is turned away once, before the dice, and the GM passes it as the player said it."""
    barrier = dict(caster_id="finch", spell="Physical Barrier", force=8, reason="the bikes")
    llm = SeeingLLM([([tool("cast", **barrier)], "tool_use"),
                     ([tool("cast", **barrier, edge="reroll")], "tool_use"),
                     ([text("The barrier snaps up between Finch and the bikes.")], "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    mage, n = _finch(g)
    g.dice = ScriptedDice([5] * 4 + [2] * (n - 4) + [5] * (n - 4))
    res = g.run_turn([("finch", "Finch casts Physical Barrier at Force 8 and uses edge to reroll fails.")])
    first, second = llm.results()
    assert first["is_error"] and "uses edge to reroll fails" in first["content"] and "edge='reroll'" in first["content"]
    assert "Nothing was rolled" in first["content"] and not second.get("is_error")
    casts = [e for e in g.ledger.events(res.turn_id) if e["kind"] == "cast"]
    assert len(casts) == 1 and casts[0]["payload"]["hits"] == 8                     # (the reroll, capped at the Force)
    assert int(g.ledger.stat(mage, "edge_points")) == 2 and any("second chance" in c for c in res.cards)
    assert not [f for f in flags.listing(tmp_path) if f["kind"] == "tool error"]  # a reminder isn't a bug report


def test_edge_none_for_a_branch_not_taken(make_game, tmp_path):
    """Live T174: the Edge rode the Manabolt branch; the barrier branch happened. edge='none' says so - no reminder,
    no point spent."""
    llm = SeeingLLM([([tool("cast", caster_id="finch", spell="Physical Barrier", force=5, reason="bikes at speed",
                            edge="none")], "tool_use"),
                     ([text("The barrier takes the first bike head on.")], "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    mage, _ = _finch(g)
    res = g.run_turn([("finch", "If the bikes come at speed Finch throws up a Physical Barrier; if not, Manabolt at "
                               "Force 6 and uses edge to reroll 6s.")])
    assert [r.get("is_error") for r in llm.results()] == [None]
    assert int(g.ledger.stat(mage, "edge_points")) == 3
    assert any(e["kind"] == "cast" for e in g.ledger.events(res.turn_id))
    assert not any(e["kind"] == "edge" for e in g.ledger.events(res.turn_id))


def test_edge_asks_classify_the_call(make_game):
    g = make_game()
    setup_demo(g)

    def mode(post):
        asked = edge_asks(g, [("razor", post)])
        return asked["razor"][1] if asked else "no ask"
    assert mode("Razor casts it at Force 8 and uses edge to reroll fails.") == "reroll"                  # T164
    assert mode("Still uses edge to reroll misses.") == "reroll"                                        # T165
    assert mode("Razor shoots, using edge to have 6's reroll") == "push"                                # T172
    assert mode("I roll Con, Edge if I miss.") == "if_short"
    assert mode("He'll use edge to reroll misses if needed") == "if_short"                              # T155
    assert mode("Razor pushes the limit on the shot.") == "push"
    assert mode("Razor pushes it open and uses edge to reroll misses.") == "reroll"     # (the door isn't the Edge)
    assert mode("Razor spends a point of Edge on the dodge.") is None                   # called, mode not said
    assert "uses edge to reroll fails" in edge_asks(g, [("razor", "Razor casts it at Force 8 and uses edge to reroll "
                                                                  "fails.")])["razor"][2]
    for prose in ("Razor pushes it open and walks in.", "He stands on the edge of the roof.",
                  "He gives them a second chance to surrender.", "Razor creeps to the edge to look down.",
                  "The other focus on edge with dam", "((I'll use edge to reroll later))", "Razor burns edge to live"):
        assert mode(prose) == "no ask", prose


def test_the_edge_check_refuses_once_and_files_no_bug(make_game, tmp_path):
    """The wrong mode is turned away naming the right one; a second try goes through either way; a refusal counts as
    no tool error and files no flag; an NPC's attack on a PC who called Edge needs their dodge/soak Edge; and on the
    last tool step nothing is checked (the GM couldn't redo the roll)."""
    g = make_game(dice=ScriptedDice([]))
    setup_demo(g)
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    ctx.edge_asks = {"razor": ("Razor", "reroll", "uses edge to reroll fails")}
    look = {"actor_id": "razor", "skill": "perception", "threshold": 2, "reason": "look"}
    out = tools.run_tool(ctx, tool("request_test", **look, edge="if_short"))
    assert out["is_error"] and "which is 'reroll'" in out["content"] and "'if_short'" in out["content"]
    assert ctx.tool_errors == 0 and not flags.listing(tmp_path) and not g.ledger.events(5)    # nothing rolled
    out = tools.run_tool(ctx, tool("request_test", **look))                     # once a turn: now it goes through
    assert not out.get("is_error") and "razor" in ctx.rolled
    ctx = tools.TurnContext(g, 6, g.current_scene_id())
    ctx.edge_asks = {"razor": ("Razor", None, "spends a point of Edge on the dodge")}
    out = tools.run_tool(ctx, tool("attack", attacker_id="joey-two-knives", target_id="razor", reason="knife"))
    assert out["is_error"] and "defense_edge or soak_edge" in out["content"]
    assert "mode their words mean" in out["content"]
    assert "'reroll'" not in out["content"]                                      # (never a mode it couldn't read)
    ctx = tools.TurnContext(g, 6, g.current_scene_id())                          # on a soak, insurance = a reroll
    ctx.edge_asks = {"razor": ("Razor", "if_short", "Edge on the soak if it hurts")}
    out = tools.run_tool(ctx, tool("attack", attacker_id="joey-two-knives", target_id="razor", reason="knife",
                                   soak_edge="reroll"))
    assert not out.get("is_error") and "razor" in ctx.edge_settled
    ctx = tools.TurnContext(g, 7, g.current_scene_id())
    ctx.edge_asks = {"razor": ("Razor", "reroll", "uses edge to reroll fails")}
    ctx.steps = g.settings.models.dm_max_steps
    assert not tools.run_tool(ctx, tool("request_test", **look)).get("is_error")


def _mode(g, post, handle="razor"):
    asked = edge_asks(g, [(handle, post)])
    return asked[handle][1] if handle in asked else "no ask"


def test_edge_called_for_another_pc_isnt_the_posters(make_game):
    """Live T172: a player wrote "...and filamet spends edge so his 6's go again", and the call went down as Magic's - a
    roll of Magic's without Edge would have been refused and the GM told to push Magic's point (R14: Edge only on the
    spender's own roll). Whose Edge it is, is the subject's; a call for someone else's character is left out."""
    g = make_game(dice=ScriptedDice([]))
    setup_demo(g)
    for name in ("Magic", "Filament", "Quiet Lou"):
        g.create_pc(name, "street_samurai", name.lower().replace(" ", "-"))
    assert _mode(g, "Razor watches the door. Ghost uses edge to reroll 6's on his hack.") == "no ask"
    assert _mode(g, "Razor covers the door. Ghost shoots the ganger, using edge to have 6's reroll.") == "no ask"
    assert _mode(g, "I cover the door while Ghost spends a point of edge on the shot.") == "no ask"
    assert _mode(g, "Using edge to reroll misses, Ghost hacks the node.") == "no ask"
    assert _mode(g, "Ghost's edge on the hack, Razor watches.") == "no ask"
    assert _mode(g, "Kaz uses edge to reroll his misses.") == "no ask"                 # (an NPC's isn't Razor's)
    # the poster's own call keeps its mode beside someone else's
    assert _mode(g, "Razor uses edge to reroll misses on the shot. Ghost uses edge to reroll 6's on his hack.") == "reroll"
    assert _mode(g, "Razor shoots at Joey and uses edge to reroll misses.") == "reroll"   # (Joey is the target)
    assert _mode(g, "Kaz watches as Razor uses edge to bluff past the guard.") is None
    assert _mode(g, "Joey draws on Razor, who uses edge on the dodge.") is None
    assert _mode(g, "Razor's Edge on the soak.") is None
    assert _mode(g, "When Ghost jacks in, I'll use edge to reroll misses on the soak.") == "reroll"
    t172 = "Lou throws a knife at the same guy and filamet uses edge to reroll his 6's on it"   # (T172's shape)
    assert _mode(g, "Magic casts a force 6 stunbolt at the ganger boss, using edge to have 6's reroll. " + t172,
                 "magic") == "push"
    assert _mode(g, "Magic casts a force 6 stunbolt at the ganger boss. " + t172, "magic") == "no ask"
    assert _mode(g, "Filament trys the login at the desk terminal with brask's codes. He will push edge on this roll.",
                 "magic") == "no ask"                                    # (live T93's shape: 'he' is Filament)
    assert _mode(g, "Magic - Alice's character - makes this roll to talk her round. He'll use edge to reroll "
                    "misses if needed", "magic") == "if_short"           # (live T155's shape: 'he' is Magic)
    ctx = tools.TurnContext(g, 5, g.current_scene_id())                  # Joey's swing at Razor needs none of it
    ctx.edge_asks = edge_asks(g, [("razor", "Razor holds the door. Ghost shoots Joey, using edge to reroll misses.")])
    out = tools.run_tool(ctx, tool("attack", attacker_id="joey-two-knives", target_id="razor", reason="knife"))
    assert not ctx.edge_asks and not out.get("is_error")


def test_story_words_arent_edge(make_game):
    """Prose isn't a call: a place's edge ("the roof's edge for the shot", review), an edge in the voice, someone's
    edge as what they are, a declined Edge ("not using edge this time") - and a grenade that explodes doesn't make a
    called reroll a push. Each used to turn the PC's roll away, telling the GM to spend a point nobody called."""
    g = make_game(dice=ScriptedDice([]))
    setup_demo(g)
    for prose in ("Razor lies prone at the roof's edge for the shot.", "Razor settles on the cliff edge for the shot.",
                  "Razor crouches at the rooftop edge for the throw.", "She adds an edge to her voice for the con.",
                  "Razor uses his edge as a street samurai to stare him down.", "Razor goes to the edge for a shot.",
                  "Razor casts Manabolt, not using edge this time.", "Razor doesn't use edge on the drain.",
                  "I won't spend edge on this one, reroll misses is for later.", "Razor shoots without using edge.",
                  "Razor never uses edge on drain", "Razor shoots Joey - not using edge this time."):
        assert _mode(g, prose) == "no ask", prose
    assert _mode(g, "Razor doesn't flinch and uses edge to reroll misses.") == "reroll"    # (the 'not' is the flinch's)
    assert _mode(g, "Razor puts his edge on the dodge.") is None
    assert _mode(g, "Razor uses edge as insurance on the dodge.") == "if_short"
    assert _mode(g, "Razor uses edge to reroll his misses on the soak as the grenade explodes.") == "reroll"
    assert _mode(g, "When the grenade explodes Razor uses edge to reroll misses on the soak.") == "reroll"
    assert _mode(g, "Razor uses edge for exploding 6s on the shot.") == "push"
    assert _mode(g, "Razor uses edge to explode the dice.") == "push"
    shot = {"attacker_id": "razor", "target_id": "joey-two-knives", "reason": "the shot"}
    for prose in ("Razor lies prone at the roof's edge for the shot, waiting for Joey to show.",
                  "Razor shoots Joey - not using edge this time."):
        ctx = tools.TurnContext(g, 5, g.current_scene_id())
        ctx.edge_asks = edge_asks(g, [("razor", prose)])
        assert not ctx.edge_asks and not tools.run_tool(ctx, tool("attack", **shot)).get("is_error")
    assert not roll_asks(g, [("razor", "Razor lies prone at the roof's edge for the shot.")])   # (no roll guard)
    L = g.ledger                                                         # the GM's right call on the blast goes through
    can = L.create_entity("item", "Joey's frag grenade", "", props=dict(C.CATALOG["frag-grenade"]["props"]), turn=1)
    L.give("joey-two-knives", can, 1)
    ctx = tools.TurnContext(g, 6, g.current_scene_id())
    ctx.edge_asks = edge_asks(g, [("razor", "Razor uses edge to reroll his misses on the soak as the grenade explodes.")])
    out = tools.run_tool(ctx, tool("explode", item_id=can, holder_id="joey-two-knives", reason="Joey's frag",
                                   targets=[{"id": "razor", "range": "near", "edge": "reroll"}]))
    assert not out.get("is_error") and "razor" in ctx.edge_settled


def test_insurance_beside_the_call_is_insurance(make_game):
    """Review: "If it fails, he uses edge to reroll misses" read the call's clause alone - a binding reroll - and the
    GM's right if_short was refused with "Pass edge='reroll'". A condition standing as its own clause, before or after
    the comma, makes it insurance; one that may be another verb's leaves the mode to the GM."""
    g = make_game(dice=ScriptedDice([]))
    setup_demo(g)
    for post in ("He'll use edge to reroll misses, if needed", "Razor uses edge to reroll misses, just in case",
                 "Razor uses edge to reroll misses but only if he fails",
                 "Razor casts. If it fails, he uses edge to reroll misses.", "If he misses, Razor uses edge to reroll."):
        assert _mode(g, post) == "if_short", post
    assert _mode(g, "Razor uses edge to reroll misses on the shot, and draws his knife if needed.") is None
    assert _mode(g, "If he misses, Razor uses edge to reroll 6s.") is None              # (a push can't wait for a miss)
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    ctx.edge_asks = edge_asks(g, [("razor", "Razor bluffs Kaz. If it fails, he uses edge to reroll misses.")])
    out = tools.run_tool(ctx, tool("request_test", actor_id="razor", skill="con", threshold=2, reason="bluff",
                                   edge="if_short"))
    assert not out.get("is_error") and "razor" in ctx.edge_settled


def test_a_roll_less_call_leaves_the_edge_for_the_roll(make_game):
    """Review: a decker's run starts with jack_in, which rolls nothing - it was refused for leaving out the Edge, the
    PC was settled, and the hack the Edge was called for went out without it, unchecked (the T164 failure in the
    Matrix). Calls that roll nothing - jack_in, move, a jack_out with no Tar Baby, a login's control, unresisted
    damage, a smoke grenade - aren't checked; the hack is."""
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    L = g.ledger
    hid, _ = g.introduce("host", "Renraku Host", "white gravel", rating=4, turn=1)
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    ctx.edge_asks = edge_asks(g, [("ghost", "Ghost jacks into the Renraku host and hacks the first node, using edge "
                                            "to reroll misses.")])
    assert ctx.edge_asks["ghost"][1] == "reroll"
    beat = {"decker_id": "ghost", "reason": "the run"}
    for args in ({"action": "jack_in", "host_id": hid}, {"action": "move", "node": "Entry"},
                 {"action": "admin", "effect": "all"}):
        tools.run_tool(ctx, tool("matrix", **beat, **args))
        assert "ghost" not in ctx.edge_settled, args
    assert not tools.run_tool(ctx, tool("apply_damage", target_id="ghost", dv=1, damage_type="stun", resist="none",
                                        reason="a jolt")).get("is_error")
    smoke = L.create_entity("item", "Ghost's smoke grenade", "", props=dict(C.CATALOG["smoke-grenade"]["props"]), turn=1)
    L.give("ghost", smoke, 1)
    assert not tools.run_tool(ctx, tool("explode", item_id=smoke, holder_id="ghost", reason="cover",
                                        targets=[{"id": "ghost", "range": "close"}])).get("is_error")
    assert "ghost" not in ctx.edge_settled and int(L.stat("ghost", "edge_points")) == 3
    out = tools.run_tool(ctx, tool("matrix", **beat, action="hack"))           # the roll it was called for
    assert out["is_error"] and "edge='reroll'" in out["content"]
    out = tools.run_tool(ctx, tool("matrix", **beat, action="hack", edge="reroll"))
    assert not out.get("is_error") and "second chance" in out["content"] and int(L.stat("ghost", "edge_points")) == 2
    assert matrix.edge_rides(L, "ghost", "hack") and not matrix.edge_rides(L, "ghost", "jack_out")
    st = matrix.state(L, "ghost")                                             # a Tar Baby's hold is a roll
    hp = L.get(hid)["props"]
    for ic in hp["ic"]:
        ic["active"] = ic["type"] == "tar baby"                               # (a rating 4 host has one)
    L.update_entity(hid, props=hp)
    matrix._save(L, "ghost", {**st, "tarred": True})
    assert matrix.edge_rides(L, "ghost", "jack_out") and not matrix.edge_rides(L, "ghost", "jack_out", forced=True)
    matrix._save(L, "ghost", {**st, "tarred": False, "creds": {hid: "admin"}})   # a real login: control rolls nothing
    assert not matrix.edge_rides(L, "ghost", "control", node="Cameras")
    matrix._save(L, "ghost", {**st, "tarred": False, "creds": {}})
    assert matrix.edge_rides(L, "ghost", "control", node="Cameras")


def test_table_talk_never_becomes_a_story_turn():
    """Live T158/T159/T161: bug reports and loop complaints with no "DM" in them were played as story turns (T159
    moved the scene on one). Runner talk - a bug in the office, a camera loop, starting the car - stays a move."""
    for talk in ("The teamwork check broke again, and now I'm worried we're heading for another loop.",
                 "I had to reword the post so it skipped the NPC, and it still put my rolls under her name.",
                 "Mostly I've been writing bugreports. It keeps inventing house rules whenever I point out a mistake.",
                 "((brb, pizza))", "Hey DM, quick question", "the DM ignored it again"):
        assert aside.table_talk(talk), talk
    for move in ("I plant a bug in the office.", "Filament loops the camera feed so it plays the same hallway.",
                 "You keep asking me that, Rook.", "Magic makes a teamwork roll with Brask helping.",
                 "I start the engine. \"Get in.\"", "The lights flicker - it keeps going out."):
        assert not aside.table_talk(move), move
