"""Character creation: the engine's budgets and repairs, and the guided build in a player's DMs."""
import asyncio

import pytest

from roleplay import chargen as C
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


def test_every_role_and_metatype_starts_legal():
    for role in C.ROLES:
        for meta in C.METATYPES:
            d = C.new_draft(role, meta)
            d["name"] = "X"
            assert C.problems(d) == [], (role, meta)
            assert C.attr_left(d) == 0 and C.skill_left(d) >= 0 and C.spent(d) <= C.budget(d)


def test_edits_stay_inside_the_rules():
    d = C.new_draft("street_samurai", "troll")
    assert d["attrs"]["agility"] <= 5 and d["attrs"]["body"] >= 5            # troll limits and gifts
    notes = C.edit(d, "attrs", "agility +3")
    assert "Agility has to stay 1-5" in notes[0]
    before = dict(d["attrs"])
    C.edit(d, "attrs", "log -1, cha 2")                                      # abbreviations; budget-neutral
    assert d["attrs"]["logic"] == before["logic"] - 1 and C.attr_left(d) == 1 - (2 - before["charisma"])
    notes = C.edit(d, "skills", "sorcery 3, stealth +9")
    assert notes == ["Sorcery needs a mage", "Stealth has to stay 0-6"]
    C.edit(d, "skills", "intimidation 0")
    assert "intimidation" not in d["skills"]


def test_shopping_essence_and_the_gift():
    d = C.new_draft("mage", "elf")
    assert d["role"] == "mage" and C.budget(d) == C.NUYEN_AWAKENED and C.gift(d) == 6
    C.shop(d, "sell", "power focus (2)")
    assert C.shop(d, "buy", "wired") == []                                   # 2 Essence of chrome...
    assert C.essence(d) == 4.0 and C.gift(d) == 4                            # ...costs 2 Magic
    assert "costs" in C.shop(d, "buy", "steel")[0]                           # can't afford a Steel Lynx
    C.shop(d, "sell", "wired")
    s = C.new_draft("decker")
    assert C.shop(s, "buy", "power focus (1)") == ["Power focus (1) needs a mage"]
    assert C.shop(s, "buy", "flash x3") == [] and s["gear"]["flash-bang"] == 3
    m = C.new_draft("mage")
    C.toggle(m, "spells", "1 2 3 4 5 6 7")                                    # toggling: off, then on again
    assert len(m["spells"]) <= C.SPELL_PICKS


def test_the_gms_proposal_is_repaired_not_trusted():
    d = C.new_draft()
    s = {"pitch": "A wheelman.", "name_ideas": ["Lugnut", "Gears", "Two-Tone"], "metatype": "ork", "role": "rigger",
         "attrs": {a: 6 for a in C.BASE_ATTRS},                              # way over budget
         "skills": [{"skill": "piloting", "rating": 9}, {"skill": "sorcery", "rating": 4},
                    {"skill": "firearms", "rating": 4}],
         "gear": ["control-rig", "steel-lynx", "bulldog", "power-focus-2"], "spells": [], "forms": [],
         "look": "Grease-stained ork in a Yakuza windbreaker.", "personality": "Never stops talking about engines."}
    C.apply_suggestion(d, s)
    assert (d["metatype"], d["role"]) == ("ork", "rigger") and C.attr_left(d) == 0
    assert d["skills"] == {"piloting": 6, "firearms": 4}                     # capped; no sorcery for a rigger
    assert "power-focus-2" not in d["gear"] and C.spent(d) <= C.budget(d)    # over budget and illegal: dropped
    assert d["look"].endswith("engines.") and d["picks"] == {"metatype": "ork", "role": "rigger"}


def test_build_makes_a_real_runner(make_game):
    g = make_game()
    setup_demo(g)
    d = C.new_draft("street_samurai", "ork")
    d.update(name="Lugnut", pronouns="he/him", look="Big ork in a Yakuza windbreaker.")
    eid = C.build(g, d, "lugnut", 1)
    L = g.ledger
    s = L.stats(eid)
    assert s["edge"] == 3 and s["essence"] == C.essence(d) and s["reaction"] == d["attrs"]["reaction"] + 1
    assert s["nuyen"] == min(C.CASH_CAP, C.budget(d) - C.spent(d))
    assert "(he/him)" in L.get(eid)["description"]
    sheet = sr_lite.sheet(L, eid)
    assert "PC (ork street samurai, he/him, player: lugnut)" in sheet and "cyberware" in sheet
    n, parts = sr_lite.build_pool(L, eid, "firearms")
    assert ("Lugnut's Smartlink", 2) in parts
    with pytest.raises(LedgerError, match="already exists"):
        C.build(g, d, "lugnut2", 1)


SUGGESTION = {"pitch": "An elf decker who burned Renraku once and wants to again.", "name_ideas": ["Glitch", "Wisp"],
              "metatype": "elf", "role": "decker", "attrs": {"body": 2, "agility": 4, "reaction": 4, "strength": 1,
                                                             "willpower": 4, "logic": 6, "intuition": 5, "charisma": 5},
              "skills": [{"skill": "hacking", "rating": 6}, {"skill": "electronics", "rating": 5}],
              "gear": ["deck-3", "light-pistol", "lined-coat", "datajack"], "spells": [], "forms": [],
              "look": "Silver-haired elf in a patched Renraku techie jacket.", "personality": "Dry, patient, petty."}


def test_the_guided_build_in_dms(make_game):
    g = make_game(FakeLLM(extraction=lambda user: SUGGESTION))
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("7", "Jo", "!newchar", False, react)
        assert "building a new runner" in ch.sent[-1]["text"] and "1/10 Concept" in ch.dms[-1][1][0]["title"]
        dm = lambda text: t.whisper("7", text, FakeChannel())                 # noqa: E731
        last = lambda: ch.dms[-1][1][0] if isinstance(ch.dms[-1][1], list) else ch.dms[-1][1]   # noqa: E731
        await dm("elf decker with a grudge against Renraku")
        assert "burned Renraku" in last()["description"] and "**1** Glitch" in last()["description"]
        await dm("1")
        await dm("3")                                                       # they/them
        assert "Metatype" in last()["title"] and "Elf** ★" in last()["description"]
        await dm("ok")
        await dm("ok")
        assert "Attributes" in last()["title"]
        await dm("logic +9")
        assert "Logic has to stay" in last()["description"]
        await dm("ok")
        await dm("stealth +2")
        await dm("ok")
        assert "Gear" in last()["title"]                                    # (no magic step for a decker)
        await dm("buy 12 x2")                                               # two HE grenades
        assert "✅x2" in last()["description"]
        await dm("ok")
        await dm("go skills")
        assert "Skills" in last()["title"]
        t2 = CampaignTable(g, ch, owner_id="1")                             # a restart keeps the draft
        await t2.whisper("7", "ok", FakeChannel())
        await t2.whisper("7", "ok", FakeChannel())
        await t2.whisper("7", "ok", FakeChannel())                         # gear ok, look keeps the sketch
        assert "Review" in ch.dms[-1][1][0]["title"] and "Glitch (they/them) - elf decker" in ch.dms[-1][1][0]["description"]
        await t2.whisper("7", "done", FakeChannel())
        pc = g.character_for("glitch")
        assert pc and pc["name"] == "Glitch" and pc["id"] in g.ledger.roster(g.current_scene_id())
        assert any(m["title"] == "🎲 Glitch joins the table" for m in ch.sent)
        assert t2.handles["7"] == "glitch" and not await t2.chargen_for("7")
        assert int(g.ledger.stat(pc["id"], "stealth")) == 2
        await t.close()
        await t2.close()
    asyncio.run(go())


def test_closed_dms_get_a_hint_in_the_channel(make_game):
    g = make_game()
    setup_demo(g)

    class NoDMs(FakeChannel):
        async def dm_cards(self, user_id, cards):
            raise PermissionError("Cannot send messages to this user")

    async def go():
        ch = NoDMs()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("7", "Jo", "!newchar", False, react)
        assert "couldn't DM you" in ch.sent[-1]["text"] and "7" not in t.chargens
        await t.close()
    asyncio.run(go())


def test_newcomers_see_the_options_and_questions_dont_become_characters(make_game):
    llm = FakeLLM(extraction=lambda user: SUGGESTION)
    g = make_game(llm)
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()

        async def react(e):
            pass
        await t.handle("7", "Jo", "!roles", False, react)
        assert ch.sent[-1]["title"] == "🧬 What you can play" and "🧌 **Troll**" in ch.sent[-1]["description"]
        await t.handle("7", "Jo", "!newchar", False, react)
        first = ch.dms[-1][1][0]["description"]
        assert "💻 **2  Decker**" in first and "🧝 **Elf**" in first          # the menu, before any question
        dm = lambda text: t.whisper("7", text, FakeChannel())                 # noqa: E731
        await dm("What classes can I pick from")
        card = ch.dms[-1][1][0]
        assert "Concept" in card["title"] and "sounds like a question" in card["description"]
        assert llm.usage.calls == 0                                          # no GM call, no build from a question
        await dm("help")
        assert "Concept" in ch.dms[-1][1][0]["title"]
        await dm("2")                                                        # a role straight off the list
        card = ch.dms[-1][1][0]
        assert "Name" in card["title"] and "Starting from a decker" in card["description"]
        assert (await t.chargen_for("7")).d["role"] == "decker"
        await t.close()
    asyncio.run(go())


def test_the_magic_step_shows_drain_codes():
    from roleplay.discord_bot import chargen_flow
    d = C.new_draft("mage", "elf")
    d["step"] = "magic"
    body = chargen_flow.prompt(None, d)["description"]
    assert "Stunbolt (F-3) - a mana jolt" in body and "Mind Probe (F) - " in body       # (no hyphen against the dash)
    assert "F-3 is the Force minus 3, never under 2" in body and "(5 each)" in body
    assert "Spells: Manabolt F-3, Stunbolt F-3" in chargen_flow.preview(d)
    t = C.new_draft("technomancer", "elf")
    t["step"] = "magic"
    assert "Puppeteer (L+2) - " in chargen_flow.prompt(None, t)["description"]
    assert "Forms: Resonance Spike L-1, Puppeteer L+2" in chargen_flow.preview(t)
