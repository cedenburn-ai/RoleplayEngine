import pytest

from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import sr_lite


def test_roll_hits_and_glitches():
    r = sr_lite.Roll(4, [5, 6, 1, 1])
    assert r.hits == 2 and not r.glitch          # 2 ones is not MORE than half of 4
    r = sr_lite.Roll(4, [1, 1, 1, 6])
    assert r.glitch and not r.crit_glitch
    r = sr_lite.Roll(3, [1, 1, 2])
    assert r.crit_glitch


def test_pool_uses_sheet_gear_and_wounds(make_game):
    g = make_game()
    ghost = g.create_pc("Ghost", "decker", "ghost")
    pool, parts = sr_lite.build_pool(g.ledger, ghost, "hacking")
    assert pool == 6 + 6 + 2                      # logic 6 + hacking 6 + cyberdeck 2
    g.ledger.set_stat(ghost, "physical_damage", 6)
    pool2, _ = sr_lite.build_pool(g.ledger, ghost, "hacking")
    assert pool2 == pool - 2


def test_untrained_hacking_is_refused(make_game):
    g = make_game()
    razor = g.create_pc("Razor", "street_samurai", "razor")
    with pytest.raises(LedgerError):
        sr_lite.build_pool(g.ledger, razor, "hacking")


def test_modifiers_are_clamped():
    mods, notes = sr_lite.clamp_mods([{"label": "a", "value": 9}, {"label": "b", "value": 4}])
    assert sum(v for _, v in mods) == 6 and notes


def test_threshold_test_records(make_game):
    g = make_game(dice=ScriptedDice([5, 6, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]))
    ghost = g.create_pc("Ghost", "decker", "ghost")
    res = sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", threshold=3, reason="crack the chip")
    assert res["success"] and res["hits"] == 3 and res["net"] == 0
    assert "Logic 6 + Hacking 6 + Ghost's Cyberdeck 2 = 14d6" in res["card"]
    assert g.conn.execute("SELECT COUNT(*) AS n FROM tests").fetchone()["n"] == 1


def test_opposed_against_host(make_game):
    g = make_game(dice=ScriptedDice([5] * 14 + [1] * 10))
    ghost = g.create_pc("Ghost", "decker", "ghost")
    host, _ = g.introduce("host", "Renraku vault", "", rating=5)
    res = sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", opposed={"entity_id": host}, reason="in")
    assert res["success"] and "Host (rating 5 doubled) 10 = 10d6" in res["card"]


def test_attack_damage_ammo_and_overflow(make_game):
    g = make_game(dice=ScriptedDice([6] * 16 + [1] * 6 + [1] * 8))
    razor = g.create_pc("Razor", "street_samurai", "razor")
    joey, _ = g.introduce("npc", "Joey", "ganger", template="ganger")
    gun = next(i for i in g.ledger.holdings(razor) if "ammo_capacity" in i["props"])
    res = sr_lite.attack(g.ledger, g.dice, 1, razor, joey, gun["id"], reason="shoot")
    assert res["hit"] and res["boxes"] > 0
    assert g.ledger.item_state(razor, gun["id"])["loaded"] == 14
    assert res["target_status"] in ("dying", "dead", "unconscious")


def test_cannot_attack_with_gear_you_dont_hold(make_game):
    g = make_game()
    razor = g.create_pc("Razor", "street_samurai", "razor")
    ghost = g.create_pc("Ghost", "decker", "ghost")
    deck_gun = next(i for i in g.ledger.holdings(ghost) if "ammo_capacity" in i["props"])
    with pytest.raises(LedgerError):
        sr_lite.attack(g.ledger, g.dice, 1, razor, ghost, deck_gun["id"])


def test_edge_adds_dice_and_runs_out(make_game):
    g = make_game()
    ghost = g.create_pc("Ghost", "decker", "ghost")
    g.ledger.set_stat(ghost, "edge_points", 1)
    res = sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", threshold=2, reason="push", use_edge=True)
    assert "Edge, pushed - 6s explode (0 left) 3" in res["card"] and "= 17d6" in res["card"]
    with pytest.raises(LedgerError):
        sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", threshold=2, reason="again", use_edge=True)


def test_difficulty_shifts_thresholds_and_opposition(make_game):
    g = make_game(dice=ScriptedDice([5, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] + [2] * 40))
    ghost = g.create_pc("Ghost", "decker", "ghost")
    g.set_difficulty(["hard"])
    res = sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", threshold=2, reason="x")
    assert "(threshold 3)" in res["card"] and not res["success"]       # 2 hits vs 2+1
    host, _ = g.introduce("host", "Vault", "", rating=4)
    res = sr_lite.request_test(g.ledger, g.dice, 1, ghost, "hacking", opposed={"entity_id": host}, reason="y")
    assert "Table (hard) 1 = 9d6" in res["card"]                       # 8 host dice + 1
    g.set_difficulty(["opposition", "-2"])
    assert g.difficulty()["level"] == "custom" and g.difficulty()["opposition"] == -2
    with pytest.raises(LedgerError):
        g.set_difficulty(["impossible"])


def test_gm_model_and_effort_persist(make_game, tmp_path):
    g = make_game()
    assert g.set_dm_model("haiku") == "claude-haiku-5-5"
    g.set_dm_effort("high")
    with pytest.raises(LedgerError):
        g.set_dm_effort("ludicrous")
    assert "haiku, effort high" in g.settings_line()
    assert g.ledger.meta("dm_model") == "claude-haiku-5-5"


def test_stun_overflow_becomes_physical(make_game):
    g = make_game()
    joey, _ = g.introduce("npc", "Joey", "ganger", template="ganger")
    pmax, smax = sr_lite.monitor_max(g.ledger, joey)
    sr_lite._apply_boxes(g.ledger, joey, smax + 5, "stun")
    assert g.ledger.stat(joey, "stun_damage") == smax
    assert g.ledger.stat(joey, "physical_damage") == 2                      # 5 past the track: 2 Physical (p. 170)
