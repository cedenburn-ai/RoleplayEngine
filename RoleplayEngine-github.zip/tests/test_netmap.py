"""The network map: a host laid out as a picture from the ledger - nothing on it the engine doesn't know."""
import asyncio

import pytest
from PIL import Image

from roleplay import netmap
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import matrix
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


def _jacked_in(g):
    hid = g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=4, turn=1)[0]
    matrix.act(g.ledger, g.dice, 1, "ghost", "jack_in", hid)
    return hid


def test_render_follows_the_decker(make_game, tmp_path):
    g = make_game()
    setup_demo(g)
    with pytest.raises(LedgerError, match="hasn't been in any host"):
        netmap.render(g, "ghost")
    hid = _jacked_in(g)
    assert netmap.host_for(g, "ghost") == hid and [p["id"] for p in netmap.personas_in(g, hid)] == ["ghost"]
    for gm in (False, True):
        out = netmap.render(g, "ghost", gm=gm, out=tmp_path / f"net_{gm}.png")
        assert Image.open(out).size == (netmap.W, netmap.H)
    path = netmap.render(g, "ghost")                                   # default: next to the campaign
    assert path.parent == g.path.parent / "maps" and path.name.endswith(f"_matrix_{hid}.png")
    matrix.act(g.ledger, g.dice, 1, "ghost", "jack_out")
    assert netmap.host_for(g, "ghost") == hid                         # jacked out: the last host she touched


def test_net_command_and_auto_post(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})

        async def react(e):
            pass
        await t.handle("2", "Bob", "!net", False, react)
        assert "not playing anyone" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!join ghost", False, react)
        await t.handle("2", "Bob", "!net", False, react)
        assert "hasn't been in any host" in ch.sent[-1]["text"]
        _jacked_in(g)
        await t.handle("2", "Bob", "!map matrix gm", False, react)       # a player's 'gm' is ignored: their own map
        assert ch.sent[-1]["title"] == "🕸️ Ares Lab Host" and ch.sent[-1]["image"].endswith(".png")
        await t.handle("1", "Owner", "!net gm", True, react)             # the owner isn't playing: whoever's in
        assert ch.dms[-1][0] == "1" and ch.dms[-1][1][0]["title"] == "🕸️ Ares Lab Host (GM view)"
        n = len(ch.sent)
        await t._post_netmaps(["[ROLL] Razor shoots"], ch.send_cards)    # no Matrix action, no map
        assert len(ch.sent) == n
        await t._post_netmaps(["[MATRIX] Ghost - hack · Ares Lab Host (rating 4)\n3 hits"], ch.send_cards)
        assert len(ch.sent) == n + 1 and ch.sent[-1]["title"] == "🕸️ Ares Lab Host"
        await t.close()
    asyncio.run(go())
