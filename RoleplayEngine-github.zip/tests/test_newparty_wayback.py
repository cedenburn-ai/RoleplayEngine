"""A new party's edges (review 2026-10-27): the way back never books a runner in two worlds, a reset the bot dies in
the middle of is put back when the world opens, the table can't slip a turn or a stale card past a change of crew,
the old crew's parked scenes and PC-era pictures don't come back, the canon knows the skip, and the graph analysis
keeps the change of crew when the buffer that carried it was lost."""
import asyncio
import json
import os
import subprocess
import sys
import time
from types import SimpleNamespace

import pytest

from roleplay import charledger, newparty
from roleplay.art import ArtDirector, NullArtProvider
from roleplay.discord_bot import bot as botmod
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import canon, commit
from roleplay.dm.tools import TurnContext
from roleplay.engine.ledger import LedgerError
from roleplay.game import Game
from roleplay.graphlog import analyze, fmt
from roleplay.setup import setup_blank
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text
from .test_discord import FakeChannel
from .test_newparty import brain, demo_world
from .test_session_zero import FakeDiscordChannel


def other_world(make_game):
    w = make_game(FakeLLM())
    setup_blank(w, "Downtown Seattle", "rain")
    return w


def reopen(g, tmp_path, calls=None):
    """The same world opened again - a restart (the recorder and recover run as the bot's would)."""
    art = ArtDirector(tmp_path / "art", "test", provider=NullArtProvider(), out=lambda s: None)
    return Game(g.path, llm=FakeLLM([], brain(calls if calls is not None else [])), art=art, out=lambda s: None)


# ── the way back never books a runner in two worlds ─────────────────────
def test_undo_waits_for_a_runner_checked_out_elsewhere_and_keeps_what_they_earned(make_game, tmp_path):
    g = demo_world(make_game, [])
    here = g.path.stem
    newparty.run(g, backup_root=tmp_path / "bk")
    other = other_world(make_game)
    eid, _ = charledger.check_out(other, "Razor", "7", 1)       # (on the shelf: another world takes him)
    other.ledger.set_stat(eid, "karma", 99)
    assert charledger.sync(other, eid)
    for ask in (newparty.can_undo, newparty.undo):               # (asked, and at the ✅: refused, named)
        with pytest.raises(LedgerError, match=r"\*\*Razor\*\* go to \*\*" + other.path.stem):
            ask(g)
    r = charledger.get(g, "Razor")
    assert r["campaign"] == other.path.stem and r["data"]["stats"]["karma"] == 99 and charledger.sync(other, eid)
    assert g.ledger.get("razor")["kind"] == "npc"               # (nothing taken back)
    charledger.check_in(other, eid, write_backstory=False)       # returned there: back on the shelf with karma 99
    rec = newparty.undo(g)
    L = g.ledger
    assert L.get("razor")["kind"] == "pc" and L.stat("razor", "karma") == 99      # the same Razor, the newer sheet
    assert charledger.get(g, "Razor")["campaign"] == here and charledger.sync(g, "razor")
    assert any("Razor played in another world since" in n for n in rec["ledger_notes"])
    assert charledger.get(g, "Ghost")["campaign"] == here and L.get("ghost")["kind"] == "pc"
    with pytest.raises(LedgerError, match="checked out to"):
        charledger.check_out(other, "Razor", "7", 2)             # (one world at a time again)


def test_a_rollback_leaves_alone_a_runner_taken_meanwhile(make_game, tmp_path, monkeypatch):
    g = demo_world(make_game, [])
    other = other_world(make_game)

    def taken_then_boom(game, *a, **k):                          # mid-catch-up: another table takes Razor, then...
        eid, _ = charledger.check_out(other, "Razor", "7", 1)
        other.ledger.set_stat(eid, "karma", 42)
        charledger.sync(other, eid)
        raise RuntimeError("the world pass fell over")
    monkeypatch.setattr(newparty, "_catch_up", taken_then_boom)
    with pytest.raises(RuntimeError):
        newparty.run(g, backup_root=tmp_path / "bk")
    r = charledger.get(g, "Razor")
    assert r["campaign"] == other.path.stem and r["data"]["stats"]["karma"] == 42
    assert charledger.sync(other, other.ledger.find("Razor")["id"])          # (that world's copy still saves)
    assert charledger.get(g, "Ghost")["campaign"] == g.path.stem            # (the untouched row went back)
    assert g.ledger.get("razor")["kind"] == "pc" and newparty.running(g) is None and newparty.last(g) is None


def test_undo_frees_a_departed_runner_checked_back_in_since(make_game, tmp_path):
    g = demo_world(make_game, [])
    here = g.path.stem
    kid = g.create_pc("Marco", "decker", "marco", "", g.turn_no())
    charledger.register(g, kid, "9", "Alice")
    charledger.check_in(g, kid, write_backstory=False)          # he left this world before the reset
    newparty.run(g, backup_root=tmp_path / "bk")
    assert charledger.check_out(g, "Marco", "9", g.turn_no()) == ("marco", True)   # (back in: the same Marco)
    assert g.ledger.get("marco")["status"] == "active"
    newparty.undo(g)
    assert g.ledger.get("marco")["status"] == "departed"         # (the world as it was: he'd left)
    r = charledger.get(g, "Marco")
    assert r["campaign"] is None and r["entity_id"] is None      # ...so the ledger has him on the shelf, not here
    other = other_world(make_game)
    assert other.ledger.get(charledger.check_out(other, "Marco", "9", 1)[0])["kind"] == "pc"
    assert charledger.get(g, "Razor")["campaign"] == here


# ── a reset the bot dies in the middle of ───────────────────────────────
def killed_mid_reset(g, tmp_path, monkeypatch):
    """newparty.run as a force-stop leaves it: the reset half done, no except run (no rollback)."""
    def boom(*a, **k):
        raise RuntimeError("taskkill /F")
    monkeypatch.setattr(newparty, "_catch_up", boom)
    monkeypatch.setattr(newparty, "_rollback", lambda *a, **k: [])
    with pytest.raises(RuntimeError):
        newparty.run(g, backup_root=tmp_path / "bk")
    monkeypatch.undo()


def test_a_reset_killed_part_way_is_put_back_when_the_world_opens(make_game, tmp_path, monkeypatch):
    calls = []
    g = demo_world(make_game, calls)
    t, start, scene = g.turn_no(), g.clock(), g.current_scene_id()
    killed_mid_reset(g, tmp_path, monkeypatch)
    L = g.ledger
    assert L.get("razor")["kind"] == "npc" and charledger.get(g, "Razor")["campaign"] is None   # (half done)
    assert newparty.running(g)["turn"] == t and newparty.last(g) is None
    assert set(newparty.running(g)["let"]) == {"razor", "ghost"}
    assert g.undo() == "Nothing to undo."                        # !undo can't put T5's snapshot over a half reset
    assert "died part-way" in newparty.refusal(g)
    with pytest.raises(LedgerError, match="died part-way"):
        newparty.preview(g)
    g2 = reopen(g, tmp_path, calls)                             # the bot comes back up
    L2 = g2.ledger
    assert L2.get("razor")["kind"] == "pc" and L2.get("razor")["props"]["ledger"] == "razor"
    assert charledger.get(g2, "Razor")["campaign"] == g2.path.stem and charledger.sync(g2, "razor")
    assert newparty.running(g2) is None and newparty.last(g2) is None and newparty.pending(g2) is None
    assert g2.clock() == start and g2.current_scene_id() == scene and L2.scene(scene)["title"] != newparty.CATCHUP_WHERE
    assert g2.conn.execute("SELECT COUNT(*) FROM players").fetchone()[0] == 2
    assert g2.undo().startswith("Undid turn 5")                 # (its snapshots are back where !undo finds them)
    g2.close()


def test_the_owner_can_put_back_a_reset_that_died_part_way(make_game, tmp_path, monkeypatch):
    g = demo_world(make_game, [])
    killed_mid_reset(g, tmp_path, monkeypatch)
    rec = newparty.can_undo(g)                                  # (`!rp newparty undo` on the world still open)
    assert rec["status"] == newparty.RUNNING and "died part-way" in newparty.undo_confirm_text(rec)
    newparty.undo(g)
    assert g.ledger.get("ghost")["kind"] == "pc" and charledger.get(g, "Ghost")["campaign"] == g.path.stem
    assert newparty.running(g) is None and g.undo().startswith("Undid turn 5")


def test_a_reset_still_running_elsewhere_is_left_alone(make_game, tmp_path):
    g = demo_world(make_game, [])
    rec = {"status": newparty.RUNNING, "turn": g.turn_no(), "at": time.time(), "pid": os.getppid(),
           "backup": str(tmp_path / "nowhere"), "old_crew": [], "let": {}, "label": "three weeks", "clock_from": 0}
    g.ledger.set_meta(newparty.KEY, json.dumps([rec]))           # (another process mid-reset: the parent's pid, alive)
    assert newparty.recover(g) is None and newparty.running(g)
    with pytest.raises(LedgerError, match="under way"):
        newparty.can_undo(g)
    assert "under way" in newparty.refusal(g)
    p = subprocess.Popen([sys.executable, "-c", "pass"])
    p.wait()
    assert newparty._pid_alive(os.getpid()) and not newparty._pid_alive(p.pid)


# ── the table, around a change of crew ──────────────────────────────────
class SlowChannel(FakeChannel):
    async def send(self, text=None, **kw):
        if text and text.startswith("⏳ The old crew"):
            await asyncio.sleep(0.05)                           # (a Discord round trip)
        return await super().send(text, **kw)


class AskChannel(FakeChannel):
    n = 0

    async def ask(self, content, card, emojis, holder=None):
        AskChannel.n += 1
        self.sent.append({"text": content, "title": card["title"], "description": card["description"],
                          "footer": None, "image": None})
        return f"ask{AskChannel.n}"


def test_a_post_during_the_first_line_waits_and_a_stale_card_queues_nothing(make_game, tmp_path, monkeypatch):
    monkeypatch.setenv("ROLEPLAY_BACKUP_DIR", str(tmp_path / "backups"))
    g = demo_world(make_game, [], script=[([text("Kaz shrugs.")], "end_turn")] * 2
                   + [([text("Something happens.")], "end_turn")] * 3)
    g.conn.execute("UPDATE players SET afk=1 WHERE discord_id='8'")      # (Ghost's player is away)
    t0 = g.turn_no()

    async def go():
        ch = type("Ch", (SlowChannel, AskChannel), {})()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 0.2, "cap": 1, "grace": 0.05})
        await t.refresh()
        t.last_active["razor"] = time.time()
        async def ignore(e):
            pass
        await t.handle("8", "Al", "I slip out the back with the chip.", False, ignore)
        assert t.comebacks                                      # ("back in?" for the away player)
        reacts = []

        async def react(e):
            reacts.append(e)

        async def post():
            await asyncio.sleep(0.01)                           # lands while the "⏳" line is going out
            await t.handle("7", "Jo", "I duck out the back.", False, react)
        await asyncio.gather(t.new_party("1", newparty.DEFAULT_GAP, newparty.DEFAULT_LABEL), post())
        assert reacts == ["⏸️"] and not t.director.queue        # (held, not a turn)
        assert t.comebacks == {} and t.requests == {} and t.undo_votes == {}
        assert not await t.answer_back("8", True)               # (the card went with the old crew)
        await t._come_back("8", ["I slip out the back with the chip."])      # (and a late one queues nothing)
        assert not t.director.queue and "no runner of yours" in ch.sent[-1]["text"]
        await asyncio.sleep(0.4)
        await t.drain()
        assert g.conn.execute("SELECT COUNT(*) FROM turns WHERE id>?", (t0,)).fetchone()[0] == 0
        assert newparty.pending(g) and not t._started()         # (the new crew's session zero is still to come)
        await t.close()
    asyncio.run(go())


def test_a_confirm_after_the_channel_switched_worlds_does_nothing(make_game, tmp_path, monkeypatch):
    monkeypatch.setenv("ROLEPLAY_BACKUP_DIR", str(tmp_path / "backups"))
    a = demo_world(make_game, [])
    b = demo_world(make_game, [], ledger=False)

    async def go():
        ta, tb = CampaignTable(a, FakeChannel(), owner_id="1"), CampaignTable(b, FakeChannel(), owner_id="1")
        bot, dch = botmod.RPBot(), FakeDiscordChannel(42)
        bot.bindings["42"] = {"campaign": a.path.stem, "owner": "1"}
        bot.tables[42] = ta
        msg = SimpleNamespace(channel=dch, author=SimpleNamespace(id=1, guild_permissions=SimpleNamespace(
            manage_guild=False)))
        await bot.rp_command(msg, "!rp newparty a month")
        assert bot.pending[42]["campaign"] == a.path.stem
        bot.bindings["42"] = {"campaign": b.path.stem, "owner": "1"}     # (what `!rp start <b>` leaves)
        bot.tables[42] = tb
        await bot.answer_restart(dch, "1", True)
        assert "moved on from" in dch.sent[-1] and 42 not in bot.pending
        assert newparty.last(a) is None and newparty.last(b) is None and b.ledger.get("razor")["kind"] == "pc"
        await ta.close()
        await tb.close()
        await bot.close()
    asyncio.run(go())


# ── what the GM is shown after the skip ─────────────────────────────────
def test_the_old_crews_parked_scenes_dont_come_back(make_game, tmp_path):
    g = demo_world(make_game, [])
    L = g.ledger
    parked = [s["id"] for s in L.scenes() if s["status"] == "parked"]
    assert parked                                                # (the demo's bar fight at the Lucky Shot, S1)
    g.ledger.set_meta(f"frame_S{parked[0]}", json.dumps({"intent": "The crew is fencing the chip to Kaz."}))
    res = newparty.run(g, backup_root=tmp_path / "bk")
    assert not [s for s in L.scenes() if s["status"] == "parked"]
    assert set(res["record"]["scenes_parked_closed"]) == set(parked)
    assert L.meta(f"frame_S{parked[0]}") is None
    assert "parked closed too" in newparty.owner_text(g, res)
    nova = g.create_pc("Nova", "street_samurai", "nova", "", g.turn_no())
    g.enter_scene([nova], g.turn_no())
    t = g.turn_no()
    start = g.current_scene_id()
    sid = commit.auto_cut(g, TurnContext(g, t, start), start, {"location": "The Lucky Shot", "who": ["Nova"]}, t)
    assert sid not in parked and sid != res["record"]["scene_closed"]         # a fresh scene at the old place
    assert L.scene(sid)["title"] == "The Lucky Shot" and set(L.roster(sid)) == {"nova", "the-lucky-shot"}
    assert world_whereabouts(g, "kaz")                          # (who was there stays 'last seen' there)


def world_whereabouts(g, eid):
    from roleplay.dm import world
    return world.whereabouts(g, eid)


def test_the_old_crew_get_a_picture_of_who_they_are_now(make_game, tmp_path):
    g = demo_world(make_game, [])
    S, t = g.sub, g.turn_no()
    old = S.clarify("razor", "RAZOR - PC holding the Lucky Shot door, sustaining a Physical Barrier; plan: hit the "
                             "Renraku van at dawn. Owes Kaz 2,000 nuyen.", t)
    newparty.run(g, backup_root=tmp_path / "bk")
    pic = S.clarification("razor")
    assert pic["id"] != old and pic["by"] == "newparty"
    for words in ("an NPC the GM plays since the new party after T5", "WANTS NOW [A", "keeping the Ancients off",
                  "WHERE: a coffin motel off the Redmond strip", "AS THE CREW SPLIT: Razor took his cut",
                  "HOW THEY FEEL NOW: Kaz (+2)", "ended with the skip", "history now", "Owes Kaz 2,000 nuyen"):
        assert words in pic["text"], words
    assert S.clarification("ghost")["by"] == "newparty"
    g.enter_scene(["razor"], g.turn_no())
    packet, _ = build_packet(g, g.current_scene_id(), [("scene", "A new crew walks in.")], g.turn_no() + 1)
    assert f"[{pic['id']}" in packet and "A player character until the new party" in packet   # (and the note, unfolded)


def test_the_canon_knows_the_skip_and_how_it_ended(make_game, tmp_path):
    g = demo_world(make_game, [])
    g.ledger.set_meta("canon", json.dumps({
        "turn": 5, "at": time.time() - 60, "settled": [], "timeline": ["Day 1: the chip changed hands"],
        "upcoming": ["Renraku comes for the chip"], "open_threads": ["The Ancients' convoy, five minutes out"],
        "people": [{"id": "razor", "name": "Razor", "stands": "a PC at the door"},
                   {"id": "kaz", "name": "Kaz", "stands": "behind the bar, waiting on the convoy five minutes out"}]}))
    ending = "The convoy rolled past the Lucky Shot without stopping; the crew split up that night."
    newparty.run(g, backup_root=tmp_path / "bk", ending=ending)
    c = canon.current(g)
    assert ending in c["settled"][-1]["what"] and any("skipped three weeks" in x and ending in x for x in c["timeline"])
    stands = {p["id"]: p["stands"] for p in c["people"]}
    assert stands["kaz"].startswith("(before the three weeks skip)") and "no longer a player" in stands["razor"]
    assert c["open_threads"][0].startswith("(before the three weeks skip)")
    lines = "\n".join(canon.packet_lines(g, g.current_scene_id()))
    assert "(before the three weeks skip) behind the bar" in lines and ending in lines
    gathered = canon.gather(g)["text"]                          # (the read-back the table forces after it)
    assert "A NEW PARTY AFTER T5" in gathered and ending in gathered
    assert "Razor took his cut" in gathered and "WHAT HAPPENED OFFSCREEN IN THE GAP" in gathered


# ── the graph analysis keeps the change of crew ─────────────────────────
def test_the_change_of_crew_survives_a_restart_and_a_lost_buffer(make_game, tmp_path):
    for lose in (False, True):
        calls = []
        g = demo_world(make_game, calls, ledger=False)
        newparty.run(g, backup_root=tmp_path / f"bk{lose}")
        d = fmt.log_dir(g.path)
        g.close()
        if lose:                                                # (the buffer on disk gone over the restart)
            (d / fmt.PENDING).unlink()
        g2 = reopen(g, tmp_path, calls)
        g2.create_pc("Nova", "street_samurai", "nova", "", g2.turn_no())
        g2.enter_scene(["nova"], g2.turn_no())
        g2.run_turn([("nova", "I look around.")])
        doc = fmt.read_turn(d, g2.turn_no())
        assert bool(doc["process"]["marks"]) is not lose        # (the file carries it only if the buffer did)
        out = tmp_path / f"analysis{lose}"
        ch = analyze.analyze(d, out)["summary"]["chapters"]
        assert len(ch) == 1 and ch[0]["first_file"] == g2.turn_no() and set(ch[0]["former_pcs"]) == {"razor", "ghost"}
        assert "Changes of crew" in (out / "report.html").read_text(encoding="utf-8")
        g2.close()


def test_a_crew_change_taken_back_isnt_a_chapter(tmp_path):
    d = tmp_path / "log"
    for ev in ({"kind": "new-party", "turn": 5, "former_pcs": ["a"]}, {"kind": "new-party-undone", "turn": 5},
               {"kind": "new-party", "turn": 9, "former_pcs": ["b"]}):
        fmt.append_mark(d, ev)
    got = analyze.with_marks_file(d, [], [4, 5, 6, 9, 10])
    assert [(m["turn"], m["file_turn"]) for m in got] == [(9, 10)]
    assert analyze.with_marks_file(d, [{"kind": "new-party", "turn": 9, "file_turn": 10}], [10]) == \
        [{"kind": "new-party", "turn": 9, "file_turn": 10}]     # (a file's own copy stands; never twice)
