"""NPC voices: dialogue posted under the speaker's name and portrait (a webhook), with the avatar's Discord
copy remembered and refreshed instead of re-uploaded every line."""
import asyncio
import time
from types import SimpleNamespace

from PIL import Image

from roleplay.discord_bot.session import CampaignTable, _expiry
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


class VoiceChannel(FakeChannel):
    def __init__(self, works=True):
        super().__init__()
        self.voices, self.stored, self.refreshed, self.works = [], [], [], works

    async def send_cards(self, cards):
        await super().send_cards(cards)
        return [{"channel_id": "1", "message_id": f"m{len(self.sent)}", "url": f"https://cdn/{i}.png?ex=7fffffff"}
                if c.get("image") else None for i, c in enumerate(cards)]

    async def voice(self, name, text, avatar_url):
        if self.works:
            self.voices.append((name, text, avatar_url))
        return self.works

    async def store_asset(self, path, caption):
        self.stored.append(caption)
        return {"channel_id": "cast", "message_id": f"s{len(self.stored)}",
                "url": f"https://cdn/{caption}.png?ex={int(time.time()) + 3600:x}"}

    async def refresh_asset(self, channel_id, message_id):
        self.refreshed.append(message_id)
        return f"https://cdn/fresh-{message_id}.png?ex=7fffffff"


def _game(make_game, tmp_path):
    g = make_game(FakeLLM())
    setup_demo(g)
    for eid in ("kaz", "ghost"):
        p = tmp_path / f"{eid}.png"
        Image.new("RGB", (64, 64), (40, 10, 90)).save(p)
        g.conn.execute("INSERT INTO art(entity_id, version, path, status) VALUES(?,1,?,'ready')", (eid, str(p)))
    return g


def test_lines_go_out_as_the_character(make_game, tmp_path):
    g = _game(make_game, tmp_path)
    g.conn.execute("INSERT INTO presented(entity_id, turn) VALUES('ghost', 1)")       # Ghost seen before; Kaz not

    async def go():
        ch = VoiceChannel()
        t = CampaignTable(g, ch, owner_id="1")
        res = SimpleNamespace(turn_id=4, info={"introduced": []},
                              narration='Rain.\n\n**Kaz:** "Tanaka."\n\n**Ghost:** "Cool."\n\n**A Bouncer:** "Move."\n\n'
                                        '**Kaz:** "Go."')
        await t._post_story(await t.run(t._story_cards, res, False))
        names = [v[0] for v in ch.voices]
        assert names == ["Kaz", "Ghost", "A Bouncer", "Kaz"] and ch.voices[0][1] == '"Tanaka."'
        reveal = [m for m in ch.sent if (m.get("title") or "").endswith("Kaz") and m.get("image")]
        assert len(reveal) == 1                                       # Kaz's first line: the big portrait first
        assert ch.voices[0][2] == ch.voices[3][2] == "https://cdn/0.png?ex=7fffffff"   # ...and that card is his avatar
        assert ch.stored == ["Ghost"] and ch.voices[1][2].startswith("https://cdn/Ghost.png")   # uploaded once
        assert ch.voices[2][2] is None                                # an extra: their name, the default avatar
        assert any((m.get("footer") or "").startswith("T4 ·") for m in ch.sent)  # the turn still gets its footer
        assert not any(m.get("author") for m in ch.sent)              # no dialogue cards when voices work

        g.conn.execute("UPDATE voice_assets SET expires=0 WHERE entity_id='ghost'")     # the link expired
        assert (await t._avatar("ghost")).startswith("https://cdn/fresh-s1") and ch.refreshed == ["s1"]
        assert ch.stored == ["Ghost"]                                 # refreshed, not re-uploaded
        await t.close()
    asyncio.run(go())


def test_no_webhook_falls_back_to_cards_and_voices_can_be_turned_off(make_game, tmp_path):
    g = _game(make_game, tmp_path)

    async def go():
        ch = VoiceChannel(works=False)
        t = CampaignTable(g, ch, owner_id="1")
        res = SimpleNamespace(turn_id=4, info={"introduced": []}, narration='**Kaz:** "Tanaka."')
        await t._post_story(await t.run(t._story_cards, res, False))
        card = next(m for m in ch.sent if m.get("author") == "Kaz")
        assert card["description"] == '"Tanaka."' and card["thumbnail"]           # the card it would have been

        async def react(e):
            pass
        await t.handle("2", "Bob", "!voices off", False, react)
        assert "campaign owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!voices off", True, react)
        assert "off" in ch.sent[-1]["text"] and not t.voices_on()
        await t.close()
    asyncio.run(go())


def test_expiry_is_read_from_discords_link():
    assert _expiry("https://cdn.discordapp.com/attachments/1/2/x.png?ex=68f00000&is=1&hm=abc") == 0x68f00000
    assert _expiry("https://example.com/x.png") > time.time()


def test_a_speaker_is_found_by_the_name_the_gm_uses(make_game):
    """The GM writes **Berit:** for Berit Strom. An exact-name lookup missed her, so her lines went out as a gray
    extra with no portrait. Now the label's words find the person - someone in the scene first - or nobody."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    L.create_entity("npc", "Berit Strom", "Troll woman, laundromat smock.", tier=2)
    L.create_entity("npc", "Van Driver", "ANVIL response driver.", tier=1)
    L.create_entity("npc", "Chase Car Driver", "Wheelman.", tier=1)
    sid = g.current_scene_id()
    assert g.find_speaker("Berit", sid)["name"] == "Berit Strom"
    assert g.find_speaker("Joey", sid)["id"] == "joey-two-knives"
    assert g.find_speaker("Driver", sid) is None                       # two drivers, neither here: nobody
    g.enter_scene(["van-driver"], g.turn_no(), sid)
    assert g.find_speaker("the Driver", sid)["id"] == "van-driver"   # the one in the scene
    assert g.find_speaker("Voice from the car", sid) is None
    card = CampaignTable._dialogue_card(SimpleNamespace(game=g), {"speaker": "Berit", "text": "Find him."})
    assert card["author"] == "Berit Strom" and card["speaker_id"] == "berit-strom"
