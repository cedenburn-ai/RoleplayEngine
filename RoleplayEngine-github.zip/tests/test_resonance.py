"""Technomancers: the living persona, complex forms with fading, and sprites that owe tasks."""
import pytest

from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import matrix, resonance, sr_lite
from roleplay.setup import setup_demo


def _techno(g):
    return g.create_pc("Static", "technomancer", "static", "ork technomancer", 1)


def _host(g, rating=4):
    return g.introduce("host", "Ares Lab Host", "a cathedral of chrome pipes", rating=rating, turn=1)[0]


def test_living_persona_and_stable_refs(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    assert matrix.deck(L, tm) == (6, "Living persona") and matrix.living(L, tm)
    matrix.act(L, g.dice, 1, tm, "jack_in", _host(g))                     # no deck, still jacks in
    refs = sr_lite.advancement_refs()
    assert refs[19] == "firearms" and refs[31] == "resonance" and refs[33] == "compiling"   # old numbers kept
    with pytest.raises(LedgerError, match="Resonance can't be bought"):
        sr_lite.advance(L, 1, "razor", "31")
    with pytest.raises(LedgerError, match="needs Resonance"):
        sr_lite.advance(L, 1, "razor", "software")


def test_ic_hits_a_technomancer_as_stun(make_game):
    g = make_game(dice=ScriptedDice([6] * 8 + [2] * 11 + [2] * 12))      # Killer: 8 vs 0, soak 0 of 12
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    matrix.act(L, g.dice, 1, tm, "jack_in", _host(g))
    lines = matrix._ic_attack(L, g.dice, 1, tm, {"type": "killer", "rating": 4, "damage": 0, "active": True}, {})
    # the living persona's Device Rating (Resonance 6) + Firewall (6) soak it - Matrix damage, as a deck's (flag #29)
    assert "soaks Device Rating 6 + Firewall 6 = 12d6 -> 0 hits: living persona takes 12S" in lines[0]
    assert L.stat(tm, "stun_damage") == 11                                # (monitor caps stun)


def test_complex_forms(make_game):
    g = make_game(dice=ScriptedDice([6] * 4 + [2] * 8 + [2] * 11         # Cleaner: 4 hits, fading 6 unsoaked
                                    + [6] * 6 + [2] * 6 + [2] * 8 + [2] * 11))   # Puppeteer: 6 vs 0; fading
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    hid = _host(g)
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", present=True, turn=1)
    matrix.act(L, g.dice, 1, tm, "jack_in", hid)
    st = matrix.state(L, tm)
    st["overwatch"] = 10
    matrix._save(L, tm, st)
    res = resonance.thread(L, g.dice, 1, tm, "Cleaner", 6)
    assert "Resonance 6 + Software 6 = 12d6" in res["card"] and "Overwatch -4" in res["card"]
    assert matrix.state(L, tm)["overwatch"] == 6 and "Fading 6S" in res["card"]
    res = resonance.thread(L, g.dice, 1, tm, "Puppeteer", 4, dog)
    assert "Doberman answers to Static now - no access needed" in res["card"]
    assert L.get(dog)["props"]["controller"] == tm and matrix.state(L, tm)["overwatch"] == 6 + 4
    with pytest.raises(LedgerError, match="isn't in a host"):
        resonance._in_host(L, "razor")


def _jacked(g, overwatch=10):
    setup_demo(g)
    tm = _techno(g)
    matrix.act(g.ledger, g.dice, 1, tm, "jack_in", _host(g))
    st = matrix.state(g.ledger, tm)
    st["overwatch"] = overwatch
    matrix._save(g.ledger, tm, st)
    return tm


def test_threading_is_limited_by_the_level_and_fades_physical_on_hits(make_game):
    """SR5 p. 250-252: Software + Resonance [Level], and the fading is physical when the threading HITS beat
    Resonance - not the Level (the original build's rule; §7g fixed it for spells only)."""
    g = make_game(dice=ScriptedDice([6] * 6 + [2] * 6 + [2] * 11       # Cleaner L4: 6 hits, the Level keeps 4
                                    + [6] * 3 + [2] * 8 + [2] * 11))    # L8 (-1 for wounds): 3 hits - still stun
    tm = _jacked(g)
    L = g.ledger
    res = resonance.thread(L, g.dice, 1, tm, "Cleaner", 4)
    assert "(limit: Level 4 -> 4)" in res["card"] and "Overwatch -4" in res["card"]
    assert "Fading 4S · Cleaner L+0 at Level 4" in res["card"]
    res = resonance.thread(L, g.dice, 1, tm, "Cleaner", 8)
    assert "at Level 8 (over Resonance)" in res["card"] and "Fading 8S · Cleaner L+0 at Level 8" in res["card"]
    assert L.stat(tm, "physical_damage") == 0
    g2 = make_game(dice=ScriptedDice([6] * 8 + [2] * 4 + [2] * 11))   # 8 hits at Level 8: past Resonance 6
    tm2 = _jacked(g2)
    res = resonance.thread(g2.ledger, g2.dice, 1, tm2, "Cleaner", 8)
    assert "Fading 8P (hits over Resonance)" in res["card"] and g2.ledger.stat(tm2, "physical_damage") == 8


def test_held_forms_cost_dice_and_static_veil_blinds_patrol(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 9 + [2] * 11 + [2] * 30))
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    hid = _host(g)
    matrix.act(L, g.dice, 1, tm, "jack_in", hid)
    resonance.thread(L, g.dice, 1, tm, "Static Veil", 4)
    assert resonance.veiled(L, tm) and ("Sustaining 1 form", -2) in sr_lite.build_pool(L, tm, "software")[1]
    hp = L.get(hid)["props"]
    for ic in hp["ic"]:
        ic["active"] = ic["type"] == "patrol"
    L.update_entity(hid, props=hp)
    ow = matrix.state(L, tm)["overwatch"]
    matrix._respond(L, g.dice, 1, tm, matrix.state(L, tm), hid, {})
    assert matrix.state(L, tm)["overwatch"] == ow                        # Patrol can't see through the veil
    resonance.release(L, tm)
    assert not resonance.veiled(L, tm) and L.stat(tm, "sustaining_forms") == 0


def test_sprites_owe_tasks(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 8 + [5] + [2] * 3 + [2] * 11   # 3 vs 1: two tasks; fading 2
                                    + [2] * 30))
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    hid = _host(g)
    ctx = TurnContext(g, 9, g.current_scene_id())
    dispatch(ctx, "matrix", {"decker_id": tm, "action": "jack_in", "host_id": hid})
    card = dispatch(ctx, "sprite", {"techno_id": tm, "action": "compile", "sprite_type": "crack", "level": 4})
    sid = next(e["id"] for e in L.entities(kind="sprite"))
    assert "owes 2 task(s)" in card and "Fading 2S · 2 x 1 sprite hit" in card and sid in L.roster(g.current_scene_id())
    assert "SPRITE (crack, Level 4; Static's, 2 task(s) left)" in sr_lite.sheet(L, sid)
    card = dispatch(ctx, "sprite", {"techno_id": tm, "action": "task", "sprite_id": sid, "task": "help me in"})
    assert "next Matrix action gets +4 dice" in card and "1 task(s) left" in card
    n, parts = matrix._pool(L, tm, "hacking", None, False)
    assert ("Crack sprite", 4) in parts and L.stat(tm, "sprite_assist") == 0   # used once
    card = dispatch(ctx, "sprite", {"techno_id": tm, "action": "task", "sprite_id": sid, "task": "data search"})
    assert "decompiles" in card and L.get(sid)["status"] == "departed"


def test_forms_must_be_known_and_can_be_learned(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    tm = _techno(g)
    L.update_entity(tm, props={**L.get(tm)["props"], "forms": ["cleaner"]})
    matrix.act(L, g.dice, 1, tm, "jack_in", _host(g))
    with pytest.raises(LedgerError, match="doesn't know Puppeteer"):
        resonance.thread(L, g.dice, 1, tm, "Puppeteer", 3, "kaz")
    sr_lite.award_karma(L, 1, tm, resonance.LEARN_COST)                      # 4, like SR5 (p. 107) - the sheets said 5
    assert sr_lite.advance(L, 1, tm, "form Puppeteer L+2")["card"].startswith("[KARMA] Static learns Puppeteer")
    assert L.stat(tm, "karma") == 0
