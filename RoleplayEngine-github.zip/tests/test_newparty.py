"""A new party in the same world (newparty.py): the old crew become the GM's NPCs with their whole record, the ledger
lets them go, the story skips ahead while the world catches up, a new session and a new chapter - and the way back."""
import asyncio
import json
import re
from pathlib import Path
from types import SimpleNamespace

import pytest

from roleplay import charledger, newparty
from roleplay.discord_bot import bot as botmod
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import world
from roleplay.engine import clock
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import machines
from roleplay.graphlog import fmt
from roleplay.setup import setup_blank, setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel
from .test_session_zero import FakeDiscordChannel

COMMIT = {"summary": "Razor leaned on Kaz about a buyer while Ghost watched the door.", "recalled": [], "facts": [],
          "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
          "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"}, {"id": "ghost", "role": "present"}]}


def persona(name: str) -> dict:
    return {"temperament": f"{name} stays cool until cornered.", "motivations": "Money and a quiet life.",
            "lines": "Never sells out a friend.", "prejudices": "Distrusts corps.", "voice": "Few words, flat.",
            "backstory": "Came up hard in the Barrens.", "hooks": ["owes a fixer"], "connections": "A fence or two.",
            "secret": "", "affiliations": []}


MINDS = {
    "Razor": {"persona": persona("Razor"),
              "beliefs": [{"about": "kaz", "attitude": 2, "belief": "Razor thinks Kaz is the one honest bartender in "
                                                                   "Redmond."},
                          {"about": "ghost", "attitude": 1, "belief": "Razor thinks Ghost talks too much but delivers."},
                          {"about": "tanaka", "attitude": -2, "belief": "Razor never met Tanaka."},     # (never dealt)
                          {"about": "nobody-at-all", "attitude": 3, "belief": "Nobody."}],
              "goal": {"goal": "pay back the favor Kaz is owed by keeping the Ancients off the Lucky Shot",
                       "targets": ["kaz", "joey-two-knives"]},
              "whereabouts": {"where": "a coffin motel off the Redmond strip", "place": "Redmond Barrens"},
              "epilogue": "Razor took his cut, sold his coat and rented a coffin over the strip."},
    "Ghost": {"persona": persona("Ghost"),
              "beliefs": [{"about": "razor", "attitude": 2, "belief": "Ghost thinks Razor saved his life on the 520."}],
              "goal": {"goal": "crack the Renraku chip and sell what's on it", "targets": ["tanaka"]},
              "whereabouts": {"where": "the back booth at the Lucky Shot", "place": "the-lucky-shot"},
              "epilogue": "Ghost kept the booth at the Lucky Shot and the chip in his sock."},
}
MOVES = ["{n} sold a rumor to a reporter at Pike Place.", "{n} checked an old dead drop under the monorail tracks.",
         "{n} called in a favor from a Lone Star dispatcher downtown.", "{n} spent a night watching a garage in Tacoma.",
         "{n} bought noodles for an informant in Renton.", "{n} lost money at a rigged card table in Puyallup.",
         "{n} slept through a rainy Sunday in a capsule hotel.", "{n} haggled for ammunition with a dwarf in Everett."]


def brain(calls: list):
    """FakeLLM.extraction for every read a new party makes (and the turns around it), by what the prompt says."""
    def answer(user: str):
        calls.append(user.split("\n", 1)[0][:60])
        m = re.match(r"FORMER PLAYER CHARACTER: (\w+)", user)
        if m:
            return MINDS[m.group(1)]
        if "HOW THEY FELT BEFORE" in user:                    # the scene closing: NPC minds settle about the crew
            return {"beliefs": [{"about": "razor", "attitude": 1, "belief": "Kaz thinks Razor is good for his word.",
                                 "changed": True}]}
        if "WHAT JUST HAPPENED TO YOU" in user:               # an offscreen move
            name = re.match(r"(?:CHARACTER|FACTION): (.+?) \[", user).group(1)
            aid = re.search(r"YOUR AGENDAS:\n- \[(A\d+)\]", user)
            n = sum(1 for c in calls if name in c)
            return {"decision": "continue" if aid else "none", "agenda_id": aid.group(1) if aid else "", "goal": "",
                    "targets": [], "action": "made a move", "test_skill": "", "test_threshold": 0,
                    "on_success": MOVES[n % len(MOVES)].format(n=name), "on_failure": "", "learns_on_success": [],
                    "spend": 0, "new_people": [], "contacts": [], "acquire": [], "whereabouts": [],
                    "hook": "Razor could put a job in a new crew's way at the Lucky Shot." if name == "Razor" else "",
                    "hook_about": ["kaz"] if name == "Razor" else [], "hook_replaces": [], "feeling_about": "", "feeling_attitude": 0,
                    "feeling_belief": "", "wait_minutes": 2880}
        if user.startswith("NPC:"):
            return persona(user.split(":", 1)[1].split("[")[0].strip())
        return COMMIT                                        # (the memory pass, and anything else asked)
    return answer


def demo_world(make_game, calls: list, script=None, ledger=True):
    g = make_game(FakeLLM(script or [], brain(calls)))
    setup_demo(g)
    for eid, uid, who in (("razor", "7", "Jo"), ("ghost", "8", "Al")):
        if ledger:                                            # (both checked out to this world, as play leaves them)
            charledger.register(g, eid, uid, who)
        g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)", (uid, eid, who))
    for _ in range(2):                                        # two played turns in the scene: Kaz has things to settle
        g.run_turn([("razor", "Kaz, who buys Renraku data?")])
    return g


def test_the_old_crew_become_the_worlds_npcs(make_game, tmp_path):
    calls = []
    g = demo_world(make_game, calls)
    L, S = g.ledger, g.sub
    host, _ = g.introduce("host", "Renraku chip host", "", rating=5)
    L.update_entity("ghost", props={**L.get("ghost")["props"], "matrix": {"host": host, "node": "n1", "mode": "ar"}})
    L.set_stat("razor", "stun_damage", 3)
    L.set_stat("razor", "karma", 7)
    g.conn.execute("INSERT INTO jobs(id, title, status, progress, created_turn) VALUES('J1', 'Sell the chip', 'active', "
                   "'Looking for a buyer.', 4)")
    g.ledger.set_meta("canon", json.dumps({"turn": 5, "settled": [], "upcoming": ["Renraku comes for the chip"],
                                            "people": [{"id": "razor", "name": "Razor", "stands": "a PC"}]}))
    before = {e: (L.stats(e), sorted(i["id"] for i in L.holdings(e)), sorted(m["id"] for m in machines.owned_by(L, e)),
                  len(S.links_of(e))) for e in ("razor", "ghost")}
    kaz_view = S.current_belief("kaz", "razor")
    t, start, session, sid = g.turn_no(), g.clock(), L.session(), g.current_scene_id()

    res = newparty.run(g, backup_root=tmp_path / "bk")
    rec = res["record"]

    for eid in ("razor", "ghost"):                            # NPCs the GM plays - with everything they had
        e = L.get(eid)
        assert e["kind"] == "npc" and e["tier"] == 2 and e["player"] is None and e["status"] == "active"
        assert "ledger" not in e["props"] and e["props"]["former_pc"]["ledger"] == eid
        assert world.persona(e) and e["props"]["whereabouts"]["where"]
        stats, items, drones, links = before[eid]
        assert {k: v for k, v in L.stats(eid).items() if not k.startswith(("attitude:", "stun_damage", "rest_"))} == \
            {k: v for k, v in stats.items() if not k.startswith(("stun_damage", "rest_"))}
        assert sorted(i["id"] for i in L.holdings(eid)) == items
        assert sorted(m["id"] for m in machines.owned_by(L, eid)) == drones
        assert len(S.links_of(eid)) >= links
        assert not g.conn.execute("SELECT 1 FROM scene_roster WHERE entity_id=?", (eid,)).fetchone()
        assert g.control_of(eid) == "gm" and g.character_for(eid) is None
        assert world.agendas_of(g, eid) and g.conn.execute("SELECT 1 FROM world_actors WHERE npc_id=?", (eid,)).fetchone()
        assert any("A player character until the new party" in n["text"] for n in S.notes_for(eid, 5))
    assert not g.conn.execute("SELECT 1 FROM players").fetchone()
    assert S.current_belief("kaz", "razor")["id"] != kaz_view["id"] if kaz_view else S.current_belief("kaz", "razor")
    # Their own minds: views only of the people they actually dealt with, from what they witnessed
    assert S.current_belief("razor", "kaz") and L.stat("razor", "attitude:kaz") == 2
    assert S.current_belief("razor", "ghost") and S.current_belief("ghost", "razor")
    assert L.stat("ghost", "attitude:razor") == 1             # (+2 at the split; three weeks apart cool it - minds.cool)
    assert any("Ghost -> Razor +2 to +1" in m for m in res["mended"])
    assert S.current_belief("razor", "tanaka") is None
    first = next(u for u in calls if u.startswith("FORMER PLAYER CHARACTER: Razor"))
    assert first
    assert L.get("razor")["props"]["whereabouts"]["place"] == "Redmond Barrens"
    assert "Razor took his cut" in rec["old_crew"][0]["epilogue"] or "Razor took his cut" in rec["old_crew"][1]["epilogue"]
    # The ledger: progress and a backstory home, the checkout released, and never back into this world
    r = charledger.get(g, "Razor")
    assert r["campaign"] is None and r["entity_id"] is None and r["data"]["stats"]["karma"] == 7
    assert r["backstory"][-1] == {"world": g.path.stem, "text": "scene summary"}
    with pytest.raises(LedgerError, match="already has someone called Razor"):
        charledger.check_out(g, "Razor", "7", g.turn_no())
    other = make_game(FakeLLM())
    setup_blank(other, "Downtown Seattle", "rain")
    eid, back = charledger.check_out(other, "Razor", "7", 1)  # (on the shelf: any other world can have him)
    assert not back and other.ledger.get(eid)["kind"] == "pc"
    # The skip: the clock, the session, the scene, the world's moves
    assert g.clock() == start + newparty.DEFAULT_GAP and rec["clock_to"] == g.clock()
    assert L.session() == session + 1 == rec["session"]
    assert L.scene(sid)["status"] == "closed" and L.scene(sid)["closed_turn"] == t
    assert g.current_scene_id() == rec["scene_opened"] != sid and L.current_scene()["title"] == "Three weeks later"
    assert L.roster(rec["scene_opened"]) == []
    assert len(rec["passes"]) == 4 and rec["passes"][-1] == g.clock()
    steps = [a for a in world.agendas_of(g, "razor") if a["steps"]]
    assert steps and rec["world_moves"] >= 2 and rec["hooks"] >= 1   # the world moved them across the gap
    assert g.conn.execute("SELECT 1 FROM nodes WHERE kind='slice' AND visibility='offscreen' AND text LIKE "
                          "'Razor took his cut%'").fetchone()
    assert g.turn_no() == t                                  # (a reset isn't a turn)
    # What the clock's rules do with three weeks, and the threads that stay with the old crew
    assert L.stat("razor", "stun_damage") == 0
    assert not (L.get("ghost")["props"]["matrix"].get("host"))
    assert {o["id"]: o["jacked_out"] for o in res["crew"]} == {"ghost": "Renraku chip host", "razor": None}
    assert g.conn.execute("SELECT status FROM jobs WHERE id='J1'").fetchone()[0] == "dropped"
    c = json.loads(L.meta("canon"))
    assert "went its separate ways" in c["settled"][-1]["what"] and "no longer a player character" in c["people"][0]["stands"]
    assert c["upcoming"][0].startswith("(before the three weeks skip)")
    # The backup, and !undo can't reach back across it
    folder = Path(rec["backup"])
    assert folder.parent == tmp_path / "bk"
    assert (folder / g.path.name).exists() and (folder / "character_ledger.db").exists() and (folder / "README.txt").exists()
    assert sorted(p.name for p in (folder / "undo").glob("before_*.db")) == ["before_000004.db", "before_000005.db"]
    assert "isn't a turn" in g.undo() and newparty.pending(g)["turn"] == t
    with pytest.raises(LedgerError, match="hasn't opened yet"):
        newparty.run(g, backup_root=tmp_path / "bk")          # (one at a time: the last hasn't opened)
    # The owner's summary and the table's card
    text_ = newparty.owner_text(g, res)
    assert rec["backup"] in text_ and "Razor" in text_ and "goal [A" in text_
    card = newparty.card(g, rec)
    assert card["title"] == "⏳ Three weeks later..." and "Razor took his cut" in card["description"]
    assert "!characterledger checkout" in card["description"]


def test_a_failure_halfway_puts_the_world_back(make_game, tmp_path, monkeypatch):
    calls = []
    g = demo_world(make_game, calls)
    t, start, scene = g.turn_no(), g.clock(), g.current_scene_id()

    def boom(*a, **k):
        raise RuntimeError("the world pass fell over")
    monkeypatch.setattr(newparty, "_catch_up", boom)
    with pytest.raises(RuntimeError):
        newparty.run(g, backup_root=tmp_path / "bk")
    L = g.ledger
    assert L.get("razor")["kind"] == "pc" and L.get("razor")["props"]["ledger"] == "razor"
    assert charledger.get(g, "Razor")["campaign"] == g.path.stem and charledger.get(g, "Razor")["backstory"] == []
    assert g.clock() == start and g.current_scene_id() == scene and g.turn_no() == t and newparty.last(g) is None
    assert g.conn.execute("SELECT COUNT(*) FROM players").fetchone()[0] == 2
    assert g.sub.recorder.marks == []


def test_the_way_back_until_the_new_crew_plays(make_game, tmp_path):
    calls = []
    g = demo_world(make_game, calls)
    start = g.clock()
    newparty.run(g, backup_root=tmp_path / "bk")
    marco = make_game(FakeLLM())                              # someone checks a runner out into the new chapter...
    setup_blank(marco, "Downtown Seattle", "rain")
    k = charledger.register(marco, marco.create_pc("Marco", "decker", "marco"), "9", "Alice")
    charledger.check_in(marco, "marco", write_backstory=False)
    charledger.check_out(g, "Marco", "9", g.turn_no())
    rec = newparty.undo(g)
    L = g.ledger
    assert L.get("razor")["kind"] == "pc" and L.get("razor")["props"]["ledger"] == "razor" and L.get("marco") is None
    assert charledger.get(g, "Razor")["campaign"] == g.path.stem and charledger.get(g, "Marco")["campaign"] is None
    assert g.clock() == start and newparty.last(g) is None and rec["old_crew"]
    assert g.conn.execute("SELECT COUNT(*) FROM players").fetchone()[0] == 2
    assert g.undo().startswith("Undid turn 5")               # (the snapshots are back where !undo finds them)
    marks = fmt.read_marks(fmt.log_dir(g.path))
    assert [m["kind"] for m in marks] == ["new-party", "new-party-undone"] and g.sub.recorder.marks == []
    assert k == "marco"
    # Once the new crew has played, the way back is !undo to the start of the chapter first
    g2 = demo_world(make_game, [], ledger=False)
    newparty.run(g2, backup_root=tmp_path / "bk2")
    g2.create_pc("Nova", "street_samurai", "nova", "", g2.turn_no())
    g2.enter_scene(["nova"], g2.turn_no())
    g2.run_turn([("nova", "I look around.")])
    with pytest.raises(LedgerError, match="played since"):
        newparty.can_undo(g2)


def test_the_table_confirms_then_opens_a_new_chapter(make_game, tmp_path, monkeypatch):
    monkeypatch.setenv("ROLEPLAY_BACKUP_DIR", str(tmp_path / "backups"))
    calls = []
    opening = [([text("Rain on the windows of a Tacoma noodle bar. **Mr. Johnson:** \"You're the new crew.\"")],
                "end_turn")]
    g = demo_world(make_game, calls, script=[([text("Kaz shrugs.")], "end_turn")] * 2 + opening)

    async def go():
        ch, dch = FakeChannel(), FakeDiscordChannel(42)
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()
        b = botmod.RPBot()
        b.bindings["42"] = {"campaign": g.path.stem, "owner": "1"}
        b.tables[42] = t

        def msg(uid, admin=False):
            return SimpleNamespace(channel=dch, author=SimpleNamespace(
                id=int(uid), guild_permissions=SimpleNamespace(manage_guild=admin)))
        await b.rp_command(msg("7"), "!rp newparty 3 weeks")
        assert "Only the campaign owner" in dch.sent[-1] and 42 not in b.pending
        await b.rp_command(msg("1"), "!rp newparty a fortnight | Razor and Ghost slipped out the back before "
                                     "Renraku's team came through the door.")
        assert b.pending[42]["kind"] == "newparty" and b.pending[42]["gap"] == 14 * clock.DAY
        assert b.pending[42]["ending"].startswith("Razor and Ghost slipped out")
        await b.answer_restart(dch, "7", True)                # not the asker: nothing happens
        assert L_kind(g, "razor") == "pc"
        await b.answer_restart(dch, "1", True)
        assert L_kind(g, "razor") == "npc" and 42 not in b.pending
        if t.canon_task is not None:                          # (the read-back it kicked off, done before we look on)
            await t.canon_task
        card = next(m for m in ch.sent if (m["title"] or "") == "⏳ A fortnight later...")
        assert "**How it ended:** Razor and Ghost slipped out the back" in card["description"]
        end = newparty.last(g)["ending_id"]                   # (everyone still in the scene lived it - Kaz too)
        assert end in {r["id"] for r in g.sub.witnessed_slices("kaz", 50)}
        assert g.sub.node(end)["visibility"] == "public" and g.sub.node(end)["scene_id"] == newparty.last(g)["scene_closed"]
        assert any(c.startswith("FORMER PLAYER CHARACTER") for c in calls)
        assert any("New party ready" in (m["text"] or "") for m in ch.sent)
        assert ch.dms and ch.dms[-1][0] == "1" and "Backup" in ch.dms[-1][1]
        assert (tmp_path / "backups" / "newparty").exists()
        await t.welcome(g.path.stem)                          # (the bot comes back up: the chapter's own session zero)
        assert (ch.sent[-1]["title"] or "").startswith("⏳ A fortnight later")

        reacts = []

        async def react(e):
            reacts.append(e)
        t.paused = True                                       # (while a reset runs, posts don't go into a turn)
        await t.handle("9", "Alice", "I walk into the bar.", False, react)
        assert reacts == ["⏸️"] and not t.director.queue
        t.paused = False
        await t.handle("9", "Alice", "!join razor", False, react)
        assert "isn't in this scene" in ch.sent[-1]["text"]  # (the old crew are NPCs out in the world now)
        await t.handle("9", "Alice", "!begin", False, react)
        assert "Nobody has a runner yet" in ch.sent[-1]["text"]
        await t.handle("9", "Alice", "!newchar Nova street_samurai", False, react)
        assert t.handles == {"9": "nova"}
        await t.handle("9", "Alice", "!begin a quiet data job", False, react)
        assert any("Here we go: **Nova**" in (m["text"] or "") for m in ch.sent)
        req = g.llm.dm_requests[-1]
        assert "A new chapter in a world already in motion" in req and "Nova (street samurai)" in req
        assert "The players asked for: a quiet data job" in req and "Ghost, Razor" in req
        assert "How the old story ended: Razor and Ghost slipped out the back" in req
        assert any("You're the new crew" in (m["description"] or "") for m in ch.sent)
        assert newparty.pending(g) is None and t._started()
        await t.handle("9", "Alice", "!begin", False, react)
        assert "already going" in ch.sent[-1]["text"]
        # The graph log carried on: the opening turn's file has the reset in it
        d = fmt.log_dir(g.path)
        doc = fmt.read_turn(d, g.turn_no())
        assert doc["process"]["marks"][0]["kind"] == "new-party"
        assert set(doc["process"]["marks"][0]["former_pcs"]) == {"razor", "ghost"}
        whys = {x["why"] for x in doc["process"]["touches"] if x["phase"] == "between"}
        assert {"new-party", "offscreen"} <= whys
        assert fmt.turns_on_file(d)[-2:] == [g.turn_no() - 1, g.turn_no()]
        from roleplay.graphlog import analyze
        ch_ = analyze.analyze(d, tmp_path / "analysis")["summary"]["chapters"]
        assert ch_ and ch_[0]["former_pcs"] and ch_[0]["crew_ratio_before"] is not None
        assert "Changes of crew" in (tmp_path / "analysis" / "report.html").read_text(encoding="utf-8")
        await t.handle("1", "Owner", "!undo", True, react)
        assert "Undid turn" in ch.sent[-1]["text"]           # (the new crew's turns undo as any turn does)
        await t.close()
        await b.close()
    asyncio.run(go())


def L_kind(g, eid):
    return g.ledger.get(eid)["kind"]


def test_the_console_asks_first(make_game, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("ROLEPLAY_BACKUP_DIR", str(tmp_path / "backups"))
    from roleplay.console import Console
    g = demo_world(make_game, [])
    c = Console(g)
    c.handle("!newparty 10 days")
    out = capsys.readouterr().out
    assert "!newparty confirm" in out and g.ledger.get("razor")["kind"] == "pc"
    c.handle("!newparty confirm")
    out = capsys.readouterr().out
    assert g.ledger.get("razor")["kind"] == "npc" and "Ten days later" in out and "Backup" in out
    c.handle("!newparty confirm")
    assert "nothing to confirm" in capsys.readouterr().out
    c.handle("!newparty undo")
    c.handle("!newparty confirm")
    assert g.ledger.get("razor")["kind"] == "pc" and "taken back" in capsys.readouterr().out


def test_a_world_nobody_plays_just_skips_ahead(make_game, tmp_path):
    g = make_game(FakeLLM([], brain([])))
    setup_blank(g, "Downtown Seattle", "rain")
    g.run_turn([("scene", "(Stage direction from the table, not a character - open the scene: rain.)")])
    start = g.clock()
    res = newparty.run(g, 7 * clock.DAY, "a week", backup_root=tmp_path / "bk")
    assert res["crew"] == [] and g.clock() == start + 7 * clock.DAY and len(res["record"]["passes"]) == 2
    assert "old crew" not in newparty.opening(g, "Nova (street samurai): a big troll")
    plan = {"crew": [], "label": "a week", "clock_from": 0, "clock_to": 7 * clock.DAY, "scene": "Opening",
            "passes": 2, "session": 2, "backup": "b", "calls": 3}
    assert "Nobody's playing a runner here" in newparty.confirm_text(plan)
    assert "How did the old story end?" in newparty.confirm_text(plan)


def test_gaps_and_refusals(make_game):
    assert newparty.parse_gap("") == (newparty.DEFAULT_GAP, "three weeks")
    assert newparty.parse_gap("a month later")[0] == 30 * clock.DAY
    for bad in ("evening", "an hour", "two years", "soonish"):
        with pytest.raises(LedgerError):
            newparty.parse_gap(bad)
    g = make_game(FakeLLM())
    setup_blank(g, "Downtown Seattle", "rain")
    with pytest.raises(LedgerError, match="Nothing's been played"):
        newparty.preview(g)
