"""The scene frame (dm/frame.py): who everyone in the room is now and where they stand with each other, built from
their files - and the goals and hooks the story has moved past, retired. (Live T161: Brask's read on Lou was from T48,
five of her goals were from Day 2, three hooks waited to reopen a closed storyline, and how Juno and Brask stood with
each other never reached the GM.)"""
import asyncio

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import canon, frame, world
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM
from .test_discord import FakeChannel

COMMIT = {"summary": "Razor and Kaz talk shop.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}


def _frame(ids: dict) -> dict:
    return {"intent": "Razor came to sell the Renraku chip and get paid tonight.",
            "pressure": "The Ancients are looking for the chip.",
            "people": [{"id": "kaz", "now": "Holding the chip in his safe, nervous since the Ancients came by.",
                        "wants_here": "His cut, and the chip out of his bar before midnight.",
                        "wont": "Deal with Renraku people directly.",
                        "toward": [{"id": "razor", "stance": "Owes him for the Ancients business; trusts him."},
                                   {"id": "joey-two-knives", "stance": "Not here - ignored."},
                                   {"id": "kaz", "stance": "(himself - dropped)"}],
                        "settled": ["The split is 60/40"]},
                       {"id": "razor", "now": "Wants out of the deal fast.", "wants_here": "The money.", "wont": "",
                        "toward": [{"id": "kaz", "stance": "Wary but grateful."}], "settled": []},
                       {"id": "tanaka", "now": "Not in the room", "wants_here": "", "wont": "", "toward": [],
                        "settled": []}],
            "over": [{"id": ids["old"], "why": "the docks meeting already happened"},
                     {"id": ids["hook"], "why": "the buyer came and went"},
                     {"id": "A999", "why": "(not shown - ignored)"}]}


def _world(make_game):
    ids, seen = {}, []

    def structured(user):
        if "EVERYONE IN THE ROOM" in user:
            seen.append(user)
            return _frame(ids)
        return COMMIT
    g = make_game(FakeLLM([], structured))
    setup_demo(g)
    ids["live"] = world.add_agenda(g, "kaz", "Get the chip out of the bar before midnight", ["razor"], 1, "test")
    ids["old"] = world.add_agenda(g, "kaz", "Meet the buyer at the docks at dawn", ["razor"], 1, "test")
    ids["hook"] = world.add_hook(g, "kaz", None, "Kaz's buyer turns up early at the Lucky Shot", ["razor"], 1)
    g.ledger.set_stat("kaz", "attitude:razor", 2)
    g.sub.add_belief("kaz", "razor", "Kaz thinks Razor is reliable but reckless with the Ancients.", 1)
    return g, ids, seen


def test_the_frame_reads_everyone_and_retires_what_is_over(make_game):
    g, ids, seen = _world(make_game)
    sid = g.current_scene_id()
    assert frame.due(g, sid)
    f = frame.run(g, sid)
    text = seen[0]
    assert f"Goal [{ids['live']}]" in text and f"[{ids['hook']}]" in text
    assert "Sees Razor (attitude +2)" in text and "reliable but reckless" in text
    assert [p["id"] for p in f["people"]] == ["kaz", "razor"]                        # (Tanaka isn't here)
    assert [t["id"] for t in f["people"][0]["toward"]] == ["razor"]                  # (nor Joey; nor himself)
    status = lambda t, x: g.conn.execute(f"SELECT status FROM {t} WHERE id=?", (x,)).fetchone()[0]  # noqa: E731
    assert status("agendas", ids["old"]) == "done" and status("agendas", ids["live"]) == "active"
    assert status("hooks", ids["hook"]) == "stale" and len(f["retired"]) == 2
    assert not frame.due(g, sid)


def test_the_packet_leads_with_the_frame_and_shrinks_old_feelings(make_game):
    g, _, _ = _world(make_game)
    sid = g.current_scene_id()
    frame.run(g, sid)
    packet, _ = build_packet(g, sid, [("razor", "So, Kaz - the money?")], 99)
    assert packet.index("=== SCENE FRAME") < packet.index("=== PRESENT ===")
    assert "WHY THEY'RE HERE: Razor came to sell the Renraku chip" in packet
    assert "toward Razor: Owes him for the Ancients business" in packet and "toward Joey" not in packet
    assert "settled with the crew (don't re-open): The split is 60/40" in packet
    assert "Feels about Razor" not in packet and "Attitudes (where they stand is in the SCENE FRAME): Razor +2" in packet
    g.sub.add_belief("kaz", "razor", "Kaz now suspects Razor sold him out.", g.turn_no() + 5)   # newer than the frame
    packet, _ = build_packet(g, sid, [("razor", "So, Kaz - the money?")], 99)
    assert "Feels about Razor" in packet and "sold him out" in packet


def test_it_reframes_when_the_cast_changes_or_the_scene_runs_on(make_game):
    g, _, _ = _world(make_game)
    sid = g.current_scene_id()
    frame.run(g, sid)
    g.ledger.enter(sid, ["joey-two-knives"], g.turn_no())
    assert frame.due(g, sid)
    frame.run(g, sid)
    assert "(Arrived since the frame" not in "\n".join(frame.packet_lines(g, sid))
    for i in range(frame.FRAME_EVERY):
        g.run_turn([("razor", f"Razor haggles, round {i + 1}.")])
    assert frame.due(g, sid)


def test_the_canon_retires_goals_and_hooks_world_wide(make_game):
    g, ids, _ = _world(make_game)
    data = {k: [] for k in ("settled", "people", "holdings", "timeline", "upcoming", "open_threads", "closed_threads",
                            "conflicts", "rulings")}
    data["over"] = [{"id": ids["old"], "why": "happened"}, {"id": "A999", "why": "no such goal"}]
    gathered = canon.gather(g)
    assert f"[{ids['old']}]" in gathered["text"] and "GOALS NPCs AND FACTIONS ARE PURSUING" in gathered["text"]
    res = canon.apply(g, gathered, data)
    assert res["retired"] == [f"{ids['old']} (happened)"]
    assert g.conn.execute("SELECT status FROM agendas WHERE id=?", (ids["live"],)).fetchone()[0] == "active"


def test_the_schema_is_strict():
    def walk(s):
        if s.get("type") == "object":
            assert s.get("additionalProperties") is False and set(s["required"]) == set(s["properties"])
            for v in s["properties"].values():
                walk(v)
        if s.get("type") == "array":
            walk(s["items"])
    walk(frame.schema())
    walk(canon.schema())


def test_at_the_table(make_game):
    g, _, _ = _world(make_game)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("9", "Owner", "!frame now", True, react)
        await t.frame_task
        await t.handle("9", "Owner", "!frame", True, react)
        assert any("Razor came to sell the Renraku chip" in d for _, d in ch.dms if isinstance(d, str))
        await t.handle("1", "Alice", "!frame", False, react)
        assert "for the campaign owner" in ch.sent[-1]["text"]
        await t.close()
    asyncio.run(go())
