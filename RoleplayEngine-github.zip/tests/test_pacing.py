"""Pacing: the engine catches the GM going in circles - an exchange that never lands, NPCs re-asking what's settled -
and the next turn breaks it."""
import asyncio
import json

import pytest

from roleplay import flags
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import aside, pacing
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel

COMMIT = {"summary": "Brask set another condition.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}
READ = {"looping": True, "what": "Kaz keeps re-setting his terms for the job.",
        "break_it": "Kaz takes Razor's last answer and names the meet."}
NO = {"looping": False, "what": "", "break_it": ""}        # the veto: the cheap read sees no loop


def _llm(endings, read=READ, **said_to_gm):
    """said_to_gm: what the GM aside's answer sets (loop=True: it judged the table talk a loop complaint)."""
    reads = []

    def structured(user):
        if "PACING REVIEW" in user:
            reads.append(user)
            return read
        if "SAYS TO YOU, OUT OF CHARACTER" in user:          # (the GM aside)
            return {"answer": "You're right - that's settled. Next turn moves on.", "direction": "", "fixes": [],
                    "is_move": False, **said_to_gm}
        return COMMIT
    return FakeLLM([([text(e)], "end_turn") for e in endings], structured), reads


def test_how_a_turn_ends_and_what_gets_asked_again():
    assert pacing.ends_on_ask('Kaz leans in. **Kaz:** "Him, you, or me?"')
    assert pacing.ends_on_ask("Pembrook sets a mug down and waits for him to decide about the call.")
    assert pacing.ends_on_ask("Brask and Greta both look at Magic.")
    assert pacing.ends_on_ask("Cops, press, or both. Your call, chummer.")
    assert not pacing.ends_on_ask("Across town, Low Wharf's eight o'clock is getting closer.")
    old = [(12, 'Brask: "And where am I meant to sleep, someplace Calloway would never think to check?"')]
    assert pacing.reasked('Juno: "So where is Bo meant to sleep, someplace Calloway would never check?"', old)
    assert not pacing.reasked('Kaz: "Is the money clean?"', old)


def test_a_loop_gets_named_and_the_next_turn_breaks_it(make_game, tmp_path):
    asks = [f'**Kaz:** "Before I say yes - {q}?"' for q in ("who sent you", "why tonight", "who else knows",
                                                             "what's in it for me")]
    llm, reads = _llm(asks + ["Kaz names the meet.", "The van rolls out."])
    g = make_game(llm)
    setup_demo(g)
    for i in range(4):
        g.run_turn([("razor", f"I answer him ({i}).")])
    assert not reads                                                  # (four ends on a question: tripped from now)
    g.run_turn([("razor", "Fine. Deal?")])
    assert len(reads) == 1 and "the last 4 turns all ended with someone waiting on the players" in reads[0]
    msg = llm.dm_requests[-1]
    assert "PACING - the engine noticed the story going in circles" in msg and "Kaz keeps re-setting his terms" in msg
    assert any(f["kind"] == "loop" for f in flags.listing(tmp_path))
    g.run_turn([("razor", "We go.")])                                 # (closed: nothing new to read)
    assert len(reads) == 1


def test_the_players_saying_so_trips_it(make_game):
    llm, reads = _llm(["Kaz squints.", "Kaz shrugs."])
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    g.run_turn([("razor", "Are we there yet? We already told you who sent us.")])
    assert reads and 'the players say so: "already told", "are we there yet"' in reads[0]
    assert "PACING" in llm.dm_requests[-1]


def test_stuck_reads_it_now_and_the_next_turn_breaks_it(make_game, tmp_path):
    llm, reads = _llm(['**Kaz:** "Who sent you?"', "Kaz names the meet."])
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "Alice", "!join razor", False, react)
        turns = g.turn_no()
        await t.handle("1", "Alice", "!stuck Kaz keeps asking the same thing", False, react)
        card = ch.sent[-1]
        assert card["title"] == "🔁 Going in circles? - from Alice" and "Kaz keeps re-setting" in card["description"]
        assert g.turn_no() == turns and g.ledger.meta(pacing.FORCED)                # no turn spent; the nudge waits
        assert any(f["kind"] == "loop report" and f["who"] == "Alice" for f in flags.listing(tmp_path))
        g.run_turn([("razor", "So?")])
        assert "Kaz takes Razor's last answer and names the meet." in llm.dm_requests[-1]
        assert not g.ledger.meta(pacing.FORCED)                                   # used once
        await t.close()
    asyncio.run(go())


# ── flags #39, #40, #41, #45 (2026-10-27): the read can't veto the players, a 'no' answers only what it read, and an
# NPC's re-raised demand is caught by speaker and words, however short ──
def test_what_the_players_say_and_how_a_turn_waits():
    assert pacing.said("The teamwork check broke again, and now I'm worried we're heading for another loop.")["loop"] == [
        "another loop"]
    for complaint in ("Hey DM, this is a loop", "we're stuck in a loop with Greta", "You're looping again.",
                      "recurring NPC loops", "This feels recursive", "Brask keeps asking the same question",
                      # (review, 2026-10-27: none of these reached anything)
                      "this feels like a loop", "feels like we are in a loop", "the NPCs are looping",
                      "why does she keep asking about the key?", "hey dm Kaz is looping",
                      "hey dm how many times do I need to answer this", "Hey DM, we keep going around and around.",
                      "Telling the DM she's had her kid all along, it just ignored that and wouldn't go forward",
                      "this exchange is clearly over and it's being padded for time",     # (live T151's, T39's shapes)
                      # (review of flag #45: "it" stalling, and a bare "This is a loop." with no camera in the post)
                      "it ignores the post and won't move forward till it gets a yes or no", "This is a loop.",
                      "That's another loop."):
        assert pacing.said(complaint)["loop"], complaint
    for maybe in ("I told you, I can't know what Pembrook will do.", "She asked again?",
                  "Juno keeps asking for a straight answer", "Greta is looping on the door",
                  "Relax, the guard sees nothing - it's a loop.", "We covered this already.", "Here we go again."):
        s = pacing.said(maybe)                            # worth a read: the read decides
        assert s["maybe"] and not s["loop"], maybe
    npcs = {"juno", "greta", "marrow", "kaz"}              # ...but an NPC on file doing the looping is a complaint
    for complaint in ("Juno keeps asking for a straight answer", "Greta is looping on the door",
                      "Ugh. Kaz is looping again.", "Juno keeps asking for a straight answer when I already told her"):
        assert pacing.said(complaint, npcs)["loop"], complaint
    for line in ("Kaz keeps pushing the cart toward the van.", '"Juno keeps asking for a straight answer," I say.',
                 "Magic keeps asking her about the key."):
        assert not pacing.said(line, npcs)["loop"], line          # (a story verb, a line said, a PC asking)
    assert "This is a loop." not in pacing.said("The camera feed? This is a loop.")["loop"]   # (a decker's)
    for move in ("Filament loops the cameras on the loading dock.", "The feed's looping an empty ramp.",
                 "Call T, we are gonna keep her in the loop", "I flick the cop call into a loop and stash the log.",
                 "I leave the duress channel running on a loop so Spotter's team sees it.",
                 "I push a ghost-loop into the Lucky Shot's grid.", "I want to loop my deck in on this one.",
                 "Magic asks again about the pay.", "I told her about the job.", "I'll keep asking around the bar.",
                 "How many times has he done this?",
                 "just tell her they keep asking for him to drop by the clinic for a checkup",
                 # a decker's loop (review, 2026-10-27: each was a decisive complaint)
                 "Filament keeps the cameras in a loop while we walk past.", "Keep the feed in a loop until we're out.",
                 "Filament puts the cameras on loop again.", "Filament checks the cameras are still looping.",
                 "Filament runs a recursive search on the host.", "I pull a second loop onto his HUD."):
        s = pacing.said(move)
        assert not s["loop"] and not s["maybe"], move
    for line in ('"I told you, we go at dawn."', "I already told Ghost about the plan", "He asks again: Where's the chip?",
                 '"We already agreed on 5k"', "Magic asks her the same question in Sperethiel.",
                 'Magic grabs his collar. "Answer me straight: who hired you?"', '"Like I said, the meet is at noon."',
                 '"I told you, no guns in the van."', "I hit your head with the bat",
                 'Magic: "This is going in circles, Kaz. I already answered that."'):   # (a character says it)
        assert not pacing.said(line)["loop"], line                # never decisive: at most worth a read
    assert pacing.said("I'm not answering any more scenes that delay this")["impatient"]
    # live T183-T186: four turns running ended on Magic being waited on, and none of them counted - their shapes
    assert pacing.ends_on_ask("You haven't said a word since the fixer paid out.")
    assert pacing.ends_on_ask("Magic, the woman's still holding your drink out, and she hasn't stepped back.")
    assert pacing.ends_on_ask("The line goes quiet. She's waiting.")


def test_a_no_answers_only_what_it_read(make_game):
    """Live T145-T147: one 'no' was reused for the next two turns, the players' "are we there yet" with it. Now each
    new trip is read afresh, and a player's word gets through a 'no'."""
    asks = [f'**Kaz:** "Before I say yes - {q}?"' for q in ("who sent you", "why tonight", "who else knows",
                                                             "what's in it for me", "who's driving", "who's the buyer")]
    llm, reads = _llm(asks + ["Kaz names the meet."], read=NO)
    g = make_game(llm)
    setup_demo(g)
    for i in range(4):
        g.run_turn([("razor", f"I answer him ({i}).")])
    g.run_turn([("razor", "Fine. Deal?")])
    assert len(reads) == 1 and "PACING -" not in llm.dm_requests[-1]       # a streak of 4: read, and a 'no'
    g.run_turn([("razor", "Deal?")])
    assert len(reads) == 2 and "PACING -" not in llm.dm_requests[-1]       # a streak of 5: new, so read again
    g.run_turn([("razor", "This is going in circles - I already answered that.")])
    assert len(reads) == 3 and "The players themselves say it's looping" in reads[-1]
    msg = llm.dm_requests[-1]
    assert "PACING - the engine noticed the story going in circles" in msg
    assert '("going in circles", "i already answered that")' in msg
    assert "Open at the end of T" in msg and "Kaz's \"Before I say yes - who's the buyer?\"" in msg


def test_a_loop_said_to_the_gm_reaches_the_next_turn(make_game):
    """Live T158's shape - "The teamwork check broke again, and now I'm worried we're heading for another loop" - is
    table talk now: the aside takes it, so no turn's check would ever see it. The aside hands it on, and the next
    turn's note is firm."""
    llm, reads = _llm(['**Kaz:** "Who sent you?"', "Kaz names the meet."], read=NO)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    said = "The teamwork check broke again, and now I'm worried we're heading for another loop"
    assert aside.table_talk(said)
    aside.ask(g, "Alice (plays Razor [razor])", said, "razor")
    g.run_turn([("razor", "So, the job?")])
    assert reads and 'The players say the story is going in circles ("another loop")' in llm.dm_requests[-1]
    assert not g.ledger.meta(pacing.HEARD)                                 # (heard once)


# ── the review (2026-10-27): what's decisive and what's a read's; a third go is the first go's own question; the
# aside's own read hands a complaint on; and an undo keeps it ──
def test_a_camera_loop_or_a_line_of_dialogue_never_closes_the_scene(make_game, tmp_path):
    """Review: "Filament keeps the cameras in a loop while we walk past the guard post." and a character's '"I told
    you, we go at dawn."' were decisive - a PACING note ("close the exchange, don't end on a question") and a loop flag
    whatever the read said; the live code had let its read decide. A decker's loop is nothing now; words a character
    says too are worth a read, and its 'no' stands."""
    llm, reads = _llm(["Kaz squints.", "The guard yawns.", "Kaz nods.", "Kaz shrugs."], read=NO)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    g.run_turn([("razor", "Filament keeps the cameras in a loop while we walk past the guard post.")])
    assert not reads and "PACING -" not in llm.dm_requests[-1]
    g.run_turn([("razor", '"I told you, we go at dawn."')])
    assert len(reads) == 1 and "Some of the players' words may be a loop complaint" in reads[0]
    assert "PACING -" not in llm.dm_requests[-1]
    g.run_turn([("razor", 'Razor grabs his collar. "Answer me straight: who hired you?"')])
    assert len(reads) == 2 and "PACING -" not in llm.dm_requests[-1]
    assert not [f for f in flags.listing(tmp_path) if f["kind"] == "loop"]


@pytest.mark.parametrize("said_to_gm", [
    "hey dm, the NPCs keep asking the same stuff", "hey dm the NPCs keep asking for a straight answer",
    "hey dm Kaz is looping", "hey dm this feels like a loop", "hey dm she keeps demanding a yes or no",
    "Hey DM, Kaz keeps bringing up who sent us.", "Hey DM, we settled that two turns ago"])
def test_the_gm_s_own_read_of_a_complaint_hands_it_on(make_game, said_to_gm):
    """Review: the aside promises "the next turn closes it", and only the words pacing knew were handed on - "hey dm Kaz
    is looping" and flag #45's "straight answer" demands got the promise and nothing. The aside's own read (`loop` in
    its answer) arms the hand-off now, whatever the words: the next turn's note is firm, in the player's words."""
    llm, reads = _llm(['**Kaz:** "Who sent you?"', "Kaz names the meet."], read=NO, loop=True)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    assert aside.table_talk(said_to_gm) and "loop" in aside.schema()["required"]
    aside.ask(g, "Alice (plays Razor [razor])", said_to_gm, "razor")
    g.run_turn([("razor", "So, the job?")])
    msg = llm.dm_requests[-1]
    assert reads and "PACING - the engine noticed the story going in circles" in msg
    assert "The players say the story is going in circles (" in msg and "Kaz's \"Who sent you?\"" in msg
    assert not g.ledger.meta(pacing.HEARD)


def test_the_gm_s_no_leaves_a_maybe_alone(make_game):
    """...and its 'no' takes a soft word out: "I already told Ghost about the plan, does he know?" asks about the
    record. A firm wording still goes through - the players' own words are decisive - and a move goes to the turn,
    which reads the post itself."""
    llm, reads = _llm(['**Kaz:** "Who sent you?"', "Kaz names the meet."], read=NO, loop=False)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, I already told Ghost about the plan, does he know?", "razor")
    assert not g.ledger.meta(pacing.HEARD)
    said = "Hey DM I think I'm getting into another loop"
    assert pacing.heard(g, "Alice", said, drop=True) == [] and not g.ledger.meta(pacing.HEARD)
    aside.ask(g, "Alice (plays Razor [razor])", said, "razor")
    assert "another loop" in g.ledger.meta(pacing.HEARD)
    g.run_turn([("razor", "So, the job?")])
    assert 'The players say the story is going in circles ("another loop")' in llm.dm_requests[-1]


def test_a_move_said_to_the_gm_is_the_turn_s_to_read(make_game):
    llm, reads = _llm(['**Kaz:** "Who sent you?"'], read=NO, is_move=True)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM I think I'm getting into another loop", "razor")
    assert res["is_move"] and not g.ledger.meta(pacing.HEARD)          # (the post goes to the turn, which reads it)


def test_a_complaint_to_the_gm_outlives_an_undo(make_game):
    """Review: "Hey DM, that's another loop", then !undo of the looping turn - the restore took the complaint with it
    (it came after that turn's snapshot), and the redo heard nothing; a !stuck the same. What the table said between
    turns is kept across an undo, as its rulings and directions are - and what the undone turn used up comes back."""
    llm, reads = _llm(['**Kaz:** "Who sent you?"', '**Kaz:** "Who sent you, really?"'], read=NO)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "Kaz, the job.")])
    g.run_turn([("razor", "A friend sent us.")])
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM I think I'm getting into another loop", "razor")
    assert g.undo().startswith("Undid turn")
    assert "another loop" in g.ledger.meta(pacing.HEARD)
    g.run_turn([("razor", "A friend sent us. Now the job.")])
    assert 'The players say the story is going in circles ("another loop")' in llm.dm_requests[-1]
    stuck = pacing.player_says_stuck(g, "Alice", "Kaz keeps asking who sent us")
    assert g.undo().startswith("Undid turn") and g.ledger.meta(pacing.FORCED) == stuck["note"]
    g.run_turn([("razor", "A friend sent us. The job, Kaz.")])
    assert stuck["note"] in llm.dm_requests[-1]


# ── review of the build (2026-10-27): the loops that still got through ──
def test_a_two_go_chain_the_table_ruled_settled_is_firm(make_game):
    """Review of flag #40: a matching active ruling was only quoted in the note - it never made the chain firm."""
    from roleplay import rulings
    g = make_game(FakeLLM(extraction=lambda u: NO))
    setup_demo(g)
    rulings.add(g, "Kaz's fee is settled at 5k - NPCs don't re-raise it.", "gm")
    t0 = g.turn_no()
    for i, narr in enumerate(['**Kaz:** "The fee - five thousand, or I walk?"', '**Kaz:** "My fee. Five thousand?"'],
                             start=t0 + 1):
        g.conn.execute("INSERT INTO turns(id, scene_id, inputs, narration, status) VALUES (?,?,?,?,'committed')",
                       (i, g.current_scene_id(), json.dumps([["razor", "Fine."]]), narr))
    g.conn.execute("INSERT INTO turns(id, scene_id, inputs, status) VALUES (?,?,?,'open')",
                   (t0 + 3, g.current_scene_id(), json.dumps([["razor", "We move."]])))
    chk = pacing.check(g, [("razor", "We move.")])
    assert chk["raised"] and chk["raised"][0]["firm"]
    assert pacing.pre_turn(g, [("razor", "We move.")]).startswith("Settled: Kaz's")


