"""`!dossier <name>`: the crew's file on someone, put on the table - from the public record only."""
import asyncio
import threading
import time
from pathlib import Path

from roleplay import recap
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel

FILE = {"alias": "", "affiliation": "The Lucky Shot", "status": "CONTACT",
        "who": "Ork bartender who owns the Lucky Shot.", "lately": "Patched the crew up after the bar fight."}


def _llm():
    asked = []

    def write(user):
        asked.append(user)
        return FILE
    return FakeLLM(extraction=write), asked


def test_a_file_is_the_public_record_and_is_kept_until_something_new(make_game):
    llm, asked = _llm()
    g = make_game(llm)
    setup_demo(g)
    g.sub.add_note(["kaz"], "SECRET: Kaz sells the crew's movements to Lone Star.", 3)       # GM-only
    card = recap.file_on(g, "kaz")
    assert card["name"] == "Kaz" and card["status"] == "CONTACT" and Path(card["image"]).exists()
    assert len(asked) == 1 and "SECRET" not in asked[0] and "WHAT THE CREW SAW" in asked[0]
    assert recap.file_on(g, "kaz")["image"] == card["image"] and len(asked) == 1     # kept: no second call
    g.sub.write_slice(30, g.current_scene_id(), "Kaz slid Razor a datachip across the bar.",
                      [("kaz", "actor"), ("razor", "target")], [])
    recap.file_on(g, "kaz")
    assert len(asked) == 2 and "datachip" in asked[1]                                   # something new: rewritten


def test_no_file_on_someone_the_crew_never_met(make_game):
    g = make_game()
    setup_demo(g)
    eid = g.ledger.create_entity("npc", "Mr. Johnson", "A suit nobody has met.", tier=2)
    assert recap.subject(g, eid) is None and recap.file_on(g, eid) is None
    assert "Kaz" in recap.known_people(g) and "Mr. Johnson" not in recap.known_people(g)


def test_dossier_puts_the_file_on_the_table_even_mid_turn(make_game):
    llm, asked = _llm()
    g = make_game(llm)
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        gate = threading.Event()
        busy = t.loop.run_in_executor(t.pool, gate.wait, 30)     # the GM, mid-turn, on the game thread
        t0 = time.time()
        await t.handle("2", "Bob", "!dossier kaz", False, react)
        assert time.time() - t0 < 5 and ch.sent[-1]["title"] == "🗂️ Kaz" and ch.sent[-1]["image"]
        await t.handle("2", "Bob", "!dossier", False, react)
        assert ch.sent[-1]["title"] == "🗂️ The crew's files" and "Kaz" in ch.sent[-1]["description"]
        await t.handle("2", "Bob", "!intel Nobody Atall", False, react)
        assert "No file on anyone called 'Nobody Atall'" in ch.sent[-1]["text"]
        gate.set()
        await busy
        await t.close()
    asyncio.run(go())
