"""The canon (dm/canon.py): the story read back and reconciled - what's settled, contradictions fixed in the record,
the table's rulings reviewed but never dropped without the owner. (Live, T160: Juno kept re-asking where Bo sleeps,
"Dr. Brask is confirmed as a woman" sat in the facts, and R11 still scheduled a Thursday that had come and gone.)"""
import asyncio
import json

from roleplay import rulings
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import canon
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM
from .test_discord import FakeChannel

COMMIT = {"summary": "Razor and Kaz agreed the chip stays in the safe.", "recalled": [], "facts": [], "told": [],
          "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
          "members": [{"id": "razor", "role": "actor"}]}


def _canon(fact_id: str) -> dict:
    return {
        "settled": [{"what": "The chip stays in Kaz's safe until the buyer pays", "since": "T2"}],
        "people": [{"id": "kaz", "name": "Kaz", "stands": "Holding the chip; trusts Razor, wants his cut."}],
        "holdings": ["Kaz: the Renraku datachip (in the safe)"], "timeline": ["Night 1: the deal at the Lucky Shot"],
        "upcoming": ["The buyer comes at midnight"], "open_threads": ["Who tipped off the Ancients?"],
        "closed_threads": ["Whether Kaz can be trusted - he can"],
        "conflicts": [{"issue": f"{fact_id} says Kaz is a woman", "canon": "Kaz is a man (T1 onward)",
                       "fixes": [f"fact kaz (replaces {fact_id}): Kaz is an ork man, the Lucky Shot's owner.",
                                 "clarify kaz: Ork bartender, holding the chip in his safe for Razor until midnight.",
                                 "karma razor: +5 for nothing",                    # (not the canon's to do)
                                 "ruling: the canon makes rules now"]}],           # (nor this)
        "rulings": [{"id": "R1", "verdict": "built_in", "why": "Teamwork caps are the engine's now."},
                    {"id": "R2", "verdict": "keep", "why": "Still the table's call."},
                    {"id": "R3", "verdict": "stale", "why": "Thursday has come and gone."},
                    {"id": "R9", "verdict": "stale", "why": "(no such ruling)"}]}


def _world(make_game):
    seen = []

    def structured(user):
        if "ENGINE RULES" in user:
            seen.append(user)
            return _canon(fid)
        return COMMIT
    g = make_game(FakeLLM([], structured))
    setup_demo(g)
    fid = g.sub.add_fact("Kaz is a woman.", ["kaz"], 1, by="dm")
    for text in ("Teamwork dice cap at the leader's skill.", "Called shots are -4.", "Juno raises Bo on Thursday."):
        rulings.add(g, text, "owner")
    for i in range(2):
        g.run_turn([("razor", f"Razor talks the chip deal through with Kaz, part {i + 1}.")])
    return g, fid, seen


def test_the_read_back_writes_the_canon_and_fixes_the_record(make_game):
    g, fid, seen = _world(make_game)
    karma = g.ledger.stat("razor", "karma")
    res = canon.run(g)
    c = canon.current(g)
    assert c["turn"] == res["turn"] and c["settled"][0]["since"] == "T2" and res["settled"] == 1
    assert "Razor talks the chip deal through" in seen[0] or "chip stays in the safe" in seen[0]
    assert "[R1]" in seen[0] and "TABLE RULINGS" in seen[0]
    # the contradiction is fixed in the record: the old fact superseded, the picture rewritten
    assert g.conn.execute("SELECT 1 FROM supersedes WHERE old_id=?", (fid,)).fetchone()
    assert "holding the chip in his safe" in g.sub.clarification("kaz")["text"]
    assert any("FACT" in e for e in res["fixed"]) and set(res["skipped"]) == {"karma", "ruling"}
    assert g.ledger.stat("razor", "karma") == karma
    assert len(rulings.active(g)) == 3                                      # nothing dropped on its own
    # the packet carries it, near the top
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "Where's the chip?")], 99)
    assert "=== CANON" in packet and "SETTLED: The chip stays in Kaz's safe" in packet
    assert packet.index("=== TABLE RULINGS") < packet.index("=== CANON") < packet.index("=== PRESENT")


def test_rulings_are_suggested_never_dropped_until_the_owner_says(make_game):
    g, _, _ = _world(make_game)
    canon.run(g)
    assert [r["id"] for r in canon.suggested(g)] == ["R1", "R3"]          # (R9 doesn't exist; R2 is kept)
    text = canon.review_text(g)
    assert "**R1**" in text and "**R3**" in text and "R2" not in text and "!rulings tidy" in text
    assert canon.tidy_rulings(g, "9") == ["R1", "R3"]
    assert [r["id"] for r in rulings.active(g)] == ["R2"] and canon.suggested(g) == []
    assert canon.review_text(g) is None


def test_when_its_due(make_game):
    g, _, _ = _world(make_game)
    assert not canon.due(g)                                                 # (two turns: too early for a first one)
    last = canon._last_turn(g)
    g.ledger.set_meta(canon.KEY, json.dumps({"turn": last}))
    assert not canon.due(g)
    g.ledger.set_meta(canon.KEY, json.dumps({"turn": last - canon.CANON_EVERY}))
    assert canon.due(g)


def test_the_schema_is_strict():
    def walk(s):
        if s.get("type") == "object":
            assert s.get("additionalProperties") is False and set(s["required"]) == set(s["properties"])
            for v in s["properties"].values():
                walk(v)
        if s.get("type") == "array":
            walk(s["items"])
    walk(canon.schema())


def test_reconcile_and_tidy_at_the_table(make_game):
    g, _, _ = _world(make_game)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("9", "Owner", "!reconcile", True, react)
        await t.canon_task
        titles = [m.get("title") for m in ch.sent]
        assert "⚖️ Rulings review" in titles
        assert any("read back and reconciled" in (m.get("text") or "") for m in ch.sent)
        await t.handle("1", "Alice", "!rulings tidy", False, react)
        assert "for the campaign owner" in ch.sent[-1]["text"] and len(rulings.active(g)) == 3
        await t.handle("9", "Owner", "!rulings tidy", True, react)
        assert "Dropped **R1**, **R3**" in ch.sent[-1]["text"] and [r["id"] for r in rulings.active(g)] == ["R2"]
        await t.handle("9", "Owner", "!canon", True, react)
        assert any("SETTLED" in d for _, d in ch.dms)
        await t.close()
    asyncio.run(go())


def test_a_thin_picture_never_wipes_a_rich_one(make_game):
    g, _, _ = _world(make_game)
    rich = ("Kaz, ork bartender and owner of the Lucky Shot: brass-capped tusks, a voice like gravel, a soft spot for "
            "strays. He owes Razor for the Ancients business, keeps a shotgun under the bar, and won't deal with Renraku "
            "people directly. He's holding the chip in his safe and wants his cut before midnight.")
    g.sub.clarify("kaz", rich, 1)
    canon.run(g)                                     # its "clarify kaz" is a one-liner: it becomes a note
    assert g.sub.clarification("kaz")["text"] == rich
    note = g.sub.notes_for("kaz", 1)[0]["text"]
    assert note.startswith("Correction (canon read-back") and "holding the chip in his safe" in note


def _fixes(fid: str, *lines: str) -> dict:
    return {**_canon(fid), "conflicts": [{"issue": "T2 says Kaz and Razor fell out", "canon": "They're square",
                                          "fixes": list(lines)}]}


def test_space_separated_fix_lines_land_and_lost_ones_are_flagged(make_game, tmp_path):
    """Live T181: `note quiet-lou filament: T165 death line was an error` was lost, the canon fixes flag listed only
    what landed, and the next pass read the conflict as resolved. Now space-separated ids land, and a line naming
    no one on file is flagged, kept in the canon and shown to the next pass."""
    from roleplay import flags
    g, fid, _ = _world(make_game)
    res = canon.apply(g, canon.gather(g), _fixes(fid, "note kaz razor: Kaz and Razor are square.",
                                                 "note nobody-here: lost"))
    note = next(n for n in g.sub.notes_for("razor", 5) if n["text"] == "Kaz and Razor are square.")
    assert any(n["id"] == note["id"] for n in g.sub.notes_for("kaz", 5))
    assert res["unplaced"] == ["note nobody-here: lost"] and canon.current(g)["unplaced"] == res["unplaced"]
    flag = next(f for f in flags.listing(tmp_path) if f["kind"] == "canon fixes")
    assert "Could not place: note nobody-here: lost" in flag["text"]
    assert "COULD NOT BE PLACED" in canon.render(canon.current(g))           # (the next pass reads it)


def test_a_canon_fix_in_no_line_form_is_flagged_too(make_game, tmp_path):
    """Review (2026-10-24): a fix written with a dash for the colon matched no pattern, was dropped by split, and
    never reached unplaced - so no 'Could not place' flag, and the next pass read the conflict as resolved."""
    from roleplay import flags
    g, fid, _ = _world(make_game)
    res = canon.apply(g, canon.gather(g), _fixes(fid, "note kaz - alive after all"))
    assert res["unplaced"] == ["note kaz - alive after all"] and res["skipped"] == []
    assert "Could not place: note kaz - alive after all" in next(
        f for f in flags.listing(tmp_path) if f["kind"] == "canon fixes")["text"]
    assert "note kaz - alive after all" in canon.render(canon.current(g))


def test_a_thin_bracketed_clarify_is_still_demoted(make_game):
    """The thin-picture guard reads ids the way apply does: 'Kaz [kaz]' is Kaz - so a one-liner can't slip past it
    and wipe his picture."""
    g, fid, _ = _world(make_game)
    rich = "Kaz, ork bartender and owner of the Lucky Shot: " + "brass-capped tusks, a voice like gravel; " * 6
    g.sub.clarify("kaz", rich, 1)
    canon.apply(g, canon.gather(g), _fixes(fid, "clarify Kaz [kaz]: Storyline closed."))
    assert g.sub.clarification("kaz")["text"] == rich
    assert g.sub.notes_for("kaz", 1)[0]["text"].startswith("Correction (canon read-back")


def test_the_canon_log_line_counts_what_it_couldnt_place(make_game, capsys):
    g, fid, _ = _world(make_game)
    g.llm.extraction = lambda user: _fixes(fid, "note nobody-here: lost") if "ENGINE RULES" in user else COMMIT

    async def go():
        t = CampaignTable(g, FakeChannel(), owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        t.kick_canon(force=True)
        await t.canon_task
        await t.close()
    asyncio.run(go())
    assert "0 fixes, 1 unplaced" in capsys.readouterr().out
