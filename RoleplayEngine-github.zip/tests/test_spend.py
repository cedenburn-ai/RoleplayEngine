"""The spend log: every call itemized by campaign and purpose; older turns and images folded in, never twice."""
import sqlite3
import time
from types import SimpleNamespace

from roleplay import spend
from roleplay.dm.llm import Usage


def _usage(inp=1000, out=500):
    return SimpleNamespace(input_tokens=inp, output_tokens=out, cache_read_input_tokens=0,
                           cache_creation_input_tokens=0)


def test_calls_are_filed_under_their_campaign_purpose_and_turn(tmp_path):
    game = SimpleNamespace(path=tmp_path / "rage.db", spend_turn=7)
    u = Usage()
    u.sink = spend.Sink(game)
    cost = u.add("claude-haiku-5-5", _usage(), "memory")
    u.add("claude-opus-5-5", _usage(2000, 1000), "gm")
    assert u.by_purpose["memory"] == cost and u.calls == 2
    rows = sqlite3.connect(tmp_path / "usage.db").execute(
        "SELECT campaign, purpose, model, input, output, turn, cost FROM calls ORDER BY id").fetchall()
    assert rows[0][:6] == ("rage", "memory", "claude-haiku-5-5", 1000, 500, 7) and abs(rows[0][6] - cost) < 1e-9
    assert rows[1][1] == "gm" and rows[1][6] > rows[0][6]


def test_a_broken_sink_never_costs_a_turn(tmp_path):
    u = Usage()
    u.sink = lambda *a: 1 / 0
    assert u.add("claude-haiku-5-5", _usage(), "memory") > 0              # (the call still counts in-process)
    spend.record(tmp_path / "missing" / "deeper", "x", "gm", "m")         # an unwritable folder: silently skipped


def _campaign(folder, name, turns, art=()):
    folder.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(folder / f"{name}.db")
    c.execute("CREATE TABLE turns(id INTEGER PRIMARY KEY, status TEXT, cost REAL, created_at TEXT)")
    c.executemany("INSERT INTO turns VALUES(?,?,?,?)", turns)
    c.execute("CREATE TABLE art(entity_id TEXT, version INT, status TEXT, provider TEXT, model TEXT, created_at TEXT, "
              "created_turn INT)")
    c.executemany("INSERT INTO art VALUES(?,?,?,?,?,?,?)", art)
    c.commit()
    c.close()


def test_earlier_turns_come_in_once_and_never_twice(tmp_path):
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    _campaign(tmp_path, "rage", [(1, "committed", 0.10, now), (2, "committed", 0.20, now), (3, "open", 0.5, now),
                                 (4, "committed", 0.30, now)])
    _campaign(tmp_path / "archive", "rage-20261014-195002", [(1, "committed", 0.05, now)])
    spend.record(tmp_path, "rage", "gm", "claude-opus-5-5", cost=0.25, turn=4)    # turn 4 was itemized live
    assert spend.backfill(tmp_path) == 3                  # turns 1, 2 and the archived world's turn 1
    assert spend.backfill(tmp_path) == 0                  # idempotent
    r = spend.report(tmp_path)
    assert abs(r["all"] - (0.10 + 0.20 + 0.25 + 0.05)) < 1e-9 and abs(r["today"] - r["all"]) < 1e-9
    camps = {c["key"]: c for c in r["by_campaign"]}
    assert camps["rage-20261014-195002"]["archived"] == "2026-10-14T19:50" and camps["rage"]["base"] == "rage"
    assert {p["key"] for p in r["by_purpose"]} == {"gm", "history"}
    assert r["top_turns"][0]["turn"] == 4 and r["top_turns"][0]["itemized"]
    assert abs(spend.report(tmp_path, campaign="rage")["all"] - r["all"]) < 1e-9     # archived copies count
    assert spend.campaign_total(tmp_path, "rage") == round(0.10 + 0.20 + 0.25, 4)


def test_images_are_priced_from_the_art_tables(tmp_path):
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    _campaign(tmp_path, "demo", [], art=[("kaz", 1, "ready", "openai", "gpt-image-2.5-flare", now, 3),
                                          ("razor", 1, "ready", "adopted", None, now, 1),      # an old file: free
                                          ("ghost", 1, "failed", "openai", "gpt-image-2.5-flare", now, 4)])
    r = spend.report(tmp_path)
    assert r["images"]["count"] == 1 and r["images"]["cost"] == spend.IMAGE_PRICES["gpt-image-2.5-flare"]
    assert r["days"][-1]["purposes"]["images"] > 0 and len(r["days"]) == 30
