"""Magic: the GM picks the spell, the Force and the targets; the engine does casting, resistance, damage and drain."""
import json

import pytest

from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import magic, resonance, sr_lite
from roleplay.setup import setup_demo


def _mage(g):
    return g.create_pc("Sable", "mage", "sable", "elf hermetic mage", 1)


def test_manabolt_ignores_armor_and_machines(make_game):
    g = make_game(dice=ScriptedDice([6] * 5 + [2] * 9 + [2] * 4 + [2] * 10))   # 5 hits vs 0; drain soak 0
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    res = magic.cast(L, g.dice, 1, sable, "Manabolt", 6, [{"id": "kaz"}])
    assert "Magic 6 + Sorcery 6 + Sable's Power focus 2 = 14d6" in res["card"]
    assert "Kaz: resists 4d6 -> 0, takes 5P (no armor)" in res["card"]            # the net hits (SR5 p. 283)
    assert "Drain  3S" in res["card"] and L.stat(sable, "stun_damage") == 3        # Force 6 - 3
    assert "Drain  3S · Manabolt F-3 at Force 6" in res["card"]                   # checkable against the sheet
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", turn=1)
    res = magic.cast(L, ScriptedDice([6] * 14 + [2] * 10), 1, sable, "manabolt", 2, [{"id": dog}])
    assert "no mind, no aura - Manabolt passes through" in res["card"]


def test_overcasting_drains_the_body(make_game):
    """Drain turns physical when the hits (after the Force limit) beat the caster's Magic - not the Force (p. 281)."""
    g = make_game(dice=ScriptedDice([6] * 8 + [2] * 6 + [2] * 4 + [2] * 10))   # 8 hits, under the Force 9 limit
    setup_demo(g)
    sable = _mage(g)
    res = magic.cast(g.ledger, g.dice, 1, sable, "Stunbolt", 9, [{"id": "kaz"}])
    assert "Force 9 (overcast)" in res["card"] and "Drain  6P (hits over Magic)" in res["card"]
    assert g.ledger.stat(sable, "physical_damage") == 6
    g2 = make_game(dice=ScriptedDice([2] * 14 + [2] * 4 + [2] * 10))            # overcast, but no hits: stun drain
    setup_demo(g2)
    sable2 = _mage(g2)
    res = magic.cast(g2.ledger, g2.dice, 1, sable2, "Stunbolt", 9, [{"id": "kaz"}])
    assert "Drain  6S" in res["card"] and g2.ledger.stat(sable2, "physical_damage") == 0


def test_fireball_uses_blast_bands(make_game):
    g = make_game(dice=ScriptedDice([6] * 4 + [2] * 10      # 4 hits
                                    + [2] * 3               # Kaz (caught unaware): soak 3 dice, 0 hits
                                    + [2] * 9 + [2] * 6     # Razor dodges 9 dice: 0; soaks 6: 0
                                    + [2] * 10))            # drain
    setup_demo(g)
    sable = _mage(g)
    res = magic.cast(g.ledger, g.dice, 1, sable, "Fireball", 6,
                     [{"id": "kaz", "range": "point_blank", "aware": False}, {"id": "razor", "range": "near"}])
    boxes = {r["id"]: r["boxes"] for r in res["results"]}
    assert boxes == {"kaz": 10, "razor": 5}                  # 6+4 at the center; 6+4-5 near, armor 4 - AP 3
    assert "Drain  5S" in res["card"]


def test_known_spells_learning_and_heal(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 11 + [2] * 10))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    with pytest.raises(LedgerError, match="doesn't know Powerbolt"):
        magic.cast(L, g.dice, 1, sable, "Powerbolt", 4, [{"id": "kaz"}])
    with pytest.raises(LedgerError, match="costs 5 karma"):
        sr_lite.advance(L, 1, sable, "spell powerbolt")
    sr_lite.award_karma(L, 1, sable, 5)
    assert sr_lite.advance(L, 1, sable, "spell Powerbolt F-3")["card"].startswith(   # as the learn list shows it
        "[KARMA] Sable learns Powerbolt")
    L.set_stat("razor", "physical_damage", 5)
    res = magic.cast(L, g.dice, 1, sable, "Heal", 4, [{"id": "razor"}])
    assert "Razor heals 3" in res["card"] and L.stat("razor", "physical_damage") == 2
    assert "Drain  2S · Heal F-4 at Force 4, min 2" in res["card"]               # 4 - 4 = 0: the floor


def test_drain_codes_read_like_the_book():
    """Flag #62: the sheets showed one number ('Stunbolt 3') and the player read it as the modifier. The code is the
    book's (SR5 p. 283): F-3, F+1, a bare F; forms print L+0 (p. 252)."""
    assert (magic.drain_code(-3), magic.drain_code(1), magic.drain_code(0)) == ("F-3", "F+1", "F")
    assert (resonance.fading_code(2), resonance.fading_code(0), resonance.fading_code(-1)) == ("L+2", "L+0", "L-1")
    assert magic.spell_label("stunbolt") == "Stunbolt F-3" and magic.spell_label("mind probe") == "Mind Probe F"
    assert magic.spell_at("physical barrier", 6) == "Physical Barrier F-1 (5)"
    assert resonance.form_label("puppeteer") == "Puppeteer L+2" and resonance.form_at("cleaner", 6) == "Cleaner L+0 (6)"
    assert magic.drain_value(4, -4) == 2 and magic.drain_value(7, -3) == 4
    for typed in ("Stunbolt F-3", "stunbolt (F-3)", "Stunbolt f", "Stunbolt F - 3", "stunbolt"):
        assert magic.spell(typed) == "stunbolt"                               # the sheet's label works as a name
    assert magic.spell("Mind Probe F") == "mind probe" and resonance.form("Puppeteer L+2") == "puppeteer"
    with pytest.raises(LedgerError, match="No spell"):
        magic.spell("Stunbolt F-3 please")


def test_spell_table_is_the_book():
    """Every spell's type, range, duration and drain, from its stat block (SR5 pp. 284-294). Powerbolt was F-2,
    the original build's - the book prints F-3 like every bolt (flag #63)."""
    book = {"manabolt": ("mana", "LOS", "I", -3), "stunbolt": ("mana", "LOS", "I", -3),          # p. 284
            "powerbolt": ("physical", "LOS", "I", -3), "lightning bolt": ("physical", "LOS", "I", -3),
            "fireball": ("physical", "LOS (A)", "I", -1),
            "detect life": ("mana", "T", "S", -3), "clairvoyance": ("mana", "T", "S", -3),     # p. 286
            "mind probe": ("mana", "T", "S", 0),                                                  # p. 287
            "heal": ("mana", "T", "P", -4), "increase reflexes": ("physical", "T", "S", 0),       # p. 288
            "confusion": ("mana", "LOS", "S", -3),                                                # p. 290
            "invisibility": ("mana", "LOS", "S", -2),                                             # p. 291
            "armor": ("physical", "LOS", "S", -2), "control actions": ("mana", "LOS", "S", -1),   # p. 292
            "levitate": ("physical", "LOS", "S", -2),                                             # p. 293
            "physical barrier": ("physical", "LOS (A)", "S", -1)}                                 # p. 294
    assert {k: (v["type"], v["range"], v["duration"], v["drain"]) for k, v in magic.SPELLS.items()} == book
    assert {k for k in magic.SPELLS if magic.sustained(k)} == {k for k, v in book.items() if v[2] == "S"}
    resisted = {k: v["resist"] for k, v in magic.SPELLS.items() if v["target"] == "resisted"}
    assert resisted == dict.fromkeys(("confusion", "control actions", "mind probe"), ("logic", "willpower"))


def test_powerbolt_drains_force_minus_3(make_game):
    g = make_game(dice=ScriptedDice([6] * 5 + [2] * 9))                # 5 hits; Kaz, the soak: default misses
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["powerbolt"]})
    res = magic.cast(L, g.dice, 1, sable, "Powerbolt", 6, [{"id": "kaz"}])
    assert "Drain  3S · Powerbolt F-3 at Force 6" in res["card"] and L.stat(sable, "stun_damage") == 3


def test_confusion_is_resisted_with_logic_and_willpower(make_game):
    g = make_game(dice=ScriptedDice([6] * 4 + [2] * 10 + [2] * 30))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["confusion"]})
    pool = int(L.stat("kaz", "logic")) + int(L.stat("kaz", "willpower"))
    res = magic.cast(L, g.dice, 1, sable, "Confusion", 4, [{"id": "kaz"}])
    assert f"Kaz: resists Logic + Willpower {pool}d6 -> 0, 4 net hits" in res["card"]      # (SR5 p. 290)
    assert L.stat("kaz", "spell_penalty") == 4


def test_a_cast_is_on_the_record(make_game):
    """Live T164-T175: the drain had to be rebuilt from the formula - the card lived only in Discord. Now a cast is a
    tests row, the event carries the drain, and dropping a spell is an event too."""
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 11 + [2] * 10))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    ctx = TurnContext(g, 9, g.current_scene_id())
    dispatch(ctx, "cast", {"caster_id": sable, "spell": "Armor", "force": 4, "targets": [{"id": "razor"}],
                           "reason": "cover the door"})
    row = g.conn.execute("SELECT * FROM tests WHERE actor_id=?", (sable,)).fetchone()
    spec = json.loads(row["spec"])
    assert spec == {"kind": "cast", "spell": "armor", "force": 4, "targets": ["razor"], "edge": None,
                    "reason": "cover the door"}
    assert row["turn_id"] == 9 and row["net"] == 3 and row["success"] == 1
    ev = next(e for e in L.events(9) if e["kind"] == "cast")
    assert ev["payload"] == {"spell": "armor", "force": 4, "hits": 3, "drain": 2, "drain_type": "stun"}
    dispatch(ctx, "end_spell", {"caster_id": sable, "spell": "Armor"})
    ev = next(e for e in L.events(9) if e["kind"] == "spell_end")
    assert ev["actor"] == sable and ev["payload"] == {"spells": ["armor"], "targets": ["razor"]}


def test_physical_barrier_is_a_wall_with_numbers(make_game):
    """SR5 p. 294: Armor and Structure 1 per hit; at Structure 0 it collapses and the spell ends. Live T164-T174, riders
    crashed into Magic's barrier with nothing on it to break."""
    g = make_game(dice=ScriptedDice([6] * 4 + [2] * 10 + [2] * 10))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["physical barrier"]})
    res = magic.cast(L, g.dice, 1, sable, "Physical Barrier", 5, [])
    assert "(Armor 4 / Structure 4)" in res["card"] and "Drain  4S · Physical Barrier F-1 at Force 5" in res["card"]
    b = magic.barrier(L, sable)
    assert (b["armor"], b["structure"], b["hits"]) == (4, 4, 4)
    assert "Sable's Physical Barrier: Armor 4 / Structure 4" in magic.summary_lines(L, sable)
    hit = magic.damage_barrier(L, 1, sable, 3, "a bike")
    assert hit["structure"] == 1 and not hit["broken"]
    assert "Sable's Physical Barrier: Armor 4 / Structure 1 (of 4)" in magic.summary_lines(L, sable)
    hit = magic.damage_barrier(L, 1, sable, 2, "a van")
    assert hit["broken"] and magic.barrier(L, sable) is None and L.stat(sable, "sustaining") == 0
    assert any(e["kind"] == "spell_end" and e["payload"]["why"] == "a van" for e in L.events(1))
    with pytest.raises(LedgerError, match="isn't holding a Physical Barrier"):
        magic.damage_barrier(L, 1, sable, 1)


def test_each_physical_barrier_is_its_own_wall(make_game):
    """Live review: a second barrier took the first one's Armor and Structure on every hit, regrowing never fixed it,
    one collapse ended both, and the packet showed only the first. Each cast is its own wall (a wall per doorway):
    its own numbers, its own hits, its own collapse, its own packet line (SR5 p. 294)."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["physical barrier"]})
    magic.cast(L, ScriptedDice([6] * 4), 1, sable, "Physical Barrier", 5, [])                 # 4 hits, then misses
    res = magic.cast(L, ScriptedDice([6] * 2), 1, sable, "Physical Barrier", 2, [{"id": "razor"}])
    assert "(Armor 2 / Structure 2) - wall #2 of the 2 Sable holds" in res["card"]
    assert [(b["n"], b["target"], b["armor"], b["structure"]) for b in magic.barriers(L, sable)] == \
        [(1, sable, 4, 4), (2, "razor", 2, 2)]
    lines = magic.summary_lines(L, sable)
    assert "Sable's Physical Barrier #1 (on Sable): Armor 4 / Structure 4" in lines
    assert "Sable's Physical Barrier #2 (on Razor): Armor 2 / Structure 2" in lines
    with pytest.raises(LedgerError, match=r"Which Physical Barrier\? Sable holds 2: #1 on Sable; #2 on Razor"):
        magic.damage_barrier(L, 1, sable, 1)                   # two walls: the engine asks which, never guesses
    hit = magic.damage_barrier(L, 1, sable, 1, "a bike", which="1")
    assert hit["line"] == "  The Physical Barrier #1 (on Sable) takes 1 - Structure 3/4 (Armor 4)"
    assert [(b["armor"], b["structure"]) for b in magic.barriers(L, sable)] == [(4, 3), (2, 2)]   # #2 untouched
    magic.regrow_barriers(L, 1)
    assert [(b["armor"], b["structure"]) for b in magic.barriers(L, sable)] == [(4, 4), (2, 2)]
    hit = magic.damage_barrier(L, 1, sable, 4, "a van", which="#1")
    assert hit["broken"] and L.stat(sable, "sustaining") == 1                            # one wall down, one up
    left = magic.barrier(L, sable)                                                       # (the only one: no asking)
    assert (left["target"], left["armor"], left["structure"]) == ("razor", 2, 2)
    assert "Sable's Physical Barrier: Armor 2 / Structure 2" in magic.summary_lines(L, sable)
    ev = [e for e in L.events(1) if e["kind"] == "spell_end"]
    assert ev[-1]["payload"] == {"spells": ["physical barrier"], "targets": [sable], "why": "a van"}


def test_seeing_through_invisibility_is_one_call(make_game):
    """SR5 p. 290-291: anyone who might see the subject resists a mana illusion with Logic + Willpower, the cast's hits
    the threshold - an attribute-only test (p. 152). Live review: the card asked for that roll and request_test could
    roll only a skill ('Unknown skill willpower'); now the card names the call and the call rolls it."""
    from roleplay.dm.prompts import DM_SYSTEM
    from roleplay.dm.tools import TOOLS
    g = make_game()
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    res = magic.cast(L, ScriptedDice([6] * 3), 1, sable, "Invisibility", 4, [])
    assert "(anyone who might see them: request_test with attributes logic + willpower, threshold 3)" in res["card"]
    n, parts, _ = sr_lite.attribute_pool(L, "kaz", ["logic", "willpower"])
    assert parts[:2] == [("Logic", int(L.stat("kaz", "logic"))), ("Willpower", int(L.stat("kaz", "willpower")))]
    g.dice = ScriptedDice([6] * 3)
    ctx = TurnContext(g, 9, g.current_scene_id())
    card = dispatch(ctx, "request_test", {"actor_id": "kaz", "attributes": ["logic", "willpower"], "threshold": 3,
                                          "reason": "is someone there?"})
    assert card.startswith("[ROLL] Kaz: Logic + Willpower (threshold 3)") and f"= {n}d6" in card and "SUCCESS" in card
    spec = json.loads(g.conn.execute("SELECT spec FROM tests WHERE actor_id='kaz'").fetchone()["spec"])
    assert spec["skill"] is None and spec["attributes"] == ["logic", "willpower"]
    with pytest.raises(LedgerError, match="not both"):
        sr_lite.request_test(L, g.dice, 9, "kaz", "perception", attributes=["logic", "willpower"])
    with pytest.raises(LedgerError, match="Which skill"):
        sr_lite.request_test(L, g.dice, 9, "kaz", None, threshold=2)
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", turn=1)
    with pytest.raises(LedgerError, match="isn't a living mind"):
        sr_lite.request_test(L, g.dice, 9, dog, None, attributes=["logic", "willpower"])
    test = next(t for t in TOOLS if t["name"] == "request_test")["input_schema"]
    assert "skill" not in test["required"] and test["properties"]["attributes"]["items"]["enum"] == \
        list(sr_lite.ATTRIBUTES)
    assert "resists with request_test attributes logic + willpower" in DM_SYSTEM


def test_an_empty_spell_list_knows_them_all(make_game):
    """No list on file means every spell (cast enforces only a list it has; the sheets show all). Live review: '!advance
    spell Powerbolt F-3' on an empty list charged 5 karma and cut the caster down to Powerbolt alone - and chargen let a
    mage toggle every pick off, past the six-pick limit. Forms the same."""
    from roleplay import chargen as C
    from roleplay import charsheet
    g = make_game()
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": []})
    sr_lite.award_karma(L, 1, sable, 5)
    with pytest.raises(LedgerError, match="already knows Powerbolt - with no list on file, they know every spell"):
        sr_lite.advance(L, 1, sable, "spell Powerbolt F-3")
    assert L.stat(sable, "karma") == 5 and magic.known(L, sable) == [] and magic.learnable(L, sable) == []
    assert "Learn a spell" not in charsheet.advancement_card(g, sable, 0)["description"]
    assert "Kaz" in magic.cast(L, ScriptedDice([6] * 3), 1, sable, "Powerbolt", 3, [{"id": "kaz"}])["card"]
    tm = g.create_pc("Static", "technomancer", "static", "ork technomancer", 1)
    L.update_entity(tm, props={**L.get(tm)["props"], "forms": []})
    sr_lite.award_karma(L, 1, tm, 5)
    with pytest.raises(LedgerError, match="they know every complex form"):
        sr_lite.advance(L, 1, tm, "form Puppeteer")
    assert L.get(tm)["props"]["forms"] == [] and "Learn a complex form" not in \
        charsheet.advancement_card(g, tm, 0)["description"]
    mage, techno = C.new_draft("mage"), C.new_draft("technomancer")
    mage["spells"], techno["forms"] = [], []
    assert "pick at least one spell" in C.problems(mage) and "pick at least one complex form" in C.problems(techno)


def test_spirits_drain_when_summoned_and_banished(make_game):
    """Twice the spirit's hits, physical when its Force beats Magic - the card says so (it said 'hits over Magic'
    for a Force 8 spirit that rolled one hit). Banishing drains the same way (SR5 p. 300-301)."""
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 7 + [5] + [2] * 7 + [2] * 10      # summon: 3 vs 1; drain soak
                                    + [6] * 2 + [2] * 8 + [5] + [2] * 7 + [2] * 10))   # banish: 2 vs 1; drain soak
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    ctx = TurnContext(g, 9, g.current_scene_id())
    card = dispatch(ctx, "spirit", {"caster_id": sable, "action": "summon", "spirit_type": "air", "force": 8})
    assert "Drain  2P (Force over Magic) · 2 x 1 spirit hit" in card and L.stat(sable, "physical_damage") == 2
    sid = next(e["id"] for e in L.entities(kind="spirit"))
    card = dispatch(ctx, "spirit", {"caster_id": sable, "action": "banish", "spirit_id": sid})
    assert "Weakened: 1 service(s) left" in card
    assert "Drain  2P (Force over Magic) · 2 x 1 spirit hit" in card and L.stat(sable, "physical_damage") == 4
    assert any(e["kind"] == "banish" for e in L.events(9))


def test_sustained_spells_cost_dice_and_can_be_dropped(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 11 + [2] * 10      # Armor on Razor: 3 hits
                                    + [6] * 4 + [2] * 8 + [2] * 4 + [2] * 10))   # Confusion on Kaz: 4 vs 0
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    magic.cast(L, g.dice, 1, sable, "Armor", 4, [{"id": "razor"}])
    assert sr_lite.best_armor(L, "razor") == (7, "Razor's Armored jacket + Armor spell 3")
    n, parts = sr_lite.build_pool(L, sable, "sorcery")
    assert ("Sustaining 1 spell", -2) in parts and n == 12
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["confusion"]})
    magic.cast(L, g.dice, 1, sable, "Confusion", 4, [{"id": "kaz"}])
    assert ("Confused", -4) in sr_lite.build_pool(L, "kaz", "perception")[1]
    assert ("Sustaining 2 spells", -4) in sr_lite.build_pool(L, sable, "sorcery")[1]   # (+ -1 from drain wounds)
    magic.end_spell(L, sable)
    assert sr_lite.best_armor(L, "razor")[0] == 4 and L.stat("kaz", "spell_penalty") == 0
    assert not any(label.startswith("Sustaining") for label, _ in sr_lite.build_pool(L, sable, "sorcery")[1])


def test_a_spirit_answers_serves_and_leaves(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 7 + [5] + [2] * 3 + [2] * 10))   # 3 vs 1: two services
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    ctx = TurnContext(g, 9, g.current_scene_id())
    card = dispatch(ctx, "spirit", {"caster_id": sable, "action": "summon", "spirit_type": "fire", "force": 4})
    sid = next(e["id"] for e in L.entities(kind="spirit"))
    assert "owes 2 service(s)" in card and "Drain  2S" in card
    assert sid in L.roster(g.current_scene_id()) and L.stat(sid, "agility") == 6 and L.stat(sid, "armor") == 4
    assert any("flame lash" in i["name"] for i in L.holdings(sid))
    assert "SPIRIT (fire, Force 4; Sable's, 2 service(s) left)" in sr_lite.sheet(L, sid)
    assert dispatch(ctx, "spirit", {"caster_id": sable, "action": "order", "spirit_id": sid,
                                    "task": "burn the van"}).endswith("1 service(s) left")
    assert "goes home" in dispatch(ctx, "spirit", {"caster_id": sable, "action": "order", "spirit_id": sid})
    assert L.get(sid)["status"] == "departed" and sid not in L.roster(g.current_scene_id())


def test_the_astral_layer(make_game):
    g = make_game(dice=ScriptedDice([6] * 8 + [2] * 20))
    setup_demo(g)
    L = g.ledger
    sable = _mage(g)
    with pytest.raises(LedgerError, match="isn't Awakened"):
        magic.astral(L, 1, "razor", "perceive")
    magic.astral(L, 1, sable, "perceive")
    assert ("Perceiving astrally", -2) in sr_lite.build_pool(L, sable, "firearms")[1]
    assert ("Perceiving astrally", -2) not in sr_lite.build_pool(L, sable, "perception")[1]
    assert "projects - the body is limp" in magic.astral(L, 1, sable, "project")
    shot = sr_lite.attack(L, g.dice, 1, "razor", sable, next(i["id"] for i in L.holdings("razor") if "dv" in i["props"]))
    assert "Projecting astrally, body limp 0" in shot["card"]
