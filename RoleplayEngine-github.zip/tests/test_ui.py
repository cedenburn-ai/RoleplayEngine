"""The Discord forms and buttons (ui.py), driven with fake interactions: same draft, same rules, private replies."""
import asyncio
from types import SimpleNamespace

from roleplay import chargen as C
from roleplay.discord_bot import ui
from roleplay.discord_bot.chargen_flow import load as load_draft
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_blank

from .conftest import FakeLLM
from .test_discord import FakeChannel


class FakeResponse:
    def __init__(self):
        self.calls, self.done = [], False

    def is_done(self):
        return self.done

    async def _log(self, kind, *a, **kw):
        self.calls.append((kind, a, kw))
        self.done = True

    async def send_message(self, *a, **kw):
        await self._log("send", *a, **kw)

    async def edit_message(self, **kw):
        await self._log("edit", **kw)

    async def send_modal(self, modal):
        await self._log("modal", modal)

    async def defer(self, **kw):
        await self._log("defer", **kw)


class FakeFollowup:
    def __init__(self):
        self.sent = []

    async def send(self, *a, **kw):
        self.sent.append((a, kw))
        return SimpleNamespace(id=1, channel=SimpleNamespace(id=2), attachments=[])


def interaction(uid="7", name="Jo", channel_id=99):
    i = SimpleNamespace(user=SimpleNamespace(id=int(uid), display_name=name), response=FakeResponse(),
                        followup=FakeFollowup(), channel_id=channel_id, channel=SimpleNamespace(id=channel_id))

    async def edit_original_response(**kw):
        i.response.calls.append(("edit_original", (), kw))
    i.edit_original_response = edit_original_response
    return i


def _game(make_game):
    g = make_game(FakeLLM())
    setup_blank(g, "Downtown Seattle", "rain")
    return g


def test_the_builder_forms_drive_the_same_draft(make_game):
    g = _game(make_game)

    async def go():
        t = CampaignTable(g, FakeChannel(), owner_id="1")
        bot = SimpleNamespace(tables={99: t})
        form = ui.BasicsForm(bot, t, C.new_draft(), first=True)
        form.name._value, form.pronouns._value, form.concept._value = "Glitch", "she/her", ""
        form.meta._values, form.role._values = ["elf"], ["decker"]
        i = interaction()
        await form.on_submit(i)
        kind, _, kw = i.response.calls[-1]
        assert kind == "send" and kw["ephemeral"] and isinstance(kw["view"], ui.ReviewView)
        d = load_draft(g, "7")
        assert (d["name"], d["pronouns"], d["metatype"], d["role"]) == ("Glitch", "she/her", "elf", "decker")
        attrs = ui.SpreadForm(bot, t, d, "attrs")
        attrs.field._value = "BOD 9 AGI 4"                               # too much: rejected as a whole
        i = interaction()
        await attrs.on_submit(i)
        assert "BOD has to be 1-6" in i.response.calls[-1][2]["embed"].description and d["attrs"]["body"] != 9
        skills = ui.SpreadForm(bot, t, d, "skills")
        skills.field._value = "Hacking 6, Electronics 5, Stealth 4"
        await skills.on_submit(interaction())
        assert d["skills"] == {"hacking": 6, "electronics": 5, "stealth": 4}
        gear = ui.GearView(bot, t, d, "Weapons")
        gear.sel._values = ["heavy-pistol", "katana"]
        i = interaction()
        await gear.on_items(i)
        assert {"heavy-pistol", "katana"} <= set(d["gear"]) and isinstance(i.response.calls[-1][2]["view"], ui.GearView)
        review = ui.ReviewView(bot, t, d)
        assert review.magic not in review.children                       # (no spells button for a decker)
        d["look"] = "Silver-haired elf in a patched techie jacket."
        i = interaction()
        await review.done.callback(i)
        assert g.character_for("glitch")["name"] == "Glitch"               # built, seated, and on the ledger
        assert i.response.calls[-1][0] == "edit_original" and i.followup.sent      # sheet sent privately
        await t.close()
    asyncio.run(go())


def test_only_the_holder_can_press_the_buttons():
    chosen = []

    async def on_choice(interaction, yes):
        chosen.append((interaction.user.id, yes))

    async def go():
        v = ui.ChoiceView("7", on_choice)
        stranger = interaction("8")
        await v.yes.callback(stranger)
        assert "for <@7>" in stranger.response.calls[-1][1][0] and not chosen
        holder = interaction("7")
        await v.no.callback(holder)
        assert chosen == [(7, False)] and holder.response.calls[-1][0] == "edit"
    asyncio.run(go())


def test_the_forms_answer_inside_discords_three_seconds_even_mid_turn(make_game):
    """A form that saved before answering waited out the GM's turn on the game thread - past Discord's 3 seconds, so
    "How they look" said "Something went wrong". Every builder step answers first; nothing waits on the game thread."""
    import threading
    import time
    g = _game(make_game)

    async def go():
        t = CampaignTable(g, FakeChannel(), owner_id="1")

        async def table_for(channel):
            return t
        bot = SimpleNamespace(tables={99: t}, table_for=table_for)
        gate = threading.Event()
        busy = t.loop.run_in_executor(t.pool, gate.wait, 30)          # the GM, mid-turn, on the game thread
        t0 = time.time()

        form = ui.BasicsForm(bot, t, C.new_draft(), first=True)
        form.name._value, form.pronouns._value, form.concept._value = "Glitch", "she/her", ""
        form.meta._values, form.role._values = ["elf"], ["mage"]
        i = interaction()
        await form.on_submit(i)
        d = i.response.calls[-1][2]["view"].d
        look = ui.LookForm(bot, t, d)
        look.field._value = "Average height, forgettable face, grey jacket, a thin scar along one knuckle."
        await look.on_submit(i := interaction())
        assert i.response.calls[0][0] == "edit"
        attrs = ui.SpreadForm(bot, t, d, "attrs")
        attrs.field._value = C.attrs_text(d)
        await attrs.on_submit(interaction())
        gear = ui.GearView(bot, t, d)
        gear.sel._values = [k for k in ui.GearView._items(gear, gear.cat)][:1]
        await gear.on_items(interaction())
        spells = ui.MagicView(bot, t, d)
        spells.sel._values = list(C.magic.SPELLS)[:2] if hasattr(C, "magic") else []
        await spells.on_pick(interaction())
        await ui.open_builder(bot, i := interaction())
        assert i.response.calls[0][0] == "send"                         # picked up where they left off
        assert time.time() - t0 < 3                                       # all of it, while the GM worked
        assert load_draft(g, "7")["look"].startswith("Average height")   # and it was saved
        gate.set()
        await busy
        await t.close()
    asyncio.run(go())


def test_the_spell_and_form_pickers_show_the_codes():
    """The picker labels carry the drain (or fading) code; the value stays the key, so picks still save."""
    async def go():
        view = ui.MagicView(None, None, C.new_draft("mage", "elf"))
        labels = {o.value: o.label for o in view.sel.options}
        assert labels["stunbolt"] == "Stunbolt F-3" and labels["mind probe"] == "Mind Probe F"
        assert "• Manabolt F-3" in view.embed().description and "F-3 drains the Force minus 3" in view.embed().description
        view = ui.MagicView(None, None, C.new_draft("technomancer", "elf"))
        assert {o.value: o.label for o in view.sel.options}["cleaner"] == "Cleaner L+0"
    asyncio.run(go())
