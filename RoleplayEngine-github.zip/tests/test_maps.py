"""!map: the metroplex with what the party knows, drawn by the engine (labels never collide)."""
import asyncio

from PIL import Image

from roleplay import maps
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


def test_projection_and_schematic():
    P = maps.Projection(maps.METRO, maps.SIZE)
    x, y = P(47.6062, -122.3321)                             # downtown Seattle
    assert 470 < x < 510 and 620 < y < 670
    img = maps.schematic()
    assert img.size == maps.SIZE
    assert img.getpixel((int(P(47.62, -122.26)[0]), int(P(47.62, -122.26)[1]))) == maps.WATER   # Lake Washington
    assert img.getpixel((int(P(47.66, -122.13)[0]), int(P(47.66, -122.13)[1]))) != maps.WATER   # the Barrens


def test_labels_never_overlap():
    img = Image.new("RGB", (400, 300))
    from PIL import ImageDraw
    labels = maps.Labels(ImageDraw.Draw(img), img.size)
    f = maps._font(14)
    assert labels.place(200, 150, "The Lucky Shot", f, (255, 255, 255))
    for _ in range(6):                                       # the same spot again: tries around, then gives up
        labels.place(200, 150, "The Lucky Shot", f, (255, 255, 255))
    b = labels.boxes
    assert all(i == j or a[2] < c[0] or a[0] > c[2] or a[3] < c[1] or a[1] > c[3]
               for i, a in enumerate(b) for j, c in enumerate(b))
    assert labels.place(395, 20, "Salish-Shidhe Border", f, (255, 255, 255))   # pulled back inside the frame
    assert labels.boxes[-1][2] <= 400


def test_known_places_and_render(make_game, tmp_path):
    g = make_game()
    setup_demo(g)
    hidden, _ = g.introduce("location", "Renraku safehouse", "a quiet condo", turn=1, where={"district": "Bellevue"})
    assert [p["id"] for p in maps.known_places(g)] == ["the-lucky-shot"]          # never been there, never seen it
    assert {p["id"] for p in maps.known_places(g, everything=True)} == {"the-lucky-shot", hidden}
    for view in ("metro", "here"):
        out = maps.render(g, view, out=tmp_path / f"{view}.png")
        assert Image.open(out).size == (maps.SIZE if view == "metro" else (1200, 900))


def test_map_command(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!map", False, react)
        assert ch.sent[-1]["title"] == "🗺️ Seattle Metroplex" and ch.sent[-1]["image"].endswith(".png")
        await t.handle("2", "Bob", "!map gm", False, react)
        assert "campaign owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!map gm", True, react)
        assert ch.dms[-1][0] == "1" and "GM eyes only" in ch.dms[-1][1][0]["title"]
        await t.close()
    asyncio.run(go())
