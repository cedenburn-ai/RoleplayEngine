"""Called rolls, read whole and held by the engine (flags #38, #48-#52; the owner, 2026-10-27, decisions 3 and 4).

Live T155: a player called a teamwork Negotiation test with Magic leading (Charisma 4 + Negotiation 3) and Brask
helping, Edge on the misses if it came up short - and the GM narrated past it, then rolled Brask's 2 dice instead,
five `!undo`s running. At T128 a teamwork Negotiation call with Magic in the lead went out with no helper rolled. Now
the call's leader, skill and helpers are read from the post; a roll that gives the call away is turned away before the
dice (the third time the engine rolls it right); narrating past it is sent back twice, then the engine rolls it; the
helpers and the bonus are on the record; and the teamwork cap is the book's (the leader's skill), not R8's +4."""
import json

import pytest

from roleplay import flags
from roleplay.dm import calls, canon, prompts, research, tools
from roleplay.dm.turn import _user_message, edge_asks, roll_asks
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import machines, matrix, sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool

# Posts of the live ones' shapes - invented, keeping what the parsers read (the names said twice, the typos, a helping
# that's the offer, the teamwork and Edge wording). T155 stands for the take that survived the reruns; flag #50 gave
# the declared one, ORIGINAL.
T155 = ("Magic, the character Alice plays, and only magic is making the roll to persuade her. He'll use edge to "
        "reroll misses if needed\n\nI walk her through what we found at the clinic anf what it means for the kids, "
        "andI make the offer. She keeps her name clean, the families get looked after quietly, and we line up "
        "backers who can actually pay. She and Brask too, if she still wants him once his name is all over "
        "the feeds. I'm helping her get the project funded a year early, and all we ask is her signature on the "
        "transfer and her silence about the rest.\n\nBrask has been told to keep quiet until magic has her "
        "persuaded.")
ORIGINAL = "Teamwork Negotiation test, Magic leading, Brask helping. He'll use edge to reroll misses if needed."
T128 = ("She's jumpy as hell, so nearly anything we try wpuld probably spook her. If it goes that way we Ditch the "
        "plan, walk straight up and press the printout flat to her window, the circled names and all. \"We know "
        "what happened, we can help, or we go to the authorities. Your choice\" (Call it a teamwork negotiations "
        "check, Magic leading the roll. If she wants out she'll talk. If not she bolts and we let her go, then we "
        "follow the car or hack it. Depends on the next round anyway. Filament probably just mutters a sad \"Come "
        "on, lady. They were kids\", Lou probably throws up his hands at her for wanting to stay in this.)")
COMMIT = {"summary": "Magic pitched Vandermeer.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "magic", "role": "actor"}]}


def _t155(g):
    """The T155 room: Magic (Charisma 4 + Negotiation 3 = 7), Dr. Brask (no Negotiation: Charisma 3 - 1 = 2 dice),
    Dr. Vandermeer on the line."""
    setup_demo(g)
    L = g.ledger
    magic = g.create_pc("Magic", "street_samurai", "magic")
    for k, v in (("charisma", 4), ("negotiation", 3), ("willpower", 6), ("edge", 3), ("edge_points", 3)):
        L.set_stat(magic, k, v)
    brask, _ = g.introduce("npc", "Dr. A. Brask", "virologist", "expert", aliases=["Brask", "Dr. Brask"], turn=1)
    ach, _ = g.introduce("npc", "Dr. Marit Vandermeer", "virologist", "expert", aliases=["Vandermeer"], turn=1)
    for k, v in (("charisma", 3), ("negotiation", 0)):
        L.set_stat(brask, k, v)
    for k, v in (("charisma", 3), ("negotiation", 3), ("willpower", 4)):
        L.set_stat(ach, k, v)
    g.enter_scene([magic, brask, ach], 1)
    return magic, brask, ach


def _calls(g, handle, post):
    inputs = [(handle, post)]
    asked, edge = roll_asks(g, inputs), edge_asks(g, inputs)
    for pc, (name, _, quote) in edge.items():
        asked.setdefault(pc, (name, quote))
    return calls.read(g, inputs, g.current_scene_id(), asked, edge), edge


def _ctx(g, handle, post, turn=5):
    ctx = tools.TurnContext(g, turn, g.current_scene_id())
    ctx.calls, ctx.edge_asks = _calls(g, handle, post)
    return ctx


def _tests(g, turn):
    return g.conn.execute("SELECT * FROM tests WHERE turn_id=? ORDER BY id", (turn,)).fetchall()


class Recording(FakeLLM):
    """A FakeLLM that answers the called-roll read with `read` (None: it fails) and counts the reads."""

    def __init__(self, dm_script=None, read=None):
        super().__init__(dm_script, COMMIT)
        self.read, self.reads = read, []

    def structured(self, model, system, user, schema, **kw):
        if user.startswith("CALLED ROLL READ"):
            self.reads.append(user)
            if self.read is None:
                raise RuntimeError("no read")
            return self.read
        return super().structured(model, system, user, schema, **kw)


# ── reading the call ────────────────────────────────────────────────────
def test_the_t155_post_is_magics_call(make_game):
    """The surviving T155 post: Magic leads (he's named twice over), nobody helps - Brask is told to keep out of it, and
    "I'm helping her get the project funded", paragraphs on, is the offer, not a helper - the task is a social one, and
    the Edge is insurance. The declared take (flag #50) has Brask as the helper and Negotiation named."""
    g = make_game(Recording())
    magic, brask, _ = _t155(g)
    (call,), edge = _calls(g, "magic", T155)
    assert (call.leader, call.helpers, call.among, call.skill, call.task) == (magic, [], [], None, "negotiation")
    assert call.owed and not call.teamwork and edge[magic][1] == "if_short"
    assert "making the roll to persuade her" in call.words
    (call,), edge = _calls(g, "magic", ORIGINAL)
    assert (call.leader, call.helpers, call.skill, call.teamwork) == (magic, [brask], "negotiation", True)
    assert edge[magic][1] == "if_short" and not g.llm.reads                 # (the words settled both: no model read)


def test_the_calls_words_keep_their_sentence_ends(make_game):
    """Review 2026-10-28: the quote every send-back and flag gives joined the call's sentences bare - "...Brask helping
    He uses edge to reroll..." - as if the player had written one."""
    g = make_game(Recording())
    _t155(g)
    (call,), _ = _calls(g, "magic", ORIGINAL)
    assert call.words == ORIGINAL
    (call,), _ = _calls(g, "magic", "Magic leads the pitch! Brask helps; teamwork Negotiation test")
    assert call.words == "Magic leads the pitch! Brask helps; teamwork Negotiation test"


def test_a_calls_quote_keeps_its_line_breaks_and_one_ellipsis(make_game):
    """Review of the fix above: a Discord post puts each part on its own line, and the line break joined bare again
    ("...the pitch Brask helps..."); and a call ending on its full stop was quoted "...test....". A sentence a line
    break ends keeps a ';', and the quote drops the call's own end."""
    g = make_game(Recording())
    _t155(g)
    (call,), _ = _calls(g, "magic", "Magic leads the pitch\nBrask helps\nteamwork Negotiation test")
    assert call.words == "Magic leads the pitch; Brask helps; teamwork Negotiation test"
    (call,), _ = _calls(g, "magic", ORIGINAL)
    assert call.words == ORIGINAL and call.quoted() == "..." + ORIGINAL[:-1] + "..."
    assert call.quoted(9) == "...Teamwork..."


@pytest.mark.parametrize("post, lead, helpers, among, skill", [
    ("Razor leads the pitch to the fixer; Kaz assists by adding dice to his pool.", "razor", ["kaz"], [], None),
    ("Razor is the leader on this negotiation, Kaz is assisting.", "razor", ["kaz"], [], None),
    ("Teamwork: Razor leads the con, Kaz assists", "razor", ["kaz"], [], None),
    ("Razor makes a Leadership test with Kaz assisting", "razor", ["kaz"], [], None),
    ("Razor pitches the deal (Negotiation + Charisma, Kaz helps)", None, ["kaz"], [], "negotiation"),
    ("Make an Etiquette test, Kaz helping.", None, ["kaz"], [], "etiquette"),
    ("Razor has the highest pool so he leads, Kaz helps.", "razor", ["kaz"], [], None),
    ("Razor and Kaz work the fixer together - teamwork Negotiation", None, [], ["razor", "kaz"], "negotiation"),
    ("Ghost helps Brask with the diagnosis, teamwork roll - she leads, she is the doctor", "dr-a-brask", ["ghost"], [],
     None),
])
def test_leads_and_helps_read_as_the_player_put_it(make_game, post, lead, helpers, among, skill):
    """Review of flags #48/#52: 'leads', 'helps', 'assists', 'Negotiation + Charisma' and 'Make an Etiquette test'
    called nothing; "Ghost helps Brask... she leads" made Ghost the actor. (Untrained Leadership isn't a skill here.)"""
    g = make_game(Recording())
    _t155(g)
    handle = "ghost" if post.startswith("Ghost") else "razor"
    (call,), _ = _calls(g, handle, post)
    assert (call.leader, call.helpers, call.among, call.skill) == (lead, helpers, among, skill), post
    assert call.owed


# What the live Haiku read returned for T128, three runs of three (review of flag #38): nobody helping.
T128_LIVE_READ = {"called": True, "leader": "magic", "helpers": [], "skill": "negotiation", "named_skill": True,
                  "against": "dr-a-brask"}


def _crew(g):
    """Filament and Quiet Lou beside Magic, both played by the GM as at T128 (their players away; Lou a companion)."""
    out = []
    for name in ("Filament", "Quiet Lou"):
        eid = g.create_pc(name, "decker" if name == "Filament" else "street_samurai", name.lower().replace(" ", "-"))
        g.set_control(eid, "gm")
        g.enter_scene([eid], 1)
        out.append(eid)
    return out


def test_the_t128_teamwork_call(make_game):
    """Live T128 (flag #38): teamwork, Negotiation, Magic leading - and nobody named to help, so the words leave the
    helpers open: the cheap read is asked. The live read named nobody either (helpers [] three times of three), so
    the engine picks the helpers itself: the crew the post has pitching in - Filament and Lou, speaking up and
    gesturing beside him. Their spoken lines ("we can help") are nobody's part; Brask, whom it's aimed at, isn't one."""
    g = make_game(Recording(read=T128_LIVE_READ))
    magic, brask, _ = _t155(g)
    el, sam = _crew(g)
    (call,), _ = _calls(g, "magic", T128)
    assert (call.leader, call.skill, call.teamwork, call.how, call.against) == (magic, "negotiation", True, "model",
                                                                                brask)
    assert call.helpers == [el, sam] and call.picked
    assert len(g.llm.reads) == 1 and "THE POST:\nShe's jumpy as hell" in g.llm.reads[0]
    g2 = make_game(Recording())                                       # no read: the words' reading stands
    _t155(g2)
    _crew(g2)
    (call,), _ = _calls(g2, "magic", T128)
    assert (call.leader, call.skill, call.teamwork, call.helpers) == ("magic", "negotiation", True, [el, sam])
    g3 = make_game(Recording())                                       # nobody else on file: nobody to pick
    _t155(g3)
    (call,), _ = _calls(g3, "magic", T128)
    assert call.helpers == [] and not call.picked


def test_story_words_call_nothing(make_game):
    """No false positives: rolling eyes, a van rolling to a stop, rolling out, leading someone down the stairs,
    helping someone into a van, a pitch with no roll words. Nothing is read by the model either."""
    g = make_game(Recording())
    _t155(g)
    for post in ("I walk to the bar and order a drink.", "He rolls his eyes at Kaz and the van rolls to a stop.",
                 "We'll roll out at dawn.", "Razor leads Kaz down the stairs. Kaz helps her into the van.",
                 "Razor makes the pitch to Kaz.", "Razor rolls up the window and drives.",
                 "Kaz helps him to his feet.", "Razor pays Kaz with a roll of nuyen.", "((I'll roll later))"):
        assert _calls(g, "razor", post)[0] == [], post
        assert not roll_asks(g, [("razor", post)]), post
    for post in ("Kaz takes the check and pays.", "Kaz hits the guard and I help.",
                 "Razor heads out with survival gear."):
        assert _calls(g, "razor", post)[0] == [], post
    # Review of P3: everyday nouns, Edge's prose words, quoted speech and a roll declined became owed calls - two
    # send-backs each, and an engine roll whose card quoted "No roll needed". Live T102's shape (R16 backs it).
    for post in ("I look whether I can clear the debt from this system myself. No roll or system check. He'd know "
                 "this already",
                 "No roll needed - Razor searches the files Kaz's login opens.", "Razor pushes it open and steps inside.",
                 "Razor walks to the edge to look down at the street.", "Razor asks for the check and leaves a tip.",
                 "Razor calls for the check.", "Razor wants a blood test on the kid before we move him.",
                 "We need a paternity test, Kaz says the kid isn't his.", "Razor does the sound check on the van.",
                 "Razor runs his tests against the samples Kaz brought.", "I need the test results from the lab.",
                 "Razor makes the background check calls to his contacts.",
                 "We do this without a roll, he's my friend.", "Razor doesn't need to roll for this, Kaz owes him.",
                 'Razor grins. "Teamwork makes the dream work."', 'Razor shrugs. "Fine, we\'ll roll with it."',
                 "Razor shrugs. Fine, we'll roll with it.", "A second chance to surrender, Kaz says."):
        assert _calls(g, "razor", post)[0] == [], post
        assert not roll_asks(g, [("razor", post)]), post
    assert not g.llm.reads
    for post in ("I roll Perception to watch the street. Kaz helps her into the van.",   # (a hand, not a helper)
                 "I roll Perception to scan the room. Kaz helps the bartender with the kegs.",
                 "I roll Perception to scan the room. Kaz helps himself to a drink.",
                 "Razor and Kaz head to the bar. Razor rolls Perception.",               # (walking in together)
                 "Razor and Kaz head in and Razor rolls Perception."):
        (call,), _ = _calls(g, "razor", post)
        assert (call.leader, call.skill, call.helpers, call.among) == ("razor", "perception", [], []), post
    (call,), _ = _calls(g, "razor", "Razor rolls Negotiation. Kaz helps.")              # (a bare help beside it is)
    assert call.helpers == ["kaz"]


def test_the_live_posts_that_called_nothing_still_call_nothing(make_game):
    """Replayed over the live world's 188 turns (on a copy), in these shapes: the group checking each other out (T118)
    and "She helped us get this rolling" (T140) asked for no roll; "Climb into admin" (T95) is a decker's, not
    Athletics; and "She should probably roll a check" (T127) was the doctor's roll - nobody's named, so without a read
    it's no call, never the poster's on a guess; the read names her."""
    g = make_game(Recording())
    magic, brask, _ = _t155(g)
    for post in ("The group checks each other out - do we even pass at Brask's lunch place",
                 "She helped us get this rolling for the families"):
        assert _calls(g, "magic", post)[0] == [] and not roll_asks(g, [("magic", post)]), post
    (call,), _ = _calls(g, "magic", "Climb into admin. He uses edge, and both other runners use edge too, to help "
                                    "as a group check (they're on whatever counts as phones in the Sixth World)")
    assert call.task is None and call.plain
    t127 = ("We wait for the doctor to park nose to nose with us. She should probably roll a check, whether she "
            "climbs out or gets spooked")
    assert _calls(g, "magic", t127)[0] == [] and len(g.llm.reads) == 1
    g2 = make_game(Recording(read={"called": True, "leader": "dr-a-brask", "helpers": [], "skill": "perception",
                                   "named_skill": False, "against": ""}))
    _t155(g2)
    (call,), _ = _calls(g2, "magic", t127)
    assert (call.leader, call.task, call.how) == ("dr-a-brask", "perception", "model")


def test_the_cheap_read_settles_what_the_words_leave_open(make_game):
    """Role words and a task but no roll words ("Razor convinces the fixer with Kaz backing him up") - the read
    decides. It says it's a call: Kaz helps. It says it isn't, or there's no read: no call."""
    read = {"called": True, "leader": "razor", "helpers": ["kaz"], "skill": "negotiation", "named_skill": False,
            "against": ""}
    post = "Razor convinces the fixer with Kaz backing him up."
    g = make_game(Recording(read=read))
    setup_demo(g)
    (call,), _ = _calls(g, "razor", post)
    assert (call.owed, call.leader, call.helpers, call.task, call.how) == (True, "razor", ["kaz"], "negotiation",
                                                                           "model")
    g2 = make_game(Recording(read=dict(read, called=False)))
    setup_demo(g2)
    assert _calls(g2, "razor", post)[0] == [] and len(g2.llm.reads) == 1
    g3 = make_game(Recording())
    setup_demo(g3)
    assert _calls(g3, "razor", post)[0] == []


# ── before the dice ─────────────────────────────────────────────────────
def test_a_roll_that_gives_the_call_away_is_turned_away(make_game, tmp_path):
    """The T155 take: Brask rolling with Magic as her helper, Vandermeer rolling against Magic, Magic's Con, Magic
    without Brask - each turned away before the dice, saying exactly what to roll; no tool error, no flag, nothing
    rolled. The roll they called goes through, Brask helping, the Edge riding it."""
    g = make_game(dice=ScriptedDice([2] * 400))
    magic, brask, ach = _t155(g)
    pitch = {"reason": "the pitch", "opposed_by": {"entity_id": ach, "skill": "negotiation"}}
    wrong = [dict(pitch, actor_id=brask, skill="negotiation", helpers=[{"id": magic}]),
             dict(pitch, actor_id=magic, skill="con", helpers=[{"id": brask}], edge="if_short")]
    ctx = _ctx(g, "magic", ORIGINAL)
    out = tools.run_tool(ctx, tool("request_test", **wrong[0]))
    assert out["is_error"] and "Dr. A. Brask rolling and Magic helping" in out["content"]
    assert "actor_id='magic'" in out["content"] and "helpers=[{'id': 'dr-a-brask'}]" in out["content"]
    assert "skill='negotiation' (they named it)" in out["content"] and "edge='if_short'" in out["content"]
    out = tools.run_tool(ctx, tool("request_test", **wrong[1]))
    assert out["is_error"] and "they named Negotiation, and this rolls Con" in out["content"]
    assert "Next time the engine rolls it that way itself" in out["content"]
    assert not _tests(g, 5) and not g.ledger.events(5) and not ctx.cards and ctx.tool_errors == 0
    assert not flags.listing(tmp_path)
    out = tools.run_tool(ctx, tool("request_test", **dict(pitch, actor_id=magic, skill="negotiation",
                                                          helpers=[{"id": brask}], edge="if_short")))
    assert not out.get("is_error") and ctx.calls[0].met
    assert out["content"].startswith("[ROLL] Magic: Negotiation") and "Team   Dr. A. Brask Negotiation 2d6" in out["content"]
    for args, said in ((dict(pitch, actor_id=ach, skill="negotiation", opposed_by={"entity_id": magic}),
                        "Dr. Marit Vandermeer rolling against Magic - Magic rolls it"),
                       (dict(pitch, actor_id=magic, skill="negotiation", edge="if_short"),
                        "they named Dr. A. Brask helping, and this roll leaves Dr. A. Brask out")):
        ctx = _ctx(g, "magic", ORIGINAL, turn=6)
        out = tools.run_tool(ctx, tool("request_test", **args))
        assert out["is_error"] and said in out["content"], args
    ctx = _ctx(g, "magic", T155, turn=7)                    # (the surviving take: Brask pitching at Vandermeer)
    out = tools.run_tool(ctx, tool("request_test", **dict(pitch, actor_id=brask, skill="negotiation")))
    assert out["is_error"] and "Dr. A. Brask is making the Negotiation roll their player called for Magic" in out["content"]
    out = tools.run_tool(ctx, tool("request_test", actor_id=brask, skill="perception", threshold=2, reason="looks"))
    assert not out.get("is_error")                          # (her own look round isn't the call)


def test_the_other_side_rolling_is_only_a_give_away_in_the_calls_skill(make_game):
    """Kaz's Perception against Razor's called Con is the call run from the wrong side (Razor's Edge can't ride it);
    Joey spotting Razor while Razor's player only said "pushes the limit on the shot" is Joey's own roll."""
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    ctx = _ctx(g, "razor", "Razor bluffs Kaz about the chip. I roll Con.")
    out = tools.run_tool(ctx, tool("request_test", actor_id="kaz", skill="perception", reason="sees through it",
                                   opposed_by={"entity_id": "razor", "skill": "con"}))
    assert out["is_error"] and "this has Kaz rolling against Razor - Razor rolls it" in out["content"]
    ctx = _ctx(g, "razor", "Razor pushes the limit on the shot.")
    out = tools.run_tool(ctx, tool("request_test", actor_id="joey-two-knives", skill="perception", reason="spots him",
                                   opposed_by={"entity_id": "razor", "skill": "stealth"}))
    assert not out.get("is_error") and not ctx.calls[0].met


def test_the_third_give_away_is_the_engines_roll(make_game):
    """Turned away twice, the GM hands Brask the roll a third time: the engine rolls the call itself - Magic leading,
    Brask helping, his Edge, the GM's opposition and modifiers kept - and Brask's roll never reaches the record."""
    g = make_game(dice=ScriptedDice([2] * 400))
    magic, brask, ach = _t155(g)
    ctx = _ctx(g, "magic", ORIGINAL)
    gm = {"actor_id": brask, "skill": "negotiation", "helpers": [{"id": magic}], "reason": "Brask explains the assay",
          "opposed_by": {"entity_id": ach, "skill": "negotiation"}, "modifiers": [{"label": "cold call", "value": -1}]}
    for _ in range(calls.HARD_REFUSALS):
        assert tools.run_tool(ctx, tool("request_test", **gm))["is_error"]
    out = tools.run_tool(ctx, tool("request_test", **gm))
    assert not out.get("is_error") and out["content"].startswith("(Engine: ")
    card = ctx.cards[-1]
    assert card.startswith("[ROLL] Magic: Negotiation + Charisma vs Dr. Marit Vandermeer (opposed)")
    assert "  Called Magic's player called it" in card and "Team   Dr. A. Brask Negotiation 2d6" in card
    assert "- cold call 1 = 6d6" in card and "second chance" in card       # (all 2s: short, so the insurance rode)
    rows = _tests(g, 5)
    assert [r["actor_id"] for r in rows] == [magic]
    spec = json.loads(rows[0]["spec"])
    assert spec["by"] == "engine" and spec["helpers"][0]["id"] == brask and spec["opposed"]["entity_id"] == ach
    assert ctx.calls[0].met and ctx.calls[0].by_engine and magic in ctx.rolled
    assert int(g.ledger.stat(magic, "edge_points")) == 2


def test_the_highest_pool_leads_a_group_call(make_game):
    """A group named with no leader: the highest pool for the skill rolled leads, the rest help (a player, flag #52:
    the best pool should lead, everyone else helping). Kaz's Negotiation 8 beats Razor's 1."""
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    ctx = _ctx(g, "razor", "Razor and Kaz work the fixer together - teamwork Negotiation")
    out = tools.run_tool(ctx, tool("request_test", actor_id="razor", skill="negotiation", threshold=2,
                                   helpers=[{"id": "kaz"}], reason="the pitch"))
    assert out["is_error"] and "Razor rolling and Kaz helping" in out["content"]
    assert "the highest pool for Negotiation of Razor and Kaz" in out["content"] and "actor_id='kaz'" in out["content"]
    out = tools.run_tool(ctx, tool("request_test", actor_id="kaz", skill="negotiation", threshold=2,
                                   helpers=[{"id": "razor"}], reason="the pitch"))
    assert not out.get("is_error") and ctx.calls[0].met


def test_a_helper_who_doesnt_say_whom_leaves_the_leader_to_the_gm(make_game):
    """Ghost's player: "With my help, Razor picks the lock" - Ghost helps; who leads they didn't quite say. The read
    settles it (Razor); without one the GM picks the roller, and only Ghost's help is held."""
    post = "With my help, Razor picks the lock - teamwork roll."
    lock = {"skill": "engineering", "threshold": 2, "reason": "the lock"}
    g = make_game(Recording(), dice=ScriptedDice([2] * 200))
    setup_demo(g)
    ctx = _ctx(g, "ghost", post)
    (call,) = ctx.calls
    assert (call.leader, call.helpers, call.task) == (None, ["ghost"], "engineering") and len(g.llm.reads) == 1
    out = tools.run_tool(ctx, tool("request_test", actor_id="razor", **lock))
    assert out["is_error"] and "Ghost is helping, as their player said" in out["content"]
    assert not tools.run_tool(ctx, tool("request_test", actor_id="razor", helpers=[{"id": "ghost"}], **lock)).get(
        "is_error") and call.met
    g2 = make_game(Recording(read={"called": True, "leader": "razor", "helpers": ["ghost"], "skill": "engineering",
                                   "named_skill": False, "against": ""}))
    setup_demo(g2)
    (call,), _ = _calls(g2, "ghost", post)
    assert (call.leader, call.helpers, call.how) == ("razor", ["ghost"], "model")


def test_two_posts_calling_one_roll_are_both_answered(make_game):
    """Razor's player and Ghost's both call the pitch - one roll answers both, and nobody is sent back for the other."""
    g = make_game(dice=ScriptedDice([5] * 200))
    setup_demo(g)
    inputs = [("razor", "Razor makes this roll to convince the fixer, Ghost helping."),
              ("ghost", "Ghost helps Razor with the pitch (teamwork).")]
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    ctx.calls = calls.read(g, inputs, g.current_scene_id(), roll_asks(g, inputs), {})
    assert [(c.poster, c.leader, c.helpers) for c in ctx.calls] == [("razor", "razor", ["ghost"]),
                                                                    ("ghost", "razor", ["ghost"])]
    assert not tools.run_tool(ctx, tool("request_test", actor_id="razor", skill="negotiation", threshold=2,
                                        helpers=[{"id": "ghost"}], reason="the pitch")).get("is_error")
    assert all(c.met for c in ctx.calls) and calls.unmet(ctx) == []


def test_teamwork_with_nobody_helping_is_asked_once(make_game, tmp_path):
    """T128 with nobody else on file to pick: the GM is asked once to name who pitches in; repeated, it's the call -
    and it's filed, never a teamwork call rolled solo in silence (flag #38)."""
    g = make_game(Recording(), dice=ScriptedDice([2] * 200))
    magic, brask, _ = _t155(g)
    ctx = _ctx(g, "magic", T128)
    roll = {"actor_id": magic, "skill": "negotiation", "opposed_by": {"entity_id": brask}, "reason": "the window"}
    out = tools.run_tool(ctx, tool("request_test", **roll))
    assert out["is_error"] and "they called teamwork, and this roll of Magic's has nobody helping" in out["content"]
    assert not tools.run_tool(ctx, tool("request_test", **roll)).get("is_error") and ctx.calls[0].met
    assert "teamwork called, nobody helped" in {f["kind"] for f in flags.listing(tmp_path)}


def test_the_t128_helpers_the_engine_picked_are_held(make_game):
    """Review of flag #38, end to end on the live read: the GM's roll of Magic alone is turned away (hard - not the
    one-time nudge it was), and when the GM narrates past it the engine rolls Magic's Negotiation with Filament and
    Lou helping, the book's cap on what they add."""
    g = make_game(Recording(read=T128_LIVE_READ), dice=ScriptedDice([2] * 400))
    magic, brask, _ = _t155(g)
    el, sam = _crew(g)
    ctx = _ctx(g, "magic", T128)
    roll = {"actor_id": magic, "skill": "negotiation", "opposed_by": {"entity_id": brask}, "reason": "the window"}
    for _ in range(calls.HARD_REFUSALS):
        out = tools.run_tool(ctx, tool("request_test", **roll))
        assert out["is_error"] and "their post has Filament and Quiet Lou pitching in" in out["content"]
    out = tools.run_tool(ctx, tool("request_test", **roll))           # (the third: the engine rolls it right)
    assert "Team   Filament Negotiation" in ctx.cards[-1] and "Quiet Lou Negotiation" in ctx.cards[-1]
    llm = Recording([([text("Brask reads the page.")], "end_turn")] * 3 + [([text("Magic talks.")], "end_turn")],
                    read=T128_LIVE_READ)
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    _t155(g)
    _crew(g)
    res = g.run_turn([("magic", T128)])
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation"))
    assert "Filament Negotiation" in card and "Quiet Lou Negotiation" in card
    spec = json.loads(_tests(g, res.turn_id)[0]["spec"])
    assert [h["id"] for h in spec["helpers"]] == [el, sam] and spec["by"] == "engine"


def test_list_and_bracket_wordings_keep_their_helpers(make_game):
    """Review of flag #38: "Leader: Magic. Helpers: Filament, Lou." and "Magic (lead), Filament, Lou" lost every
    helper after the first (and the second its leader) when the read failed. A name with a verb of its own isn't
    one of a list ("Filament helps, Lou watches the door")."""
    g = make_game(Recording())
    magic, _, _ = _t155(g)
    el, sam = _crew(g)
    for post in ("Negotiation teamwork test. Leader: Magic. Helpers: Filament, Lou.",
                 "Teamwork Negotiation: Magic (lead), Filament, Lou.",
                 "Teamwork negotiation check, Magic leads, Filament and Lou assist."):
        (call,), _ = _calls(g, "magic", post)
        assert (call.leader, call.helpers, call.task) == (magic, [el, sam], "negotiation"), post
    (call,), _ = _calls(g, "magic", "Magic rolls Negotiation - Filament helps, Lou watches the door.")
    assert call.helpers == [el]


def test_a_flat_teamwork_modifier_is_turned_away(make_game):
    """Flag #38's probe: the GM rolled Magic's pitch with "teamwork: Filament and Lou back him (R8)" +4 - 11d6, past
    the book cap of 3 with nobody rolling to help. A modifier standing in for teamwork is turned away (nothing rolled):
    helpers roll, capped at the leader's skill (decision 3) - and the engine never carries one into its own roll."""
    g = make_game(dice=ScriptedDice([2] * 200))
    magic, brask, _ = _t155(g)
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    for label in ("teamwork: Filament and Lou back him (R8)", "Magic's coaching (teamwork)", "R8 helpers"):
        out = tools.run_tool(ctx, tool("request_test", actor_id=magic, skill="negotiation", threshold=2, reason="pitch",
                                       modifiers=[{"label": label, "value": 4}]))
        assert out["is_error"] and "stands in for teamwork" in out["content"] and "helpers=" in out["content"], label
    assert not _tests(g, 5)
    out = tools.run_tool(ctx, tool("request_test", actor_id=magic, skill="negotiation", threshold=2, reason="pitch",
                                   modifiers=[{"label": "Magic coaching her line by line", "value": 1}]))
    assert not out.get("is_error")                           # (live: coaching isn't teamwork)
    ctx = _ctx(g, "magic", ORIGINAL, turn=6)
    card = calls.engine_roll(ctx, ctx.calls[0], {"actor_id": brask, "skill": "negotiation", "threshold": 2,
                                                 "modifiers": [{"label": "R8 teamwork", "value": 4}]})
    assert "R8" not in card and "Team   Dr. A. Brask Negotiation" in card and "Pool   Charisma 4 + Negotiation 3 =" in card


# ── after the narration ─────────────────────────────────────────────────
def test_a_gm_that_narrates_past_it_is_sent_back_then_the_engine_rolls(make_game, tmp_path):
    """The live failure, end to end: the GM narrates past the call three times. Sent back twice, with exactly what to
    roll; then the engine rolls it - Magic leading, Brask helping, Edge as called - and the narration is the one written
    from the result. read_turn shows the roll, the help and who rolled it."""
    script = [([text("Vandermeer listens, and Brask does the talking.")], "end_turn"),
              ([text("Brask explains the serology. Vandermeer agrees.")], "end_turn"),
              ([text("Vandermeer says yes.")], "end_turn"),
              ([text("Magic makes the pitch; Vandermeer weighs it.")], "end_turn")]
    llm = Recording(script)
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    magic, brask, _ = _t155(g)
    res = g.run_turn([("magic", ORIGINAL)])
    assert res.narration == "Magic makes the pitch; Vandermeer weighs it." and len(llm.dm_requests) == 4
    assert "CALLED ROLLS" in llm.dm_requests[0] and "Magic [magic] leads (they named them)" in llm.dm_requests[0]
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation"))
    assert "Called Magic's player called it" in card and "Dr. A. Brask Negotiation 2d6" in card
    assert "held in reserve" in card                         # (insurance: all 5s, never short)
    kinds = [f["kind"] for f in flags.listing(tmp_path)]
    assert "skipped a roll" in kinds and "engine rolled a called roll" in kinds
    ctx = tools.TurnContext(g, res.turn_id + 1, g.current_scene_id())
    seen = research.run(ctx, "read_turn", {"turn_ids": [f"T{res.turn_id}"]})
    assert "Dr. A. Brask (" in seen and "helping: +" in seen and "rolled by the engine" in seen


def test_the_pitch_is_rolled_even_after_another_roll_of_his(make_game, tmp_path):
    """Review of P3 (flag #49, path B): the surviving T155 post names no skill, but "to persuade her" is the pitch. The
    GM reads Vandermeer first (Judge Intentions: Charisma + Intuition) and narrates her agreeing three times - the
    engine still rolls Magic's Negotiation, his insurance Edge riding it (the read spent none), and the GM narrates
    from it. Before, that other roll let the narration with no pitch stand."""
    llm = Recording([([tool("request_test", actor_id="magic", attributes=["charisma", "intuition"], threshold=2,
                            reason="reads her", edge="none")], "tool_use")]
                    + [([text("Vandermeer agrees.")], "end_turn")] * 3
                    + [([text("Magic makes the offer; Vandermeer weighs it.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    _t155(g)
    res = g.run_turn([("magic", T155)])
    assert res.narration == "Magic makes the offer; Vandermeer weighs it."
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation + Charisma"))
    assert "Called Magic's player called it" in card and "held in reserve" in card      # (all 5s: never short)
    kinds = {f["kind"] for f in flags.listing(tmp_path)}
    assert "engine rolled a called roll" in kinds and "called roll never made" not in kinds


def test_a_guessed_skill_off_the_social_ones_is_never_piled_on(make_game, tmp_path):
    """A task off the social skills is a guess ("to search the lab" reads as Perception - the GM's Electronics may
    have been it): with the leader's other roll made, the engine doesn't add the guess on top - it's flagged instead."""
    llm = Recording([([tool("request_test", actor_id="razor", skill="electronics", threshold=2, reason="the lab files")],
                      "tool_use")] + [([text("The files give up the address.")], "end_turn")] * 3)
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    res = g.run_turn([("razor", "Razor rolls to search the lab for the address.")])
    assert res.narration == "The files give up the address." and len(llm.dm_requests) == 2 + calls.SEND_BACKS
    assert not any("Called Razor's player" in c for c in res.cards)
    assert {"skipped a roll", "called roll never made"} <= {f["kind"] for f in flags.listing(tmp_path)}


def test_the_send_back_says_exactly_what_to_roll(make_game):
    """The send-back names the leader, the skill, the helpers and the Edge - and that the engine rolls it after."""
    class Seeing(Recording):
        def dm_step(self, system, tools_, messages, progress=None):
            self.seen = [m["content"] for m in messages if m["role"] == "user" and isinstance(m["content"], str)]
            return super().dm_step(system, tools_, messages, progress)
    llm = Seeing([([text("Brask explains it.")], "end_turn"),
                  ([tool("request_test", actor_id="magic", skill="negotiation", threshold=2, reason="pitch",
                         helpers=[{"id": "dr-a-brask"}], edge="if_short")], "tool_use"),
                  ([text("Magic lays it out.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    _t155(g)
    res = g.run_turn([("magic", ORIGINAL)])
    back = llm.seen[-1]
    assert res.narration == "Magic lays it out." and back.startswith("(Engine: Magic's player called a roll")
    assert "actor_id='magic'" in back and "helpers=[{'id': 'dr-a-brask'}]" in back and "edge='if_short'" in back
    assert "Sent back 1 of 2; after that the engine rolls it itself" in back
    assert "OOC" not in back                                 # (no way out of a called roll any more)


def test_the_last_step_is_still_held(make_game):
    """Review of flag #49 (D): late in the tool budget the guard used to switch off. With no room left to send the
    GM back, the engine rolls the call at once and the GM narrates from it."""
    llm = Recording([([tool("request_test", actor_id="kaz", skill="perception", threshold=2, reason="looks")],
                      "tool_use"),
                     ([text("Kaz buys it.")], "end_turn"),
                     ([text("Kaz squints at the chip, then buys it.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    g.settings.models.dm_max_steps = 1
    res = g.run_turn([("razor", "Razor bluffs Kaz about the chip. I roll Con, Edge if I miss.")])
    assert res.narration == "Kaz squints at the chip, then buys it." and len(llm.dm_requests) == 3
    card = next(c for c in res.cards if c.startswith("[ROLL] Razor: Con + Charisma vs Kaz (opposed)"))
    assert "Called Razor's player called it" in card            # (aimed at Kaz: the book's Con + Charisma against him)


# ── the record and the cap ──────────────────────────────────────────────
def test_helpers_and_the_bonus_are_on_the_record(make_game):
    """Flag #38: T128's 8d6 against Magic's base 7 couldn't say whether anyone helped. The tests row keeps each
    helper's dice and hits, the bonus and the cap that bit - and read_turn says it."""
    g = make_game(dice=ScriptedDice([5] * 8 + [5] * 7 + [2] * 50))
    magic, brask, _ = _t155(g)
    g.ledger.set_stat(brask, "negotiation", 6)                  # 9 dice of hers, 8 hits on 5s
    res = sr_lite.request_test(g.ledger, g.dice, 9, magic, "negotiation", threshold=2, reason="pitch",
                               helpers=[{"id": brask}, {"id": "joey-two-knives"}])
    assert "+3 dice to Magic (capped at their Negotiation 3)" in res["card"]
    row = _tests(g, 9)[0]
    spec = json.loads(row["spec"])
    assert spec["teamwork"] == 3 and spec["cap"] == 3
    assert spec["helpers"][0]["id"] == brask and spec["helpers"][0]["dice"] == 9 and spec["helpers"][0]["hits"] >= 4
    assert "Dr. A. Brask (" in research.roll_line(g.ledger, row) and "helping: +3 (capped at 3)" in research.roll_line(
        g.ledger, row)


def test_the_teamwork_cap_is_the_books(make_game):
    """Decision 3 (the owner, 2026-10-27): helpers' dice are capped at the leader's skill rating - the SR5 cap the engine
    uses - and that supersedes R8's 'max +4'. The canon read-back is told so (ENGINE_RULES), so it can mark R8's cap
    built in; no ruling is touched."""
    g = make_game(dice=ScriptedDice([5] * 100))
    magic, brask, _ = _t155(g)
    g.ledger.set_stat(brask, "negotiation", 6)
    team = sr_lite.teamwork(g.ledger, g.dice, magic, "negotiation", [{"id": brask}])
    assert team["hits"] > 4 and team["bonus"] == 3 == team["cap"]
    assert "capped at the leader's skill rating - the SR5 book cap, which replaces a ruling's \"max +4\"" in \
        canon.ENGINE_RULES
    assert "the engine rolls the call itself" in canon.ENGINE_RULES
    assert "capped at the leader's rating in the skill" in prompts.DM_SYSTEM
    assert "There is no skipping one" in prompts.DM_SYSTEM and "one short out-of-character line rather than" not in \
        prompts.DM_SYSTEM


def test_the_turn_message_lists_the_call(make_game):
    """The GM is told up front, so its first roll is the right one."""
    g = make_game(Recording())
    _t155(g)
    ctx = _ctx(g, "magic", ORIGINAL)
    msg = _user_message(g, "(packet)", [("magic", ORIGINAL)], g.current_scene_id(), 9, called=calls.lines(ctx))
    assert "CALLED ROLLS (binding" in msg
    assert "Magic [magic] leads (they named them) · Dr. A. Brask [dr-a-brask] helps · Negotiation (they named it)" in msg
    assert "Edge: if_short" in msg


def test_a_matrix_call_waits_for_the_beat_that_rolls(make_game):
    """A call in the Matrix is met by a Matrix beat of the decker's that rolls - a jack-in rolls nothing - and what
    it's told to do names the host the player picked (P2's hook, tools.matrix_target)."""
    g = make_game(dice=ScriptedDice([2] * 400))
    setup_demo(g)
    hid, _ = g.introduce("host", "Renraku Host", "white gravel", rating=4, turn=1)
    post = "Ghost hacks the Renraku host, using edge to reroll misses."
    ctx = _ctx(g, "ghost", post)
    from roleplay.dm.turn import matrix_asks
    ctx.matrix_asks = matrix_asks(g, [("ghost", post)])
    (call,) = ctx.calls
    assert call.task == "hacking" and "into the host they named, Renraku Host" in calls.instruction(ctx, call)
    tools.run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_in", host_id=hid, reason="in"))
    assert not call.met and calls.unmet(ctx) == [call]
    out = tools.run_tool(ctx, tool("matrix", decker_id="ghost", action="hack", edge="reroll", reason="the node"))
    assert not out.get("is_error") and call.met and matrix.live(g.ledger, "ghost") == hid


# ── review of P3 (2026-10-27): what the hold got wrong ─────────────────
T17 = ("T tell her the corp guys are making you jumpy and your PI friend says to give him a couple of days. Say "
       "straight out that he figures they'd pay ten times that, but you've got a bad feeling the boy isn't safe. Point "
       "out they never move this quick unless something's up. (I try to assist her, helping on the roll) Screw it, Tell "
       "her I'm sure enough that I'll cover a trip out of town for her and the kid, 500 ought to do it. Just stay off "
       "grid")
READ_NO = {"called": False, "leader": "", "helpers": [], "skill": "", "named_skill": False, "against": ""}


def test_an_npc_roll_aimed_elsewhere_is_the_npcs_own(make_game):
    """A roll is the call's only where it's aimed where the call is. Joey's Perception against Ghost sneaking in isn't
    Razor's called scan, and Joey leaning on Razor isn't Razor's haggle with Tanaka: each was refused twice and then
    rolled as Razor's call, "vs Ghost" - his own teammate - with Joey's 'Why'. Razor's Intimidation on Joey doesn't
    meet the haggle either; the engine's own roll of it is against Tanaka."""
    g = make_game(dice=ScriptedDice([4] * 400))
    setup_demo(g)
    ctx = _ctx(g, "razor", "I roll Perception to scan the bar for trouble.")
    spot = {"actor_id": "joey-two-knives", "skill": "perception", "reason": "Joey spots Ghost slipping in the back",
            "opposed_by": {"entity_id": "ghost", "skill": "stealth"}}
    for _ in range(calls.HARD_REFUSALS + 1):
        assert not tools.run_tool(ctx, tool("request_test", **spot)).get("is_error")
    assert not ctx.calls[0].met and {r["actor_id"] for r in _tests(g, 5)} == {"joey-two-knives"}
    card = calls.engine_roll(ctx, ctx.calls[0], spot)        # (and the engine never borrows that opposition)
    assert card.startswith("[ROLL] Razor: Perception + Intuition (threshold 2)") and "Joey spots" not in card
    ctx = _ctx(g, "razor", "I roll to haggle Tanaka down on the chip.", turn=6)
    (call,) = ctx.calls
    assert (call.task, call.against) == ("negotiation", "tanaka")
    lean = {"actor_id": "joey-two-knives", "skill": "intimidation", "reason": "Joey leans on Razor",
            "opposed_by": {"entity_id": "razor", "skill": "intimidation", "attribute": "willpower"}}
    for _ in range(calls.HARD_REFUSALS + 1):
        assert not tools.run_tool(ctx, tool("request_test", **lean)).get("is_error")
    out = tools.run_tool(ctx, tool("request_test", actor_id="razor", skill="intimidation", reason="back off",
                                   opposed_by={"entity_id": "joey-two-knives"}))
    assert not out.get("is_error") and not call.met and calls.unmet(ctx) == [call]
    assert calls.engine_roll(ctx, call).startswith("[ROLL] Razor: Negotiation + Charisma vs Tanaka (opposed)")


def test_a_ram_a_bandage_a_grenade_a_sprite_and_a_drone_meet_their_calls(make_game):
    """The roll tools the hold didn't know never met a call: a ram the GM rolled right was rolled again by the engine
    (Razor's one called push spent twice, Edge 3 -> 1), a bandage became a First Aid test opposed by the patient, a
    thrown grenade and a compile were sent back (the compile for "a spirit call"), and a drone its rigger runs was
    never the rigger's roll. Each meets its call now - nothing left owed."""
    g = make_game(dice=ScriptedDice([4] * 3000))
    setup_demo(g)
    L = g.ledger
    van = g.introduce("vehicle", "The van", "", owner_id="razor", model="bulldog", present=True, turn=1)[0]
    ctx = _ctx(g, "razor", "Razor floors it and rams Joey with the van - Piloting test, pushing the limit.")
    out = tools.run_tool(ctx, tool("crash", vehicle_id=van, driver_id="razor", into_id="joey-two-knives",
                                   speed_kph=50, reason="run him down", edge="push"))
    assert not out.get("is_error") and ctx.calls[0].met and calls.unmet(ctx) == []
    assert int(L.stat("razor", "edge_points")) == 2
    L.set_stat("ghost", "physical_damage", 4)
    ctx = _ctx(g, "razor", "Razor kneels and bandages Ghost's arm - First Aid test.", turn=6)
    (call,) = ctx.calls
    said = calls.instruction(ctx, call)
    assert call.against == "ghost" and "heal how='first_aid'" in said and "opposed_by" not in said
    out = tools.run_tool(ctx, tool("heal", target_id="ghost", how="first_aid", damage_type="physical",
                                   healer_id="razor", reason="bandages"))
    assert not out.get("is_error") and call.met and calls.unmet(ctx) == []
    call.met = False                                         # (were it the engine's: a threshold, not the patient)
    assert calls.engine_roll(ctx, call).startswith("[ROLL] Razor: First Aid + Logic (threshold 2)")
    nade = L.create_entity("item", "frag grenade", description="frag grenade", tier=1,
                           props={"explosive": "frag", "dv": 18, "blast": -1, "grenade": True}, turn=1)
    L.give("razor", nade, 1, {})
    ctx = _ctx(g, "razor", "Razor lobs the frag grenade at Joey - Throwing test.", turn=7)
    out = tools.run_tool(ctx, tool("explode", item_id=nade, holder_id="razor", thrown=True, space="open",
                                   targets=[{"id": "joey-two-knives", "range": "close", "aware": False}],
                                   reason="the frag"))
    assert not out.get("is_error") and ctx.calls[0].met
    wire = g.create_pc("Wire", "technomancer", "wire")
    g.enter_scene([wire], 1)
    ctx = _ctx(g, "wire", "Wire rolls Compiling to compile a courier sprite.", turn=8)
    (call,) = ctx.calls
    assert calls.instruction(ctx, call).startswith("a sprite call with Wire [wire] rolling")
    out = tools.run_tool(ctx, tool("sprite", techno_id=wire, action="compile", sprite_type="courier", level=2,
                                   reason="the sprite"))
    assert not out.get("is_error") and call.met
    spy = machines.build_machine(L, "Fly-Spy", "fly-spy", "ghost", turn=1)
    machines.set_control(L, 1, spy, "ghost", "remote")
    ctx = _ctx(g, "ghost", "I send my Fly-Spy over the fence to scout the yard - Perception test.", turn=9)
    out = tools.run_tool(ctx, tool("request_test", actor_id=spy, skill="perception", threshold=2, reason="the yard"))
    assert not out.get("is_error") and ctx.calls[0].met


def test_an_object_or_a_lowercase_name_word_never_leads(make_game):
    """"Lou ghosts up behind the guard, rolling Stealth", "Magic slips by the nurse, rolls Con" and "I stay quiet,
    rolling Stealth" made the guard, the nurse (live aliases of NPCs not even in the scene) or Quiet Lou the leader:
    the poster's own roll was refused twice, then the engine rolled the NPC's. A name leads only as its clause's
    subject, an NPC's alias counts only in the scene, and a lowercase name word leads only if the read says so - as
    an NPC leading a player's call is the read's to check."""
    g = make_game(Recording(), dice=ScriptedDice([4] * 400))
    setup_demo(g)
    pcs = {n: g.create_pc(n, a, n.lower().split()[0]) for n, a in (("Filament", "decker"), ("Magic", "street_samurai"),
                                                                    ("Quiet Lou", "street_samurai"))}
    g.enter_scene(list(pcs.values()), 1)
    g.introduce("npc", "KD-4 Night Guard", "night guard", "security", aliases=["Guard"], turn=1)
    g.introduce("npc", "KD-4 Night Nurse", "night nurse", "civilian", aliases=["Nurse"], turn=1)
    quiet = "Filament keeps it low and quiet, makes a Stealth test to slip by."
    for handle, post in (("quiet", "Lou ghosts up behind the guard, rolling Stealth to stay unseen."),
                         ("magic", "Magic slips by the nurse, rolls Con to pass as a visiting doctor."),
                         ("filament", "I stay quiet, rolling Stealth past the guard post."),
                         ("magic", "I stay close to the guard, rolling Perception."), ("filament", quiet)):
        (call,), _ = _calls(g, handle, post)
        assert call.leader is None and calls.leader(g.ledger, call) == call.poster, post
    ctx = _ctx(g, "quiet", "Lou ghosts up behind the guard, rolling Stealth to stay unseen.")
    out = tools.run_tool(ctx, tool("request_test", actor_id=pcs["Quiet Lou"], skill="stealth", threshold=3,
                                   reason="behind the guard"))
    assert not out.get("is_error") and ctx.calls[0].met
    n = len(g.llm.reads)
    (call,), _ = _calls(g, "magic", "Kaz makes the roll, I help.")                  # (an NPC to lead: the read checks)
    assert call.leader == "kaz" and len(g.llm.reads) == n + 1
    g2 = make_game(Recording(read={"called": True, "leader": pcs["Quiet Lou"], "helpers": [], "skill": "stealth",
                                   "named_skill": True, "against": ""}))
    setup_demo(g2)
    for name, arch in (("Filament", "decker"), ("Quiet Lou", "street_samurai")):
        g2.enter_scene([g2.create_pc(name, arch, name.lower().split()[0])], 1)
    (call,), _ = _calls(g2, "filament", quiet)                                      # (the read says it is Lou's)
    assert call.leader == pcs["Quiet Lou"]


def test_the_engines_roll_answers_both_posts_that_called_it(make_game, tmp_path):
    """Two posts calling one pitch: the engine's roll (the third give-away, or the backstop) met only the first, so
    the GM was sent back for the other and rolled the pitch twice - or the backstop rolled it twice, or flagged the
    second as never made. One roll answers both, whoever makes it."""
    g = make_game(dice=ScriptedDice([5] * 400))
    setup_demo(g)
    inputs = [("razor", "Razor makes this roll to convince the fixer, Ghost helping."),
              ("ghost", "Ghost helps Razor with the pitch (teamwork).")]
    ctx = tools.TurnContext(g, 5, g.current_scene_id())
    ctx.calls = calls.read(g, inputs, g.current_scene_id(), roll_asks(g, inputs), {})
    kaz = {"actor_id": "kaz", "skill": "negotiation", "threshold": 2, "reason": "Kaz pitches",
           "helpers": [{"id": "razor"}]}
    for _ in range(calls.HARD_REFUSALS):
        assert tools.run_tool(ctx, tool("request_test", **kaz))["is_error"]
    assert tools.run_tool(ctx, tool("request_test", **kaz))["content"].startswith("(Engine: ")
    assert len(ctx.calls) == 2 and all(c.met for c in ctx.calls) and calls.unmet(ctx) == []
    llm = Recording([([text("The fixer listens.")], "end_turn")] * 3 + [([text("Razor makes the pitch.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    setup_demo(g)
    res = g.run_turn([("razor", "Razor makes a Negotiation test to convince the fixer, Ghost helping."),
                      ("ghost", "Ghost helps Razor with the Negotiation test.")])
    assert res.narration == "Razor makes the pitch." and len(_tests(g, res.turn_id)) == 1
    assert "called roll never made" not in {f["kind"] for f in flags.listing(tmp_path)}


def test_a_hold_the_engine_cant_roll_ends(make_game, tmp_path):
    """When the engine couldn't roll the call itself, the refusal never ended: the leader knocked out mid-turn (the
    named helper taking the pitch over was refused, and told to roll the unconscious leader), or nobody named to lead.
    A leader who can't act answers the call, as unmet has it; a third give-away the engine can't roll goes through,
    flagged for the table."""
    g = make_game(dice=ScriptedDice([4] * 400))
    setup_demo(g)
    ctx = _ctx(g, "razor", "Razor rolls Negotiation to talk the fixer down, Ghost helping.")
    g.ledger.set_stat("razor", "stun_damage", 20)
    out = tools.run_tool(ctx, tool("request_test", actor_id="ghost", skill="negotiation", threshold=2,
                                   reason="Ghost takes the pitch over"))
    assert not out.get("is_error")
    g2 = make_game(Recording(), dice=ScriptedDice([4] * 400))
    setup_demo(g2)
    ctx = _ctx(g2, "ghost", "With my help, Razor scans the crowd for the courier - teamwork Perception.")
    (call,) = ctx.calls
    assert (call.leader, call.helpers) == (None, ["ghost"])
    look = {"actor_id": "razor", "skill": "perception", "threshold": 2, "reason": "the crowd"}
    for _ in range(calls.HARD_REFUSALS):
        assert "Ghost is helping" in tools.run_tool(ctx, tool("request_test", **look))["content"]
    out = tools.run_tool(ctx, tool("request_test", **look))
    assert not out.get("is_error") and call.given_up and not call.met
    assert "called roll never made" in {f["kind"] for f in flags.listing(tmp_path)}


def test_a_helper_only_call_holds_only_the_rolls_it_names(make_game):
    """Live T17's shape: "(I try to assist her, helping on the roll)" in a post about the pitch - with no leader read,
    every roll that turn was refused for leaving Quiet Lou out, without end (Juno noticing the van outside). Only a roll of someone the call
    names, or one Lou helps, is held to it."""
    g = make_game(Recording(), dice=ScriptedDice([4] * 400))
    setup_demo(g)
    sam = g.create_pc("Quiet Lou", "street_samurai", "quiet-lou")
    teo, _ = g.introduce("npc", "Marisol", "a frightened mother", "civilian", turn=1)
    juno, _ = g.introduce("npc", "Juno", "the neighbour's girl", "civilian", turn=1)
    g.enter_scene([sam, teo, juno], 1)
    ctx = _ctx(g, "quiet-lou", T17)
    (call,) = ctx.calls
    assert (call.leader, call.helpers) == (None, [sam])
    for _ in range(calls.HARD_REFUSALS + 2):
        assert not tools.run_tool(ctx, tool("request_test", actor_id=juno, skill="perception", threshold=2,
                                            reason="Juno notices the van outside")).get("is_error")
    assert not call.met
    out = tools.run_tool(ctx, tool("request_test", actor_id=teo, skill="negotiation", threshold=2, reason="the deal",
                                   helpers=[{"id": sam}]))
    assert not out.get("is_error") and call.met


def test_malformed_gm_arguments_never_cost_the_turn(make_game):
    """An opposed_by sent as a JSON string raised out of the guard (AttributeError) and a threshold of '3 (hard)' out
    of the backstop (ValueError): run_turn undid the turn each time, where with no call they were tool errors. Now
    the first is a tool error the GM fixes, and the engine rolls the second on the book's threshold."""
    llm = FakeLLM([([tool("request_test", actor_id="razor", skill="negotiation", reason="pitch",
                          opposed_by='{"entity_id": "kaz"}')], "tool_use"),
                   ([tool("request_test", actor_id="razor", skill="negotiation", reason="pitch",
                          opposed_by={"entity_id": "kaz"})], "tool_use"),
                   ([text("Kaz hears him out.")], "end_turn")], COMMIT)
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    n = g.turn_no()
    res = g.run_turn([("razor", "Razor makes a Negotiation test to convince Kaz.")])
    assert g.turn_no() == n + 1 and res.narration == "Kaz hears him out."
    llm = FakeLLM([([tool("request_test", actor_id="kaz", skill="negotiation", threshold="3 (hard)",
                          reason="Kaz pitches")], "tool_use")]
                  + [([text("Kaz calms down.")], "end_turn")] * 3 + [([text("Razor talks him down.")], "end_turn")],
                  COMMIT)
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    n = g.turn_no()
    res = g.run_turn([("razor", "Razor rolls Negotiation to talk Kaz down.")])
    assert g.turn_no() == n + 1 and res.narration == "Razor talks him down."
    # (talking Kaz down is aimed at Kaz - read inside "talk Kaz down" since 2026-10-28 - so the engine's roll is the
    # book's opposed one, Kaz resisting, where it was the book's average 2 when the call was aimed at nobody)
    assert any(c.startswith("[ROLL] Razor: Negotiation + Charisma vs Kaz (opposed)") for c in res.cards), res.cards


def test_one_called_edge_is_one_point(make_game):
    """The GM pushed Razor's called Edge on his Perception, then the engine pushed it again on the called Con - one
    "pushing the limit", two points. The engine's roll goes without it, and says so."""
    llm = FakeLLM([([tool("request_test", actor_id="razor", skill="perception", threshold=2, reason="reads the room",
                          edge="push")], "tool_use")]
                  + [([text("Kaz squints.")], "end_turn")] * 3 + [([text("Razor's bluff lands.")], "end_turn")], COMMIT)
    g = make_game(llm, dice=ScriptedDice([4] * 400))
    setup_demo(g)
    e0 = int(g.ledger.stat("razor", "edge_points"))
    res = g.run_turn([("razor", "Razor rolls Con to bluff Kaz about the chip, pushing the limit.")])
    card = next(c for c in res.cards if c.startswith("[ROLL] Razor: Con + Charisma vs Kaz (opposed)"))
    assert "spent on another roll this turn - not again" in card and "pushed" not in card
    assert int(g.ledger.stat("razor", "edge_points")) == e0 - 1


def test_the_engine_never_rolls_for_a_player_who_didnt_post(make_game, tmp_path):
    """Ghost's "Razor makes a Perception test to watch the door, I help" with Razor's player silent: the GM was sent
    back twice for Razor's test, then the engine rolled it - and Ghost's own look was refused. Each player decides for
    their own character: Razor's roll isn't owed, and only its shape holds if the GM rolls it."""
    llm = Recording([([tool("request_test", actor_id="ghost", skill="perception", threshold=2,
                            reason="Ghost watches the door")], "tool_use"),
                     ([text("Ghost keeps an eye on the door.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([4] * 400))
    setup_demo(g)
    g.set_control("razor", "player")
    res = g.run_turn([("ghost", "Razor makes a Perception test to watch the door, I help.")])
    assert res.narration == "Ghost keeps an eye on the door." and len(llm.dm_requests) == 2
    assert [r["actor_id"] for r in _tests(g, res.turn_id)] == ["ghost"]
    assert "isn't owed" in llm.dm_requests[0]
    llm = Recording([([text("Kaz glowers.")], "end_turn")])         # (Razor named, but not as the leader)
    g = make_game(llm, dice=ScriptedDice([4] * 400))
    setup_demo(g)
    g.set_control("razor", "player")
    res = g.run_turn([("ghost", "Razor talks Kaz down with a Negotiation test, I help.")])
    assert res.narration == "Kaz glowers." and len(llm.dm_requests) == 1
    assert not {"skipped a roll", "engine rolled a called roll", "called roll never made"} & {
        f["kind"] for f in flags.listing(tmp_path)}


def test_the_read_can_veto_a_loose_cue(make_game, tmp_path):
    """A post stayed owed when the cheap read said it called nothing. A bare cue word - "teamwork" - is the read's to
    veto, and with no read it's no call; a roll word stands whatever the read says. And "No roll needed" is one step,
    no send-back, no flag (it was two send-backs and an engine Perception quoting the player saying no roll)."""
    post = "Nice teamwork back there, Kaz."
    for read, n in ((None, 0), (READ_NO, 0), (dict(READ_NO, called=True), 1)):
        g = make_game(Recording(read=read))
        setup_demo(g)
        assert len(_calls(g, "razor", post)[0]) == n, read
    g = make_game(Recording(read=READ_NO))
    setup_demo(g)
    (call,), _ = _calls(g, "razor", "Razor rolls Con on Kaz - nice teamwork back there.")
    assert call.owed and call.skill == "con"
    llm = Recording([([text("Razor reads the files.")], "end_turn")] * 4)
    g = make_game(llm, dice=ScriptedDice([5] * 200))
    setup_demo(g)
    res = g.run_turn([("razor", "No roll needed - Razor searches the files Kaz's login opens.")])
    assert res.narration == "Razor reads the files." and len(llm.dm_requests) == 1 and not res.cards
    assert not flags.listing(tmp_path)


# ── review of the build (2026-10-27): the gaps the skeptics found ───────
BRASK_PITCH = {"actor_id": "dr-a-brask", "skill": "negotiation", "reason": "Brask pitches",
              "opposed_by": {"entity_id": "dr-marit-vandermeer", "skill": "negotiation"}}


def _stubborn(gm: dict, narration="Brask lays out the serology; Vandermeer agrees to the deal."):
    """A GM that hands the pitch to Brask every time it's asked, then narrates past it (live T155, five !undos)."""
    roll, narr = ([tool("request_test", **gm)], "tool_use"), ([text(narration)], "end_turn")
    return [roll, narr, roll, narr, roll, narr, narr, ([text("Magic makes the offer.")], "end_turn")]


def test_the_highest_pool_leads_when_nobody_is_named(make_game):
    """Flag #48, decision 4: "the highest pool among the named participants if nobody is named as leader". "Teamwork
    Stealth test to sneak past the guards, Lou helping" from Magic's player was Magic's 2 untrained dice by default -
    the GM's Lou-led roll refused twice, then the engine rolled Magic's itself. Lou's 9 lead now, Magic helps."""
    g = make_game(dice=ScriptedDice([4] * 400))
    magic, _, _ = _t155(g)
    sam = g.create_pc("Quiet Lou", "street_samurai", "quiet-lou")
    g.ledger.set_stat(sam, "stealth", 6)
    g.enter_scene([sam], 1)
    post = "Teamwork Stealth test to sneak past the guards, Lou helping."
    ctx = _ctx(g, "magic", post)
    (call,) = ctx.calls
    assert (call.leader, call.helpers) == (None, [sam]) and calls.leader(g.ledger, call, "stealth") == sam
    assert "the highest pool of Magic [magic] and Quiet Lou [quiet-lou]" in calls.lines(ctx)
    out = tools.run_tool(ctx, tool("request_test", actor_id=magic, skill="stealth", threshold=2, reason="sneak",
                                   helpers=[{"id": sam}]))
    assert out["is_error"] and "it's Quiet Lou's roll (the highest pool for Stealth of Magic and Quiet Lou" in \
        out["content"]
    out = tools.run_tool(ctx, tool("request_test", actor_id=sam, skill="stealth", threshold=2, reason="sneak"))
    assert out["is_error"] and "Magic is in on it" in out["content"]       # (the poster helps the one who leads)
    out = tools.run_tool(ctx, tool("request_test", actor_id=sam, skill="stealth", threshold=2, reason="sneak",
                                   helpers=[{"id": magic}]))
    assert not out.get("is_error") and call.met and "Team   Magic Stealth" in out["content"]
    ctx = _ctx(g, "magic", post, turn=6)                               # (and the engine's own roll is Lou's)
    assert calls.engine_roll(ctx, ctx.calls[0]).startswith("[ROLL] Quiet Lou: Stealth + Agility")
    ctx = _ctx(g, "magic", "Teamwork Stealth test, Magic leads, Lou helping.", turn=7)
    assert calls.leader(g.ledger, ctx.calls[0], "stealth") == magic     # (a leader they named stands, pools or no)


def test_the_read_never_replaces_a_leader_the_words_named(make_game):
    """Review of flag #48: "Teamwork Negotiation test to convince her, Magic leads." came out Brask's on a read that
    named her - the words' own lead words, the poster's too, stand."""
    g = make_game(Recording(read={"called": True, "leader": "dr-a-brask", "helpers": [], "skill": "negotiation",
                                  "named_skill": True, "against": ""}))
    magic, _, _ = _t155(g)
    (call,), _ = _calls(g, "magic", "Teamwork Negotiation test to convince her, Magic leads.")
    assert call.leader == magic and call.how == "model"


def test_the_give_aways_the_hold_missed(make_game):
    """Review of flags #48/#49/#52 - rolls in Magic's place that went through: Brask's lone pitch at a threshold (soft:
    her repeats reached the record beside the engine's roll for Magic), Brask's Etiquette at Vandermeer with Magic as
    her helper or on her own (outside the named Negotiation), and Vandermeer's read "opposed by Brask's Negotiation".
    Each is turned away now - and the engine's roll keeps Vandermeer as the other side, never Brask."""
    g = make_game(dice=ScriptedDice([3] * 600))
    magic, brask, ach = _t155(g)
    turn = 20
    for post, gm, said in (
            (T155, dict(actor_id=brask, skill="negotiation", threshold=3, reason="Brask explains the serology"),
             "Dr. A. Brask is making the Negotiation roll their player called for Magic"),
            (ORIGINAL, dict(actor_id=brask, skill="etiquette", reason="bedside manner", helpers=[{"id": magic}],
                            opposed_by={"entity_id": ach}), "this has Dr. A. Brask rolling and Magic helping"),
            (ORIGINAL, dict(actor_id=brask, skill="etiquette", reason="bedside manner", opposed_by={"entity_id": ach}),
             "Dr. A. Brask is a helper they named - the roll is Magic's"),
            (T155, dict(actor_id=brask, skill="etiquette", reason="bedside manner", opposed_by={"entity_id": ach}),
             "Dr. A. Brask is making the Etiquette roll their player called for Magic"),
            (T155, dict(actor_id=ach, attributes=["willpower", "charisma"], reason="weighs Brask's case",
                        opposed_by={"entity_id": brask, "skill": "negotiation"}),
             "this has Dr. A. Brask making the Negotiation side of it against Dr. Marit Vandermeer")):
        turn += 1
        ctx = _ctx(g, "magic", post, turn=turn)
        for _ in range(calls.HARD_REFUSALS):
            out = tools.run_tool(ctx, tool("request_test", **gm))
            assert out["is_error"] and said in out["content"], (post[:20], gm)
        assert tools.run_tool(ctx, tool("request_test", **gm))["content"].startswith("(Engine: ")
        card = ctx.cards[-1]
        # (a social skill within the call's - the GM's Etiquette on "to persuade her" - is the GM's to pick)
        assert card.startswith("[ROLL] Magic: ") and "vs Dr. A. Brask" not in card, card
        if gm.get("opposed_by"):
            assert "vs Dr. Marit Vandermeer (opposed)" in card
        assert [r["actor_id"] for r in _tests(g, turn)] == [magic]


def test_a_call_that_names_no_skill_is_still_the_leaders(make_game, tmp_path):
    """Flags #49/#52: a call with a leader but no skill or task ("Only magic is making the roll... Then I make the
    offer", two sentences on) let Brask's pitch through every time, and the backstop had nothing to roll: three Brask
    rows, the narration on her roll standing. Now "only Magic" and "not Brask" make her roll a give-away; a bare "Magic
    is making the roll" gets the one nudge - and either way the engine rolls Magic's Negotiation against Vandermeer,
    the skill and the other side taken from the roll the GM gave away."""
    real = ("Only magic is making the roll. He'll use edge to reroll misses if needed.\n\nI explain about the kids. "
            "I tell her what the clinic costs them. Then I make the offer.")
    plain = "Magic is making the roll, not Brask. He'll use edge to reroll misses if needed."
    bare = "Magic is making the roll. He'll use edge to reroll misses if needed."
    for post, brask_rows in ((real, 0), (plain, 0), (bare, 2)):
        llm = Recording(_stubborn(BRASK_PITCH))
        g = make_game(llm, dice=ScriptedDice([5] * 600))
        magic, brask, ach = _t155(g)
        res = g.run_turn([("magic", post)])
        rows = [r["actor_id"] for r in _tests(g, res.turn_id)]
        assert rows.count(brask) == brask_rows and rows.count(magic) == 1, (post, rows)
        card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation + Charisma"))
        assert "vs Dr. Marit Vandermeer (opposed)" in card and "Called Magic's player called it" in card
    (call,), _ = _calls(g, "magic", real)
    assert (call.hint, call.only, call.task) == ("negotiation", True, None)
    (call,), _ = _calls(g, "magic", plain)
    assert call.excluded == [brask]
    assert "called roll never made" not in {f["kind"] for f in flags.listing(tmp_path)}


def test_a_plain_call_leaves_an_npcs_roll_at_a_runner_alone(make_game):
    """What the plain-call hold must not touch: Joey's Perception against Ghost sneaking in is Joey's own."""
    g = make_game(dice=ScriptedDice([4] * 200))
    setup_demo(g)
    ctx = _ctx(g, "razor", "Razor pushes the limit on the shot.")
    out = tools.run_tool(ctx, tool("request_test", actor_id="joey-two-knives", skill="perception", reason="spots him",
                                   opposed_by={"entity_id": "ghost", "skill": "stealth"}))
    assert not out.get("is_error") and ctx.calls[0].seen is None


def test_a_call_with_no_skill_asks_the_read_or_tells_the_table(make_game, tmp_path):
    """Flag #51: "I want a teamwork skill check, Magic leading, Brask helping, with Edge reroll on failures" read as
    sure - no read asked - and with the GM narrating past it the engine had no skill: no roll, the narration
    committed, a developer flag the only trace, after a send-back that promised the engine would roll it. Now the read
    names the skill and the engine rolls it; with no read, the send-back promises only what's true and the table is
    told the roll wasn't made ([CALL])."""
    post = "I want a teamwork skill check, Magic leading, Brask helping, with Edge reroll on failures."
    read = {"called": True, "leader": "magic", "helpers": ["dr-a-brask"], "skill": "negotiation", "named_skill": False,
            "against": "dr-marit-vandermeer"}
    narr = [([text("Vandermeer listens while Brask explains the serology, and agrees.")], "end_turn")] * 3 + [
        ([text("Magic makes the case.")], "end_turn")]
    llm = Recording(list(narr), read=read)
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    magic, brask, ach = _t155(g)
    res = g.run_turn([("magic", post)])
    assert len(llm.reads) == 1 and res.narration == "Magic makes the case."
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation + Charisma vs Dr. Marit Vandermeer"))
    assert "Team   Dr. A. Brask Negotiation" in card

    class Seeing(Recording):
        def dm_step(self, system, tools_, messages, progress=None):
            self.seen = [m["content"] for m in messages if m["role"] == "user" and isinstance(m["content"], str)]
            return super().dm_step(system, tools_, messages, progress)
    llm = Seeing(list(narr))
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    outs = []
    g.out = outs.append
    _t155(g)
    res = g.run_turn([("magic", post)])
    assert len(llm.reads) == 2                                 # (at the start, and for the skill at the backstop)
    assert "the engine rolls it itself if it can tell the skill" in llm.seen[-1]
    assert "no skill said" in llm.dm_requests[0]
    assert not _tests(g, res.turn_id) and any(o.startswith("[CALL] The roll Magic's player called") for o in outs)
    assert "called roll never made" in {f["kind"] for f in flags.listing(tmp_path)}
    from roleplay.discord_bot.render import classify
    assert classify(next(o for o in outs if o.startswith("[CALL]"))) == "notice"   # (the channel shows it)


@pytest.mark.parametrize("post", [
    "Magic leads a teamwork persuasion roll, Brask assists. Use edge to reroll misses.",
    "Magic gets Vandermeer on board - teamwork, Brask helping, Magic leading the roll. Edge to reroll misses.",
    "Teamwork roll, Magic leading - Brask helping, Magic does the talking."])
def test_more_task_words_point_at_the_pitch(make_game, post):
    """Review of flag #51: 'persuasion' (TASKS had persuad-), 'on board' and 'does the talking' named no task."""
    g = make_game(Recording())
    magic, brask, _ = _t155(g)
    (call,), _ = _calls(g, "magic", post)
    assert (call.leader, call.helpers, call.task) == (magic, [brask], "negotiation"), post


@pytest.mark.parametrize("post, mode", [
    ("Teamwork Negotiation, Magic leading, with Edge reroll on failures.", "reroll"),
    ("Teamwork Negotiation, Magic leading. Edge reroll if he misses.", "if_short"),
    ("Magic rolls Negotiation with an Edge reroll on misses.", "reroll"),
    ("Magic rolls Negotiation. Reroll misses with edge.", "reroll"),
    ("Magic rolls Negotiation, Edge reroll on misses.", "reroll")])
def test_more_edge_wordings_are_held(make_game, post, mode):
    """Review of flag #51: edge_asks read none of these, so the called Edge wasn't held on the roll."""
    g = make_game()
    magic, _, _ = _t155(g)
    assert edge_asks(g, [("magic", post)])[magic][1] == mode, post


def test_a_called_push_with_no_edge_left_is_still_rolled(make_game, tmp_path):
    """Flag #50, path 1: Magic called a push at 0 Edge (spent per session); the GM narrated past it three times, the
    engine's push raised 'no Edge points left', and the call was given up - the narration with no roll committed. The
    engine rolls it without the push now, and the card says so."""
    llm = Recording([([text("Vandermeer listens; Brask does the talking.")], "end_turn")] * 3
                    + [([text("Magic pitches.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([3] * 400))
    magic, _, _ = _t155(g)
    g.ledger.set_stat(magic, "edge_points", 0)
    res = g.run_turn([("magic", "Teamwork Negotiation test led by Magic, Brask helping. Magic pushes the limit.")])
    assert res.narration == "Magic pitches."
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation"))
    assert "no points left - rolled without the push they called" in card
    assert "called roll never made" not in {f["kind"] for f in flags.listing(tmp_path)}


def test_an_opposition_the_engine_cant_roll_never_ends_the_call(make_game, tmp_path):
    """Flag #50, path 2: the GM's give-away carried opposed_by with three attributes (it passes the schema; the pool
    rejects it). Turned away before the dice, the GM narrated past twice - and the engine reused that opposition,
    raised, and gave up. It rolls the call in its own shape now, against Vandermeer by the book."""
    bad = dict(BRASK_PITCH, opposed_by={"entity_id": "dr-marit-vandermeer",
                                       "attributes": ["charisma", "intuition", "willpower"]})
    llm = Recording([([tool("request_test", **bad)], "tool_use")]
                    + [([text("Vandermeer listens; Brask does the talking.")], "end_turn")] * 3
                    + [([text("Magic pitches.")], "end_turn")])
    g = make_game(llm, dice=ScriptedDice([3] * 400))
    magic, _, _ = _t155(g)
    res = g.run_turn([("magic", ORIGINAL)])
    assert res.narration == "Magic pitches."
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation"))
    assert "the GM's version wouldn't roll" in card
    assert [r["actor_id"] for r in _tests(g, res.turn_id)] == [magic]


def test_a_possessive_ends_a_sentence(make_game):
    """Review of flag #52: "This is Magic's roll, not Brask's. Brask can help." - the period after "Brask's" read as an
    initial's, so "Brask can help" fell into the call's sentence and the help was lost."""
    g = make_game(Recording())
    magic, brask, _ = _t155(g)
    (call,), _ = _calls(g, "magic", "This is Magic's roll, not Brask's. Brask can help.")
    assert (call.leader, call.helpers, call.excluded) == (magic, [brask], [brask])


@pytest.mark.parametrize("post", [
    "Magic as the leader, Brask as helper: teamwork negotiation roll to convince Vandermeer, edge to reroll misses",
    "Magic gets Vandermeer on board - teamwork, Brask helping, Magic leading the roll. Edge to reroll misses.",
    "Magic leads, Brask helps. Persuade Vandermeer. Teamwork. Edge: reroll misses.",
    "Magic takes point on this, Brask chips in. Teamwork check to win Vandermeer over, edge to reroll misses.",
    "Teamwork Negotiation, Magic leads, Brask helps - Magic pitches the deal to Vandermeer."])
def test_whom_its_aimed_at_is_never_a_helper(make_game, post):
    """Review 2026-10-28 of flag #51, with the read down: "Brask as helper" (no article) wasn't a help, and only the
    first task word was looked behind ("negotiation roll to convince Vandermeer"), so the pitch was aimed at nobody and
    the teamwork's picked helpers took in Vandermeer - the one it's aimed at, rolling to help convince herself. "gets
    Vandermeer on board" has her inside the task; a short task line between ("Persuade Vandermeer.") lost the role line
    beyond it, Magic's lead with it; "takes point" is a lead."""
    g = make_game(Recording())
    magic, brask, ach = _t155(g)
    (call,), _ = _calls(g, "magic", post)
    assert (call.leader, call.helpers, call.against) == (magic, [brask], ach), post
    # (only the call's own task is looked behind: the Stealth here isn't aimed at the one Magic later talks to)
    (call,), _ = _calls(g, "magic", "Magic rolls Stealth to sneak past the desk and later convinces Vandermeer.")
    assert (call.task, call.against) == ("stealth", None)


def test_the_engines_teamwork_roll_with_nobody_to_help_is_filed(make_game, tmp_path):
    """Flag #38 (review 2026-10-28): T128 with Filament and Lou their own players' idle characters - nobody the engine
    may pick to help - and the live read (helpers []). The GM narrates past it; the engine rolls Magic's Negotiation
    alone. That's still never a teamwork call rolled solo in silence: the card says nobody could help, and it's filed,
    as the GM's own solo roll is."""
    llm = Recording([([text("Brask reads the page.")], "end_turn")] * 3 + [([text("Magic talks.")], "end_turn")],
                    read=T128_LIVE_READ)
    g = make_game(llm, dice=ScriptedDice([5] * 400))
    _t155(g)
    for name in ("Filament", "Quiet Lou"):                      # (idle: their players didn't post - hands off)
        g.enter_scene([g.create_pc(name, "decker", name.lower().replace(" ", "-"))], 1)
    res = g.run_turn([("magic", T128)])
    card = next(c for c in res.cards if c.startswith("[ROLL] Magic: Negotiation"))
    assert "Team   nobody to help" in card and "Filament Negotiation" not in card
    assert "teamwork called, nobody helped" in {f["kind"] for f in flags.listing(tmp_path)}
