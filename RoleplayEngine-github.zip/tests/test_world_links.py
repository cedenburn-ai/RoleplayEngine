"""The world's connective tissue: the story clock, NPCs reaching each other, factions acting through people."""
import pytest

from roleplay.dm import world
from roleplay.engine import clock
from roleplay.engine.dice import ScriptedDice
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import text
from .test_world import NONE, PERSONA, WorldLLM, _personas


# ── the story clock ──────────────────────────────────────────────────────

def test_clock_parsing_and_formatting():
    """Story time is narrative: a day and a part of it, said the way a person would."""
    D = clock.DAY
    now = 22 * 60 + 30                                         # Day 1, night
    assert clock.fmt(now) == "Day 1, night" and clock.short(D + 15 * 60) == "Day 2 afternoon"
    assert clock.parse("later", now) == D + 60                  # the next part of the day: the small hours
    assert clock.fmt(clock.parse("tomorrow morning", now)) == "Day 2, morning"
    assert clock.fmt(clock.parse("next morning", now)) == "Day 2, morning"
    assert clock.fmt(clock.parse("evening", D + 15 * 60)) == "Day 2, evening"
    assert clock.parse("this afternoon", D + 15 * 60) == D + 15 * 60         # already is: no jump
    assert clock.fmt(clock.parse("day 4 night", now)) == "Day 4, night"
    assert clock.parse("2 days later", now) == now + 2 * D
    assert clock.fmt(clock.parse("tomorrow morning", D + 2 * 60)) == "Day 2, morning"   # at 2 a.m., it's hours away
    assert clock.parse("+45m", now) == now + 45 and clock.parse("02:10", now) == D + 130   # the old forms still work
    afternoon = D + 15 * 60
    assert [clock.since(t, afternoon) for t in (afternoon, D + 9 * 60, D + 2 * 60, 22 * 60, 9 * 60, 2 * 60)] == [
        "this afternoon", "this morning", "last night", "last night", "yesterday morning", "the night before last"]
    assert clock.since(D * 3 + 15 * 60, D * 9 + 15 * 60) == "6 days ago"
    with pytest.raises(ValueError):
        clock.parse("teatime", now)


def test_a_turn_doesnt_tick_the_clock_the_gm_moves_it(make_game):
    extraction = {**NONE, "summary": "Razor waited.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 25}
    llm = WorldLLM([([text("Time crawls.")], "end_turn"),
                    ([text("Dawn comes grey.\n<dm>\ntime: next morning\n</dm>")], "end_turn")], extraction)
    g = make_game(llm)
    setup_demo(g)
    start = g.clock()
    res = g.run_turn([("razor", "I wait.")])
    assert g.clock() == start and g.sub.node(res.slice_id)["story_time"] == start   # (the estimate is ignored)
    res = g.run_turn([("razor", "I wait until morning.")])
    assert g.clock_line() == "Day 2, morning" and res.narration == "Dawn comes grey."
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hi")], res.turn_id + 1)
    assert "Story time: Day 2, morning" in packet
    assert "(S3, last night, heat" in packet and "(S3, this morning, heat" in packet   # memories in story time


# every phrasing the clock investigation found the GM writing (time: lines, narrations) - live T156-T164
READS = [
    ("Day 9, evening", ["3 days later, evening", "3 days later evening", "three days later, evening",
                        "evening, 3 days later", "evening (3 days later)", "3 days later. evening", "Day 9 - evening",
                        "day 9 at dusk", "day 9: evening", "the evening of day 9"]),
    ("Day 8, evening", ["two days later at dusk"]),
    ("Day 8, morning", ["two days later, morning", "a couple of days later", "couple days later",
                        "the day after tomorrow"]),
    ("Day 13, morning", ["a week later, morning", "a week later", "a week after", "next week"]),
    ("Day 13, evening", ["next week, evening"]),
    ("Day 186, morning", ["6 months later", "six months later", "six months on"]),
    ("Day 36, morning", ["a month later"]),
    ("Day 20, morning", ["a fortnight later"]),
    ("Day 9, morning", ["three quiet days go by", "3 days pass", "in 3 days", "after 3 days", "days later", "day 9"]),
    ("Day 6, morning", ["late morning", "mid-morning", "by midmorning", "this morning", "in the morning"]),
    ("Day 6, midday", ["by noon", "later today", "later that day", "a few hours later", "mid-day"]),
    ("Day 6, afternoon", ["early afternoon", "by early afternoon", "that afternoon", "later this afternoon"]),
    ("Day 6, evening", ["early evening", "that evening", "later that evening", "by dusk", "by nightfall", "Evening!"]),
    ("Day 6, night", ["that night", "later that night", "tonight", "after dark", "into the night"]),
    ("Day 7, late night", ["before dawn", "just before dawn", "after midnight", "late that night"]),
    ("Day 7, dawn", ["tomorrow at dawn", "dawn tomorrow", "until dawn"]),
    ("Day 7, morning", ["the following morning", "the morning after", "overnight", "the next morning", "tomorrow",
                        "the day after", "a night passes"]),
    ("Day 7, midday", ["noon tomorrow", "tomorrow at noon"]),
    ("Day 7, evening", ["next day, evening", "the following day, evening", "the evening after"]),
    ("Day 8, night", ["two nights later"]),
]


def test_the_clock_reads_what_the_gm_writes():
    """Live T160/T162: '6 months later' (a skip a player asked for) and '3 days later, evening' were both thrown out,
    and the clock sat six months and three days behind the story. A jump now combines with a part of day on either
    side, months and years are units, and the GM's everyday phrasings read."""
    D = clock.DAY
    now = 5 * D + 9 * 60                                         # Day 6, morning: the live clock at T162
    for want, phrasings in READS:
        for s in phrasings:
            assert clock.fmt(clock.parse(s, now)) == want, s
    assert clock.parse("an hour later", now) == now + 60 and clock.parse("ten minutes later", now) == now + 10
    assert clock.parse("half an hour later", now) == now + 30 and clock.parse("18 months later", now) == now + 540 * D
    assert clock.parse("6 months later", now) == now + 180 * D                  # a month is 30 days, a year 365
    assert clock.parse("a year later", now) == now + 365 * D
    # '<N days later>, late night' is the small hours AFTER that day's evening
    assert clock.parse("3 days later, late night", now) == 9 * D + 60          # Day 10, 01:00
    # in the small hours the story's day is still the one before (as 'tomorrow' always has been)
    small = 7 * D + 60                                                         # Day 8, 01:00
    assert clock.fmt(clock.parse("3 days later, evening", small)) == "Day 10, evening"
    for s in ("later that night", "that night", "tonight", "night", "late that night"):   # this night, not 21 hours on
        assert clock.parse(s, small) == small, s
    # ...but the rest of today is the coming one, on the calendar day the GM sees (review, 2026-10-24: at 03:00
    # 'later that morning' was read as yesterday's, so the clock silently stayed - and no miss was recorded)
    for at in (7 * D + 60, 7 * D + 3 * 60, 7 * D + 4 * 60 + 50):                # Day 8, 01:00 / 03:00 / 04:50
        for s, want in (("this morning", 9), ("later that morning", 9), ("later this morning", 9), ("this dawn", 6),
                        ("this afternoon", 15), ("that midday", 12), ("this evening", 19), ("later that evening", 19)):
            assert clock.parse(s, at) == 7 * D + want * 60, (at, s)
    # today's part never rolls a day on: once it's passed, the clock stays
    late = 5 * D + 22 * 60                                                     # Day 6, night
    for s in ("that evening", "later that evening", "this evening", "this morning"):
        assert clock.parse(s, late) == late, s
    assert clock.fmt(clock.parse("evening", late)) == "Day 7, evening"         # (a bare part is the next one)
    for bad in ("teatime", "3 days later, teatime", "an hour later, evening", "twenty minutes later"):
        with pytest.raises(ValueError, match="^can't read a time from"):
            clock.parse(bad, now)
    with pytest.raises(ValueError, match="digits work"):
        clock.parse("eighteen months later", now)
    # a part of day before a jump with no number (review, 2026-10-24: it was read as an adjective and dropped -
    # 'evening, days later' landed in the morning, and 'evening, hours later' moved three hours with no error)
    for s in ("evening, days later", "dusk, days later", "evening - days later", "evening (days later)"):
        assert clock.fmt(clock.parse(s, now)) == "Day 9, evening", s
    assert clock.fmt(clock.parse("night, days later", now)) == "Day 9, night"
    assert clock.fmt(clock.parse("late evening, days later", now)) == "Day 9, night"
    assert clock.fmt(clock.parse("evening, weeks later", now)) == "Day 27, evening"
    with pytest.raises(ValueError, match="^can't read a time from"):
        clock.parse("evening, hours later", now)                               # (as 'an hour later, evening')
    # and memories read like it after a long skip: not '26 weeks ago'
    assert clock.since(5 * D + 9 * 60, 188 * D + 9 * 60) == "6 months ago"
    assert clock.since(5 * D + 22 * 60, 188 * D + 9 * 60) == "6 months ago"     # (a night, too)
    assert clock.since(5 * D, 30 * D) == "3 weeks ago" and clock.since(5 * D, 400 * D) == "a year ago"


def test_a_time_line_the_clock_cant_read_reaches_the_gm(make_game):
    """Live T162: 'time: 3 days later, evening' was rejected into the bot log alone, and the GM narrated on from the
    old clock ('Day 7, evening' after three days had passed). Now the next packet says so, right under Story time."""
    extraction = {**NONE, "summary": "The crew lay low.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}]}
    llm = WorldLLM([([text("Three quiet days go by.\n<dm>\ntime: 3 days later, teatime\n</dm>")], "end_turn"),
                    ([text("Still quiet.")], "end_turn"),
                    ([text("Three quiet days go by.\n<dm>\ntime: 3 days later, evening\n</dm>")], "end_turn")],
                   extraction)
    g = make_game(llm)
    setup_demo(g)
    start = g.clock()
    res = g.run_turn([("razor", "We lie low.")])
    assert g.clock() == start                                                  # not moved...
    res = g.run_turn([("razor", "We keep lying low.")])
    lines = res.packet.splitlines()
    at = next(i for i, x in enumerate(lines) if x.startswith("Story time:"))
    assert "your last `time: 3 days later, teatime` wasn't read, so that line didn't move the clock" in lines[at + 1]
    res = g.run_turn([("razor", "Still lying low.")])
    assert "wasn't read" not in res.packet                                     # (once: the turn right after)
    assert g.clock_line() == "Day 4, evening" and g.ledger.meta("clock_miss") == ""   # a line that reads clears it


LIE_LOW = {**NONE, "summary": "The crew lay low.", "recalled": [], "facts": [], "told": [], "new_entities": [],
           "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}
TEATIME = "Three quiet days go by.\n<dm>\ntime: 3 days later, teatime\n</dm>"


def test_the_owners_time_answers_an_unread_time_line(make_game):
    """Review (2026-10-24): after an unread `time: 3 days later, teatime`, the owner's `!time 3 days later, evening`
    moved the clock - and the next packet still said the clock didn't move, "set it again, e.g. `time: 3 days later,
    evening`". A GM that did skipped three more days: Day 1 -> Day 4 (the owner) -> Day 7. Setting the clock, any
    way, answers the miss."""
    import asyncio

    from roleplay.discord_bot.session import CampaignTable

    from .test_discord import FakeChannel
    g = make_game(WorldLLM([([text(TEATIME)], "end_turn")], LIE_LOW))
    setup_demo(g)
    g.run_turn([("razor", "We lie low.")])
    assert g.clock_line() == "Day 1, night" and g.ledger.meta("clock_miss")     # unread, and kept for the GM

    async def go():
        t = CampaignTable(g, FakeChannel(), owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})

        async def react(e):
            pass
        await t.handle("1", "Owner", "!time 3 days later, evening", False, react)
        assert g.clock_line() == "Day 4, evening"
        packet, _ = build_packet(g, g.current_scene_id(), [("razor", "ok")], g.turn_no() + 1)
        assert "wasn't read" not in packet and g.ledger.meta("clock_miss") == ""
        await t.close()
    asyncio.run(go())


def test_a_whisper_doesnt_spend_the_unread_time_note(make_game):
    """Review (2026-10-24): the note showed on turn_id - 1 alone, so a whisper right after the unread line took it -
    told the private GM call to set the shared clock - and the table's next turn heard nothing (the T162 miss again).
    A whisper never shows it; the table's next public turn does."""
    llm = WorldLLM([([text(TEATIME)], "end_turn"), ([text("Razor pockets the chip quietly.")], "end_turn"),
                    ([text("The rain keeps falling.")], "end_turn")], LIE_LOW)
    g = make_game(llm)
    setup_demo(g)
    g.run_turn([("razor", "We lie low for three days.")])
    g.run_turn([("razor", "I pocket the chip")], private="razor")
    g.run_turn([("razor", "What now?")])
    told = ["your last `time: 3 days later, teatime` wasn't read" in req for req in llm.dm_requests]
    assert told == [False, False, True]


# ── NPCs reaching each other ─────────────────────────────────────────────

def test_a_call_is_witnessed_by_both_carries_hearsay_and_wakes_the_other(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    aid = world.add_agenda(g, "kaz", "find out who Razor works for", ["razor"], g.turn_no(), by="dm")
    memory = next(r["id"] for r in g.sub.witnessed_slices("kaz") if r["id"].startswith("T"))
    llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz called Tanaka",
                        "on_success": "Kaz called Tanaka about Razor.",
                        "contacts": [{"who": "tanaka", "kind": "npc", "says": "Razor's selling - you buying?",
                                      "shares": [memory, "T999"]}]}
    lines = g.world_pass()
    assert any("reached Tanaka" in x for x in lines)
    call = next(r for r in g.conn.execute("SELECT * FROM nodes WHERE visibility='offscreen' AND text LIKE 'Kaz reached%'"))
    assert dict(g.sub.members_of(call["id"])) == {"kaz": "actor", "tanaka": "target"}     # both remember the call
    assert g.conn.execute("SELECT how, source FROM knows WHERE holder='tanaka' AND node_id=?",
                          (memory,)).fetchone()[:] == ("told", "kaz")                     # and Tanaka heard the story
    jobs = [j for j in world.plan(g) if j.kind == "agent"]
    tj = next(j for j in jobs if j.npc == "tanaka")                                      # the call wakes him
    assert "MESSAGE (tonight): Kaz reached Tanaka: Razor's selling - you buying?" in tj.user
    world.apply(g, tj, {**NONE})
    assert all(j.npc != "tanaka" for j in world.plan(g) if j.kind == "agent")             # message read

    g.ledger.enter(g.current_scene_id(), ["kaz"], g.turn_no())                           # Kaz back on screen:
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "Kaz?")], g.turn_no() + 1)
    assert "Lately, offscreen: [W" in packet and "Kaz reached Tanaka" in packet           # the DM knows what he did


# ── factions ─────────────────────────────────────────────────────────────

FACTION = {"summary": "A Redmond street gang of elves in green leathers.", "wants": "Turf and respect.",
           "methods": "Intimidation, numbers, payback.", "resources": "Thirty gangers, bikes, a chop shop.",
           "territory": "Redmond Barrens.", "leadership": "A war council.", "rivals": "The Halloweeners.",
           "secret": "They owe a Yakuza oyabun.", "reach": 3, "funds": 15000}


class FactionLLM(WorldLLM):
    def structured(self, model, system, user, schema, **kw):
        if system is world.PERSONA_SYSTEM:
            self.world_calls.append(("persona", user))
            joey = "Joey Two-Knives [joey" in user
            return {**PERSONA, "affiliations": [{"name": "the Ancients", "role": "ganger"}] if joey else []}
        if system is world.FACTION_SYSTEM:
            self.world_calls.append(("faction", user))
            return FACTION
        return super().structured(model, system, user, schema, **kw)


def test_affiliations_found_factions_that_act_through_their_people(make_game):
    llm = FactionLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 6 + [1] * 30))
    setup_demo(g)
    L = g.ledger
    for _ in range(6):                                        # personas, then the faction's own profile
        g.world_pass()
    anc = L.find("Ancients")
    assert anc and anc["kind"] == "faction" and L.find("the Ancients")["id"] == anc["id"]
    joey = L.find("Joey Two-Knives")["id"]
    assert [(f["id"], role) for f, role in world.factions_of(g, joey)] == [(anc["id"], "ganger")]
    assert world.persona(L.get(anc["id"]))["wants"] == "Turf and respect."
    assert int(L.stat(anc["id"], "reach")) == 3 and int(L.stat(anc["id"], "nuyen")) == 15000
    assert L.get(anc["id"])["description"].startswith("A Redmond street gang")
    assert "KNOWN MEMBERS:\n- Joey Two-Knives (ganger)" in next(u for k, u in llm.world_calls if k == "faction")
    assert "Member of: Ancients (ganger)" in world.persona_line(L.get(joey))

    # a member gets hurt -> the faction notices; it rolls its reach and sends people
    from roleplay.engine.rules import sr_lite
    sr_lite.apply_damage(L, ScriptedDice([1] * 10), g.turn_no() + 1, joey, 4, "physical")
    g.conn.execute("INSERT INTO turns(id, scene_id, status) VALUES(?,?,'committed')", (g.turn_no() + 1, 1))
    llm.agent[anc["id"]] = {**NONE, "decision": "start", "goal": "Find who hurt Joey and make an example",
                            "targets": [joey], "action": "The Ancients put the word out on the street",
                            "test_skill": "street network", "test_threshold": 2,
                            "on_success": "The Ancients' word went out across Redmond.",
                            "new_people": [{"name": "Vex", "description": "Ancients enforcer", "template": "ganger"}],
                            "contacts": [{"who": joey, "kind": "npc", "says": "Sit tight, we're on it.", "shares": []}],
                            "spend": 500}
    job = next(j for j in world.plan(g) if j.npc == anc["id"])
    assert "Your ganger Joey Two-Knives was hurt" in job.user and "YOUR MEMBERS: Joey Two-Knives" in job.user
    assert "FACTION: Ancients" in job.user and "reach x2" in job.user
    lines = world.apply(g, job, llm.agent[anc["id"]])
    assert any("reach 6d6 vs 2: 6 hit(s), success" in x for x in lines)                 # reach 3 -> 6 dice
    vex = L.find("Vex")["id"]
    assert (vex, "recruit") in [(m["id"], r) for m, r in world.members_of(g, anc["id"])]
    assert int(L.stat(anc["id"], "nuyen")) == 15000 - 500
    assert sr_lite.condition(L, joey) == "wounded"
    jj = next(j for j in world.plan(g) if j.kind == "agent" and j.npc == joey)            # orders wake the member
    assert "MESSAGE (tonight): Ancients reached Joey Two-Knives: Sit tight, we're on it." in jj.user
    assert "Ancients [" in world.summary(g) and "members: Joey Two-Knives, Vex" in world.summary(g)


def test_things_and_whereabouts_stay_true_to_the_ledger(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    L = g.ledger
    chip = next(i["id"] for i in L.holdings("ghost") if "chip" in i["id"])
    book, _ = g.introduce("item", "Tanaka's ledger", "a battered paper ledger of debts", owner_id="tanaka", turn=0)
    old_scene = g.current_scene_id()
    g.new_scene("Out in the rain", None, ["razor", "ghost"], g.turn_no())        # the party leaves Kaz at the bar
    aid = world.add_agenda(g, "kaz", "get leverage on Tanaka", ["tanaka", chip], g.turn_no(), by="dm")
    llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz lifted Tanaka's ledger",
                        "on_success": "Kaz lifted Tanaka's ledger from his coat at the noodle bar.",
                        "acquire": [book, chip],
                        "whereabouts": [{"who": "kaz", "where": "a noodle bar in Chinatown"},
                                        {"who": "razor", "where": "the bottom of Puget Sound"}]}
    lines = g.world_pass()
    user = next(u for k, u in llm.world_calls if k == "agent" and "Kaz [kaz]" in u)
    assert f"Renraku datachip [{chip}] - held by Ghost (PC)" in user                    # the ledger, shown
    assert "WHERE YOU ARE: The Lucky Shot (where they were last seen)" in user
    assert any("takes Tanaka's ledger" in x for x in lines) and L.holds("kaz", book) and not L.holds("tanaka", book)
    assert any("can't take Renraku datachip" in x for x in lines) and L.holds("ghost", chip)   # never from a PC
    assert "kaz" not in L.roster(old_scene)                                             # he left the bar
    assert world.whereabouts(g, "kaz").startswith("a noodle bar in Chinatown")
    assert L.get("razor")["props"].get("whereabouts") is None                           # nobody moves the PCs
    trig = world.triggers(g, "tanaka", 0, g.turn_no())                                  # Tanaka will miss it
    assert any("Tanaka's ledger is gone" in x for x, _ in trig)
    g.enter_scene(["kaz"], g.turn_no())                                                 # back on screen
    assert "whereabouts" not in L.get("kaz")["props"]


def test_something_done_to_you_later_in_the_same_pass_still_counts(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    L = g.ledger
    book, _ = g.introduce("item", "Tanaka's ledger", "a battered paper ledger of debts", owner_id="tanaka", turn=0)
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    world.add_agenda(g, "tanaka", "collect old debts", [], g.turn_no(), by="dm")       # Tanaka moves first...
    world.add_agenda(g, "kaz", "get leverage on Tanaka", ["tanaka"], g.turn_no(), by="dm")
    llm.agent["tanaka"] = {**NONE, "decision": "continue", "action": "Tanaka counted the night's take.",
                           "on_success": "Tanaka counted the night's take."}
    llm.agent["kaz"] = {**NONE, "decision": "continue", "action": "Kaz lifted Tanaka's ledger",
                        "on_success": "Kaz lifted Tanaka's ledger.", "acquire": [book]}
    g.world_pass()                                                     # ...then Kaz robs him, same turn
    assert L.holds("kaz", book)
    assert any(j.npc == "tanaka" and "Tanaka's ledger is gone" in j.user for j in world.plan(g) if j.kind == "agent")


def test_factions_see_who_is_on_screen_and_their_people_remember_their_work(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    syn, _ = g.introduce("faction", "Lone Star", "Seattle's contracted police", turn=0)
    g.ledger.update_entity(syn, props={"persona": {"summary": "Cops for hire."}})
    world.join_faction(g, "kaz", syn, "informant", 0)              # Kaz is in the scene with the PCs
    world.join_faction(g, "tanaka", syn, "asset", 0)               # Tanaka is not
    aid = world.add_agenda(g, syn, "work the 520 bridge case", ["razor"], g.turn_no(), by="dm")
    llm.agent[syn] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Lone Star squeezed its asset",
                      "on_success": "Lone Star had Tanaka pull the fence's books on the 520 job.",
                      "whereabouts": [{"who": "kaz", "where": "a precinct interview room"}]}
    job = next(j for j in world.plan(g) if j.npc == syn)
    assert "Kaz [kaz] (informant, ok, ON SCREEN)" in job.user and "never narrate what they do" in AGENT_SYSTEM_TEXT()
    world.apply(g, job, llm.agent[syn])
    w = g.conn.execute("SELECT id FROM nodes WHERE visibility='offscreen' ORDER BY rowid DESC LIMIT 1").fetchone()["id"]
    roles = dict(g.sub.members_of(w))
    assert roles.get("tanaka") == "actor" and "kaz" not in roles                    # named offscreen member: a witness
    assert "kaz" in g.ledger.roster(g.current_scene_id())                           # nobody drags Kaz off screen
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], g.turn_no() + 1)
    assert "only Lone Star, Tanaka know:" in packet or "only Tanaka, Lone Star know:" in packet


def AGENT_SYSTEM_TEXT():
    return world.AGENT_SYSTEM


def test_nobody_starves_and_new_contacts_get_real_names(make_game):
    llm = WorldLLM()
    g = make_game(llm, dice=ScriptedDice([6] * 40))
    setup_demo(g)
    _personas(g)
    g.settings.knobs.world_agents_per_pass = 1
    g.ledger.leave(g.current_scene_id(), ["kaz"])
    world.add_agenda(g, "tanaka", "collect old debts", [], g.turn_no(), by="dm")
    g.conn.execute("INSERT INTO world_actors(npc_id, last_turn, last_time) VALUES('tanaka', 0, 100)")   # waited long
    g.conn.execute("INSERT INTO world_actors(npc_id, last_turn, last_time) VALUES('kaz', 0, ?)", (g.clock(),))
    world.reach_out(g, "joey-two-knives", "kaz", "We need to talk.", [], set(), None, g.turn_no())     # Kaz has mail
    assert [j.npc for j in world.plan(g) if j.kind == "agent"] == ["tanaka"]                        # oldest first

    aid = world.add_agenda(g, "kaz", "find a fence", [], g.turn_no(), by="dm")
    llm.agent["kaz"] = {**NONE, "decision": "continue", "agenda_id": aid, "action": "Kaz called around.",
                        "on_success": "Kaz called around for a fence.",
                        "contacts": [{"who": "old-precinct-partner", "kind": "npc", "says": "Need a favor.",
                                      "shares": [], "description": "Kaz's ex-partner from the Star, now on a desk"}]}
    job = next(j for j in world.plan(g) if j.npc == "kaz") if any(j.npc == "kaz" for j in world.plan(g)) else None
    job = job or world._agent_job(g, g.ledger.get("kaz"), [], [], {"turn": 0, "time": None}, g.turn_no())
    lines = world.apply(g, job, llm.agent["kaz"])
    partner = g.ledger.find("Old Precinct Partner")
    assert partner and partner["description"].startswith("Kaz's ex-partner") and any("someone new" in x for x in lines)
