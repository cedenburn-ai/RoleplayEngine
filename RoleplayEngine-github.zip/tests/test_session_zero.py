"""Starting a game: sectioned help, session zero, !pregen, !begin, and restarts that ask before archiving."""
import asyncio

from roleplay.discord_bot import bot as botmod
from roleplay.discord_bot.session import CampaignTable, help_cards
from roleplay.setup import setup_blank, setup_rage

from .conftest import FakeLLM, text
from .test_chargen import SUGGESTION
from .test_discord import FakeChannel


def test_help_is_sectioned_and_complete():
    cards = help_cards()
    assert [c["title"].split(" ", 1)[1] for c in cards] == ["Slash commands", "Playing", "Your character", "The table",
                                                            "Starting a game", "GM controls (campaign owner / server managers)"]
    everything = "\n".join(c["description"] for c in cards)
    assert all(len(c["description"].splitlines()) >= 4 for c in cards)          # one command per line
    for cmd in ("!go", "!ooc", "!afk", "!askgm", "!newchar", "!pregen", "!join", "!leave", "!yes", "!cs", "!sheet",
                "!advance", "!karma", "!recap", "!map here", "!net", "!who", "!scene", "!time", "!art", "!rulings",
                "!ruling veto", "!rp start", "!begin", "!rp restart", "!rp stop", "!dmplay", "!idle", "!companions",
                "!undo", "!gmmodel", "!gmeffort", "!difficulty", "!timer", "!voices", "!map gm", "!map restyle",
                "!world", "!pov", "!minds", "!merge", "!graph", "!settings", "!cost", "/newchar", "/sheet", "/shop",
                "/whisper", "/askgm", "/join", "/checkout", "/advance"):
        assert cmd in everything, cmd
    assert "street_samurai" in everything                                        # (archetypes filled in)


def test_a_new_world_starts_with_session_zero(make_game):
    llm = FakeLLM([([text("Rain on the window of the Noodle Nook. **Mr. Johnson:** \"I hear you're good.\"")],
                    "end_turn")], extraction=lambda user: SUGGESTION if "concept" in user else {
        "summary": "A Johnson approached the crew.", "recalled": [], "facts": [], "told": [], "new_entities": [],
        "moved_to": {"location": "", "description": "", "who": []}, "members": []})
    g = make_game(llm)
    setup_blank(g, "Downtown Seattle", "rain and neon")

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()

        async def react(e):
            pass
        await t.welcome("noir")
        assert ch.sent[-1]["title"] == "🌆 A new world: noir" and "!pregen" in ch.sent[-1]["description"]
        await t.handle("7", "Jo", "!begin", False, react)
        assert "Nobody has a runner yet" in ch.sent[-1]["text"]
        await t.handle("7", "Jo", "!pregen elf decker with a grudge", False, react)
        assert "rolling up a runner" in ch.sent[-1]["text"]
        review = ch.dms[-1][1][0]
        assert "Review" in review["title"] and "Glitch (they/them) - elf decker" in review["description"]
        await t.whisper("7", "done", FakeChannel())
        assert any("When everyone has a runner: `!begin`" in (m["description"] or "") for m in ch.sent)
        await t.handle("7", "Jo", "!begin a quiet data job", False, react)
        assert any("Here we go: **Glitch**" in (m["text"] or "") for m in ch.sent)
        assert "The players asked for: a quiet data job" in llm.dm_requests[0] and "Glitch (elf decker)" in llm.dm_requests[0]
        assert any("I hear you're good" in (m["description"] or "") for m in ch.sent)
        await t.handle("7", "Jo", "!begin", False, react)
        assert "already going" in ch.sent[-1]["text"]
        await t.close()
    asyncio.run(go())


def test_a_seeded_world_waits_for_its_players(make_game):
    g = make_game(FakeLLM())
    setup_rage(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.welcome("rage")                                     # nobody seated: session zero, no opening yet
        assert ch.sent[-1]["title"] == "🌆 A new world: rage" and "`!join rage` (Rage)" in ch.sent[-1]["description"]
        assert g.ledger.meta("opening")                             # (Dutch's call waits for !begin)
        await t.close()
    asyncio.run(go())


class FakeDiscordChannel:
    def __init__(self, cid):
        self.id, self.sent = cid, []

    async def send(self, content=None, **kw):
        self.sent.append(content if content is not None else kw.get("embed") or kw.get("embeds"))

        class _M:
            id = 555

            async def add_reaction(self, e):
                pass
        return _M()


def test_restart_asks_then_archives(tmp_path, monkeypatch):
    monkeypatch.setattr(botmod, "CAMPAIGN_DIR", tmp_path)
    monkeypatch.setattr(botmod, "BINDINGS", tmp_path / "bindings.json")
    for name in ("noir.db", "noir.db-wal"):
        (tmp_path / name).write_text("x")
    (tmp_path / "noir_art").mkdir()
    (tmp_path / "noir_art" / "kaz.png").write_text("png")

    async def go():
        b = botmod.RPBot()
        ch = FakeDiscordChannel(42)
        b.pending[42] = {"campaign": "noir", "uid": "1", "message_id": "555", "expires": 1e12}
        await b.answer_restart(ch, "2", True)                     # not the asker: ignored
        assert 42 in b.pending and (tmp_path / "noir.db").exists()
        await b.answer_restart(ch, "1", False)
        assert "plays on" in ch.sent[-1] and (tmp_path / "noir.db").exists()
        await b.answer_restart(ch, "1", True)                     # nothing pending any more
        assert "Nothing waiting" in ch.sent[-1]
        where = botmod.archive_campaign("noir")
        assert not (tmp_path / "noir.db").exists() and (tmp_path / where).exists()
        assert (tmp_path / where.replace(".db", "_art") / "kaz.png").exists()        # moved, never deleted
        await b.close()
    asyncio.run(go())


def test_an_unknown_rp_subcommand_says_so_and_changes_nothing(tmp_path, monkeypatch):
    # (2026-10-27: `!rp newparty` on a bot that didn't have it yet answered with the help card alone - it read as if
    #  something had happened)
    monkeypatch.setattr(botmod, "BINDINGS", tmp_path / "bindings.json")
    from types import SimpleNamespace

    async def go():
        b = botmod.RPBot()
        ch = FakeDiscordChannel(42)
        msg = SimpleNamespace(channel=ch, author=SimpleNamespace(id=1, guild_permissions=None))
        await b.rp_command(msg, "!rp newpary 3 weeks")
        assert "`!rp newpary` isn't a command here - did you mean `!rp newparty`?" in ch.sent[-1]
        assert "Nothing was changed" in ch.sent[-1] and not b.pending
        await b.rp_command(msg, "!rp")                            # (plain !rp / !rp help: just the card)
        assert not isinstance(ch.sent[-1], str)
        await b.close()
    asyncio.run(go())


def test_backups_snapshot_live_databases_and_rotate(tmp_path):
    import sqlite3
    import zipfile
    from roleplay import backup
    camp, dest = tmp_path / "campaigns", tmp_path / "backups"
    (camp / "noir_art").mkdir(parents=True)
    (camp / "noir_undo").mkdir()
    (camp / "sheets").mkdir()
    (camp / "noir_art" / "kaz.png").write_bytes(b"png")
    (camp / "noir_undo" / "before_3.db").write_bytes(b"x")
    (camp / "sheets" / "x.png").write_bytes(b"x")
    live = sqlite3.connect(camp / "noir.db")
    live.execute("PRAGMA journal_mode=WAL")
    live.execute("CREATE TABLE t(x)")
    live.execute("INSERT INTO t VALUES (42)")
    live.commit()                                         # still open: the row may only be in the WAL
    z = backup.run(camp, dest, keep=2)
    names = zipfile.ZipFile(z).namelist()
    assert "noir.db" in names and "noir_art/kaz.png" in names
    assert not any("undo" in n or n.startswith("sheets") or n.endswith("-wal") for n in names)
    zipfile.ZipFile(z).extract("noir.db", tmp_path / "restore")
    assert sqlite3.connect(tmp_path / "restore" / "noir.db").execute("SELECT x FROM t").fetchone() == (42,)
    live.close()
    import time
    for _ in range(3):
        time.sleep(1.1)
        backup.run(camp, dest, keep=2)
    assert len(list(dest.glob("campaigns-*.zip"))) == 2 and not backup.due(dest)
