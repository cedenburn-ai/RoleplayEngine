"""The graph browser: one server, any campaign in the folder, defaulting to the one live in Discord."""
import json
import re
import shutil
import subprocess
import urllib.error
import urllib.request
from pathlib import Path

import pytest

from roleplay.browser.server import Api, campaigns, live_campaign, serve
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import magic, sr_lite
from roleplay.game import Game
from roleplay.setup import setup_demo, setup_rage

INDEX = Path(__file__).resolve().parents[1] / "roleplay" / "browser" / "static" / "index.html"


def test_the_rolls_list_says_what_was_rolled(make_game):
    """Live review: a cast's tests row has no skill, and the turn's Rolls list printed it 'sable : 3 hits' - no spell,
    no Force, no target - so the T164-T175 drain record couldn't be read on the one page that shows it. The page's own
    rollLabel names each kind of row, fed the rows the engine really writes (node runs it; skipped without node)."""
    html = INDEX.read_text(encoding="utf-8")
    assert "${esc(rollLabel(s))}" in html                                  # (the Rolls list uses it)
    fn = re.search(r"^function rollLabel\(s\) \{.*?^\}", html, re.S | re.M).group(0)
    node = shutil.which("node")
    if not node:
        pytest.skip("node isn't installed")
    g = make_game()
    setup_demo(g)
    L = g.ledger
    sable = g.create_pc("Sable", "mage", "sable", "elf hermetic mage", 1)
    magic.cast(L, ScriptedDice([6] * 3), 1, sable, "Manabolt", 6, [{"id": "kaz"}], "drop the ganger")
    sr_lite.request_test(L, ScriptedDice([6] * 2), 1, "kaz", None, threshold=2, attributes=["logic", "willpower"])
    sr_lite.request_test(L, ScriptedDice([6] * 2), 1, "razor", "perception", threshold=2)
    specs = [json.loads(r["spec"]) for r in g.conn.execute("SELECT spec FROM tests ORDER BY rowid")]
    specs += [{"kind": "attack", "target": "kaz"}, {"kind": "ram", "target": "kaz", "kph": 50}]
    out = subprocess.run([node, "-e", fn + f"\nconsole.log(JSON.stringify({json.dumps(specs)}.map(rollLabel)))"],
                         capture_output=True, text=True, encoding="utf-8", timeout=30, check=True)
    assert json.loads(out.stdout) == ["cast manabolt F6 → kaz", "logic + willpower", "perception", "attack → kaz",
                                      "ram → kaz at 50 km/h"]


def test_campaign_picker(tmp_path):
    for name, seed in (("demo", setup_demo), ("rage", setup_rage)):
        g = Game(tmp_path / f"{name}.db")
        seed(g)
        g.close()
    assert live_campaign(tmp_path) == "demo"                               # nothing bound: the fallback
    (tmp_path / "discord_bindings.json").write_text(json.dumps({"123": {"campaign": "rage", "owner": "1"}}))
    assert live_campaign(tmp_path) == "rage" and {c["name"]: c["live"] for c in campaigns(tmp_path)} == \
        {"demo": False, "rage": True}

    server = serve(tmp_path / "demo.db", port=0, background=True)
    base = f"http://127.0.0.1:{server.server_port}"

    def get(path):
        with urllib.request.urlopen(base + path, timeout=5) as r:
            return json.loads(r.read())
    try:
        assert get("/api/campaigns")["current"] == "demo"
        assert get("/api/graph")["campaign"] == "demo"
        assert get("/api/graph?c=rage")["campaign"] == "rage"
        assert any(n["label"] == "Dutch" for n in get("/api/graph?c=rage")["nodes"])
        with pytest.raises(urllib.error.HTTPError):
            get("/api/graph?c=../secrets")
    finally:
        server.shutdown()
    assert Api(tmp_path / "rage.db").graph()["campaign"] == "rage"
