"""!charactersheet: the player's own character as cards, with the portrait, by DM."""
import asyncio

from PIL import Image

from roleplay import charsheet
from roleplay.engine.rules import sr_lite
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel


def test_cards_show_what_a_roll_would_use(make_game, tmp_path):
    g = make_game()
    setup_demo(g)
    g.ledger.set_stat("razor", "physical_damage", 3)
    cards = charsheet.cards(g, "razor")
    first, skills, gear, growth = cards
    assert first["title"] == "🎲 Razor" and first["image"] is None and "No portrait yet" in first["description"]
    fields = {f["name"]: f["value"] for f in first["fields"]}
    assert "**AGI** 6" in fields["Attributes"] and "**ESS** 2.6" in fields["Attributes"]
    assert "▰▰▰▱▱▱▱▱▱▱▱ 3/11" in fields["Condition"] and "−1** to every pool" in fields["Condition"]
    assert "**Edge** 3/3" in fields["Resources"] and "¥3,000" in fields["Resources"]
    assert "Firearms      6 + AGI 6 = 11 dice  (Wounds -1)" in skills["description"]   # = build_pool, not a guess
    assert "Ares Predator V** · DV 5P AP -1 · 15/15 rounds" in gear["description"]
    assert gear["footer"].endswith("The Lucky Shot (Redmond Barrens)")
    assert growth["title"] == "Advancement" and "**Karma: 0**" in growth["description"]
    assert "19  Firearms      6 → 7   21\n" in growth["description"]
    assert " 2  AGI           6 → -  max" in growth["description"]
    assert "21 Hacking" in growth["description"] and "Sorcery" not in growth["description"]    # mundane: no magic
    assert "NOTE" not in charsheet.text(cards) and "N1" not in charsheet.text(cards)          # never the GM's notes

    p = tmp_path / "razor.png"
    Image.new("RGB", (64, 64), (20, 20, 20)).save(p)
    g.conn.execute("INSERT INTO art(entity_id, version, path, status) VALUES('razor', 1, ?, 'ready')", (str(p),))
    assert charsheet.cards(g, "razor")[0]["image"] == str(p)


def test_spending_and_earning_karma(make_game):
    import pytest
    from roleplay.engine.ledger import LedgerError
    from roleplay.engine.rules import sr_lite
    g = make_game()
    setup_demo(g)
    L = g.ledger
    with pytest.raises(LedgerError, match="costs 21 karma; Razor has 0"):
        sr_lite.advance(L, 1, "razor", "19")
    assert sr_lite.award_karma(L, 1, "razor", 20, "the bridge job") == "[KARMA] Razor +20 karma - the bridge job (now 20)"
    sr_lite.award_karma(L, 1, "razor", 10)
    res = sr_lite.advance(L, 1, "razor", "19")                     # Firearms 6 -> 7: x3, a group-sized skill
    assert res["card"] == "[KARMA] Razor raises Firearms to 7 (21 karma, 9 left)" and L.stat("razor", "firearms") == 7
    assert sr_lite.advance_cost(L, "razor", "perception")[1] == (int(L.stat("razor", "perception")) + 1) * 2
    assert sr_lite.advance(L, 1, "razor", "con")["rating"] == 1                   # learn a skill: 2 karma
    with pytest.raises(LedgerError, match="natural maximum"):
        sr_lite.advance(L, 1, "razor", "AGI")
    with pytest.raises(LedgerError, match="needs Magic"):
        sr_lite.advance(L, 1, "razor", "sorcery")
    with pytest.raises(LedgerError, match="Only player characters"):
        sr_lite.advance(L, 1, "kaz", "5")
    assert sr_lite.advancement_refs()[19] == "firearms"                           # numbers never shift


def test_the_gm_awards_karma_in_the_dm_block(make_game):
    extraction = {"summary": "The job wrapped.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": [],
                               "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
                  "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 2}
    g = make_game(FakeLLM([([text("Clean getaway.\n<dm>\nkarma razor, ghost: +3 got the chip out clean\n</dm>")],
                            "end_turn")], extraction))
    setup_demo(g)
    res = g.run_turn([("razor", "Drive.")])
    assert res.narration == "Clean getaway."
    assert "[KARMA] Razor +3 karma - got the chip out clean (now 3)" in res.cards
    assert g.ledger.stat("ghost", "karma") == 3


def test_charactersheet_is_dmed_to_the_player(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})

        async def react(e):
            pass
        await t.handle("2", "Bob", "!cs", False, react)
        assert "not playing anyone" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!join ghost", False, react)
        await t.handle("2", "Bob", "!charactersheet razor", False, react)        # not the owner: your own sheet
        uid, cards = ch.dms[-1]
        assert uid == "2" and cards[0]["title"] == "🎲 Ghost" and cards[1]["title"] == "Kit, gifts & karma"
        assert all(Image.open(c["image"]).width == 1600 for c in cards)        # two rendered pages
        await t.handle("1", "Owner", "!charactersheet kaz", True, react)          # the owner may look at anyone
        assert ch.dms[-1][1][0]["title"] == "🎭 Kaz"
        await t.close()
    asyncio.run(go())


def test_discord_renders_fields(tmp_path):
    from roleplay.discord_bot.bot import DiscordChannel

    class Sink:
        def __init__(self):
            self.messages = []

        async def send(self, content=None, **kw):
            self.messages.append(kw)
    sink = Sink()
    asyncio.run(DiscordChannel._send_cards(sink, [{"title": "x", "fields": [
        {"name": "Attributes", "value": "**AGI** 6", "inline": False}]}]))
    e = sink.messages[0]["embeds"][0]
    assert e.fields[0].name == "Attributes" and e.fields[0].value == "**AGI** 6"


def test_the_sheet_pages_render_for_every_kind_of_runner(make_game, tmp_path):
    from roleplay import chargen as C, sheetart
    g = make_game()
    setup_demo(g)
    eids = ["razor", "ghost", "kaz"]                                     # samurai, decker (+ drone), an NPC
    for role, meta in (("mage", "elf"), ("technomancer", "dwarf"), ("rigger", "troll")):
        d = C.new_draft(role, meta)
        d.update(name=f"T{role[:4]}", pronouns="they/them", look="A runner.")
        eids.append(C.build(g, d, f"t{role}", 1))
    g.ledger.set_stat("razor", "physical_damage", 5)
    for eid in eids:
        p1, p2 = sheetart.render(g, eid, tmp_path)
        assert Image.open(p1).width == Image.open(p2).width == sheetart.W


def test_every_sheet_shows_the_drain_code(make_game):
    """Flags #62/#63: 'Stunbolt 3' / 'Physical Barrier (drain 5)' read as the modifier, and the note said drain turns
    physical above Force 6. Every surface now shows the book's code, what it costs at full Magic, and the hits rule."""
    import re
    from roleplay import sheetart
    from roleplay.engine.rules import magic, resonance
    g = make_game()
    setup_demo(g)
    L = g.ledger
    sable = g.create_pc("Sable", "mage", "sable", "elf hermetic mage", 1)
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": magic.known(L, sable) + ["mind probe"]})
    card = charsheet.magic_card(g, sable, 0)["description"]
    assert "Spells (drain: F = the Force you cast at, never under 2): " in card
    assert "Stunbolt F-3 (3 at Force 6)" in card and "Stunbolt 3 " not in card
    assert re.search(r"Mind Probe F(?![+\-\d]) \(6 at Force 6\)", card)
    assert "hits beat your Magic (6)" in card and "turns physical" not in card
    text = sr_lite.sheet(L, sable)                                       # !sheet text, !askdm, the GM's packet
    assert "Spells (drain: F = the Force cast at, never under 2; at Force 6 in brackets): " in text
    assert "Stunbolt F-3 (3)" in text and "drain resist 10 dice (Willpower + Logic)" in text
    assert "Spells" not in sr_lite.sheet(L, "razor")                     # mundane: no line
    assert "Learn a spell** (5 karma" in charsheet.advancement_card(g, sable, 0)["description"]
    assert "Powerbolt F-3" in charsheet.advancement_card(g, sable, 0)["description"]

    tm = g.create_pc("Static", "technomancer", "static", "ork technomancer", 1)
    assert "Puppeteer L+2 (8)" in sr_lite.sheet(L, tm) and "Cleaner L+0 (6)" in sr_lite.sheet(L, tm)
    rcard = charsheet.resonance_card(g, tm, 0)["description"]
    assert "Puppeteer L+2 (8 at Level 6)" in rcard and "hits beat your Resonance (6)" in rcard
    assert "Learn a complex form** (4 karma" in charsheet.advancement_card(g, tm, 0)["description"]

    for eid, panel in ((sable, sheetart.magic_panel(L, sable, L.stats(sable))),     # the picture: it has to fit
                       (tm, sheetart.resonance_panel(L, L.get(tm), L.stats(tm)))):
        items = next(p for k, p in panel if k == "list")
        assert all(sheetart.font(20).getlength(i) <= sheetart.LIST_W for i in items)
        assert all(sheetart.font(18).getlength(p) <= sheetart.NOTE_W for k, p in panel if k == "note")
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": []})              # no list: every spell, and
    items = next(p for k, p in sheetart.magic_panel(L, sable, L.stats(sable)) if k == "list")    # all of them fit
    assert "Physical Barrier  F-1 (5)" in items and len(items) == len(magic.SPELLS)
    assert all(sheetart.font(20).getlength(i) <= sheetart.LIST_W for i in items)


def test_karma_respects_the_metatype(make_game):
    from roleplay import chargen as C
    g = make_game()
    setup_demo(g)
    d = C.new_draft("street_samurai", "ork")
    d.update(name="Grit", pronouns="he/him", look="An ork.")
    eid = C.build(g, d, "grit", 1)
    g.ledger.set_stat(eid, "body", 6)
    assert sr_lite.advance_cost(g.ledger, eid, "body") == (7, 35, None)  # an ork's Body goes to 9
    g.ledger.set_stat(eid, "logic", 5)
    assert "natural maximum (5)" in sr_lite.advance_cost(g.ledger, eid, "logic")[2]


def test_sheet_means_the_picture_sheet_like_the_slash_command():
    """`/sheet` sent pictures and `!sheet` sent text - one name, two answers, and the table thought it broke."""
    from roleplay.discord_bot.session import _sheet_kind
    assert _sheet_kind("sheet", "") == ("charactersheet", "")
    assert _sheet_kind("sheet", "Sable") == ("charactersheet", "Sable")       # (the owner looking at someone)
    assert _sheet_kind("sheet", "text") == ("textsheet", "")
    assert _sheet_kind("sheet", "TEXT sable") == ("textsheet", "sable")
    assert _sheet_kind("shop", "x") == ("shop", "x")
