import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["ROLEPLAY_TILES"] = "off"          # (no map tiles from the internet in tests: the traced shores)

from roleplay.art import ArtDirector, NullArtProvider  # noqa: E402
from roleplay.game import Game  # noqa: E402


class FakeLLM:
    """Scripted stand-in for the Anthropic wrapper: no network, no spend. consult_script scripts the research loops
    out of the story (the aside, !askdm): (blocks, stop_reason) per step, like dm_script."""

    def __init__(self, dm_script=None, extraction=None, consult_script=None):
        self.dm_script = list(dm_script or [])
        self.extraction = extraction
        self.consult_script = list(consult_script or [])
        self.usage = SimpleNamespace(total=0.0, calls=0, by_model={})
        self.dm_requests = []
        self.consults = []

    def dm_step(self, system, tools, messages, progress=None):
        self.dm_requests.append(messages[0]["content"])
        blocks, stop = self.dm_script.pop(0) if self.dm_script else ([text("The rain keeps falling.")], "end_turn")
        return SimpleNamespace(content=blocks, stop_reason=stop, usage=None, model="fake")

    def consult(self, model, system, messages, tools=None, schema=None, **kw):
        """One research-loop step: the next scripted reply - else the plain answer, structured() with a schema and
        text() without, so a test that scripts no lookups sees the one call it always did."""
        self.consults.append({"model": model, "system": system, "messages": list(messages),
                              "tools": [t["name"] for t in tools or []], "schema": schema, **kw})
        if self.consult_script:
            blocks, stop = self.consult_script.pop(0)
            return SimpleNamespace(content=blocks, stop_reason=stop, usage=None, model="fake")
        user = messages[0]["content"]
        reply = (json.dumps(self.structured(model, system, user, schema, **kw)) if schema
                 else self.text(model, system, user, **kw))
        return SimpleNamespace(content=[text(reply)], stop_reason="end_turn", usage=None, model="fake")

    def structured(self, model, system, user, schema, **kw):
        if self.extraction is None:
            raise RuntimeError("no scripted extraction")
        return self.extraction(user) if callable(self.extraction) else self.extraction

    def text(self, model, system, user, **kw):
        return "scene summary"


def text(s):
    return SimpleNamespace(type="text", text=s)


def tool(name, **inp):
    tool.n = getattr(tool, "n", 0) + 1
    return SimpleNamespace(type="tool_use", name=name, input=inp, id=f"tu_{tool.n}")


@pytest.fixture
def make_game(tmp_path):
    games = []

    def _make(llm=None, dice=None):
        art = ArtDirector(tmp_path / "art", "test", provider=NullArtProvider(), out=lambda s: None)
        g = Game(tmp_path / f"c{len(games)}.db", llm=llm or FakeLLM(), dice=dice, art=art, out=lambda s: None)
        games.append(g)
        return g

    yield _make
    for g in games:
        g.close()
