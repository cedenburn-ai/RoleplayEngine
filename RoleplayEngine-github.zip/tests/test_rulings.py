"""Table rulings: a short, capped list of house rules in the GM's context; the table can veto any."""
import asyncio

import pytest

from roleplay import rulings
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.ledger import LedgerError
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text
from .test_discord import FakeChannel


def test_add_revise_cap_and_the_packet(make_game):
    g = make_game()
    setup_demo(g)
    r1 = rulings.add(g, "Grenades down a stairwell count as near for the next landing.", "owner")
    assert r1["id"] == "R1"
    r2 = rulings.add(g, "Grenades down a stairwell count as close for the next landing.", "gm", replaces="R1")
    assert r2["replaces"] == "R1" and rulings.get(g, "R1")["status"] == "replaced"   # the old text stays on record
    assert [r["id"] for r in rulings.active(g)] == ["R2"]
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hm")], 9)
    assert "=== TABLE RULINGS" in packet and "[R2] Grenades down a stairwell count as close" in packet
    for i in range(rulings.MAX - 1):
        rulings.add(g, f"house rule {i}", "owner")
    with pytest.raises(LedgerError, match="revise or drop one"):
        rulings.add(g, "one too many", "owner")
    long = rulings.add(g, "x " * 400, "gm", replaces="R3")
    assert len(long["text"]) <= rulings.MAX_CHARS


def test_the_gm_records_a_ruling_and_the_table_hears_it(make_game):
    extraction = {"summary": "Razor asked about stairs.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": [],
                               "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
                  "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 1}
    g = make_game(FakeLLM([([text("It bounces down.\n<dm>\nruling: Thrown grenades down stairs land one band "
                                  "further than aimed.\n</dm>")], "end_turn")], extraction))
    setup_demo(g)
    res = g.run_turn([("razor", "I bounce it down the stairs.")])
    assert res.narration == "It bounces down."
    assert any(c.startswith("[RULING] R1: Thrown grenades down stairs") and "!ruling veto R1" in c for c in res.cards)
    assert rulings.active(g)[0]["by"] == "gm"


def test_askdm_and_the_table_commands(make_game):
    class Echo(FakeLLM):
        def text(self, model, system, user, **kw):
            self.asked = user
            return "ok"
    g = make_game(Echo())
    setup_demo(g)
    rulings.add(g, "Edge can't be spent on drone rolls.", "owner")
    g.askdm("razor", "can I push my drone's attack?")
    assert "TABLE RULINGS" in g.llm.asked and "[R1] Edge can't be spent on drone rolls." in g.llm.asked

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!ruling add Ammo is tracked per magazine, not per bullet.", False, react)
        assert ch.sent[-1]["text"].startswith("📜 **R2** Ammo is tracked")
        await t.handle("2", "Bob", "!ruling edit R2 something", False, react)
        assert "for the campaign owner" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!ruling veto R1", False, react)
        assert "vetoed by <@2>" in ch.sent[-1]["text"] and rulings.get(g, "R1")["status"] == "vetoed"
        await t.handle("1", "Owner", "!ruling edit R2 Ammo is tracked per shot.", True, react)
        assert "(revises R2)" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!rules", False, react)
        assert ch.sent[-1]["title"] == "📜 Table rulings" and "R3" in ch.sent[-1]["description"]
        await t.close()
    asyncio.run(go())


def test_ids_are_forgiving_and_errors_say_what_exists(make_game):
    g = make_game()
    setup_demo(g)
    rulings.add(g, "Edge resets when we rest.", "owner")
    assert [rulings.norm_id(x) for x in ("R1", "r1", "1", "#1", "R#1", "R1:")] == ["R1"] * 6
    r = rulings.add(g, "Edge resets after a fight or a finished run.", "owner", "1")    # "3", not just "R3"
    assert r["id"] == "R2" and r["replaces"] == "R1"
    with pytest.raises(LedgerError, match="R1 was already revised - it's R2 now"):
        rulings.add(g, "again", "owner", "1")
    with pytest.raises(LedgerError, match="No active ruling R7 to revise - the table has R2"):
        rulings.add(g, "nope", "owner", "7")


def test_the_table_isnt_kept_waiting_by_the_gms_turn(make_game):
    """A turn holds the game thread for a minute or more: !ruling and !rulings answer anyway, and any other command
    that has to wait says it was heard (⏳) - then takes the ⏳ back."""
    import threading
    import time as _time
    g = make_game()
    setup_demo(g)
    rulings.add(g, "Edge resets when we rest.", "owner")

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        reacts, unreacts = [], []

        async def react(e):
            reacts.append(e)

        async def unreact(e):
            unreacts.append(e)
        gate = threading.Event()
        busy = t.loop.run_in_executor(t.pool, gate.wait, 30)     # the GM, mid-turn, on the game thread
        t.director.resolving = True
        t0 = _time.time()
        await t.handle("1", "Owner", "!ruling edit 1 Edge resets after a fight or a finished run.", True, react, unreact)
        assert _time.time() - t0 < 1.0
        assert "(revises R1)" in ch.sent[-1]["text"] and "mid-turn" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!rulings", False, react, unreact)
        assert "**R2** Edge resets after a fight" in ch.sent[-1]["description"] and _time.time() - t0 < 2.0
        assert reacts == []                                    # (nothing had to wait)

        slow = asyncio.ensure_future(t.handle("2", "Bob", "!time", False, react, unreact))
        await asyncio.sleep(1.8)
        assert reacts == ["⏳"] and not slow.done()            # heard, and waiting on the GM
        gate.set()
        await busy
        t.director.resolving = False
        await slow
        assert unreacts == ["⏳"] and ch.sent[-1]["text"].startswith("🕒")
        await t.close()
    asyncio.run(go())


def test_a_ruling_request_goes_to_the_gm_and_comes_back_as_its_own_line(make_game):
    extraction = {"summary": "Razor asked for Edge back.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": [],
                               "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
                  "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 1}
    g = make_game()
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()
        reacts = []

        async def react(e):
            reacts.append(e)
        await t.handle("3", "Nobody", "!ruling can we get Edge back?", False, react)
        assert "`!join` first" in ch.sent[-1]["text"] and t.director.queue == []
        await t.handle("2", "Bob", "!join razor", False, react)
        await t.handle("2", "Bob", "!ruling for a one time rule of cool reset our edge", False, react)
        assert ch.sent[-1]["text"].startswith("📜 Asked the GM") and reacts[-1] == "📝"
        assert t.director.queue == [("razor", "[RULING REQUEST - out of character, to the GM] for a one time rule "
                                              "of cool reset our edge")]
        await t.close()
    asyncio.run(go())
    g = make_game(FakeLLM([([text("Razor rolls his shoulders.\n<dm>\nruled: Granted, once - Edge back to full.\n"
                                  "</dm>")], "end_turn")], extraction))      # (the table closed its game)
    setup_demo(g)
    res = g.run_turn([("razor", "[RULING REQUEST - out of character, to the GM] reset our edge")])
    assert res.narration == "Razor rolls his shoulders." and "[GM RULING] Granted, once - Edge back to full." in res.cards


def test_undo_keeps_the_tables_rulings_and_takes_back_the_gms(make_game):
    g = make_game()
    setup_demo(g)
    rulings.add(g, "Edge resets when we rest.", "owner")                    # R1, before the turn
    g.snapshot(g.turn_no() + 1)
    rulings.add(g, "Edge resets after a fight.", "owner", "R1")             # R2: the owner, mid-turn
    rulings.add(g, "Grenades bounce one band further.", "gm")               # R3: the GM, in the turn
    rulings.retire(g, "R3", "vetoed", "2")                                  # ...vetoed by a player: that stays
    rulings.add(g, "Smartlinks don't stack with laser sights.", "gm")       # R4: the GM's, untouched - undone
    g.undo()
    rows = {r["id"]: r for r in g.conn.execute("SELECT * FROM rulings")}
    assert rows["R1"]["status"] == "replaced" and rows["R2"]["status"] == "active"
    assert rows["R3"]["status"] == "vetoed" and "R4" not in rows
    assert rulings.add(g, "next", "owner")["id"] == "R5"                    # an undone R# isn't handed out again


def test_a_gm_revision_of_a_table_rule_undoes_cleanly(make_game):
    g = make_game()
    setup_demo(g)
    rulings.add(g, "Edge resets when we rest.", "owner")                    # R1
    g.snapshot(g.turn_no() + 1)
    rulings.add(g, "Edge resets when we sleep.", "gm", "R1")                # R2: the GM revises the table's rule
    g.undo()
    assert [r["id"] for r in rulings.active(g)] == ["R1"]


def test_edge_comes_back_to_full_when_the_gm_says(make_game):
    from roleplay.engine.rules import sr_lite
    g = make_game()
    setup_demo(g)
    L = g.ledger
    pcs = [p["id"] for p in L.entities(kind="pc") if int(L.stat(p["id"], "edge", 0))]
    for pid in pcs:
        L.set_stat(pid, "edge_points", 0)
    card = sr_lite.refresh_edge(L, 1, "all", "out of the fight (R4)")["card"]
    assert card.startswith("[EDGE] Edge back to full:") and "R4" in card
    assert all(int(L.stat(p, "edge_points")) == int(L.stat(p, "edge")) for p in pcs)
    assert "(already full)" in sr_lite.refresh_edge(L, 1, pcs[0])["card"]


def test_the_gm_drops_a_ruling_it_no_longer_needs(make_game):
    """Without a way to drop one, a GM overwrote stale rulings with 'Retired.' - two of the fifteen slots, wasted."""
    extraction = {"summary": "The table moved on.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": [],
                               "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
                  "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 0}
    g = make_game(FakeLLM([([text("Fine.\n<dm>\nruling R1: drop\n</dm>")], "end_turn")], extraction))
    setup_demo(g)
    rulings.add(g, "Posts from the quiet-lou account are Magic acting.", "gm")
    res = g.run_turn([("razor", "We're sorted now.")])
    assert "[RULING] R1 dropped - it's no longer needed" in res.cards
    assert rulings.active(g) == [] and rulings.get(g, "R1")["status"] == "dropped"
