"""The Matrix at the table (2026-10-27): its rolls on the record (flag #25), the !difficulty dial reaching the hosts
(flags #27/#28, the owner's call), IC dressed in the host's sculpting (flag #35), and the host a player names is the one
their decker goes after (flag #36)."""
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from roleplay import flags
from roleplay.dm import aside, research
from roleplay.dm.prompts import ASKDM_SYSTEM, DM_SYSTEM
from roleplay.dm.tools import TurnContext, dispatch, matrix_target
from roleplay.dm.turn import _user_message, matrix_asks
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import matrix, resonance, sr_lite
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool

COMMIT = {"summary": "Ghost went into the Matrix.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "ghost", "role": "actor"}]}
STUDIO = ("Small Tacoma ad agency's host, sculpted as a 1920s ocean liner's ballroom at midnight: brass rails, a "
          "dance band that never tires, a cabin door per datastore, and IC dressed as night porters with brass keys.")
ARCADE = ("Facilities contractor host running the atrium's dome camera, stairwell cams, front-desk audio pickup and "
          "HVAC across the Larkspur's tower. Sculpted as a damp boiler room under one bare bulb: hissing valves, work "
          "orders, a sleepy bellhop patrol IC pushing a luggage cart, camera feeds as fogged portholes")
LARKSPUR = ("The Larkspur's host, sculpted as a quiet greenhouse of white iron and fogged glass; gardener IC in green "
            "aprons, the guest list as seed packets on a potting bench.")


class LoopLLM(FakeLLM):
    """Records every message list the GM's loop sends (what the engine handed back)."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.calls = []

    def dm_step(self, system, tools, messages, progress=None):
        self.calls.append(list(messages))
        return super().dm_step(system, tools, messages, progress)


def _results(llm) -> list[str]:
    return [b["content"] for m in llm.calls[-1] if m["role"] == "user" and isinstance(m["content"], list)
            for b in m["content"] if isinstance(b, dict) and b.get("type") == "tool_result"]


def _host(g, name="Mothlight Trideo Productions host", desc=STUDIO, rating=4, turn=1):
    return g.introduce("host", name, desc, rating=rating, turn=turn)[0]


def _n(L, skill, attribute=None):
    return sr_lite.build_pool(L, "ghost", skill, attribute)[0]


def _rows(g, turn=None):
    sql = "SELECT * FROM tests" + (" WHERE turn_id=?" if turn is not None else "") + " ORDER BY id"
    return [dict(r) | {"spec": json.loads(r["spec"])} for r in g.conn.execute(sql, () if turn is None else (turn,))]


# ── flag #25: Matrix rolls on the record ────────────────────────────────

def test_every_matrix_roll_is_a_tests_row_with_the_hosts_dice(make_game):
    """Flag #25 (T106): Magic's player asked to see the KD-4 host's roll against the T105 crack (7 hits, Edge spent),
    and nothing on file kept it - the card was the only place the host's dice ever were."""
    n = 14                                                  # Logic 6 + Hacking 6 + Ghost's Cyberdeck 2
    g = make_game(dice=ScriptedDice([5] * 3 + [2] * (n - 3)          # the crack: 3 hits...
                                    + [6, 5, 5, 1]                   # ...vs Hub A's 4 dice: 3 - the defender's
                                    + [6] * (n - 3)                  # Second Chance: the 11 misses come up hits
                                    + [2] * 9))                      # (the search after: nothing)
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 5, "ghost", "jack_in", hid)
    res = matrix.act(L, g.dice, 5, "ghost", "hack", edge="reroll", reason="crack the backlot gate")
    assert "SUCCESS: cracks Hub A" in res["card"] and "vs     Hub A (green, rating 2) doubled = 4d6 -> 6 5 5 1" in res["card"]
    row = _rows(g, 5)[-1]
    spec = row["spec"]
    assert spec["kind"] == "matrix" and spec["action"] == "hack" and spec["host"] == hid and spec["node"] == "Hub A"
    assert spec["skill"] == "hacking" and spec["pool"] == "Logic 6 + Hacking 6 + Ghost's Cyberdeck 2 = 14d6"
    assert spec["vs"] == "Hub A (green, rating 2) doubled 4" and spec["vs_pool"] == 4
    assert sorted(spec["vs_dice"], reverse=True) == [6, 5, 5, 1] and spec["vs_hits"] == 3
    assert spec["edge"].startswith("second chance: 11 misses rerolled") and spec["reason"] == "crack the backlot gate"
    assert row["hits"] == 14 and row["success"] == 1 and row["net"] == 11
    matrix.act(L, g.dice, 5, "ghost", "search")
    s = _rows(g, 5)[-1]["spec"]
    assert s["action"] == "search" and s["threshold"] == 2 and "vs" not in s      # (unopposed: the threshold instead)

    line = research.roll_line(L, dict(row, spec=json.dumps(spec)))
    assert line.startswith("  - Ghost: Matrix hack (Hacking) in Mothlight Trideo Productions host at Hub A: Logic 6")
    assert "vs Hub A (green, rating 2) doubled 4 = 4d6 -> 6 5 5 1 -> 3 hits -> success (net +11)" in line
    assert "Edge: second chance: 11 misses rerolled" in line and line.endswith("- crack the backlot gate")


def test_an_ic_attack_is_on_the_record_from_the_deckers_side(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 5 + [5] + [2] * 8))   # Track IC: 3 hits vs Ghost's 1
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    matrix.act(L, g.dice, 2, "ghost", "jack_in", hid)
    matrix._ic_attack(L, g.dice, 2, "ghost", {"type": "track", "rating": 4, "damage": 0, "active": True, "node": "n2"},
                      {})
    row = _rows(g, 2)[-1]
    s = row["spec"]
    assert s["action"] == "defend" and s["ic"] == "track" and s["node"] == "Hub A" and s["vs"] == "Track IC (4) attack 8"
    assert s["pool"].startswith("Intuition ") and " + Firewall " in s["pool"] and s["vs_hits"] == 3
    assert row["hits"] == 1 and not row["success"] and row["net"] == -2
    assert "defends against Track IC in Mothlight Trideo Productions host at Hub A" in research.roll_line(
        L, dict(row, spec=json.dumps(s)))


def test_the_browser_names_a_matrix_roll(make_game):
    """The graph browser's Rolls list (rollLabel) reads the engine's own Matrix row: the beat, where, and the host's
    dice (node runs the page's function; skipped without node)."""
    html = (Path(__file__).resolve().parents[1] / "roleplay" / "browser" / "static" / "index.html").read_text(
        encoding="utf-8")
    fn = re.search(r"^function rollLabel\(s\) \{.*?^\}", html, re.S | re.M).group(0)
    node = shutil.which("node")
    if not node:
        pytest.skip("node isn't installed")
    g = make_game(dice=ScriptedDice([5] * 3 + [2] * 11 + [6, 5, 5, 1]))
    setup_demo(g)
    hid = _host(g)
    matrix.act(g.ledger, g.dice, 1, "ghost", "jack_in", hid)
    matrix.act(g.ledger, g.dice, 1, "ghost", "hack")
    specs = [r["spec"] for r in _rows(g)]
    out = subprocess.run([node, "-e", fn + f"\nconsole.log(JSON.stringify({json.dumps(specs)}.map(rollLabel)))"],
                         capture_output=True, text=True, encoding="utf-8", timeout=30, check=True)
    assert json.loads(out.stdout) == [f"matrix hack in {hid} @ Hub A vs Hub A (green, rating 2) doubled 4: 6 5 5 1 "
                                      "(3 hits)"]


def test_read_turn_and_the_aside_show_a_past_matrix_roll(make_game):
    """The GM's read_turn and the aside's THE LAST TURNS give the host's dice beside the decker's - what the table
    asked for at T106."""
    llm = FakeLLM([([tool("matrix", decker_id="ghost", action="jack_in", host_id="mothlight-trideo-productions-host"),
                     tool("matrix", decker_id="ghost", action="hack", node="Hub A", reason="the backlot gate")],
                    "tool_use"),
                   ([text("In the Mothlight host, the union guard IC waves Ghost through.")], "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    _host(g, turn=0)
    res = g.run_turn([("ghost", "Ghost jacks into the Mothlight host and hacks the gate.")])
    card = next(c for c in res.cards if "hack" in c.splitlines()[0])
    vs = next(x for x in card.splitlines() if x.startswith("  vs "))
    faces = vs.split(" -> ")[1]                              # the host's dice, as the card showed them
    out = dispatch(TurnContext(g, g.turn_no() + 1, g.current_scene_id()), "read_turn",
                   {"turn_ids": [f"T{res.turn_id}"]})
    line = next(x for x in out.splitlines() if "Matrix hack" in x)
    assert f"vs Hub A (green, rating 2) doubled 4 = 4d6 -> {faces} ->" in line and "the backlot gate" in line
    recent = aside._recent(g)
    assert f"T{res.turn_id} - the rolls:" in recent and f"doubled 4 = 4d6 -> {faces}" in recent
    assert "a Matrix roll's row has the host's (or the IC's) dice" in aside.SYSTEM


# ── flags #27/#28: the difficulty dial reaches the Matrix ───────────────

def test_the_dial_gives_the_host_and_its_ic_their_dice(make_game):
    """The owner, 2026-10-27: "The difficulty dial reaches the Matrix" - one dial for the room and the net. Live T106
    (a player): the Matrix played far harder than the meat world - the dial never touched a host."""
    n = 14
    g = make_game(dice=ScriptedDice([2] * n + [5] * 5                 # the crack fails: Hub A 4 + the table's 1
                                    + [2] * 9 + [2] * 9))             # Killer: 9 dice vs Ghost's 9 - a miss
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    g.set_difficulty(["hard"])
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    res = matrix.act(L, g.dice, 1, "ghost", "hack")
    assert "vs     Hub A (green, rating 2) doubled 4 + Table (hard) 1 = 5d6 -> 5 5 5 5 5 -> 5 hits" in res["card"]
    assert "FAILED: Hub A holds" in res["card"] and _rows(g)[-1]["spec"]["table"] == "hard"
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", {"type": "killer", "rating": 4, "damage": 0, "active": True}, {})
    assert "Killer IC (4) attacks: 8 + Table (hard) 1 = 9d6 -> 0 hits" in lines[0] and lines[0].endswith("misses")
    assert _rows(g)[-1]["spec"]["vs"] == "Killer IC (4) attack 8 + Table (hard) 1"
    assert matrix.dial(L, "kaz") == {"opposition": 0, "threshold": 0, "level": "hard"}     # (an NPC's host: straight)
    assert matrix.against(L, "kaz", "Host 4 doubled", 8) == ([("Host 4 doubled", 8)], 8)
    g.set_difficulty(["story"])
    assert matrix.against(L, "ghost", "Hub A (green, rating 2) doubled", 4)[1] == 2
    assert matrix.vs_text(*matrix.against(L, "ghost", "Hub A doubled", 4)) == "Hub A doubled 4 - Table (story) 2 = 2d6"


def test_the_dial_shifts_matrix_thresholds(make_game):
    g = make_game(dice=ScriptedDice([5] * 2 + [2] * 20))              # a search: 2 hits - short of 3
    setup_demo(g)
    L = g.ledger
    hid = _host(g)
    g.set_difficulty(["hard"])
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    res = matrix.act(L, g.dice, 1, "ghost", "search")
    assert "(needs 3 - table hard +1)" in res["card"] and "Nothing yet" in res["card"]
    assert _rows(g)[-1]["spec"]["threshold"] == 3
    g.set_difficulty(["normal"])
    assert matrix.threshold(L, "ghost", 2) == (2, "")


def test_black_ics_emergency_jack_out_takes_the_dials_shift(make_game):
    g = make_game(dice=ScriptedDice([6] * 13 + [2] * 9 + [2] * 8      # 13 vs 0: 19P, soak 0 - it would drop him
                                    + [6] * 4 + [2] * 6))             # Willpower + Logic: 4 hits, needs 4 + 1
    setup_demo(g)
    L = g.ledger
    hid = _host(g, rating=6)
    g.set_difficulty(["hard"])
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    lines = matrix._ic_attack(L, g.dice, 1, "ghost", {"type": "black ic", "rating": 6, "damage": 0, "active": True}, {})
    assert "the emergency jack-out fails (10d6 -> 4 hits, needs 5 - table hard +1): Ghost takes 19" in lines[0]
    assert any(r["spec"]["action"] == "emergency_jack_out" and r["spec"]["threshold"] == 5 for r in _rows(g))


def test_the_dial_reaches_a_complex_form_against_the_host(make_game):
    g = make_game(dice=ScriptedDice([6] * 3 + [2] * 9 + [2] * 9 + [2] * 11))   # Puppeteer: 3 vs 0; fading unsoaked
    setup_demo(g)
    L = g.ledger
    tm = g.create_pc("Static", "technomancer", "static", "ork technomancer", 1)
    hid = _host(g)
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", present=True, turn=1)
    g.set_difficulty(["hard"])
    matrix.act(L, g.dice, 1, tm, "jack_in", hid)
    res = resonance.thread(L, g.dice, 1, tm, "Puppeteer", 3, dog)
    assert "vs     Host 4 doubled 8 + Table (hard) 1 = 9d6" in res["card"]
    row = _rows(g)[-1]
    assert row["spec"]["action"] == "thread" and row["spec"]["form"] == "Puppeteer" and row["spec"]["vs_pool"] == 9
    assert row["success"] and row["net"] == 3


def test_the_difficulty_text_says_it_covers_the_matrix(make_game):
    g = make_game()
    setup_demo(g)
    g.set_difficulty(["hard"])
    assert "opposition +1 - in the room and the Matrix" in g.settings_line()
    assert any("`!difficulty` dial counts in here too" in x for x in matrix.HELP)
    assert "dial counts in the Matrix as in the room" in ASKDM_SYSTEM
    assert "plus the table difficulty's dice" in DM_SYSTEM
    msg = _user_message(g, "(packet)", [("ghost", "I hack in.")], g.current_scene_id(), 99)
    assert "in the Matrix too: host defense, IC attacks, Matrix thresholds" in msg
    from roleplay.dm import canon
    assert "The !difficulty dial reaches the Matrix" in canon.ENGINE_RULES


# ── flag #35: IC in the host's sculpting ────────────────────────────────

def test_ic_wears_the_hosts_look(make_game):
    """Flag #35 (T116, a player): the IC should look the way the host is sculpted (a guard out of an old black-and-white
    cop show, in a host that loves old films) - the host's description had the look; the map gave its IC as bare
    types."""
    assert matrix.ic_looks(STUDIO) == {"": "IC dressed as night porters with brass keys"}
    assert matrix.ic_looks(ARCADE) == {"patrol": "a sleepy bellhop patrol IC pushing a luggage cart"}
    assert matrix.ic_looks(LARKSPUR) == {"": "gardener IC in green aprons"}
    assert matrix.ic_looks("polished brass; patrol IC appears as paper-crane clerks. IC sculpted as origami cranes") \
        == {"patrol": "patrol IC appears as paper-crane clerks", "": "IC sculpted as origami cranes"}
    assert matrix.ic_looks("a hall of ice sculptures, black lacquer everywhere") == {}        # (ice isn't IC)
    g = make_game()
    setup_demo(g)
    L = g.ledger
    hid = _host(g, "Bellevue Arcade Building Services host", ARCADE, rating=3)
    matrix.act(L, g.dice, 1, "ghost", "jack_in", hid)
    lines = matrix.summary_lines(L, "ghost", 1)
    ic = next(x for x in lines if x.startswith("  Its IC (call it IC"))
    assert "Patrol IC - a sleepy bellhop patrol IC pushing a luggage cart" in ic
    assert "Track IC, Killer IC: no look on file - give it one in the host's sculpting (and note it)" in ic
    assert lines.index(ic) == 2 and lines[1].startswith("  The host looks like:")
    g2 = make_game()
    setup_demo(g2)
    matrix.act(g2.ledger, g2.dice, 1, "ghost", "jack_in", _host(g2))
    ic = next(x for x in matrix.summary_lines(g2.ledger, "ghost", 1) if x.startswith("  Its IC"))
    assert ic.endswith("Patrol IC, Track IC, Killer IC, Tar Baby IC - IC dressed as night porters with brass keys")


def test_the_gm_is_told_to_cut_into_the_matrix_and_call_ic_ic(make_game):
    for words in ("Make the cut into the Matrix explicit", 'Call IC "IC", every time',
                  "somebody here loves old movies", "Show the decker's own icon"):
        assert words in DM_SYSTEM


# ── flag #36: the host a player names is binding ────────────────────────

def _plaza(g):
    """The T120 table's shape: the rating-5 Larkspur host on file, and the arcade's own building-services host
    (rating 3) that runs the cameras."""
    L = g.ledger
    larkspur = _host(g, "Larkspur Room Host", LARKSPUR, rating=5, turn=2)
    plaza = _host(g, "Bellevue Arcade Building Services Host", ARCADE, rating=3, turn=2)
    L.update_entity(plaza, props={**L.get(plaza)["props"], "site": L.current_scene()["location_id"]})
    archive = g.introduce("item", "Arcade camera archive", "thirty days of the atrium's footage", owner_id=plaza,
                          turn=2)[0]
    return larkspur, plaza, archive


def test_the_packet_lists_the_hosts_and_what_each_runs(make_game):
    g = make_game()
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    packet = build_packet(g, g.current_scene_id(), [("razor", "We scope the Larkspur host.")], g.turn_no() + 1)[0]
    head = "=== HOSTS ON FILE (here, or in play lately - the host or device a player names is the one their decker"
    assert head in packet
    rows = packet.split(head)[1].split("\n\n")[0]
    first, second = [x for x in rows.splitlines() if x.startswith(("Larkspur", "Bellevue"))]
    assert first.startswith(f"Bellevue Arcade Building Services Host [{plaza}] - rating 3 (6d6 against a decker; IC: "
                            "Patrol IC, Track IC, Killer IC)") and " · site: here · " in first
    assert "runs Cameras, Door locks, Comms; holds Arcade camera archive" in first
    assert second.startswith(f"Larkspur Room Host [{larkspur}] - rating 5 (10d6 against a decker") and "Black IC" in second
    assert not g.ledger.get(larkspur)["props"].get("nodes")            # (listing a host draws no map: read-only)
    g.ledger.leave(g.current_scene_id(), ["ghost"])                   # no decker in the room: no list
    assert "HOSTS ON FILE" not in build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0]


def test_named_hosts_the_way_people_say_them(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    larkspur, plaza, archive = _plaza(g)
    assert matrix.named_hosts(L, "Ghost goes after the Larkspur host tonight") == [larkspur]
    assert matrix.named_hosts(L, "into Larkspur's host, quietly") == [larkspur]
    assert matrix.named_hosts(L, "Ghost wipes the arcade camera archive") == [plaza]      # (through what it holds)
    assert matrix.named_hosts(L, "the Bellevue Arcade Building Services") == [plaza]
    g.introduce("location", "Larkspur Room", "the wine bar's private dining room", turn=2)
    assert matrix.named_hosts(L, "we walk into the Larkspur Room for dinner") == []          # (that's the place)
    assert matrix_asks(g, [("razor", "I order a rating 4 armor jacket and some noodles.")]) == []
    assert matrix_asks(g, [("razor", "((the Larkspur host is a 5, right?))")]) == []
    (ask,) = matrix_asks(g, [("razor", "Once Ghost picks the rating 3 security cameras as his target, we leave.")])
    assert (ask.who, ask.decker, ask.rating, ask.host) == ("Razor", "ghost", 3, None)      # (Ghost's dive, Razor's word)
    assert "rating 3 security cameras" in ask.words
    (ask,) = matrix_asks(g, [("ghost", "Ghost hacks the Larkspur host. It's rated five.")])
    assert (ask.host, ask.who, ask.decker, ask.avoid) == (larkspur, "Ghost", "ghost", False)


def test_a_jack_in_into_a_host_they_didnt_name_is_sent_back(make_game):
    """Flag #36, live T120: the post named the rating-3 camera system as Filament's target - and the GM dove the
    rating-5 Larkspur host, put right only by !undo. The engine turns that jack-in away once, before any dice."""
    llm = LoopLLM([([tool("matrix", decker_id="ghost", action="jack_in", host_id="larkspur-room-host")], "tool_use"),
                   ([tool("matrix", decker_id="ghost", action="jack_in",
                          host_id="bellevue-arcade-building-services-host")], "tool_use"),
                   ([text("In the arcade's boiler-room host, the bellhop Patrol IC wheels its cart past Ghost.")],
                    "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    res = g.run_turn([("razor", "Ghost picks the rating 3 security cameras as his target, and jacks in from the "
                                "booth.")])
    refused = next(x for x in _results(llm) if x.startswith("Refused:"))
    assert "Razor's post names a rating 3 target" in refused and "rating 3 security cameras" in refused
    assert "goes into Larkspur Room Host (rating 5)" in refused and "introduce that host (kind 'host', rating 3)" in refused
    assert "call it again with despite='<why>' (the table sees it flagged) - a bare re-call is turned away again. " \
           "Nothing was rolled." in refused
    assert matrix.state(g.ledger, "ghost")["host"] == plaza and not g.ledger.get(larkspur)["props"].get("last_seen")
    assert not any("Larkspur" in c.splitlines()[0] for c in res.cards)


def test_the_send_back_is_once_and_a_named_host_settles_it(make_game):
    g = make_game()
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx.matrix_asks = matrix_asks(g, [("ghost", "Ghost jacks into the Bellevue Arcade Building Services Host.")])
    assert matrix_target(ctx) == {"host": plaza, "rating": None, "avoid": [], "who": "Ghost",
                                  "words": ctx.matrix_asks[0].words}                 # (P3's hook)
    assert "jacks into the Bellevue Arcade Building Services Host" in ctx.matrix_asks[0].words
    from roleplay.dm import tools
    block = tool("matrix", decker_id="ghost", action="jack_in", host_id=larkspur)
    first = tools.run_tool(ctx, block)
    assert first.get("is_error") and "Ghost's post goes after Bellevue Arcade Building Services Host" in first["content"]
    assert f"jack_in to Bellevue Arcade Building Services Host [{plaza}]. If" in first["content"]
    assert not matrix.state(g.ledger, "ghost").get("host")
    again = tools.run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_in", host_id=larkspur))
    assert again.get("is_error") and "a bare re-call is turned away again" in again["content"]   # (review of #36)
    again = tools.run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_in", host_id=larkspur))
    assert not again.get("is_error") and matrix.state(g.ledger, "ghost")["host"] == larkspur   # (the third: flagged)
    assert "matrix target overridden" in {f["kind"] for f in flags.listing(g.path.parent)}
    ctx2 = TurnContext(g, g.turn_no() + 1, g.current_scene_id())                # a beat mid-run, on another host
    ctx2.matrix_asks = ctx.matrix_asks
    beat = tools.run_tool(ctx2, tool("matrix", decker_id="ghost", action="search"))
    assert beat.get("is_error") and "This search goes into Larkspur Room Host" in beat["content"]
    assert "(that leaves this one)" in beat["content"]
    ctx3 = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx3.matrix_asks = matrix_asks(g, [("ghost", "Ghost hacks the cameras - a rating 3 system.")])
    assert not tools.run_tool(ctx3, tool("matrix", decker_id="ghost", action="move", node="Entry")).get("is_error")
    ctx4 = TurnContext(g, g.turn_no() + 1, g.current_scene_id())                # nothing named: never in the way
    assert matrix_target(ctx4) is None
    assert not tools.run_tool(ctx4, tool("matrix", decker_id="ghost", action="jack_in", host_id=plaza)).get("is_error")
    spider = g.introduce("npc", "Night Spider", "the Larkspur's night-shift security decker", template="expert",
                         turn=2)[0]
    g.ledger.give(spider, g.ledger.create_entity("item", "Spider's cyberdeck", "", props={"deck": 4}, turn=2), 1)
    ctx5 = TurnContext(g, g.turn_no() + 1, g.current_scene_id())                # (an NPC spider goes where it goes)
    ctx5.matrix_asks = ctx.matrix_asks
    assert not tools.run_tool(ctx5, tool("matrix", decker_id=spider, action="jack_in", host_id=larkspur)).get("is_error")


def test_a_test_against_a_host_they_didnt_name_is_sent_back_too(make_game):
    """Review of flag #36: the guard covered only the matrix tool, and a request_test with the host as opposed_by is
    the other way a decker goes at a host (the live GM did, T103 and T119). The T121 camera hack the player called
    against a rating 3 target went through against the rating-5 Larkspur host, 10d6. It's held the same way now: turned
    away, a bare re-call turned away again, the third through - flagged. A test against the host they named goes."""
    from roleplay.dm import tools
    g = make_game(dice=ScriptedDice([2] * 200))
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx.matrix_asks = matrix_asks(g, [("razor", "Ghost picks the rating 3 security cameras as his target.")])
    hack = dict(actor_id="ghost", skill="hacking", reason="loop the atrium dome", opposed_by={"entity_id": larkspur})
    out = tools.run_tool(ctx, tool("request_test", **hack))
    assert out["is_error"] and "This Hacking test goes against Larkspur Room Host (rating 5) - harder than the rating 3" \
        in out["content"] and "introduce that host (kind 'host', rating 3) and roll it against it" in out["content"]
    assert not g.conn.execute("SELECT 1 FROM tests").fetchone()
    assert tools.run_tool(ctx, tool("request_test", **hack))["is_error"]
    assert not tools.run_tool(ctx, tool("request_test", **hack)).get("is_error")
    assert "matrix target overridden" in {f["kind"] for f in flags.listing(g.path.parent)}
    ctx = TurnContext(g, g.turn_no() + 2, g.current_scene_id())
    ctx.matrix_asks = matrix_asks(g, [("razor", "Ghost picks the rating 3 security cameras as his target.")])
    assert not tools.run_tool(ctx, tool("request_test", **dict(hack, opposed_by={"entity_id": plaza}))).get("is_error")
    out = tools.run_tool(ctx, tool("request_test", actor_id="ghost", skill="perception", reason="looks round",
                                   opposed_by={"entity_id": larkspur}))
    assert not out.get("is_error")                                    # (not a Matrix skill: not a dive)


def _ctx(g, posts, turn_id=None):
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx.matrix_asks = matrix_asks(g, posts, turn_id)
    return ctx


def _jack(ctx, decker, host):
    from roleplay.dm import tools
    return tools.run_tool(ctx, tool("matrix", decker_id=decker, action="jack_in", host_id=host))


def test_a_named_target_holds_only_its_own_deckers_dive(make_game):
    """Review of flag #36: a named host was checked against every decker's jack-in, and the one reminder a turn was
    spent on the wrong decker - Static's jack-in (his player named nothing) was turned away for Ghost's host, and
    then Ghost went into the rating-5 Larkspur host unchecked: the T120 failure the guard is for."""
    from roleplay.dm import calls
    g = make_game()
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    glass = _host(g, rating=3, turn=2)
    tm = g.create_pc("Static", "technomancer", "static", "ork technomancer", 1)
    g.ledger.enter(g.current_scene_id(), [tm], 1)
    ctx = _ctx(g, [("ghost", "Ghost jacks into the Bellevue Arcade Building Services Host to loop the cameras."),
                   ("static", "Static goes into the Matrix too, looking around for anything interesting.")])
    assert [(a.decker, a.host) for a in ctx.matrix_asks] == [("ghost", plaza)]
    assert not _jack(ctx, tm, glass).get("is_error")                  # (nothing named for Static's dive)
    out = _jack(ctx, "ghost", larkspur)                                 # (and Ghost's reminder is still his)
    assert out.get("is_error") and "Ghost's post goes after Bellevue Arcade Building Services Host" in out["content"]
    assert not matrix.state(g.ledger, "ghost").get("host")
    from roleplay.dm import tools                                     # (each decker's own: with a reason, through)
    assert not tools.run_tool(ctx, tool("matrix", decker_id="ghost", action="jack_in", host_id=larkspur,
                                        despite="the GM checked: the loop runs through the Larkspur's feed")).get("is_error")
    # each names their own: the hook gives each decker theirs, and one's host never holds the other's dive
    ctx2 = _ctx(g, [("ghost", "Ghost jacks into the Bellevue Arcade Building Services Host."),
                    ("static", "Static hacks the Mothlight host.")])
    assert matrix_target(ctx2, tm)["host"] == glass and matrix_target(ctx2, "ghost")["host"] == plaza
    assert "into the host they named, Mothlight Trideo Productions host" in calls._matrix_hint(ctx2, tm)
    assert _jack(ctx2, "ghost", glass).get("is_error")                 # (Static's host isn't Ghost's)
    assert not _jack(ctx2, tm, glass).get("is_error")
    # a post can name another runner's dive - the decker it names, not the poster
    (ask,) = matrix_asks(g, [("razor", "Static goes after the Mothlight host while I watch the door.")])
    assert (ask.who, ask.decker, ask.host) == ("Razor", tm, glass)
    ctx3 = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    ctx3.matrix_asks = [ask]
    assert not _jack(ctx3, "ghost", larkspur).get("is_error")           # (not Ghost's dive)
    out = _jack(ctx3, tm, larkspur)
    assert out.get("is_error") and "Razor's post goes after Mothlight" in out["content"]
    assert "for Static's dive" in out["content"]


def test_a_rating_binds_only_when_its_said_of_the_target(make_game):
    """Review of flag #36: any rating in a sentence with a Matrix word counted - the decker's own deck, a skill, a
    maglock picked by hand, "rated one of the best" - so the host the player meant was turned away and the GM was
    told to make one up at that rating. And a rating named is a ceiling: an easier host is never turned away."""
    from roleplay.dm.turn import MATRIX_POST
    g = make_game()
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    for post in ("Ghost jacks into the arcade's host with his rating 4 deck to loop the cameras.",
                 "Razor works the rating 5 maglock on the service door while Ghost hacks the building's host.",
                 "Ghost jacks in with his rating 6 Hacking and goes for the building's host.",
                 "The Larkspur is rated one of the best in Bellevue, so Ghost hacks its cameras.",
                 "Ghost hacks the arcade cameras while I order a rating 4 armor jacket.",
                 "Ghost pulls out his rating 4 deck and goes after the building's cameras"):
        assert MATRIX_POST.search(post) and matrix_asks(g, [("ghost", post)]) == [], post   # (the reading ran)
        assert not _jack(_ctx(g, [("ghost", post)]), "ghost", plaza).get("is_error"), post
    for post in ("Once Ghost picks the rating 3 security cameras as his target, we go.",
                 "Ghost hacks the cameras - a rating 3 system.", "Ghost hacks the cameras, rated 3.",
                 "Hack the rating 3 tower cameras.", "Ghost goes for the cameras. Their system is rated three."):
        assert [a.rating for a in matrix_asks(g, [("ghost", post)])] == [3], post
    kiosk = _host(g, "Kiosk Network host", "", rating=2, turn=2)
    post = [("ghost", "Ghost hacks the cameras - a rating 3 system.")]
    assert not _jack(_ctx(g, post), "ghost", kiosk).get("is_error")    # (easier than they said: theirs)
    out = _jack(_ctx(g, post), "ghost", _host(g, rating=4, turn=2))
    assert out.get("is_error") and "goes into Mothlight Trideo Productions host (rating 4) - harder than the rating 3 " \
                                   "they named" in out["content"]
    assert "Jack into a host on file at rating 3 or lower" in out["content"]
    assert "introduce that host (kind 'host', rating 3)" in out["content"]


def test_a_host_merely_mentioned_doesnt_move_a_run(make_game):
    """Review of flag #36: "what the Kovacs payoff ledger said" - a file Horizon's host holds - named Horizon, and the
    search Ghost was making in the Mothlight host was turned away with "jack_in to it (that leaves this one)"; the
    words it quoted were the post's first, not the ones that named it."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    horizon = g.introduce("host", "Horizon Credit Auburn host", "", rating=4, turn=1)[0]
    glass = _host(g, rating=3)
    g.introduce("item", "Kovacs payoff ledger", "the payoffs", owner_id=horizon, turn=1)
    matrix.act(L, g.dice, 3, "ghost", "jack_in", glass)
    from roleplay.dm import tools
    post = ("Still in the Matrix, Ghost searches for the trideo files - and thinks about what the Kovacs payoff ledger "
            "said.")
    assert matrix.named_hosts(L, post) == [horizon] and matrix_asks(g, [("ghost", post)]) == []
    assert not tools.run_tool(_ctx(g, [("ghost", post)]), tool("matrix", decker_id="ghost", action="search")).get(
        "is_error")
    post = ("Still in the Mothlight host for now, and nothing much there. Later tonight Ghost goes after the Kovacs "
            "payoff ledger in Horizon's records.")
    (ask,) = matrix_asks(g, [("ghost", post)])
    assert ask.host == horizon and "goes after the Kovacs payoff ledger" in ask.words      # (the words that named it)
    out = tools.run_tool(_ctx(g, [("ghost", post)]), tool("matrix", decker_id="ghost", action="search"))
    assert out.get("is_error") and "goes after the Kovacs payoff ledger" in out["content"]
    assert f"jack_in to Horizon Credit Auburn host [{horizon}] (that leaves this one)" in out["content"]


def test_a_host_they_rule_out_is_never_the_one(make_game):
    """Review of flag #36: "Filament skips the Larkspur host - too hot - and goes for the rating 3 security cameras"
    named the Larkspur host, and the right jack-in was turned away with "Go after the one they named - jack_in to it":
    the flag #36 dive, steered by the engine. T119's GM had set up just that contrast (a rating-5 host, and the
    tower's own lower-grade system)."""
    from roleplay.dm import calls
    for post in ("Ghost skips the Larkspur host - too hot - and goes for the rating 3 security cameras instead.",
                 "Not the Larkspur host. Hack the rating 3 tower cameras.",
                 "Ghost stays out of the Larkspur host and hacks the building's cameras instead.",
                 "Forget the Larkspur host, it's a rating 5. Ghost hacks the tower's own system - the cameras."):
        g = make_game()
        setup_demo(g)
        larkspur, plaza, _ = _plaza(g)
        asks = matrix_asks(g, [("ghost", post)])
        assert [a.host for a in asks if a.host] == [larkspur] and all(a.avoid for a in asks if a.host), post
        assert 5 not in [a.rating for a in asks], post                  # (the 5 is the one they ruled out)
        ctx = _ctx(g, [("ghost", post)])
        t = matrix_target(ctx, "ghost")
        assert t is None or (t["host"] is None and t["avoid"] == [larkspur]), post
        out = _jack(ctx, "ghost", larkspur)
        assert out.get("is_error") and "rules out Larkspur Room Host" in out["content"], post
        assert "the host they ruled out" in out["content"] and "Go after" not in out["content"], post
        assert not _jack(_ctx(g, [("ghost", post)]), "ghost", plaza).get("is_error"), post
    g = make_game()
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    ctx = _ctx(g, [("ghost", "Not the Larkspur host. Hack the rating 3 tower cameras.")])
    assert calls._matrix_hint(ctx, "ghost") == (" - against the rating 3 target they named (a host no harder) - not "
                                                "Larkspur Room Host, which they ruled out")
    ctx = _ctx(g, [("ghost", "Ghost stays out of the Larkspur host and hacks the building's cameras instead.")])
    assert calls._matrix_hint(ctx, "ghost") == " - not Larkspur Room Host, which they ruled out"
    for post in ("Ghost hacks the Larkspur host, not the arcade's.", "Ghost won't wait - he hacks the Larkspur host."):
        (ask,) = matrix_asks(g, [("ghost", post)])
        assert ask.host == larkspur and not ask.avoid, post               # (going after it, not ruling it out)
    assert matrix_asks(g, [("ghost", "Ghost jacks in. Don't let the Larkspur host spot you.")]) == []
    (ask,) = matrix_asks(g, [("ghost", "Ghost won't touch the Larkspur host tonight.")])
    assert ask.host == larkspur and ask.avoid
    # a named host above the rating they named: both listed, and never "go after" the harder one
    post = [("ghost", "Ghost goes after the Larkspur host's rating 3 cameras.")]
    assert matrix_target(_ctx(g, post), "ghost")["host"] is None
    out = _jack(_ctx(g, post), "ghost", _host(g, rating=4, turn=2))
    assert out.get("is_error") and "goes after Larkspur Room Host" in out["content"]
    assert "names a rating 3 target" in out["content"] and "Go after" not in out["content"]
    assert "Jack into a host on file at rating 3 or lower" in out["content"]
    assert not _jack(_ctx(g, post), "ghost", plaza).get("is_error")      # (no harder than the 3 they named)


def test_a_target_named_one_turn_holds_the_next_turns_dive(make_game):
    """Review of flag #36, live T120 -> T121: a post naming the rating-3 cameras as the target, with the crew to find
    somewhere safe to jack in first, put the dive off; it came at T121, in another scene, on a post that named
    nothing. The guard read only the turn's own posts."""
    from roleplay.dm.turn import MATRIX_CARRY
    llm = LoopLLM([([text("The crew slips out to a noodle bar with a quiet booth in the back.")], "end_turn"),
                   ([tool("matrix", decker_id="ghost", action="jack_in", host_id="larkspur-room-host")], "tool_use"),
                   ([tool("matrix", decker_id="ghost", action="jack_in",
                          host_id="bellevue-arcade-building-services-host")], "tool_use"),
                   ([text("In the arcade's boiler-room host, the bellhop Patrol IC wheels its cart past Ghost.")],
                    "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    larkspur, plaza, _ = _plaza(g)
    first = g.run_turn([("razor", "Once Ghost picks the rating 3 security cameras as his target, the crew looks for "
                                  "somewhere quiet he can jack in from.")])
    held = matrix_asks(g, [], first.turn_id + 1)
    assert [(a.decker, a.rating, a.turn) for a in held] == [("ghost", 3, first.turn_id)]
    assert matrix_asks(g, [], first.turn_id + MATRIX_CARRY + 1) == []            # (a few turns, not forever)
    newer = matrix_asks(g, [("ghost", "Ghost jacks into the Bellevue Arcade Building Services Host.")], first.turn_id + 1)
    assert [a.host for a in newer] == [plaza]                                    # (a newer word on it is the one)
    g.new_scene("A noodle bar booth", None, ["ghost", "razor"], first.turn_id)   # (live: T121 was another scene)
    g.run_turn([("razor", "Now. The camera over the side door has our faces. Kill it and the other feed.")])
    refused = next(x for x in _results(llm) if x.startswith("Refused:"))
    assert f"Razor's post at T{first.turn_id} names a rating 3 target" in refused and "for Ghost's dive" in refused
    assert "goes into Larkspur Room Host (rating 5) - harder than the rating 3 they named" in refused
    assert "or the story has moved on from what they named then" in refused
    assert matrix.state(g.ledger, "ghost")["host"] == plaza
    assert matrix_asks(g, [], g.turn_no() + 1) == []                             # (the jack-in took it up)


def test_the_jack_in_turn_gives_the_gm_the_ics_look(make_game):
    """Review of flag #35: a dive at this table is jack_in, every beat and the narration in one turn (live T121, T126,
    T131), and on that turn the GM had no THE MATRIX section - the jack_in card had no look, and HOSTS ON FILE cut
    the description before the IC's (six of the seven live hosts). The host's own Patrol IC never reached it."""
    llm = LoopLLM([([tool("matrix", decker_id="ghost", action="jack_in",
                          host_id="bellevue-arcade-building-services-host")], "tool_use"),
                   ([text("In the arcade's boiler-room host, the bellhop Patrol IC wheels its cart past Ghost.")],
                    "end_turn")], COMMIT)
    g = make_game(llm)
    setup_demo(g)
    _plaza(g)
    res = g.run_turn([("razor", "Ghost goes hot into the building services host.")])
    first = llm.calls[0][-1]["content"]
    first = first if isinstance(first, str) else " ".join(str(b) for b in first)
    line = next(x for x in first.splitlines() if x.startswith("Bellevue Arcade Building Services Host ["))
    assert line.endswith("hissing... · its IC: a sleepy bellhop patrol IC pushing a luggage cart")
    (back,) = _results(llm)
    assert "(GM only - the cut into the Matrix, as this host sculpts itself:)" in back
    assert "Its IC (call it IC, and play it as the host sculpts it" in back
    assert "Patrol IC - a sleepy bellhop patrol IC pushing a luggage cart" in back
    card = next(c for c in res.cards if "jacks into" in c.splitlines()[0])
    assert "GM only" not in card and "bellhop" not in card                         # (the players' card stays theirs)
    L = g.ledger
    assert "its IC:" not in matrix.host_line(L, "larkspur-room-host")              # (shown whole: no repeat)
    assert "gardener IC in green aprons" in matrix.host_line(L, "larkspur-room-host")


def test_the_gm_is_told_a_named_matrix_target_is_binding(make_game):
    assert "A Matrix target the player names is binding the same way" in DM_SYSTEM
    assert "never a harder host they didn't pick, and never one they rule out" in DM_SYSTEM
    assert "A target named a turn or two before the dive still holds" in DM_SYSTEM
    assert "and so does the jack_in's result on the turn they dive" in DM_SYSTEM
    from roleplay.dm import canon
    assert "The host or device a player names is the one the decker goes after" in canon.ENGINE_RULES
    assert "into a host they ruled out is turned away" in canon.ENGINE_RULES
    assert "a bare re-call again" in canon.ENGINE_RULES and "turned away once" not in canon.ENGINE_RULES
