"""The flag log: the GM's `flag:` lines, the players' !reportbug and what the engine notices, in one place the dashboard
shows."""
import asyncio
import json

from roleplay import flags
from roleplay.dashboard import data, server
from roleplay.discord_bot import runtime
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_dashboard import _request
from .test_discord import FakeChannel

EXTRACTION = {"summary": "Razor tried the door.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": [],
                           "where": {"district": "", "near": "", "bearing": "", "distance_m": 0}},
              "members": [{"id": "razor", "role": "actor"}], "minutes_elapsed": 0}


def test_the_log_records_dedupes_and_tracks_status(make_game, tmp_path):
    g = make_game()
    a = flags.record(g, "engine", "tool error", "cast: unknown spell", turn=3, context={"input": {"spell": "x"}})
    assert flags.record(g, "engine", "tool error", "cast:  unknown   spell", turn=3) == a      # the same flag, once
    b = flags.record(g, "player", "bug report", "Quiet Lou keeps talking for me", who="Alice", turn=3)
    assert a != b and [f["id"] for f in flags.listing(tmp_path)] == [b, a]
    assert flags.listing(tmp_path)[1]["context"] == {"input": {"spell": "x"}}
    assert flags.counts(tmp_path)["open_by_source"] == {"engine": 1, "player": 1}
    f = flags.set_status(tmp_path, a, "fixed", "spell list reloads now")
    assert f["status"] == "fixed" and f["note"] == "spell list reloads now"
    assert [x["id"] for x in flags.listing(tmp_path)] == [b] and len(flags.listing(tmp_path, None)) == 2
    assert flags.record(g, "engine", "tool error", "cast: unknown spell", turn=3) not in (None, a)   # fixed, then again
    assert flags.record(object(), "engine", "x", "no game") is None                               # never raises


def test_the_gm_flags_for_the_developers_and_the_table_never_sees_it(make_game, tmp_path):
    g = make_game(FakeLLM([([text("The door holds.\n<dm>\nflag: The lockpick tool refused Razor's maglock "
                                  "passkey, but it's on his sheet.\n</dm>")], "end_turn")], EXTRACTION))
    setup_demo(g)
    res = g.run_turn([("razor", "I try the passkey.")])
    assert res.narration == "The door holds." and not any("flag" in c.lower() for c in res.cards)
    f = flags.listing(tmp_path)[0]
    assert (f["source"], f["kind"], f["turn"], f["campaign"]) == ("gm", "gm flag", res.turn_id, g.path.stem)
    assert f["text"].startswith("The lockpick tool refused")


def test_the_engine_flags_a_speaker_tag_with_no_one_behind_it(make_game, tmp_path):
    g = make_game(FakeLLM([([text("**Pruett [no-such-npc]:** \"Photos. Now.\"")], "end_turn")], EXTRACTION))
    setup_demo(g)
    res = g.run_turn([("razor", "I wait.")])
    f = flags.listing(tmp_path)[0]
    assert f["kind"] == "speaker id" and "no-such-npc" in f["text"] and f["turn"] == res.turn_id


def test_a_player_reports_a_bug_with_the_turn_attached(make_game, tmp_path):
    g = make_game(FakeLLM([([text("Kaz shrugs.")], "end_turn")], EXTRACTION))
    setup_demo(g)
    last = g.run_turn([("razor", "Kaz, work?")]).turn_id

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "Alice", "!join razor", False, react)
        await t.handle("1", "Alice", "!bug", False, react)
        assert "!reportbug <what went wrong>" in str(ch.sent[-1]) and not flags.listing(tmp_path)
        await t.handle("1", "Alice", "!reportbug Kaz forgot the job we took", False, react)
        f = flags.listing(tmp_path)[0]
        assert f"logged as **#{f['id']}**" in str(ch.sent[-1])
        assert (f["source"], f["who"], f["turn"], f["text"]) == ("player", "Alice", last, "Kaz forgot the job we took")
        assert f["context"]["character"] == "Razor" and f["context"]["last_narration"] == "Kaz shrugs."
        await t.close()
    asyncio.run(go())


def test_the_dashboard_shows_flags_and_marks_them(make_game, tmp_path, monkeypatch):
    monkeypatch.setattr(runtime, "RUN_DIR", tmp_path / ".run")
    g = make_game()
    fid = flags.record(g, "gm", "gm flag", "The map put Berit in two places.", turn=4)
    dash = server.Dashboard(0, "serve", tmp_path)
    dash.start()
    try:
        host = {"Host": f"127.0.0.1:{dash.port}"}
        code, body = _request(dash.port, "GET", "/api/dash/flags", host)
        d = json.loads(body)
        assert code == 200 and d["flags"][0]["id"] == fid and d["counts"]["by_status"] == {"open": 1}
        assert _request(dash.port, "POST", "/api/dash/flags/status", host, {"id": fid, "status": "fixed"})[0] == 403
        code, body = _request(dash.port, "POST", "/api/dash/flags/status", {**host, "X-RP-Key": dash.key},
                              {"id": fid, "status": "fixed", "note": "one pin per person"})
        assert code == 200 and json.loads(body)["status"] == "fixed"
        assert json.loads(_request(dash.port, "GET", "/api/dash/flags", host)[1])["flags"] == []
        all_ = json.loads(_request(dash.port, "GET", "/api/dash/flags?status=all", host)[1])["flags"]
        assert all_[0]["note"] == "one pin per person"
        assert "flags" not in [c["name"] for c in data.campaign_list(tmp_path)]        # not a world
    finally:
        dash.shutdown()
