"""Fights: the engine owns the battlefield (zones, positions, sides, a round log); the GM narrates and sends deltas."""
from PIL import Image

from roleplay import battlemap, encounters
from roleplay.dm import dmblock
from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import sr_lite
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool

BAR = [{"name": "counter", "cover": "hard"}, {"name": "booths", "cover": "light"}, {"name": "front door"},
       {"name": "street", "near": ["front door"]}]


def _game(make_game, llm=None, dice=None):
    g = make_game(llm or FakeLLM(), dice=dice)
    setup_demo(g)
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    return g


def test_the_jump_and_ambushes(make_game):
    # razor, ghost, kaz, joey: Joey ambushes. The others roll surprise (3 needed), then everyone rolls Initiative -
    # and whoever's caught flat-footed loses 10 of it (SR5 p. 192).
    g = _game(make_game, dice=ScriptedDice([6] * 3 + [1] * 20))
    enc, card = encounters.start(g, 1, BAR, {"joey-two-knives": "front door", "razor": "counter"}, ["joey-two-knives"])
    assert card.startswith("[FIGHT] Ambush! Initiative (each 10 is an Action Phase") and "caught flat-footed -10" in card
    assert [z["name"] for z in enc["zones"]] == ["counter", "booths", "front door", "street"]
    assert encounters.distance(enc, "counter", "street") == 3 and encounters.distance(enc, "booths", "booths") == 0
    flat = {j["name"]: j["flat"] for j in enc["jump"]}
    assert flat["Joey Two-Knives"] is False and list(flat.values()).count(True) >= 1
    assert enc["jump"][-1]["flat"]                                         # the flat-footed act last
    assert all(j["surprise"] == (10 if j["flat"] else 0) for j in enc["jump"])
    assert encounters.start(g, 1)[1] == ""                                 # one fight per scene


def test_range_cover_melee_and_sides(make_game):
    g = _game(make_game)
    enc, _ = encounters.start(g, 1, BAR, {"razor": "street", "joey-two-knives": "counter", "ghost": "booths"})
    atk, dfn, notes = encounters.attack_mods(g, "razor", "joey-two-knives", "firearms")
    assert atk == [("Range: extreme (counter)", -6)] and dfn == [("Cover: hard (counter)", 4)]
    atk, dfn, notes = encounters.attack_mods(g, "ghost", "joey-two-knives", "close_combat")
    assert atk == [] and "closes in (booths -> counter)" in notes[0]
    assert encounters.zone_of(encounters.active(g), "ghost") == "counter"
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    enc = encounters.active(g)
    assert encounters.side(g, enc, "joey-two-knives") == "hostile" and encounters.side(g, enc, "kaz") == "neutral"
    assert encounters.side(g, enc, "razor") == "runners"
    res = sr_lite.attack(g.ledger, g.dice, 1, "razor", "joey-two-knives", "razor-s-ares-predator-v",
                         situation=[("Range: far", -3)], cover=[("Cover: hard", 4)], reason="t")
    assert "Range: far 3" in res["card"] and "Cover: hard 4" in res["card"]           # (shown as "- Range: far 3")


def test_a_fight_is_one_memory_not_a_dozen(make_game):
    script = [([tool("fight", action="start", zones=BAR, positions=[{"id": "joey-two-knives", "zone": "front door"}]),
                tool("attack", attacker_id="razor", target_id="joey-two-knives", reason="he drew first")], "tool_use"),
              ([text("Razor fires across the bar.")], "end_turn"),
              ([text("Joey dives behind the door frame.\n<dm>\nbattle end: Joey ran into the street\n</dm>")], "end_turn")]
    extraction = {"summary": "Razor shot at Joey across the bar.", "recalled": [], "told": [], "new_entities": [],
                  "facts": [{"text": "Joey Two-Knives drew a knife on Razor in the Lucky Shot.", "about": ["joey-two-knives"],
                             "replaces": ""}],
                  "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}, {"id": "joey-two-knives", "role": "target"}],
                  "combat": {"moves": [{"id": "joey-two-knives", "zone": "street"}], "zones": [], "over": False, "how": ""}}
    g = _game(make_game, FakeLLM(script, extraction))
    n_slices = lambda: g.conn.execute("SELECT COUNT(*) FROM nodes WHERE kind='slice'").fetchone()[0]   # noqa: E731
    before = n_slices()
    res = g.run_turn([("razor", "I draw on Joey.")])
    assert res.cards[0].startswith("[FIGHT]") and res.cards[1].startswith("[ROLL] Razor attacks")
    assert res.info["slice_id"] is None and n_slices() == before            # the round went to the fight's log
    assert any("drew a knife" in f["text"] for f in g.sub.facts_for("joey-two-knives", 5))   # canon still records
    enc = encounters.active(g)
    assert enc["round"] == 1 and enc["log"][0]["text"] == "Razor shot at Joey across the bar."
    assert encounters.zone_of(enc, "joey-two-knives") == "street"           # moved by the memory pass
    packet, _ = build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)
    assert "=== FIGHT - round 2" in packet and "Joey Two-Knives [joey-two-knives] hostile @ street" in packet
    g.run_turn([("razor", "I go after him.")])
    assert encounters.active(g) is None
    fight = g.conn.execute("SELECT * FROM nodes WHERE kind='slice' AND text LIKE 'The fight:%'").fetchone()
    assert fight and n_slices() == before + 1                               # ...and the whole fight became one memory
    roles = dict(g.conn.execute("SELECT node_id, role FROM members WHERE slice_id=?", (fight["id"],)).fetchall())
    assert roles["razor"] == "actor" and roles["joey-two-knives"] == "target"
    ended = encounters.get(g, 1)
    assert ended["outcome"] == "Joey ran into the street" and ended["round"] == 2
    assert Image.open(battlemap.render(g, ended["id"])).width >= 1100


def test_fights_end_themselves_and_dm_lines_steer_them(make_game):
    g = _game(make_game)
    ctx = TurnContext(g, 5, g.current_scene_id())
    _, entries = dmblock.split("x\n<dm>\nbattle: counter (hard cover) | booths (light) | front door\n"
                               "zone joey-two-knives: front door\n</dm>")
    dmblock.apply(ctx, entries)
    enc = encounters.active(g)
    assert [z["cover"] for z in enc["zones"]] == ["hard", "light", "none"] and ctx.cards[0].startswith("[FIGHT]")
    assert encounters.zone_of(enc, "joey-two-knives") == "front door"
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    g.ledger.set_stat("joey-two-knives", "physical_damage", 30)              # down and out
    how = encounters.step(g, encounters.active(g), 6, "Razor dropped Joey.", [], {})
    assert how == "Joey Two-Knives went down"
    g2 = _game(make_game)
    enc, _ = encounters.start(g2, 1, BAR)
    for r in range(encounters.QUIET_ROUNDS):
        how = encounters.step(g2, encounters.active(g2), 2 + r, "They glare at each other.", [], {})
    assert how == "the fighting petered out"
    assert Image.open(battlemap.render(g2, enc["id"])).height > 400


def test_giving_up_ends_a_fight_without_anyone_going_down(make_game):
    g = _game(make_game)
    g.introduce("npc", "Ancients Lookout", "", "ganger", present=True, turn=1)
    enc, _ = encounters.start(g, 1, BAR, {"joey-two-knives": "front door", "ancients-lookout": "street"})
    encounters.note_attack(g, "razor", "joey-two-knives", False)
    encounters.note_attack(g, "ancients-lookout", "ghost", False)
    how = encounters.step(g, encounters.active(g), 2, "Joey drops the knife; the lookout bolts.", [], {}, None,
                          [{"id": "joey-two-knives", "how": "surrendered"}, {"id": "ancients-lookout", "how": "fled"},
                           {"id": "razor", "how": "fled"}])                  # (runners don't yield through this)
    enc = encounters.active(g)
    assert how == "Joey Two-Knives surrendered; Ancients Lookout fled"
    assert encounters.side(g, enc, "razor") == "runners" and "ancients-lookout" not in enc["positions"]
    encounters.note_attack(g, "razor", "joey-two-knives", True)              # shooting him doesn't re-arm him...
    assert encounters.side(g, encounters.active(g), "joey-two-knives") == "surrendered"
    encounters.note_attack(g, "joey-two-knives", "razor", True)              # ...but his going for a hold-out does
    assert encounters.side(g, encounters.active(g), "joey-two-knives") == "hostile"
    assert Image.open(battlemap.render(g, enc["id"])).width >= 1100


# ── 2026-10-24: fights that start, run and end right ─────────────────────
EXTRACTION = {"summary": "Joey jumped Razor in the alley.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []},
              "members": [{"id": "razor", "role": "target"}, {"id": "joey-two-knives", "role": "actor"}]}


def test_a_not_over_battle_end_keeps_the_fight(make_game, tmp_path):
    """Live T174: `battle end: not yet - fight continues` ended the fight mid-fight, and the next turn rolled a fresh
    jump. Only an anchored not-over line is turned away, and only while a hostile still stands."""
    from roleplay import flags
    from roleplay.dm.tools import run_tool
    g = _game(make_game)
    encounters.start(g, 1, BAR)
    encounters.note_attack(g, "razor", "joey-two-knives", True)            # Joey's hostile, and on his feet
    ctx = TurnContext(g, 2, g.current_scene_id())
    _, entries = dmblock.split("x\n<dm>\nbattle end: not yet - fight continues; Joey is the last one up\n</dm>")
    dmblock.apply(ctx, entries)
    assert encounters.active(g)["ending"] is None and any(e.startswith("FIGHT GOES ON") for e in ctx.events)
    assert encounters.step(g, encounters.active(g), 2, "Razor keeps shooting.", [], {}) is None
    out = run_tool(ctx, tool("fight", action="end", how="Not over - Joey still fights"))
    assert out["is_error"] and out["content"].startswith("Refused: the fight isn't over - Joey Two-Knives still stands")
    assert ctx.tool_errors == 0 and not flags.listing(tmp_path)              # the table's rule, not a bug
    for real in ("No one left standing - Joey is down", "Still bodies on the floor; it's done"):
        assert encounters.NOT_OVER.match(real) is None, real                 # (the verifier's false refusals)
    assert encounters.request_end(g, "No one left standing - Joey is down")
    assert encounters.step(g, encounters.active(g), 3, "Joey drops.", [], {}) == "No one left standing - Joey is down"


def test_newcomers_join_the_running_fight(make_game):
    """Live T171: a mid-fight `fight` call came back 'already on' and registered nobody, so the fight ended itself
    with Garvey, Fenn and Gutter standing; T172 then sprang a fresh ambush on all three. Now they join this round,
    rolling for surprise (+3 when their own side is already fighting), and only the ids named hostile take a side."""
    g = _game(make_game, dice=ScriptedDice([1] * 300))
    encounters.start(g, 1, BAR)
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    encounters.step(g, encounters.active(g), 1, "Razor fires.", [], {})
    for name, template in (("Pastor Garvey", "ganger"), ("Bartender Bo", "civilian")):   # (in after it started)
        g.introduce("npc", name, "", template, present=True, turn=2)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "fight", {"action": "start", "positions": [{"id": "pastor-garvey", "zone": "street"},
                                                                   {"id": "bartender-bo", "zone": "counter"}],
                                  "hostile": ["pastor-garvey"]})
    assert out.startswith("[FIGHT] Joining the fight in round 2: ")
    assert "Pastor Garvey (surprise 0 on 9d6 (alerted +3) - caught flat-footed)" in out     # R 3 + I 3, +3: Joey's up
    assert "Bartender Bo (surprise 0 on " in out and "Bo (surprise 0 on 9d6 (alerted" not in out
    enc = encounters.active(g)
    assert enc["sides"]["pastor-garvey"] == "hostile" and "bartender-bo" not in enc["sides"]   # never bystanders
    assert encounters.zone_of(enc, "pastor-garvey") == "street"
    assert encounters.unaware(g, "pastor-garvey") and not encounters.unaware(g, "razor")      # (Razor's engaged)
    packet, _ = build_packet(g, g.current_scene_id(), [], 3)
    assert "Joining this round: " in packet and "Pastor Garvey - flat-footed: can't dodge until they act" in packet
    assert dispatch(ctx, "fight", {"action": "start", "positions": [{"id": "pastor-garvey", "zone": "booths"}]}) \
        == "The fight is already on - layout updated (nobody new to join)."
    encounters.step(g, encounters.active(g), 2, "Garvey rides in.", [], {})
    assert not encounters.unaware(g, "pastor-garvey")                        # surprised only until the round's out
    sr_lite.attack(g.ledger, g.dice, 2, "razor", "kaz", "razor-s-katana", reason="a swing at Kaz")
    sid = g.current_scene_id()
    assert encounters.alerted(g, "kaz", 4, sid) and not encounters.alerted(g, "kaz", 5, sid)   # (two turns' worth)
    assert not encounters.alerted(g, "ghost", 4, sid)


def test_whoever_the_crew_hurts_is_a_foe(make_game):
    """Live T171: the barrier crash hurt Garvey through apply_damage, which marked no sides, so the fight ended itself
    with him standing. An NPC hurt since the fight began counts as a foe - unless the hostiles hurt them; source_id
    names who did it (and opens a fight when none is on)."""
    g = _game(make_game, dice=ScriptedDice([2] * 200))
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=True, turn=1)
    encounters.start(g, 1, BAR)
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    encounters.note_attack(g, "joey-two-knives", "kaz", True)                 # Joey cuts Kaz: Kaz is no foe
    g.ledger.set_stat("joey-two-knives", "physical_damage", 30)
    ctx = TurnContext(g, 1, g.current_scene_id())
    for who in ("pastor-garvey", "kaz"):
        dispatch(ctx, "apply_damage", {"target_id": who, "dv": 3, "damage_type": "stun", "resist": "none",
                                       "reason": "thrown into the wall"})
    enc = encounters.active(g)
    assert encounters.foes(g, enc) == ["joey-two-knives", "pastor-garvey"]
    assert encounters.step(g, enc, 1, "Garvey hits the wall.", [], {}) is None          # he's up: it goes on
    g.ledger.set_stat("pastor-garvey", "physical_damage", 30)
    assert encounters.step(g, encounters.active(g), 2, "Garvey drops.", [], {}) == \
        "Joey Two-Knives went down; Pastor Garvey went down"
    g2 = _game(make_game, dice=ScriptedDice([2] * 200))
    ctx = TurnContext(g2, 1, g2.current_scene_id())
    out = dispatch(ctx, "apply_damage", {"target_id": "joey-two-knives", "dv": 4, "damage_type": "physical",
                                         "source_id": "razor", "reason": "Razor shoves him down the stairs"})
    assert ctx.cards[0].startswith("[FIGHT]") and ctx.cards[1].startswith("[DAMAGE] Joey Two-Knives")
    assert out.startswith("[FIGHT]") and "\n[DAMAGE] Joey Two-Knives" in out          # (the GM sees the fight open)
    assert encounters.side(g2, encounters.active(g2), "joey-two-knives") == "hostile"


def test_a_combat_spell_opens_the_fight_a_probe_doesnt(make_game):
    """Live T175: a Manabolt on Fenn resolved outside any fight. A damage spell at someone is an attack; Mind Probe on a
    prisoner isn't, and nothing in a whisper opens a fight."""
    from .test_magic import _mage
    g = _game(make_game, dice=ScriptedDice([2] * 300))
    sable = _mage(g)
    g.enter_scene([sable], 1)
    L = g.ledger
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": list(L.get(sable)["props"]["spells"]) + ["mind probe"]})
    ctx = TurnContext(g, 2, g.current_scene_id())
    dispatch(ctx, "cast", {"caster_id": sable, "spell": "Mind Probe", "force": 3, "targets": [{"id": "joey-two-knives"}]})
    dispatch(TurnContext(g, 2, g.current_scene_id(), private=sable), "cast",
             {"caster_id": sable, "spell": "Stunbolt", "force": 3, "targets": [{"id": "joey-two-knives"}]})
    assert encounters.active(g) is None
    dispatch(ctx, "cast", {"caster_id": sable, "spell": "Stunbolt", "force": 3, "targets": [{"id": "joey-two-knives"}]})
    assert ctx.cards[-2].startswith("[FIGHT]") and ctx.cards[-1].startswith("[ROLL] Sable casts Stunbolt")
    enc = encounters.active(g)
    assert encounters.side(g, enc, "joey-two-knives") == "hostile" and enc["attacks"][-1]["from"] == sable


def test_a_blow_on_someone_already_down_opens_no_fight(make_game):
    """Live T167/T170/T171: a cut on someone already out opened a fight each time - and ended it the same turn
    ('Hollow Joe went down'), so the GM's real fight call found one 'already on'. The card no longer calls a 0-hit
    blow on no defense a tie (flag #65)."""
    g = _game(make_game, dice=ScriptedDice([2] * 100))
    g.ledger.set_stat("joey-two-knives", "stun_damage", 10)                  # out cold
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": "joey-two-knives",
                                   "weapon_id": "razor-s-katana", "reason": "makes sure"})
    assert encounters.active(g) is None and not any(c.startswith("[FIGHT]") for c in ctx.cards)
    assert "MISS (no hits - with no defense it's a Success Test, SR5 p. 189)" in out and "ties go" not in out
    out = dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": "kaz", "weapon_id": "razor-s-katana",
                                   "reason": "a real tie"})
    assert "MISS (ties go to the defender)" in out


def test_a_fight_after_a_cut_runs_that_turn(make_game):
    """Live T164/T168: the fight started after a mid-turn cut_scene wasn't stepped - its flat-footed stayed flat-footed
    into the next turn, and an end called that turn landed a turn late."""
    def play(end_line):
        script = [([tool("cut_scene", title="The alley", bring_ids=["razor", "joey-two-knives"]),
                    tool("fight", action="start", ambushers=["joey-two-knives"]),
                    tool("attack", attacker_id="joey-two-knives", target_id="razor", reason="jumped him")], "tool_use"),
                  ([text("Joey jumps Razor in the alley." + end_line)], "end_turn")]
        g = _game(make_game, FakeLLM(script, EXTRACTION), dice=ScriptedDice([1] * 400))
        g.run_turn([("razor", "I head out back.")])
        return g
    g = play("")
    enc = encounters.active(g)
    assert enc and enc["scene_id"] == g.current_scene_id() and enc["round"] == 1
    assert enc["log"][0]["text"] == "Joey jumped Razor in the alley."
    assert not encounters.unaware(g, "razor")                                # the opening beat was this turn's
    g = play("\n<dm>\nbattle end: done\n</dm>")
    assert encounters.active(g) is None
    assert g.conn.execute("SELECT outcome FROM encounters ORDER BY id DESC").fetchone()["outcome"] == "done"


def test_a_hostile_s_victims_are_no_foes_whatever_became_of_him(make_game):
    """Review: Joey smashed a bottle over Kaz and then surrendered - Kaz, no longer 'hurt by a hostile', turned into a
    foe still standing, so the fight stopped ending itself and a coup de grace on the dying Garvey was refused while
    Kaz stood. A long fight's 40-attack log forgot a hostile's early victims the same way."""
    def bottle(g):
        dispatch(TurnContext(g, 2, g.current_scene_id()), "apply_damage", {
            "target_id": "kaz", "dv": 3, "damage_type": "stun", "resist": "none", "source_id": "joey-two-knives",
            "reason": "Joey smashes a bottle over Kaz"})
    g = _game(make_game, dice=ScriptedDice([2] * 300))
    encounters.start(g, 1, BAR, hostile=["joey-two-knives"])
    bottle(g)
    assert encounters.foes(g, encounters.active(g)) == ["joey-two-knives"]
    assert encounters.step(g, encounters.active(g), 2, "Joey throws up his hands.", [], {}, None,
                           [{"id": "joey-two-knives", "how": "surrendered"}]) == "Joey Two-Knives surrendered"
    g = _game(make_game, dice=ScriptedDice([2] * 300))                     # ...or he runs, leaving Garvey dying
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=True, turn=1)
    encounters.start(g, 1, BAR, hostile=["joey-two-knives", "pastor-garvey"])
    bottle(g)
    g.ledger.set_stat("pastor-garvey", "physical_damage", 11)
    assert encounters.step(g, encounters.active(g), 2, "Joey bolts.", [], {}, None,
                           [{"id": "joey-two-knives", "how": "fled"}]) == "Joey Two-Knives fled; Pastor Garvey went down"
    g = _game(make_game, dice=ScriptedDice([2] * 300))                     # a long fight remembers who Joey hurt
    encounters.start(g, 1, BAR, hostile=["joey-two-knives"])
    bottle(g)
    for _ in range(encounters.ATTACKS_KEPT + 5):
        encounters.note_attack(g, "razor", "joey-two-knives", False)
    enc = encounters.active(g)
    assert len(enc["attacks"]) == encounters.ATTACKS_KEPT + 1 and enc["attacks"][0]["to"] == "kaz"
    assert encounters.foes(g, enc) == ["joey-two-knives"]


def test_a_bystander_hurt_by_nobody_never_stands_against_the_crew(make_game):
    """Review: a shattered mirror cut Kaz (apply_damage, no source) while Razor fought Joey. Kaz - 'neutral' in the GM's
    own packet - then refused Razor's coup de grace on Joey ('Attack, or deal with them first') and cost the mop-up its
    Action Phase. The hurt with no side still keep the fight from ending itself (live T171's Garvey, hurt by the
    barrier with no source), but only the hostile side stands against anyone - the table's ruling: no live threat."""
    g = _game(make_game, dice=ScriptedDice([1] * 400))
    encounters.start(g, 1, BAR, hostile=["joey-two-knives"])
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    ctx = TurnContext(g, 1, g.current_scene_id())
    dispatch(ctx, "apply_damage", {"target_id": "kaz", "dv": 3, "damage_type": "physical", "resist": "none",
                                   "reason": "the shattered mirror behind the bar cuts Kaz"})
    g.ledger.set_stat("joey-two-knives", "stun_damage", 10)                 # the only enemy is out cold
    assert encounters.standing(g, encounters.active(g)) == ["kaz"] and encounters.stands_against(g, "razor") == []
    out = dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": "joey-two-knives", "finish": True,
                                   "reason": "finish him"})
    assert "finishes Joey Two-Knives" in out and "mopping up, free" in out
    packet, _ = build_packet(g, g.current_scene_id(), [], 2)
    assert "Kaz [kaz] neutral @ " in packet


def test_a_fight_after_a_cut_takes_in_only_who_is_there(make_game):
    """Review: the alley's fight, stepped after a mid-turn cut, took in everyone the turn's memory pass saw - Joey and
    Kaz, left behind in the bar, rolled Initiative in the alley, sat in its packet, and would have been witnesses in
    its memory."""
    extraction = {**EXTRACTION, "summary": "Razor walked out on the bar brawl and got jumped in the alley.",
                  "members": [{"id": "razor", "role": "actor"}, {"id": "joey-two-knives", "role": "target"},
                              {"id": "kaz", "role": "present"}, {"id": "pastor-garvey", "role": "actor"}],
                  "combat": {"moves": [], "over": False}}
    script = [([tool("cut_scene", title="The alley", bring_ids=["razor"]),
                tool("scene_presence", enter=["pastor-garvey"]),
                tool("attack", attacker_id="pastor-garvey", target_id="razor", reason="jumps him")], "tool_use"),
              ([text("Razor walks out on the bar brawl; in the alley Garvey swings at him.")], "end_turn")]
    g = _game(make_game, FakeLLM(script, extraction), dice=ScriptedDice([3] * 600))
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=False, turn=1)
    encounters.start(g, 1)                                                   # the bar's fight, from before
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    g.run_turn([("razor", "I walk out the back.")])
    enc = encounters.active(g)
    assert enc["scene_id"] == g.current_scene_id() and enc["round"] == 1
    assert set(enc["positions"]) == {"razor", "pastor-garvey"} and set(enc["members"]) <= {"razor", "pastor-garvey"}
    assert {j["id"] for j in enc["jump"]} == {"razor", "pastor-garvey"}


def test_out_and_back_in_one_turn_is_one_round_of_one_fight(make_game):
    """Review: cutting out back and resuming the bar in the same turn stepped the bar's fight twice (round +2) and
    ended it twice - two fight_end events, two fight memories paid for. With the fight still on, the round trip
    ended it as 'the scene moved on', and its NPCs never reflected (the scene that closed was the back room)."""
    def play(over):
        ex = {**EXTRACTION, "summary": "Razor ducked out back and came straight in again.",
              "members": [{"id": "razor", "role": "actor"}, {"id": "joey-two-knives", "role": "target"}],
              "combat": {"moves": [], "over": over, "how": "Joey went down" if over else ""}}
        g = _game(make_game, FakeLLM([], ex), dice=ScriptedDice([3] * 900))
        bar = g.current_scene_id()
        g.llm.dm_script = [([tool("cut_scene", title="Out back", bring_ids=["razor"]),
                             tool("cut_scene", title="Back in", resume_scene_id=bar, bring_ids=["razor"])], "tool_use"),
                           ([text("Razor steps out, thinks better of it, comes back in swinging.")], "end_turn")]
        encounters.start(g, 1, hostile=["joey-two-knives"])
        encounters.note_attack(g, "razor", "joey-two-knives", True)
        g.run_turn([("razor", "I step out and come back.")])
        return g, bar
    g, _ = play(True)
    assert [tuple(r) for r in g.conn.execute("SELECT status, round FROM encounters")] == [("ended", 1)]
    assert [e["kind"] for e in g.ledger.events(g.turn_no()) if e["kind"] == "fight_end"] == ["fight_end"]
    g, bar = play(False)
    enc = encounters.active(g)
    assert enc and enc["scene_id"] == bar and enc["round"] == 1 and len(enc["log"]) == 1
    ex = {**EXTRACTION, "moved_to": {"location": "The Docks", "description": "", "who": ["razor", "ghost"]},
          "combat": {"over": False}}                                       # the party leaves, no cut: the engine cuts
    g = _game(make_game, FakeLLM([([text("They pile into the van and go.")], "end_turn")], ex))
    bar = g.current_scene_id()
    encounters.start(g, 1, hostile=["joey-two-knives"])
    encounters.note_attack(g, "razor", "joey-two-knives", True)
    g.run_turn([("razor", "We bail.")])
    assert g.current_scene_id() != bar and encounters.active(g, bar) is None
    assert g.conn.execute("SELECT outcome FROM encounters").fetchone()["outcome"] == "the scene moved on"


def test_a_combat_spell_at_a_runner_opens_the_fight_too(make_game):
    """Review: a Crows shaman's Manabolt at Razor opened no fight - only a runner's bolt at an NPC did - so it rolled
    no Initiative, spent no Action Phase and marked nobody, and the next attack opened a fresh jump (live T175's shape,
    the other way round). Only a bolt between two runners isn't a fight."""
    from .test_magic import _mage
    g = _game(make_game, dice=ScriptedDice([2] * 400))
    L = g.ledger
    sable = _mage(g)
    g.enter_scene([sable], 1)
    ctx = TurnContext(g, 2, g.current_scene_id())
    dispatch(ctx, "cast", {"caster_id": sable, "spell": "Stunbolt", "force": 3, "targets": [{"id": "razor"}]})
    assert encounters.active(g) is None                                      # (one runner's bolt at another)
    shaman, _ = g.introduce("npc", "Crows Shaman", "", "ganger", present=True, turn=1)
    L.set_stat(shaman, "magic", 5)
    L.set_stat(shaman, "sorcery", 5)
    L.update_entity(shaman, props={**L.get(shaman)["props"], "spells": ["manabolt"]})
    out = dispatch(ctx, "cast", {"caster_id": shaman, "spell": "Manabolt", "force": 4, "targets": [{"id": "razor"}]})
    assert out.startswith("[FIGHT]") and ctx.cards[-1].startswith("[ROLL] Crows Shaman casts Manabolt")
    assert "Action Complex: Cast Spell - action 1 of" in ctx.cards[-1]
    assert encounters.side(g, encounters.active(g), shaman) == "hostile"


def test_one_runner_s_accident_on_another_is_no_fight(make_game):
    """Review: apply_damage on Ghost with Razor as the source - a backswing, the team mage's barrier - opened a fight
    with nobody hostile in it: it couldn't end itself, and for three turns it wrote no memory, rested nobody and held
    the Action Phase limit. A thing named as the source isn't anyone to fight either (it would stand forever)."""
    g = _game(make_game, dice=ScriptedDice([2] * 300))
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "apply_damage", {"target_id": "ghost", "dv": 3, "damage_type": "stun", "source_id": "razor",
                                         "reason": "Razor's backswing catches Ghost"})
    assert out.startswith("[DAMAGE] Ghost") and encounters.active(g) is None
    dispatch(ctx, "apply_damage", {"target_id": "joey-two-knives", "dv": 3, "damage_type": "stun",
                                   "source_id": "razor-s-katana", "reason": "the katana slips off the bar"})
    assert encounters.active(g) is None
    dispatch(ctx, "apply_damage", {"target_id": "joey-two-knives", "dv": 3, "damage_type": "stun",
                                   "source_id": "razor", "reason": "Razor shoves him into the jukebox"})
    assert encounters.side(g, encounters.active(g), "joey-two-knives") == "hostile"   # (a real one still does)


def test_an_ambush_line_keeps_its_opening_beat(make_game):
    """A `<dm>` ambush lands after the tools ran: no blow has been struck, so the turn is a memory of the lead-up and
    the fight stays at its jump - the flat-footed don't lose their beat before anyone could take it."""
    script = [([text("Shadows move by the booths.\n<dm>\nambush joey-two-knives: from the booths\n</dm>")], "end_turn")]
    g = _game(make_game, FakeLLM(script, {**EXTRACTION, "summary": "Joey's crew slid into the booths."}),
              dice=ScriptedDice([1] * 200))
    res = g.run_turn([("razor", "I order a drink.")])
    enc = encounters.active(g)
    assert enc["round"] == 0 and enc["log"] == [] and res.info["slice_id"]
    assert encounters.unaware(g, "razor")
    razor = next(j for j in enc["jump"] if j["id"] == "razor")
    assert razor["surprise"] == 10                                           # (no new round rolled over the -10)
    assert not [e for e in g.ledger.events(res.turn_id) if e["kind"] == "initiative"]
