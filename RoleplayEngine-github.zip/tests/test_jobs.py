"""Jobs: the memory pass files the crew's runs (offered -> active -> done); the GM sees the open ones."""
from roleplay import jobs
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM

BASE = {"summary": "Things happened.", "members": [], "recalled": [], "facts": [], "told": [], "new_entities": [],
        "moved_to": {"location": "", "description": "", "who": []}}


class JobsLLM(FakeLLM):
    """The memory pass only flags that a job moved; a second call (purpose 'jobs') reads the details."""

    def __init__(self, script):
        super().__init__()
        self.script, self.current, self.followups = list(script), [], 0

    def structured(self, model, system, user, schema, **kw):
        if "summary" in schema["properties"]:
            self.current = self.script.pop(0) if self.script else []
            return {**BASE, "job_moved": bool(self.current)}
        assert kw.get("purpose") == "jobs" and "JOBS ON FILE:" in user
        self.followups += 1
        return {"jobs": self.current}


def _game(make_game, script):
    g = make_game(JobsLLM(script))
    setup_demo(g)
    return g


def _job(change, title="", jid="", **kw):
    return {"id": jid, "change": change, "title": title, "client": kw.get("client", ""),
            "objective": kw.get("objective", ""), "pay": kw.get("pay", ""), "deadline": kw.get("deadline", ""),
            "progress": kw.get("progress", "")}


def test_a_job_goes_from_offer_to_done(make_game):
    g = _game(make_game, [
        [_job("new", "Lift the Renraku client list", client="kaz", objective="Copy the client list off the host",
              pay="5,000 nuyen on delivery")],
        [_job("active", jid="J1", deadline="before dawn", progress="Ghost is in the host")],
        [_job("new", "lift the renraku CLIENT list!", progress="the file is copied")],      # the same job again
        [],                                                                                   # small talk
        [_job("done", jid="J1", progress="Delivered to Kaz and paid")],
    ])
    t0 = g.turn_no()                                                        # (the demo seeds a few turns)
    g.run_turn([("razor", "Kaz, what's the job?")])
    j = jobs.get(g, "J1")
    assert (j["status"], j["client_id"], j["pay"], j["created_turn"]) == ("offered", "kaz", "5,000 nuyen on delivery",
                                                                          t0 + 1)
    assert "JOBS ON FILE:\n[J1] offered - Lift the Renraku client list; for Kaz [kaz]" in jobs.commit_lines(g)

    g.run_turn([("razor", "We're in.")])
    j = jobs.get(g, "J1")
    assert (j["status"], j["deadline"], j["pay"], j["updated_turn"]) == ("active", "before dawn",
                                                                         "5,000 nuyen on delivery", t0 + 2)
    packet, _ = build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)
    assert "=== THE JOB" in packet and "[J1] active - Lift the Renraku client list" in packet and "deadline: before dawn" in packet
    assert jobs.current(g.conn)["id"] == "J1"

    g.run_turn([("ghost", "Copying it now.")])
    assert len(jobs.all_jobs(g.conn)) == 1 and jobs.get(g, "J1")["progress"] == "the file is copied"
    g.run_turn([("razor", "Nice weather.")])
    assert g.llm.followups == 3                           # a quiet turn costs no second call

    g.run_turn([("razor", "Here's your list, Kaz.")])
    j = jobs.get(g, "J1")
    assert (j["status"], j["closed_turn"]) == ("done", t0 + 5) and jobs.current(g.conn) is None
    packet, _ = build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)
    assert "THE JOB" not in packet and jobs.commit_lines(g).endswith("(none)")
    assert g.conn.execute("SELECT COUNT(*) FROM events WHERE kind='job'").fetchone()[0] == 4      # audited


def test_strays_are_ignored_and_two_changes_a_turn_at_most(make_game):
    g = _game(make_game, [[_job("update", jid="J9", progress="?"), _job("done", progress="no title, no id")]])
    g.run_turn([("razor", "Hm.")])
    assert jobs.all_jobs(g.conn) == []
    assert jobs.apply(g, 2, [_job("bogus", "x"), _job("new", "A", jid=""), _job("new", "B"), _job("new", "C")]) == \
        ["JOB J1 offered: A", "JOB J2 offered: B"]                          # two changes a turn at most


def test_a_campaign_from_before_the_tracker_is_read_once(make_game):
    class ReadingLLM(FakeLLM):
        calls = 0

        def structured(self, model, system, user, schema, **kw):
            ReadingLLM.calls += 1
            assert kw.get("purpose") == "jobs" and "KNOWN PEOPLE" in user and "[T1]" in user
            return {"jobs": [{"title": "Courier run for Kaz", "client": "kaz", "objective": "Carry the chip uptown",
                              "pay": "2k", "deadline": "", "status": "done", "progress": "Delivered",
                              "first_turn": 1, "last_turn": 1}]}

    g = make_game(ReadingLLM())
    setup_demo(g)
    g.sub.write_slice(1, g.current_scene_id(), "Razor carried Kaz's chip uptown and got paid.", [("razor", "actor")], [])
    assert jobs.backfill(g) == ["J1"] and jobs.backfill(g) == [] and ReadingLLM.calls == 1
    j = jobs.get(g, "J1")
    assert (j["status"], j["client_id"], j["by"], j["closed_turn"]) == ("done", "kaz", "backfill", 1)
