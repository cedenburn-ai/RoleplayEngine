"""Coloured roll cards and help (```ansi blocks): the same words as before, coloured - and the owner can switch it off."""
import asyncio
import re

from roleplay.discord_bot import ansi
from roleplay.discord_bot.render import EMBED_LIMIT, MSG_LIMIT, card_messages
from roleplay.discord_bot.session import CampaignTable, help_cards
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.rules import sr_lite
from roleplay.setup import setup_demo

from .test_discord import FakeChannel

CODES = re.compile(r"\x1b\[[0-9;]*m")


def strip(s: str) -> str:
    return CODES.sub("", s)


def test_a_roll_card_is_coloured_without_changing_a_word(make_game):
    g = make_game()
    setup_demo(g)
    win = sr_lite.request_test(g.ledger, ScriptedDice([6, 6, 5, 4, 3, 1, 2, 2]), 1, "razor", "perception",
                               threshold=3, reason="Spot the tail", modifiers=[{"label": "Rain", "value": -1}])["card"]
    lose = sr_lite.request_test(g.ledger, ScriptedDice([1, 1, 1, 2, 4]), 1, "ghost", "stealth", threshold=2)["card"]
    hit = sr_lite.attack(g.ledger, ScriptedDice([6, 6, 5, 5, 4, 3, 2, 2, 2, 1, 1, 6, 4, 4, 3, 3, 2, 1, 3, 3, 3]), 1,
                         "razor", "kaz")["card"]
    for card in (win, lose, hit):
        assert strip(ansi.card_block(card)) == card                              # the words are untouched
    w = ansi.card_block(win)
    assert ansi.paint("[ROLL]", "1;36") in w and ansi.paint("SUCCESS", ansi.BOLD_GREEN) in w
    assert ansi.paint("6 6 5", ansi.BOLD_GREEN) in w and ansi.paint("1", ansi.RED) in w   # hits green, ones red
    assert ansi.paint(" - Rain 1", ansi.RED) in w and ansi.paint("3 hits", ansi.BOLD_WHITE) in w
    lo = ansi.card_block(lose)
    assert ansi.paint("CRITICAL GLITCH", ansi.BOLD_RED) in lo and ansi.paint("FAILURE", ansi.BOLD_RED) in lo
    h = ansi.card_block(hit)
    assert ansi.paint("HIT", ansi.BOLD_GREEN) in h and "takes" in h and "1 hits" not in strip(h)
    msgs = card_messages([win, lose, hit], color=True)
    assert len(msgs) == 1 and msgs[0].startswith("```ansi\n") and len(msgs[0]) <= MSG_LIMIT
    assert card_messages([win], color=False)[0].startswith("```\n[ROLL]")       # (plain, as before)


def test_the_help_screen_is_coloured_wrapped_and_complete():
    plain = "\n".join(c["description"] for c in help_cards())
    cards = help_cards(color=True)
    assert [c["title"] for c in cards] == [c["title"] for c in help_cards()]
    for c in cards:
        assert c["description"].startswith("```ansi\n") and len(c["description"]) <= EMBED_LIMIT
        body = strip(c["description"]).split("\n")[1:-1]
        assert all(len(x) <= ansi.WIDTH + 2 for x in body), c["title"]      # (+2: an emoji is drawn double-wide)
    coloured = " ".join(strip("\n".join(c["description"] for c in cards)).split())     # (wrapped lines rejoined)
    for cmd in re.findall(r"`([!/][^`]*)`", plain):
        assert " ".join(cmd.split()) in coloured, cmd                        # nothing lost in the colouring
    assert "\x1b[1;32m!undo\x1b[0m" in cards[1]["description"] and "\x1b[0;36m<name>\x1b[0m" in cards[1]["description"]


def test_the_owner_can_switch_colours_off(make_game):
    g = make_game()
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        card = "[ROLL] Razor: Perception + Intuition (threshold 2)\n  Roll   6 5 1 -> 2 hits\n  SUCCESS (net +0)"
        await t._post([("line", card)])
        assert ch.sent[-1]["text"].startswith("```ansi\n")
        await t.handle("1", "Alice", "!colors off", False, react)
        assert "owner" in ch.sent[-1]["text"] and t.colors_on()
        await t.handle("9", "Owner", "!colours off", False, react)
        assert "**off**" in ch.sent[-1]["text"] and not t.colors_on()
        await t._post([("line", card)])
        assert ch.sent[-1]["text"] == f"```\n{card}\n```"
        await t.close()
    asyncio.run(go())
