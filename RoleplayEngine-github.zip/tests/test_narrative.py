"""Story directions (narrative.py): the table steering the story from outside the turn - they stand in the packet
until the GM lands them or the table takes them back, and an undo never loses what the table asked for."""
import asyncio

import pytest

from roleplay import narrative
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.ledger import LedgerError
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text
from .test_discord import FakeChannel

COMMIT = {"summary": "Kaz takes a call.", "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}


def test_directions_stand_in_the_packet_until_removed(make_game):
    g = make_game(FakeLLM([], COMMIT))
    setup_demo(g)
    d = narrative.add(g, "Rook calls with a new job soon.", "1", "Alice")
    assert d["id"] == "D1" and narrative.get(g, "1")["text"] == "Rook calls with a new job soon."
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "I wait.")], 99)
    assert "=== STORY DIRECTIONS FROM THE TABLE" in packet and "[D1] Rook calls with a new job soon." in packet
    narrative.close(g, "d1", "removed", "1")
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "I wait.")], 99)
    assert "STORY DIRECTIONS" not in packet
    with pytest.raises(LedgerError, match="already removed"):
        narrative.close(g, "D1", "removed", "1")
    for i in range(narrative.MAX):
        narrative.add(g, f"Thread {i}", "1")
    with pytest.raises(LedgerError, match="already 10"):
        narrative.add(g, "one too many", "1")


def test_the_gm_lands_one_and_an_undo_brings_it_back(make_game):
    g = make_game(FakeLLM([([text("Kaz's phone buzzes: Rook, with work.\n<dm>\nnarrative D1: done\n</dm>")],
                            "end_turn")], COMMIT))
    setup_demo(g)
    narrative.add(g, "Rook calls with a new job soon.", "1", "Alice")
    res = g.run_turn([("razor", "Razor nurses his drink.")])
    assert any(c.startswith("[STORY] D1 done") for c in res.cards) and narrative.active(g) == []
    narrative.add(g, "Bring back Joey.", "2", "Bob")             # (the table, after the turn)
    g.undo()
    assert [d["id"] for d in narrative.active(g)] == ["D1", "D2"]  # the GM's done went with its turn; Bob's stays
    assert narrative.add(g, "Another.", "1")["id"] == "D3"         # (an id is never handed out twice)


def test_the_gm_cant_add_or_remove_by_other_words(make_game):
    g = make_game(FakeLLM([([text("The bar hums.\n<dm>\nnarrative D1: forget it\n</dm>")], "end_turn")], COMMIT))
    setup_demo(g)
    narrative.add(g, "Rook calls.", "1")
    g.run_turn([("razor", "Razor waits.")])
    assert [d["id"] for d in narrative.active(g)] == ["D1"]


def test_at_the_table(make_game):
    g = make_game(FakeLLM([], COMMIT))
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "Alice", "!narrative add Rook calls with a new job soon", False, react)
        assert "🧭 **D1** Rook calls with a new job soon" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!steer Joey comes back with a grudge", False, react)       # (bare text adds)
        assert "**D2** Joey comes back with a grudge" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!narrative", False, react)
        assert ch.sent[-1]["title"] == "🧭 Story directions" and "*Alice, T" in ch.sent[-1]["description"]
        await t.handle("2", "Bob", "!narrative remove D1", False, react)                      # (Alice's)
        assert "is Alice's" in ch.sent[-1]["text"] and len(narrative.active(g)) == 2
        await t.handle("1", "Alice", "!narrative remove D1", False, react)
        assert "**D1** removed" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!narrative clear", False, react)
        assert "for the campaign owner" in ch.sent[-1]["text"]
        await t.handle("9", "Owner", "!narrative clear", True, react)
        assert "Cleared **D2**" in ch.sent[-1]["text"] and narrative.active(g) == []
        await t.handle("9", "Owner", "!narrative remove D7", True, react)
        assert ch.sent[-1]["text"].startswith("⚠️ No direction D7")
        await t.close()
    asyncio.run(go())
