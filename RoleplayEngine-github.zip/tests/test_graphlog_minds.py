"""Minds per turn (roleplay/graphlog/minds.py, DESIGN.md §8f): beside every turn file, who everyone is and what's on
their mind - the attitude matrix, the views, what they were told, goals and hooks, who witnessed what, who was
together, what changed and why (the offscreen world, minds cooling, a new party, a story seed), a restart and an
undo, the backfill against the record, the reader, the cost - and nothing at the table reads it. No network."""
import gzip
import json
import re
import time
from pathlib import Path

import pytest

from roleplay import graphlog, newparty
from roleplay.dm import witness
from roleplay.dm.minds import COOL_EVERY, cool, reflect_scene
from roleplay.graphlog import fmt, minds, perspectives
from roleplay.graphlog.__main__ import main as cli
from roleplay.graphlog.backfill import backfill
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_graphlog import TALK, _demo, _reopen
from .test_newparty import demo_world
from .test_witness import _world as _witness_world
from .test_world import KAZ_INVESTIGATES, _play_story

ROOT = Path(__file__).resolve().parent.parent / "roleplay"


def _minds(g, turn: int) -> dict:
    return minds.read_minds(graphlog.log_dir(g.path), turn)


def _rows(doc, key) -> list[dict]:
    return fmt.rows_of(doc[key])


def _events(doc, kind=None, who=None) -> list[dict]:
    return [e for e in doc["events"] if (kind is None or e["kind"] == kind) and (who is None or e.get("who") == who)]


def _grudge(user):
    """Kaz's reflection holds a grudge; every other call is the memory pass's."""
    if user.startswith("CHARACTER: Kaz"):
        return {"beliefs": [{"about": "razor", "attitude": -3, "belief": "Kaz thinks Razor sold him out.",
                             "changed": True}]}
    return TALK


# ── forward: every part ─────────────────────────────────────────────────

def test_every_turn_writes_who_everyone_is_and_what_they_hold(make_game):
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    assert minds.minds_on_file(d) == graphlog.turns_on_file(d) == [1, 2, 3]   # (the seeded past has minds too)
    res = g.run_turn([("razor", "Kaz, who buys hot Renraku data? Tanaka?")])
    doc = _minds(g, res.turn_id)
    L, c = g.ledger, g.conn
    assert doc["schema"] == minds.SCHEMA and doc["kind"] == "minds" and doc["reconstructed"] is False
    assert doc["exactness"] == {"*": "exact"} and doc["meta"]["diff_since"] == res.turn_id - 1
    assert doc["meta"]["events_seq"] == c.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]
    chars = {r["id"]: r for r in _rows(doc, "characters")}
    assert set(chars) == {e["id"] for e in L.entities() if e["kind"] in minds.KINDS}
    razor = chars["razor"]
    assert razor["kind"] == "pc" and razor["player"] == "razor" and razor["condition"] == "ok"
    assert razor["scene"] == L.scene_of("razor") == g.current_scene_id() and razor["former_pc"] is None
    assert chars["kaz"]["control"] == g.control_of("kaz") == "gm"
    # the whole attitude matrix, every current view, every hearsay row with its teller and turn
    stats = {(r[0], r[1].split(":", 1)[1]): r[2] for r in c.execute(
        "SELECT entity_id, key, value FROM stats WHERE key LIKE 'attitude:%'")}
    assert {(r["holder"], r["about"]): r["value"] for r in _rows(doc, "attitudes")} == stats
    assert [[r["holder"], r["node"], r["how"], r["source"], r["turn"]] for r in _rows(doc, "knows")] == \
        [list(r) for r in c.execute("SELECT holder, node_id, how, source, turn FROM knows ORDER BY turn, rowid")]
    # who witnessed the turn's moment, who was together, what's on their minds
    assert doc["witnessing"] == [res.slice_id]
    assert sorted(map(tuple, doc["witnesses"][res.slice_id])) == sorted(
        (m, r) for m, r in g.sub.members_of(res.slice_id) if r in g.settings.knobs.witness_roles)
    sid = g.current_scene_id()
    assert [sid, "active", [x for x in L.roster(sid) if x in chars]] in doc["co_presence"]
    assert {"razor", "ghost"} <= set(doc["salience"])                       # (the PCs are always in play)
    top = doc["salience"]["razor"]
    assert {(res.slice_id, "witnessed"), ("T2", "witnessed")} <= {(n, how) for n, _, how in top}   # (T2: recalled)
    assert len(top) <= minds.TOP
    assert [r for _, r, _ in top] == sorted((r for _, r, _ in top), reverse=True)
    assert all(n != "razor" for n, *_ in top + doc["salience_people"]["razor"])   # (never themselves)
    assert "T<turn>.minds.json.gz" in (d / fmt.FORMAT_TXT).read_text(encoding="utf-8")


def test_views_numbers_goals_and_hooks_are_tables_and_events(make_game):
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    t = g.turn_no()
    reflect_scene(g, 1, t)                                    # (between turns: Kaz thinks the bar fight over)
    bid = g.sub.current_belief("kaz", "razor")["id"]
    from roleplay.dm import world
    aid = world.add_agenda(g, "kaz", "keep the Ancients out of the Lucky Shot", ["razor"], t, by="dm")
    hid = world.add_hook(g, "kaz", aid, "Kaz asks Razor to walk the Ancients' lieutenant out", ["razor"], t)
    nxt = g.run_turn([("razor", "Kaz?")]).turn_id
    doc = _minds(g, nxt)
    b = next(r for r in _rows(doc, "beliefs") if r["id"] == bid)
    assert (b["holder"], b["about"], b["attitude"], b["why"]) == ("kaz", "razor", -3, "belief")
    ev = _events(doc, "belief", "kaz")[0]
    assert ev["id"] == bid and ev["phase"] == "between" and ev["turn"] == t and ev["why"] == "belief"
    assert _events(doc, "attitude", "kaz") == [{"kind": "attitude", "who": "kaz", "about": "razor", "from": None,
                                                 "to": -3, "why": "belief", "phase": "between", "turn": t}]
    a = next(r for r in _rows(doc, "agendas") if r["id"] == aid)
    assert (a["actor"], a["status"], a["targets"], a["by"]) == ("kaz", "active", ["razor"], "dm")
    h = next(r for r in _rows(doc, "hooks") if r["id"] == hid)
    assert (h["actor"], h["agenda"], h["status"], h["about"]) == ("kaz", aid, "ready", ["razor"])
    assert {(e["kind"], e["id"], e["change"], e["why"]) for e in doc["events"] if e["kind"] in ("agenda", "hook")} \
        == {("agenda", aid, "new", "gm"), ("hook", hid, "new", "world")}
    cat = fmt.catalog_at(fmt.read_catalog(graphlog.log_dir(g.path)))
    assert cat[bid]["text"] == "Kaz thinks Razor sold him out." and "keep the Ancients out" in cat[aid]["text"]
    blob = json.dumps(doc)                                    # (the text is the catalog's, never the minds file's)
    assert "sold him out" not in blob and "keep the Ancients out" not in blob and "lieutenant" not in blob


def test_witnesses_are_the_witness_scopes_own_whispers_too(make_game):
    """A perspective is what they witnessed by witness.py's rule - a whisper's target is a member who may never have
    noticed - plus what they were told."""
    g, _, bar, slip, away = _witness_world(make_game)
    doc = _minds(g, g.run_turn([("razor", "Another one, Kaz.")]).turn_id)    # (the offscreen moment on file too)
    wit, told, _, facts = minds.perspective_sets(doc)
    for e in g.ledger.entities():
        if e["kind"] in minds.KINDS:
            sc = witness.Scope(g, e["id"])
            assert wit[e["id"]] == sc.witnessed and facts[e["id"]] == sc.facts, e["id"]
            assert told[e["id"]] >= set(sc.heard)                # (and what they heard: every knows row)
    assert f"T{slip}" in wit["ghost"] and f"T{slip}" not in wit["razor"]    # (Razor never noticed the tracker)
    assert ["razor", "target"] not in doc["witnesses"][f"T{slip}"] and away in wit["kaz"]


# ── between turns: each writer lands in the next file, with its why ─────

def test_an_offscreen_move_lands_in_the_next_file_as_the_worlds(make_game):
    g, llm = _play_story(make_game, [6] * 8, KAZ_INVESTIGATES)
    t = g.turn_no()
    g.world_pass()                                            # Kaz investigates, learns T4, feels -3, sends Mako
    g.llm.dm_script = [([text("Three orks peel off the wall.\n<dm>\nlanded H1: Mako's crew jumped Razor.\n</dm>")],
                        "end_turn")]
    g.llm.extraction = {"summary": "Mako's crew jumped Razor.", "recalled": [], "facts": [], "told": [],
                        "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                        "members": [{"id": "razor", "role": "target"}]}
    nxt = g.run_turn([("razor", "I keep walking.")]).turn_id
    doc = _minds(g, nxt)
    kaz = {(e["kind"], e.get("change")): e for e in _events(doc, who="kaz")}
    assert kaz[("belief", None)]["why"] == "world" and kaz[("belief", None)]["phase"] == "between"
    assert kaz[("attitude", None)]["to"] == -3 and kaz[("attitude", None)]["why"] == "world"
    assert kaz[("agenda", "new")]["why"] == "world" and kaz[("agenda", "new")]["turn"] == t
    assert kaz[("hook", "new")]["why"] == "world"
    assert kaz[("hook", "landed")]["why"] == "landed" and kaz[("hook", "landed")]["phase"] == "turn"
    learned = _events(doc, "learned", "kaz")
    assert learned == [{"kind": "learned", "who": "kaz", "node": "T4", "how": "discovered", "from": None,
                        "why": "world", "phase": "between", "turn": t}]
    assert _events(doc, "appeared", "mako")[0]["why"] == "world"
    w1 = doc["witnesses"]["W1"]
    assert {w for w, _ in w1} == {"kaz", "mako"} and "W1" in doc["witnessing"]
    assert "kaz" in doc["salience"] and doc["salience"]["kaz"][0][2] in ("witnessed", "agenda", "belief", "told")


def test_feelings_cooling_between_turns_land_as_cool(make_game):
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    reflect_scene(g, 1, g.turn_no())
    g.run_turn([("razor", "Kaz?")])
    g.set_clock(g.clock() + COOL_EVERY + 1)
    t = g.turn_no()
    assert cool(g, t)                                         # (a scene close or a new party's skip: between turns)
    nxt = g.run_turn([("razor", "Kaz, about the other night.")]).turn_id
    assert _events(_minds(g, nxt), "attitude", "kaz") == [{"kind": "attitude", "who": "kaz", "about": "razor",
                                                           "from": -3, "to": -2, "why": "cool", "phase": "between",
                                                           "turn": t}]


def test_a_new_party_lands_in_the_next_file_as_the_resets(make_game, tmp_path):
    calls = []
    g = demo_world(make_game, calls)
    t = g.turn_no()
    bid = g.sub.add_belief("tanaka", "kaz", "Tanaka thinks Kaz talks too much.", t)     # (the world, before the reset)
    g.ledger.set_stat("tanaka", "attitude:kaz", -1)
    g.ledger.log(t, "belief", "tanaka", {"about": "kaz", "attitude": -1, "belief": bid, "by": "world"})
    newparty.run(g, backup_root=tmp_path / "bk")
    nxt = g.run_turn([("razor", "Anyone here?")]).turn_id
    doc = _minds(g, nxt)
    before = _events(doc, "belief", "tanaka")
    assert [(e["why"], e["phase"], e.get("during")) for e in before] == [("world", "between", None)]
    for eid in ("razor", "ghost"):
        kind = _events(doc, "kind", eid)[0]
        assert (kind["from"], kind["to"], kind["why"], kind["phase"], kind["during"]) == \
            ("pc", "npc", "new-party", "between", "new-party")
        assert any(e["why"] == "new-party" for e in _events(doc, "belief", eid))
        assert any(e["change"] == "new" and e["why"] == "new-party" for e in _events(doc, "agenda", eid))
        assert _events(doc, "persona", eid)[0]["why"] == "new-party"
        row = next(r for r in _rows(doc, "characters") if r["id"] == eid)
        assert row["kind"] == "npc" and row["former_pc"] == t and row["player"] is None
    cooled = _events(doc, "attitude", "ghost")
    assert any(e["why"] == "cool" and e.get("during") == "new-party" for e in cooled)   # (three weeks apart)
    assert any(e["why"] == "world" for e in doc["events"] if e["kind"] in ("agenda", "hook"))   # (the catch-up)
    assert all(e["phase"] == "between" for e in doc["events"] if e.get("during"))


def test_askdm_between_turns_changes_no_mind(make_game):
    """!askdm writes a lookup touch (the turn file's) and maybe a doubt - never a view, a number or hearsay."""
    g = _demo(make_game)
    g.run_turn([("razor", "Kaz?")])
    g.askdm("razor", "What did Kaz say about Tanaka?")
    nxt = g.run_turn([("razor", "Tanaka, then.")]).turn_id
    assert not [e for e in _minds(g, nxt)["events"] if e["kind"] in ("belief", "attitude", "learned")]


# ── a restart, an undo, a failure ───────────────────────────────────────

def test_a_restart_between_turns_loses_no_mind(make_game, tmp_path):
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    g.run_turn([("razor", "Kaz?")])
    t = g.turn_no()
    reflect_scene(g, 1, t)                                    # (the bot then goes down before the next turn)
    g2 = _reopen(g, tmp_path, extraction=_grudge)
    try:
        assert g2.sub.recorder.minds_prev is None
        nxt = g2.run_turn([("razor", "Kaz, are we good?")]).turn_id
        doc = _minds(g2, nxt)
        assert doc["meta"]["diff_since"] == t and doc["exactness"] == {"*": "exact"}
        assert [(e["kind"], e["why"], e["phase"]) for e in _events(doc, who="kaz")
                if e["kind"] in ("belief", "attitude")] == [("belief", "belief", "between"),
                                                            ("attitude", "belief", "between")]
    finally:
        g2.close()


def test_undo_takes_a_turns_minds_with_it(make_game):
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    g.run_turn([("razor", "Kaz?")])
    reflect_scene(g, 1, g.turn_no())                          # (between turns: still in the record an undo restores)
    t = g.run_turn([("razor", "Kaz, about the other night.")]).turn_id
    d = graphlog.log_dir(g.path)
    assert _events(_minds(g, t), "belief", "kaz")
    g.ledger.set_stat("kaz", "attitude:ghost", 1)            # (a hand edit after it: the undo of it takes this back)
    hand = _events(_minds(g, g.run_turn([("razor", "One more.")]).turn_id), "attitude", "kaz")
    assert hand == [{"kind": "attitude", "who": "kaz", "about": "ghost", "from": None, "to": 1, "why": "unlogged",
                     "phase": None, "turn": None}]
    g.undo()
    g.undo()
    assert minds.minds_on_file(d)[-1] == t - 1 and g.sub.recorder.minds_prev is None
    again = g.run_turn([("razor", "Kaz, about the other night.")]).turn_id
    doc = _minds(g, again)
    assert again == t and doc["meta"]["diff_since"] == t - 1
    assert [e["why"] for e in _events(doc, "belief", "kaz")] == ["belief"]          # (between: kept, so again)
    assert ("kaz", "ghost") not in {(r["holder"], r["about"]) for r in _rows(doc, "attitudes")}


def test_a_minds_file_that_fails_costs_nothing_and_heals(make_game, monkeypatch):
    said = []
    g = make_game(FakeLLM(extraction=_grudge))
    g.out = said.append
    setup_demo(g)
    d = graphlog.log_dir(g.path)
    real = minds.build

    def boom(*a, **k):
        raise OSError("disk full")
    monkeypatch.setattr(minds, "build", boom)
    reflect_scene(g, 1, g.turn_no())
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    assert t in graphlog.turns_on_file(d) and t not in minds.minds_on_file(d)       # (the graph file stands)
    assert any("minds not written" in s and "disk full" in s for s in said)
    monkeypatch.setattr(minds, "build", real)
    nxt = g.run_turn([("razor", "Kaz, again.")]).turn_id
    doc = _minds(g, nxt)
    assert doc["meta"]["diff_since"] == t - 1 and _events(doc, "belief", "kaz")    # (the next one covers both)


def test_a_first_minds_file_on_a_world_with_history_says_partial(make_game):
    """Deployed onto a world already played (the minds files start now): no earlier file to diff against, so the
    events are only what the turn's own numbers date - backfill rebuilds the rest."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    for t in minds.minds_on_file(d):
        minds.minds_file(d, t).unlink()
    g.sub.recorder.minds_prev = None
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    doc = _minds(g, t)
    assert doc["exactness"]["events"].startswith("partial") and doc["meta"]["diff_since"] is None
    assert not _events(doc, "appeared") and doc["witnessing"] == [f"T{t}"]


# ── the backfill ────────────────────────────────────────────────────────

def _strip(doc: dict) -> dict:
    return {k: v for k, v in doc.items() if k != "meta"} | {"meta": {k: v for k, v in doc["meta"].items()
                                                                   if k not in ("written_at", "ms")}}


def _table(doc, key) -> list[str]:
    return sorted(map(str, doc[key]["rows"]))


def _goals(doc) -> set:
    return {(r["id"], r["actor"], r["steps"], tuple(r["targets"])) for r in _rows(doc, "agendas")}


def _ids(doc, key) -> set:
    return {r["id"] for r in _rows(doc, key)}


def _kinds(doc) -> dict:
    return {r["id"]: r["kind"] for r in _rows(doc, "characters")}


def _views(doc) -> list:
    """The view and number events, as a set to compare (the forward log's and the backfill's order may differ)."""
    return sorted((e["kind"], e.get("who"), e.get("about"), e.get("to"), e.get("why")) for e in doc["events"]
                  if e["kind"] in ("belief", "attitude"))


def test_backfill_rebuilds_the_minds_and_ends_on_the_record(make_game, tmp_path):
    """A world played forward - a whisper, the party leaving, an offscreen move with a feeling, a hook landed, a view
    formed and cooled between turns - rebuilt from history alone into a second folder: every exact field matches the
    forward files turn by turn, and the end state is the ledger's."""
    g, llm = _play_story(make_game, [6] * 8, KAZ_INVESTIGATES)
    g.world_pass()
    g.llm.extraction = {"summary": "Razor walked on through the rain.", "recalled": [], "facts": [], "told": [],
                        "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                        "members": [{"id": "razor", "role": "actor"}, {"id": "ghost", "role": "present"}]}
    g.run_turn([("razor", "I keep walking.")])
    time.sleep(1.1)                                           # (a cooling between turns, after the snapshot's second)
    g.set_clock(g.clock() + 3 * COOL_EVERY)
    cool(g, g.turn_no())
    g.run_turn([("ghost", "Coffee.")])
    fwd, out = graphlog.log_dir(g.path), tmp_path / "rebuilt"
    res = backfill(g.path, out, say=lambda s: None)
    chk = res["minds"]["check"]
    assert chk["attitudes"]["mismatch"] == [] and not chk["beliefs"]["missing"] and not chk["beliefs"]["extra"]
    assert chk["attitudes"]["record"] >= 1 and chk["after_last_snapshot"] == []
    assert minds.minds_on_file(out) == minds.minds_on_file(fwd)
    for t in minds.minds_on_file(fwd):
        a, b = minds.read_minds(fwd, t), minds.read_minds(out, t)
        assert b["reconstructed"] is True and b["exactness"]["attitudes"].startswith("exact")
        assert all(re.match(r"(exact|approximate|missing)\b", v) for v in b["exactness"].values()), b["exactness"]
        for key in ("attitudes", "beliefs", "knows"):
            assert a[key]["columns"] == b[key]["columns"] and _table(a, key) == _table(b, key), (t, key)
        for key in ("witnesses", "witnessing", "facts"):
            assert a[key] == b[key], (t, key)
        assert _goals(a) == _goals(b) and _ids(a, "hooks") == _ids(b, "hooks"), t
        assert _kinds(a) == _kinds(b) and _views(a) == _views(b), t
    # idempotent, and a forward minds file is never replaced without --force
    before = {t: _strip(minds.read_minds(out, t)) for t in minds.minds_on_file(out)}
    backfill(g.path, out, say=lambda s: None)
    assert {t: _strip(minds.read_minds(out, t)) for t in minds.minds_on_file(out)} == before
    kept = backfill(g.path, say=lambda s: None)["minds"]
    assert kept["written"] == [] and kept["skipped"] == minds.minds_on_file(fwd)
    assert all(not minds.read_minds(fwd, t)["reconstructed"] for t in minds.minds_on_file(fwd))
    forced = backfill(g.path, force=True, say=lambda s: None)["minds"]
    assert forced["written"] == minds.minds_on_file(fwd)
    assert minds.read_minds(fwd, forced["written"][-1])["reconstructed"]


def test_backfill_places_a_new_partys_minds_after_its_turn(make_game, tmp_path):
    """A reset happens long after its turn's snapshot (an owner's confirm): its lines' times put them in the next
    file, as the forward log does - and the record's end state still matches."""
    calls = []
    g = demo_world(make_game, calls)
    t = g.turn_no()
    time.sleep(1.1)
    newparty.run(g, backup_root=tmp_path / "bk")
    nxt = g.run_turn([("razor", "Anyone here?")]).turn_id
    res = backfill(g.path, tmp_path / "rebuilt", say=lambda s: None)
    assert res["minds"]["check"]["attitudes"]["mismatch"] == []
    a, b = _minds(g, nxt), minds.read_minds(tmp_path / "rebuilt", nxt)
    for key in ("attitudes", "beliefs"):
        assert _table(a, key) == _table(b, key), key
    kinds = {r["id"]: r["kind"] for r in _rows(minds.read_minds(tmp_path / "rebuilt", t), "characters")}
    assert kinds["razor"] == "pc" and {r["id"]: r["kind"] for r in _rows(b, "characters")}["razor"] == "npc"
    assert any(e["kind"] == "kind" and e["why"] == "new-party" for e in b["events"])


# ── the reader ──────────────────────────────────────────────────────────

def test_the_reader_tells_one_characters_story(make_game, capsys):
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    reflect_scene(g, 1, g.turn_no())
    t1 = g.run_turn([("razor", "Kaz?")]).turn_id
    g.set_clock(g.clock() + COOL_EVERY + 1)
    cool(g, g.turn_no())
    t2 = g.run_turn([("razor", "Kaz, about the other night.")]).turn_id
    d = graphlog.log_dir(g.path)
    m = perspectives.mind_at(d, "Kaz")
    assert m["turn"] == t2 and m["id"] == "kaz" and m["attitudes"] == {"razor": -2}
    assert m["beliefs"][0]["text"] == "Kaz thinks Razor sold him out." and m["beliefs"][0]["attitude"] == -3
    assert perspectives.mind_at(d, "razor")["toward"] == {"kaz": -2}
    assert f"T{t2}" in m["witnessed"] and m["where"]["scene"] == g.current_scene_id()
    assert m["salience"] and m["salience_source"] == "recorded" and m["salience"][0][3]   # (with its text)
    old = perspectives.mind_at(d, "kaz", t1)
    assert old["turn"] == t1 and old["attitudes"] == {"razor": -3}
    early = perspectives.mind_at(d, "kaz", 1)                 # (before any of it: no view yet)
    assert early["attitudes"] == {} and early["beliefs"] == []
    tl = perspectives.timeline(d, "kaz")
    mine = [(x["turn"], e["kind"], e.get("why")) for x in tl for e in x["events"] if e["for"] == "mine"]
    assert (t1, "belief", "belief") in mine and (t2, "attitude", "cool") in mine
    assert any(e["for"] == "about me" for x in perspectives.timeline(d, "razor") for e in x["events"])
    assert cli(["mind", str(g.path), "kaz"]) == 0
    out = capsys.readouterr().out
    assert out.startswith(f"Kaz [kaz] at T{t2}") and "-2 Razor [B1" in out and "(cool, between)" in out
    assert cli(["mind", "kaz", "--log", str(d), "--turn", str(t1)]) == 0
    assert f"at T{t1}" in capsys.readouterr().out
    with pytest.raises(SystemExit, match="nobody called 'Nobody'"):
        cli(["mind", str(g.path), "Nobody"])


def test_a_log_from_before_the_minds_still_reads(make_game):
    """Turn files from before the minds (schema 1, no sidecar): the graph reads as it did, and the reader says
    there's nothing for those turns rather than failing."""
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    for t in minds.minds_on_file(d):
        minds.minds_file(d, t).unlink()
    assert perspectives.mind_at(d, "razor") is None and perspectives.timeline(d, "razor") == []
    assert graphlog.read_turn(d, 3)["schema"] == fmt.SCHEMA == 1
    assert "No minds file" in perspectives.text(d, "razor")
    from roleplay.graphlog.analyze import analyze
    assert analyze(d, d / "a")["turns"] == 3


# ── what the record says outright: who hurt whom, a GM's fix, a rename, going home ──

def _hurt(g, attacker: str, target: str) -> None:
    """An attack the rules roll that lands (the attacker's dice hit; the defence and soak miss)."""
    from roleplay.engine.dice import ScriptedDice
    from roleplay.engine.rules import sr_lite
    for split in range(4, 14):
        sr_lite.attack(g.ledger, ScriptedDice([6] * split + [1] * 60), g.turn_no(), attacker, target,
                       reason="the GM's call")
        if sr_lite.condition(g.ledger, target) != "ok":
            return
    raise AssertionError("the attack never landed")


def test_who_hurt_whom_is_on_file(make_game):
    """Every attack the rules roll is an event (attacker, target, hit, boxes), and the condition it left says who did
    it; a heal says why; a repair line's death is dated and explained, not 'time'."""
    from roleplay.engine.rules import sr_lite
    g = _demo(make_game)
    g.run_turn([("razor", "Kaz?")])
    t = g.turn_no()
    _hurt(g, "razor", "kaz")
    doc = _minds(g, g.run_turn([("razor", "Sorry, Kaz.")]).turn_id)
    hit = [e for e in _events(doc, "attacked", "razor") if e["hit"]]
    assert hit and (hit[-1]["about"], hit[-1]["why"], hit[-1]["phase"], hit[-1]["turn"]) == \
        ("kaz", "attack", "between", t)
    assert hit[-1]["boxes"] > 0 and hit[-1]["target_status"] == sr_lite.condition(g.ledger, "kaz")
    hurt = _events(doc, "condition", "kaz")
    assert [(e["from"], e["why"], e["by"]) for e in hurt] == [("ok", "damage", "razor")]
    d = graphlog.log_dir(g.path)
    kaz = {(e["kind"], e["for"]) for x in perspectives.timeline(d, "kaz") for e in x["events"]}
    assert ("attacked", "about me") in kaz and ("attacked", "mine") in {
        (e["kind"], e["for"]) for x in perspectives.timeline(d, "razor") for e in x["events"]}
    t = g.turn_no()
    for track in ("physical", "stun"):
        sr_lite.heal(g.ledger, t, "kaz", track, 12, reason="a street doc")
    g.ledger.set_stat("tanaka", "physical_damage", 30)        # (an owner's repair script: he died offscreen)
    g.ledger.log(t, "repair", "tanaka", {"what": "died", "why": "bled out offscreen"})
    doc = _minds(g, g.run_turn([("razor", "Better?")]).turn_id)
    assert [(e["to"], e["why"], e.get("reason")) for e in _events(doc, "condition", "kaz")] == \
        [("ok", "heal", "a street doc")]
    assert [(e["to"], e["why"], e["reason"], e["phase"], e["turn"]) for e in _events(doc, "condition", "tanaka")] == \
        [("dead", "repair", "bled out offscreen", "between", t)]


def test_what_they_carry_and_what_changes_hands_is_on_file(make_game):
    """witness.Scope.known counts what a character carries: the minds file has it (holdings), and a hand-off
    (transfer_item) is an event - the giver's, about the one who got it - so information that travels on a thing
    leaves a trace."""
    g = _demo(make_game)
    stick, _ = g.introduce("item", "Sealed credstick", "a credstick with someone else's ledger on it")
    g.ledger.give("kaz", stick, 1)
    g.run_turn([("razor", "Kaz?")])
    t = g.turn_no()
    state = g.ledger.take("kaz", stick, 1)                  # (as the transfer_item tool does it)
    g.ledger.log(t, "transfer_item", "kaz", {"item": stick, "to": "razor", "qty": 1})
    g.ledger.give("razor", stick, 1, state)
    doc = _minds(g, g.run_turn([("razor", "Thanks for the stick.")]).turn_id)
    assert [(h["holder"], h["name"], h["qty"]) for h in _rows(doc, "holdings") if h["item"] == stick] == \
        [("razor", "Sealed credstick", 1)] and stick in witness.Scope(g, "razor").known()
    assert _events(doc, "handed") == [{"kind": "handed", "who": "kaz", "about": "razor", "item": stick, "qty": 1,
                                       "why": "gm", "phase": "between", "turn": t}]
    d = graphlog.log_dir(g.path)
    assert stick in {h["item"] for h in perspectives.mind_at(d, "razor")["carries"]}
    assert ("handed", "about me") in {(e["kind"], e["for"]) for x in perspectives.timeline(d, "razor")
                                      for e in x["events"]}
    assert "What I carry: " in perspectives.text(d, "razor")


def test_a_hook_the_gm_drops_is_the_gms_with_its_reason(make_game, tmp_path):
    """corrections.correct(..., 'hook'): the drop is the GM's, dated by its line and with the table's reason - not the
    world's silent housekeeping - forward and in the backfill alike."""
    from roleplay.dm import corrections, world
    g = _demo(make_game)
    t = g.turn_no()
    aid = world.add_agenda(g, "kaz", "keep the Ancients out of the Lucky Shot", ["razor"], t, by="dm")
    hid = world.add_hook(g, "kaz", aid, "Kaz asks Razor to walk the Ancients' lieutenant out", ["razor"], t)
    g.run_turn([("razor", "Kaz?")])
    at = g.turn_no()
    time.sleep(1.1)                                           # (the fix comes after the snapshot's second)
    corrections.correct(g, at, hid, "hook", reason="the table ruled it never happens")
    nxt = g.run_turn([("razor", "Kaz, again.")]).turn_id
    assert [e for e in _events(_minds(g, nxt), "hook") if e["change"] == "stale"] == [
        {"kind": "hook", "who": "kaz", "id": hid, "change": "stale", "about": ["razor"], "why": "gm",
         "reason": "the table ruled it never happens", "phase": "between", "turn": at}]
    backfill(g.path, tmp_path / "rebuilt", say=lambda s: None)
    status = {x: next(r["status"] for r in _rows(minds.read_minds(tmp_path / "rebuilt", x), "hooks") if r["id"] == hid)
              for x in (at, nxt)}
    assert status == {at: "ready", nxt: "stale"}             # (by its line - the actor has no next hook to guess by)


def test_a_rename_is_one_story_under_two_names(make_game, tmp_path):
    """The story reveals a name (`name <id>: ...`, !rename): an event says so, and the reader follows one id through
    every file whatever they were called - by either name. The backfill gives the old name back before it."""
    from roleplay.dm import speakers
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    reflect_scene(g, 1, g.turn_no())                          # (Kaz forms a view of Razor, under his old name)
    t1 = g.run_turn([("razor", "Kaz?")]).turn_id
    time.sleep(1.1)
    speakers.rename(g, "kaz", "Kazuo Ito", g.turn_no())
    t2 = g.run_turn([("razor", "Kazuo, again.")]).turn_id
    assert _events(_minds(g, t2), "renamed") == [{"kind": "renamed", "who": "kaz", "from": "Kaz", "to": "Kazuo Ito",
                                                  "why": "gm", "phase": "between", "turn": t1}]
    d = graphlog.log_dir(g.path)
    by_id = [x["turn"] for x in perspectives.timeline(d, "kaz")]
    assert t1 in by_id and [x["turn"] for x in perspectives.timeline(d, "Kazuo Ito")] == by_id \
        == [x["turn"] for x in perspectives.timeline(d, "Kaz")]
    assert perspectives.mind_at(d, "Kaz", t2)["id"] == perspectives.mind_at(d, "Kazuo Ito", t1)["id"] == "kaz"
    out = tmp_path / "rebuilt"
    backfill(g.path, out, say=lambda s: None)
    named = {x: next(r["name"] for r in _rows(minds.read_minds(out, x), "characters") if r["id"] == "kaz")
             for x in (t1, t2)}
    assert named == {t1: "Kaz", t2: "Kazuo Ito"}
    assert [(e["from"], e["to"]) for e in _events(minds.read_minds(out, t2), "renamed")] == [("Kaz", "Kazuo Ito")]


def test_a_runner_gone_home_stays_on_file_departed(make_game):
    """!characterledger checkin: a departure, dated and why ledger - not 'gone, unlogged' - and they stay in the
    table (their views and numbers still stand, under a holder on file), out of play; checking back in, a return."""
    from roleplay import charledger
    calls = []
    g = demo_world(make_game, calls)
    g.ledger.set_stat("ghost", "attitude:kaz", 1)
    t = g.turn_no()
    charledger.check_in(g, "ghost", write_backstory=False)
    doc = _minds(g, g.run_turn([("razor", "Where'd Ghost go?")]).turn_id)
    assert _events(doc, "departed") == [{"kind": "departed", "who": "ghost", "why": "ledger", "phase": "between",
                                         "turn": t}] and not _events(doc, "gone")
    row = next(r for r in _rows(doc, "characters") if r["id"] == "ghost")
    assert row["status"] == "departed" and "ghost" not in doc["salience"]
    assert ("ghost", "kaz") in {(r["holder"], r["about"]) for r in _rows(doc, "attitudes")}
    t = g.turn_no()
    assert charledger.check_out(g, "Ghost", "8", t) == ("ghost", True)
    doc = _minds(g, g.run_turn([("ghost", "I'm back.")]).turn_id)
    assert [(e["kind"], e["why"], e["turn"]) for e in _events(doc, who="ghost") if e["kind"] == "returned"] == \
        [("returned", "ledger", t)]


def test_the_reader_finds_what_is_aimed_at_someone(make_game):
    """A hook aimed at someone (its about: a list) and an attack on them are 'about me' in their timeline, as a goal
    aimed at them is; someone joining an outfit is in the outfit's."""
    from roleplay.dm import world
    g = _demo(make_game)
    t = g.turn_no()
    aid = world.add_agenda(g, "kaz", "keep the Ancients out of the Lucky Shot", ["razor"], t, by="dm")
    hid = world.add_hook(g, "kaz", aid, "Kaz asks Razor to walk the Ancients' lieutenant out", ["razor"], t)
    fid = world.ensure_faction(g, "The Ancients", t)
    world.join_faction(g, "joey-two-knives", fid, "lieutenant", t)
    g.run_turn([("razor", "Kaz?")])
    d = graphlog.log_dir(g.path)
    razor = {(e["kind"], e.get("id"), e["for"]) for x in perspectives.timeline(d, "razor") for e in x["events"]}
    assert {("agenda", aid, "about me"), ("hook", hid, "about me")} <= razor
    outfit = {(e["kind"], e["who"], e["for"]) for x in perspectives.timeline(d, fid) for e in x["events"]}
    assert ("joined", "joey-two-knives", "about me") in outfit
    assert "hook by Kaz: H1 new" in perspectives.text(d, "razor")


# ── a new party and a seed, in the planned order ──

def _movers(calls: list):
    """test_newparty's reads, with every offscreen actor of a catch-up pass moving somewhere."""
    from .test_newparty import brain
    base = brain(calls)

    def answer(user: str):
        out = base(user)
        if "WHAT JUST HAPPENED TO YOU" in user and isinstance(out, dict):
            name = re.match(r"(?:CHARACTER|FACTION): (.+?) \[", user).group(1)
            out = dict(out, whereabouts=[{"who": name, "where": f"{name} laid low in a Puyallup garage", "place": ""}])
        return out
    return answer


def test_the_old_crews_undated_changes_are_the_resets(make_game, tmp_path):
    """No line dates the old crew's new personas or their leaving the scene - the reset made them: between, at its
    turn, during new-party (FORMAT), as its pictures and views are."""
    calls = []
    g = demo_world(make_game, calls)
    t = g.turn_no()
    newparty.run(g, backup_root=tmp_path / "bk")
    doc = _minds(g, g.run_turn([("razor", "Anyone here?")]).turn_id)
    for eid in ("razor", "ghost"):
        mine = [e for e in _events(doc, who=eid) if e["kind"] in ("persona", "moved", "whereabouts", "picture")]
        assert {e["kind"] for e in mine} >= {"persona", "picture"}
        assert all((e["why"], e["phase"], e["turn"], e.get("during")) == ("new-party", "between", t, "new-party")
                   for e in mine), mine


def test_a_new_partys_catch_up_is_told_from_the_world_before_it(make_game, tmp_path, monkeypatch):
    """Review 2026-10-28: the catch-up passes' goals, steps, hooks, hearsay and newcomers write no line in the event
    log, so nothing dated them - they read as the world's moves just before the reset. The mark keeps where each table
    stood when the reset began (rows_after, beside events_after): a row above it is the reset's, one below the
    world's before it. And a move stamped at the reset's first minute is the world's before it too (cause()'s lower
    bound is strict)."""
    from roleplay.dm import world
    calls = []
    g = demo_world(make_game, calls)
    watcher, _ = g.introduce("npc", "Dock Watcher", "a kid who watches the bar", "civilian", turn=g.turn_no())
    g.run_turn([("razor", "Who's the kid?")])
    t = g.turn_no()

    def moves(who: str, tag: str) -> dict:                   # what the world does for Tanaka - before, and in the gap
        aid = world.add_agenda(g, "tanaka", f"find a buyer ({tag})", [], t, by="world")
        hid = world.add_hook(g, "tanaka", aid, f"Tanaka calls Razor ({tag})", ["razor"], t)
        g.sub.add_knows("tanaka", who, "discovered", None, t)
        eid, _ = g.introduce("npc", f"Runner {tag}", "a kid who runs messages", "civilian", turn=t)
        return {"agenda": aid, "hook": hid, "knows": who, "newcomer": eid}
    before = moves("T1", "before")
    world.move(g, watcher, "watching the Lucky Shot from across the street", None)       # (at the reset's first minute)
    run_pass, gap = world.run_pass, {}

    def catch_up(game, *a, **kw):
        out = run_pass(game, *a, **kw)
        gap.setdefault("rows", moves("T2", "gap"))
        return out
    monkeypatch.setattr(world, "run_pass", catch_up)
    newparty.run(g, backup_root=tmp_path / "bk")
    mark = next(m for m in fmt.read_marks(graphlog.log_dir(g.path)) if m["kind"] == "new-party")
    assert set(mark["rows_after"]) == set(minds.WATERMARKED) and mark["events_after"] is not None
    doc = _minds(g, g.run_turn([("razor", "Anyone here?")]).turn_id)

    def tags(ids: dict) -> list:
        evs = [e for e in doc["events"] if (e["kind"] in ("agenda", "hook") and e.get("change") == "new"
                                            and e["id"] in (ids["agenda"], ids["hook"]))
               or (e["kind"] == "learned" and e["who"] == "tanaka" and e["node"] == ids["knows"])
               or (e["kind"] == "appeared" and e["who"] == ids["newcomer"])]
        return sorted((e["kind"], e["phase"], e.get("during")) for e in evs)
    assert tags(before) == [("agenda", "between", None), ("appeared", "between", None), ("hook", "between", None),
                            ("learned", "between", None)]
    assert tags(gap["rows"]) == [("agenda", "between", "new-party"), ("appeared", "between", "new-party"),
                                 ("hook", "between", "new-party"), ("learned", "between", "new-party")]
    moved = _events(doc, "whereabouts", watcher)
    assert [(e["why"], e.get("during")) for e in moved] == [("world", None)]


def test_a_new_partys_catch_up_personas_are_its_own(make_game, tmp_path):
    """Review 2026-10-28 (of the watermark): the catch-up passes write NPCs' personas too - props, no line, no row - so
    they read as the world's moves before the reset. world.apply logs each persona it writes now, and the line dates it
    after the mark's events_after."""
    calls = []
    g = demo_world(make_game, calls)
    has = lambda: {e["id"] for e in g.ledger.entities() if (e["props"] or {}).get("persona")}    # noqa: E731
    before = has()
    newparty.run(g, backup_root=tmp_path / "bk")
    npcs = has() - before - {"razor", "ghost"}                       # (the old crew's are the reset's own anyway)
    assert npcs and g.conn.execute("SELECT COUNT(*) FROM events WHERE kind='persona'").fetchone()[0] >= len(npcs)
    doc = _minds(g, g.run_turn([("razor", "Anyone here?")]).turn_id)
    written = [e for e in doc["events"] if e["kind"] == "persona" and e["who"] in npcs]
    assert {e["who"] for e in written} == npcs
    assert all((e["why"], e["phase"], e.get("during")) == ("world", "between", "new-party") for e in written)


def test_a_new_partys_mark_survives_a_lost_buffer(make_game, tmp_path, monkeypatch):
    """The reset's mark rides the recorder's buffer into the next turn file - and marks.jsonl has it the moment it
    happens. A minds file that failed right after the reset, or a restart that dropped the buffer (the bot deployed
    onto a world with no log, the backfill run, the reset), still leaves the next minds file tagging the reset's own."""
    calls = []
    g = demo_world(make_game, calls)
    newparty.run(g, backup_root=tmp_path / "bk")

    def boom(*a, **k):
        raise OSError("disk full")
    real = minds.build
    monkeypatch.setattr(minds, "build", boom)
    t = g.run_turn([("razor", "Anyone here?")]).turn_id
    monkeypatch.setattr(minds, "build", real)
    doc = _minds(g, g.run_turn([("razor", "Still here?")]).turn_id)
    assert doc["meta"]["diff_since"] == t - 1
    for eid in ("razor", "ghost"):
        assert _events(doc, "kind", eid)[0].get("during") == "new-party"
        assert _events(doc, "persona", eid)[0]["why"] == "new-party"
    # the rollout: the bot up on a world with no log, the console's backfill, the reset, a restart, a turn
    import shutil
    from roleplay.art import ArtDirector, NullArtProvider
    from roleplay.game import Game
    from .test_newparty import brain
    g = demo_world(make_game, calls, ledger=False)
    d, path = graphlog.log_dir(g.path), g.path
    g.close()
    shutil.rmtree(d)
    up = lambda tag: Game(path, llm=FakeLLM([], brain(calls)), art=ArtDirector(  # noqa: E731
        tmp_path / f"art{tag}", "t", provider=NullArtProvider(), out=lambda s: None), out=lambda s: None)
    g = up("1")
    backfill(path, say=lambda s: None)
    newparty.run(g, backup_root=tmp_path / "bk2")
    g.close()
    g = up("2")
    try:
        nxt = g.run_turn([("razor", "Anyone here?")]).turn_id
        assert graphlog.read_turn(d, nxt)["process"]["marks"] == []        # (the buffer's copy went with the restart)
        doc = minds.read_minds(d, nxt)
        assert all(_events(doc, "kind", eid)[0].get("during") == "new-party" for eid in ("razor", "ghost"))
    finally:
        g.close()


# ── the seam: the first exact file after a backfill ──

def test_the_first_forward_file_after_a_backfill_invents_nothing(make_game, tmp_path):
    """A world played before the minds, rebuilt, then a forward turn: the backfill replays the heals and places
    today's whereabouts by the story clock, so the seam doesn't report a heal from turns ago or an old move as new -
    and what the rebuild only guessed (a scene left with no line) says basis: reconstructed, why reconstruction, in a
    file whose events read approximate."""
    from roleplay.dm import world
    from roleplay.engine.rules import sr_lite
    g = _demo(make_game)
    time.sleep(1.1)                                           # (each between-turns line after its snapshot's second)
    _hurt(g, "razor", "kaz")
    hurt = g.run_turn([("razor", "Kaz, I'm sorry.")]).turn_id
    time.sleep(1.1)
    for track in ("physical", "stun"):
        sr_lite.heal(g.ledger, g.turn_no(), "kaz", track, 12, reason="a street doc")
    world.move(g, "tanaka", "lying low at a cousin's in Puyallup", None)
    g.ledger.leave(1, ["joey-two-knives"])                    # (out of the old bar scene - no line says so)
    healed = g.run_turn([("razor", "Better?")]).turn_id
    d = graphlog.log_dir(g.path)
    for t in minds.minds_on_file(d):                          # (as if it was all played before the minds existed)
        minds.minds_file(d, t).unlink()
    backfill(g.path, say=lambda s: None)
    rebuilt = {t: {r["id"]: r for r in _rows(minds.read_minds(d, t), "characters")} for t in (hurt, healed)}
    assert rebuilt[hurt]["kaz"]["condition"] == "wounded" and rebuilt[healed]["kaz"]["condition"] == "ok"
    assert rebuilt[healed]["tanaka"]["whereabouts"] and minds.read_minds(d, healed)["meta"]["story_time"] is not None
    g.sub.recorder.minds_prev = None
    doc = _minds(g, g.run_turn([("razor", "Kaz, one more.")]).turn_id)
    assert doc["meta"]["diff_since"] == healed and doc["exactness"]["events"].startswith("approximate")
    assert not fmt.exact(doc, "events")
    assert not _events(doc, "condition", "kaz") and not _events(doc, "whereabouts", "tanaka")
    assert [(e["why"], e["basis"], e["phase"]) for e in _events(doc, "moved", "joey-two-knives")] == \
        [("reconstruction", "reconstructed", None)]
    assert "how sure" in perspectives.text(d, "joey")


def test_a_backfill_after_a_reset_keeps_the_reset_after_its_turn(make_game, tmp_path):
    """The backfill run (or run again) after a new party: the rumors its scene close spread are the next file's, as
    the forward log has them - and the old crew's personas, which the reset wrote, aren't theirs from turn 1."""
    calls = []
    g = demo_world(make_game, calls)
    t = g.turn_no()
    time.sleep(1.1)
    newparty.run(g, backup_root=tmp_path / "bk")
    nxt = g.run_turn([("razor", "Anyone here?")]).turn_id
    fwd, out = graphlog.log_dir(g.path), tmp_path / "rebuilt"
    backfill(g.path, out, say=lambda s: None)
    told = lambda doc: sorted((r["holder"], r["node"], r["how"]) for r in _rows(doc, "knows"))  # noqa: E731
    assert told(minds.read_minds(out, t)) == told(minds.read_minds(fwd, t))
    heard = lambda doc: sorted((e["who"], e["node"], e["phase"], e.get("during"))  # noqa: E731
                               for e in _events(doc, "learned"))
    assert heard(minds.read_minds(fwd, nxt)) and heard(minds.read_minds(out, nxt)) == heard(minds.read_minds(fwd, nxt))
    for x in range(1, t + 1):
        rows = {r["id"]: r for r in _rows(minds.read_minds(out, x), "characters")}
        assert rows["razor"]["persona"] is None and rows["ghost"]["persona"] is None, x
    assert {r["id"]: r["persona"] for r in _rows(minds.read_minds(out, nxt), "characters")}["razor"]
    assert "persona:razor" not in fmt.catalog_at(fmt.read_catalog(out), t)


def test_a_backfill_leaves_a_turn_a_forward_file_already_covers(make_game, monkeypatch):
    """A minds file that failed heals in the next (diff_since the one before): the backfill doesn't fill the hole
    with a rebuilt one, and the reader never counts a turn's events twice."""
    g = make_game(FakeLLM(extraction=_grudge))
    setup_demo(g)
    d = graphlog.log_dir(g.path)
    g.run_turn([("razor", "Kaz?")])
    real = minds.build
    monkeypatch.setattr(minds, "build", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    reflect_scene(g, 1, g.turn_no())
    gap = g.run_turn([("razor", "Kaz, again?")]).turn_id
    monkeypatch.setattr(minds, "build", real)
    g.run_turn([("razor", "Kaz, one more.")])
    res = backfill(g.path, say=lambda s: None)["minds"]
    assert res["covered"] == [gap] and gap not in minds.minds_on_file(d)
    views = [e["id"] for x in perspectives.timeline(d, "kaz") for e in x["events"] if e["kind"] == "belief"]
    assert len(views) == len(set(views)) == 1


def test_minds_that_stop_are_a_flag_and_in_status(make_game, monkeypatch, capsys):
    """A minds file failing turn after turn: the turn files go on, turns.csv says which turns have no minds file, the
    status line counts them, and a flag goes up once (the console line alone is easy to miss)."""
    from roleplay import flags
    g = _demo(make_game)
    d = graphlog.log_dir(g.path)
    good = g.run_turn([("razor", "Kaz?")]).turn_id
    monkeypatch.setattr(minds, "snapshot", lambda game: (_ for _ in ()).throw(KeyError("a row it can't read")))
    bad = [g.run_turn([("razor", f"Kaz, {i}?")]).turn_id for i in range(3)]
    rows = fmt.read_csv(d)
    assert rows[good]["minds_bytes"].isdigit() and all(rows[t]["minds_bytes"] == "" for t in bad)
    up = [f for f in flags.listing(g.path.parent, campaign=g.path.stem) if "minds files stopped" in f["text"]]
    assert len(up) == 1 and f"after T{good}" in up[0]["text"]
    assert cli(["status", str(g.path)]) == 0
    out = capsys.readouterr().out
    have = minds.minds_on_file(d)
    assert have[-1] == good and f"minds: {len(have)} file(s) T{have[0]}..T{good}" in out \
        and f"no minds file beside {len(bad)} turn file(s)" in out \
        and "stopped" in out


def test_the_graph_log_package_keeps_lf_line_endings():
    """The graph log's files are LF (as the rest of the package always was): a whole file rewritten CRLF made every
    line differ, so any edit another build made in parallel merged as one conflict the size of the file."""
    crlf = [p.name for p in sorted((ROOT / "graphlog").glob("*.py")) if b"\r\n" in p.read_bytes()]
    assert crlf == []


# ── what it costs ───────────────────────────────────────────────────────

def _big_world(g, npcs: int = 70, slices: int = 900) -> None:
    """A world the live one's size in minds: ~70 characters, ~900 moments, a hundred views and rumors."""
    import random
    rnd = random.Random(7)
    L, S, c = g.ledger, g.sub, g.conn
    c.execute("BEGIN")
    ids = [g.introduce("npc", f"Extra {i}", f"someone on the strip number {i}", "civilian", turn=g.turn_no())[0]
           for i in range(npcs)]
    people = ids + ["razor", "ghost", "kaz"]
    for i in range(slices):
        who = rnd.sample(people, 4)
        S.write_offscreen(g.turn_no(), f"Moment {i}: {who[0]} and {who[1]} talked.",
                          [(who[0], "actor"), (who[1], "target"), (who[2], "present"), (who[3], "mentioned")])
    for i in range(120):
        h, a = rnd.sample(people, 2)
        bid = S.add_belief(h, a, f"{h} thinks {a} is trouble ({i}).", g.turn_no())
        L.set_stat(h, f"attitude:{a}", rnd.randint(-3, 3))
        L.log(g.turn_no(), "belief", h, {"about": a, "attitude": 0, "belief": bid})
    for i in range(240):
        S.add_knows(rnd.choice(people), f"W{rnd.randint(1, slices)}", "rumor", rnd.choice(people), g.turn_no())
    c.execute("COMMIT")


def test_the_minds_add_well_under_a_quarter_second_to_a_turn(make_game):
    g = _demo(make_game)
    _big_world(g)
    t = g.run_turn([("razor", "Kaz?")]).turn_id
    doc = _minds(g, t)
    assert doc["meta"]["characters"] >= 70 and len(doc["witnesses"]) >= 900
    took = []
    for _ in range(3):                                        # (the forward path: the last file's state cached)
        prev = minds.state_of(doc)
        ratios = {r[0]: r[6] for r in graphlog.read_turn(graphlog.log_dir(g.path), t)["nodes"]["rows"]}
        t0 = time.perf_counter()
        minds.build(g, t + 1, ratios, prev, "x")
        took.append(time.perf_counter() - t0)
    assert min(took) < 0.25, took                            # (the live world's: ~17 ms)
    assert doc["meta"]["ms"] < 1000


# ── nothing at the table reads it ───────────────────────────────────────

PLAYER_SURFACES = ["recap.py", "chronicle.py", "charsheet.py", "dossier.py", "dm/aside.py", "dm/witness.py",
                   "dm/turn.py", "dm/research.py", "substrate/packet.py", "dashboard", "discord_bot", "browser"]
READS_MINDS = re.compile(r"\bread_minds\(|\bminds_on_file\(|\bminds_file\(|\bmind_at\(|\.minds\.json|"
                         r"graphlog\.(?:minds|perspectives)\b|graphlog\s+import\s+[^\n]*\b(?:minds|perspectives)\b")


def test_no_player_facing_surface_reads_the_minds(make_game, monkeypatch):
    """The minds files are GM-side through and through (every NPC's view, the sealed, the goals): no view at the table
    - the dashboard's player views, recaps, the aside, !askdm - reads them. The source says so, and with every way to
    read them booby-trapped, each still answers."""
    for rel in PLAYER_SURFACES:
        p = ROOT / rel
        for f in ([p] if p.is_file() else sorted(p.rglob("*.py"))):
            assert not READS_MINDS.search(f.read_text(encoding="utf-8")), f
    g = _demo(make_game)
    g.run_turn([("razor", "Kaz?")])
    reads = []

    def trap(*a, **k):
        reads.append(a)
        raise AssertionError("a player-facing surface read the minds")
    real_open, real_read = gzip.open, Path.read_bytes
    monkeypatch.setattr(minds, "read_minds", trap)
    monkeypatch.setattr(perspectives, "mind_at", trap)
    monkeypatch.setattr(gzip, "open", lambda f, *a, **k: trap(f) if ".minds." in str(f) else real_open(f, *a, **k))
    monkeypatch.setattr(Path, "read_bytes", lambda self: trap(self) if ".minds." in self.name else real_read(self))
    from roleplay import chronicle, recap
    from roleplay.dashboard import data
    from roleplay.dm import aside
    assert g.askdm("razor", "What did Kaz say?")
    aside.ask(g, "Jo (plays Razor [razor])", "Hey DM, who's Tanaka again?", "razor")
    assert recap.gather(g) is not None and recap.subject(g, "kaz")
    assert chronicle.record(g, "razor")
    assert data.people(g.path.stem, folder=g.path.parent)["party"]
    assert data.overview(g.path.stem, folder=g.path.parent) and data.story(g.path.stem, folder=g.path.parent)
    assert reads == []
