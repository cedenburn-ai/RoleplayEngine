"""Who plays whom: players, the GM (companions), idle - and stepping into NPCs."""
import asyncio

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm.turn import _user_message
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


def test_control_defaults_and_overrides(make_game):
    g = make_game()
    setup_demo(g)
    assert g.control_of("razor") == "idle" and g.control_of("kaz") == "gm"     # nobody holds Razor: parked
    g.set_companions(True)                                   # (that's only about an !afk player's character now)
    assert g.control_of("ghost") == "idle"                   # unclaimed isn't a companion - nobody made them one
    g.conn.execute("INSERT INTO players(discord_id, handle, name) VALUES('9', 'ghost', 'Bob')")
    assert g.control_of("ghost") == "player"
    g.conn.execute("UPDATE players SET afk=1")
    assert g.control_of("ghost") == "gm"                     # away: the GM covers
    g.set_control("razor", "gm")
    assert g.control_of("razor") == "gm"                     # a companion someone made


def test_character_for_inhabited_npc(make_game):
    g = make_game()
    setup_demo(g)
    assert g.character_for("razor")["id"] == "razor"
    assert g.character_for("kaz") is None                    # nobody is in Kaz yet
    g.conn.execute("INSERT INTO players(discord_id, handle, name) VALUES('9', 'kaz', 'Bob')")
    assert g.character_for("kaz")["id"] == "kaz" and g.control_of("kaz") == "player"
    brief = g.catch_up("kaz")
    assert "Kaz" in brief and "N1" not in brief              # their sheet and memories, never the GM's notes


def test_dm_is_told_who_plays_whom(make_game):
    g = make_game()
    setup_demo(g)
    g.set_control("ghost", "gm")                             # a companion
    g.conn.execute("INSERT INTO players(discord_id, handle, name) VALUES('1', 'razor', 'Alice')")
    msg = _user_message(g, "(packet)", [("razor", "I lean on the bar.")], g.current_scene_id(), 9)
    assert "Played by humans (never write their dialogue, thoughts, choices or actions" in msg and "posts happens): Razor." in msg
    assert "PCs YOU are playing as companions until a player takes over: Ghost." in msg
    g.conn.execute("INSERT INTO players(discord_id, handle, name) VALUES('2', 'kaz', 'Bob')")
    msg = _user_message(g, "(packet)", [("razor", "Well?"), ("kaz", "I polish a glass.")], g.current_scene_id(), 9)
    assert "Kaz [kaz]: I polish a glass." in msg and "NPCs a human is inhabiting right now" in msg


def test_discord_join_switch_leave_and_dmplay(tmp_path, make_game):
    g = make_game(FakeLLM())
    setup_demo(g)
    g.set_companions(True)
    g.set_control("ghost", "gm")                             # Ghost is a companion; Razor is just parked

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        say = lambda uid, text: t.handle(uid, f"user{uid}", text, False, react)   # noqa: E731
        await say("1", "!join razor")
        assert "<@1> is playing **Razor**" in ch.sent[-1]["text"] and ch.dms[-1][0] == "1"
        await say("2", "!join ghost")
        assert "takes over **Ghost** from the GM" in ch.sent[-1]["text"]
        await say("1", "!join ghost")                        # Ghost is Bob's: asking, not taking
        assert ch.sent[-1]["title"] == "🔐 user1 asks to play Ghost" and t.handles["2"] == "ghost"
        await say("2", "!no")
        await say("2", "!join tanaka")
        assert "isn't in this scene" in ch.sent[-1]["text"]
        await say("2", "!join kaz")                          # Bob steps into Kaz; Ghost is parked, not GM-played
        assert "steps into **Kaz**" in ch.sent[-1]["text"] and "**Ghost** steps out of the story" in ch.sent[-1]["text"]
        assert "You're playing Kaz" in ch.dms[-1][1]
        assert t.expected == {"razor", "kaz"} and g.control_of("ghost") == "idle"
        assert "ghost" not in g.ledger.roster(g.current_scene_id())
        await say("2", "!who")
        who = ch.sent[-1]["text"]
        assert "**Kaz** (<@2>)" in who and "Ghost" not in who
        await say("2", "!leave")
        assert "steps away from **Kaz**" in ch.sent[-1]["text"] and "the GM plays them for now" in ch.sent[-1]["text"]
        assert g.character_for("kaz") is None and t.expected == {"razor"}
        await say("1", "!afk")
        assert "the GM plays **Razor** for now" in ch.sent[-1]["text"] and t.expected == set()
        await say("1", "!back")
        await say("2", "!dmplay razor")                      # not the owner
        assert "campaign owner" in ch.sent[-1]["text"]
        await say("1", "!idle razor")                        # the owner benches their own seat
        assert "**Razor** will hang back quietly" in ch.sent[-1]["text"] and "<@1> is off the seat" in ch.sent[-1]["text"]
        assert g.control_of("razor") == "idle"
        await say("1", "!join razor")                        # rejoining clears the override
        await say("1", "!leave")                             # a PC nobody holds steps out of the story
        assert "**Razor** steps out of the story" in ch.sent[-1]["text"] and g.control_of("razor") == "idle"
        assert "razor" not in g.ledger.roster(g.current_scene_id())
        await say("1", "!companion razor")                   # ...unless someone makes them a companion
        assert "**Razor** is a companion now" in ch.sent[-1]["text"] and g.control_of("razor") == "gm"
        assert "razor" in g.ledger.roster(g.current_scene_id())
        await say("1", "!park razor")
        assert "🅿️ **Razor** steps out" in ch.sent[-1]["text"] and g.control_of("razor") == "idle"
        await say("1", "!companions off")
        assert "Companions **off**" in ch.sent[-1]["text"] and g.control_of("razor") == "idle"
        await t.close()
    asyncio.run(go())


def test_time_command(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 60, "cap": 60, "grace": 1})

        async def react(e):
            pass
        await t.handle("2", "Bob", "!time", False, react)
        assert ch.sent[-1]["text"] == "🕒 Day 1, night"
        await t.handle("2", "Bob", "!time +1h", False, react)
        assert "owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!time teatime", False, react)
        assert ch.sent[-1]["text"].startswith("⚠️ can't read a time")
        await t.handle("1", "Owner", "!time 02:15", False, react)
        assert ch.sent[-1]["text"] == "🕒 Day 2, late night"
        await t.handle("1", "Owner", "!time tomorrow morning", False, react)       # (at 2 a.m., hours away)
        assert ch.sent[-1]["text"] == "🕒 Day 2, morning"
        await t.close()
    asyncio.run(go())


def test_askgm_works_and_typos_get_a_suggestion(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!join razor", False, react)
        await t.handle("2", "Bob", "!askgm what's my firearms pool?", False, react)
        assert ch.dms[-1][0] == "2" and ch.dms[-1][1].startswith("**You asked:** what's my firearms pool?")
        await t.handle("2", "Bob", "!charactersheat", False, react)
        assert ch.sent[-1]["text"] == "❓ No `!charactersheat` - did you mean `!charactersheet`? (`!help` lists them)"
        await t.handle("2", "Bob", "!xyzzy", False, react)
        assert ch.sent[-1]["text"] == "❓ No `!xyzzy` (`!help` lists them)"
        await t.whisper("2", "!askgm can Kaz see me?", ch)                    # in DMs too
        assert ch.sent[-1]["text"].startswith("**You asked:** can Kaz see me?")
        await t.close()
    asyncio.run(go())


def test_a_newline_after_the_command_is_fine(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!join razor", False, react)
        await t.handle("2", "Bob", "!askdm\n\nI have a question.\nHow much damage?", False, react)   # as phones send it
        assert ch.dms[-1][1].startswith("**You asked:** I have a question.\nHow much damage?")
        await t.handle("2", "Bob", "!askgm\nsecond line", False, react)
        assert ch.dms[-1][1].startswith("**You asked:** second line")
        await t.handle("2", "Bob", "!", False, react)                       # a bare bang doesn't crash
        await t.close()
    asyncio.run(go())


class AskChannel(FakeChannel):
    """A channel with reaction buttons, like Discord."""
    async def ask(self, content, card, emojis, holder=None):
        self.sent.append({"text": content, "title": card["title"], "description": card["description"],
                          "footer": None, "image": None, "emojis": emojis})
        return f"m{len(self.sent)}"


def test_nobody_takes_a_seat_without_the_players_say_so(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)
    g.set_companions(True)

    async def go():
        ch = AskChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        say = lambda uid, text: t.handle(uid, f"user{uid}", text, False, react)   # noqa: E731
        await say("1", "!join razor")
        await say("2", "!join ghost")
        await say("1", "!join ghost")
        card = ch.sent[-1]
        assert card["text"] == "<@2>" and card["emojis"] == ["✅", "❌"] and "<@2>: react ✅" in card["description"]
        key = next(iter(t.requests))
        await say("1", "!yes")                               # the asker can't approve their own ask
        assert "Nobody's asking for your character" in ch.sent[-1]["text"]
        await t.reaction(key, "3", "✅")                       # neither can a bystander
        assert t.handles["2"] == "ghost" and key in t.requests
        await t.reaction(key, "2", "❌")
        assert "keeps **Ghost**" in ch.sent[-1]["text"] and not t.requests
        await say("1", "!join ghost")
        key = next(iter(t.requests))
        await t.reaction(key, "2", "✅")
        texts = [m["text"] or "" for m in ch.sent[-3:]]
        assert any("hands **Ghost** to <@1>" in x for x in texts) and any("is playing **Ghost**" in x for x in texts)
        assert t.handles.get("1") == "ghost" and "2" not in t.handles and g.control_of("razor") == "idle"
        await say("2", "!join razor")                        # Razor was parked: free to take
        assert t.handles["2"] == "razor"
        await say("2", "!join ghost")
        t.requests[next(iter(t.requests))]["expires"] = 0     # asks expire
        await say("1", "!yes")
        assert "Nobody's asking" in ch.sent[-1]["text"] and t.handles["1"] == "ghost"
        await t.close()
    asyncio.run(go())


def test_one_player_cant_act_for_another(make_game):
    from roleplay.dm.turn import _user_message
    g = make_game()
    setup_demo(g)
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('1','razor','A',0), ('2','ghost','B',0)")
    msg = _user_message(g, "", [("razor", "I tell Ghost to shoot the guard, and he does.")], g.current_scene_id(), 5)
    assert "Each human decides only for their own character" in msg
    g.conn.execute("DELETE FROM players WHERE discord_id='2'")
    msg = _user_message(g, "", [("razor", "I shoot.")], g.current_scene_id(), 5)
    assert "Each human decides" not in msg                  # (one human at the table: nothing to guard)


def test_the_gm_knows_who_is_at_the_table_but_silent(make_game):
    from roleplay.dm.turn import _user_message
    g = make_game()
    setup_demo(g)
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('1','razor','A',0), ('2','ghost','B',0)")
    g.active_players = {"razor", "ghost"}
    msg = _user_message(g, "", [("razor", "I pick the lock.")], g.current_scene_id(), 5)
    assert "At the table but silent this turn (active in the last few minutes): Ghost." in msg
    g.active_players = {"razor"}                                     # Ghost's player wandered off: no nudge...
    msg = _user_message(g, "", [("razor", "I pick the lock.")], g.current_scene_id(), 5)
    assert "silent this turn" not in msg and "Away right now (no sign of their player for 10+ minutes): Ghost." in msg
    g.active_players = {"razor", "ghost"}
    whisper = _user_message(g, "", [("razor", "I palm it.")], g.current_scene_id(), 5, g.ledger.get("razor"))
    assert "silent this turn" not in whisper                         # never invite the table into a whisper


def test_activity_is_tracked_per_player(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        t = CampaignTable(g, FakeChannel(), owner_id="9")
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "A", "!join razor", False, react)
        await t.handle("2", "B", "!join ghost", False, react)
        await t.handle("2", "B", "!who", False, react)
        assert t.active_players() == {"razor", "ghost"}
        t.last_active["ghost"] -= 3600
        assert t.active_players() == {"razor"}
        t.typing("2")
        assert "ghost" in t.active_players()
        await t.close()
    asyncio.run(go())


def test_a_post_while_away_is_held_until_they_say_theyre_back(make_game):
    """!afk, then a post: the bot asks (✅ back in / ✖️ stay away) and holds the move until they answer."""
    g = make_game(FakeLLM())
    setup_demo(g)
    g.set_companions(True)

    async def go():
        ch = AskChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 30, "cap": 60, "grace": 0.05})
        await t.refresh()
        reacts = []

        async def react(e):
            reacts.append(e)
        await t.handle("2", "Alice", "!join razor", False, react)
        await t.handle("2", "Alice", "!afk", False, react)
        assert "is away" in ch.sent[-1]["text"] and "2" in t.away

        await t.handle("2", "Alice", "I check the back door.", False, react)
        card = ch.sent[-1]
        assert card["title"] == "💤 You're marked away" and "The GM is playing **Razor** for you" in card["description"]
        assert reacts[-1] == "⏸️" and t.director.queue == []                       # held, not in the turn
        await t.handle("2", "Alice", "And I keep my gun low.", False, react)
        assert len([m for m in ch.sent if m["title"] == "💤 You're marked away"]) == 1   # one card, both held

        await t.reaction(f"m{len(ch.sent)}", "3", "✅")                              # not theirs to answer
        assert t.director.queue == []
        await t.reaction(f"m{len(ch.sent)}", "2", "✅")
        assert "is back - **Razor** is yours again - your post's in" in ch.sent[-1]["text"]
        assert [x for _, x in t.director.queue] == ["I check the back door.", "And I keep my gun low."]
        assert "2" not in t.away and g.control_of("razor") == "player"

        t.director.queue.clear()
        await t.handle("2", "Alice", "!afk", False, react)
        await t.handle("2", "Alice", "brb lol", False, react)
        await t.handle("2", "Alice", "!no", False, react)                           # typed answers work too
        assert "stays away - your post was set aside" in ch.sent[-1]["text"] and t.director.queue == []
        await t.handle("2", "Alice", "ok I'm here", False, react)
        await t.handle("2", "Alice", "!back", False, react)                         # !back answers the card: in
        assert "your post's in" in ch.sent[-1]["text"] and [x for _, x in t.director.queue] == ["ok I'm here"]
        await t.close()
    asyncio.run(go())


def test_a_companion_is_made_on_purpose(make_game):
    """Built for the GM (the builder's 🎭 button / `done gm`), or handed over with !companion: the GM plays them and the
    builder keeps their own seat. Someone else's seated character isn't yours to hand over."""
    from roleplay import chargen as C
    g = make_game(FakeLLM())
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        say = lambda uid, text: t.handle(uid, f"user{uid}", text, False, react)   # noqa: E731
        await say("1", "!join razor")
        d = C.new_draft("street_samurai", "elf")
        d.update(name="Quiet Lou", pronouns="she/her", look="Wiry elf with throwing knives.", for_gm=True)
        await t.finish_chargen("1", "user1", d)
        assert ch.sent[-1]["title"] == "🎭 Quiet Lou joins the crew" and "the GM plays them" in ch.sent[-1]["description"]
        sam = g.ledger.find("Quiet Lou")
        assert g.control_of(sam["id"]) == "gm" and t.handles["1"] == "razor"           # Alice still plays Razor
        assert sam["id"] in g.ledger.roster(g.current_scene_id())
        await say("2", "!join ghost")
        await say("1", "!companion ghost")                   # Bob's seat: not Alice's to hand over
        assert "only they (or the campaign owner)" in ch.sent[-1]["text"] and g.control_of("ghost") == "player"
        await say("2", "!companion ghost")                   # Bob hands his own over
        assert "**Ghost** is a companion now" in ch.sent[-1]["text"] and "2" not in t.handles
        d2 = C.new_draft("decker", "human")
        d2.update(name="Wire", pronouns="he/him", look="Thin human decker in a hoodie.")
        await t.finish_chargen("1", "user1", d2)           # a new runner of your own parks the old one
        assert t.handles["1"] == "wire" and "**Razor** steps out of the story" in ch.sent[-1]["description"]
        assert g.control_of("razor") == "idle"
        await t.close()
    asyncio.run(go())


def test_a_player_undo_needs_the_table(make_game):
    """A player's !undo asks everyone else at the table; one ❌ keeps the turn, everyone's ✅ takes it back."""
    extraction = {"summary": "Razor kicked the door.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "razor", "role": "actor"}]}
    from .conftest import text
    g = make_game(FakeLLM([([text("The door holds.")], "end_turn"), ([text("It holds again.")], "end_turn")],
                          extraction))
    setup_demo(g)

    async def go():
        ch = AskChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        say = lambda uid, text_: t.handle(uid, f"user{uid}", text_, False, react)   # noqa: E731
        await say("1", "!join razor")
        await say("2", "!join ghost")
        g.run_turn([("razor", "I kick the door.")])
        turn = g.turn_no()
        await say("1", "!undo")
        card = ch.sent[-1]
        assert card["title"] == f"↩️ user1 wants to take back turn T{turn}" and card["text"] == "<@2>"
        assert "Razor kicked the door." in card["description"] and card["emojis"] == ["✅", "❌"]
        key = next(iter(t.undo_votes))
        await t.reaction(key, "1", "✅")                       # the asker's own ✅ doesn't count
        assert key in t.undo_votes and g.turn_no() == turn
        await say("2", "!no")
        assert "<@2> keeps turn" in ch.sent[-1]["text"] and g.turn_no() == turn
        await say("1", "!undo")
        await t.reaction(next(iter(t.undo_votes)), "2", "✅")
        assert "(the table agreed)" in ch.sent[-1]["text"] and g.turn_no() == turn - 1
        assert "messages from that turn stay in the channel" in ch.sent[-1]["text"]   # (what undo can't do, said)
        await say("2", "!afk")                               # alone at the table: just done
        g.run_turn([("razor", "I kick it again.")])
        await say("1", "!undo")
        assert "Undid turn" in ch.sent[-1]["text"] and not t.undo_votes
        assert "doesn't change the numbers" in ch.sent[-1]["text"]
        await t.close()
    asyncio.run(go())
