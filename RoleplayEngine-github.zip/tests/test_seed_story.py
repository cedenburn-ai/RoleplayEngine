"""Story seeds end to end (seed.py, DESIGN.md §12l) on an invented story - the ferry dock of test_spoiler_guard:
a story splits into what the players may read and the GM's half, seeds come out of seeds/ (or there are none), and the
console reads one into a world - spoiler-free unless asked - and files it."""
import pytest

from roleplay import seed
from roleplay.art import ArtDirector, NullArtProvider
from roleplay.engine.ledger import LedgerError
from roleplay.game import Game
from roleplay.setup import setup_demo

from .conftest import FakeLLM
from .test_spoiler_guard import GM, MEMORY, NAMES, PLAYER, plan


def test_a_story_splits_into_what_the_players_may_read_and_the_gms_half():
    both = seed.split("night-ferry.md", f"{PLAYER}\n\n{GM}")
    assert [(d.name, d.gm) for d in both] == [("night-ferry.md", False), ("night-ferry.md (for the GM)", True)]
    assert "Corwin" not in both[0].text and both[1].text.startswith("## For the GM only")
    assert [d.gm for d in seed.split("night-ferry.GM-SECRETS.md", PLAYER)] == [True]    # the file's name says so
    docs, skipped = seed.parse(f"A pasted pitch.\n<<<file: ferry.md>>>\n{PLAYER}\n<<<skipped: map.png>>>\n"
                               f"<<<file: ferry.secret.txt>>>\n{GM}")
    assert [(d.name, d.gm) for d in docs] == [("pasted", False), ("ferry.md", False), ("ferry.secret.txt", True)]
    assert skipped == ["map.png"]


def test_seeds_come_out_of_the_seeds_folder_and_no_folder_is_no_seeds(tmp_path):
    folder = tmp_path / "seeds"
    assert seed.available(folder) == []
    with pytest.raises(LedgerError, match="No seed called 'night-ferry' in seeds/."):
        seed.from_seeds("night-ferry", folder)
    folder.mkdir()
    (folder / "night-ferry.GM-SECRETS.md").write_text(GM, encoding="utf-8")
    (folder / "night-ferry.md").write_text(PLAYER, encoding="utf-8")
    (folder / "notes.txt").write_text("another one", encoding="utf-8")
    assert seed.available(folder) == ["night-ferry", "notes"]
    docs = seed.from_seeds("night-ferry.md", folder)
    assert [(d.name, d.gm) for d in docs] == [("night-ferry.md", False), ("night-ferry.GM-SECRETS.md", True)]
    with pytest.raises(LedgerError, match="there's night-ferry, notes"):
        seed.from_seeds("rent", folder)
    with pytest.raises(LedgerError, match="letters, numbers"):
        seed.from_seeds("../night-ferry", folder)


def test_the_console_reads_a_story_previews_it_spoiler_free_and_files_it(tmp_path):
    art = lambda: ArtDirector(tmp_path / "art", "test", provider=NullArtProvider(), out=lambda s: None)  # noqa: E731
    path = tmp_path / "world.db"
    g = Game(path, llm=FakeLLM([], MEMORY), art=art(), out=lambda s: None)
    setup_demo(g)
    g.close()
    (tmp_path / "night-ferry.md").write_text(PLAYER, encoding="utf-8")
    (tmp_path / "night-ferry.GM.md").write_text(GM, encoding="utf-8")
    files = [str(tmp_path / "night-ferry.md"), str(tmp_path / "night-ferry.GM.md")]
    asked = []
    llm = FakeLLM([], lambda user: asked.append(user) or plan())          # the read: cast, threads, opening
    out = []
    assert seed.main([str(path), *files, "--dry-run"], llm=llm, art=art(), out=out.append) == 0
    assert len(asked) == 3 and all("THE GM-ONLY STORY" in u and "Corwin Vale" in u for u in asked)
    shown = "\n".join(out)
    assert "The Night Ferry" in shown and not [n for n in NAMES if seed._says(shown, n)]      # spoiler-free
    out.clear()
    assert seed.main([str(path), *files], llm=llm, art=art(), out=out.append, ask=lambda q: "n") == 1
    assert out[-1] == "Cancelled - nothing written."
    out.clear()
    assert seed.main([str(path), *files, "--yes"], llm=llm, art=art(), out=out.append) == 0
    assert "The Night Ferry is in the world" in out[-1] and not [n for n in NAMES if seed._says(out[-1], n)]
    g = Game(path, llm=FakeLLM([], MEMORY), art=art(), out=lambda s: None)
    try:
        assert [a["title"] for a in seed.applied(g)] == ["The Night Ferry"]
        assert g.ledger.find("the harbormaster") is not None
    finally:
        g.close()
    assert seed.main([str(tmp_path / "nope.db"), *files], llm=llm, out=out.append) == 2
