"""The party roster: the whole crew on one card for the table (`!party`, `/party`)."""
import asyncio
import threading
import time

from PIL import Image

from roleplay import rosterart
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .test_discord import FakeChannel


def test_the_crew_is_read_from_the_ledger(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('2', 'ghost', 'Bob', 1)")
    L.set_stat("razor", "physical_damage", 4)
    L.set_stat("razor", "stun_damage", 2)
    ent = L.get("ghost")
    L.update_entity("ghost", props={**ent["props"], "sustained": [{"spell": "invisibility", "target": "razor",
                                                                  "force": 4, "hits": 2}]})
    people = rosterart.crew(g)
    assert [m["id"] for m in people] == ["ghost", "razor"]               # the seated first, then the GM's
    ghost, razor = people
    assert ghost["player"] == "Bob" and ghost["away"] and razor["player"] is None
    assert ghost["sustained"] == ["Invisibility Force 4 on Razor"]          # not 'F4': that reads as a drain code
    assert razor["status"] == "wounded" and razor["physical"][0] == 4 and razor["penalty"] >= 1
    assert razor["weapon"]["name"] == "Ares Predator V" and razor["explosives"] == ["2× HE grenade"]
    assert razor["where"] and razor["edge"][1] >= 1

    out = rosterart.render(g, people, g.path.parent / "sheets" / "party.png")
    assert Image.open(out).size == (rosterart.W, rosterart.TOP + 2 * (rosterart.STRIP + rosterart.GAP) + 18)
    text = rosterart.text(razor)
    assert "**Razor**" in text and "WOUNDED" in text and "Physical `▰▰▰▰" in text


def test_if_drawing_fails_the_crew_goes_out_as_text(make_game, monkeypatch):
    g = make_game()
    setup_demo(g)

    def broken(*a, **k):
        raise OSError("no fonts")
    monkeypatch.setattr(rosterart, "render", broken)
    card = rosterart.cards(g)[0]
    assert card["title"] == "🛡️ The crew" and "**Razor**" in card["description"] and "**Ghost**" in card["description"]


def test_party_posts_for_the_table_even_mid_turn(make_game):
    g = make_game()
    setup_demo(g)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        gate = threading.Event()
        busy = t.loop.run_in_executor(t.pool, gate.wait, 30)     # the GM, mid-turn, on the game thread
        t0 = time.time()
        await t.handle("2", "Bob", "!party", False, react)
        assert time.time() - t0 < 5 and ch.sent[-1]["title"] == "🛡️ The crew" and ch.sent[-1]["image"]
        await t.handle("2", "Bob", "!crew", False, react)                 # (the names people reach for)
        assert ch.sent[-1]["title"] == "🛡️ The crew"
        gate.set()
        await busy
        await t.close()
    asyncio.run(go())
