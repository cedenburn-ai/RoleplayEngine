"""keys.py: config.toml, then the environment, then the Windows user environment, then (the token only) the old token
file - and never a key in a message."""
import codecs
import os
import sys
import tomllib
from types import SimpleNamespace

import pytest

from roleplay import keys
from roleplay.config import ROOT

SECRETS = ("tok-from-config", "tok-from-env", "tok-from-registry", "tok-from-file", "ant-from-config",
           "ant-from-env", "oai-from-config", "oai-from-registry")


@pytest.fixture
def place(tmp_path, monkeypatch):
    """Nothing set anywhere: a config file that isn't there yet, no variables, no user environment, no token file."""
    for var in keys.ENV.values():
        monkeypatch.setenv(var, "")                     # (so what export_api_keys sets is put back afterwards)
        monkeypatch.delenv(var)
    monkeypatch.setenv("ROLEPLAY_CONFIG", str(tmp_path / "config.toml"))
    monkeypatch.setenv("ROLEPLAY_TOKEN_FILE", str(tmp_path / "Program.cs"))
    monkeypatch.setattr(keys, "_exported", {})
    registry: dict = {}
    monkeypatch.setattr(keys.sys, "platform", "win32")
    monkeypatch.setitem(sys.modules, "winreg", _winreg(registry))
    return SimpleNamespace(dir=tmp_path, registry=registry,
                           config=lambda body: (tmp_path / "config.toml").write_text(body, encoding="utf-8"),
                           token_file=lambda tok: (tmp_path / "Program.cs").write_text(
                               f'const string DISCORD_TOKEN = "{tok}";\n', encoding="utf-8"))


def _winreg(values: dict):
    """A stand-in for the registry's HKCU\\Environment."""
    class Key:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def query(key, name):
        if name not in values:
            raise FileNotFoundError(name)
        return values[name], 1
    return SimpleNamespace(HKEY_CURRENT_USER=1, OpenKey=lambda root, path: Key(), QueryValueEx=query)


def test_config_wins_then_the_environment_then_the_user_environment_then_the_token_file(place, monkeypatch):
    place.config('[keys]\ndiscord_token = "tok-from-config"\n')
    monkeypatch.setenv("DISCORD_BOT_TOKEN", "tok-from-env")
    place.registry["DISCORD_BOT_TOKEN"] = "tok-from-registry"
    place.token_file("tok-from-file")
    assert (keys.get("discord_token"), keys.source("discord_token")) == ("tok-from-config", str(place.dir / "config.toml"))
    place.config("[keys]\n")
    assert (keys.get("discord_token"), keys.source("discord_token")) == ("tok-from-env", "environment")
    monkeypatch.delenv("DISCORD_BOT_TOKEN")
    assert (keys.get("discord_token"), keys.source("discord_token")) == ("tok-from-registry", "user environment")
    del place.registry["DISCORD_BOT_TOKEN"]
    assert (keys.get("discord_token"), keys.source("discord_token")) == ("tok-from-file", str(place.dir / "Program.cs"))
    (place.dir / "Program.cs").unlink()
    assert keys.get("discord_token") is None and keys.source("discord_token") is None


def test_blanks_and_placeholders_dont_count(place, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-from-env")
    for blank in ('""', '"   "', '"..."', '"your-anthropic-key"', '"<paste it here>"', '"changeme"', '"xxxx"', "3"):
        place.config(f"[keys]\nanthropic_api_key = {blank}\n")
        assert keys.get("anthropic_api_key") == "ant-from-env", blank
    monkeypatch.setenv("ANTHROPIC_API_KEY", "your-key-here")
    assert keys.get("anthropic_api_key") is None
    place.config('[keys]\nanthropic_api_key = "  ant-from-config  "\n')                 # (trimmed, not refused)
    assert keys.get("anthropic_api_key") == "ant-from-config"


def test_the_config_is_config_toml_at_the_root_unless_roleplay_config_names_another(place, monkeypatch):
    monkeypatch.delenv("ROLEPLAY_CONFIG")
    assert keys.config_path() == ROOT / "config.toml"
    monkeypatch.setattr(keys, "ROOT", place.dir)
    monkeypatch.setattr(keys, "CONFIG", place.dir / "config.toml")
    place.config('[keys]\nopenai_api_key = "oai-from-config"\n')
    assert keys.source("openai_api_key") == "config.toml"                                 # (named from the root)
    other = place.dir / "elsewhere" / "mine.toml"
    other.parent.mkdir()
    other.write_text('[keys]\nopenai_api_key = "oai-from-config"\n', encoding="utf-8")
    (place.dir / "config.toml").unlink()
    monkeypatch.setenv("ROLEPLAY_CONFIG", str(other))
    assert keys.get("openai_api_key") == "oai-from-config"
    assert keys.source("openai_api_key") == str(other.relative_to(place.dir))


def test_a_broken_config_says_where_never_what(place, monkeypatch, capsys):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-from-env")
    place.config('[keys]\nanthropic_api_key = "ant-from-config\n')                     # (unterminated)
    assert keys.get("anthropic_api_key") == "ant-from-env"                              # the environment still works
    why = keys.problem()
    assert why.startswith("config.toml isn't valid TOML") and "line 2" in why and "ant-from" not in why
    place.config('anthropic_api_key = "ant-from-config"\n')
    assert keys.problem() == "config.toml has no [keys] table" and keys.get("anthropic_api_key") == "ant-from-env"
    (place.dir / "config.toml").unlink()
    assert "isn't there" in keys.problem()                                            # ROLEPLAY_CONFIG names it
    monkeypatch.delenv("ROLEPLAY_CONFIG")
    monkeypatch.setattr(keys, "CONFIG", place.dir / "config.toml")
    assert keys.problem() is None                                                     # no file at all is fine
    assert capsys.readouterr() == ("", "")


def test_a_config_windows_saved_is_read(place, monkeypatch):
    """Review 2026-10-28: Windows PowerShell 5 writes UTF-16 (`>`, Out-File) or UTF-8 with a BOM (Set-Content
    -Encoding UTF8), and Notepad offers both - the first crashed every entry point, the second was refused as bad
    TOML. Both are read now; a file that isn't UTF-8 at all says so, and the environment still works."""
    body = '[keys]\ndiscord_token = "tok-from-config"\n'
    monkeypatch.setenv("DISCORD_BOT_TOKEN", "tok-from-env")
    cfg = place.dir / "config.toml"
    for raw in (body.encode("utf-8-sig"), body.encode("utf-16"), codecs.BOM_UTF16_BE + body.encode("utf-16-be")):
        cfg.write_bytes(raw)
        assert keys.get("discord_token") == "tok-from-config" and keys.problem() is None
    cfg.write_bytes(("# café\n" + body).encode("cp1252"))
    assert keys.get("discord_token") == "tok-from-env"
    assert keys.problem().startswith("config.toml isn't UTF-8 text - save it as UTF-8")


def test_the_console_wont_start_without_the_gms_key(place, monkeypatch, capsys):
    """Review 2026-10-28: `python -m roleplay` with no Anthropic key seeded the demo, then died on the first turn in
    the SDK's traceback, never naming config.toml. It refuses up front now, as the bot does - before it opens a world -
    and says first what's wrong with a config.toml that's there."""
    from roleplay import console
    monkeypatch.setattr(console, "CAMPAIGN_DIR", place.dir / "campaigns")
    place.config("[keys]\nanthropic_api_key = unquoted\n")
    with pytest.raises(SystemExit) as exc:
        console.main(["demo"])
    assert str(exc.value).startswith("No Anthropic API key - the GM can't think without one: put anthropic_api_key in "
                                     "config.toml")
    assert "config.toml isn't valid TOML" in capsys.readouterr().out and not (place.dir / "campaigns").exists()


def test_the_old_token_file_is_for_the_discord_token_only(place, monkeypatch):
    place.token_file("tok-from-file")
    assert keys.get("discord_token") == "tok-from-file"
    assert keys.get("anthropic_api_key") is None and keys.get("openai_api_key") is None
    monkeypatch.delenv("ROLEPLAY_TOKEN_FILE")
    monkeypatch.setattr(keys, "TOKEN_FILE", place.dir / "DungeonsAndDiscords" / "Program.cs")
    assert keys.get("discord_token") is None                                          # (the old project isn't here)
    (place.dir / "DungeonsAndDiscords").mkdir()
    (place.dir / "Program.cs").rename(place.dir / "DungeonsAndDiscords" / "Program.cs")
    assert keys.get("discord_token") == "tok-from-file"
    (place.dir / "DungeonsAndDiscords" / "Program.cs").write_text("// no token in here\n", encoding="utf-8")
    assert keys.get("discord_token") is None


def test_export_puts_the_api_keys_in_the_environment_and_the_token_nowhere(place, monkeypatch):
    place.config('[keys]\ndiscord_token = "tok-from-config"\nanthropic_api_key = "ant-from-config"\n')
    monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-from-env")
    place.registry["OPENAI_API_KEY"] = "oai-from-registry"
    assert keys.export_api_keys() == ["anthropic_api_key", "openai_api_key"]
    assert os.environ["ANTHROPIC_API_KEY"] == "ant-from-config"                       # config.toml wins
    assert os.environ["OPENAI_API_KEY"] == "oai-from-registry"
    assert "DISCORD_BOT_TOKEN" not in os.environ
    assert keys.source("openai_api_key") == "user environment"                        # (where it was found, still)
    st = keys.status()
    assert st == {"discord_token": str(place.dir / "config.toml"), "anthropic_api_key": str(place.dir / "config.toml"),
                  "openai_api_key": "user environment", "config": str(place.dir / "config.toml"), "error": None}


def test_no_registry_off_windows(place, monkeypatch):
    monkeypatch.setattr(keys.sys, "platform", "linux")

    class NoRegistry:
        def __getattr__(self, name):
            raise AssertionError("winreg touched off Windows")
    monkeypatch.setitem(sys.modules, "winreg", NoRegistry())
    place.registry["ANTHROPIC_API_KEY"] = "ant-from-registry"
    assert keys.get("anthropic_api_key") is None and keys.source("anthropic_api_key") is None
    assert keys.export_api_keys() == []
    monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-from-env")
    assert keys.get("anthropic_api_key") == "ant-from-env"


def test_nothing_is_ever_printed(place, monkeypatch, capsys):
    place.config('[keys]\ndiscord_token = "tok-from-config"\nanthropic_api_key = "ant-from-config"\n'
                 'openai_api_key = "oai-from-config"\n')
    place.token_file("tok-from-file")
    keys.export_api_keys()
    told = [keys.source(n) for n in keys.ENV] + [keys.how_to_set(n) for n in keys.ENV] + [str(keys.status())]
    out = capsys.readouterr()
    assert out == ("", "")
    assert not any(s in t for s in SECRETS for t in told)


def test_the_example_config_parses_and_sets_nothing(place, monkeypatch):
    example = ROOT / "config.example.toml"
    with open(example, "rb") as f:
        table = tomllib.load(f)["keys"]
    assert set(table) == set(keys.ENV) and not any(table.values())
    monkeypatch.setenv("ROLEPLAY_CONFIG", str(example))
    assert keys.problem() is None and all(keys.get(n) is None for n in keys.ENV)
