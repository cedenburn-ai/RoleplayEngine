"""In-game shops: the GM stocks a place from the catalog (SR5's prices and Availability); runners buy there with real
nuyen - off the shelf, or delivered when the story clock gets there."""
import asyncio

import pytest

from roleplay import chargen, shops
from roleplay.discord_bot.session import CampaignTable
from roleplay.dm.tools import TurnContext, dispatch
from roleplay.engine import clock
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import explosives, machines, sr_lite
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM
from .test_discord import FakeChannel


def test_the_gm_stocks_a_shop_and_runners_buy(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    ctx = TurnContext(g, 5, g.current_scene_id())
    out = dispatch(ctx, "open_shop", {"location_id": "the-lucky-shot", "name": "Kaz's back room", "kind": "gun shop",
                                      "items": ["heavy-pistol", "smartlink", "fly-spy", "laser-cannon", "frag-grenade"],
                                      "markup": 1.2, "legal": True})
    assert "heavy-pistol 870" in out and "laser-cannon" in out                 # 725 x 1.2; unknown key reported
    assert "frag-grenade (11F: Forbidden - a legal shop can't stock it)" in out
    packet = build_packet(g, g.current_scene_id(), [], 6)[0]
    assert "SHOP HERE: Kaz's back room" in packet and "Ares Predator V 870¥ x2 (Avail 5R)" in packet
    L.set_stat("razor", "nuyen", 5000)
    ctx.posted = {"razor"}                                                     # (his money: his player's word)
    card = dispatch(ctx, "buy", {"buyer_id": "razor", "item": "heavy-pistol"})
    assert card.startswith("[SHOP] Razor buys Ares Predator V at Kaz's back room for 870") and L.stat("razor", "nuyen") == 4130
    gun = next(i for i in L.holdings("razor") if i["name"] == "Razor's Ares Predator V")
    assert not sr_lite.arriving(gun)                                            # a legal shop's shelf: here now
    ess = L.stat("razor", "essence")
    L.set_stat("razor", "nuyen", 10000)
    shops.buy(g, "razor", "smart", 1, 5)                                        # chrome is installed on the spot
    assert round(L.stat("razor", "essence"), 2) == round(ess - 0.2, 2)
    with pytest.raises(LedgerError, match="Ghost has 2,000"):
        shops.buy(g, "ghost", "fly", 1, 5)                                      # 2,400 at this markup
    L.set_stat("ghost", "nuyen", 3000)
    res = shops.buy(g, "ghost", "fly", 1, 5)
    assert len(machines.owned_by(L, "ghost")) == 2                              # (Ghost's own Fly-Spy + the new one)
    spy = L.require(res["entities"][0])
    assert spy["props"]["autosofts"] == {} and not L.holdings(spy["id"])       # the book's frame: nothing bundled
    shops.buy(g, "razor", "heavy-pistol", 1, 5)                                 # the second of two
    with pytest.raises(LedgerError, match="doesn't sell"):
        shops.buy(g, "razor", "heavy-pistol", 1, 5)                             # sold out


def test_book_prices_and_availability_on_every_item():
    """The owner's call (2026-10-24): the catalog is SR5's own prices and Availability. Live T182-T187: a Steel Lynx went
    for 8,100 (book 25,000, 10R), a Doberman cost more than a Roto-drone, and nothing had an Availability at all."""
    C = chargen.CATALOG
    assert all("avail" in v for v in C.values())
    book = {"fly-spy": 2000, "crawler": 4000, "roto-drone": 5000, "doberman": 5000, "steel-lynx": 25000,
            "smg": 730, "heavy-pistol": 725, "assault-rifle": 2650, "he-grenade": 100, "frag-grenade": 100,
            "flash-bang": 100, "smoke-grenade": 40, "thermal-smoke": 60, "lmg": 5800, "weapon-mount": 2500,
            "heavy-mount": 5000, "autosoft-targeting": 1500, "wired-reflexes": 39000, "muscle-replacement": 25000,
            "control-rig": 97000, "deck-4": 345000, "scorpion": 12000, "americar": 16000, "bulldog": 35000,
            "power-focus-2": 36000, "knife": 300}
    assert {k: C[k]["cost"] for k in book} == book
    assert [C[k]["avail"] for k in ("steel-lynx", "doberman", "roto-drone", "smg", "frag-grenade", "flash-bang",
                                    "weapon-mount", "heavy-mount", "lmg")] == ["10R", "4R", "6", "8R", "11F", "6R",
                                                                              "8F", "14F", "12F"]
    assert chargen.avail_of(C["steel-lynx"]) == (10, "R") and chargen.avail_of(C["bulldog"]) == (0, "")
    assert C["lmg"]["props"]["size"] == "heavy" and C["smg"]["props"]["size"] == "standard"
    assert "size" not in C["katana"]["props"]                                    # a blade doesn't go on a mount


def test_money_and_place_matter(make_game):
    g = make_game()
    setup_demo(g)
    shops.stock(g, "the-lucky-shot", "Kaz's", "fence", [{"key": "steel-lynx", "stock": 1}, "power-focus-2"], 1.0, 1,
                legal=True)
    with pytest.raises(LedgerError, match="costs 25,000"):
        shops.buy(g, "razor", "steel", 1, 1)
    g.ledger.set_stat("razor", "nuyen", 60000)
    with pytest.raises(LedgerError, match="only has 1"):
        shops.buy(g, "razor", "steel", 2, 1)
    tanaka_scene = g.new_scene("Chinatown", None, ["ghost"], 2)
    with pytest.raises(LedgerError, match="isn't anywhere that sells gear"):
        shops.buy(g, "ghost", "steel", 1, 2)
    del tanaka_scene


def test_the_dealer_searches_restricted_gear_and_it_arrives_later(make_game):
    """SR5 p. 418, as the table rules it: Kaz (the contact, Negotiation 4 + Charisma 4) searches for each restricted or
    forbidden item when he stocks it - his roll, not the buyer's - and the net hits set when it comes. Nothing fails at
    the checkout; what's still on its way can't be used until the clock gets there (live N353: the GM tracked a
    courier 'around T209' by hand while the ledger already had the gun in Filament's hands)."""
    g = make_game(dice=ScriptedDice([5, 5, 5, 2, 2, 2, 2, 2] + [5] + [2] * 10        # frag: 3 vs 1 -> net 2
                                    + [2] * 8 + [5, 5, 2, 2]))                        # smoke: 0 vs 2 -> net -2
    setup_demo(g)
    L = g.ledger
    ctx = TurnContext(g, 5, g.current_scene_id())
    out = dispatch(ctx, "open_shop", {"location_id": "the-lucky-shot", "name": "Kaz's back room", "kind": "fence",
                                      "items": ["frag-grenade", "smoke-grenade", "medkit"], "contact_id": "kaz"})
    assert "frag-grenade (11F): Kaz 8d6 -> 3 vs Availability 11d6 -> 1: found" in out
    assert "smoke-grenade (4R): Kaz 8d6 -> 0 vs Availability 4d6 -> 2: came up dry first - slower" in out
    offers = L.require("the-lucky-shot")["props"]["shop"]["items"]
    assert offers["frag-grenade"]["hours"] == 3 and offers["smoke-grenade"]["hours"] == 18   # 6 h / 2; 6 h x 3
    assert "hours" not in offers["medkit"]                                      # legal gear: on the shelf
    again, _ = shops.stock(g, "the-lucky-shot", "Kaz's back room", "fence", ["frag-grenade", "smoke-grenade"], 1.0, 5,
                           contact_id="kaz")                                    # a restock: no fishing for a faster find
    assert again["items"]["frag-grenade"]["hours"] == 3 and again["items"]["smoke-grenade"]["hours"] == 18
    assert "(the earlier search stands)" in shops.search_lines(g, again)[0]
    g.set_clock(2 * clock.DAY + 15 * 60)                                        # Day 3, 15:00
    L.set_stat("razor", "nuyen", 1000)
    res = shops.buy(g, "razor", "frag", 1, 6)                                   # 15:00 + 3 h -> evening, 19:00
    assert res["until"] == 2 * clock.DAY + 19 * 60
    assert "On its way from Kaz's back room - arrives this evening." in res["card"]
    frag = L.require(res["entities"][0])
    assert sr_lite.arriving(frag) and L.holds("razor", frag["id"])
    with pytest.raises(LedgerError, match="on its way from Kaz's back room - arrives this evening"):
        explosives.explode(L, g.dice, 6, frag["id"], "razor", [{"id": "kaz", "range": "close"}])
    assert "ON THE WAY" in build_packet(g, g.current_scene_id(), [], 7)[0]
    assert shops.arrivals(g, 7) == []                                           # (the clock hasn't got there)
    g.set_clock(2 * clock.DAY + 20 * 60)
    assert shops.arrivals(g, 8) == ["[SHOP] Razor's frag grenade arrives from Kaz's back room."]
    assert not sr_lite.arriving(L.require(frag["id"]))


def test_the_markup_buys_dice_and_prices_one_item_apart(make_game):
    """Each 25% over the list price is a die on the search (p. 418); one item can be priced apart from the shop's
    markup (live T181-T185: BarrensBolt's 0.9 refurb price ran over a serial-scrubbed HK-227 and 11F frags alike)."""
    g = make_game(dice=ScriptedDice([2] * 40))
    setup_demo(g)
    shop, _ = shops.stock(g, "the-lucky-shot", "Kaz's", "fence", ["medkit", {"key": "smg", "markup": 1.5}], 0.8, 1)
    assert shop["items"]["medkit"]["price"] == 400 and shop["items"]["smg"]["price"] == 1100     # 500 x 0.8; 730 x 1.5
    assert shop["items"]["smg"]["search"]["extra"] == 2 and shop["items"]["smg"]["search"]["pool"] == 10


def test_a_remote_dealer_sells_without_stocking_the_room(make_game):
    """Live T181-T187: BarrensBolt's online listings were stocked onto Castellano's Hardware, the room the crew stood
    in, and every packet there said SHOP HERE for a drone dealer. A remote shop lives on the dealer's own entity, is listed in
    the scene where the runners looked it up - !shop, !buy, the UI and the packet all find it - and ships by courier."""
    g = make_game(dice=ScriptedDice([5] * 60))
    setup_demo(g)
    L = g.ledger
    yard, _ = g.introduce("location", "BarrensBolt salvage yard", "a drone dealer's lot", turn=1)
    ctx = TurnContext(g, 5, g.current_scene_id())
    with pytest.raises(LedgerError, match="where the runners are standing"):
        dispatch(ctx, "open_shop", {"location_id": "the-lucky-shot", "name": "BarrensBolt", "kind": "online dealer",
                                    "items": ["roto-drone"], "remote": True})
    out = dispatch(ctx, "open_shop", {"location_id": yard, "name": "BarrensBolt Refurb", "kind": "online drone dealer",
                                      "items": ["roto-drone", "doberman", "autosoft-targeting"], "remote": True})
    assert "Listed in this scene" in out
    assert not L.require("the-lucky-shot")["props"].get("shop")                 # the bar sells nothing
    holder, shop = shops.where(g, "razor")
    assert holder["id"] == yard and shop["remote"]
    card = shops.card(g, "razor")
    assert card["title"] == "🛒 BarrensBolt Refurb" and "remote: everything comes by courier" in card["description"]
    assert "SHOP ON THE LINE: BarrensBolt Refurb" in build_packet(g, g.current_scene_id(), [], 6)[0]
    L.set_stat("razor", "nuyen", 20000)
    res = shops.buy(g, "razor", "roto", 1, 6)
    roto = L.require(res["entities"][0])
    assert sr_lite.arriving(roto) and "On its way from BarrensBolt Refurb" in res["card"]
    with pytest.raises(LedgerError, match="nobody can run it yet"):
        machines.set_control(L, 6, roto["id"], "razor")
    g.new_scene("The van", None, ["razor"], 7)
    assert shops.where(g, "razor") == (None, None)                              # the listing stayed in that scene...
    shops.buy(g, "razor", "dober", 1, 7, shop_id=yard)                          # ...and the dealer's still a call away


def test_buy_onto_a_drone_and_drop_from_it(make_game):
    """Live T184/T188: canon said Filament's Roto-drone had a grenade drop rig, but the grenades sat in his pockets and
    nothing could put them on it. buy onto: straight onto a drone the buyer owns - and the drone throws them (its own
    Pilot + Targeting). An autosoft goes onto the buyer's only drone with room."""
    g = make_game(dice=ScriptedDice([2] * 80))
    setup_demo(g)
    L = g.ledger
    roto = machines.build_machine(L, "Razor's Roto-drone", "roto-drone", "razor", 1, equipped=False)
    shops.stock(g, "the-lucky-shot", "Kaz's", "gun shop", ["flash-bang", "autosoft-targeting", "medkit"], 1.0, 1,
                legal=True)
    L.set_stat("razor", "nuyen", 5000)
    res = shops.buy(g, "razor", "flash", 2, 2, onto="roto")
    assert "Straight onto Razor's Roto-drone" in res["card"] and L.holds(roto, res["entities"][0])
    assert "Aboard: 2x Razor's flash-bang" in sr_lite.sheet(L, roto)
    with pytest.raises(LedgerError, match="doesn't go on a weapon mount"):
        shops.buy(g, "razor", "medkit", 1, 2, onto=roto)
    shops.buy(g, "razor", "autosoft", 1, 2)                                     # (its only drone: the Roto-drone)
    assert sr_lite.autosofts(L, L.require(roto)) == {"targeting": 3}
    boom = dispatch(TurnContext(g, 3, g.current_scene_id()), "explode", {
        "item_id": res["entities"][0], "holder_id": roto, "thrown": True, "space": "room",
        "targets": [{"id": "kaz", "range": "close"}]})
    assert "Throw  Pilot 3 + Targeting autosoft 3 = 6d6" in boom
    assert next(i["qty"] for i in L.holdings(roto) if i["id"] == res["entities"][0]) == 1


def test_chrome_on_the_way_is_installed_when_it_arrives(make_game):
    g = make_game(dice=ScriptedDice([5] * 8 + [2] * 8))
    setup_demo(g)
    L = g.ledger
    shops.stock(g, "the-lucky-shot", "Doc Wire's", "street doc", ["wired-reflexes"], 1.0, 1, contact_id="kaz")
    L.set_stat("razor", "nuyen", 50000)
    ess, rea = L.stat("razor", "essence"), L.stat("razor", "reaction")
    res = shops.buy(g, "razor", "wired", 1, 2)
    assert "(installed then)" in res["card"] and L.stat("razor", "essence") == ess and L.stat("razor", "reaction") == rea
    assert sr_lite.initiative_dice(L, "razor")[0] == 0                         # (not wired yet: no extra die)
    g.set_clock(g.clock() + 3 * clock.DAY)
    cards = shops.arrivals(g, 3)
    assert cards and "Installed:" in cards[0] and f"REA {int(rea)} -> {int(rea) + 1}" in cards[0]
    assert round(L.stat("razor", "essence"), 2) == round(ess - 2.0, 2) and sr_lite.initiative_dice(L, "razor")[0] == 1


def test_only_their_player_spends_their_nuyen(make_game):
    """A player's character buys - and fits out their drone - on their player's word this turn, like lending a drone
    (§7a): the GM can't spend a quiet player's money, nor an idle PC's (parked, or an away player's - hands-off in the
    packet). A companion's is the GM's call."""
    g = make_game()
    setup_demo(g)
    L = g.ledger
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('id-ghost', 'ghost', 'Ghost', 0)")
    shops.stock(g, "the-lucky-shot", "Kaz's", "gun shop", ["medkit"], 1.0, 1, legal=True)
    L.set_stat("ghost", "nuyen", 5000)
    ctx = TurnContext(g, 2, g.current_scene_id())
    with pytest.raises(LedgerError, match="Ghost's player hasn't bought that"):
        dispatch(ctx, "buy", {"buyer_id": "ghost", "item": "medkit"})
    ctx.posted = {"ghost"}
    assert dispatch(ctx, "buy", {"buyer_id": "ghost", "item": "medkit"}).startswith("[SHOP] Ghost buys")
    with pytest.raises(LedgerError, match="Razor's player hasn't bought that"):              # (parked: idle)
        dispatch(TurnContext(g, 2, g.current_scene_id()), "buy", {"buyer_id": "razor", "item": "medkit"})
    g.set_control("razor", "gm")                                                             # a companion
    assert dispatch(TurnContext(g, 2, g.current_scene_id()), "buy", {"buyer_id": "razor", "item": "medkit"})


def test_t181_to_t188_replayed(make_game):
    """The live order, replayed through run_turn: Filament (Ghost here) looks up an online drone dealer and buys a
    Steel Lynx and grenades onto his Roto-drone. The dealer is a remote shop on its own lot (the bar stays a bar), the
    Lynx costs the book's 25,000 and comes by courier, and it can't be run until the story clock gets there - then a
    [SHOP] card says it's arrived."""
    from types import SimpleNamespace                    # (conftest's tool() takes `name` itself: these spell it out)
    from .conftest import text, tool
    extraction = {"summary": "Ghost orders drones.", "recalled": [], "facts": [], "told": [], "new_entities": [],
                  "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "ghost", "role": "actor"}]}
    script = [([SimpleNamespace(type="tool_use", name="introduce", id="tu_shop_intro",
                                input={"kind": "location", "name": "BarrensBolt salvage yard",
                                       "description": "a drone lot", "district": "Redmond Barrens"}),
                SimpleNamespace(type="tool_use", name="open_shop", id="tu_shop_open",
                                input={"location_id": "barrensbolt-salvage-yard", "name": "BarrensBolt Refurb",
                                       "kind": "online drone dealer", "items": ["steel-lynx", "frag-grenade"],
                                       "remote": True}),
                tool("buy", buyer_id="ghost", item="steel-lynx"),
                tool("buy", buyer_id="ghost", item="frag-grenade", qty=2, onto_id="ghost-s-roto-drone")], "tool_use"),
              ([text("The order goes through; a courier ETA blinks on Ghost's AR.")], "end_turn"),
              ([text("A week of waiting.\n<dm>\ntime: a week later, morning\n</dm>")], "end_turn")]
    g = make_game(FakeLLM(script, extraction), dice=ScriptedDice([5] * 8 + [2] * 10 + [5] * 8 + [2] * 11 + [2] * 300))
    setup_demo(g)
    L = g.ledger
    machines.build_machine(L, "Ghost's Roto-drone", "roto-drone", "ghost", 1, equipped=False)
    L.set_stat("ghost", "nuyen", 30000)
    res = g.run_turn([("ghost", "I look it up online for delivery: a Steel Lynx, and two frags for the roto.")])
    assert any(c.startswith("[SHOP] Ghost buys Steel Lynx at BarrensBolt Refurb for 25,000¥") for c in res.cards)
    assert not L.require("the-lucky-shot")["props"].get("shop") and L.stat("ghost", "nuyen") == 4800
    lynx = next(m for m in machines.owned_by(L, "ghost") if m["props"]["model"] == "steel lynx")
    assert sr_lite.arriving(lynx) and lynx["props"]["autosofts"] == {}
    assert "Aboard: 2x Ghost's frag grenade" in sr_lite.sheet(L, "ghost-s-roto-drone")
    with pytest.raises(LedgerError, match="nobody can run it yet"):
        machines.set_control(L, 2, lynx["id"], "ghost")
    res = g.run_turn([("ghost", "We wait for the courier.")])
    assert any(c == "[SHOP] Ghost's Steel Lynx arrives from BarrensBolt Refurb." for c in res.cards)
    assert not sr_lite.arriving(L.require(lynx["id"]))
    assert "Ghost takes the controls" in machines.set_control(L, 3, lynx["id"], "ghost")   # (it runs now)


def test_shop_commands(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)
    shops.stock(g, "the-lucky-shot", "Kaz's back room", "fence", ["light-pistol", "he-grenade"], 1.0, 1)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()

        async def react(e):
            pass
        await t.handle("2", "Bob", "!join razor", False, react)
        await t.handle("2", "Bob", "!shop", False, react)
        assert ch.sent[-1]["title"] == "🛒 Kaz's back room" and "`1` HE grenade - **100¥** · Avail 11F" in ch.sent[-1]["description"]
        await t.handle("2", "Bob", "!buy 1 x3", False, react)
        assert ch.sent[-1]["text"].startswith("🛒 Razor buys 3× HE grenade") and "On its way" in ch.sent[-1]["text"]
        await t.close()
    asyncio.run(go())


def test_buy_takes_its_number_from_the_shop_you_looked_at(make_game):
    """Review E2: `!shop kaz` showed Kaz's back room - '`1` Armored jacket - 1,000¥' - and `!buy 1` then charged
    5,000¥ for a Roto-drone at BarrensBolt, the newest shop, because !buy never knew which card the player was
    reading. Now a number is the last card's; `from <shop>` names one; and with two open and no card seen, a bare
    number is refused rather than guessed."""
    g = make_game(FakeLLM(), dice=ScriptedDice([5] * 60))
    setup_demo(g)
    L = g.ledger
    shops.stock(g, "the-lucky-shot", "Kaz's back room", "gun shop", ["armored-jacket", "medkit"], 1.0, 1, legal=True)
    yard, _ = g.introduce("location", "BarrensBolt salvage yard", "a drone lot", turn=2)
    shops.stock(g, yard, "BarrensBolt Refurb", "online drone dealer", ["roto-drone", "steel-lynx"], 1.0, 2, remote=True)
    L.set_stat("razor", "nuyen", 30000)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()

        async def react(e):
            pass
        await t.handle("2", "Bob", "!join razor", False, react)
        await t.handle("2", "Bob", "!buy 1", False, react)
        assert "More than one shop is open (BarrensBolt Refurb, Kaz's back room)" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!shop kaz", False, react)
        assert ch.sent[-1]["title"] == "🛒 Kaz's back room" and "`1` Armored jacket - **1,000¥**" in ch.sent[-1]["description"]
        await t.handle("2", "Bob", "!buy 1", False, react)
        assert ch.sent[-1]["text"].startswith("🛒 Razor buys Armored jacket at Kaz's back room for 1,000¥ (29,000¥ left)")
        await t.handle("2", "Bob", "!buy armored", False, react)                # (a name: from the same card)
        assert "Armored jacket at Kaz's back room" in ch.sent[-1]["text"]
        await t.handle("2", "Bob", "!buy 1 from barrensbolt", False, react)
        assert ch.sent[-1]["text"].startswith("🛒 Razor buys Roto-drone at BarrensBolt Refurb for 5,000¥")
        await t.handle("2", "Bob", "!shop the moon", False, react)
        assert ch.sent[-1]["text"] == ("⚠️ No shop 'the moon' open to Razor - open: BarrensBolt Refurb, "
                                       "Kaz's back room.")
        await t.handle("2", "Bob", "!shop", False, react)                       # (the newest again: its numbers)
        assert ch.sent[-1]["title"] == "🛒 BarrensBolt Refurb" and "`1` Steel Lynx" in ch.sent[-1]["description"]
        await t.handle("2", "Bob", "!buy 1", False, react)                      # (the Roto-drone sold out)
        assert ch.sent[-1]["text"] == "⚠️ Steel Lynx costs 25,000¥ - Razor has 23,000¥."
        assert L.stat("razor", "nuyen") == 30000 - 1000 - 1000 - 5000
        await t.close()
    asyncio.run(go())


def test_a_delivery_lands_on_a_table_turn_not_in_a_whisper(make_game):
    """Review E2: the owner's `!time` jumped the clock past Ghost's Steel Lynx, the next turn was Razor's whisper, and
    the delivery was cleared there - its only card in Razor's DMs. The table and Ghost never saw it."""
    g = make_game(FakeLLM(), dice=ScriptedDice([5] * 18 + [2] * 300))
    setup_demo(g)
    L = g.ledger
    yard, _ = g.introduce("location", "BarrensBolt salvage yard", "a drone lot", turn=1)
    shops.stock(g, yard, "BarrensBolt", "online drone dealer", ["steel-lynx"], 1.0, 1, remote=True)
    L.set_stat("ghost", "nuyen", 30000)
    lynx = shops.buy(g, "ghost", "steel", 1, 1)["entities"][0]
    g.set_clock(g.clock() + 40 * clock.DAY)
    res = g.run_turn([("razor", "I check the alley on the quiet.")], private="razor")
    assert not any(c.startswith("[SHOP]") for c in res.cards) and sr_lite.arriving(L.require(lynx))
    res = g.run_turn([("ghost", "We wait for the courier.")])
    assert "[SHOP] Ghost's Steel Lynx arrives from BarrensBolt." in res.cards


def test_a_delivery_nobody_holds_goes_without_a_card(make_game):
    """Review E2: deliveries were announced for gear nobody held ('[SHOP] Brick's Armored jacket arrives' with its
    holders []). One that's left every hand drops off the list quietly."""
    g = make_game(dice=ScriptedDice([2] * 40))
    setup_demo(g)
    L = g.ledger
    yard, _ = g.introduce("location", "BarrensBolt salvage yard", "a drone lot", turn=1)
    shops.stock(g, yard, "BarrensBolt", "online dealer", ["armored-jacket"], 1.0, 1, remote=True)
    L.set_stat("razor", "nuyen", 5000)
    jacket = shops.buy(g, "razor", "armored", 1, 1)["entities"][0]
    L.take("razor", jacket, 1)
    g.set_clock(g.clock() + 3 * clock.DAY)
    assert shops.arrivals(g, 2) == [] and shops._ids(g, shops.TRANSIT) == []


def test_chrome_on_its_way_stays_with_its_buyer(make_game):
    """Review E2: Razor's Wired reflexes, still with the courier, was handed to Ghost (Essence 1.0) with transfer_item
    and put into him when it came - Essence -1.0, past the floor buy had checked for Razor. Gear on its way can't be
    handed over now; and chrome that comes to someone at the floor isn't put in (the Essence is checked again then)."""
    g = make_game(dice=ScriptedDice([5] * 8 + [2] * 8))
    setup_demo(g)
    L = g.ledger
    shops.stock(g, "the-lucky-shot", "Doc Wire's", "street doc", ["wired-reflexes"], 1.0, 1, contact_id="kaz")
    L.set_stat("razor", "nuyen", 50000)
    wired = shops.buy(g, "razor", "wired", 1, 2)["entities"][0]
    with pytest.raises(LedgerError, match="on its way from Doc Wire's - .* nobody has it to hand over yet"):
        dispatch(TurnContext(g, 2, g.current_scene_id()), "transfer_item",
                 {"item_id": wired, "from_id": "razor", "to_id": "ghost"})
    assert L.holds("razor", wired) and not L.holds("ghost", wired)
    L.set_stat("razor", "essence", 1.0)                  # (since the order - another world's chrome, the GM's word)
    rea = L.stat("razor", "reaction")
    g.set_clock(g.clock() + 3 * clock.DAY)
    assert shops.arrivals(g, 3) == ["[SHOP] Razor's Wired reflexes arrives from Doc Wire's. Not installed: it would "
                                    "drop Razor's Essence to -1.0 - the street doc won't risk it below 0.5."]
    assert L.stat("razor", "essence") == 1.0 and L.stat("razor", "reaction") == rea
    assert sr_lite.initiative_dice(L, "razor")[0] == 0 and "NOT INSTALLED" in sr_lite.sheet(L, "razor")
