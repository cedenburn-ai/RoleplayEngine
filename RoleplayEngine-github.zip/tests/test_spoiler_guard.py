"""The spoiler guard (dm/spoilers.py, DESIGN.md §12l, 2026-10-28): a name the table hasn't learned never reaches what
it reads. The first seed's rehearsal found two leaks - a waiting <dm> note's GM-only words in the memory pass's ENGINE
EVENTS (the public summary named a sealed NPC by them and unsealed him), and a GM-only label in the scene frame the GM
plays from (said at the table). Each root is tested here, then the backstop on everything that becomes public.

The story here is invented for the tests - a ferry dock, a man in a green coat, a harbormaster with a name of her
own - so no test says anything about the owner's seed."""
import json
from types import SimpleNamespace

from roleplay import flags, jobs, seed
from roleplay.dm import aside, dmblock, frame, speakers, spoilers, tensions, world
from roleplay.dm.tools import TurnContext
from roleplay.graphlog import fmt
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool

PLAYER = ("# The Night Ferry\nThe crew waits at the ferry dock in the rain. A man in a green coat hands out flyers for "
          "a boxing match nobody has heard of. The harbormaster, a heavy dwarf, counts crates and says nothing. Riders "
          "in lantern-red scarves watch from the far end of the pier.")
GM = ("## For the GM only\nThe man in the green coat is Corwin Vale, a smuggler. He works for the Lantern Syndicate, "
      "the riders in the scarves. The harbormaster's real name is Greta Brandt; she keeps the Syndicate's books. Odile "
      "Marchetti runs the Syndicate from across the bay. Vale once flew escort for Osprey Aerospace.")
DOCS = [seed.Doc("night-ferry.md", PLAYER, False), seed.Doc("night-ferry.GM.md", GM, True)]
NAMES = ("Corwin", "Vale", "Greta", "Brandt", "Odile", "Marchetti", "Syndicate")       # what the table hasn't learned


def plan() -> dict:
    """The read: the man in the green coat filed under his GM-only name (sealed for it), the harbormaster public with a
    real name of her own, the boss nobody has met, and the outfit the crew has only seen."""
    person = {"template": "civilian", "persona": {}, "where": "", "place": "", "dead": False}
    return {"title": "The Night Ferry", "intent": "The crew stumbles onto a smuggling ring.", "arc": "",
            "secret_words": ["Corwin Vale", "Lantern Syndicate", "Greta Brandt", "Odile Marchetti", "smuggler"],
            "people": [
                {**person, "key": "vale", "name": "Corwin Vale", "true_name": "", "known": True,
                 "description": "a man in a green coat who hands out flyers", "secret": "He smuggles."},
                {**person, "key": "harbor", "name": "the harbormaster", "true_name": "Greta Brandt", "known": True,
                 "description": "a heavy dwarf who counts crates", "secret": "She keeps the books."},
                {**person, "key": "boss", "name": "Odile Marchetti", "true_name": "", "known": False,
                 "description": "", "secret": "Runs it all."}],
            "outfits": [{"key": "ring", "name": "The Lantern Syndicate", "true_name": "", "known": False,
                         "description": "an outfit in lantern-red scarves", "secret": "Smugglers.", "profile": {}}],
            "places": [], "ties": [], "facts": [], "events": [], "feelings": [], "agendas": [], "hooks": [],
            "tensions": [], "job": {}, "contradictions": [], "opening": {}}


MEMORY = {"summary": "Razor watched the dock.", "members": [{"id": "razor", "role": "actor"}], "recalled": [],
          "facts": [], "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}}


def _leaks(text_) -> list[str]:
    return [n for n in NAMES if seed._says(str(text_ or ""), n)]


def _seeded(make_game, llm=None) -> tuple:
    """The demo world with the ferry seeded into it: (game, {key: id})."""
    g = make_game(llm or FakeLLM([], MEMORY))
    setup_demo(g)
    seed.apply(g, DOCS, plan(), "night-ferry")
    L = g.ledger
    handles = {"vale": "the man in a green coat", "harbor": "the harbormaster", "boss": "someone the crew hasn't met",
               "ring": "the outfit in lantern-red scarves"}
    return g, {k: L.find(h)["id"] for k, h in handles.items()}


class Seeing(FakeLLM):
    """Keeps every message the GM was sent - the send-backs too."""

    def dm_step(self, system, tools_, messages, progress=None):
        self.seen = [m["content"] for m in messages if m["role"] == "user" and isinstance(m["content"], str)]
        return super().dm_step(system, tools_, messages, progress)


def _memory_prompts():
    seen = []

    def extraction(user):
        seen.append(user)
        return json.loads(json.dumps(MEMORY))
    return seen, extraction


# ── the first leak: what the memory pass reads ──────────────────────────

def test_a_waiting_gm_note_never_reaches_the_memory_pass(make_game):
    """The rehearsal's T191, in small (the repro): a note waiting on a Q# or a name not on file put its whole text in
    ENGINE EVENTS. It says only that a GM-only line waits now - and it still lands, after the pass."""
    secret = "the bartender is secretly a retired dragon hunter"
    for line in (f"note somebody-new: {secret}", f"note Q1: {secret}", f"note kaz: {secret}"):
        seen, extraction = _memory_prompts()
        g = make_game(FakeLLM([([text(f"Kaz shrugs.\n<dm>\n{line}\n</dm>")], "end_turn")], extraction))
        setup_demo(g)
        g.run_turn([("razor", "Kaz, who buys Renraku data?")])
        memory = [u for u in seen if "NARRATION:" in u]
        assert memory and not any(secret in u for u in memory), line
        if line.startswith("note somebody-new"):
            events = memory[0].split("ENGINE EVENTS", 1)[1].split("NARRATION:")[0]
            assert "NOTE on 1 not on file yet: a GM-only line" in events and "somebody-new" not in events
        if line.startswith("note kaz"):
            assert any(n["text"] == secret for n in g.sub.notes_for("kaz", 5))      # (on file all the same)


def test_every_gm_only_engine_event_reaches_the_pass_by_kind_and_ids(make_game, tmp_path):
    """Goals, hook landings, doubts (the line and the tool), tensions opened, moved and shelved, and every waiting
    kind: the memory pass reads each by its kind and ids, never its words. A public line - a fact, karma - keeps its
    words: the pass mustn't extract the GM's own fact again (dmblock._held's reason)."""
    secret = {k: f"secret {k} words" for k in ("agenda", "landed", "doubt", "tension", "moved", "shelve", "held-note",
                                                "held-agenda", "held-clarify", "held-doubt", "tool", "clarify")}
    block = "\n".join([f"agenda kaz: {secret['agenda']}", f"landed H1: {secret['landed']}",
                       f"doubt kaz: {secret['doubt']}", f"tension kaz: {secret['tension']}? | public: Kaz owes them",
                       f"tension Q1: {secret['moved']} | next: he calls", f"shelve Q2: {secret['shelve']}",
                       f"clarify kaz: {secret['clarify']}", f"note somebody-new: {secret['held-note']}",
                       f"agenda nobody-yet: {secret['held-agenda']}", f"clarify somebody-new: {secret['held-clarify']}",
                       f"doubt somebody-new: {secret['held-doubt']}", "fact kaz: Kaz drinks rye.",
                       "fact kaz, the bartender: Kaz owes Tanaka 14,000 nuyen."])
    seen, extraction = _memory_prompts()
    llm = FakeLLM([([tool("doubt", action="raise", text=secret["tool"], ids=["kaz"])], "tool_use"),
                   ([text(f"Kaz wipes the bar.\n<dm>\n{block}\n</dm>")], "end_turn")], extraction)
    g = make_game(llm)
    setup_demo(g)
    world.add_hook(g, "kaz", None, "Kaz's buyer turns up early", ["razor"], 1)
    tensions.open_tension(g, "Will Kaz pay?", ["kaz"], 1)
    tensions.open_tension(g, "Who tipped off Lone Star?", ["kaz"], 1)
    g.run_turn([("razor", "I watch Kaz.")])
    memory = next(u for u in seen if "NARRATION:" in u)
    events = memory.split("ENGINE EVENTS", 1)[1].split("NARRATION:")[0]
    assert not [k for k, s in secret.items() if s in memory]
    for said in ("AGENDA A", "HOOK LANDED H1 (GM-only)", "DOUBT X", "TENSION Q3 opened on kaz (GM-only)",
                 "TENSION Q1 moved (GM-only)", "TENSION Q2 shelved (GM-only)", "NOTE on 1 not on file yet: a GM-only",
                 "AGENDA on 1 not on file yet: a GM-only", "CLARIFY on 1 not on file yet: a GM-only"):
        assert said in events, said
    assert events.count("(GM-only)") >= 6
    assert "Kaz drinks rye." in events and "Kaz owes Tanaka 14,000 nuyen." in events
    assert "not one to extract again" in events
    owes = [f for f in g.sub.facts_for("kaz", 20) if f["text"] == "Kaz owes Tanaka 14,000 nuyen."]
    assert len(owes) == 1                                                    # (once: the pass didn't extract it again)


def test_someone_sealed_reaches_the_memory_pass_by_their_handle_alone(make_game):
    """Rehearsal round 1 (2026-10-28): KNOWN ENTITIES listed everyone the seed filed lately with their descriptions -
    a sealed NPC nobody had met among them, described by the GM file's plot. Nothing of them is the crew's yet."""
    seen, extraction = _memory_prompts()
    g, ids = _seeded(make_game, FakeLLM([([text("Ghost watches the pier.")], "end_turn")], extraction))
    g.ledger.update_entity(ids["boss"], description="registered owner of a houseboat across the bay")
    boss = g.ledger.get(ids["boss"])
    assert boss["id"] in seed.sealed_ids(g.conn)
    g.run_turn([("razor", "I watch the pier.")])
    known = next(u for u in seen if "NARRATION:" in u).split("KNOWN ENTITIES", 1)[1].split("EARLIER MEMORIES")[0]
    assert f"{boss['id']}: " in known and "houseboat" not in known
    assert "counts crates" in known                                  # (the harbormaster's: public, she keeps hers)


def test_the_commit_prompt_says_gm_only_lines_are_withheld():
    from roleplay.dm.prompts import COMMIT_SYSTEM
    assert "marked GM-only" in COMMIT_SYSTEM and "never write about it" in COMMIT_SYSTEM


# ── the seed keeps what the guard needs ─────────────────────────────────

def test_the_seed_keeps_its_terms_and_the_names_behind_its_handles(make_game):
    g, ids = _seeded(make_game)
    L = g.ledger
    kept = json.loads(L.meta(seed.META_TERMS))
    assert {"Corwin Vale", "Greta Brandt", "Odile Marchetti", "Syndicate"} <= set(kept["terms"])
    assert set(kept["secret_words"]) == set(plan()["secret_words"])
    assert L.get(ids["harbor"])["props"]["true_name"] == "Greta Brandt"
    assert L.get(ids["vale"])["props"]["true_name"] == "Corwin Vale"                # (sealed for it: the handle's)
    assert not _leaks(" ".join(L.get(x)["name"] for x in ids.values()))
    G = spoilers.guard(g)
    by = {s.id: s for s in G.secrets}
    assert by[ids["harbor"]].names == ["Greta Brandt"] and not by[ids["harbor"]].sealed
    assert by[ids["vale"]].sealed and by[ids["boss"]].sealed and by[ids["ring"]].sealed
    assert dict(G.terms)["Brandt"] == ids["harbor"] and dict(G.terms)["Syndicate"] == ids["ring"]
    assert "smuggler" in G.words and "smuggler" not in dict(G.terms)        # (a plot word: told, never cut)
    # a capital in the GM file no secret word names: the seed's own guard keeps it off its public lines, but at the
    # table it's as often a corp's name - never cut from the narration
    assert "Osprey" in kept["terms"] and spoilers.hits(g, "A Osprey Aerospace jet roars over the dock.") == []


def test_a_seed_filed_before_the_guard_still_has_its_names(make_game):
    """A world seeded before 2026-10-28 kept the real names only in its GM notes and pictures: they're read from
    there."""
    g, ids = _seeded(make_game)
    L = g.ledger
    for x in ids.values():
        L.update_entity(x, props={k: v for k, v in L.get(x)["props"].items() if k not in ("true_name", "gm_names")})
    L.set_meta(seed.META_TERMS, "")
    by = {s.id: s for s in spoilers.guard(g).secrets}
    assert by[ids["harbor"]].names == ["Greta Brandt"] and by[ids["vale"]].names == ["Corwin Vale"]
    assert spoilers.scrub(g, "Greta Brandt waves.")[0] == "The harbormaster waves."


# ── the second leak: the frame, and what the GM reads first ─────────────

def test_the_packet_opens_on_the_sealed_block_while_any_are_left(make_game):
    g, ids = _seeded(make_game)
    sid = g.current_scene_id()
    packet, _ = build_packet(g, sid, [("razor", "hi")], g.turn_no() + 1)
    head = packet.split("\n=== SEALED", 1)
    assert len(head) == 2 and "=== PRESENT ===" not in head[0] and "=== OPEN TENSIONS" not in head[0]
    block = "=== SEALED" + head[1].split("\n===", 1)[0]
    assert 'say "the harbormaster"' in block and '"Greta Brandt"' in block
    assert '"the man in a green coat"' in block and "not met yet" in block and '"Corwin Vale"' in block
    assert f"({ids['boss']}) someone the crew hasn't met" in block
    assert '"the outfit in lantern-red scarves"' in block and '"smuggler"' in block
    assert "sealed" not in fmt.surfaced(packet, set(ids.values()))       # (ids in parentheses: nothing surfaced)
    # play reveals her name: her line goes, and the rest stay
    ctx = TurnContext(g, g.turn_no(), sid)
    dmblock.apply(ctx, dmblock.split(f"<dm>\nname {ids['harbor']}: Greta Brandt\n</dm>")[1])
    packet, _ = build_packet(g, sid, [("razor", "hi")], g.turn_no() + 1)
    block = packet.split("\n=== SEALED", 1)[1].split("\n===", 1)[0]
    assert "harbormaster" not in block and "Greta" not in block and "Corwin Vale" in block
    assert spoilers.hits(g, "Greta Brandt waves.") == []


def test_the_frame_knows_the_names_and_writes_only_handles(make_game, tmp_path):
    """The frame is told the names behind the files and who the crew hasn't met; what it writes is scrubbed to the
    crew's names after, flagged spoiler-free; and the packet labels it the GM's own planning."""
    asked = []

    def structured(user):
        if "EVERYONE IN THE ROOM" in user:
            asked.append(user)
            return {"intent": "Watching the dock for the Lantern Syndicate's boat.", "pressure": "",
                    "people": [{"id": ids["harbor"], "now": "Greta Brandt is counting the Syndicate's crates.",
                                "wants_here": "To be left alone.", "wont": "Talk about Odile Marchetti.",
                                "toward": [{"id": "razor", "stance": "Brandt doesn't trust him."}],
                                "settled": ["Corwin Vale owes her"]}], "over": []}
        return MEMORY
    g, ids = _seeded(make_game, FakeLLM([], structured))
    sid = g.current_scene_id()
    g.enter_scene([ids["harbor"]], g.turn_no(), sid)
    f = frame.run(g, sid)
    assert "NAMES THE TABLE HASN'T LEARNED" in asked[0] and '"Greta Brandt"' in asked[0]
    assert "Names: the GM plays from your frame" in frame.SYSTEM
    p = f["people"][0]
    written = json.dumps(f)
    assert not _leaks(written), _leaks(written)
    assert p["now"] == "The harbormaster is counting the outfit in lantern-red scarves' crates."
    assert f["intent"] == "Watching the dock for the outfit in lantern-red scarves' boat."     # (never "the the")
    assert p["wont"] == "Talk about someone." and p["settled"] == ["The man in a green coat owes her"]
    assert p["toward"] == [{"id": "razor", "stance": "The harbormaster doesn't trust him."}]
    assert any(fl["kind"] == "spoiler" for fl in flags.listing(tmp_path))
    assert not _leaks(json.dumps(flags.listing(tmp_path)))                  # (the owner reads flags: spoiler-free)
    lines = "\n".join(frame.packet_lines(g, sid))
    assert "GM-only - your own planning" in lines and "never quote it" in lines and "(SEALED, above)" in lines


def test_the_gm_is_told_never_to_say_them():
    from roleplay.dm.prompts import DM_SYSTEM
    assert "Never say a sealed name or a GM-only label at the table" in DM_SYSTEM
    assert "`name <id>: <the name>`" in DM_SYSTEM and "SEALED section" in DM_SYSTEM


# ── the backstop: the narration ─────────────────────────────────────────

def test_a_narration_that_slips_goes_back_once_then_is_scrubbed_and_flagged(make_game, tmp_path):
    again = "Greta Brandt shrugs.\n<dm>\nnote the-harbormaster: Greta Brandt is nervous.\n</dm>"
    llm = Seeing([([text("The harbormaster - Greta Brandt, by the tag on her coat - nods at Razor.")], "end_turn"),
                  ([text(again)], "end_turn")], MEMORY)
    g, ids = _seeded(make_game, llm)
    g.enter_scene([ids["harbor"]], g.turn_no())
    res = g.run_turn([("razor", "I watch the harbormaster.")])
    assert res.narration == "The harbormaster shrugs."
    back = llm.seen[-1]
    assert back.startswith("(Engine: the narration says names the table hasn't learned")
    assert '"Greta Brandt" (say "the harbormaster"' in back and "`name <id>: <the name>`" in back
    assert any("Greta Brandt is nervous." == n["text"] for n in g.sub.notes_for(ids["harbor"], 5))   # (its <dm> kept)
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert len(spoiled) == 2 and all(f"the harbormaster [{ids['harbor']}]" in f["text"] for f in spoiled)
    assert not _leaks(json.dumps(spoiled)) and not _leaks(g.sub.node(f"T{res.turn_id}")["text"])


def test_a_narration_that_comes_back_clean_posts_as_written(make_game):
    llm = Seeing([([text("**Greta [the-harbormaster]:** \"Move along.\"")], "end_turn"),
                  ([text("**The harbormaster [the-harbormaster]:** \"Move along.\"")], "end_turn")], MEMORY)
    g, ids = _seeded(make_game, llm)
    g.enter_scene([ids["harbor"]], g.turn_no())
    res = g.run_turn([("razor", "I watch the harbormaster.")])
    assert res.narration == '**The harbormaster:** "Move along."' and len(llm.seen) == 2
    assert not [a for a in g.ledger.get(ids["harbor"])["aliases"] if "Greta" in a]


def test_a_name_line_reveals_the_name_it_gives(make_game, tmp_path):
    """Play reveals her name: the narration may say it beside its `name` line, and from then on it's the crew's."""
    llm = Seeing([([text(f"\"Call me Greta Brandt,\" the dwarf says.\n<dm>\nname the-harbormaster: Greta Brandt\n"
                          "fact the-harbormaster: Greta Brandt runs the harbor office.\n</dm>")], "end_turn")], MEMORY)
    g, ids = _seeded(make_game, llm)
    res = g.run_turn([("razor", "What's your name?")])
    assert "Greta Brandt" in res.narration and len(llm.seen) == 1                # (not sent back)
    assert g.ledger.get(ids["harbor"])["name"] == "Greta Brandt"
    assert any(f["text"] == "Greta Brandt runs the harbor office." for f in g.sub.facts_for(ids["harbor"], 5))
    assert spoilers.hits(g, "Greta Brandt waves.") == [] and not flags.listing(tmp_path)


def test_the_guard_reads_whole_words_only(make_game):
    g, ids = _seeded(make_game)
    assert spoilers.hits(g, "The valet's daughter Valerie brewed valerian tea.") == []
    assert spoilers.hits(g, "the ilsebrandt account") == []
    assert [t for t, _ in spoilers.hits(g, "Vale's coat.")] == ["Vale"]
    said, found = spoilers.scrub(g, 'He meets Corwin Vale. "Corwin knows." Ask the Syndicate.')
    assert said == 'He meets the man in a green coat. "The man in a green coat knows." Ask the outfit in lantern-red ' \
                   'scarves.'
    assert {o for _, o in found} == {ids["vale"], ids["ring"]}
    assert spoilers.scrub(g, "Odile Marchetti waits.")[0] == "Someone waits."      # (nothing seen of her: no handle)
    assert spoilers.hits(g, "a smuggler on the pier") == []                         # (a plot word: never cut)
    assert spoilers.narration(g, "Kaz nods.\n<dm>\nnote kaz: Greta Brandt pays him.\n</dm>") == []   # (the GM's notes)


# ── the backstop: what the memory pass files ────────────────────────────

def test_the_memory_pass_is_scrubbed_and_mentioned_never_unseals(make_game, tmp_path):
    """Its summary, facts, new names and places in the names the crew knows; a sealed NPC it calls mentioned isn't
    filed so (the narration never called him anything), and stays sealed; a new NPC under a GM-only name isn't
    filed at all."""
    def extraction(user):
        return {**MEMORY, "summary": "Razor asked about Corwin Vale and the Lantern Syndicate.",
                "members": [{"id": "razor", "role": "actor"}, {"id": ids["vale"], "role": "mentioned"},
                            {"id": ids["ring"], "role": "mentioned"}],
                "facts": [{"text": "Corwin Vale smuggles for the Syndicate.", "about": [ids["vale"]], "replaces": ""}],
                "new_entities": [{"name": "Odile Marchetti", "kind": "npc", "description": "the boss", "aliases": [],
                                  "present": False, "where": {}},
                                 {"name": "Dock Rat", "kind": "npc", "description": "a kid who runs for Greta Brandt",
                                  "aliases": ["Brandt's kid"], "present": False, "where": {}}]}
    g, ids = _seeded(make_game, FakeLLM([([text("Razor asks around about the flyers.")], "end_turn")], extraction))
    res = g.run_turn([("razor", "Who's handing out flyers?")])
    S, L = g.sub, g.ledger
    slice_ = S.node(res.slice_id)
    assert slice_["text"] == "Razor asked about the man in a green coat and the outfit in lantern-red scarves."
    members = dict(S.members_of(res.slice_id))
    assert ids["vale"] not in members and ids["ring"] not in members
    assert {ids["vale"], ids["ring"], ids["boss"]} <= seed.sealed_ids(g.conn)
    fact = S.node(res.info["facts"][0])
    assert fact["text"] == "The man in a green coat smuggles for the outfit in lantern-red scarves."
    assert ids["vale"] not in [x["other"] for x in S.links_of(fact["id"])]
    assert not L.find("Odile Marchetti") and L.find("Dock Rat")["description"] == "a kid who runs for the harbormaster"
    assert not L.find("Dock Rat")["aliases"]
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert spoiled and not _leaks(json.dumps(flags.listing(tmp_path)))


def test_mentioned_by_the_handle_is_filed_but_only_meeting_unseals(make_game):
    """The narration calls him by his handle: 'mentioned' is filed - and still doesn't unseal him (seed.NOT_MET). Being
    in the room does, as before."""
    turn = {"role": "mentioned"}

    def extraction(user):
        return {**MEMORY, "members": [{"id": "razor", "role": "actor"}, {"id": ids["vale"], "role": turn["role"]}]}
    llm = FakeLLM([([text("Kaz says the man in a green coat was asking about Razor.")], "end_turn"),
                   ([text("The man in a green coat walks in.")], "end_turn")], extraction)
    g, ids = _seeded(make_game, llm)
    res = g.run_turn([("razor", "Who's asking?")])
    assert dict(g.sub.members_of(res.slice_id))[ids["vale"]] == "mentioned"
    assert ids["vale"] in seed.sealed_ids(g.conn)
    turn["role"] = "present"
    g.run_turn([("razor", "I wait.")])
    assert ids["vale"] not in seed.sealed_ids(g.conn)


def test_the_job_board_never_says_them(make_game, tmp_path):
    g, ids = _seeded(make_game)
    jobs.apply(g, g.turn_no(), [{"id": "", "change": "new", "title": "Find Corwin Vale", "client": ids["boss"],
                                 "objective": "Ask the Syndicate", "pay": "", "deadline": "", "progress": ""}])
    j = jobs.open_jobs(g)[0]
    assert j["title"] == "Find the man in a green coat" and j["objective"] == "Ask the outfit in lantern-red scarves"
    assert j["client_id"] is None                                         # (a client the crew hasn't met: never)
    assert any(f["kind"] == "spoiler" for f in flags.listing(tmp_path))


# ── the backstop: the GM's own public lines, the world, the answers ─────

def test_the_gms_public_lines_never_say_them(make_game, tmp_path):
    """A public fact that names one is kept as a GM note; establish_fact and introduce refuse it, naming the handle;
    an open question's public line is scrubbed, and its question - the dashboard's - too, the words on a note."""
    from roleplay.dm.tools import run_tool
    g, ids = _seeded(make_game)
    ctx = TurnContext(g, g.turn_no(), g.current_scene_id())
    dmblock.apply(ctx, dmblock.split("<dm>\nfact the-harbormaster: Greta Brandt keeps two sets of books.\ntension "
                                     "the-harbormaster: Who does Greta Brandt answer to? | public: Brandt owes "
                                     "someone\n</dm>")[1])
    assert not g.sub.facts_for(ids["harbor"], 5)
    assert any("Greta Brandt keeps two sets of books." in n["text"] for n in g.sub.notes_for(ids["harbor"], 5))
    q = tensions.get(g, next(x for x in ctx.tensions_touched))
    assert q["question"] == "Who does the harbormaster answer to?" and q["public"] == "The harbormaster owes someone"
    assert any("The question in full" in n["text"] for n in g.sub.notes_for(q["id"], 5))
    for name, args in (("establish_fact", {"text": "Corwin Vale runs the flyers.", "about_ids": ["razor"]}),
                       ("introduce", {"kind": "npc", "name": "Corwin Vale", "description": "a smuggler"})):
        out = run_tool(ctx, SimpleNamespace(type="tool_use", name=name, input=args, id=f"tu_{name}"))
        assert out.get("is_error") and "the man in a green coat" in out["content"], out
    assert not g.ledger.find("Corwin Vale")
    assert not _leaks(json.dumps(flags.listing(tmp_path)))


def test_the_world_never_files_a_gm_only_name(make_game):
    g, ids = _seeded(make_game)
    assert world.ensure_faction(g, "the Lantern Syndicate", g.turn_no()) == ids["ring"]   # (the outfit on file)
    assert world.ensure_faction(g, "Odile Marchetti's crew", g.turn_no()) is None         # (never a new public one)
    assert not g.ledger.find("Odile Marchetti's crew")


def test_a_label_with_a_gm_only_name_is_never_learned(make_game):
    g, ids = _seeded(make_game)
    text_, said, learned = speakers.resolve(g, f"**Greta [{ids['harbor']}]:** \"Move.\"", g.turn_no())
    assert said == {"Greta": ids["harbor"]} and not learned and "Greta" not in g.ledger.get(ids["harbor"])["aliases"]


def test_the_asides_and_askdms_answers_are_guarded(make_game, tmp_path):
    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            return {"answer": "That was Greta Brandt, the Syndicate's bookkeeper.", "direction": "", "fixes": [],
                    "is_move": False, "loop": False}
        return MEMORY
    llm = FakeLLM([], structured)
    g, ids = _seeded(make_game, llm)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, who was the dwarf?", "razor")
    assert res["answer"] == "That was the harbormaster, the outfit in lantern-red scarves' bookkeeper."
    llm.consult_script = [([text("You saw Corwin Vale by the dock.")], "end_turn")]
    assert g.askdm("razor", "Who handed me the flyer?") == "You saw the man in a green coat by the dock."
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert {f["text"].split(" said")[0] for f in spoiled} == {"The aside's answer", "!askdm's answer"}
    assert not _leaks(json.dumps(spoiled))


def test_a_card_at_the_table_never_says_them(make_game, tmp_path):
    """A roll's Why, a transfer's reason, karma's: the GM's own words, posted as they happen - the table's out hook
    scrubs every card and notice (never a log line), the whisperer's too."""
    import asyncio
    from roleplay.discord_bot.session import CampaignTable
    from .test_discord import FakeChannel
    g, ids = _seeded(make_game)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        g.out("[ROLL] Razor: Con + Charisma vs the harbormaster (opposed)\n  Why    sweet-talk Greta Brandt")
        g.out("[GUARD] a log line stays as it is: Brandt")
        await asyncio.sleep(0.05)                     # (the out hook hands its line to the loop: then the post)
        await t.drain()
        return ch.sent
    sent = asyncio.run(go())
    said = "\n".join(m["text"] or "" for m in sent)
    assert "sweet-talk the harbormaster" in said and not _leaks(said)
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert spoiled and not _leaks(json.dumps(spoiled))
    assert spoilers.card(g, "[NUYEN] 500 : Razor -> the world (a bribe for Corwin Vale)") == \
        "[NUYEN] 500 : Razor -> the world (a bribe for the man in a green coat)"


# ── the guard's own review (2026-10-28): each way past it, closed ───────

def _call(tool_name, **inp):
    return SimpleNamespace(type="tool_use", name=tool_name, input=inp, id=f"tu_{tool_name}")


def test_the_seed_keeps_every_label_the_gm_file_gives_anyone(make_game, tmp_path):
    """The rehearsal's leak 2, at its root: the GM file's nickname for a public NPC - a plain word of what anyone sees of
    her, capitalized - was never a term (only real names and handled names were kept), so SEALED never named it, the
    frame's scrub left it and the narration said it. It's hers on file now, cut capitalized - the plain word stands."""
    gm = GM + ' On the pier they call her **"Crates" (Greta Brandt)**; the dockhands know him as "Flyers".'
    g = make_game(FakeLLM([], MEMORY))
    setup_demo(g)
    seed.apply(g, [DOCS[0], seed.Doc("night-ferry.GM.md", gm, True)], plan(), "night-ferry")
    harbor, vale = g.ledger.find("the harbormaster"), g.ledger.find("the man in a green coat")
    assert harbor["props"]["gm_names"] == ["Crates"] and "Crates" not in (vale["props"].get("gm_names") or [])
    assert [t for t, _ in spoilers.hits(g, "Crates nods. CRATES!")] == ["Crates"]
    assert spoilers.hits(g, "She counts the crates twice.") == []          # (her description's word: a plain one)
    assert spoilers.scrub(g, '**Crates:** "Move along."')[0] == '**The harbormaster:** "Move along."'
    assert spoilers.narration(g, '**Crates:** "Move along."')
    assert '"Crates"' in "\n".join(spoilers.packet_lines(g))
    # the read's labels by their shapes - beside a name of theirs only, and never a name the player-safe story says
    assert seed.gm_labels('Tom Fenn ("Ferryman") rows. Greta "Tally" Brandt counts.', ["Tom Fenn"], "", []) == \
        ["Ferryman"]
    assert seed.gm_labels('Greta "Tally" Brandt counts.', ["Greta Brandt"], "", []) == ["Tally"]
    assert seed.gm_labels('Tom Fenn, known as "Ferryman", rows.', ["Tom Fenn"], "", []) == ["Ferryman"]
    assert seed.gm_labels('**"The Ferryman" (Tom Fenn)**', ["Tom Fenn"], "A man waits for the Ferryman.", []) == []
    assert seed.gm_labels('**"Ferryman" (Tom Fenn)**', ["Tom Fenn"], "", ["the ferryman"]) == []


def test_a_handle_filed_title_cased_never_reveals_its_owners_label(make_game):
    """Rehearsal round 1 (2026-10-28), on the owner's story: the read filed a public NPC's handle title-cased, so it held
    her GM label's word capitalized - and so did every item filed after her. A name on file holding a word as written
    counted as revealing it: the label was no term at all, and SEALED, the frame and the cut all went without it. Now
    it's cut on its own, and the names on file that hold it stand as written."""
    gm = GM + ' On the pier they call her **"Crates" (Greta Brandt)**.'
    p = plan()
    p["people"][1]["name"] = "The Dwarf Who Counts Crates"
    g = make_game(FakeLLM([], MEMORY))
    setup_demo(g)
    seed.apply(g, [DOCS[0], seed.Doc("night-ferry.GM.md", gm, True)], p, "night-ferry")
    harbor = g.ledger.find("The Dwarf Who Counts Crates")
    board = g.ledger.get(g.introduce("item", "The Dwarf Who Counts Crates's tally board", "a chalked board")[0])
    assert harbor["props"]["gm_names"] == ["Crates"]
    assert [t for t, _ in spoilers.hits(g, "Crates nods.")] == ["Crates"]
    assert spoilers.hits(g, "She counts the crates twice.") == []
    assert spoilers.hits(g, f"{harbor['name']} nods at {board['name']}.") == []
    assert spoilers.scrub(g, f'**Crates:** "Move along." {harbor["name"]} waits.')[0] == \
        f'**{harbor["name"]}:** "Move along." {harbor["name"]} waits.'
    assert '"Crates"' in "\n".join(spoilers.packet_lines(g))
    speakers.rename(g, harbor["id"], "Crates")                    # (a `name` line in play: hers from then on)
    assert spoilers.hits(g, "Crates nods.") == []


def test_introduce_reads_every_name_it_would_file_and_an_alias_never_reveals(make_game):
    """An alias holding a GM-only name was filed unread - and then counted as revealing it, everywhere; and a name on
    file as another kind skipped the check while game.introduce filed something new under it."""
    from roleplay.dm.tools import run_tool
    g, ids = _seeded(make_game)
    L = g.ledger
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    out = run_tool(ctx, _call("introduce", kind="npc", name="a dockhand", description="a wiry dockhand in oilskins",
                              aliases=["Greta Brandt"]))
    assert out.get("is_error") and "the harbormaster" in out["content"] and not L.find("a dockhand")
    gang = L.get(g.introduce("faction", "The Ancients", "an elf street gang")[0])
    out = run_tool(ctx, _call("introduce", kind="location", name=gang["name"],
                              description="the back room where Greta Brandt keeps the Syndicate's books"))
    assert out.get("is_error") and not [e for e in L.entities(kind="location") if e["name"] == gang["name"]]
    out = run_tool(ctx, _call("introduce", kind="npc", name="the harbormaster", description="Greta Brandt, of course"))
    assert not out.get("is_error") and out["content"].startswith("Already known as")    # (no one new: nothing filed)
    L.update_entity(ids["harbor"], aliases=["Greta Brandt"])         # (an alias filed some other way - a merge, a hand)
    assert spoilers.hits(g, "Greta Brandt waves.") and '"Greta Brandt"' in "\n".join(spoilers.packet_lines(g))


def test_the_asides_direction_and_fix_cards_are_guarded(make_game, tmp_path):
    """The aside's card says its direction ("Next turn: ...") and quotes its [FIX] cards - the GM's own words, posted
    outside the out hook; only its answer was scrubbed."""
    import asyncio
    from roleplay.discord_bot.session import CampaignTable
    from .test_discord import FakeChannel

    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            return {"answer": "Sure - next turn.",
                    "direction": "Greta Brandt comes out of the harbor office to meet the crew.",
                    "fixes": ["fix kaz: template expert - Corwin Vale set him up as a fence"], "is_move": False,
                    "loop": False}
        return MEMORY
    g, ids = _seeded(make_game, FakeLLM([], structured))

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.gm_aside("2", "Alice", "Hey DM, can the harbormaster come talk to us next turn?", react)
        await asyncio.sleep(0.05)
        await t.drain()
        return ch.sent
    sent = asyncio.run(go())
    card = next(m for m in sent if (m["title"] or "").startswith("🎙️ GM aside"))
    assert "-# Next turn: The harbormaster comes out of the harbor office" in card["description"]
    assert "the man in a green coat set him up as a fence" in card["description"]
    assert not _leaks(json.dumps(sent)) and not _leaks(" | ".join(aside.directions(g)))
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert any(f["text"].startswith("The aside's direction") for f in spoiled) and not _leaks(json.dumps(spoiled))


def _move(**over) -> dict:
    d = {"decision": "start", "agenda_id": "", "goal": "Keep the ferry running quietly", "targets": [],
         "action": "Sends word down the pier", "test_skill": "", "test_threshold": 2, "on_success": "",
         "on_failure": "", "learns_on_success": [], "spend": 0, "new_people": [], "contacts": [], "acquire": [],
         "whereabouts": [], "hook": "", "hook_about": [], "hook_replaces": [], "feeling_about": "",
         "feeling_attitude": 0, "feeling_belief": "", "wait_minutes": 30}
    return {**d, **over}


def test_what_the_world_writes_of_someone_is_guarded(make_game, tmp_path):
    """The world checked a newcomer's and a contact's name and filed their descriptions as written - public by birth
    (the dashboard's people, the art's story, !dossier), from a model that reads the actor's GM notes. An outfit's
    profile summary too. And !dossier's card, unlike the recap's, posted as its model wrote it."""
    from roleplay import recap
    from roleplay.dashboard import data as dash

    def structured(user):
        if user.startswith("STORY TIME NOW:") and "SUBJECT [" in user:
            return {"alias": "", "affiliation": "Odile Marchetti", "status": "CONTACT",
                    "who": "A skinny kid who carries messages for Odile Marchetti.", "lately": "Ran past the crew."}
        return {**MEMORY, "members": [{"id": "razor", "role": "actor"},
                                      {"id": g.ledger.find("Dock Rat")["id"], "role": "present"}]}
    g, ids = _seeded(make_game, FakeLLM([([text("A kid in a torn hoodie sprints past Razor.")], "end_turn")],
                                        structured))
    L = g.ledger
    world.apply(g, world.Job("agent", ids["boss"], "", g.turn_no()), _move(
        new_people=[{"name": "Dock Rat", "template": "civilian",
                     "description": "a skinny kid who carries messages for Odile Marchetti"}],
        contacts=[{"who": "Pier Warden", "kind": "npc", "template": "civilian", "says": "Keep the night ferry clear.",
                   "shares": [], "description": "an old warden who owes Greta Brandt a favour"}]))
    assert L.find("Dock Rat")["description"] == "a skinny kid who carries messages for someone"
    assert L.find("Pier Warden")["description"] == "an old warden who owes the harbormaster a favour"
    crew = g.introduce("faction", "The Tidewater Crew")[0]
    world.apply(g, world.Job("faction_persona", crew, "", g.turn_no()),
                {"summary": "Boatmen who run boxes for Corwin Vale.", "reach": 2, "funds": 5000})
    assert L.get(crew)["description"] == "Boatmen who run boxes for the man in a green coat."
    shown = json.dumps(dash.people(g.path.stem, folder=g.path.parent))
    assert "Dock Rat" in shown and not _leaks(shown)
    g.run_turn([("razor", "I watch the pier.")])
    card = recap.file_on(g, L.find("Dock Rat")["id"])
    assert card["who"] == "A skinny kid who carries messages for someone." and not _leaks(json.dumps(card))
    assert not _leaks(json.dumps(flags.listing(tmp_path)))


def test_the_memory_pass_never_puts_someone_sealed_where_the_narration_never_showed_them(make_game, tmp_path):
    """Only 'mentioned' was checked: a pass that filed him 'present' - the narration never showing him, the GM's note
    on him in ENGINE EVENTS - unsealed him as surely as T191's 'mentioned', and walked him into the room. A witness
    role stands when the narration calls them by their handle, or they were in the scene when the turn began."""
    from roleplay.dashboard import data as dash

    def extraction(user):
        return {**MEMORY, "members": [{"id": "razor", "role": "actor"}, {"id": ids["vale"], "role": "present"}]}
    llm = FakeLLM([([text("Razor watches the dock from under the awning.\n<dm>\nnote the-man-in-a-green-coat: he "
                          "watches Razor from the ferry's upper deck\n</dm>")], "end_turn"),
                   ([text("Razor waits by the bollards.")], "end_turn")], extraction)
    g, ids = _seeded(make_game, llm)
    res = g.run_turn([("razor", "I watch the dock.")])
    assert ids["vale"] not in dict(g.sub.members_of(res.slice_id)) and ids["vale"] in seed.sealed_ids(g.conn)
    assert ids["vale"] not in g.ledger.roster(g.current_scene_id())
    assert "the man in a green coat" not in json.dumps(dash.people(g.path.stem, folder=g.path.parent))
    spoiled = [f for f in flags.listing(tmp_path) if f["kind"] == "spoiler"]
    assert any("never showed them" in f["text"] for f in spoiled) and not _leaks(json.dumps(spoiled))
    g.enter_scene([ids["vale"]], g.turn_no())                       # (in the room when the turn begins: there)
    res = g.run_turn([("razor", "I wait.")])
    assert dict(g.sub.members_of(res.slice_id))[ids["vale"]] == "present" and ids["vale"] not in seed.sealed_ids(g.conn)


def test_a_handle_said_with_other_articles_is_still_the_handle(make_game):
    """The handle was wanted word for word: "the man in the green coat" (his is "a green coat") lost the fact the crew
    had just heard about him, and he stayed sealed though the table had met him."""
    def extraction(user):
        return {**MEMORY, "facts": [{"text": "The man in the green coat works the docks.", "about": [ids["vale"]],
                                     "replaces": ""}]}
    g, ids = _seeded(make_game, FakeLLM([([text("\"The man in the green coat works the docks,\" Kaz says.")],
                                          "end_turn")], extraction))
    res = g.run_turn([("razor", "Who hands out the flyers?")])
    fact = g.sub.node(res.info["facts"][0])
    assert ids["vale"] in [x["other"] for x in g.sub.links_of(fact["id"])] and ids["vale"] not in seed.sealed_ids(g.conn)
    assert spoilers.says_handle(g, ids["vale"], "that man in the green coat")
    assert not spoilers.says_handle(g, ids["vale"], "a man in a coat")


def test_a_name_line_reveals_only_its_own_persons_name(make_game, tmp_path):
    """Any `name` line let its text through: one on no one (the record kept her name hidden), one on the wrong person
    (he took her name, and the guard dropped it for good), one that carried a second hidden name - and a fact beside
    a line that landed nowhere was filed public under the name. A line counts only on its owner's own id; one that
    can't be taken is refused, spoiler-free."""
    clean = "The harbormaster counts crates."
    lines = ("name nobody-here: Greta Brandt", "name the-man-in-a-green-coat: Greta Brandt",
             "name the-harbormaster: Greta Brandt, who keeps Corwin Vale's books")
    for line in lines:
        llm = Seeing([([text(f"Greta Brandt counts crates.\n<dm>\n{line}\nfact the-harbormaster: Greta Brandt runs the "
                              "harbor office.\n</dm>")], "end_turn"), ([text(clean)], "end_turn")], MEMORY)
        g, ids = _seeded(make_game, llm)
        res = g.run_turn([("razor", "What's your name?")])
        assert res.narration == clean and len(llm.seen) == 2, line         # (sent back: nothing revealed it)
        assert g.ledger.get(ids["harbor"])["name"] == "the harbormaster", line
        assert g.ledger.get(ids["vale"])["name"] == "the man in a green coat", line
        assert not [f for f in g.sub.facts_for(ids["harbor"], 5) if "Greta" in f["text"]], line   # (a GM note)
        assert spoilers.hits(g, "Greta Brandt waves.") and spoilers.hits(g, "Corwin Vale waves."), line
    assert not _leaks(json.dumps(flags.listing(tmp_path)))
    back = spoilers.send_back(g, spoilers.hits(g, "Greta Brandt waves."))
    assert "on that person's own id, never a way to keep one" in back


def test_between_turns_no_name_line_reveals_a_hidden_one(make_game, tmp_path):
    """The aside reads SEALED and may write `name` in its fixes: it named a sealed NPC nobody had met, with no play at
    all, and the guard let his name through from then on. Between turns a name line can't reveal a hidden name, nor
    name someone the crew hasn't met - a plain correction still lands."""
    fix = ["name the-man-in-a-green-coat: Corwin Vale"]

    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            return {"answer": "Done.", "direction": "", "fixes": [fix[0]], "is_move": False, "loop": False}
        return MEMORY
    g, ids = _seeded(make_game, FakeLLM([], structured))
    for line in fix[:], ["name the-harbormaster: Greta Brandt"], ["name the-man-in-a-green-coat: Greencoat"]:
        fix[0] = line[0]
        res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, put their real name on file?", "razor")
        assert res["fixed"] == [], line
    assert g.ledger.get(ids["vale"])["name"] == "the man in a green coat" and ids["vale"] in seed.sealed_ids(g.conn)
    assert g.ledger.get(ids["harbor"])["name"] == "the harbormaster" and spoilers.hits(g, "Corwin Vale hands it over.")
    fix[0] = "name kaz: Kazimir"                                   # (a name the table may know: a slip set right)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, it's Kazimir, not Kaz.", "razor")
    assert res["fixed"] == ["a name"] and g.ledger.get("kaz")["name"] == "Kazimir"
    assert not _leaks(json.dumps(flags.listing(tmp_path)))


def test_a_waiting_fact_that_says_a_gm_only_name_reaches_the_pass_as_gm_only(make_game):
    """On the line's own path a fact saying a hidden name is kept as a GM note, and the pass reads it by kind and ids;
    waiting for someone not on file yet, its words - scrubbed of the name, its plot whole - reached the pass that
    writes the public summary."""
    seen, extraction = _memory_prompts()
    g, ids = _seeded(make_game, FakeLLM([([text("Kaz shrugs.\n<dm>\nfact the-man-in-a-green-coat, somebody-new: "
                                                 "Corwin Vale smuggles guns under the fish crates\n</dm>")], "end_turn")],
                                        extraction))
    g.run_turn([("razor", "Kaz, what's under the crates?")])
    memory = next(u for u in seen if "NARRATION:" in u)
    assert "fish crates" not in memory and "a GM-only line" in memory.split("ENGINE EVENTS", 1)[1]
    assert not [f for f in g.sub.facts_for(ids["vale"], 5) if "fish crates" in f["text"]]
    assert any("fish crates" in n["text"] for n in g.sub.notes_for(ids["vale"], 5))


def test_no_flag_says_a_gm_only_name(make_game, tmp_path):
    """Only the guard's own flags were kept spoiler-free: a tool error kept the GM's whole input, the spoke-for-a-player
    guard quoted the draft before the spoiler guard read it, and a GM `flag:` line was filed as written - on the
    flags page the owner reads."""
    from roleplay.dm.turn import hands_off
    llm = FakeLLM([
        ([_call("annotate", target_ids=["harbor-master"],
                text="Greta Brandt keeps the Syndicate's books for Odile Marchetti.")], "tool_use"),
        ([text('**Ghost:** "Greta Brandt, right? Odile Marchetti sends her regards."')], "end_turn"),
        ([text("The harbormaster looks up from her crates.\n<dm>\nflag: the packet called her Greta Brandt but SEALED "
               "says the harbormaster\n</dm>")], "end_turn")], MEMORY)
    g, ids = _seeded(make_game, llm)
    g.enter_scene(["ghost"], g.turn_no())
    assert hands_off(g, g.current_scene_id(), [("razor", "x")]) == ["Ghost"]
    g.run_turn([("razor", "I nod to the harbormaster.")])
    listing = flags.listing(tmp_path)
    assert {"tool error", "spoke for a player", "gm flag"} <= {f["kind"] for f in listing}
    assert not _leaks(json.dumps(listing))
    gm = next(f for f in listing if f["kind"] == "gm flag")
    assert gm["text"] == "the packet called her the harbormaster but SEALED says the harbormaster"


def test_an_art_change_and_its_caption_are_guarded(tmp_path):
    """update_art's change is posted under the new picture, and the caption is written from it - an art post never
    meets the out hook."""
    import asyncio
    from roleplay.art import ArtDirector
    from roleplay.discord_bot.session import CampaignTable
    from roleplay.dm.tools import run_tool
    from roleplay.game import Game
    from .test_discord import FakeChannel

    class Painter:
        name, model, edit_model = "fake", "fake-1", "fake-edit"

        def generate(self, prompt, size):
            return b"\x89PNG fake"

        def edit(self, image_path, prompt, size):
            return b"\x89PNG fake edit"

    def structured(user):
        if user.startswith("MODE: "):                       # (the art writer echoes the change into its caption)
            return {"prompt": "TASK: Edit the provided image.",
                    "caption": "The harbormaster - Greta Brandt to her friends - with a ledger under her arm."}
        return MEMORY
    art = ArtDirector(tmp_path / "art", "x", provider=Painter(), out=lambda s: None)
    g = Game(tmp_path / "w.db", llm=FakeLLM([], structured), art=art, out=lambda s: None)
    setup_demo(g)
    seed.apply(g, DOCS, plan(), "night-ferry")
    harbor = g.ledger.find("the harbormaster")["id"]
    first = tmp_path / "art" / f"{harbor}.png"
    first.parent.mkdir(parents=True, exist_ok=True)
    first.write_bytes(b"\x89PNG first")
    g.conn.execute("INSERT INTO art(entity_id, version, path, status, story, provider, created_turn) "
                   "VALUES(?,?,?,?,?,?,?)", (harbor, 1, str(first), "ready", "", "fake", 1))
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        out = run_tool(ctx, _call("update_art", entity_id=harbor,
                                  change="Greta Brandt now carries the Syndicate's ledger for Odile Marchetti"))
        assert not out.get("is_error"), out
        for _ in range(100):
            await asyncio.sleep(0.02)
            if any("changed" in (m["title"] or "") for m in ch.sent):
                break
        await t.drain()
        return ch.sent
    try:
        sent = asyncio.run(go())
        post = next(m for m in sent if "changed" in (m["title"] or ""))
        assert "now carries the outfit in lantern-red scarves' ledger for someone" in post["description"]
        assert not _leaks(post["description"]) and not _leaks(" ".join(ctx.events))
    finally:
        g.art.shutdown(wait=True)
        g.close()


def test_a_shop_never_opens_under_a_gm_only_name(make_game):
    """open_shop's name and kind are the !shop card's title and first line, posted straight to the channel."""
    from roleplay.dm.tools import run_tool
    g, ids = _seeded(make_game)
    here = next(e["id"] for e in g.ledger.entities(kind="location"))
    ctx = TurnContext(g, g.turn_no() + 1, g.current_scene_id())
    out = run_tool(ctx, _call("open_shop", location_id=here, name="Brandt's Chandlery",
                              kind="the Syndicate's back-room fence", items=["medkit"], markup=1.0))
    assert out.get("is_error") and "the harbormaster" in out["content"]
    assert not g.ledger.get(here)["props"].get("shop")
    out = run_tool(ctx, _call("open_shop", location_id=here, name="The Chandlery", kind="a ship's chandler",
                              items=["medkit"], markup=1.0))
    assert not out.get("is_error") and g.ledger.get(here)["props"]["shop"]["name"] == "The Chandlery"


def test_a_send_back_never_costs_the_turn_nor_a_second_roll(make_game):
    """Sent back on the turn's last narrating step, a rewrite that reached for a tool - or came back empty - lost the
    turn, though the engine held a narration it could scrub; and a rewrite's tools ran, 'No tools - the rolls stand'
    or not: one action, two rolls."""
    slip, said = ("Greta Brandt counts the crates twice and waves Razor off.",
                  "The harbormaster counts the crates twice and waves Razor off.")
    roll = dict(actor_id="razor", skill="perception", attribute="intuition", threshold=2, why="spot the crates")
    llm = Seeing([], MEMORY)
    g, ids = _seeded(make_game, llm)
    m = g.settings.models.dm_max_steps
    llm.dm_script = [([tool("annotate", target_ids=["razor"], text=f"note {i}")], "tool_use") for i in range(m)] + [
        ([text(slip)], "end_turn"), ([tool("annotate", target_ids=["razor"], text="one more")], "tool_use")]
    res = g.run_turn([("razor", "I watch the harbormaster.")])
    assert res.narration == said and len(llm.dm_requests) == m + 1      # (the last step: scrubbed, never sent back)
    for rewrite in ([tool("request_test", **roll)], "tool_use"), ([text("  ")], "end_turn"):
        llm = Seeing([([tool("request_test", **roll)], "tool_use"), ([text(slip)], "end_turn"), rewrite], MEMORY)
        g, ids = _seeded(make_game, llm)
        res = g.run_turn([("razor", "I look the crates over.")])
        kinds = [r[0] for r in g.conn.execute("SELECT kind FROM events WHERE turn_id=?", (res.turn_id,))]
        assert res.narration == said and kinds.count("test") == 1, rewrite
    # and a rewrite for a player's hands-off character answers its tool calls, never runs them
    llm = Seeing([([tool("request_test", **roll)], "tool_use"), ([text("Ghost nods and takes the flyer.")], "end_turn"),
                  ([tool("request_test", **roll)], "tool_use"), ([text("Ghost watches the crates.")], "end_turn")],
                 MEMORY)
    g, ids = _seeded(make_game, llm)
    g.enter_scene(["ghost"], g.turn_no())
    res = g.run_turn([("razor", "I look the crates over.")])
    kinds = [r[0] for r in g.conn.execute("SELECT kind FROM events WHERE turn_id=?", (res.turn_id,))]
    assert res.narration == "Ghost watches the crates." and kinds.count("test") == 1


def test_a_word_the_table_reads_plainly_is_cut_only_capitalized(make_game):
    """Every word of a GM-only name was cut in any case: "Every crime syndicate ... the vale below the overpass" went
    back to the GM and lost both nouns. A word the public record (or the rules, or the seed's own texts) uses plainly
    is cut only capitalized - "the Syndicate" still is - and a name of two words in any case."""
    g, ids = _seeded(make_game)
    line = "Every crime syndicate in the sprawl wants this pier, and the fog lies in the vale below the overpass."
    assert spoilers.hits(g, line)                                       # (nothing the table read says either yet)
    g.sub.add_fact("A crime syndicate runs half the vale's piers.", ["razor"], g.turn_no())
    assert spoilers.hits(g, line) == [] and [t for t, _ in spoilers.hits(g, "Ask the Syndicate.")] == ["Syndicate"]
    assert [t for t, _ in spoilers.hits(g, "Vale watches. VALE!")] == ["Vale"]
    assert [t for t, _ in spoilers.hits(g, "corwin vale waves")] == ["Corwin Vale"]
    assert seed.plain_words("A crime syndicate.", "The Syndicate pays Odile.", ["Syndicate", "Corwin Vale", "Odile"]) \
        == ["Syndicate"]


WET = [seed.Doc("wet.md", "# Wet Market\nThe crew waits under the market awning. A cook in a paper hat fries noodles. "
                          "A fixer in a red hat haggles over a crate. A dockhand with a limp hauls nets, and his "
                          "sister mends them.", False),
       seed.Doc("wet.GM.md", "## For the GM only\nThe cook is Kim Ng. The fixer is Siobhan O'Malley. The dockhand is "
                             "Oskar Brandt; his sister is Greta Brandt.", True)]


def _wet_plan() -> dict:
    def p(key, name, true, desc):
        return {"template": "civilian", "persona": {}, "where": "", "place": "", "dead": False, "key": key,
                "name": name, "true_name": true, "known": True, "description": desc, "secret": "."}
    return {"title": "Wet Market", "intent": "x", "arc": "",
            "secret_words": ["Kim Ng", "Siobhan O'Malley", "Oskar Brandt", "Greta Brandt"],
            "people": [p("cook", "the cook", "Kim Ng", "a cook in a paper hat"),
                       p("fixer", "the fixer in the red hat", "Siobhan O'Malley", "a fixer in a red hat"),
                       p("dock", "the dockhand", "Oskar Brandt", "a dockhand with a limp"),
                       p("sister", "the dockhand's sister", "Greta Brandt", "she mends nets")],
            "outfits": [], "places": [], "ties": [], "facts": [], "events": [], "feelings": [], "agendas": [],
            "hooks": [], "tensions": [], "job": {}, "contradictions": [], "opening": {}}


def test_the_shapes_a_name_takes_at_the_table(make_game):
    """A plural or a possessive, a curly apostrophe, a title before it, a name split by markdown, a two-letter surname,
    an O' name's own part, a surname two people share - each was missed, or garbled, or handed to the wrong one."""
    g, ids = _seeded(make_game)
    put = lambda s: spoilers.scrub(g, s)[0]                              # noqa: E731
    assert put("Kaz eyes the Brandts' boat, Vale’s coat.") == \
        "Kaz eyes the harbormaster's boat, the man in a green coat’s coat."
    assert put("He nods at Mr. Vale. Marchettis never wait.") == "He nods at the man in a green coat. Someone never wait."
    assert put("**Greta** Brandt waves.") == "**The harbormaster** waves."
    assert put("Greta\n> Brandt waves.") == "The harbormaster waves."
    assert put("Ask the Syndicate's boys.") == "Ask the outfit in lantern-red scarves' boys."
    w = make_game(FakeLLM([], MEMORY))
    setup_demo(w)
    seed.apply(w, WET, _wet_plan(), "wet")
    put = lambda s: spoilers.scrub(w, s)[0]                              # noqa: E731
    assert put('Ng flips the noodles. "Thanks, Ms. Ng."') == 'The cook flips the noodles. "Thanks, the cook."'
    assert put("O’Malley counts the cash; Malley always does.") == \
        "The fixer in the red hat counts the cash; the fixer in the red hat always does."
    assert put("Oskar's sister, Ms. Brandt, keeps mending.") == "The dockhand's sister, someone, keeps mending."
    sealed = "\n".join(spoilers.packet_lines(w))
    assert '"Brandt" is a GM-only name of more than one of them' in sealed and "the dockhand (" in sealed
    assert "the dockhand's sister (" in sealed


def test_a_move_to_a_place_under_a_gm_only_name_files_no_place(make_game):
    """moved_to was scrubbed, not refused: the cut filed a public place called "Someone" - and every later "someone"
    read as a mention of it - or a second entity under a sealed NPC's handle, announced at the table."""
    for place in ("Odile Marchetti's boathouse", "Corwin Vale"):
        held = []

        def extraction(user):
            gm = held[0]
            pcs = [e for e in gm.ledger.roster(gm.current_scene_id()) if gm.ledger.get(e)["kind"] == "pc"]
            return {**MEMORY, "moved_to": {"location": place, "description": "a place by the water", "who": pcs}}
        g, ids = _seeded(make_game, FakeLLM([([text("Everyone follows the crates down the pier.")], "end_turn")],
                                            extraction))
        held.append(g)
        before, scene = {e["id"] for e in g.ledger.entities(status=None)}, g.current_scene_id()
        g.run_turn([("razor", "We follow the crates.")])
        assert {e["id"] for e in g.ledger.entities(status=None)} == before and g.current_scene_id() == scene, place
        assert g.ledger.find("someone") is None, place
