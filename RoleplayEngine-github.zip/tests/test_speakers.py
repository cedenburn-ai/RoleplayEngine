"""Dialogue carries who's speaking: **Pruett [ration-man]:** - names drift, ids don't."""
import asyncio

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm import speakers
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel

EXTRACTION = {"summary": "The watcher gave his name.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []},
              "members": [{"id": "razor", "role": "actor"}]}


def test_ids_are_stripped_and_a_new_name_is_learned(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    eid = L.create_entity("npc", "Ration Man", "Neat man in a navy jacket.", tier=2)
    clean, said, learned = speakers.resolve(g, '**Pruett [ration-man]:** "Outreach."\n\n**Kaz [kaz]:** "Huh."\n\n'
                                               '**Voice on the radio:** "Copy."')
    assert clean == '**Pruett:** "Outreach."\n\n**Kaz:** "Huh."\n\n**Voice on the radio:** "Copy."'
    assert said == {"Pruett": eid, "Kaz": "kaz"} and learned == ["Pruett = Ration Man"]
    assert L.find("Pruett")["id"] == eid                                         # found everywhere now
    _, said, learned = speakers.resolve(g, '**Kaz [ration-man]:** "..."')       # someone else's name stays theirs
    assert said == {"Kaz": eid} and learned == [] and L.find("Kaz")["id"] == "kaz"
    _, said, _ = speakers.resolve(g, '**Ghost [no-such-id]:** "..."')              # a bad id: no claim
    assert said == {}


def test_a_name_revealed_renames_and_keeps_the_old_one(make_game):
    g = make_game()
    setup_demo(g)
    L = g.ledger
    eid = L.create_entity("npc", "Ration Man", "Neat man in a navy jacket.", tier=2)
    assert speakers.rename(g, eid, "Pruett", 9) == "Ration Man is on file as Pruett now"
    ent = L.get(eid)
    assert ent["name"] == "Pruett" and "Ration Man" in ent["aliases"] and L.find("Ration Man")["id"] == eid
    import pytest
    from roleplay.engine.ledger import LedgerError
    with pytest.raises(LedgerError, match="already someone else"):
        speakers.rename(g, eid, "Kaz")


def test_the_gm_tags_the_speaker_and_the_right_face_goes_with_the_line(make_game):
    narration = ('The man in the passenger seat swallows.\n\n**Pruett [ration-man]:** "Name\'s Pruett."\n\n'
                 '<dm>\nname ration-man: Pruett\n</dm>')
    g = make_game(FakeLLM([([text(narration)], "end_turn")], EXTRACTION))
    setup_demo(g)
    L = g.ledger
    eid = L.create_entity("npc", "Ration Man", "Neat man in a navy jacket.", tier=2)
    res = g.run_turn([("razor", "Who are you?")])
    assert "[ration-man]" not in res.narration and '**Pruett:** "Name\'s Pruett."' in res.narration
    assert res.info["speakers"] == {"Pruett": eid} and L.get(eid)["name"] == "Pruett"
    assert any(c.startswith("[NAME] Ration Man is on file as Pruett") for c in res.cards)
    card = CampaignTable._dialogue_card(type("T", (), {"game": g})(), {"speaker": "Pruett", "text": "x"},
                                        said=res.info["speakers"])
    assert card["speaker_id"] == eid and card["author"] == "Pruett"


def test_rename_is_the_owners(make_game):
    g = make_game()
    setup_demo(g)
    g.ledger.create_entity("npc", "Ration Man", "Neat man in a navy jacket.", tier=2)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("2", "Bob", "!rename Ration Man = Pruett", False, react)
        assert "campaign owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!rename Ration Man = Pruett", True, react)
        assert ch.sent[-1]["text"] == "📇 Ration Man is on file as Pruett now."
        await t.close()
    asyncio.run(go())
