"""Discord layer without Discord: the turn director's timing, and a full table on a fake channel."""
import asyncio

from roleplay.art import ArtDirector, NullArtProvider
from roleplay.discord_bot.render import card_messages, chunks, classify
from roleplay.discord_bot.session import CampaignTable
from roleplay.discord_bot.table import TableDirector
from roleplay.game import Game
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool


def run(coro):
    return asyncio.run(coro)


# ── the director ─────────────────────────────────────────────────────────

def test_resolves_after_grace_when_everyone_acted():
    async def go():
        got = []

        async def resolve(inputs):
            got.append(inputs)
        d = TableDirector(resolve, lambda: {"razor", "ghost"}, quiet=5, cap=10, grace=0.05)
        d.add("razor", "a")
        await asyncio.sleep(0.15)
        assert not got and d.waiting_on() == {"ghost"}          # still waiting on Ghost
        d.add("ghost", "b")
        await asyncio.sleep(0.2)
        assert got == [[("razor", "a"), ("ghost", "b")]]
    run(go())


def test_quiet_timer_resolves_with_whoever_spoke_and_typing_resets_it():
    async def go():
        got = []

        async def resolve(inputs):
            got.append(inputs)
        d = TableDirector(resolve, lambda: {"razor", "ghost"}, quiet=0.3, cap=10, grace=0.05, typing_grace=0.3)
        d.add("razor", "a")
        await asyncio.sleep(0.2)
        d.typing("ghost")                                     # Ghost is typing: keep waiting
        await asyncio.sleep(0.2)
        assert not got
        await asyncio.sleep(0.25)
        assert got == [[("razor", "a")]]
    run(go())


def test_go_and_cap_and_next_batch():
    async def go():
        got = []

        async def resolve(inputs):
            got.append(inputs)
            await asyncio.sleep(0.1)                          # the GM is thinking
        d = TableDirector(resolve, lambda: {"razor", "ghost"}, quiet=5, cap=0.3, grace=0.05)
        d.add("razor", "a")
        assert d.go()
        await asyncio.sleep(0.05)
        d.add("ghost", "late")                                # arrives mid-resolution -> next batch
        await asyncio.sleep(0.5)                              # cap (0.3 s) resolves it without everyone
        assert got == [[("razor", "a")], [("ghost", "late")]]
        assert not d.go()                                     # nothing queued
    run(go())


def test_parse_story_keeps_order_and_splits_speakers():
    from roleplay.discord_bot.render import parse_story
    segs = parse_story('Kaz sets the glass down.\n\n**Kaz:** "Tanaka." He shrugs.\n\n'
                       'Through clenched tusks: **Kaz:** "Pick fast." **Booth Guy:** "Easy."\n\n'
                       '**RETRIEVAL 3: HOLDING AT RALLY.** The van waits.')
    kinds = [(s["kind"], s.get("speaker")) for s in segs]
    assert kinds == [("narration", None), ("dialogue", "Kaz"), ("narration", None), ("dialogue", "Kaz"),
                     ("dialogue", "Booth Guy"), ("narration", None)]
    assert segs[1]["text"] == '"Tanaka." He shrugs.' and segs[2]["text"] == "Through clenched tusks"
    assert segs[-1]["text"].startswith("**RETRIEVAL 3")          # bold that isn't a speaker stays narration


def test_story_cards_portraits_big_then_thumbnail(tmp_path):
    from types import SimpleNamespace
    from PIL import Image

    async def go():
        art = ArtDirector(tmp_path / "art", "x", provider=NullArtProvider(), out=lambda s: None)
        g = Game(tmp_path / "s.db", llm=FakeLLM(), art=art, out=lambda s: None)
        setup_demo(g)
        (tmp_path / "art").mkdir(exist_ok=True)
        for eid in ("kaz", "the-lucky-shot"):
            p = tmp_path / "art" / f"{eid}.png"
            Image.new("RGB", (512, 512), (90, 20, 120)).save(p)
            g.conn.execute("INSERT INTO art(entity_id, version, path, status) VALUES(?,?,?,?)", (eid, 1, str(p), "ready"))
        t = CampaignTable(g, FakeChannel(), owner_id="1")
        res = SimpleNamespace(turn_id=4, info={"introduced": []},
                              narration='The neon buzzes.\n\n**Kaz:** "Tanaka."\n\n**Kaz:** "Go."\n\n**A Bouncer:** "Move."')
        cards = await t.run(t._story_cards, res, False)
        assert cards[0]["description"].startswith("📍") and cards[0]["thumbnail"].endswith(".jpg")   # location strip
        assert cards[1]["color"] == 0x9B59B6 and cards[1]["description"] == "The neon buzzes."
        assert cards[2]["author"] == "Kaz" and cards[2]["image"].endswith("kaz.png")     # first time: big portrait
        assert cards[3]["author"] == "Kaz" and cards[3]["thumbnail"].endswith(".jpg") and not cards[3].get("image")
        assert cards[4]["author"] == "A Bouncer" and cards[4]["color"] == 0x95A5A6       # extra: gray, no portrait
        assert cards[-1]["footer"].startswith("T4 ·")
        moved = await t.run(t._story_cards, res, True)
        assert moved[0]["title"].startswith("📍 The Lucky Shot") and moved[0]["image"]  # arrived: big location card
        await t.close()
    run(go())


def test_discord_channel_batches_cards_and_attachments(tmp_path):
    from roleplay.discord_bot.bot import DiscordChannel

    class Sink:
        def __init__(self):
            self.messages = []

        async def send(self, content=None, **kw):
            self.messages.append(kw)

    imgs = []
    for i in range(3):
        p = tmp_path / f"p{i}.png"
        p.write_bytes(b"\x89PNG")
        imgs.append(str(p))
    cards = [{"description": f"para {i}", "color": 1} for i in range(6)]
    cards[1]["image"] = imgs[0]
    cards[2]["thumbnail"] = imgs[0]                       # same picture twice in one message -> one file
    cards[6:] = [{"author": "Kaz", "description": "hi", "thumbnail": imgs[1]},
                 {"title": "x", "description": "y", "image": imgs[2], "footer": "T4"}]
    sink = Sink()
    asyncio.run(DiscordChannel(sink, None).send_cards(cards))
    assert [len(m["embeds"]) for m in sink.messages] == [5, 3]           # <= 5 embeds per message
    for m in sink.messages:
        names = {f.filename for f in m["files"]}
        urls = [u for e in m["embeds"] for u in (e.image.url, e.thumbnail.url) if u]
        assert all(u.startswith("attachment://") and u[len("attachment://"):] in names for u in urls)
    assert len(sink.messages[0]["files"]) == 1                           # dedup within a message


def test_render_helpers():
    assert classify("[ROLL] Ghost: ...") == "card" and classify("[MINDS] 2 beliefs") == "log"
    assert classify("[NEW] npc: Kaz") == "notice"
    long = "\n".join(f"line {i} " + "x" * 80 for i in range(100))
    assert all(len(c) <= 1900 for c in chunks(long, 1900))
    assert card_messages(["[ROLL] a", "[ROLL] b"])[0].startswith("```\n[ROLL] a")


# ── a whole table on a fake channel ──────────────────────────────────────

class FakeChannel:
    def __init__(self):
        self.sent, self.dms = [], []

    async def send(self, text=None, *, title=None, description=None, color=None, footer=None, image=None):
        self.sent.append({"text": text, "title": title, "description": description, "footer": footer, "image": image})

    async def send_cards(self, cards):
        for c in cards:
            self.sent.append({"text": None, "title": c.get("title"), "description": c.get("description"),
                              "footer": c.get("footer"), "image": c.get("image"), "author": c.get("author"),
                              "thumbnail": c.get("thumbnail"), "color": c.get("color")})

    def typing(self):
        class _T:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                return False
        return _T()

    async def dm(self, user_id, text):
        self.dms.append((user_id, text))

    async def dm_cards(self, user_id, cards):
        self.dms.append((user_id, cards))


def test_table_plays_a_turn(tmp_path):
    script = [([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="ask for a buyer")],
               "tool_use"),
              ([text("**Kaz:** \"Tanaka.\" Ghost, the door opens. What do you do?")], "end_turn")]
    extraction = {"summary": "Razor asked Kaz for a buyer.", "recalled": [], "facts": [], "told": [],
                  "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"}]}

    async def go():
        art = ArtDirector(tmp_path / "art", "x", provider=NullArtProvider(), out=lambda s: None)
        g = Game(tmp_path / "t.db", llm=FakeLLM(script, extraction), art=art, out=lambda s: None)
        setup_demo(g)
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 2, "cap": 5, "grace": 0.05})
        await t.refresh()
        reacts = []

        async def react(e):
            reacts.append(e)
        await t.handle("2", "Alice", "hello?", False, react)
        assert "not playing anyone" in ch.sent[-1]["text"]
        await t.handle("2", "Alice", "!join razor", False, react)
        await t.handle("3", "Bob", "!join ghost", False, react)
        assert "playing **Razor**" in ch.sent[-2]["text"] and t.expected == {"razor", "ghost"}
        await t.handle("2", "Alice", "Kaz, who buys Renraku data?", False, react)
        await t.handle("3", "Bob", "I watch the door.", False, react)
        for _ in range(50):                                   # grace, then the turn resolves
            await asyncio.sleep(0.05)
            if any(m["footer"] for m in ch.sent):
                break
        await t.drain()
        texts = [m["text"] or "" for m in ch.sent]
        card_i = next(i for i, s in enumerate(texts) if s.startswith("```") and "Negotiation" in s)
        narr_i = next(i for i, m in enumerate(ch.sent) if m["description"] and "Tanaka" in m["description"])
        assert card_i < narr_i and ch.sent[narr_i]["footer"].startswith("T4 ·")   # roll card, then the story
        assert reacts.count("📝") == 2

        await t.handle("3", "Bob", "!askdm what's my hacking pool?", False, react)
        assert ch.dms and ch.dms[-1][0] == "3"
        await t.handle("3", "Bob", "!undo", False, react)
        assert "campaign owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!difficulty hard", False, react)
        assert "difficulty hard" in ch.sent[-1]["text"]
        await t.handle("3", "Bob", "!gmmodel", False, react)           # anyone may look...
        await t.handle("3", "Bob", "!gmmodel haiku", False, react)     # ...only the owner may change
        assert "campaign owner" in ch.sent[-1]["text"]
        await t.handle("1", "Owner", "!undo", False, react)
        assert "Undid turn 4" in ch.sent[-1]["text"]
        await t.close()
    run(go())


def test_a_seeded_opening_plays_once(tmp_path):
    extraction = {"summary": "Dutch called Rage with a job.", "recalled": [], "facts": [], "told": [],
                  "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}, "members": []}

    async def go():
        art = ArtDirector(tmp_path / "art", "x", provider=NullArtProvider(), out=lambda s: None)
        llm = FakeLLM([([text("Your commlink buzzes. **Dutch:** \"Got work, chummer.\" What do you say?")], "end_turn")],
                      extraction)
        g = Game(tmp_path / "t.db", llm=llm, art=art, out=lambda s: None)
        setup_demo(g)
        g.conn.execute("DELETE FROM turns")                        # a fresh world: nothing played yet
        g.ledger.set_meta("opening", "Rage's commlink rings: Dutch the fixer has a job.")
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 2, "cap": 5, "grace": 0.05})
        await t.refresh()
        await t.open_scene()
        assert "Stage direction from the table" in llm.dm_requests[0] and "Dutch the fixer" in llm.dm_requests[0]
        assert any("Got work" in (m["description"] or "") for m in ch.sent) and g.ledger.meta("opening") == ""
        await t.open_scene()                                        # a restart doesn't replay it
        assert len(llm.dm_requests) == 1
        await t.close()
    run(go())
