"""Full turns against a scripted LLM: tools, commit, memory, undo - no network."""
from roleplay.engine.dice import ScriptedDice
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool


def demo(make_game, llm, dice=None):
    g = make_game(llm=llm, dice=dice or ScriptedDice([5, 5, 5, 6] + [2] * 40))
    setup_demo(g)
    return g


def test_packet_surfaces_kaz_memory_of_razor_and_secret(make_game):
    llm = FakeLLM(extraction={"summary": "Razor asked Kaz about buyers.", "members": [], "recalled": [],
                              "facts": [], "new_entities": []})
    g = demo(make_game, llm)
    res = g.run_turn([("razor", "I lean on the bar. 'Kaz, who buys hot Renraku data?'")])
    packet = res.packet
    assert "Remembers (earlier" in packet
    assert "jukebox" in packet                     # the bar fight, from three sessions ago
    assert "Lone Star" in packet                   # Kaz's secret DM note
    assert "Tanaka" in packet                      # mentioned -> pulled in with his fact
    assert "Renraku datachip" in packet            # Ghost's gear
    assert "recovery" in packet or "send a team" in packet   # the chip's secret DM note rides along


def test_turn_runs_tools_commits_slice_and_links(make_game):
    script = [
        ([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="ask Kaz for a buyer")],
         "tool_use"),
        ([tool("annotate", target_ids=["kaz"], text="Kaz will mention Razor to Lone Star if pressed.")], "tool_use"),
        ([text("**Kaz:** \"Tanaka. Chinatown. You didn't hear it from me.\" What do you do, Razor?")], "end_turn"),
    ]

    def extraction(user):
        return {"summary": "Razor asked Kaz for a buyer; Kaz pointed him to Tanaka, remembering the bar fight.",
                "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"},
                            {"id": "tanaka", "role": "mentioned"}, {"id": "ghost", "role": "present"}],
                "recalled": ["T2"], "facts": [{"text": "Kaz recommended Tanaka to Razor.", "about": ["kaz", "tanaka"]}],
                "new_entities": [{"name": "Granny Lu", "kind": "npc", "description": "noodle stall owner"}]}

    llm = FakeLLM(script, extraction)
    g = demo(make_game, llm)
    res = g.run_turn([("razor", "Kaz, who buys hot Renraku data?")])
    assert "Tanaka" in res.narration
    assert res.cards and "Negotiation" in res.cards[0]
    sid = res.slice_id
    roles = dict(g.sub.members_of(sid))
    assert roles["razor"] == "actor" and roles["kaz"] == "target" and roles["tanaka"] == "mentioned"
    assert roles["ghost"] == "present" and roles["the-lucky-shot"] == "location"
    assert roles["T2"] == "recalled"               # the attention-head link to the bar fight
    assert g.ledger.find("Granny Lu") is not None
    assert any("Lone Star if pressed" in n["text"] for n in g.sub.notes_for("kaz"))
    # the remembered bar fight got hotter than the other old slice in that scene
    assert g.sub.energy_of("T2") > g.sub.energy_of("T1")


def test_party_moving_cuts_the_scene_and_returning_resumes_it(make_game):
    stay = {"summary": "x", "members": [], "recalled": [], "facts": [], "told": [], "new_entities": [],
            "moved_to": {"location": "", "description": "", "who": []}}
    go = dict(stay, moved_to={"location": "Tanaka's Shop", "description": "a cluttered Chinatown back room",
                              "who": ["razor", "ghost"]})
    back = dict(stay, moved_to={"location": "The Lucky Shot", "description": "", "who": ["razor", "ghost"]})
    split = dict(stay, moved_to={"location": "The Alley", "description": "wet", "who": ["razor"]})
    script = iter([split, go, back])
    llm = FakeLLM(extraction=lambda user: next(script) if "KNOWN ENTITIES" in user else {"beliefs": []})
    g = demo(make_game, llm)
    bar_scene = g.current_scene_id()
    g.run_turn([("razor", "I step into the alley alone.")])
    assert g.current_scene_id() == bar_scene                 # only one PC moved: no cut
    res = g.run_turn([("razor", "We head to Tanaka's.")])
    assert res.info["auto_cut"] and g.current_scene_id() != bar_scene
    assert set(g.ledger.roster(g.current_scene_id())) >= {"razor", "ghost"}
    assert "kaz" in g.ledger.roster(bar_scene)               # Kaz stayed behind in the parked scene
    assert g.sub.node(f"S{bar_scene}")["text"].startswith("Scene: Selling the chip.")   # closed scene summarized
    g.run_turn([("razor", "Back to the Lucky Shot.")])
    assert g.current_scene_id() == bar_scene                 # returning resumes the parked scene


def test_undo_restores_everything(make_game):
    llm = FakeLLM([([tool("transfer_nuyen", from_id="world", to_id="razor", amount=1000, reason="tip")], "tool_use"),
                   ([text("Kaz slides you a credstick.")], "end_turn")],
                  {"summary": "x", "members": [], "recalled": [], "facts": [], "new_entities": []})
    g = demo(make_game, llm)
    before = g.ledger.stat("razor", "nuyen")
    turns_before = g.turn_no()
    g.run_turn([("razor", "Any work?")])
    assert g.ledger.stat("razor", "nuyen") == before + 1000
    g.undo()
    assert g.ledger.stat("razor", "nuyen") == before
    assert g.turn_no() == turns_before


def test_rejected_tool_reports_error_and_turn_continues(make_game):
    llm = FakeLLM([([tool("attack", attacker_id="razor", target_id="kaz", weapon_id="rocket-launcher",
                          reason="cheese")], "tool_use"),
                   ([text("Razor reaches for a rocket launcher he doesn't have.")], "end_turn")],
                  {"summary": "x", "members": [], "recalled": [], "facts": [], "new_entities": []})
    g = demo(make_game, llm)
    res = g.run_turn([("razor", "I pull out my rocket launcher")])
    assert not res.cards
    assert g.ledger.stat("kaz", "physical_damage") == 0


def test_failed_turn_rolls_back(make_game):
    class Boom(FakeLLM):
        def dm_step(self, *a, **k):
            raise RuntimeError("network down")

    g = demo(make_game, Boom())
    n = g.turn_no()
    try:
        g.run_turn([("razor", "hi")])
    except RuntimeError:
        pass
    assert g.turn_no() == n


def test_a_dm_note_on_someone_the_turn_introduces_lands(make_game):
    """Live T8: the GM's `note liesl-kovacs: ...` was read before the memory pass put Liesl Kovacs on file, and lost.
    A line naming someone not on file yet waits for commit, then lands - whole, never on just the half it knew."""
    said = ("A woman in a Ironwood jacket waves Razor over.\n<dm>\nnote liesl-kovacs: owes Ironwood twenty grand.\n"
            "note kaz, liesl-kovacs: Kaz knows her from the old days.\nnote nobody-at-all: lost\n</dm>")
    llm = FakeLLM([([text(said)], "end_turn")],
                  {"summary": "Liesl Kovacs waved Razor over.", "members": [{"id": "razor", "role": "actor"}],
                   "recalled": [], "facts": [], "new_entities": [{"name": "Liesl Kovacs", "kind": "npc",
                                                                   "description": "a Ironwood fixer"}]})
    g = demo(make_game, llm)
    logged = []
    g.out = logged.append
    g.run_turn([("razor", "Who's she?")])
    assert {n["text"] for n in g.sub.notes_for("liesl-kovacs", 10)} >= {"owes Ironwood twenty grand.",
                                                                        "Kaz knows her from the old days."}
    assert any(n["text"] == "Kaz knows her from the old days." for n in g.sub.notes_for("kaz", 10))
    skips = [x for x in logged if "dm block" in x]
    assert len(skips) == 1 and "nobody-at-all" in skips[0]                   # (said once, after the retry)


def test_a_held_dm_line_still_reaches_the_memory_pass(make_game):
    """Review (2026-10-24): a fact naming anyone not on file waits for the memory pass - and the pass no longer saw
    it, in ENGINE EVENTS or FACTS ALREADY KNOWN, so it was free to extract the same fact again (store.add_fact keeps
    both copies). Before the wait, `fact kaz, the bartender: ...` was in both. It's in ENGINE EVENTS now, marked the
    GM's own; it lands on Kaz once, after the pass, and gets the retrieval touch commit gives the GM's facts."""
    said = ("Kaz wipes the bar down.\n<dm>\nfact kaz, the bartender: Kaz owes Tanaka 14,000 nuyen.\n"
            "fact kaz: Kaz drinks rye.\n</dm>")
    prompts = []

    def extraction(user):
        prompts.append(user)
        return {"summary": "Kaz wiped the bar.", "members": [{"id": "razor", "role": "actor"}], "recalled": [],
                "facts": [], "new_entities": []}
    g = demo(make_game, FakeLLM([([text(said)], "end_turn")], extraction))
    g.run_turn([("razor", "I watch Kaz.")])
    events = next(p for p in prompts if "ENGINE EVENTS" in p).split("ENGINE EVENTS", 1)[1].split("NARRATION:")[0]
    assert "Kaz owes Tanaka 14,000 nuyen." in events and "not one to extract again" in events
    assert "Kaz drinks rye." in events                                       # (all on file: it landed before)
    owes = [f for f in g.sub.facts_for("kaz", 20) if f["text"] == "Kaz owes Tanaka 14,000 nuyen."]
    assert len(owes) == 1 and g.sub.node(owes[0]["id"])["created_turn"] == g.turn_no()
    assert g.conn.execute("SELECT touch_count FROM energy WHERE node_id=?", (owes[0]["id"],)).fetchone()[0] >= 1
