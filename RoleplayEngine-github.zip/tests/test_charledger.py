"""The character ledger: runners checked out to one world at a time, progress synced home, history as backstory."""
import asyncio

import pytest

from roleplay import chargen as C, charledger
from roleplay.discord_bot.session import CampaignTable
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import machines, sr_lite
from roleplay.setup import setup_blank, setup_demo

from .conftest import FakeLLM
from .test_discord import FakeChannel


def _world(make_game, demo=False):
    g = make_game(FakeLLM())
    (setup_demo if demo else setup_blank)(g, *(() if demo else ("Downtown Seattle", "rain")))
    return g


def _runner(g, name="Glitch", role="decker", meta="elf"):
    d = C.new_draft(role, meta)
    d.update(name=name, pronouns="they/them", look="Silver-haired elf in a patched jacket.")
    return C.build(g, d, name.lower(), 1)


def test_a_runner_travels_between_worlds(make_game):
    a, b = _world(make_game), _world(make_game)
    eid = _runner(a)
    key = charledger.register(a, eid, "7", "Jo")
    assert charledger.get(b, "glitch")["campaign"] == a.path.stem          # the same shelf, seen from any world
    with pytest.raises(LedgerError, match="checked out to"):
        charledger.check_out(b, "Glitch", "7", 1)                          # one world at a time
    a.ledger.set_stat(eid, "karma", 9)                                     # progress in world A...
    a.ledger.set_stat(eid, "physical_damage", 4)
    chip = a.ledger.create_entity("item", "Renraku datachip", "hot", props={"file": True}, turn=1)
    a.ledger.give(eid, chip)
    tid = a.ledger.begin_turn(a.current_scene_id(), [])
    a.sub.write_slice(tid, a.current_scene_id(), "Glitch cracked the Renraku chip for Kaz.", [(eid, "actor")], [])
    charledger.check_in(a, eid)                                            # ...goes home, with a backstory
    assert a.ledger.get(eid)["status"] == "departed" and eid not in a.ledger.roster(a.current_scene_id())
    r = charledger.get(b, "Glitch")
    assert r["campaign"] is None and r["data"]["stats"]["karma"] == 9
    assert r["backstory"] == [{"world": a.path.stem, "text": "scene summary"}]      # (FakeLLM's text)
    assert not any("datachip" in i["name"] for i in r["data"]["items"])               # story items stay behind
    nid, back = charledger.check_out(b, "Glitch", "7", 1)
    L = b.ledger
    assert not back and L.stat(nid, "karma") == 9 and L.stat(nid, "physical_damage") == 0   # healed, still earned
    assert L.get(nid)["props"]["pronouns"] == "they/them" and L.get(nid)["props"]["ledger"] == key
    assert any(i["name"] == "Glitch's Erika MCD-1" or "deck" in i["props"] for i in L.holdings(nid))
    assert [m["props"]["model"] for m in machines.owned_by(L, nid)] == ["fly-spy"]
    # (a bought drone is a bare frame since 2026-10-24: its autosofts travel with it, not re-bundled by model)
    assert sr_lite.autosofts(L, machines.owned_by(L, nid)[0]) == {"clearsight": 3, "stealth": 3}
    assert any("Glitch's past" in f["text"] for f in b.sub.facts_for(nid, 5))
    charledger.check_in(b, nid, write_backstory=False)
    again, back = charledger.check_out(a, "Glitch", "7", 2)                # back to the first world: same person
    assert back and again == eid and a.ledger.get(eid)["status"] == "active"
    assert len([i for i in a.ledger.holdings(eid) if "deck" in i["props"]]) == 1    # kit replaced, not doubled


def test_names_and_ownership(make_game):
    a, b, c = _world(make_game), _world(make_game, demo=True), _world(make_game)
    charledger.register(a, _runner(a, "Kaz"), "7", "Jo")
    with pytest.raises(LedgerError, match="already a Kaz"):
        charledger.register(c, _runner(c, "KAZ"), "8", "Al")              # unique across every world, any case
    with pytest.raises(LedgerError, match="Jo's"):
        charledger.check_out(b, "Kaz", "8", 1)                             # not yours
    charledger.set_shared(a, "Kaz", "7", True)
    eid = charledger.get(a, "Kaz")["entity_id"]
    charledger.check_in(a, eid, write_backstory=False)
    with pytest.raises(LedgerError, match="already has someone called Kaz"):
        charledger.check_out(b, "Kaz", "8", 1)                             # the demo's bartender owns that name


def test_the_ledger_at_the_table(make_game):
    g = _world(make_game)

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t.refresh()

        async def react(e):
            pass
        say = lambda uid, text: t.handle(uid, f"user{uid}", text, False, react)   # noqa: E731
        await say("7", "!newchar Finch decker")                            # player-made: on the ledger at once
        await say("7", "!cl")
        assert ch.sent[-1]["title"] == "📒 The Character Ledger" and "**Finch** - decker · user7's" in ch.sent[-1]["description"]
        await say("8", "!newchar finch mage")
        assert "already a finch in the character ledger" in ch.sent[-1]["text"]
        await say("7", "!characterledger return")
        assert "heads back to the character ledger" in ch.sent[-1]["text"] and "7" not in t.handles
        await say("7", "!checkout Finch")
        assert "checks **Finch** out of the character ledger - back in this world." in ch.sent[-1]["text"]
        assert t.handles["7"] == "finch" and ch.dms[-1][1][0]["title"] == "🎲 Finch"
        await say("7", "!characterledger Finch")
        assert ch.sent[-1]["title"] == "📒 Finch" and "checked out to" in ch.sent[-1]["description"]
        await t.close()
    asyncio.run(go())


def test_a_chronicle_only_knows_what_its_character_knew(make_game):
    from roleplay import chronicle
    g = _world(make_game, demo=True)
    S, sid = g.sub, g.current_scene_id()
    tid = g.ledger.begin_turn(sid, [])
    sl = S.write_slice(tid, sid, "Razor palmed the spare keycard.", [("razor", "actor")], [])
    S.set_visibility(sl, "private")
    S.write_offscreen(tid, "Kaz called his old precinct about the chip.", [("kaz", "actor")])
    kaz, ghost, razor = (chronicle.record(g, x)["lines"] for x in ("kaz", "ghost", "razor"))
    assert any("broke Joey Two-Knives' arm" in x for x in kaz)                 # Kaz was at the bar fight
    assert not any("Joey" in x for x in ghost)                                 # Ghost wasn't
    assert any("on my own, unseen" in x and "old precinct" in x for x in kaz) and not any("precinct" in x for x in razor)
    assert any("a private moment" in x for x in razor) and not any("keycard" in x for x in kaz)


def test_a_runner_is_put_away_never_deleted(make_game):
    a, b = _world(make_game), _world(make_game)
    eid = _runner(a)
    charledger.register(a, eid, "7", "Jo")
    with pytest.raises(LedgerError, match="playing in"):                   # nobody vanishes mid-story
        charledger.set_hidden(b, "Glitch", "7", True)
    with pytest.raises(LedgerError, match="Jo's to release"):
        charledger.release(b, "Glitch", "8")
    charledger.release(b, "Glitch", "8", admin=True)                       # the campaign owner can clean up
    with pytest.raises(LedgerError, match="Jo's to hide"):
        charledger.set_hidden(b, "Glitch", "8", True)
    r = charledger.set_hidden(b, "Glitch", "7", True)
    assert r["hidden"] and "put away (hidden)" in charledger.summary(r)
    assert [x["name"] for x in charledger.runners(b)] == [] and [x["name"] for x in charledger.runners(b, True)] == ["Glitch"]
    assert charledger.taken(b, "glitch")                                    # the name stays taken
    with pytest.raises(LedgerError, match="unhide Glitch"):
        charledger.check_out(b, "Glitch", "7", 1)
    with pytest.raises(LedgerError, match="already hidden"):
        charledger.set_hidden(b, "Glitch", "7", True)
    r = charledger.set_hidden(b, "Glitch", "8", False, admin=True)          # and bring them back
    assert not r["hidden"] and r["data"]["name"] == "Glitch" and charledger.runners(b)[0]["name"] == "Glitch"
    charledger.check_out(b, "Glitch", "7", 1)


def test_hide_at_the_table(make_game):
    g = _world(make_game)
    eid = _runner(g)
    charledger.register(g, eid, "7", "Jo")
    charledger.release(g, "Glitch", "7")

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")

        async def react(e):
            pass
        await t.handle("7", "Jo", "!characterledger hide Glitch", False, react)
        assert "is put away - off the list, nothing lost" in ch.sent[-1]["text"]
        await t.handle("7", "Jo", "!cl", False, react)
        assert "Glitch" not in ch.sent[-1]["description"] and "`hidden` the 1 put away" in ch.sent[-1]["description"]
        await t.handle("7", "Jo", "!cl hidden", False, react)
        assert ch.sent[-1]["title"] == "📒 Put away" and "Glitch" in ch.sent[-1]["description"]
        await t.handle("1", "Owner", "!cl unhide Glitch", True, react)
        assert "is back on the list" in ch.sent[-1]["text"]
        await t.close()
    asyncio.run(go())


def _order(g, eid, onto):
    """A remote dealer's courier order: an armored jacket and a Steel Lynx for the runner, two frags onto their drone."""
    from roleplay import shops
    yard, _ = g.introduce("location", "BarrensBolt salvage yard", "a drone lot", turn=1)
    shops.stock(g, yard, "BarrensBolt", "online drone dealer", ["armored-jacket", "steel-lynx", "frag-grenade"], 1.0, 1,
                remote=True)
    g.ledger.set_stat(eid, "nuyen", 40000)
    return [shops.buy(g, eid, key, n, 2, shop_id=yard, onto=to)["entities"][0]
            for key, n, to in (("armored", 1, None), ("steel", 1, None), ("frag", 2, onto))]


def test_gear_on_its_way_waits_for_a_runner_who_comes_back(make_game):
    """Review E2: Brick bought a jacket and a Steel Lynx for delivery (26,000¥), was returned to the ledger and
    checked back out into the same world - and the way back in took the jacket and departed the Lynx (neither was in
    the record: what's still with a courier stays behind), then announced both as they 'arrived' into nobody's hands.
    Now what's on its way stays theirs, kit bound for their drone goes onto the drone that comes back, and a delivery
    for a runner who's away waits for them."""
    from roleplay import shops
    from roleplay.engine import clock
    a = _world(make_game)
    eid = _runner(a)
    charledger.register(a, eid, "7", "Jo")
    spy = machines.owned_by(a.ledger, eid)[0]
    jacket, lynx, frags = _order(a, eid, spy["id"])
    charledger.check_in(a, eid, write_backstory=False)
    r = charledger.get(a, "Glitch")["data"]
    assert [m["model"] for m in r["drones"]] == ["fly-spy"]                     # (the Lynx stays behind)
    assert not any(i["props"].get("in_transit") for m in r["drones"] for i in m["items"])
    a.set_clock(a.clock() + 60 * clock.DAY)
    assert shops.arrivals(a, 3) == []                                           # nobody here to bring it to: it waits
    again, back = charledger.check_out(a, "Glitch", "7", 4)
    L = a.ledger
    assert back and again == eid and L.holds(eid, jacket)
    assert L.require(lynx)["status"] == "active" and lynx in [m["id"] for m in machines.owned_by(L, eid)]
    new_spy = next(m for m in machines.owned_by(L, eid) if m["props"]["model"] == "fly-spy")
    assert new_spy["id"] != spy["id"] and L.holds(new_spy["id"], frags)          # (onto the Fly-Spy that came back)
    cards = shops.arrivals(a, 5)
    assert sorted(cards) == ["[SHOP] Glitch's Armored jacket arrives from BarrensBolt.",
                             "[SHOP] Glitch's Steel Lynx arrives from BarrensBolt.",
                             "[SHOP] Glitch's frag grenade arrives from BarrensBolt."]
    assert not any(sr_lite.arriving(L.require(x)) for x in (jacket, lynx, frags))


def test_kit_on_its_way_to_a_drone_stays_behind_too(make_game):
    """Review E2: frags bought onto a Fly-Spy from a remote dealer were exported with the drone still 'on their way'
    and re-created in the next world, where nothing would ever deliver them - stuck there for good. The drone's kit
    leaves what's with a courier behind, like the runner's own."""
    a, b = _world(make_game), _world(make_game)
    eid = _runner(a)
    charledger.register(a, eid, "7", "Jo")
    spy = machines.owned_by(a.ledger, eid)[0]
    _order(a, eid, spy["id"])
    charledger.check_in(a, eid, write_backstory=False)
    nid, _ = charledger.check_out(b, "Glitch", "7", 1)
    L = b.ledger
    drones = machines.owned_by(L, nid)
    assert [m["props"]["model"] for m in drones] == ["fly-spy"]
    assert not any(sr_lite.arriving(i) for m in drones for i in L.holdings(m["id"]))
    assert not any(sr_lite.arriving(i) for i in L.holdings(nid))
    assert not any("frag" in i["name"] for i in L.holdings(drones[0]["id"]))
