"""Graph mechanics: diodes, hearsay, NPC minds, merges."""
from roleplay.config import Knobs
from roleplay.dm.minds import reflect_scene
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet
from roleplay.substrate.physics import EnergyGraph, touch_all

from .conftest import FakeLLM


def test_diode_feeds_the_replacement():
    # old fact and new fact both hang off kaz; old is superseded by new
    links = [(1, "kaz", "old", 1.0), (2, "kaz", "new", 1.0)]
    g = EnergyGraph({"kaz": 1.0, "old": 1.0, "new": 1.0}, links, arrows={"old": "new"})
    touch_all(g, Knobs(), ["old"])
    assert g.diode_hops == 1
    assert g.deposited["new"] > g.deposited["old"]       # touching the past reinforces what replaced it


def test_supersede_gates(make_game):
    g = make_game()
    s = g.sub
    for f in ("F1", "F2", "F3", "F4"):
        s.create_node(f, "fact", f, 1)
    assert s.supersede("F1", "F2", 0.9, "t", 1) == "installed"
    assert s.superseded_by("F1") == "F2"
    assert s.supersede("F2", "F1", 0.95, "t", 1) == "contested"       # cycle -> contest note, not an arrow
    assert any("Contested" in n["text"] for n in s.notes_for("F1"))
    assert s.supersede("F3", "F4", 0.6, "t", 1) == "both_live"
    assert s.supersede("F3", "F4", 0.4, "t", 1) == "too_weak"
    assert s.superseded_by("F3") is None


def test_replaced_fact_leaves_the_packet(make_game):
    g = make_game()
    setup_demo(g)
    old = next(f for f in g.sub.facts_for("kaz", 10) if "owes Razor a favor" in f["text"])
    new = g.sub.add_fact("Kaz and Razor are square now - the favor was paid with the Tanaka intro.",
                         ["kaz", "razor"], 9, replaces=old["id"], confidence=0.9)
    texts = [f["text"] for f in g.sub.facts_for("kaz", 10)]
    assert any("square now" in t for t in texts) and not any("owes Razor a favor" in t for t in texts)
    assert g.sub.superseded_by(old["id"]) == new


def test_hearsay_shows_up_as_heard(make_game):
    g = make_game()
    setup_demo(g)
    # Kaz wasn't on the bridge (T3); Razor tells him about it
    assert g.sub.add_knows("kaz", "T3", "told", "razor", 4)
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hi")], 5)
    assert "heard it from Razor" in packet and "520 bridge" in packet
    assert not g.sub.add_knows("kaz", "T3", "told", "razor", 5)     # knowing twice is still knowing once


def test_reflection_creates_belief_chain_and_attitude(make_game):
    beliefs = iter([
        {"beliefs": [{"about": "razor", "attitude": 2, "belief": "Kaz thinks Razor is trouble but his kind of trouble.",
                      "changed": True}]},
        {"beliefs": [{"about": "razor", "attitude": -1, "belief": "Kaz thinks Razor brought Renraku to his door.",
                      "changed": True}]},
    ])
    asked = []

    def think(user):
        if not user.startswith("CHARACTER: Kaz"):
            return {"beliefs": []}
        asked.append(user)
        return next(beliefs)
    g = make_game(llm=FakeLLM(extraction=think))
    setup_demo(g)
    s1 = 1                                                   # the bar-fight scene: Kaz witnessed 2 turns
    b1 = reflect_scene(g, s1, 5)
    assert b1 and g.ledger.stat("kaz", "attitude:razor") == 2
    assert g.ledger.get("kaz")["tier"] == 2                  # earned a mind
    assert reflect_scene(g, s1, 6) == [] and len(asked) == 1  # nothing new about Razor: no rereading, no call
    sid = g.sub.write_slice(8, s1, "Razor brought Renraku's men to the Lucky Shot's door.",
                            [("razor", "actor"), ("kaz", "target")], [])
    b2 = reflect_scene(g, s1, 9)
    assert f"[{sid}]" in asked[-1] and "(already counted) [" in asked[-1]   # the old memories are marked as counted
    assert g.ledger.stat("kaz", "attitude:razor") == 0       # +2 to -1 is too far for one reflection: two steps
    assert g.sub.superseded_by(b1[0]) == b2[0]               # the old view is kept, superseded
    assert g.sub.current_belief("kaz", "razor")["id"] == b2[0]
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hi")], 10)
    assert "Feels about Razor (attitude +0" in packet and "Renraku to his door" in packet


def test_grudges_cool_with_time_apart(make_game):
    from roleplay.dm.minds import COOL_EVERY, cool
    g = make_game(llm=FakeLLM(extraction=lambda user: {"beliefs": [
        {"about": "razor", "attitude": -3, "belief": "Kaz thinks Razor sold him out.", "changed": True}]}
        if user.startswith("CHARACTER: Kaz") else {"beliefs": []}))
    setup_demo(g)
    reflect_scene(g, 1, 5)
    assert g.ledger.stat("kaz", "attitude:razor") == -3
    assert cool(g) == []                                     # no time has passed
    g.set_clock(g.clock() + COOL_EVERY + 1)
    assert cool(g) and g.ledger.stat("kaz", "attitude:razor") == -2
    g.set_clock(g.clock() + 5 * COOL_EVERY)
    cool(g)
    assert g.ledger.stat("kaz", "attitude:razor") == -1      # never past -1: he remembers
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "hi")], 10)
    assert "attitude -1; time has cooled it from -3" in packet


def test_memory_lines_use_story_time(make_game):
    g = make_game()
    setup_demo(g)                                      # bar fight = session 1, courier = session 3, now = 4
    packet, _ = build_packet(g, g.current_scene_id(), [("razor", "Joey?")], g.turn_no() + 1)
    assert "3 sessions ago" in packet and "last session" in packet


def test_rumors_travel_from_the_npcs_who_saw_it(make_game):
    from roleplay.substrate import rumors
    g = make_game()
    setup_demo(g)
    S, L = g.sub, g.ledger
    # the 520 bridge job (S2, T3) had only the two PCs in it: nobody else saw it, so nobody tells it
    rumors.spread_rumors(g, 2, 10)
    assert not g.conn.execute("SELECT 1 FROM knows WHERE node_id='T3'").fetchone()
    # Kaz watches Razor shoot the courier: Kaz's people hear it from Kaz - Joey wasn't there
    sid = S.write_slice(20, 2, "Razor shot the courier in the back while Kaz watched from the van.",
                        [("razor", "actor"), ("kaz", "present")], [])
    S.touch([sid], 20, 5.0)
    assert rumors.spread_rumors(g, 2, 20) >= 1
    heard = {r["node_id"]: r for r in g.conn.execute("SELECT * FROM knows WHERE holder='joey-two-knives'")}
    assert heard[sid]["how"] == "rumor" and heard[sid]["source"] == "kaz"
    pcs = {e["id"] for e in L.entities(kind="pc")}
    assert not [r for r in g.conn.execute("SELECT source FROM knows WHERE how='rumor'") if r["source"] in pcs]
    assert not g.conn.execute("SELECT 1 FROM knows WHERE holder IN ('razor', 'kaz')").fetchone()   # witnesses
    # the dead hear nothing
    L.set_stat("joey-two-knives", "physical_damage", 99)
    sid2 = S.write_slice(21, 2, "Razor dumped the courier's car in the Sound while Kaz kept watch.",
                         [("razor", "actor"), ("kaz", "present")], [])
    S.touch([sid2], 21, 6.0)
    rumors.spread_rumors(g, 2, 21)
    assert not g.conn.execute("SELECT 1 FROM knows WHERE holder='joey-two-knives' AND node_id=?", (sid2,)).fetchone()


def test_tidy_takes_back_what_the_old_spreading_told(make_game):
    from roleplay.substrate import rumors
    g = make_game()
    setup_demo(g)
    S, L = g.sub, g.ledger
    S.add_knows("joey-two-knives", "T3", "rumor", "razor", 9)            # the old way: "via" a PC
    S.add_knows("kaz", "T3", "rumor", "joey-two-knives", 9)              # ...to someone who is now dead
    S.add_knows("joey-two-knives", "T1", "told", "razor", 9)             # told face to face: that's real, it stays
    L.set_stat("kaz", "physical_damage", 99)
    L.set_meta(rumors.TIDY, "")
    assert rumors.tidy(g) == 2
    rows = {(r["holder"], r["node_id"], r["how"]) for r in g.conn.execute("SELECT * FROM knows")}
    assert rows == {("joey-two-knives", "T1", "told")}
    assert rumors.tidy(g) == 0                                           # once per world


def test_dm_block_is_parsed_applied_and_stripped(make_game):
    from roleplay.dm import dmblock
    from roleplay.dm.tools import TurnContext
    g = make_game()
    setup_demo(g)
    narration = ("**Kaz:** \"Square?\" He nods.\n\n<dm>\nnote kaz, sgt-danjuma: Kaz will talk if the bar burns.\n"
                 "fact kaz, razor (replaces F2): Kaz and Razor are square now.\nfact nobody: ignored line\n</dm>")
    clean, entries = dmblock.split(narration)
    assert "<dm>" not in clean and clean.endswith("He nods.")
    assert [e["kind"] for e in entries] == ["note", "fact", "fact"]
    ctx = TurnContext(g, 9, g.current_scene_id())
    made = dmblock.apply(ctx, entries)
    assert len(made) == 2                                      # the unknown-id line is skipped
    assert any("talk if the bar burns" in n["text"] for n in g.sub.notes_for("kaz"))
    assert g.sub.superseded_by("F2") is not None               # the old favor fact is superseded


def test_merge_moves_memory_and_leaves_a_diode(make_game):
    g = make_game()
    setup_demo(g)
    dup, _ = g.introduce("npc", "Kaz the Bartender", "duplicate of kaz", template="civilian", present=True, turn=4)
    g.sub.add_note([dup], "note on the duplicate", 4)
    g.sub.write_slice(99, g.current_scene_id(), "the duplicate did something", [(dup, "actor")], [])
    msg = g.merge_entities("kaz", dup, 5)
    assert "Merged" in msg
    assert ("kaz", "actor") in g.sub.members_of("T99")
    assert any(n["text"] == "note on the duplicate" for n in g.sub.notes_for("kaz"))
    assert g.ledger.get(dup)["status"] == "merged"
    assert "Kaz the Bartender" in g.ledger.get("kaz")["aliases"]
    assert g.sub.superseded_by(dup) == "kaz"
    assert dup not in g.ledger.roster(g.current_scene_id())


def test_independent_model_calls_run_side_by_side():
    """The minds pass made one Haiku call per NPC, one after another - ten NPCs at the chop yard took 60-90 s.
    fan_out runs them together, keeps their order, and hands back a failure in its place."""
    import threading
    import time
    from roleplay.dm.llm import fan_out
    live, peak, lock = [0], [0], threading.Lock()

    def call(n):
        with lock:
            live[0] += 1
            peak[0] = max(peak[0], live[0])
        time.sleep(0.3)
        with lock:
            live[0] -= 1
        if n == 3:
            raise ValueError("refused")
        return n * 10
    t0 = time.time()
    out = fan_out(call, [1, 2, 3, 4, 5, 6])
    assert out[:2] == [10, 20] and isinstance(out[2], ValueError) and out[3:] == [40, 50, 60]
    assert peak[0] == 6 and time.time() - t0 < 1.0                   # six at once, not 1.8 s in a row


def test_usage_adds_up_from_many_threads():
    import threading
    from types import SimpleNamespace
    from roleplay.dm.llm import Usage
    u = Usage()
    one = SimpleNamespace(input_tokens=1000, output_tokens=100, cache_read_input_tokens=0,
                          cache_creation_input_tokens=0)
    ts = [threading.Thread(target=lambda: [u.add("claude-haiku-5-5", one, "minds") for _ in range(500)])
          for _ in range(8)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert u.calls == 4000 and u.by_model["claude-haiku-5-5"]["calls"] == 4000


def test_teamwork_adds_the_helpers_hits_to_the_leaders_pool(make_game):
    """Helpers roll their own pools; each hit is a die for the leader, up to the leader's rating in the skill."""
    from roleplay.engine.dice import ScriptedDice
    from roleplay.engine.rules import sr_lite
    g = make_game(dice=ScriptedDice([5, 6, 6, 1] + [5] * 40))
    setup_demo(g)
    L = g.ledger
    L.set_stat("razor", "negotiation", 2)
    L.set_stat("ghost", "negotiation", 2)
    L.set_stat("joey-two-knives", "stun_damage", 99)                       # out cold: can't help
    res = sr_lite.request_test(L, g.dice, 1, "razor", "negotiation", threshold=2, reason="talk the bouncer down",
                               helpers=[{"id": "ghost"}, {"id": "joey-two-knives"}, {"id": "razor"}])
    card = res["card"]
    team = next(x for x in card.splitlines() if x.startswith("  Team"))
    assert "Ghost Negotiation" in team and "Joey Two-Knives can't help" in team and team.count("Razor") == 0
    assert "+2 dice to Razor (capped at their Negotiation 2)" in card                 # 3 hits, but Razor has 2
    pool = next(x for x in card.splitlines() if x.startswith("  Pool"))
    assert "Teamwork (Ghost) 2" in pool
    alone = sr_lite.request_test(L, g.dice, 1, "razor", "negotiation", threshold=2, reason="alone")
    assert "Team" not in alone["card"] and "Teamwork" not in alone["card"]
