"""Doubts (dm/doubts.py, DESIGN.md §12k, 2026-10-26): where the record doesn't add up, written down until it's settled -
never let go into the ether. (Live: since T52 Liesl Kovacs's picture has called her daughter "Juno", and Juno is Bo's
mother, an ork in her twenties. Nothing ever asked.)"""
import asyncio
import sqlite3
from pathlib import Path

import pytest

from roleplay import flags
from roleplay.browser import server as browser_server
from roleplay.browser.server import Api
from roleplay.dashboard import data
from roleplay.discord_bot.session import CampaignTable, help_cards
from roleplay.dm import aside, canon, doubts, tensions
from roleplay.dm.prompts import COMMIT_SYSTEM, DM_SYSTEM, commit_schema
from roleplay.dm.tools import TOOLS, TurnContext, dispatch, run_tool
from roleplay.dm.turn import _tool_label
from roleplay.engine.ledger import RulesRefusal
from roleplay.setup import setup_demo
from roleplay.substrate.packet import build_packet

from .conftest import FakeLLM, text, tool
from .test_discord import FakeChannel
from .test_research import LoopLLM, _engine_notes

COMMIT = {"summary": "Razor pressed Kaz about the favor.", "members": [{"id": "razor", "role": "actor"},
                                                                     {"id": "kaz", "role": "target"}],
          "recalled": [], "facts": [], "told": [], "new_entities": [],
          "moved_to": {"location": "", "description": "", "who": []}}
SLIP = "F2 has Kaz owing Razor a favor; tonight's narration has Razor owing Kaz"


def _demo(make_game, script=None, extraction=COMMIT, llm=None):
    g = make_game(llm or FakeLLM(script or [], extraction))
    setup_demo(g)
    return g


def _ctx(g):
    return TurnContext(g, g.turn_no() + 1, g.current_scene_id())


def _deposits(g, origin, without=None):
    """What a touch on origin would add to each node's energy - tried inside a savepoint and taken back, optionally
    with one node's links gone."""
    g.conn.execute("SAVEPOINT probe")
    try:
        if without:
            g.conn.execute("DELETE FROM links WHERE a=? OR b=?", (without, without))
        before = dict(g.conn.execute("SELECT node_id, energy FROM energy").fetchall())
        g.sub.touch([origin], g.turn_no(), 1.0)
        return {k: v - before[k] for k, v in g.conn.execute("SELECT node_id, energy FROM energy") if k != origin}
    finally:
        g.conn.execute("ROLLBACK TO probe")
        g.conn.execute("RELEASE probe")


# ── raising one ─────────────────────────────────────────────────────────

def test_a_dm_line_raises_a_doubt_on_both_sides(make_game):
    g = _demo(make_game, [([text("Kaz polishes a glass. She doesn't look up.\n<dm>\ndoubt F2, T2, kaz: F2 and T2 have "
                                 "Kaz as a man - tonight I called Kaz 'she'\n</dm>")], "end_turn")])
    res = g.run_turn([("razor", "Kaz?")])
    assert "<dm>" not in res.narration and "doubt" not in res.narration
    d = doubts.get(g, "X1")
    assert d["status"] == "open" and d["raised_by"] == "gm" and d["raised_turn"] == res.turn_id and d["times"] == 1
    assert set(doubts.about(g.conn, "X1")) == {"F2", "T2", "kaz"}
    node = g.sub.node("X1")
    assert node["kind"] == "doubt" and node["visibility"] == "gm"
    # bookkeeping, not memory: no energy of its own, and links that carry none - a touch on F2 gives F2's other
    # neighbours exactly what it would with no doubt on it. (Review 2026-10-26: this checked that X1 got no energy row,
    # which held whatever its links' strength - a touch never inserts a row.)
    assert not g.conn.execute("SELECT 1 FROM energy WHERE node_id='X1'").fetchone()
    assert {r["strength"] for r in g.sub.links_of("X1")} == {0.0}
    assert _deposits(g, "F2") == pytest.approx(_deposits(g, "F2", without="X1"))
    assert _deposits(g, "F2")["kaz"] > 0
    g.conn.execute("UPDATE links SET strength=5.0 WHERE a='X1' OR b='X1'")              # (and it can fail)
    assert _deposits(g, "F2")["kaz"] < 0.9 * _deposits(g, "F2", without="X1")["kaz"]
    g.conn.execute("UPDATE links SET strength=0.0 WHERE a='X1' OR b='X1'")
    # the next turn's packet has it near the top, before anyone speaks
    packet, _ = build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)
    assert "=== DOUBTS" in packet and packet.index("=== DOUBTS") < packet.index("=== PRESENT")
    line = next(x for x in packet.splitlines() if x.startswith("[X1]"))
    assert "open 1 turn (raised T4 by you)" in line and "Kaz [kaz]" in line and "F2" in line and "T2" in line


def test_raising_the_same_doubt_again_bumps_it(make_game):
    g = _demo(make_game)
    first = doubts.raise_(g, "F2 says Kaz owes Razor; T2 says the drinks settled it", ["F2", "T2"], 4)
    assert first["status"] == "new" and first["id"] == "X1"
    again = doubts.raise_(g, "F2 says Kaz owes Razor - T2 says the drinks settled it.", ["T2", "F2", "razor"], 5)
    assert again["status"] == "bumped" and again["id"] == "X1" and again["doubt"]["times"] == 2
    assert "razor" in doubts.about(g.conn, "X1")                      # (what's newly involved joins it)
    assert doubts.raise_(g, "Who paid for the jukebox Razor broke?", ["F2", "T2"], 5)["status"] == "new"   # X2
    assert doubts.raise_(g, "F2 says Kaz owes Razor; T2 says the drinks settled it", ["F1"], 5)["id"] == "X3"
    assert "2x" in build_packet(g, g.current_scene_id(), [], 6)[0]
    doubts.resolve(g, "X1", 6, "The favor stands; the drinks were thanks.")
    back = doubts.raise_(g, "F2 says Kaz owes Razor; T2 says the drinks settled it", ["F2", "T2"], 7)
    assert back["status"] == "settled" and back["id"] == "X1"          # settled once: told, not opened twice
    assert g.conn.execute("SELECT COUNT(*) FROM doubts").fetchone()[0] == 3


def test_a_doubt_on_this_very_turn_waits_for_the_memory_pass(make_game):
    """T4 has no slice until the memory pass writes it: the line waits (LATE), then lands on it."""
    g = _demo(make_game, [([text("Kaz calls Razor his debtor.\n<dm>\ndoubt T4, F2: " + SLIP + "\n</dm>")],
                           "end_turn")])
    res = g.run_turn([("razor", "Kaz?")])
    assert res.turn_id == 4 and set(doubts.about(g.conn, "X1")) == {"T4", "F2"}


def test_a_doubt_naming_no_one_on_file_is_kept_anyway(make_game):
    g = _demo(make_game, [([text("Rain.\n<dm>\ndoubt: The timeline of the bridge job doesn't fit the clock\n"
                                 "doubt nobody-here: Someone the record has never heard of knew about the chip\n</dm>")],
                           "end_turn")])
    g.run_turn([("razor", "Wait.")])
    texts = [d["text"] for d in doubts.listing(g.conn, g.turn_no())["open"]]
    assert texts[0].startswith("The timeline of the bridge job")
    assert "never heard of" in texts[1] and "(also named, not on file: nobody-here)" in texts[1]


# ── settling one ────────────────────────────────────────────────────────

def test_the_doubt_tool_settles_one_right_after_research_in_free_steps(make_game):
    script = [([tool("recall", ids=["F2"]), tool("doubt", action="raise", ids=["F2", "T2", "kaz"], text=SLIP)],
               "tool_use"),
              ([tool("doubt", action="resolve", id="X1", text="Kaz still owes Razor; the free drinks were thanks",
                     fixes=["note kaz, razor: The free drinks were thanks - the favor is still owed (F2 stands)."])],
               "tool_use"),
              ([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="press Kaz")],
               "tool_use"),
              ([text("Kaz sighs. \"Fine. I owe you.\"")], "end_turn")]
    llm = LoopLLM(script, COMMIT)
    g = _demo(make_game, llm=llm)
    g.settings.models.dm_max_steps = 2                    # (two steps: the doubt steps would have eaten them)
    res = g.run_turn([("razor", "You owe me, Kaz.")])
    assert res.narration.startswith("Kaz sighs.") and "Negotiation" in res.cards[0]
    assert not any("tool budget for this turn is spent" in n for n in _engine_notes(llm))
    d = doubts.get(g, "X1")
    assert d["status"] == "resolved" and d["resolved_by"] == "gm" and "free drinks were thanks" in d["resolution"]
    assert d["text"] == SLIP                              # (the doubt itself is kept: history)
    note = g.sub.notes_for("kaz", 1)[0]
    assert "favor is still owed" in note["text"] and note["id"] == g.sub.notes_for("razor", 1)[0]["id"]
    results = [b["content"] for m in llm.calls[-1] if m["role"] == "user" and isinstance(m["content"], list)
               for b in m["content"] if isinstance(b, dict) and b.get("type") == "tool_result"]
    assert any(r.startswith("[X1] is on your DOUBTS list") for r in results)
    assert any(r.startswith("[X1] resolved") and "Record fixed: N" in r for r in results)
    assert _tool_label(g, tool("doubt", action="raise", ids=["kaz"], text="x")) == "📚 squaring the record"


def test_a_resolve_whose_fix_doesnt_land_stays_open(make_game):
    """A fix that went nowhere can't close the doubt - live T181, a lost canon fix read as resolved by the next pass."""
    g = _demo(make_game)
    ctx = _ctx(g)
    dispatch(ctx, "doubt", {"action": "raise", "ids": ["F2", "kaz"], "text": SLIP})
    karma = g.ledger.stat("razor", "karma")
    out = dispatch(ctx, "doubt", {"action": "resolve", "id": "X1", "text": "The favor stands.",
                                  "fixes": ["note nobody-here: lost", "karma razor: +3 for nothing"]})
    assert out.startswith("[X1] NOT resolved") and "note nobody-here: lost" in out and "karma razor" in out
    assert doubts.get(g, "X1")["status"] == "open" and g.ledger.stat("razor", "karma") == karma
    out = dispatch(ctx, "doubt", {"action": "resolve", "id": "x1", "text": "The favor stands.",
                                  "fixes": ["fact kaz, razor (replaces F2): Kaz still owes Razor the favor."]})
    assert out.startswith("[X1] resolved") and g.sub.superseded_by("F2")
    assert dispatch(ctx, "doubt", {"action": "dismiss", "id": "X1", "text": "x"}).startswith("[X1] is already resolved")
    with pytest.raises(RulesRefusal):
        dispatch(ctx, "doubt", {"action": "resolve", "id": "X9", "text": "?"})
    r = run_tool(ctx, tool("doubt", action="raise", ids=["kaz"], text=""))
    assert r["is_error"] and r["content"].startswith("Refused:") and ctx.tool_errors == 0   # (the GM's slip, no flag)


def test_resolve_and_dismiss_lines_route_by_prefix(make_game):
    g = _demo(make_game)
    q = tensions.open_tension(g, "Will Joey come back for Razor?", ["razor"], 3)
    for words in (SLIP, "N1 says Kaz sells to Lone Star; F4 says he's out of Lone Star for good",
                  "T3's courier was Renraku; N3's team is Aztechnology"):
        doubts.raise_(g, words, ["F2"], 3)
    g.llm.dm_script = [([text("The bar goes quiet.\n<dm>\nresolve X1: Kaz still owes Razor; 'Razor owes Kaz' was a "
                              "slip\nfact kaz, razor (replaces F2): Kaz owes Razor a favor, and says so.\n"
                              f"resolve {q}: Joey's gone to ground.\ndismiss X2: Both true - he quit, and still "
                              "sells to old friends\ndoubt X3, T3: T3's own summary says Renraku too\n"
                              f"dismiss {q}: not a doubt\n</dm>")], "end_turn")]
    logged = []
    g.out = logged.append
    g.run_turn([("razor", "Kaz.")])
    x1, x2, x3 = (doubts.get(g, x) for x in ("X1", "X2", "X3"))
    assert x1["status"] == "resolved" and "was a slip" in x1["resolution"] and g.sub.superseded_by("F2")
    assert tensions.get(g, q)["status"] == "resolved"                   # (resolve Q#: still the tension's)
    assert x2["status"] == "dismissed" and x2["resolution"].startswith("Both true")
    assert x3["status"] == "open" and "T3" in doubts.about(g.conn, "X3")
    assert "T3's own summary says Renraku too" in doubts.listing(g.conn, 9)["open"][0]["notes"][0]["text"]
    assert any("dismiss needs a doubt id like X3" in x for x in logged)


def test_a_settled_doubt_raised_again_by_id_reopens_with_its_history(make_game):
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2"], 3)
    doubts.resolve(g, "X1", 4, "The favor stands.")
    d = doubts.work(g, "X1", "T6 has Razor owing Kaz again", 6)
    assert d["status"] == "open" and d["resolution"] is None
    note = doubts.listing(g.conn, 6)["open"][0]["notes"][-1]["text"]
    assert "T6 has Razor owing Kaz again" in note and "reopened - it was resolved at T4 by the GM: The favor stands." in note


# ── the packet ──────────────────────────────────────────────────────────

def test_the_packet_lists_doubts_here_first_then_the_rest_and_caps_them(make_game):
    g = _demo(make_game)
    doubts.raise_(g, "Tanaka's fence is in Chinatown in F3 but in Redmond in a note", ["tanaka", "F3"], 1)
    doubts.raise_(g, SLIP, ["F2"], 2)                                  # (a fact about Kaz and Razor: here)
    for what in ("the courier's employer", "the bridge's toll camera", "who sealed the chip", "the buyer's deadline",
                 "Renraku's recovery team", "the host's rating", "the cyberarm prototype", "where the van went",
                 "how many guards rode along"):
        doubts.raise_(g, f"The record disagrees about {what}", ["renraku-datachip"], 5)
    doubts.raise_(g, "A settled one never shows", ["kaz"], 2)
    doubts.dismiss(g, "X12", 3, "fine")
    packet, _ = build_packet(g, g.current_scene_id(), [], 14)
    lines = packet.splitlines()
    head = next(i for i, x in enumerate(lines) if x.startswith("=== DOUBTS"))
    assert lines[head + 1].startswith("[X2] open 12 turns - PRESSING")   # here first, though X1 is older
    assert lines[head + 2] == "Elsewhere in the story:" and lines[head + 3].startswith("[X1] open 13 turns - PRESSING")
    shown = [x for x in lines[head:] if x.startswith("[X")]
    # the ones past SHOWN are named, and recall reads them (review 2026-10-26: "search_memory kinds: doubt finds them"
    # - a search with no words finds nothing, and nothing named them)
    assert len(shown) == doubts.SHOWN and "(and 3 more open: X9, X10, X11 - recall one by its X# to read it)" in packet
    assert "how many guards rode along" in dispatch(_ctx(g), "recall", {"ids": ["X11"]})
    assert "[X12]" not in packet and "A settled one never shows" not in packet
    assert "research it - read_turn, timeline, search_memory" in lines[head]
    assert "Never narrate over one as if it weren't there" in lines[head]


def test_no_doubts_no_section(make_game):
    g = _demo(make_game)
    assert "=== DOUBTS" not in build_packet(g, g.current_scene_id(), [], 4)[0]


# ── who else raises and settles them ────────────────────────────────────

def _canon_data(**over):
    base = {"settled": [], "people": [], "holdings": [], "timeline": [], "upcoming": [], "open_threads": [],
            "closed_threads": [], "rulings": [], "over": [],
            "conflicts": [{"issue": "T1 calls Joey an Ancient; N2 might mean he's freelance", "canon": "Probably an "
                           "Ancient", "fixes": ["note joey-two-knives: a guess, never to be applied"], "sure": False,
                           "ids": ["T1", "N2", "joey-two-knives"]}],
            "doubts": [{"id": "X1", "verdict": "resolved", "truth": "The favor stands; the drinks were thanks.",
                        "fixes": ["note kaz, razor: The favor is still owed - the drinks were thanks."]},
                       {"id": "X2", "verdict": "still_open", "truth": "", "fixes": []},
                       {"id": "X3", "verdict": "resolved", "truth": "Settled, it says", "fixes": ["note nobody: lost"]},
                       {"id": "X9", "verdict": "resolved", "truth": "Not one it was shown", "fixes": []}]}
    return {**base, **over}


def test_the_canon_settles_doubts_and_raises_the_conflicts_it_cant(make_game, tmp_path):
    seen = []

    def structured(user):
        if "ENGINE RULES" in user:
            seen.append(user)
            return _canon_data()
        return COMMIT
    g = _demo(make_game, extraction=structured)
    doubts.raise_(g, SLIP, ["F2", "T2"], 3)
    doubts.raise_(g, "Is the Lucky Shot's back door on Fifth or on the alley?", ["the-lucky-shot"], 3)
    doubts.raise_(g, "Did Tanaka meet Kaz at T3 or not?", ["tanaka", "kaz"], 3)
    res = canon.run(g)
    assert "OPEN DOUBTS" in seen[0] and "[X1] (raised T3 by the GM" in seen[0] and "on F2 (fact, T" in seen[0]
    x1 = doubts.get(g, "X1")
    assert x1["status"] == "resolved" and x1["resolved_by"] == "canon" and x1["resolution"].startswith("The favor")
    assert any("still owed - the drinks were thanks" in n["text"] for n in g.sub.notes_for("kaz", 9))
    assert doubts.get(g, "X2")["status"] == "open"                       # still_open: left for the GM
    x3 = doubts.get(g, "X3")                                             # its fix went nowhere: not settled
    assert x3["status"] == "open" and "couldn't be written: note nobody: lost" in doubts._notes(g.conn, "X3")[0]["text"]
    assert "note nobody: lost" in res["unplaced"]
    # the conflict it wasn't sure of: a doubt, raised by the canon - and its guess never applied
    x4 = doubts.get(g, "X4")
    assert x4["raised_by"] == "canon" and "(the read-back leans: Probably an Ancient)" in x4["text"]
    assert set(doubts.about(g.conn, "X4")) == {"T1", "N2", "joey-two-knives"}
    assert not any("a guess" in n["text"] for n in g.sub.notes_for("joey-two-knives", 9))
    assert res["doubts_resolved"] == ["X1"] and res["doubts_raised"] == ["X4"] and not doubts.get(g, "X9")
    text = canon.render(canon.current(g))
    assert "LEFT OPEN AS DOUBTS" in text and "-> [X4]" in text and "DOUBTS IT SETTLED" in text
    flag = next(f for f in flags.listing(tmp_path) if f["kind"] == "canon fixes")
    assert "Doubts settled: X1." in flag["text"] and "Left open as doubts (the record can't tell): X4." in flag["text"]
    assert canon.schema()["properties"]["doubts"]["items"]["properties"]["verdict"]["enum"] == ["resolved",
                                                                                               "still_open"]


def test_an_aside_raises_and_settles_doubts_in_its_fixes(make_game):
    replies = iter([{"answer": "Good catch - I'll look into it.", "direction": "", "is_move": False,
                     "fixes": ["doubt F2, kaz: Alice says Kaz paid the favor back at T2; F2 still has him owing"]},
                    {"answer": "Checked - he still owes you.", "direction": "", "is_move": False,
                     "fixes": ["resolve X1: The favor is still owed", "note kaz: Still owes Razor the favor."]},
                    {"answer": "Not a problem.", "direction": "", "is_move": False,
                     "fixes": ["doubt T1: Was Joey alone?", "dismiss X2: Joey came alone, T1 says so"]}])

    def structured(user):
        return next(replies) if "SAYS TO YOU, OUT OF CHARACTER" in user else COMMIT
    g = _demo(make_game, extraction=structured)
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, Kaz paid that favor back already", "razor")
    assert res["fixed"] == ["a doubt the GM will look into"]
    assert doubts.get(g, "X1")["raised_by"] == "aside" and "=== DOUBTS" in build_packet(g, 3, [], 4)[0]
    res = aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, did you check?", "razor")
    assert res["fixed"] == ["the GM's notes"]
    assert doubts.get(g, "X1")["status"] == "resolved" and doubts.get(g, "X1")["resolved_by"] == "aside"
    aside.ask(g, "Alice (plays Razor [razor])", "Hey DM, was Joey alone?", "razor")
    assert doubts.get(g, "X2")["status"] == "dismissed"


def test_the_memory_pass_raises_a_doubt_for_a_slip_against_a_known_fact(make_game):
    """It already reads each narration against FACTS ALREADY KNOWN; a slip against one becomes a doubt."""
    assert "contradictions" in commit_schema()["required"] and "contradictions: RARER STILL" in COMMIT_SYSTEM
    slip = {**COMMIT, "contradictions": [{"fact": "F2", "how": "F2 has Kaz owing Razor; Razor owes Kaz here"}]}
    g = _demo(make_game, [([text("\"You owe me, Razor,\" Kaz says.")], "end_turn")], slip)
    res = g.run_turn([("razor", "Kaz?")])
    d = doubts.get(g, "X1")
    assert d["raised_by"] == "commit" and d["text"].startswith(f"T{res.turn_id}'s narration doesn't fit [F2]")
    assert set(doubts.about(g.conn, "X1")) == {"F2", f"T{res.turn_id}"}
    g2 = _demo(make_game, [([text("Rain.")], "end_turn")],
               {**COMMIT, "contradictions": [{"fact": "F99", "how": "a fact it was never shown"}]})
    g2.run_turn([("razor", "Kaz?")])
    assert doubts.listing(g2.conn, 9)["open"] == []


def test_the_same_slip_on_later_turns_bumps_the_one_doubt(make_game):
    """Review (2026-10-26): each repeat was matched by its ids - {F2, T4} against {F2, T5} - so every turn that slipped
    again opened another X#, each "1x" and new, and the DOUBTS list filled with one problem."""
    hows = ["F2 has Kaz owing Razor; Razor owes Kaz here", "F2 has Kaz owing Razor; Razor owes Kaz here",
            "Kaz again says Razor is in his debt - F2 says the reverse"]

    def memory_pass(user):
        return {**COMMIT, "contradictions": [{"fact": "F2", "how": hows.pop(0)}]} if "KNOWN ENTITIES" in user else COMMIT
    g = _demo(make_game, [([text("\"You owe me, Razor,\" Kaz says.")], "end_turn")] * 3, memory_pass)
    turns = [g.run_turn([("razor", "Kaz?")]).turn_id for _ in range(3)]
    opened = doubts.listing(g.conn, g.turn_no())["open"]
    assert [d["id"] for d in opened] == ["X1"]
    d = opened[0]
    assert d["times"] == 3 and d["raised_turn"] == turns[0] and d["last_turn"] == turns[-1]   # (aged from the first)
    assert {a["id"] for a in d["about"]} == {"F2"} | {f"T{t}" for t in turns}                 # each turn that slipped
    assert [n["text"] for n in d["notes"]] == [f"(the memory pass) T{turns[1]}'s narration again: F2 has Kaz owing "
                                               "Razor; Razor owes Kaz here",
                                               f"(the memory pass) T{turns[2]}'s narration again: Kaz again says Razor "
                                               "is in his debt - F2 says the reverse"]
    line = next(x for x in build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0].splitlines()
                if x.startswith("[X1]"))
    assert "3x" in line and "Latest" in line
    doubts.resolve(g, "X1", g.turn_no(), "F2 stands: Kaz owes Razor; the narration slipped.")
    g.llm.dm_script = [([text("Rain.")], "end_turn")]
    g.llm.extraction = {**COMMIT, "contradictions": [{"fact": "F2", "how": "still the wrong way round"}]}
    g.run_turn([("razor", "Kaz?")])
    assert [x["id"] for x in doubts.listing(g.conn, g.turn_no())["open"]] == ["X2"]   # (settled: a new slip is new)


# ── undo, the owner's view, the dashboard, the graph ────────────────────

def test_doubts_are_turn_state_and_survive_an_old_snapshot(make_game):
    g = _demo(make_game, [([text("Rain.\n<dm>\ndoubt F2: " + SLIP + "\n</dm>")], "end_turn")])
    g.run_turn([("razor", "Kaz?")])
    assert doubts.get(g, "X1")
    g.undo()                                                    # the turn that raised it goes, and the doubt with it
    assert doubts.get(g, "X1") is None and not g.sub.exists("X1")
    assert doubts.raise_(g, SLIP, ["F2"], 4)["id"] == "X1"      # (the id sequence went back too)
    # a snapshot an earlier build took has no doubts table: an undo onto it mustn't drop the table from the game
    g.llm.dm_script = [([text("Rain again.")], "end_turn")]
    g.run_turn([("razor", "Kaz?")])
    snap = sorted(Path(g.undo_dir).glob("before_*.db"))[-1]
    c = sqlite3.connect(str(snap))
    c.execute("DROP TABLE doubts")
    c.commit()
    c.close()
    g.undo()
    assert doubts.listing(g.conn, 9)["open"] == []              # (the table is back - empty, as that snapshot was)
    assert doubts.raise_(g, "After the undo", ["kaz"], 5)["status"] == "new"


def test_the_owner_reads_the_doubts_by_dm(make_game):
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 1)
    doubts.raise_(g, "Was Joey alone at T1?", ["T1"], 2)
    doubts.dismiss(g, "X2", 3, "T1 says he was")
    assert any("`!doubts`" in c["description"] for c in help_cards())

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "Alice", "!doubts", False, react)
        assert "for the campaign owner" in ch.sent[-1]["text"] and not ch.dms
        await t.handle("9", "Owner", "!doubts", True, react)
        body = ch.dms[-1][1]
        assert "OPEN DOUBTS (1)" in body and "[X1] T1, open 2 turns" in body and "on: F2, Kaz [kaz]" in body
        assert "RECENTLY SETTLED (1 of 1)" in body and "[X2] dismissed T3 by the GM" in body
        assert "-> T1 says he was" in body
        await t.close()
    asyncio.run(go())


def test_the_dashboard_canon_page_lists_doubts(make_game, tmp_path):
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 1)
    doubts.raise_(g, "Was Joey alone at T1?", ["T1"], 2)
    doubts.resolve(g, "X2", 3, "Yes", by="canon")
    v = data.canon_view(g.path.stem, tmp_path)
    assert [d["id"] for d in v["doubts"]["open"]] == ["X1"] and v["doubts"]["open"][0]["raised_by_name"] == "the GM"
    assert {"id": "kaz", "label": "Kaz"} in v["doubts"]["open"][0]["about"]
    assert v["doubts"]["settled"][0]["resolved_by_name"] == "the canon read-back" and v["pressing_after"] == 10
    js = (Path(data.__file__).parent / "static" / "app.js").read_text(encoding="utf-8")
    assert "Doubts - where the record doesn" in js and "doubtPanel" in js


def test_the_3d_graph_draws_doubts(make_game):
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 1)
    doubts.raise_(g, "Was Joey alone at T1?", ["T1"], 2)
    doubts.dismiss(g, "X2", 3, "Yes")
    api = Api(g.path)
    nodes = {n["id"]: n for n in api.graph()["nodes"]}
    assert nodes["X1"]["kind"] == "doubt" and nodes["X1"]["settled"] is False and nodes["X2"]["settled"] is True
    assert any(e["source"] in ("X1", "kaz") and e["target"] in ("X1", "kaz") and e["kind"] == "about"
               for e in api.graph()["edges"])
    one = api.node("X1")
    assert one["doubt"]["status"] == "open" and {"id": "kaz", "label": "Kaz"} in one["doubt"]["about"]
    html = (Path(browser_server.__file__).parent / "static" / "graph3d.html").read_text(encoding="utf-8")
    assert "doubt:     { color: '#c6ff00', label: 'Doubt'" in html and "'tension', 'doubt', 'other'" in html
    assert "knot: '∞'" in html and "case 'knot'" in html and "n.kind === 'doubt' ? 'doubt'" in html


# ── research sees them; the GM is told ──────────────────────────────────

def test_recall_and_search_show_doubts(make_game):
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 1)
    ctx = _ctx(g)
    out = dispatch(ctx, "recall", {"ids": ["X1"]})
    assert "DOUBT open · raised T1 by you" in out and "on: F2, Kaz [kaz]" in out and "Side [F2] (fact, T" in out
    assert "DOUBT [X1] (open since T1)" in dispatch(ctx, "recall", {"ids": ["F2"]})
    assert "DOUBT [X1]" in dispatch(ctx, "recall", {"ids": ["kaz"]})
    hits = dispatch(ctx, "search_memory", {"query": "favor owing", "kinds": ["doubt"]})
    assert "[X1] (doubt, open, T1)" in hits
    doubts.resolve(g, "X1", 2, "The favor stands")
    assert "(doubt, resolved, T1; resolved T2: The favor stands)" in dispatch(ctx, "search_memory",
                                                                             {"query": "favor owing"})


def test_the_gm_is_told_what_a_doubt_is_for():
    assert "## When the record doesn't add up" in DM_SYSTEM and "never quietly pick a version" in DM_SYSTEM
    assert "`doubt <ids>: <what doesn't add up, both versions>`" in DM_SYSTEM and "`resolve X3:" in DM_SYSTEM
    assert "a tension (Q#) is an open question in the fiction" in DM_SYSTEM and "`flag:` is the engine" in DM_SYSTEM
    doubt = next(t for t in TOOLS if t["name"] == "doubt")
    assert doubt["input_schema"]["properties"]["action"]["enum"] == ["raise", "resolve", "dismiss"]
    assert "doubt" in doubt["description"].lower() and "fixes" in doubt["input_schema"]["properties"]
    assert "raise it in fixes as a doubt" in aside.SYSTEM
    assert "sure: true only when the record makes it clear" in canon.SYSTEM
    assert "An issue already on OPEN DOUBTS goes in doubts only" in canon.SYSTEM
    assert 'A fact marked "(checked: ...)" has been looked into' in COMMIT_SYSTEM


# ── review fixes (2026-10-26): a doubt never goes into the ether ────────

def test_a_dismissed_slip_stays_dismissed_and_a_resolved_one_reopens(make_game):
    """Review (2026-10-26): the memory pass's doubt on [F2, T4] never matched [F2, T5], so a false positive the GM had
    dismissed came back as a new X# the very next turn. The GM's "never was one" stands; a resolved one whose slip
    comes back reopens with its answer kept - and the pass is shown the answer beside the fact."""
    how = "F2 has Kaz owing Razor; Razor owes Kaz here"
    seen = []

    def memory_pass(user):
        if "KNOWN ENTITIES" not in user:
            return COMMIT
        seen.append(user)
        return {**COMMIT, "contradictions": [{"fact": "F2", "how": how}]}
    g = _demo(make_game, [([text("\"You owe me, Razor,\" Kaz says.")], "end_turn")] * 2, memory_pass)
    logged = []
    g.out = logged.append
    g.run_turn([("razor", "Kaz?")])
    doubts.dismiss(g, "X1", g.turn_no(), "Banter - Kaz says it to everyone")
    g.run_turn([("razor", "Kaz?")])
    assert g.conn.execute("SELECT COUNT(*) FROM doubts").fetchone()[0] == 1 and doubts.get(g, "X1")["status"] == "dismissed"
    assert "(checked: a doubt on it was dismissed T4 - Banter - Kaz says it to everyone)" in seen[-1]
    assert any("X1 was dismissed" in x for x in logged)
    g2 = _demo(make_game, [([text("\"You owe me, Razor,\" Kaz says.")], "end_turn")] * 2, memory_pass)
    g2.run_turn([("razor", "Kaz?")])
    doubts.resolve(g2, "X1", g2.turn_no(), "F2 stands: Kaz owes Razor; the narration slipped.")
    t = g2.run_turn([("razor", "Kaz?")]).turn_id
    d = doubts.get(g2, "X1")
    assert d["status"] == "open" and f"T{t}" in doubts.about(g2.conn, "X1")
    assert g2.conn.execute("SELECT COUNT(*) FROM doubts").fetchone()[0] == 1
    note = doubts._notes(g2.conn, "X1")[-1]["text"]
    assert note.startswith(f"(the memory pass) T{t}'s narration again: {how}")
    assert "(reopened - it was resolved at T4 by the GM: F2 stands" in note


def _verdict(xid, truth, fixes):
    return _canon_data(conflicts=[], doubts=[{"id": xid, "verdict": "resolved", "truth": truth, "fixes": fixes}])


def test_the_canon_keeps_the_gms_answer_to_a_doubt_settled_while_it_read(make_game):
    """Review (2026-10-26): think runs off the game thread while turns go on, and the packet tells the GM to settle a
    doubt before it narrates - so the GM often settles the very doubt the read-back is still judging. Its stale fixes
    landed on top of the GM's ruling (the record said both, the doubt read settled), and a failed one reopened it."""
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 3)
    gathered = canon.gather(g)
    doubts.resolve(g, "X1", 4, "Razor owes Kaz - F2 was the slip")          # (a turn, while think ran)
    res = canon.apply(g, gathered, _verdict("X1", "Kaz owes Razor",
                                            ["note kaz, razor: CANON-STALE Kaz still owes Razor."]))
    d = doubts.get(g, "X1")
    assert d["status"] == "resolved" and d["resolved_by"] == "gm" and d["resolution"].startswith("Razor owes Kaz")
    assert not any("CANON-STALE" in n["text"] for n in g.sub.notes_for("kaz", 20))     # (its fixes never applied)
    kept = doubts._notes(g.conn, "X1")[-1]["text"]
    assert "would have resolved it: Kaz owes Razor - with: note kaz, razor: CANON-STALE" in kept
    assert "not applied: it was resolved first (T4, by the GM)" in kept
    assert res["doubts_late"] == ["X1"] and not res["doubts_resolved"] and not res["fixed"]
    assert "DOUBTS SETTLED OR WORKED ON WHILE IT READ" in canon.render(canon.current(g))
    # a fix of its that fails reopens nothing: the GM's answer stands
    doubts.raise_(g, "Was Joey alone at T1?", ["T1", "joey-two-knives"], 4)            # X2
    gathered = canon.gather(g)
    doubts.dismiss(g, "X2", 5, "T1 says so")
    canon.apply(g, gathered, _verdict("X2", "He had his crew", ["note nobody-here: lost"]))
    assert doubts.get(g, "X2")["status"] == "dismissed"
    # worked on since (still open): its answer is a note for the GM, not applied
    doubts.raise_(g, "Is the back door on Fifth or on the alley?", ["the-lucky-shot"], 3)   # X3
    gathered = canon.gather(g)
    g.llm.dm_script = [([text("Rain.\n<dm>\ndoubt X3, T2: T2 has Razor throw Joey out the back - into the alley\n"
                              "</dm>")], "end_turn")]
    g.run_turn([("razor", "Kaz?")])
    canon.apply(g, gathered, _verdict("X3", "Fifth", ["note the-lucky-shot: The back door is on Fifth."]))
    x3 = doubts.listing(g.conn, 9)["open"][0]
    assert x3["id"] == "X3" and "worked on since" in x3["notes"][-1]["text"]           # (the packet's Latest)
    assert not any("on Fifth" in n["text"] for n in g.sub.notes_for("the-lucky-shot", 9))


def test_after_an_undo_the_canon_never_settles_another_doubt_by_its_old_id(make_game):
    """Review (2026-10-26): an undo hands an X# out again (the sequence is turn state) - the read-back settled the
    Joey doubt with the favor doubt's answer."""
    g = _demo(make_game, [([text("Rain.\n<dm>\ndoubt F2, kaz: " + SLIP + "\n</dm>")], "end_turn"),
                          ([text("Sun.\n<dm>\ndoubt T1, joey-two-knives: Was Joey alone at T1 or with his crew?\n</dm>")],
                           "end_turn")])
    g.run_turn([("razor", "Kaz?")])
    gathered = canon.gather(g)                           # X1: the favor
    g.undo()
    g.run_turn([("razor", "Joey?")])                     # X1 again: Joey's crew
    res = canon.apply(g, gathered, _verdict("X1", "Kaz owes Razor - the favor stands", []))
    d = doubts.get(g, "X1")
    assert d["text"].startswith("Was Joey alone") and d["status"] == "open" and not res["doubts_resolved"]


def test_a_dm_resolve_beside_a_fix_that_didnt_land_stays_open(make_game):
    """Review (2026-10-26): `resolve X1` beside a fact naming no one on file closed X1 while F2 stood - the doubt off
    the list, the contradiction still in the record, one log line. The doubt tool and the canon already refused that;
    the <dm> line (the one DM_SYSTEM teaches) waits now for the block's fix lines - held ones too, until after the
    memory pass."""
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 3)
    g.llm.dm_script = [([text("Kaz shrugs.\n<dm>\nresolve X1: Kaz still owes Razor - tonight's line was a slip\n"
                              "fact kaz-the-barman (replaces F2): Kaz owes Razor the favor, and says so.\n</dm>")],
                        "end_turn")]
    g.run_turn([("razor", "Kaz.")])
    still = doubts.listing(g.conn, 9)["open"]
    assert [d["id"] for d in still] == ["X1"] and not g.sub.superseded_by("F2")
    why = still[0]["notes"][-1]["text"]
    assert why.startswith("Not resolved: its answer (Kaz still owes Razor") and "kaz-the-barman" in why
    assert "Not resolved" in build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0]    # (the GM hears why)
    g.llm.dm_script = [([text("Kaz nods.\n<dm>\nresolve X1: Kaz still owes Razor\nfact kaz, razor (replaces F2): Kaz "
                              "owes Razor the favor, and says so.\n</dm>")], "end_turn")]
    g.run_turn([("razor", "Kaz.")])
    assert doubts.get(g, "X1")["status"] == "resolved" and g.sub.superseded_by("F2")


def test_a_resolve_that_half_lands_is_taken_back_whole(make_game):
    """Review (2026-10-26): the doubt tool kept the fix lines that landed, and the retry it asked for - the whole list,
    one line corrected - wrote them again: two identical facts, both replacing F2."""
    g = _demo(make_game)
    ctx = _ctx(g)
    dispatch(ctx, "doubt", {"action": "raise", "ids": ["F2", "kaz"], "text": SLIP})
    fixes = ["fact kaz, razor (replaces F2): Kaz owes Razor the favor.", "note kaz-typo: the drinks were thanks"]
    out = dispatch(ctx, "doubt", {"action": "resolve", "id": "X1", "text": "Kaz owes Razor", "fixes": fixes})
    assert out.startswith("[X1] NOT resolved") and "taken back with them: nothing was written" in out
    assert not g.sub.superseded_by("F2") and doubts.get(g, "X1")["status"] == "open"
    assert not any(e.startswith("FACT") for e in ctx.events) and not ctx.expanded
    out = dispatch(ctx, "doubt", {"action": "resolve", "id": "X1", "text": "Kaz owes Razor",
                                  "fixes": [fixes[0], "note kaz: the drinks were thanks"]})
    assert out.startswith("[X1] resolved")
    assert len(g.conn.execute("SELECT * FROM supersedes WHERE old_id='F2'").fetchall()) == 1


def test_raising_a_settled_doubt_again_in_a_line_reopens_it(make_game):
    """Review (2026-10-26): a <dm> line raising a doubt already settled was a log line - nothing reached the GM's
    DOUBTS list and it never heard why, though the record still disagreed (the new side it named wasn't kept
    either). The canon reports one it may not reopen as settled, never as "left open"."""
    g = _demo(make_game)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 3)
    doubts.dismiss(g, "X1", 3, "banter, not a slip")
    g.llm.dm_script = [([text("Kaz frowns.\n<dm>\ndoubt F2, kaz, T2: " + SLIP + "\n</dm>")], "end_turn")]
    g.run_turn([("razor", "Kaz.")])
    still = doubts.listing(g.conn, 9)["open"]
    assert [d["id"] for d in still] == ["X1"] and "T2" in doubts.about(g.conn, "X1")    # (the new side joins it)
    assert "(reopened - it was dismissed at T3 by the GM: banter, not a slip)" in still[0]["notes"][-1]["text"]
    assert "=== DOUBTS" in build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0]
    # the canon: a dismissal isn't the read-back's to undo - left settled, and labelled so
    doubts.dismiss(g, "X1", 5, "banter, again")
    unsure = {"issue": SLIP, "canon": "", "fixes": [], "sure": False, "ids": ["F2", "kaz", "T2"]}
    res = canon.apply(g, canon.gather(g), _canon_data(conflicts=[unsure], doubts=[]))
    assert doubts.get(g, "X1")["status"] == "dismissed" and not res["doubts_raised"]
    text_ = canon.render(canon.current(g))
    assert "LEFT OPEN AS DOUBTS" not in text_ and f"ALREADY SETTLED AS DOUBTS (that answer stands - not reopened)\n- " \
                                                  f"{SLIP} -> [X1]" in text_
    # ... and a resolved one the record disagrees with again comes back open
    doubts.raise_(g, "Was Joey alone at T1?", ["T1", "joey-two-knives"], 5)             # X2
    doubts.resolve(g, "X2", 5, "Alone")
    again = {"issue": "Was Joey alone at T1?", "canon": "", "fixes": [], "sure": False, "ids": ["T1", "joey-two-knives"]}
    res = canon.apply(g, canon.gather(g), _canon_data(conflicts=[again], doubts=[]))
    assert res["doubts_raised"] == ["X2"] and doubts.get(g, "X2")["status"] == "open"
    assert "Was Joey alone at T1? -> [X2] (reopened)" in canon.render(canon.current(g))


def test_the_canon_never_opens_a_second_doubt_beside_one_it_was_shown(make_game):
    """Review (2026-10-26): an open doubt is a conflict by definition, so the read-back listed X1 again under conflicts
    in its own words - below the 0.8 word match, so every pass opened another doubt beside it; and a sure conflict
    with a resolved verdict on the same doubt applied the same fix twice (two live successors of F2)."""
    g = _demo(make_game)
    doubts.raise_(g, "T1 calls Joey an Ancient; N2 might mean he's freelance", ["T1", "N2", "joey-two-knives"], 3)
    doubts.raise_(g, SLIP, ["F2", "T2", "kaz"], 3)
    fact = "fact kaz, razor (replaces F2): Kaz owes Razor a favor, still."
    data = _canon_data(
        conflicts=[{"issue": "T1 has Joey as an Ancient, but N2 suggests he works freelance",
                    "canon": "Ancient, most likely", "fixes": [], "sure": False, "ids": ["T1", "N2", "joey-two-knives"]},
                   {"issue": "Who owes whom: F2 against T2", "canon": "Kaz owes Razor", "sure": True,
                    "ids": ["F2", "T2", "kaz", "razor"], "fixes": [fact]}],
        doubts=[{"id": "X1", "verdict": "still_open", "truth": "", "fixes": []},
                {"id": "X2", "verdict": "resolved", "truth": "Kaz owes Razor", "fixes": [fact]}])
    res = canon.apply(g, canon.gather(g), data)
    assert not res["doubts_raised"] and g.conn.execute("SELECT COUNT(*) FROM doubts").fetchone()[0] == 2
    x1 = doubts.listing(g.conn, 9)["open"][0]
    assert x1["id"] == "X1" and x1["notes"][-1]["text"] == ("(the canon read-back) T1 has Joey as an Ancient, but N2 "
                                                            "suggests he works freelance (the read-back leans: "
                                                            "Ancient, most likely)")
    assert doubts.get(g, "X2")["status"] == "resolved" and res["doubts_resolved"] == ["X2"]
    assert len(g.conn.execute("SELECT * FROM supersedes WHERE old_id='F2'").fetchall()) == 1     # (one fix, not two)
    assert "-> [X1]" in canon.render(canon.current(g))                                           # (open: it is)


def test_an_aside_says_fixed_only_for_what_changed(make_game):
    """Review (2026-10-26): a doubt line matching a settled one, and a resolve or dismiss of one already settled,
    changed nothing but counted as landed - the table heard "Fixed in the record: a doubt the GM will look into"
    with nothing open."""
    replies = iter([{"answer": "I'll look again.", "direction": "", "is_move": False, "fixes": [f"doubt F2, kaz: {SLIP}"]},
                    {"answer": "Done.", "direction": "", "is_move": False, "fixes": ["dismiss X1: again"]},
                    {"answer": "Fixed.", "direction": "", "is_move": False,
                     "fixes": ["resolve X2: Razor owes Kaz", "fact kaz-the-barman (replaces F2): Razor owes Kaz now."]}])

    def structured(user):
        return next(replies) if "SAYS TO YOU, OUT OF CHARACTER" in user else COMMIT
    g = _demo(make_game, extraction=structured)
    doubts.raise_(g, SLIP, ["F2", "kaz"], 3)
    doubts.dismiss(g, "X1", 3, "not one - the drinks were thanks")

    def ask(q):
        return aside.ask(g, "Alice (plays Razor [razor])", q, "razor")["fixed"]
    assert ask("Hey DM, Kaz paid that favor back already") == ["a doubt the GM will look into"]
    assert doubts.get(g, "X1")["status"] == "open"                   # (and it is: reopened, its old answer kept)
    doubts.dismiss(g, "X1", 3, "still not one")
    assert ask("Hey DM, drop it") == []                              # (already settled: nothing changed)
    doubts.raise_(g, "Who owes whom tonight?", ["F2", "razor"], 3)    # X2
    assert ask("Hey DM, Razor owes Kaz now") == []                    # (its fix named no one: X2 stays open)
    assert doubts.get(g, "X2")["status"] == "open" and not g.sub.superseded_by("F2")


def test_a_doubt_out_of_a_whisper_is_marked_and_kept_from_the_table(make_game):
    """Review (2026-10-26): a whisper's slip came back on the next public packet as "[X1] ... T4's narration doesn't
    fit [F2]: <the whisper>" with no mark - under a header that said to ask the table - and the aside's packet, which
    answers in the open channel, had it too. Marked now, like the whisper's slice, and an aside's lookup never reads
    another player's."""
    slip = {**COMMIT, "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "mentioned"}],
            "summary": "Razor quietly palmed the keycard from behind the bar.",
            "contradictions": [{"fact": "F2", "how": "SECRETWORD: Razor palmed Kaz's keycard; F2 has Kaz owing him"}]}
    g = _demo(make_game, [([text("You palm the keycard. Nobody sees.\n<dm>\ndoubt F2, kaz: GMWORD - Razor's lift "
                                 "means Kaz owes nobody now\n</dm>")], "end_turn")], slip)
    g.run_turn([("razor", "I quietly palm the keycard")], private="razor")
    packet = build_packet(g, g.current_scene_id(), [], g.turn_no() + 1)[0]
    lines = {x[:4]: x for x in packet.splitlines() if x.startswith("[X")}
    assert "on F2, Kaz [kaz]: WHISPER, private - only Razor knows: GMWORD" in lines["[X1]"]     # (raised in a whisper)
    assert "WHISPER, private - only Razor knows: T4's narration doesn't fit [F2]: SECRETWORD" in lines["[X2]"]
    assert "never ask the table or say it there" in packet
    gm = dispatch(_ctx(g), "recall", {"ids": ["X2"]})
    assert "Side [T4] (slice, T4) WHISPER, private - only Razor knows: Razor quietly palmed" in gm
    other = TurnContext(g, g.turn_no() + 1, g.current_scene_id(), by="aside", for_table=True, asker="ghost")
    assert "can't be looked up in an aside" in dispatch(other, "recall", {"ids": ["X2"]})
    assert "WORD" not in dispatch(other, "recall", {"ids": ["F2"]})
    assert "WORD" not in dispatch(other, "search_memory", {"query": "Kaz owes", "kinds": ["doubt"]})
    mine = TurnContext(g, g.turn_no() + 1, g.current_scene_id(), by="aside", for_table=True, asker="razor")
    assert "SECRETWORD" in dispatch(mine, "recall", {"ids": ["X2"]})


def test_a_doubt_naming_a_turn_isnt_here_just_because_the_pcs_were_in_it(make_game):
    """Review (2026-10-26): the PCs are members of every turn, so a doubt naming any turn ranked as here - one about
    Tanaka's fence above the one about Kaz, standing at the bar. Now: about someone here, then about a memory involving
    an NPC or thing here, then elsewhere."""
    g = _demo(make_game)
    doubts.raise_(g, "T3 has the fence in Chinatown; F3 has him in Redmond", ["F3", "T3"], 3)    # Tanaka: not here
    doubts.raise_(g, "Was Joey alone at T1?", ["T1"], 4)                    # a turn Kaz was in: near
    doubts.raise_(g, "Is Kaz an ork or a dwarf?", ["kaz"], 5)               # Kaz himself, at the bar
    lines = build_packet(g, g.current_scene_id(), [], 6)[0].splitlines()
    head = next(i for i, x in enumerate(lines) if x.startswith("=== DOUBTS"))
    assert [x[:4] for x in lines[head + 1:head + 5]] == ["[X3]", "[X2]", "Else", "[X1]"]
