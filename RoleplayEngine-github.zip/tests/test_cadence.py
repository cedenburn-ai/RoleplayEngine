"""Turn cadence and hands-off PCs: the window after the first action, typing and more time, sitting a turn out,
the turn card - and the GM sent back when it writes for a character a human plays."""
import asyncio

from roleplay.discord_bot.session import CampaignTable
from roleplay.discord_bot.table import TableDirector
from roleplay.dm.turn import _user_message, hands_off, overreach
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel


def run(coro):
    return asyncio.run(coro)


def _director(think=0.0, **kw):
    got = []

    async def resolve(inputs):
        got.append(inputs)
        await asyncio.sleep(think)
    d = TableDirector(resolve, lambda: {"razor", "ghost"}, **{"wait": 0.3, "cap": 10, "grace": 0.05,
                                                              "typing_grace": 0.3, "extend": 0.4, **kw})
    return d, got


def test_the_window_closes_on_whoever_spoke_and_typing_holds_it():
    async def go():
        d, got = _director()
        d.add("razor", "a")
        assert d.snapshot()["waiting"] == ["ghost"] and 0 < d.snapshot()["in"] <= 0.31
        await asyncio.sleep(0.2)
        d.typing("ghost")                                    # Ghost is typing: hold the turn a little
        assert d.snapshot()["typing"] == ["ghost"]
        await asyncio.sleep(0.2)
        assert not got
        await asyncio.sleep(0.35)
        assert got == [[("razor", "a")]] and d.batch_passed == set()
    run(go())


def test_more_time_and_sitting_out():
    async def go():
        d, got = _director(holds=1)
        d.add("razor", "a")
        assert not d.hold("razor") and not d.pass_("razor")      # only someone the turn waits on
        assert d.hold("ghost") and not d.hold("ghost")           # one extension a turn here
        await asyncio.sleep(0.45)
        assert not got                                           # 0.3 s window + 0.4 s more
        assert d.pass_("ghost")                                  # ...then Ghost sits it out: everyone's in
        await asyncio.sleep(0.15)
        assert got == [[("razor", "a")]] and d.batch_passed == {"ghost"}
        d.add("ghost", "b")
        d.add("razor", "c")
        await asyncio.sleep(0.15)
        assert got[-1] == [("ghost", "b"), ("razor", "c")] and d.batch_passed == set()
    run(go())


def test_a_post_during_the_gms_turn_waits_for_the_answer_to_land():
    async def go():
        d, got = _director(think=0.4)
        d.add("razor", "a")
        assert d.go()
        await asyncio.sleep(0.05)
        d.add("razor", "follow-up")                            # posted while the GM works
        await asyncio.sleep(0.5)                               # the GM is done at ~0.4 s...
        assert len(got) == 1                                   # ...and Ghost still gets the full window to read it
        await asyncio.sleep(0.4)
        assert got[1] == [("razor", "follow-up")]
    run(go())


def test_the_card_counts_down_pings_and_goes_away(make_game):
    g = make_game(FakeLLM())
    setup_demo(g)

    class CardChannel(FakeChannel):
        def __init__(self):
            super().__init__()
            self.cards, self.dropped = [], []

        async def turn_card(self, ref, text, ping):
            self.cards.append((ref, text, list(ping)))
            return ref or len(self.cards)

        async def drop_turn_card(self, ref):
            self.dropped.append(ref)

    async def go():
        ch = CardChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 5, "cap": 30, "grace": 0.05})
        assert t.director.wait == 5                             # (an old binding's "quiet" is the wait)
        await t.refresh()

        async def react(e):
            pass
        await t.handle("1", "A", "!join razor", False, react)
        await t.handle("2", "B", "!join ghost", False, react)
        await t.handle("1", "A", "I pick the lock.", False, react)
        await asyncio.sleep(0.1)
        ref, card, ping = ch.cards[0]
        assert ref is None and ping == ["2"] and "✅ Razor" in card and "⌛ <@2>" in card and "<t:" in card
        assert await t.turn_button("3", "go") == "You're not playing at this table - `!join <character>` first."
        assert await t.turn_button("1", "wait") == "The turn isn't waiting on you."
        await t.handle("2", "B", "!pass", False, react)          # Ghost sits it out: the turn goes, the card goes
        for _ in range(40):
            await asyncio.sleep(0.05)
            if ch.dropped:
                break
        assert ch.dropped == [1] and t.card is None
        await t.close()
    run(go())


def test_the_gm_is_told_who_did_not_post(make_game):
    g = make_game()
    setup_demo(g)
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('1','razor','A',0), ('2','ghost','B',0)")
    scene = g.current_scene_id()
    assert hands_off(g, scene, [("razor", "I pick the lock.")]) == ["Ghost"]
    msg = _user_message(g, "", [("razor", "I pick the lock.")], scene, 5)
    assert "Their players did NOT post this turn: Ghost. So this turn they say nothing and decide nothing" in msg
    g.passed = {"ghost"}
    g.active_players = {"razor", "ghost"}
    msg = _user_message(g, "", [("razor", "I pick the lock.")], scene, 5)
    assert "Ghost (their player chose to sit this turn out)" in msg and "silent this turn" not in msg
    assert hands_off(g, scene, [("razor", "a"), ("ghost", "b")]) == []


def test_the_gm_is_sent_back_when_it_writes_for_a_player_character(make_game):
    script = [([text('Kaz slides the chip over. **Ghost:** "I\'ll take it." Ghost nods at Razor.')], "end_turn"),
              ([text("Kaz slides the chip over. Ghost watches from the booth. Ghost, it's your call.")], "end_turn")]
    llm = FakeLLM(script, {"summary": "Kaz handed over the chip.", "members": [], "recalled": [], "facts": [],
                           "told": [], "new_entities": [], "moved_to": {"location": "", "description": "", "who": []}})
    g = make_game(llm)
    setup_demo(g)
    g.conn.execute("INSERT INTO players(discord_id, handle, name, afk) VALUES('1','razor','A',0), ('2','ghost','B',0)")
    res = g.run_turn([("razor", "Kaz, the chip.")])
    assert res.narration.startswith("Kaz slides the chip over. Ghost watches") and len(llm.dm_requests) == 2
    assert [n for n, _ in overreach('**Ghost:** "x" Ghost nods. Ghost says nothing. Ghost\'s coat.', ["Ghost"])] == \
        ["Ghost", "Ghost"]
    script2 = [([text('**Ghost:** "Mine."')], "end_turn"), ([text('**Ghost:** "Still mine."')], "end_turn")]
    g.llm.dm_script = script2
    res = g.run_turn([("razor", "Again.")])
    assert res.narration == '**Ghost:** "Still mine."'                  # one rewrite, never a loop
