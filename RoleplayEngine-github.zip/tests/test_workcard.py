"""The work card: while the GM works, one small message says where it's up to - then goes when the story posts."""
import asyncio
import threading
import time
from types import SimpleNamespace

from roleplay.discord_bot.session import CampaignTable
from roleplay.dm.turn import _tool_label
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool
from .test_discord import FakeChannel


class WorkChannel(FakeChannel):
    def __init__(self):
        super().__init__()
        self.work, self.dropped = [], []

    async def work_card(self, ref, text):
        self.work.append(text)
        return ref or f"card{len(self.work)}"

    async def drop_turn_card(self, ref):
        self.dropped.append((ref, len(self.sent)))


def test_the_steps_read_plainly_and_never_name_a_newcomer(make_game):
    g = make_game()
    setup_demo(g)
    roll = SimpleNamespace(name="request_test", input={"actor_id": "razor", "skill": "negotiation"})
    assert _tool_label(g, roll) == "🎲 rolling Negotiation for Razor"
    assert _tool_label(g, SimpleNamespace(name="cast", input={"caster_id": "ghost", "spell": "manabolt"})) == \
        "✨ Ghost casts Manabolt"
    assert _tool_label(g, SimpleNamespace(name="introduce", input={"name": "Mr. Johnson"})) == "👤 bringing someone in"
    assert _tool_label(g, SimpleNamespace(name="update_art", input={})) == "🛠️ checking the rules"


def test_the_card_follows_the_turn_and_goes_before_the_story(make_game):
    script = [([tool("request_test", actor_id="razor", skill="negotiation", threshold=2, reason="ask for a buyer")],
               "tool_use"),
              ([text("**Kaz:** \"Tanaka.\" What do you do?")], "end_turn")]
    extraction = {"summary": "Razor asked Kaz for a buyer.", "recalled": [], "facts": [], "told": [],
                  "new_entities": [], "moved_to": {"location": "", "description": "", "who": []},
                  "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"}]}
    g = make_game(FakeLLM(script, extraction))
    setup_demo(g)
    gate = threading.Event()
    real = g.run_turn

    def slow_turn(inputs, private=None):             # a GM that takes its time after the roll
        g.progress("🧠 thinking it over", "think")
        gate.wait(10)
        return real(inputs, private)
    g.run_turn = slow_turn

    async def go():
        ch = WorkChannel()
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 0.2, "cap": 2, "grace": 0.05})
        await t.refresh()

        async def react(e):
            pass
        await t.handle("2", "Alice", "!join razor", False, react)
        await t.handle("2", "Alice", "Kaz, who buys Renraku data?", False, react)
        for _ in range(100):
            await asyncio.sleep(0.05)
            if len(ch.work) >= 2:
                break
        assert ch.work[0].startswith("⏳ **The GM is on it**  ·  started <t:") and "reading your moves" in ch.work[0]
        assert "✓ reading your moves" in ch.work[-1] and "thinking it over" in ch.work[-1]   # it moved on
        gate.set()
        for _ in range(100):
            await asyncio.sleep(0.05)
            if any("Tanaka" in (m["description"] or "") for m in ch.sent) and ch.dropped:
                break
        story_at = next(i for i, m in enumerate(ch.sent) if "Tanaka" in (m["description"] or ""))
        assert ch.dropped and ch.dropped[0][1] <= story_at                                  # gone before the story
        await t.close()
    asyncio.run(go())


def test_no_card_without_a_turn(make_game):
    g = make_game()
    setup_demo(g)

    async def go():
        ch = WorkChannel()
        t = CampaignTable(g, ch, owner_id="1")
        g.progress("📝 writing it into the story's memory", "memory")      # (a whisper, or nothing at all)
        await asyncio.sleep(0.1)
        assert ch.work == [] and t._work is None
        await t.close()
    asyncio.run(go())


def test_the_gms_stream_says_when_it_thinks_writes_and_reaches_for_a_rule():
    from roleplay.config import Models
    from roleplay.dm.llm import LLM
    ev = SimpleNamespace
    events = [ev(type="content_block_start", content_block=ev(type="thinking")),
              ev(type="content_block_start", content_block=ev(type="tool_use", name="request_test")),
              ev(type="content_block_start", content_block=ev(type="text"))]
    events += [ev(type="content_block_delta", delta=ev(type="text_delta", text="word " * 10)) for _ in range(6)]
    final = ev(content=[], stop_reason="end_turn", usage=None, model="fake")

    class Stream:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def __iter__(self):
            return iter(events)

        def get_final_message(self):
            return final
    client = ev(beta=ev(messages=ev(stream=lambda **kw: Stream())))
    llm = LLM(Models(), client=client)
    heard = []
    assert llm.dm_step([], [], [], progress=lambda kind, detail: heard.append((kind, detail))) is final
    assert heard[:3] == [("thinking", None), ("tool_call", "request_test"), ("writing", 0)]
    assert ("writing", 50) in heard and len(heard) < 10                    # every 25 words or so, not every token
