"""The turn divider: a slim strip after each GM answer, so the channel reads turn by turn."""
import asyncio

from PIL import Image

from roleplay import divider
from roleplay.discord_bot.session import CampaignTable
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text
from .test_discord import FakeChannel

EXTRACTION = {"summary": "Razor asked Kaz for a buyer.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []},
              "members": [{"id": "razor", "role": "actor"}, {"id": "kaz", "role": "target"}]}


class BannerChannel(FakeChannel):
    def __init__(self):
        super().__init__()
        self.banners = []

    async def banner(self, path):
        self.banners.append((path, len(self.sent)))


def test_the_strip_names_the_next_turn_the_time_and_the_place(make_game):
    g = make_game()
    setup_demo(g)
    n, when, where = divider.parts(g)
    assert n == g.turn_no() + 1 and when.startswith("Day ") and where
    out = divider.render(g, g.path.parent / "sheets" / "divider.png")
    img = Image.open(out)
    assert img.size == (divider.W, divider.H) and img.mode == "RGBA" and img.getpixel((2, 2))[3] == 0   # see-through
    assert divider.line(g).startswith(f"-# ━━━━━━━━  **TURN {n}**  ·  {when}  ·  {where}")


def _play(make_game, ch, before=()):
    g = make_game(FakeLLM([([text("**Kaz:** \"Tanaka.\" What do you do?")], "end_turn")], EXTRACTION))
    setup_demo(g)

    async def go():
        t = CampaignTable(g, ch, owner_id="1", timers={"quiet": 0.2, "cap": 2, "grace": 0.05})
        await t.refresh()

        async def react(e):
            pass
        for who, line in before:
            await t.handle(who, "X", line, who == "1", react)
        await t.handle("2", "Alice", "!join razor", False, react)
        await t.handle("2", "Alice", "Kaz, who buys Renraku data?", False, react)
        for _ in range(100):
            await asyncio.sleep(0.05)
            if any("Tanaka" in (m["description"] or "") for m in ch.sent) and not t.director.resolving:
                break
        await asyncio.sleep(0.2)
        await t.close()
    asyncio.run(go())
    return g


def test_after_the_story_the_next_turn_opens_under_a_strip(make_game):
    ch = BannerChannel()
    _play(make_game, ch)
    story_at = max(i for i, m in enumerate(ch.sent) if "Tanaka" in (m["description"] or ""))
    assert len(ch.banners) == 1 and ch.banners[0][1] > story_at                      # after the story
    assert ch.banners[0][0].endswith("_divider.png")


def test_a_line_without_pictures_and_none_when_off(make_game):
    ch = FakeChannel()                                       # (a channel that can't post a bare picture)
    _play(make_game, ch)
    assert any((m["text"] or "").startswith("-# ━━━━━━━━  **TURN 5**") for m in ch.sent)
    ch = BannerChannel()
    _play(make_game, ch, before=[("2", "!dividers off"), ("1", "!dividers off")])
    assert "That one's for the campaign owner." in [m["text"] for m in ch.sent]
    assert any("Turn dividers: **off**" in (m["text"] or "") for m in ch.sent) and ch.banners == []
    assert not any("━━━━" in (m["text"] or "") for m in ch.sent)
