"""Action Phases (DESIGN.md §6a, 2026-10-24): SR5 Initiative as the round's action budget - a hard limit, the table's
ruling - with Multiple Attacks, thrown weapons and the interrupt defenses. Quiet Lou is the live sheet: Reaction 7
(wired), Intuition 3, wired reflexes 1, Agility 7, Close Combat 6, Throwing 6, Athletics 6, Willpower 3."""
import asyncio

import pytest

from roleplay import charsheet, encounters, flags
from roleplay.discord_bot.render import classify
from roleplay.dm import calls
from roleplay.dm.tools import TurnContext, dispatch, run_tool
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError
from roleplay.engine.rules import machines, magic, sr_lite
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool
from .test_magic import _mage

SAM = dict(reaction=7, intuition=3, agility=7, strength=7, body=5, willpower=3, edge=3, close_combat=6, throwing=6,
           athletics=6, firearms=4)
KATANA = "quiet-lou-s-katana"


def _give(g, who, name, props, qty=1):
    iid = g.ledger.create_entity("item", name, name, tier=0, props=props, turn=1)
    g.ledger.give(who, iid, qty, {"loaded": props["ammo_capacity"]} if "ammo_capacity" in props else {})
    return iid


def _table(make_game, faces=None, llm=None):
    """The demo bar with Quiet Lou in it (a PC, like the live sheet) and Crows Biker Fenn, a ganger."""
    g = make_game(llm, dice=ScriptedDice(faces if faces is not None else [2] * 600))
    setup_demo(g)
    L = g.ledger
    sam = g.create_pc("Quiet Lou", "street_samurai", "quiet-lou", "the crew's street samurai", 1)
    for k, v in SAM.items():
        L.set_stat(sam, k, v)
    _give(g, sam, "Quiet Lou's Wired reflexes", {"augmentation": True, "essence": 2.0, "effect": "+1 Reaction"})
    _give(g, sam, "Quiet Lou's Combat knife", {"dv": 3, "ap": -1, "skill": "close_combat", "damage_type": "physical"})
    g.enter_scene([sam], 1)
    g.introduce("npc", "Crows Biker Fenn", "", "ganger", present=True, turn=1)
    return g, sam


def _fight(g, **bases):
    """A fight on, with this round's Initiative pinned: {id: base} (the dice are tested on their own)."""
    if not encounters.active(g):
        encounters.start(g, 1, hostile=["crows-biker-fenn"])
    enc = encounters.active(g)
    for eid, base in bases.items():
        r = encounters.row(g, enc, eid.replace("_", "-"))
        r.update(base=base, used=0, spent=0, defended=0, full=False, surprise=0, late=0, mid_bonus=0, flat=False)
    encounters.save(g, enc)
    return enc


def _row(g, eid):
    return next(j for j in encounters.active(g)["jump"] if j["id"] == eid)


# ── Initiative ──────────────────────────────────────────────────────────
def test_initiative_is_the_round_s_action_budget(make_game):
    """Every 10 points is an Action Phase (SR5 p. 159): Lou at 10 + 2D6 has 2 a round, 3 on 11+. Wounds take it off at
    once (p. 160); ware counts by its rating; never more than 5D6."""
    g, sam = _table(make_game)
    L = g.ledger
    assert sr_lite.initiative_rating(L, sam) == (10, 2, ["Reaction + Intuition", "Wired reflexes 1"])
    assert ("Initiative 10 + 2D6 (Reaction + Intuition; Wired reflexes 1) - each 10 is an Action Phase"
            in sr_lite.sheet(L, sam))
    card = next(f for f in charsheet.cards(g, sam)[0]["fields"] if f["name"] == "Initiative")["value"]
    assert card.startswith("**10** + 2D6 (Reaction + Intuition; Wired reflexes 1) · **Action Phases** 2-3 a round")
    g.dice = ScriptedDice([6, 6])
    row = encounters._new_row(g, L.require(sam))
    assert row["base"] == 22 and encounters.phases(g, row) == 3                  # 22, 12, 2: three passes
    g.dice = ScriptedDice([4, 3])
    row = encounters._new_row(g, L.require(sam))
    assert row["base"] == 17 and encounters.phases(g, row) == 2
    sable = _mage(g)                                                           # Magic's sheet: R 3, I 5, 1D6
    g.dice = ScriptedDice([1])
    assert encounters.phases(g, encounters._new_row(g, L.require(sable))) == 1    # 9: one action
    row = dict(row, base=12)
    assert encounters.phases(g, row) == 2
    L.set_stat(sam, "physical_damage", 6)                                      # -2 for wounds, at once
    assert encounters.score(g, row) == 10 and encounters.phases(g, row) == 1
    _give(g, "ghost", "Wired reflexes 2", {"augmentation": True})              # (no prop: the name's rating)
    assert sr_lite.initiative_dice(L, "ghost") == (2, ["Wired reflexes 2"])
    _give(g, "ghost", "Wired reflexes", {"augmentation": True, "rating": 3})
    L.set_stat("ghost", "spell_init_dice", 2)
    assert sr_lite.initiative_rating(L, "ghost")[1] == 5                         # 1 + 2 + 3 + 2, capped at 5D6


def test_drones_spirits_the_astral_and_the_matrix(make_game):
    """By what they're doing: a drone on its own Pilot x 2 + 4D6; jumped in, its rigger's cold-sim VR Initiative and the
    body gets none; remote, its rigger's actions - and nothing while the rigger is out. Astral Intuition x 2 + 2D6,
    hot-sim VR Intuition + Data Processing + 4D6."""
    g, sam = _table(make_game)
    L = g.ledger
    lynx, _ = g.introduce("drone", "Steel Lynx", "", model="steel lynx", present=True, turn=1)
    L.set_stat(lynx, "pilot", 3)
    assert sr_lite.initiative_rating(L, lynx)[:2] == (6, 4)
    g.dice = ScriptedDice([6, 6, 6, 6])
    row = encounters._new_row(g, L.require(lynx))
    assert row["base"] == 30 and encounters.phases(g, row) == 3
    _give(g, "ghost", "Control rig", {"control_rig": 2})
    roto = machines.build_machine(L, "Ghost's Roto-drone", "roto-drone", "ghost", 1)
    g.enter_scene([roto], 1)
    machines.set_control(L, 1, roto, "ghost", "jumped")
    assert sr_lite.initiative_rating(L, roto)[:2] == (9, 3)                    # Intuition 5 + deck 4, 3D6 cold-sim
    assert sr_lite.initiative_rating(L, "ghost")[:2] == (0, 0)                 # the limp body: none of its own
    sable = _mage(g)
    L.update_entity(sable, props={**L.get(sable)["props"], "astral": "projecting"})
    assert sr_lite.initiative_rating(L, sable)[:2] == (10, 2)                  # Intuition 5 x 2, 2D6
    machines.set_control(L, 1, roto, "ghost", "remote")
    L.update_entity("ghost", props={**L.get("ghost")["props"], "matrix": {"host": "h", "mode": "vr"}})
    assert sr_lite.initiative_rating(L, "ghost")[:2] == (9, 4)                 # hot-sim VR: 4D6
    L.update_entity("ghost", props={**L.get("ghost")["props"], "matrix": {}})
    assert sr_lite.initiative_rating(L, roto) == (0, 0, ["remote: on Ghost's actions"])
    _fight(g, ghost=14)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": roto, "target_id": "crows-biker-fenn", "reason": "the drone fires",
                                   "weapon_id": next(i["id"] for i in L.holdings(roto) if "dv" in i["props"])})
    assert "Action Simple: Fire Weapon - Ghost's action 1 of 2 this round (Initiative 14)" in out
    assert _row(g, "ghost")["used"] == 1                                       # (the rigger's action, not the drone's)
    L.set_stat("ghost", "stun_damage", 20)                                     # the rigger's out cold
    out = run_tool(ctx, tool("attack", attacker_id=roto, target_id="crows-biker-fenn", reason="again"))
    assert out["is_error"] and "does nothing until it's set autonomous" in out["content"]


# ── the budget ──────────────────────────────────────────────────────────
def test_an_action_past_the_budget_is_refused_before_anything_happens(make_game, tmp_path):
    """The hard limit: a 1-phase ganger's second attack is turned away with nothing spent - no damage, no round, no
    step toward the target, no dice, no row in tests - and files no bug. Live T171/T175: three full-pool attacks in a
    round the engine said held two."""
    g, sam = _table(make_game)
    L = g.ledger
    _fight(g, crows_biker_fenn=8)
    enc = encounters.active(g)
    encounters.set_zones(enc, [{"name": "bar"}, {"name": "door"}])
    enc["positions"]["crows-biker-fenn"] = "door"
    encounters.save(g, enc)
    ctx = TurnContext(g, 2, g.current_scene_id())
    gun = "crows-biker-fenn-s-cheap-pistol"
    dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": "razor", "weapon_id": gun, "reason": "shot"})
    assert _row(g, "crows-biker-fenn")["used"] == 1
    before = (L.stat("razor", "physical_damage"), L.stat("razor", "stun_damage"), L.item_state("crows-biker-fenn", gun),
              g.conn.execute("SELECT COUNT(*) FROM tests").fetchone()[0], len(g.dice.faces), len(L.events(2)))
    for args in ({"weapon_id": gun}, {"weapon_id": "crows-biker-fenn-s-knife"}):    # (the knife would close in)
        out = run_tool(ctx, tool("attack", attacker_id="crows-biker-fenn", target_id="razor", reason="again", **args))
        assert out["is_error"] and "no Action Phase left this round (Initiative 8: 1 action, used)" in out["content"]
        assert "carries into the next round" in out["content"] and "`more`" in out["content"]
    assert (L.stat("razor", "physical_damage"), L.stat("razor", "stun_damage"), L.item_state("crows-biker-fenn", gun),
            g.conn.execute("SELECT COUNT(*) FROM tests").fetchone()[0], len(g.dice.faces), len(L.events(2))) == before
    assert encounters.zone_of(encounters.active(g), "crows-biker-fenn") == "door"
    assert ctx.tool_errors == 0 and not flags.listing(tmp_path) and "crows-biker-fenn" in ctx.refused


def test_mopping_up_is_free_once_nobody_stands(make_game):
    """The table's house rule: finishing off the helpless costs no Action Phase once nobody stands against the
    attacker (live T170/T171/T175: 'kill the survivors'). Never against a player's character."""
    g, sam = _table(make_game)
    L = g.ledger
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    _fight(g, quiet_lou=17)
    encounters.note_attack(g, sam, "joey-two-knives", True)                   # Joey's hostile too
    _row(g, sam)
    enc = encounters.active(g)
    encounters.row(g, enc, sam)["used"] = 2                                   # Lou's spent his round
    encounters.save(g, enc)
    L.set_stat("crows-biker-fenn", "stun_damage", 10)                         # Fenn down, Joey up
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = run_tool(ctx, tool("attack", attacker_id=sam, target_id="crows-biker-fenn", weapon_id=KATANA, reason="cut"))
    assert out["is_error"] and "no Action Phase left" in out["content"]
    L.set_stat("joey-two-knives", "stun_damage", 10)                          # nobody stands: it's mopping up
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                   "reason": "makes sure"})
    assert "Action Complex: Melee Attack - mopping up, free" in out
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "joey-two-knives", "finish": True,
                                   "weapon_id": KATANA, "reason": "kill the survivors"})
    assert "finishes Joey Two-Knives" in out and "mopping up, free" in out and _row(g, sam)["used"] == 2
    _fight(g, crows_biker_fenn=8)                                             # an NPC on a downed runner: charged
    L.set_stat("crows-biker-fenn", "stun_damage", 0)
    L.set_stat("razor", "stun_damage", 12)
    for eid in ("quiet-lou", "ghost"):
        L.set_stat(eid, "stun_damage", 12)
    dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": "razor", "reason": "kicks him"})
    out = run_tool(ctx, tool("attack", attacker_id="crows-biker-fenn", target_id="razor", reason="again"))
    assert out["is_error"] and "no Action Phase left" in out["content"]


def test_a_whisper_spends_the_round_too(make_game):
    """A whisper during a fight is the same round - its attack spends an action; with no fight on, it opens none."""
    g, sam = _table(make_game)
    _fight(g, quiet_lou=17)
    whisper = TurnContext(g, 2, g.current_scene_id(), private=sam)
    dispatch(whisper, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                 "reason": "a quiet cut"})
    assert _row(g, sam)["used"] == 1
    g2, sam2 = _table(make_game)
    dispatch(TurnContext(g2, 2, g2.current_scene_id(), private=sam2), "attack",
             {"attacker_id": sam2, "target_id": "crows-biker-fenn", "weapon_id": KATANA, "reason": "a quiet cut"})
    assert encounters.active(g2) is None


def test_surprise_costs_ten_and_the_defense(make_game):
    """A failed surprise test: -10 Initiative (p. 192) - often the whole round - and no defense or interrupt until
    they act. The next round starts clean."""
    g, sam = _table(make_game, [1] * 600)                                      # every surprise test fails
    enc, card = encounters.start(g, 1, ambushers=["crows-biker-fenn"])
    kaz = _row(g, "kaz")
    assert kaz["flat"] and kaz["surprise"] == 10 and "caught flat-footed -10" in card
    assert encounters.score(g, kaz) == kaz["base"] - 10 and encounters.phases(g, kaz) == 0   # R 3 + I 4 + 1: 8 - 10
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = run_tool(ctx, tool("attack", attacker_id="kaz", target_id="crows-biker-fenn", reason="swings back"))
    assert out["is_error"] and "caught flat-footed: Initiative 8 - 10 = -2" in out["content"]
    parts, notes = encounters.defense_parts(g, "kaz", ["full"], True)
    assert not parts and "caught flat-footed - no interrupt before they act" in notes[0]
    encounters.roll_initiative(g, encounters.active(g), 3)
    assert _row(g, "kaz")["surprise"] == 0 and not _row(g, "kaz")["flat"]


def test_a_late_joiner_loses_ten_a_pass_gone(make_game):
    """Someone coming in after a pass is over rolls and loses 10 for each one (p. 160)."""
    g, sam = _table(make_game)
    _fight(g, quiet_lou=17)
    enc = encounters.active(g)
    encounters.row(g, enc, sam)["used"] = 2                                  # Lou's second action: pass 1 is over
    encounters.save(g, enc)
    g.introduce("npc", "Pastor Garvey", "", "ganger", present=True, turn=2)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "fight", {"action": "start", "hostile": ["pastor-garvey"],
                                  "positions": [{"id": "pastor-garvey", "zone": "The Lucky Shot"}]})
    assert _row(g, "pastor-garvey")["late"] == 10 and "came in late -10" in out


# ── Multiple Attacks ────────────────────────────────────────────────────
def test_multiple_attacks_split_one_pool(make_game):
    """One Action Phase, several strikes (SR5 p. 196): the pool is built once and split evenly - 13 is 5 / 4 / 4 -
    at most half the Close Combat 6; each strike is defended on its own, and each defense after the first since the
    defender acted is -1. Pushed Edge goes in before the split, one point for all."""
    g, sam = _table(make_game)
    L = g.ledger
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    _fight(g, quiet_lou=17)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                   "reason": "three cuts", "more": [{"target_id": "crows-biker-fenn"},
                                                                    {"target_id": "joey-two-knives"}]})
    assert out.startswith("[ROLL] Quiet Lou attacks 3 times with Quiet Lou's Katana (Close Combat + Agility) - "
                          "Multiple Attacks")
    assert "Pool   Agility 7 + Close Combat 6 = 13d6, split 5 / 4 / 4 (at most 3: half Close Combat 6)" in out
    assert "Action Complex: Melee Attack - action 1 of 2 this round (Initiative 17)" in out
    assert "Strike #2 vs Crows Biker Fenn" in out and "- Already defended 1 =" in out
    assert _row(g, sam)["used"] == 1 and len([e for e in L.events(2) if e["kind"] == "attack"]) == 3
    with pytest.raises(LedgerError, match="at most 3 attacks in one Action Phase"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                 "reason": "four", "more": [{"target_id": "crows-biker-fenn"}] * 3})
    enc = encounters.active(g)
    encounters.set_zones(enc, [{"name": "bar"}, {"name": "door"}])
    enc["positions"]["joey-two-knives"] = "door"
    encounters.save(g, enc)
    with pytest.raises(LedgerError, match="within reach of each other"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                 "reason": "two zones", "more": [{"target_id": "joey-two-knives"}]})
    L.set_stat(sam, "close_combat", 5)
    assert sr_lite.max_strikes(L, sam, "close_combat") == (3, 5)                # half of 5, rounded up (p. 48)
    L.set_stat(sam, "close_combat", 6)
    out = run_tool(ctx, tool("attack", attacker_id=sam, target_id="crows-biker-fenn", weapon_id=KATANA,
                             reason="two more", more=[{"target_id": "crows-biker-fenn"}]))
    assert not out.get("is_error") and {sam, "crows-biker-fenn"} <= ctx.rolled      # (a further strike's dodge too)
    _fight(g, quiet_lou=17)
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                   "reason": "pushed", "edge": "push", "more": [{"target_id": "crows-biker-fenn"}]})
    assert "Edge, pushed - 6s explode (2 left) 3 = 16d6, split 8 / 8" in out and L.stat(sam, "edge_points") == 2


def test_two_weapons_and_the_one_shot_a_gun_gets(make_game):
    """A gun fires once a phase - two shots need a gun in each hand (p. 165), -2 off-hand on the whole pool (p. 178)
    and a round from each; two blades put the -2 on the off hand's strikes only (p. 187). Firearms 2 makes one strike;
    an empty second gun stops the call before any round is spent."""
    g, sam = _table(make_game)
    L = g.ledger
    _fight(g, quiet_lou=17)
    ctx = TurnContext(g, 2, g.current_scene_id())
    pred = "quiet-lou-s-ares-predator-v"
    hold = _give(g, sam, "Quiet Lou's Hold-out pistol", {"dv": 3, "skill": "firearms", "ammo_capacity": 6})
    with pytest.raises(LedgerError, match="a gun fires once a phase"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": pred,
                                 "reason": "double tap", "more": [{"target_id": "crows-biker-fenn"}]})
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": pred,
                                   "reason": "a gun in each hand", "more": [{"target_id": "crows-biker-fenn",
                                                                             "weapon_id": hold}]})
    assert "- Off-hand weapon 2 = " in out.split("Strike #1")[0]               # the whole pool
    assert L.item_state(sam, pred)["loaded"] == 14 and L.item_state(sam, hold)["loaded"] == 5
    assert "Ammo   Ares Predator V 14/15 · Hold-out pistol 5/6" in out
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                   "reason": "katana and knife", "more": [{"target_id": "crows-biker-fenn",
                                                                           "weapon_id": "quiet-lou-s-combat-knife"}]})
    first, second = out.split("Strike #2")
    assert "Off-hand" not in first and "Split share 6 - Off-hand weapon 2 = 4d6" in second
    _fight(g, quiet_lou=17)
    L.set_stat(sam, "firearms", 2)
    with pytest.raises(LedgerError, match="at most 1 attack in one Action Phase"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": pred,
                                 "reason": "two guns", "more": [{"target_id": "crows-biker-fenn", "weapon_id": hold}]})
    L.set_stat(sam, "firearms", 4)
    L.set_item_state(sam, hold, {"loaded": 0})
    with pytest.raises(LedgerError, match="Hold-out pistol is empty"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": pred,
                                 "reason": "two guns", "more": [{"target_id": "crows-biker-fenn", "weapon_id": hold}]})
    assert L.item_state(sam, pred)["loaded"] == 14 and _row(g, sam)["used"] == 0      # (nothing spent)


# ── thrown weapons ──────────────────────────────────────────────────────
def test_a_thrown_knife_leaves_the_hand(make_game):
    """thrown: Throwing + Agility at range - no closing in - and the blade lands in the room (live T172/T174: Lou's
    'throws' rolled Close Combat, walked him over, and the knife never left his hand). A fan of throws needs that many
    in hand and the target this zone or the next."""
    g, sam = _table(make_game)
    L = g.ledger
    knives = _give(g, sam, "Quiet Lou's Throwing knife", {"dv": 2, "ap": -1, "skill": "throwing",
                                                           "damage_type": "physical"}, qty=2)
    _fight(g, quiet_lou=17)
    enc = encounters.active(g)
    encounters.set_zones(enc, [{"name": "bar"}, {"name": "booths"}, {"name": "door"}])
    enc["positions"].update({sam: "bar", "crows-biker-fenn": "booths", "kaz": "door"})
    encounters.save(g, enc)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": knives,
                                   "thrown": True, "reason": "two knives", "more": [{"target_id": "crows-biker-fenn"}]})
    assert "(Throwing + Agility) - Multiple Attacks" in out and "Agility 7 + Throwing 6 = 13d6, split 7 / 6" in out
    assert "Range: near (booths)" in out and "closes in" not in out
    assert "Action Simple: Throw Weapon" in out and "Thrown Throwing knife x2 now lie at The Lucky Shot" in out
    assert not L.holds(sam, knives) and L.holds("the-lucky-shot", knives)
    assert encounters.zone_of(encounters.active(g), sam) == "bar"
    with pytest.raises(LedgerError, match="has 1 Quiet Lou's Combat knife to throw - 2 throws named"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "thrown": True, "reason": "x",
                                 "weapon_id": "quiet-lou-s-combat-knife", "more": [{"target_id": "crows-biker-fenn"}]})
    L.give(sam, knives, 2)
    with pytest.raises(LedgerError, match="Short or Medium range only"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": knives,
                                 "thrown": True, "reason": "x", "more": [{"target_id": "kaz"}]})
    with pytest.raises(LedgerError, match="it's fired, not thrown"):
        dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "thrown": True, "reason": "x",
                                 "weapon_id": "quiet-lou-s-ares-predator-v"})
    nowhere = g.new_scene("A rooftop", None, [sam, "crows-biker-fenn"], 3)       # no place on file: it stays put
    ctx = TurnContext(g, 3, nowhere)
    out = dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": knives,
                                   "thrown": True, "reason": "one more"})
    assert "no place on file for it to land - it stays on Quiet Lou's sheet" in out and L.holds(sam, knives)


# ── defenses ────────────────────────────────────────────────────────────
def test_parry_block_dodge_and_full_defense(make_game):
    """Interrupts paid from Initiative (p. 168, 188): parry +Close Combat for 5 (a blade in hand), block the same
    empty-handed, dodge +Athletics - melee only; full defense +Willpower for the rest of the round, 10, against
    anything, free once it's on. Only with the score left; a machine can't."""
    g, sam = _table(make_game)
    L = g.ledger
    _fight(g, quiet_lou=17, crows_biker_fenn=8)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": sam, "reason": "a stab",
                                   "weapon_id": "crows-biker-fenn-s-knife", "defense": ["parry"]})
    assert "Parry (Close Combat) 6" in out and "Parry: Initiative 17 -> 12 (2 actions this round, 0 used)" in out
    assert encounters.phases(g, _row(g, sam)) == 2
    _fight(g, crows_biker_fenn=8)
    out = dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": sam, "reason": "a shot",
                                   "weapon_id": "crows-biker-fenn-s-cheap-pistol", "defense": ["parry", "dodge"]})
    assert "Parry: only against melee - plain defense" in out and "one of parry, block or dodge" in out
    assert encounters.score(g, _row(g, sam)) == 12                                  # (nothing paid)
    bouncer, _ = g.introduce("npc", "Bouncer", "", "civilian", present=True, turn=1)
    L.set_stat(bouncer, "close_combat", 3)
    _fight(g, bouncer=12, crows_biker_fenn=8)
    parts, notes = encounters.defense_parts(g, bouncer, ["parry"], True)
    assert not parts and "no melee weapon in hand" in notes[0]
    parts, notes = encounters.defense_parts(g, bouncer, ["block"], True)
    assert parts[-1] == ("Block (Close Combat)", 3) and "Block: Initiative 12 -> 7" in notes[0]
    _fight(g, crows_biker_fenn=8)
    out = dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": sam, "reason": "a shot",
                                   "weapon_id": "crows-biker-fenn-s-cheap-pistol", "defense": ["full"]})
    assert "Full defense (Willpower) 3" in out and "Full defense: Initiative 12 -> 2" in out
    _fight(g, crows_biker_fenn=8)
    out = dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": sam, "reason": "again",
                                   "weapon_id": "crows-biker-fenn-s-cheap-pistol"})
    assert "Full defense (Willpower) 3" in out and "Full defense:" not in out        # on for the round, free
    sable = _mage(g)
    g.enter_scene([sable], 1)
    _fight(g, **{sable: 7})
    parts, notes = encounters.defense_parts(g, sable, ["full"], False)
    assert notes == ["Full defense: needs 10 Initiative, Sable has 7 - plain defense"]
    dog, _ = g.introduce("drone", "Doberman", "", model="doberman", present=True, turn=1)
    _fight(g, **{dog: 20})
    parts, notes = encounters.defense_parts(g, dog, ["full"], True)
    assert "is a machine - no interrupts" in notes[0]


def test_the_score_left_this_pass_pays_for_an_interrupt(make_game):
    """An interrupt needs 'enough Initiative Score left' (p. 167-168) - in the pass it happens in: Lou at 17 who has
    used both his actions is in his second pass with 7 left - no full defense, but a parry (7 -> 2). A parry that
    drops 12 to 7 leaves one action."""
    g, sam = _table(make_game)
    _fight(g, quiet_lou=17)
    enc = encounters.active(g)
    encounters.row(g, enc, sam)["used"] = 2
    encounters.save(g, enc)
    parts, notes = encounters.defense_parts(g, sam, ["full", "parry"], True)
    assert notes[0] == "Full defense: needs 10 Initiative, Quiet Lou has 7 - plain defense"
    assert ("Parry (Close Combat)", 6) in parts and "Parry: Initiative 17 -> 12" in notes[1]
    _fight(g, quiet_lou=17)
    parts, notes = encounters.defense_parts(g, sam, ["full"], False, now_pass=2)     # the attacker's 2nd phase
    assert "needs 10 Initiative, Quiet Lou has 7" in notes[0]
    _fight(g, quiet_lou=12)
    encounters.defense_parts(g, sam, ["parry"], True)
    ctx = TurnContext(g, 2, g.current_scene_id())
    dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn", "weapon_id": KATANA, "reason": "one"})
    out = run_tool(ctx, tool("attack", attacker_id=sam, target_id="crows-biker-fenn", weapon_id=KATANA, reason="two"))
    assert out["is_error"] and "(Initiative 7: 1 action, used)" in out["content"]


def test_defense_wears_down_and_starts_over(make_game):
    """-1 for each defense since the defender last acted (p. 189): none, -1, -2; their own action resets it, and so does
    a new round. The unaware get no defense test, so it doesn't count."""
    g, sam = _table(make_game)
    _fight(g, quiet_lou=17, razor=14, ghost=14, crows_biker_fenn=8)
    ctx = TurnContext(g, 2, g.current_scene_id())
    cards = [dispatch(ctx, "attack", {"attacker_id": who, "target_id": "crows-biker-fenn", "reason": "x"})
             for who in (sam, "razor", "ghost")]
    assert "Already defended" not in cards[0] and "- Already defended 1 =" in cards[1]
    assert "- Already defended 2 =" in cards[2]
    dispatch(ctx, "attack", {"attacker_id": "crows-biker-fenn", "target_id": "razor", "reason": "hits back"})
    assert "Already defended" not in dispatch(ctx, "attack", {"attacker_id": sam, "target_id": "crows-biker-fenn",
                                                             "reason": "y"})
    dispatch(ctx, "attack", {"attacker_id": "razor", "target_id": "crows-biker-fenn", "reason": "from behind",
                             "unaware": True})
    assert _row(g, "crows-biker-fenn")["defended"] == 1                         # (the unaware one didn't count)
    encounters.roll_initiative(g, encounters.active(g), 3)
    assert all(not j.get("defended") and not j.get("used") and not j.get("full") for j in encounters.active(g)["jump"])


# ── the round in the turn ───────────────────────────────────────────────
EXTRACTION = {"summary": "Lou cut at Fenn.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []},
              "members": [{"id": "quiet-lou", "role": "actor"}, {"id": "crows-biker-fenn", "role": "target"}]}


def test_a_new_round_is_rolled_once_the_fight_goes_on(make_game):
    """commit rolls the next round's Initiative only once it knows the fight goes on - an ending fight rolls nothing
    (live: rolled inside step, every fight that ended still spent dice and logged a round nobody played). The table
    gets one [INITIATIVE] line after the map; the GM's tool result shows the budget the turn a fight opens."""
    script = [([tool("attack", attacker_id="quiet-lou", target_id="crows-biker-fenn", weapon_id=KATANA,
                     reason="opens up")], "tool_use"),
              ([text("Lou's katana flashes.")], "end_turn")]
    g, sam = _table(make_game, llm=FakeLLM(script, {**EXTRACTION, "combat": {"moves": [], "zones": [], "over": False,
                                                                              "how": ""}}))
    res = g.run_turn([("quiet-lou", "Lou cuts at Fenn.")])
    assert res.cards[0].startswith("[FIGHT] Initiative (each 10 is an Action Phase")
    assert "Action Complex: Melee Attack - action 1 of" in res.cards[1]
    enc = encounters.active(g)
    assert enc["round"] == 1 and all(not j.get("used") for j in enc["jump"])     # a fresh round 2
    rolled = [e for e in g.ledger.events(res.turn_id) if e["kind"] == "initiative"]
    assert len(rolled) == 1 and rolled[0]["payload"]["round"] == 2
    card = encounters.initiative_card(g, enc)
    assert card.startswith("[INITIATIVE] Round 2: ") and classify(card) == "card" and classify("[FIGHT] x") == "card"

    from .test_discord import FakeChannel
    from roleplay.discord_bot.session import CampaignTable

    async def post():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="1")
        await t._post_initiative(res.turn_id)
        await t._post_initiative(res.turn_id - 1)                               # (no new round that turn: nothing)
        await t.close()
        return ch.sent
    sent = asyncio.run(post())
    assert len(sent) == 1 and "[INITIATIVE]" in sent[0]["text"] and " Round 2: Quiet Lou" in sent[0]["text"]
    script = [([tool("attack", attacker_id="quiet-lou", target_id="crows-biker-fenn", weapon_id=KATANA,
                     reason="ends it")], "tool_use"),
              ([text("Fenn drops.\n<dm>\nbattle end: Fenn went down\n</dm>")], "end_turn")]
    g2, _ = _table(make_game, llm=FakeLLM(script, EXTRACTION))
    res = g2.run_turn([("quiet-lou", "Lou finishes it.")])
    assert encounters.active(g2) is None
    assert not [e for e in g2.ledger.events(res.turn_id) if e["kind"] == "initiative"]


def test_a_phase_spent_is_the_round_under_way(make_game):
    """Review: a fight opened with Sable's Armor spell - an Action Phase spent, no blow struck - wasn't stepped, so the
    next turn's packet said 'round 1 - narrate the opening beat' again with her phase still used, and her second
    Stunbolt was refused in a round the GM had every reason to think was fresh."""
    script = [([tool("fight", action="start", hostile=["crows-biker-fenn"]),
                tool("cast", caster_id="sable", spell="Armor", force=3, targets=[{"id": "sable"}], reason="shield")],
               "tool_use"),
              ([text("Sable's skin shimmers as Fenn draws.")], "end_turn")]
    g, sam = _table(make_game, faces=[4] * 800, llm=FakeLLM(script, {**EXTRACTION, "combat": {"over": False}}))
    sable = _mage(g)
    g.enter_scene([sable], 1)
    res = g.run_turn([("sable", "I put up Armor as Fenn comes in.")])
    enc = encounters.active(g)
    assert enc["round"] == 1 and not _row(g, sable)["used"]                   # round 1 was played: a fresh round 2
    assert [e["payload"]["round"] for e in g.ledger.events(res.turn_id) if e["kind"] == "initiative"] == [2]
    assert "Initiative, round 2 (" in encounters.initiative_line(g, enc)


def test_the_fight_tool_shows_the_gm_the_budget(make_game):
    """Live: the fight tool's result carried the zones alone (packet_lines[1:3]); an attack that opened a fight
    returned just the attack card - the GM never saw the round's budget the turn a fight began."""
    g, sam = _table(make_game)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "fight", {"action": "start", "hostile": ["crows-biker-fenn"]})
    assert "Initiative, round 1 - narrate the opening beat in this order" in out and "Quiet Lou" in out
    g2, sam2 = _table(make_game)
    ctx = TurnContext(g2, 2, g2.current_scene_id())
    out = dispatch(ctx, "attack", {"attacker_id": sam2, "target_id": "crows-biker-fenn", "weapon_id": KATANA,
                                   "reason": "first blood"})
    assert out.startswith("[FIGHT] Initiative") and "\n[ROLL] Quiet Lou attacks" in out
    sable = _mage(g2)                                                          # (live T175: a Manabolt opened it)
    g2.enter_scene([sable], 1)
    encounters.end(g2, encounters.active(g2), 2, "reset", reflect=False)
    out = dispatch(ctx, "cast", {"caster_id": sable, "spell": "Stunbolt", "force": 3,
                                 "targets": [{"id": "crows-biker-fenn"}]})
    assert out.startswith("[FIGHT] Initiative") and "Action Complex: Cast Spell - action 1 of" in out


def test_a_refused_roll_does_not_loop_the_roll_guard(make_game, tmp_path):
    """A player called a roll and the engine turned it away for want of an Action Phase: the guard counts it answered
    instead of sending the GM back into the same refusal."""
    script = [([tool("attack", attacker_id="razor", target_id="crows-biker-fenn", weapon_id="razor-s-katana",
                     reason="a third cut")], "tool_use"),
              ([text("Razor's out of time this round - next one.")], "end_turn")]
    g, sam = _table(make_game, llm=FakeLLM(script, {**EXTRACTION, "members": [{"id": "razor", "role": "actor"}]}))
    _fight(g, razor=14)
    enc = encounters.active(g)
    encounters.row(g, enc, "razor")["used"] = 2
    encounters.save(g, enc)
    res = g.run_turn([("razor", "Razor rolls to cut Fenn again.")])
    assert res.narration.startswith("Razor's out of time") and len(g.llm.dm_requests) == 2
    assert not any(f["kind"] == "skipped a roll" for f in flags.listing(tmp_path))   # (rows have 'kind', not 'what')


# ── spells ──────────────────────────────────────────────────────────────
def test_a_split_spell_and_one_action_a_cast(make_game):
    """Casting Multiple Spells (p. 281): the pool split between the targets, each its own roll, Force limit,
    resistance and drain, at most Magic of them - one action (live T65: one unsplit roll hit both). Held spells go at
    one target a cast, and say so."""
    g, sam = _table(make_game)
    L = g.ledger
    sable = _mage(g)
    g.enter_scene([sable], 1)
    _fight(g, **{sable: 9})
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "cast", {"caster_id": sable, "spell": "Manabolt", "force": 4,
                                 "targets": [{"id": "crows-biker-fenn"}, {"id": "kaz"}]})
    assert "casts Manabolt at Force 4 at 2 targets - 14d6 split 7 / 7, each its own drain" in out
    assert out.count("  Cast   Split share 7") == 2 and out.count("  Drain  ") == 2
    assert "Action Complex: Cast Spell - action 1 of 1 this round (Initiative " in out    # (less the drain's wounds)
    assert len([e for e in L.events(2) if e["kind"] == "cast"]) == 2
    out = run_tool(ctx, tool("cast", caster_id=sable, spell="Stunbolt", force=3, targets=[{"id": "kaz"}]))
    assert out["is_error"] and "no Action Phase left" in out["content"]
    with pytest.raises(LedgerError, match="at most 6 spells at once"):
        magic.check_cast(L, sable, "Manabolt", [{"id": "kaz"}] * 7)
    L.update_entity(sable, props={**L.get(sable)["props"],
                                  "spells": list(L.get(sable)["props"]["spells"]) + ["confusion"]})
    with pytest.raises(LedgerError, match="Confusion goes at one target a cast - 2 named"):
        magic.check_cast(L, sable, "Confusion", [{"id": "kaz"}, {"id": "razor"}])
    res = magic.cast(L, g.dice, 3, sable, "Fireball", 3, [{"id": "kaz", "range": "close"}, {"id": "razor"}])
    assert res["card"].count("  Cast   ") == 1                                  # an area spell: one roll


def test_increase_reflexes_counts_this_round(make_game):
    """Increase Reflexes: +1 Initiative a hit and a die every 2 (p. 288) - cast mid-fight, at once (p. 160); dropped,
    the stats go."""
    g, sam = _table(make_game, [6] * 40 + [2] * 400)
    L = g.ledger
    sable = _mage(g)
    g.enter_scene([sable], 1)
    L.update_entity(sable, props={**L.get(sable)["props"],
                                  "spells": list(L.get(sable)["props"]["spells"]) + ["increase reflexes"]})
    _fight(g, razor=9, **{sable: 12})
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = dispatch(ctx, "cast", {"caster_id": sable, "spell": "Increase Reflexes", "force": 4, "targets": [{"id": "razor"}]})
    assert L.stat("razor", "spell_init_bonus") == 4 and L.stat("razor", "spell_init_dice") == 2
    row = _row(g, "razor")
    assert row["mid_bonus"] >= 4 + 2 and encounters.phases(g, row) >= 2          # +4 and 2 new dice, this round
    assert "Initiative Razor 9 -> " in out
    dispatch(ctx, "end_spell", {"caster_id": sable, "spell": "Increase Reflexes"})
    assert L.stat("razor", "spell_init_bonus") == 0 and L.stat("razor", "spell_init_dice") == 0


# ── the review's fixes (2026-10-24) ─────────────────────────────────────
def _roto(g, mode="remote"):
    """Ghost's Roto-drone, its gun on a mount, under his control (he has a control rig to jump in with)."""
    L = g.ledger
    _give(g, "ghost", "Control rig", {"control_rig": 2})
    roto = machines.build_machine(L, "Ghost's Roto-drone", "roto-drone", "ghost", 1)
    g.enter_scene([roto], 1)
    machines.set_control(L, 1, roto, "ghost", mode)
    return roto, next(i["id"] for i in L.holdings(roto) if "dv" in i["props"])


def test_a_refused_npc_swing_leaves_the_pc_s_called_roll_guarded(make_game, tmp_path):
    """Review: Fenn, his one phase used, swung at Lou and was refused - and Lou, the target, went on ctx.refused with
    him, so Lou's player's own 'Lou rolls to cut Fenn down' was never made and nothing caught it. Only who was turned
    away counts as answered. (Since 2026-10-27 the GM is sent back calls.SEND_BACKS times; an attack is never the
    engine's to roll for it, so the miss is flagged.)"""
    script = [([tool("attack", attacker_id="crows-biker-fenn", target_id="quiet-lou",
                     weapon_id="crows-biker-fenn-s-knife", reason="Fenn swings again")], "tool_use"),
              ([text("Fenn is spent; Lou's blade sings.")], "end_turn"),
              ([text("Lou's blade sings.")], "end_turn")]
    g, sam = _table(make_game, llm=FakeLLM(script, EXTRACTION))
    _fight(g, crows_biker_fenn=8, quiet_lou=17)
    enc = encounters.active(g)
    encounters.row(g, enc, "crows-biker-fenn")["used"] = 1
    encounters.save(g, enc)
    g.run_turn([("quiet-lou", "Lou rolls to cut Fenn down.")])
    assert len(g.llm.dm_requests) == 2 + calls.SEND_BACKS                      # the guard sent the GM back
    assert [f["kind"] for f in flags.listing(tmp_path)] == ["called roll never made", "skipped a roll"]


def test_a_control_change_counts_this_round(make_game):
    """p. 160: Initiative that changes mid-round counts at once - control_drone retunes the rows (review: the drone
    kept its 0/0 'remote' row, so following the refusal's own advice - set it autonomous - was refused again all
    round, and so was a drone just jumped into, while the rigger's limp body kept its two actions)."""
    g, sam = _table(make_game, [3] * 2000)
    L = g.ledger
    roto, gun = _roto(g)
    _fight(g, ghost=14)
    ctx = TurnContext(g, 2, g.current_scene_id())
    ctx.posted = {"ghost"}
    L.set_stat("ghost", "stun_damage", 20)                                     # Ghost goes down mid-round
    out = run_tool(ctx, tool("attack", attacker_id=roto, target_id="crows-biker-fenn", weapon_id=gun, reason="fires"))
    assert out["is_error"] and "until it's set autonomous" in out["content"]
    out = dispatch(ctx, "control_drone", {"drone_id": roto, "controller_id": "autonomous"})
    assert "running on its own Pilot now\n  Initiative Ghost's Roto-drone 0 -> " in out
    out = dispatch(ctx, "attack", {"attacker_id": roto, "target_id": "crows-biker-fenn", "weapon_id": gun,
                                   "reason": "fires on its own"})
    assert "Action Simple: Fire Weapon - action 1 of " in out and _row(g, roto)["used"] == 1
    g2, _ = _table(make_game, [3] * 2000)                                      # jumping in mid-round
    roto2, gun2 = _roto(g2)
    _fight(g2, ghost=14)
    ctx = TurnContext(g2, 2, g2.current_scene_id())
    ctx.posted = {"ghost"}
    fire = {"attacker_id": roto2, "target_id": "crows-biker-fenn", "weapon_id": gun2, "reason": "fires"}
    assert "Ghost's action 1 of 2 this round (Initiative 14)" in dispatch(ctx, "attack", fire)     # remote first
    out = dispatch(ctx, "control_drone", {"drone_id": roto2, "controller_id": "ghost", "mode": "jumped"})
    assert "Initiative Ghost 14 -> none of their own this round (jumped into Ghost's Roto-drone" in out
    assert "Initiative Ghost's Roto-drone 0 -> 18 this round (+9, +3D6 rolled 3 3 3): 2 actions" in out
    assert "action 2 of 2 this round (Initiative 18)" in dispatch(ctx, "attack", fire)   # (the used one came along)
    out = run_tool(ctx, tool("attack", **fire))
    assert out["is_error"] and "(Initiative 18: 2 actions, both used)" in out["content"]
    out = run_tool(ctx, tool("attack", attacker_id="ghost", target_id="crows-biker-fenn", reason="the limp body"))
    assert out["is_error"] and "none of their own (jumped into" in out["content"]
    out = dispatch(ctx, "control_drone", {"drone_id": roto2, "controller_id": "ghost", "mode": "remote"})
    assert "Initiative Ghost's Roto-drone 18 -> none of their own this round (remote: on Ghost's actions)" in out
    ghost = _row(g2, "ghost")                                                  # out again: his own Initiative back,
    assert encounters.phases(g2, ghost) == 2 and ghost["used"] == 2           # and both actions still spent


def test_a_refused_action_opens_no_fight(make_game):
    """DESIGN §6a: an invalid attack starts nothing. Review: a remote drone whose rigger was out, and a jumped-in
    rigger's limp body, opened a fight - its [FIGHT] card went to the table - before the budget refused them; so did
    a ram, and a split bolt the dice couldn't cover. A refusal that's down to the fresh dice still leaves the fight on,
    and says so."""
    g, sam = _table(make_game)
    L = g.ledger
    roto, gun = _roto(g)
    L.set_stat("ghost", "stun_damage", 20)
    ctx = TurnContext(g, 2, g.current_scene_id())
    calls = [tool("attack", attacker_id=roto, target_id="crows-biker-fenn", weapon_id=gun, reason="fires"),
             tool("crash", vehicle_id=roto, into_id="crows-biker-fenn", speed_kph=40, reason="rams")]
    for call in calls:
        out = run_tool(ctx, call)
        assert out["is_error"] and "Ghost is unconscious" in out["content"]
    L.set_stat("ghost", "stun_damage", 0)
    machines.set_control(L, 1, roto, "ghost", "jumped")
    out = run_tool(ctx, tool("attack", attacker_id="ghost", target_id="crows-biker-fenn", reason="punch"))
    assert out["is_error"] and "none of their own (jumped into Ghost's Roto-drone" in out["content"]
    sable = _mage(g)
    g.enter_scene([sable], 1)
    for k, v in (("magic", 2), ("sorcery", 1), ("sustaining", 2)):            # two held spells, -4: under a die each
        L.set_stat(sable, k, v)
    out = run_tool(ctx, tool("cast", caster_id=sable, spell="Manabolt", force=1,
                             targets=[{"id": "crows-biker-fenn"}, {"id": "kaz"}]))
    assert out["is_error"] and "1 dice can't split 2 ways" in out["content"]
    assert encounters.active(g) is None and not ctx.cards and not [e for e in L.events(2) if e["kind"] == "fight_start"]
    assert ctx.refused == {roto, "ghost"}
    g2, _ = _table(make_game, [1] * 600)                                       # the dice leave Fenn no phase
    for k in ("reaction", "intuition"):
        g2.ledger.set_stat("crows-biker-fenn", k, 1)
    g2.ledger.set_stat("crows-biker-fenn", "stun_damage", 6)                   # -2 for wounds: 1 + 1 + 1 - 2 = 1 ...
    g2.ledger.set_stat("crows-biker-fenn", "physical_damage", 3)               # ... -3: 0
    ctx = TurnContext(g2, 2, g2.current_scene_id())
    out = run_tool(ctx, tool("attack", attacker_id="crows-biker-fenn", target_id="razor", reason="lunges"))
    assert out["is_error"] and "no Action Phase left" in out["content"]
    assert "the attempt started it:)\n[FIGHT] Initiative" in out["content"] and encounters.active(g2)


def test_an_offsite_rigger_rolls_with_the_fight(make_game):
    """Ghost runs his Roto-drone from the van: the drone is in the fight, he isn't on its map. Review: he got no row,
    was rolled the first time the drone fired - 'late', -10 a pass gone - and dropped at every new round. Now he
    rolls with everyone, at the start and each round, and is on the card."""
    g, sam = _table(make_game, [3] * 2000)
    L = g.ledger
    roto, gun = _roto(g)
    g.leave_scene(["ghost"], g.current_scene_id())
    enc, card = encounters.start(g, 1, hostile=["crows-biker-fenn"])
    assert "ghost" not in enc["positions"] and "Ghost 12 (2 actions)" in card
    for rnd in (2, 3):
        enc = encounters.active(g)
        encounters.row(g, enc, sam)["used"] = 2                               # pass 1 is over
        encounters.save(g, enc)
        ctx = TurnContext(g, rnd, g.current_scene_id())
        out = dispatch(ctx, "attack", {"attacker_id": roto, "target_id": "crows-biker-fenn", "weapon_id": gun,
                                       "reason": "fires"})
        assert "Ghost's action 1 of 2 this round (Initiative 12)" in out and not _row(g, "ghost")["late"]
        encounters.roll_initiative(g, encounters.active(g), rnd)
        assert "Ghost 12 (2 actions)" in encounters.initiative_card(g, encounters.active(g))


def test_a_bad_edge_or_no_edge_stops_the_attack_before_anything(make_game):
    """plan_strikes checks every strike's Edge and the attacker's push before a round, a die or a blow. Review: a bad
    soak_edge on the second strike raised after the first had landed (damage on the ledger, no card, no action - a
    retry struck twice); a push with no Edge points left took a round from both guns first."""
    g, sam = _table(make_game, [6] * 600)
    L = g.ledger
    g.introduce("npc", "Joey Two-Knives", "", "ganger", present=True, turn=1)
    _fight(g, quiet_lou=17)
    ctx = TurnContext(g, 2, g.current_scene_id())
    out = run_tool(ctx, tool("attack", attacker_id=sam, target_id="crows-biker-fenn", weapon_id=KATANA, reason="two",
                             more=[{"target_id": "joey-two-knives", "soak_edge": "if it hurts"}]))
    assert out["is_error"] and "Edge is spent as one of" in out["content"]
    pred = "quiet-lou-s-ares-predator-v"
    hold = _give(g, sam, "Quiet Lou's Hold-out pistol", {"dv": 3, "skill": "firearms", "ammo_capacity": 6})
    L.set_stat(sam, "edge_points", 0)
    out = run_tool(ctx, tool("attack", attacker_id=sam, target_id="crows-biker-fenn", weapon_id=pred, edge="push",
                             reason="two guns, pushed", more=[{"target_id": "crows-biker-fenn", "weapon_id": hold}]))
    assert out["is_error"] and "no Edge points left this session" in out["content"]
    assert (L.stat("crows-biker-fenn", "physical_damage"), L.stat("crows-biker-fenn", "stun_damage")) == (0, 0)
    assert L.item_state(sam, pred)["loaded"] == 15 and L.item_state(sam, hold)["loaded"] == 6
    assert not L.events(2) and _row(g, sam)["used"] == 0
    assert g.conn.execute("SELECT COUNT(*) FROM tests").fetchone()[0] == 0


def test_only_fighters_get_an_initiative_row(make_game):
    """Review: a katana on a steel door gave the door a row - 'Steel door 2 (1 action)' on the map's footer and in
    the GM's Initiative line for the rest of the round. Things have no Initiative."""
    g, sam = _table(make_game)
    L = g.ledger
    _fight(g, quiet_lou=17)
    door = L.create_entity("item", "Steel door", "steel-door", tier=0, props={}, turn=1)
    L.give("the-lucky-shot", door, 1, {})
    out = dispatch(TurnContext(g, 2, g.current_scene_id()), "attack", {"attacker_id": sam, "target_id": door,
                                                                       "weapon_id": KATANA, "reason": "hacks at it"})
    assert "Action Complex: Melee Attack - action 1 of 2" in out
    enc = encounters.active(g)
    assert door not in [j["id"] for j in enc["jump"]] and "Steel door" not in encounters.summary(g, enc)
    assert encounters.defense_parts(g, door, ["full"]) == ([], ["Steel door isn't in the fight's Initiative - plain "
                                                                "defense"])


def test_an_opening_turn_s_action_is_round_one(make_game):
    """Review: the GM opened the fight (fight start, as the prompt says, before the first blow) while Sable cast
    Increase Reflexes on Lou - no blow struck, so the turn wasn't a round, and at T+1 her Manabolt was refused 'no
    Action Phase left' in a round that never happened. A phase spent, or Initiative paid for an interrupt, is the
    round under way."""
    script = [([tool("fight", action="start", hostile=["crows-biker-fenn"]),
                tool("cast", caster_id="sable", spell="Increase Reflexes", force=3, targets=[{"id": "quiet-lou"}])],
               "tool_use"),
              ([text("Sable's fingers trace a sigil; the Crows fan out.")], "end_turn"),
              ([tool("cast", caster_id="sable", spell="Manabolt", force=4, targets=[{"id": "crows-biker-fenn"}])],
               "tool_use"),
              ([text("Sable reaches for Fenn's mind.")], "end_turn")]
    g, sam = _table(make_game, [3] * 2000, FakeLLM(script, {**EXTRACTION, "combat": {"over": False}}))
    sable = _mage(g)
    g.enter_scene([sable], 1)
    L = g.ledger
    L.update_entity(sable, props={**L.get(sable)["props"], "spells": list(L.get(sable)["props"].get("spells") or [])
                                  + ["increase reflexes", "manabolt"]})
    g.run_turn([("sable", "Sable casts Increase Reflexes on Lou as the Crows roll in.")])
    assert encounters.active(g)["round"] == 1 and not _row(g, sable)["used"]
    res = g.run_turn([("sable", "Sable Manabolts Fenn.")])
    assert any(c.startswith("[ROLL] Sable casts Manabolt") for c in res.cards)
    enc = dict(encounters.active(g), started_turn=9, attacks=[], ending=None)
    enc["jump"] = [dict(j, used=0, spent=0) for j in enc["jump"]]
    assert encounters.opening(enc, 9)
    enc["jump"][0]["spent"] = 10                                               # a full defense paid, no blow yet
    assert not encounters.opening(enc, 9)



def test_combathelp_says_what_a_round_holds(make_game):
    """!combathelp (and /combathelp) - the table's card for the SR5 Action Phases, like !matrixhelp for hosts."""
    import asyncio
    from roleplay import encounters
    from roleplay.discord_bot.session import CampaignTable, combat_help_cards
    from roleplay.setup import setup_demo
    from .test_discord import FakeChannel
    g = make_game()
    setup_demo(g)
    assert any(line.startswith("**Initiative:**") for line in encounters.HELP)
    assert all(c["title"].startswith("⚔️ In a fight") for c in combat_help_cards(True))
    assert all(len(c["description"]) <= 4096 for c in combat_help_cards(True) + combat_help_cards(False))

    async def go():
        ch = FakeChannel()
        t = CampaignTable(g, ch, owner_id="9", timers={"quiet": 60, "cap": 60, "grace": 1})
        await t.refresh()

        async def react(e):
            pass
        for cmd in ("!combathelp", "!fighthelp"):
            n = len(ch.sent)
            await t.handle("1", "Alice", cmd, False, react)
            got = ch.sent[n:]
            assert got and got[0]["title"].startswith("⚔️ In a fight") and "Action Phase" in "".join(c["description"] for c in got)
        await t.close()
    asyncio.run(go())
