from roleplay.config import Knobs
from roleplay.substrate.physics import EnergyGraph, touch_all


def test_touch_mints_at_most_twice_the_quantum():
    # a chain a-b-c-d with equal strengths; everyone at energy 1
    g = EnergyGraph({n: 1.0 for n in "abcd"}, [(1, "a", "b", 1.0), (2, "b", "c", 1.0), (3, "c", "d", 1.0)])
    before = g.total
    stats = touch_all(g, Knobs(), ["a"])
    minted = g.total - before
    assert stats.origins == 1
    assert 1.0 <= minted <= 2.0 + 1e-9          # quantum = mean = 1.0; honest mint <= 2x
    assert g.energy["a"] > g.energy["b"] > g.energy["d"]
    assert g.touched == {"a": 1}                 # only the origin counts as a touch


def test_share_is_proportional_to_strength():
    g = EnergyGraph({"x": 1.0, "wide": 1.0, "narrow": 1.0}, [(1, "x", "wide", 9.0), (2, "x", "narrow", 1.0)])
    touch_all(g, Knobs(), ["x"])
    gained_wide, gained_narrow = g.deposited["wide"], g.deposited["narrow"]
    assert abs(gained_wide / gained_narrow - 9.0) < 0.5


def test_rule5_off_by_default_and_optional():
    g = EnergyGraph({"a": 1.0, "b": 1.0}, [(1, "a", "b", 1.0)])
    touch_all(g, Knobs(), ["a"])
    assert not g.carved
    g2 = EnergyGraph({"a": 1.0, "b": 1.0}, [(1, "a", "b", 1.0)])
    touch_all(g2, Knobs(traversal_carves=True), ["a"])
    assert g2.carved[1] >= 1.0


def test_born_at_mean_and_copresence_counts_once_per_scene(make_game):
    g = make_game()
    loc, _ = g.introduce("location", "Bar", "a bar")
    a = g.create_pc("A", "face", "a")
    b = g.create_pc("B", "decker", "b")
    s1 = g.new_scene("one", loc, [a, b], 1)
    g.enter_scene([a, b], 2, s1)                 # re-entering the same scene adds nothing
    link = [l for l in g.sub.links_of(a) if l["other"] == b][0]
    assert link["together"] == 1
    g.new_scene("two", loc, [a, b], 3)
    link = [l for l in g.sub.links_of(a) if l["other"] == b][0]
    assert link["together"] == 2
    mean = g.sub.system_mean()
    g.sub.create_node("F99", "fact", "x", 3)
    assert abs(g.sub.energy_of("F99") - mean) < 1e-9


def test_lift_beats_raw_count_for_hubs(make_game):
    g = make_game()
    pc = g.create_pc("Hero", "face", "hero")
    bar, _ = g.introduce("location", "Bar", "a bar")
    kaz, _ = g.introduce("npc", "Kaz", "barkeep", template="contact")
    tanaka, _ = g.introduce("npc", "Tanaka", "fence", template="contact")
    others = [g.introduce("npc", f"Mook {i}", "x")[0] for i in range(4)]
    t = 1
    for i in range(6):                           # the hero is everywhere
        extra = [others[i % 4]]
        if i < 2:
            extra += [kaz, tanaka]               # Tanaka only ever appears with Kaz
        g.new_scene(f"s{i}", bar, [pc] + extra, t)
        t += 1
    presence, total = g.ledger.presence_counts()
    assoc = g.sub.associations(kaz, presence, total, 5)
    assert assoc[0]["id"] in (tanaka,)           # rare companion outranks the omnipresent hero/bar


def test_notes_ride_their_target_and_have_no_energy(make_game):
    g = make_game()
    kaz, _ = g.introduce("npc", "Kaz", "barkeep", template="contact")
    g.sub.ensure_entity(g.ledger.get(kaz), 0)
    n1 = g.sub.add_note([kaz], "Kaz is loyal.", 2)
    n2 = g.sub.add_note([kaz], "Kaz is wavering.", 5)
    notes = g.sub.notes_for(kaz)
    assert [n["id"] for n in notes] == [n2, n1]  # newest first, contradictions both kept
    assert g.sub.energy_of(n1) == 0.0 and g.sub.node(n1)["visibility"] == "gm"
