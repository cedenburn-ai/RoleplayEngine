"""Every structured-output schema compiles on the real API, and the GM's tool list is accepted (opt-in: RUN_LIVE=1,
a few free 400s at worst, and a few cents for the one GM call).

The fake LLM in the other tests never sees a schema, so a schema the API refuses - "the compiled grammar is too
large" - would only show up live, as every turn's memory quietly falling back to a plain summary. The memory pass
sits near that limit (jobs got their own call because of it; its `contradictions` field, 2026-10-26, was checked
here). A broken tool schema is worse: every turn's GM call fails, and nobody finds out until the bot restarts onto it.
The canon's `doubts` and its conflicts' `sure` / `ids` ride the canon schema below. The research loops out of the
story (the aside's lookups beside its JSON answer, !askdm's witness tools) run for real at the end. Run this after
changing any schema or tool:

    RUN_LIVE=1 .venv/Scripts/python -m pytest -q tests/test_live_schemas.py
"""
import os

import pytest

from roleplay import chargen, jobs, recap
from roleplay import seed
from roleplay.dm import aside, calls, canon, frame, minds, pacing, prompts, world

pytestmark = pytest.mark.skipif(os.environ.get("RUN_LIVE") != "1", reason="live API check (RUN_LIVE=1)")

SCHEMAS = {
    "memory pass": prompts.commit_schema, "jobs (follow-up)": jobs.extract_schema, "jobs (backfill)": jobs.backfill_schema,
    "NPC minds": minds.reflect_schema, "recap": recap.schema, "chargen": chargen.suggest_schema,
    "world persona": world.persona_schema, "world faction": world.faction_schema, "world agent": world.agent_schema,
    "GM aside": aside.schema, "dossier": lambda: recap.PERSON, "pacing": pacing.schema, "canon": canon.schema, "frame": frame.schema,
    "called roll": calls.read_schema,
}
from roleplay import newparty  # noqa: E402  (a new party: the old crew's minds, 2026-10-27)
SCHEMAS["new party minds"] = newparty.mind_schema
# The story seed's read is three calls because one plan was past the grammar limit (seed.PARTS, 2026-10-27).
SCHEMAS.update({f"story seed ({part})": (lambda p=part: seed.plan_schema(p)) for part in seed.PARTS})
SCHEMAS["story seed (the opening fitted to the crew)"] = seed.adapt_schema


@pytest.mark.parametrize("name", list(SCHEMAS))
def test_the_api_accepts_the_schema(name):
    import anthropic
    from roleplay.dm.llm import ensure_api_key
    ensure_api_key()
    client = anthropic.Anthropic()
    try:
        client.messages.create(model="claude-haiku-5-5", max_tokens=1, system="x",
                               messages=[{"role": "user", "content": "{}"}],
                               output_config={"effort": "low", "format": {"type": "json_schema", "schema": SCHEMAS[name]()}})
    except anthropic.BadRequestError as exc:
        pytest.fail(f"{name}: {exc}")


def test_the_api_accepts_the_gms_tools():
    """The whole tool list, sent the way every turn sends it (LLM.dm_step: the GM's model, its betas and fallbacks,
    caching) - with a one-line message and a few output tokens, so it costs cents."""
    import anthropic
    from roleplay.config import Models
    from roleplay.dm.llm import LLM
    from roleplay.dm.tools import TOOLS
    assert {"doubt", "read_turn", "timeline"} <= {t["name"] for t in TOOLS}   # (the notebook and its margin, 2026-10-26)
    llm = LLM(Models(dm_max_tokens=16, dm_effort="low"))
    try:
        msg = llm.dm_step([{"type": "text", "text": "You are a game master. Reply in one word."}], TOOLS,
                          [{"role": "user", "content": "Say hi."}])
    except anthropic.BadRequestError as exc:
        pytest.fail(f"the GM's tools ({len(TOOLS)}): {exc}")
    assert msg.stop_reason in ("end_turn", "max_tokens", "tool_use", "refusal")


def test_the_api_takes_the_research_loops_out_of_the_story():
    """The aside's lookups with its JSON answer - structured output beside tools, and the last step's tools off
    (tool_choice none) - on the GM's model, and !askdm's witness tools on its model (research.consult, 2026-10-26). A
    real loop over a stub lookup, then the forced-answer call alone: a few cents. The fake LLM sees neither shape."""
    import json
    from types import SimpleNamespace

    import anthropic
    from roleplay.config import Models
    from roleplay.dm import research, witness
    from roleplay.dm.llm import LLM
    m = Models()
    game = SimpleNamespace(llm=LLM(m))

    def stub(block):
        return {"type": "tool_result", "tool_use_id": block.id,
                "content": "=== T33 ===\nRazor [razor] posted: Five hundred by Friday, deal?\nNarration (verbatim):\n"
                           "**Kaz:** \"Five hundred by Friday. Deal.\""}
    ask = ("Alice (plays Razor [razor]) SAYS TO YOU, OUT OF CHARACTER:\nHey DM, didn't Kaz agree to five hundred at "
           "T33? Check T33 with read_turn before you answer.")
    question = "QUESTION from alice: What did Kaz agree to at T33? Read T33 with read_turn first."
    runs = [("the aside", m.dm, aside.SYSTEM, ask, aside.LOOKUPS, aside.schema(), dict(fallback=m.commit)),
            ("!askdm", m.askdm, prompts.ASKDM_SYSTEM + prompts.ASKDM_RESEARCH.format(name="Razor"), question,
             witness.TOOLS, None, {})]
    for name, model, system, user, tools, schema, kw in runs:
        for steps in (1, 0):                             # (0: the tools-off answer, whatever the loop did)
            try:
                reply, stop, _ = research.consult(game, model, system, user, tools, stub, steps, schema,
                                                  max_tokens=3000, effort="low", purpose="other", **kw)
            except anthropic.BadRequestError as exc:
                pytest.fail(f"{name} (steps {steps}): {exc}")
            assert stop in ("end_turn", "max_tokens", "refusal"), (name, stop)
            if schema and stop == "end_turn":
                assert set(json.loads(reply)) == set(schema["required"]), reply      # (with `loop`, 2026-10-27)
            assert reply or stop != "end_turn", name
