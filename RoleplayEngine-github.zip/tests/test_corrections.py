"""GM corrections: when the GM and the table agree the numbers are wrong, the GM sets them right - before the round
rolls, visibly, and on the flag log."""
import pytest

from roleplay import flags
from roleplay.dm import aside, corrections
from roleplay.engine.dice import ScriptedDice
from roleplay.engine.ledger import LedgerError, RulesRefusal
from roleplay.engine.rules import matrix
from roleplay.setup import setup_demo

from .conftest import FakeLLM, text, tool

EXTRACTION = {"summary": "Ghost read the files.", "recalled": [], "facts": [], "told": [], "new_entities": [],
              "moved_to": {"location": "", "description": "", "who": []}, "members": [{"id": "ghost", "role": "actor"}]}


def _stuck_on_a_hot_host(g):
    """Ghost in a rating-6 host carrying what a retconned dive left: Overwatch 33, traced, a beaten-up deck, the
    host on alert with its IC up, and a trace hook waiting to land."""
    hid, _ = g.introduce("host", "KD-4 Host", "a hospital ward of masked orderlies", rating=6, turn=1)
    matrix.act(g.ledger, g.dice, 1, "ghost", "jack_in", hid, mode="vr")
    L = g.ledger
    st = matrix.state(L, "ghost")
    L.update_entity("ghost", props={**L.get("ghost")["props"],
                                    "matrix": {**st, "overwatch": 33, "traced": True, "deck_damage": 7}})
    hp = dict(L.get(hid)["props"])
    L.update_entity(hid, props={**hp, "alert": 2, "ic": [{**ic, "active": True} for ic in hp["ic"]]})
    from roleplay.dm import world
    hook = world.add_hook(g, hid, None, "KD-4 security traced Ghost's body", ["ghost"], 1)
    return hid, hook


def test_the_gm_corrects_before_the_round_rolls(make_game, tmp_path):
    llm = FakeLLM([([tool("correct", target_id="ghost", what="overwatch", value="0",
                         reason="the table retconned the last dive (F36)"),
                    tool("correct", target_id="kd-4-host", what="alert", value="0", reason="same retcon"),
                    tool("matrix", decker_id="ghost", action="search", reason="read Brask's charts")], "tool_use"),
                   ([text("The ward stays quiet while Ghost reads.")], "end_turn")], EXTRACTION)
    g = make_game(llm, dice=ScriptedDice([2] * 60))
    setup_demo(g)
    hid, _ = _stuck_on_a_hot_host(g)
    res = g.run_turn([("ghost", "I read her charts, carefully.")])
    fixes = [c for c in res.cards if c.startswith("[FIX]")]
    assert fixes == ["[FIX] Ghost: Overwatch 33 -> 0 - the table retconned the last dive (F36)",
                     "[FIX] KD-4 Host: alert alert -> quiet - same retcon"]
    assert res.cards.index(fixes[-1]) < next(i for i, c in enumerate(res.cards) if c.startswith("[MATRIX]"))
    assert matrix.state(g.ledger, "ghost")["overwatch"] < matrix.NOTICED          # rolled from 0, not 33
    assert [f["kind"] for f in flags.listing(tmp_path)][:2] == ["correction", "correction"]


def test_every_lever_and_its_guard_rails(make_game):
    g = make_game()
    setup_demo(g)
    hid, hook = _stuck_on_a_hot_host(g)
    C = corrections.correct
    assert C(g, 2, "ghost", "trace", "off", "retcon") == "[FIX] Ghost: not traced - the host lost their body - retcon"
    assert "deck damage 7 -> 0" in C(g, 2, "ghost", "deck", "0", "retcon")
    assert "IC stood down (5 active -> none)" in C(g, 2, hid, "ic", None, "retcon")
    assert C(g, 2, hook, "hook", "drop", "never happened").startswith(f"[FIX] {hook} dropped")
    assert "out of the Matrix, clean" in C(g, 2, "ghost", "jack out", None, "retcon")
    st, hp = matrix.state(g.ledger, "ghost"), g.ledger.get(hid)["props"]
    assert (st["host"], st["overwatch"], st["traced"], st["deck_damage"]) == (None, 0, False, 0)
    assert not any(ic["active"] for ic in hp["ic"])
    assert g.conn.execute("SELECT status FROM hooks WHERE id=?", (hook,)).fetchone()[0] == "stale"
    for args, msg in ((("ghost", "overwatch", "50", "x"), "Overwatch is 0 to 39"),
                      (("ghost", "overwatch", "0", ""), "say why"),
                      (("ghost", "alert", "0", "x"), "isn't a host"),
                      (("ghost", "jack_out", None, "x"), "isn't jacked in"),
                      ((hook, "hook", "drop", "x"), "already stale"),
                      (("ghost", "karma", "5", "x"), "what is one of")):
        with pytest.raises(LedgerError, match=msg):
            C(g, 2, *args)


def test_a_correction_that_changes_nothing_is_turned_away(make_game, tmp_path):
    """Flag #26 (T106): a fix setting Filament's Overwatch from 0 to 0 - the trace was long over in the story - posted a
    [FIX] card and a flag, and the trace it meant kept showing on every later host. A no-op is refused, saying
    what's there and which lever was meant - and the trace can be turned off."""
    g = make_game()
    setup_demo(g)
    hid, _ = _stuck_on_a_hot_host(g)
    C = corrections.correct
    C(g, 2, "ghost", "jack out", None, "retcon")                          # out: Overwatch 0, the host eased
    L = g.ledger
    L.update_entity("ghost", props={**L.get("ghost")["props"],          # (the live record: an old run's plain True)
                                    "matrix": {**matrix.state(L, "ghost"), "traced": True}})
    flagged = len(flags.listing(tmp_path))
    with pytest.raises(LedgerError, match=r"Overwatch is already 0 \(they're not in a run: the score dies with it\)\. "
                                          "A trace is its own lever: what=trace, value off"):
        C(g, 106, "ghost", "overwatch", "0", "offline now; the trace is over")
    assert len(flags.listing(tmp_path)) == flagged                       # no card, no flag
    assert C(g, 106, "ghost", "trace", "off", "the KD-4 trace landed at T106") == (
        "[FIX] Ghost: not traced - the host lost their body - the KD-4 trace landed at T106")
    assert matrix.state(L, "ghost")["traced"] is False
    for args, msg in ((("ghost", "trace", "off"), "Ghost is not traced - the trace ends with the run"),
                      (("ghost", "deck", "7"), r"deck damage is already 7 \(Deck 7/10\)"),
                      ((hid, "alert", "1"), "KD-4 Host's alert is already noticed")):
        with pytest.raises(LedgerError, match=msg):
            C(g, 107, *args, "x")
    assert "IC stood down (1 active -> none)" in C(g, 107, hid, "ic", None, "x")      # (Patrol stays up on a logout)
    with pytest.raises(LedgerError, match="no IC is awake in KD-4 Host"):
        C(g, 107, hid, "ic", None, "x")


def test_the_trace_and_overwatch_levers_go_by_the_run(make_game, tmp_path):
    """Review 2026-10-27: the levers read the raw record, not the run every reader shows. Filament's live Lim run
    carries an old plain traced=True that shows nowhere, so 'trace on' was refused as "already traced"; and 'trace on'
    or 'overwatch 20' on a decker out of the Matrix posted a [FIX] card and a flag and changed nothing anyone reads."""
    g = make_game()
    setup_demo(g)
    hid, _ = _stuck_on_a_hot_host(g)                                    # (live, with the old plain True)
    L, C = g.ledger, corrections.correct
    assert " · TRACED" not in "\n".join(matrix.summary_lines(L, "ghost"))
    assert C(g, 2, "ghost", "trace", "on", "Track IC found him") == "[FIX] Ghost: traced - Track IC found him"
    assert matrix.state(L, "ghost")["traced"] == hid and " · TRACED" in "\n".join(matrix.summary_lines(L, "ghost"))
    with pytest.raises(RulesRefusal, match="Ghost is already traced on this run"):
        C(g, 2, "ghost", "trace", "on", "x")
    C(g, 2, "ghost", "jack out", None, "retcon")
    flagged = len(flags.listing(tmp_path))
    with pytest.raises(RulesRefusal, match="Ghost isn't in a run, and a trace lasts its run - the next jack-in starts "
                                           "untraced. What a run set going in the world is a hook: what=hook"):
        C(g, 3, "ghost", "trace", "on", "x")
    with pytest.raises(RulesRefusal, match=r"Ghost's Overwatch is 0 \(they're not in a run: the score dies with it\)\. "
                                           "A score set now would show nowhere - their next jack-in starts at 0."):
        C(g, 3, "ghost", "overwatch", "20", "x")
    assert len(flags.listing(tmp_path)) == flagged and matrix.state(L, "ghost")["overwatch"] == 0


def test_a_no_op_correction_files_no_tool_error(make_game, tmp_path):
    """Review 2026-10-27: through the correct tool, a no-op's plain LedgerError made run_tool file an engine 'tool
    error' flag - flag #26's no-op still landed on the flag log, as a bug. It's a refusal: the GM's to fix."""
    from roleplay.dm.tools import TurnContext, run_tool
    g = make_game()
    setup_demo(g)
    ctx = TurnContext(g, 2, g.current_scene_id())
    for what, value in (("overwatch", "0"), ("trace", "off"), ("deck", "0"), ("jack_out", None)):
        out = run_tool(ctx, tool("correct", target_id="ghost", what=what, value=value, reason="he's offline"))
        assert out["is_error"] and out["content"].startswith("Refused: correct: nothing to change - Ghost")
    assert flags.listing(tmp_path) == [] and ctx.tool_errors == 0 and not ctx.cards


def test_a_fix_line_takes_a_bracketed_id_or_a_name(make_game):
    """`fix [ghost]: ...` went to L.require('[ghost]') and failed; a fix line reads its target like any <dm> line."""
    from roleplay.dm import dmblock
    from roleplay.dm.tools import TurnContext
    g = make_game()
    setup_demo(g)
    hid, hook = _stuck_on_a_hot_host(g)
    ctx = TurnContext(g, 2, g.current_scene_id())
    _, entries = dmblock.split("<dm>\nfix [ghost]: overwatch 0 - F36\nfix KD-4 Host: alert 0 - F36\n"
                               f"fix {hook}: hook drop - F36\nfix nobody-here: overwatch 0 - F36\n</dm>")
    dmblock.apply(ctx, entries)
    assert len(ctx.cards) == 3 and [e["line"] for e in ctx.unplaced] == ["fix nobody-here: overwatch 0 - F36"]
    assert matrix.state(g.ledger, "ghost")["overwatch"] == 0 and g.ledger.get(hid)["props"]["alert"] == 0


def test_an_aside_fixes_the_numbers_it_agrees_are_wrong(make_game):
    """Live: the GM agreed in an aside to "reset the threat level" and couldn't. Now its fix lines do it, at once."""
    def structured(user):
        if "SAYS TO YOU, OUT OF CHARACTER" in user:
            return {"answer": "You're right - that dive was retconned. Overwatch is back to 0 and the ward is quiet.",
                    "direction": "", "is_move": False,
                    "fixes": ["fix ghost: overwatch 0 - F36 retconned the dive", "fix ghost: trace off - F36",
                              "fix kd-4-host: alert 0 - F36", "fix kd-4-host: ic off - F36"]}
        return EXTRACTION
    g = make_game(FakeLLM([], structured))
    setup_demo(g)
    hid, _ = _stuck_on_a_hot_host(g)
    res = aside.ask(g, "Alice (plays Ghost [ghost])", "Hey DM, that dive was retconned - why am I at 33?", "ghost")
    assert res["fixed"] == ["the numbers"] and len(res["cards"]) == 4
    assert res["cards"][0] == "[FIX] Ghost: Overwatch 33 -> 0 - F36 retconned the dive"
    st = matrix.state(g.ledger, "ghost")
    assert (st["overwatch"], st["traced"], g.ledger.get(hid)["props"]["alert"]) == (0, False, 0)
