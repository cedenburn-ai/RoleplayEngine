"""The dashboard (DESIGN.md §12h): one window to run the whole setup - the bot, the graph browser, the numbers.

    python -m roleplay.dashboard            open it in its own window (a second launch opens another window)
    python -m roleplay.dashboard --serve    just the local server, for a normal browser tab (Ctrl+C stops it)

Or double-click RoleplayEngine.pyw / the RoleplayEngine shortcut in the project folder.
"""
