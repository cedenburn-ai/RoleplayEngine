"""The dashboard's local server (DESIGN.md §12h): the page, its JSON, the graph browser, and the bot controls.

Standard library only, bound to 127.0.0.1, and alive only while a dashboard window is open. The app window
decides: while one is open - minimized, behind other windows, the PC asleep - the server stays, and a few seconds
after the last one closes the server stops. (A hidden page's timers only wake about once a minute, so a quiet page is
no sign the window closed - that mistake used to shut the server down under a minimized window. And the Edge process
we launch often hands off to another and exits, so its process can't tell us either: window.app_window_open looks for
the window itself.) A plain browser tab (`--browser`, or no Edge/Chrome) says hello every few seconds and goodbye when
it closes; `--serve` stays up until Ctrl+C. Safety for a local server:
- the Host header must be this server's own address (no DNS-rebinding tricks from a web page);
- anything that changes something (start the bot, back up, read the story for jobs...) needs the per-launch key
  that's written into the page - another site can't read it, so it can't press our buttons.
"""
from __future__ import annotations

import json
import os
import secrets
import socket
import sys
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .. import backup, flags, spend
from ..browser.server import ROUTES as GRAPH_ROUTES, Api as GraphApi, live_campaign, route as graph_route
from ..config import CAMPAIGN_DIR
from ..discord_bot import runtime
from . import atlas, botctl, data, window as app_window

STATIC = Path(__file__).resolve().parent / "static"
PACKAGE = Path(__file__).resolve().parents[1]              # roleplay/
ROOT = PACKAGE.parent


def code_stamp() -> float:
    """The newest engine file on disk. A server older than this is running yesterday's code: its new pages 404 (the
    Canon and Flags pages did, against a server five days old) - the page offers a restart."""
    newest = 0.0
    for pattern in ("**/*.py", "dashboard/static/*"):
        for f in PACKAGE.glob(pattern):
            try:
                newest = max(newest, f.stat().st_mtime)
            except OSError:
                pass
    return newest


def relaunch() -> None:
    """Start the app again, detached: the new launch stops this server, closes its windows, opens a fresh one and
    restarts the bot (dashboard/__main__.py)."""
    import subprocess
    pythonw = ROOT / ".venv" / "Scripts" / ("pythonw.exe" if sys.platform == "win32" else "python")
    exe = str(pythonw if pythonw.exists() else sys.executable)
    flags_ = (0x00000008 | 0x00000200) if sys.platform == "win32" else 0   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen([exe, str(ROOT / "RoleplayEngine.pyw")], cwd=str(ROOT), creationflags=flags_,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
         ".ico": "image/x-icon", ".json": "application/json"}
INSTANCE = "dashboard.json"
PREFS = "dashboard_prefs.json"
PORT = 8770                      # the usual address (another free port if it's taken)
HELLO_EVERY = 10                 # seconds between the page's hellos (a hidden page: about once a minute)
WINDOW_GRACE = 10                # after the last app window closes, seconds for another window or tab to say hello
OPENING = 60                     # seconds the first window gets to appear
BYE_GRACE = 20                   # a tab said goodbye: seconds for it (or another) to come back - a reload does at once
TAB_SILENCE = 600                # a tab nobody's heard from in this long is gone (the PC slept, the tab crashed)
APP = "roleplay-dashboard"


class Server(ThreadingHTTPServer):
    allow_reuse_address = False   # (on Windows SO_REUSEADDR would let two servers share the port)
    daemon_threads = True

    def server_bind(self):
        if sys.platform == "win32":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)):
            return                    # the page went away mid-answer (a reload, a window closing) - nothing wrong
        super().handle_error(request, client_address)


class Dashboard:
    def __init__(self, port: int = PORT, mode: str = "window", folder: Path | None = None):
        self.folder = Path(folder or CAMPAIGN_DIR)
        self.mode = mode                                  # window | browser | serve
        self.key = secrets.token_hex(16)
        self.started = time.time()
        self.code = code_stamp()                          # the engine as it was when this server started
        self._code_seen = (0.0, self.code)                # (when we last looked, what we saw)
        self.last_hello: float | None = None
        self.bye_at: float | None = None
        self.window = None                                # the app window's process, if we launched one
        self.window_gone_at: float | None = None
        self.tasks: dict[str, dict] = {}
        self.lock = threading.Lock()
        self.httpd = self._bind(port)
        self.port = self.httpd.server_address[1]
        self.url = f"http://127.0.0.1:{self.port}/"
        self.stopped = threading.Event()

    def _bind(self, port: int) -> Server:
        handler = make_handler(self)
        try:
            return Server(("127.0.0.1", port), handler)
        except OSError:
            return Server(("127.0.0.1", 0), handler)       # the usual port is taken: any free one

    # ── running ─────────────────────────────────────────────────────────
    def start(self) -> None:
        mine = runtime.run_dir(self.folder / ".run") / INSTANCE
        other = runtime.read_json(mine)
        if not (self.mode == "serve" and other and other.get("pid") != os.getpid() and botctl._alive(other.get("pid"))):
            # (a --serve copy - a dev server, a browser tab - never takes the instance file from a live dashboard:
            # the next double-click should open a window on that one)
            runtime.write_json(mine, {"pid": os.getpid(), "port": self.port, "started": self.started, "mode": self.mode})
        threading.Thread(target=self.httpd.serve_forever, name="dashboard-http", daemon=True).start()
        self._serving = True
        threading.Thread(target=self._watch, name="dashboard-watch", daemon=True).start()
        self.task("spend", "Tallying earlier spend", lambda: f"{spend.backfill(self.folder)} earlier turns brought in",
                  quiet=True)
        if self.prefs().get("autostart_bot") and not runtime.running():
            self.task("start", "Starting the bot", lambda: botctl.start(self.prefs().get("announce", False)))

    def wait(self) -> None:
        try:
            while not self.stopped.wait(0.5):
                pass
        except KeyboardInterrupt:
            self.shutdown("Ctrl+C")

    def shutdown(self, why: str = "asked to") -> None:
        """Tidy up first, then let the main thread go: once `stopped` is set the process can exit at any moment."""
        with self.lock:
            if getattr(self, "_closing", False):
                return
            self._closing = True
        _log(f"dashboard (pid {os.getpid()}) stopping: {why}", self.folder)
        try:
            info = runtime.read_json(self.folder / ".run" / INSTANCE)
            if info and info.get("pid") == os.getpid():
                (self.folder / ".run" / INSTANCE).unlink(missing_ok=True)
        except OSError:
            pass
        if self.window is not None and self.window.poll() is None:
            try:
                self.window.terminate()                       # (quit from the page: the window goes too)
            except OSError:
                pass
        if getattr(self, "_serving", False):
            self.httpd.shutdown()                         # (blocks until the HTTP loop ends - never call it unstarted)
        self.stopped.set()

    def should_close(self, now: float | None = None) -> str | None:
        """Why the dashboard should stop now, or None. Never in --serve mode."""
        if self.mode == "serve":
            return None
        now = now or time.time()
        if self.mode == "window":
            open_ = app_window.app_window_open()
            if open_ is None:                                 # (can't look for it: trust the process we launched)
                open_ = self.window is not None and self.window.poll() is None
            if open_:
                self.window_gone_at = None
                return None                                   # a window is open - minimized or not, awake or not
            if now - self.started < OPENING:
                return None                                   # (the first one is still on its way)
            self.window_gone_at = self.window_gone_at or now
            if now - max(self.last_hello or 0, self.window_gone_at) > WINDOW_GRACE:
                return "the window closed"
            return None
        seen = self.last_hello or self.started
        if self.bye_at and self.bye_at >= seen and now - self.bye_at > BYE_GRACE:
            return "the page said goodbye"
        if now - seen > TAB_SILENCE:
            return f"no page has checked in for {int(now - seen)} s"
        return None

    def _watch(self) -> None:
        while not self.stopped.wait(2.0):
            why = self.should_close()
            if why:
                threading.Thread(target=self.shutdown, args=(why,), daemon=True).start()
                return

    def hello(self) -> None:
        self.last_hello = time.time()

    def stale(self) -> bool:
        """Is the engine on disk newer than this server? (looked at no more than every 10 s)"""
        at, seen = self._code_seen
        if time.time() - at > 10:
            seen = code_stamp()
            self._code_seen = (time.time(), seen)
        return seen > self.code + 1

    def bye(self) -> None:
        self.bye_at = time.time()

    # ── background tasks (bot restarts, backups, reading a story for jobs) ─
    def task(self, kind: str, label: str, fn, quiet: bool = False) -> dict:
        with self.lock:
            busy = next((t for t in self.tasks.values() if t["kind"] == kind and t["state"] == "running"), None)
            if busy:
                return busy
            t = {"id": uuid.uuid4().hex[:8], "kind": kind, "label": label, "state": "running", "quiet": quiet,
                 "started": time.time(), "ended": None, "result": None, "error": None}
            self.tasks[t["id"]] = t

        def run():
            try:
                res = fn()
                t["result"] = res if isinstance(res, (str, dict, list, int, float)) or res is None else str(res)
                t["state"] = "done"
            except Exception as exc:
                t["error"] = str(exc) or type(exc).__name__
                t["state"] = "failed"
                _log(f"task {kind} failed: {traceback.format_exc()}", self.folder)
            t["ended"] = time.time()
        threading.Thread(target=run, name=f"task-{kind}", daemon=True).start()
        return t

    def recent_tasks(self) -> list[dict]:
        now = time.time()
        with self.lock:
            for k in [k for k, t in self.tasks.items() if t["ended"] and now - t["ended"] > 600]:
                del self.tasks[k]
            return sorted(self.tasks.values(), key=lambda t: t["started"])

    # ── prefs ───────────────────────────────────────────────────────────
    def prefs(self) -> dict:
        return {"autostart_bot": False, "announce": False,
                **(runtime.read_json(self.folder / ".run" / PREFS) or {})}

    def set_prefs(self, changes: dict) -> dict:
        p = {**self.prefs(), **{k: bool(v) for k, v in changes.items() if k in ("autostart_bot", "announce")}}
        runtime.write_json(runtime.run_dir(self.folder / ".run") / PREFS, p)
        return p

    # ── actions ─────────────────────────────────────────────────────────
    def restart_bot(self, announce: bool) -> str:
        if runtime.running():
            botctl.stop("restart")
            if not botctl.wait_until_down(420):
                raise botctl.BotError("The bot didn't stop within 7 minutes - force stop it, then start it again.")
        botctl.start(announce)
        return "restarted"

    def backfill_jobs(self, name: str) -> str:
        from .. import jobs
        from ..game import Game
        p = data.campaign_path(name, self.folder)
        g = Game(p, out=lambda s: None)
        try:
            g.art.enabled = False
            made = jobs.backfill(g)
        finally:
            g.close()
        return f"{len(made)} job{'s' if len(made) != 1 else ''} found in {name}" if made else f"no jobs in {name}'s story"


def _log(line: str, folder: Path | None = None) -> None:
    """campaigns/.run/dashboard.log (the folder's): why it stopped, and any error a page hit."""
    try:
        d = runtime.run_dir(Path(folder or CAMPAIGN_DIR) / ".run")
        with open(d / "dashboard.log", "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except OSError:
        pass


def make_handler(dash: Dashboard):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        # ── plumbing ────────────────────────────────────────────────────
        def _send(self, code: int, body: bytes, ctype: str, cache: bool = False) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "max-age=300" if cache else "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _json(self, obj, code: int = 200) -> None:
            self._send(code, json.dumps(obj, default=str).encode(), "application/json")

        def _file(self, p: Path | None, ctype: str = "image/png") -> None:
            if p and p.exists():
                self._send(200, p.read_bytes(), ctype)
            else:
                self._send(404, b"not found", "text/plain")

        def _host_ok(self) -> bool:
            return self.headers.get("Host", "") in (f"127.0.0.1:{dash.port}", f"localhost:{dash.port}")

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if not n:
                return {}
            if n > 1_000_000:                         # nothing we take is this big: don't keep the connection
                self.close_connection = True
                return {}
            try:
                return json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return {}

        # ── GET ─────────────────────────────────────────────────────────
        def do_GET(self):  # noqa: N802
            if not self._host_ok():
                return self._send(403, b"forbidden", "text/plain")
            url = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            path = url.path
            try:
                if path in ("/", "/index.html"):
                    page = (STATIC / "index.html").read_text(encoding="utf-8")
                    page = page.replace("{{KEY}}", dash.key).replace("{{HELLO}}", str(HELLO_EVERY))
                    return self._send(200, page.encode(), TYPES[".html"])
                if path.startswith("/static/"):
                    name = path[len("/static/"):]
                    f = (STATIC / name).resolve()
                    if f.parent != STATIC or f.suffix not in TYPES or not f.exists():
                        return self._send(404, b"not found", "text/plain")
                    return self._send(200, f.read_bytes(), TYPES[f.suffix], cache=f.suffix in (".png", ".ico", ".svg"))
                if path == "/favicon.ico":
                    return self._file(STATIC / "icon.ico", TYPES[".ico"])
                if path == "/graph" or path in GRAPH_ROUTES:
                    base = self.folder_campaign(q.get("c"))
                    code, body, ctype = graph_route(GraphApi(base), "/" if path == "/graph" else path, q)
                    return self._send(code, body, ctype)
                if path.startswith("/api/dash/"):
                    return self.dash_get(path[len("/api/dash/"):], q)
                return self._send(404, b"not found", "text/plain")
            except data.NotFound as exc:
                return self._json({"error": str(exc)}, 404)
            except Exception as exc:
                _log(f"GET {self.path}: {traceback.format_exc()}", dash.folder)
                return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

        def folder_campaign(self, name: str | None) -> Path:
            if name:
                try:
                    return data.campaign_path(name, dash.folder)
                except data.NotFound:
                    pass
            return dash.folder / f"{live_campaign(dash.folder)}.db"

        def dash_get(self, what: str, q: dict) -> None:
            c = q.get("c", "")
            if what == "ping":
                return self._json({"app": APP, "pid": os.getpid(), "port": dash.port})
            if what == "status":
                return self._json({"bot": botctl.status(), "stamp": data.stamp(dash.folder),
                                   "tasks": dash.recent_tasks(), "prefs": dash.prefs(), "now": time.time(),
                                   "server": {"pid": os.getpid(), "started": dash.started, "mode": dash.mode,
                                              "stale": dash.stale()}})
            if what == "campaigns":
                return self._json({"campaigns": data.campaign_list(dash.folder),
                                   "live": live_campaign(dash.folder, "")})
            if what == "overview":
                return self._json(data.overview(c, botctl.status(), dash.folder))
            if what == "story":
                return self._json(data.story(c, int(q["scene"]) if q.get("scene", "").isdigit() else None,
                                             int(q["before"]) if q.get("before", "").isdigit() else None,
                                             folder=dash.folder))
            if what == "people":
                return self._json(data.people(c, botctl.status(), dash.folder))
            if what == "spend":
                days = int(q["days"]) if q.get("days", "").isdigit() else 30
                return self._json(data.spend_view(c or None, max(7, min(days, 120)), dash.folder))
            if what == "bot":
                return self._json({"bot": botctl.status(), "backups": data.backups(), "setup": data.setup(),
                                   "prefs": dash.prefs(), "bindings": data.bindings(dash.folder), "log": str(botctl.LOG)})
            if what == "log":
                return self._json(botctl.log_since(int(q["offset"]) if q.get("offset", "").isdigit() else None))
            if what == "strays":
                pid = (botctl.status().get("pid"))
                return self._json({"strays": botctl.stray_bots({pid} if pid else set())})
            if what == "map":
                return self._file(data.fight_map(c, int(q.get("id", "0") or 0), dash.folder))
            if what == "atlas":
                return self._json(atlas.atlas(c, dash.folder))
            if what == "atlas-base":
                base = atlas.base_image(dash.folder)
                if not base:
                    return self._send(404, b"no map", "text/plain")
                return self._send(200, base[0].read_bytes(), "image/png", cache=True)
            if what == "portrait":
                return self._file(data.ledger_portrait(q.get("slug", ""), dash.folder))
            if what == "canon":
                return self._json(data.canon_view(c, dash.folder))
            if what == "flags":
                status = q.get("status", "open")
                return self._json({"flags": flags.listing(dash.folder, None if status == "all" else status,
                                                          q.get("c") or None),
                                   "counts": flags.counts(dash.folder)})
            return self._send(404, b"not found", "text/plain")

        # ── POST ────────────────────────────────────────────────────────
        def do_POST(self):  # noqa: N802
            body = self._body()                       # always read it: on a kept-alive connection, unread bytes
            if not self._host_ok():                   # would be taken for the start of the next request
                return self._send(403, b"forbidden", "text/plain")
            url = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            key = self.headers.get("X-RP-Key") or q.get("key")
            if not key or not secrets.compare_digest(key, dash.key):
                return self._json({"error": "stale key", "reload": True}, 403)
            what = url.path[len("/api/dash/"):] if url.path.startswith("/api/dash/") else ""
            try:
                return self.dash_post(what, body)
            except (botctl.BotError, data.NotFound) as exc:
                return self._json({"error": str(exc)}, 409)
            except Exception as exc:
                _log(f"POST {self.path}: {traceback.format_exc()}", dash.folder)
                return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

        def dash_post(self, what: str, body: dict) -> None:
            if what == "hello":
                dash.hello()
                return self._json({"ok": True, "every": HELLO_EVERY})
            if what == "bye":
                dash.bye()
                return self._json({"ok": True})
            if what == "bot/start":
                if runtime.running():
                    raise botctl.BotError("The bot is already running.")
                t = dash.task("bot", "Starting the bot", lambda: botctl.start(bool(body.get("announce"))))
                return self._json({"task": t})
            if what == "bot/stop":
                return self._json(botctl.stop("stop"))
            if what == "bot/restart":
                t = dash.task("bot", "Restarting the bot", lambda: dash.restart_bot(bool(body.get("announce"))))
                return self._json({"task": t})
            if what == "bot/force":
                return self._json(botctl.force_stop())
            if what == "bot/kill":
                pid = int(body.get("pid") or 0)
                if pid not in {s["pid"] for s in botctl.stray_bots()}:
                    raise botctl.BotError("That isn't a stray bot process.")
                botctl.kill(pid)
                return self._json({"ok": True})
            if what == "flags/status":
                return self._json(flags.set_status(dash.folder, int(body.get("id") or 0), str(body.get("status")),
                                                   body.get("note")))
            if what == "backup":
                t = dash.task("backup", "Backing up every world", lambda: str(backup.run(dash.folder)))
                return self._json({"task": t})
            if what == "jobs-backfill":
                name = body.get("c", "")
                data.campaign_path(name, dash.folder)
                t = dash.task(f"jobs:{name}", f"Reading {name}'s story for jobs", lambda: dash.backfill_jobs(name))
                return self._json({"task": t})
            if what == "prefs":
                return self._json(dash.set_prefs(body))
            if what == "open":
                target = {"log": botctl.LOG, "campaigns": dash.folder, "backups": backup.backup_dir()}.get(body.get("what"))
                if target is None or not Path(target).exists():
                    raise data.NotFound("nothing to open")
                if sys.platform == "win32":
                    os.startfile(str(target))                # noqa: S606 (a local file the owner asked to see)
                return self._json({"ok": True})
            if what == "quit":
                threading.Timer(0.3, dash.shutdown, args=("quit from the page",)).start()
                return self._json({"ok": True})
            if what == "relaunch":                        # the new launch stops us: nothing more to do here
                relaunch()
                return self._json({"ok": True})
            return self._send(404, b"not found", "text/plain")

    return Handler
