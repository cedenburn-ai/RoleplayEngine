"""Draws the RoleplayEngine icon (the hexagon R of the dashboard) as static/icon.ico and static/icon.png.

    python -m roleplay.dashboard.icon
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

STATIC = Path(__file__).resolve().parent / "static"
CYAN, MAGENTA, INK, FILL = (80, 220, 255), (255, 74, 166), (228, 236, 246), (15, 24, 40)


def _hexagon(s: float, inset: float = 0.0) -> list[tuple[float, float]]:
    """The SVG's hexagon (48-unit box) scaled by s, pulled in toward the middle by `inset` units."""
    pts = [(24, 3), (42, 13.5), (42, 34.5), (24, 45), (6, 34.5), (6, 13.5)]
    k = (21 - inset) / 21                                    # 21 = centre to corner
    return [((24 + (x - 24) * k) * s, (24 + (y - 24) * k) * s) for x, y in pts]


def draw(size: int = 256, ss: int = 4) -> Image.Image:
    big = size * ss
    s = big / 48
    # the rim: a diagonal cyan-to-magenta gradient, cut to the hexagon, with the dark face inside it
    grad = Image.new("RGBA", (big, big))
    gp = grad.load()
    for y in range(0, big, 4):
        for x in range(0, big, 4):
            t = min(1.0, max(0.0, (x + y) / (2 * big) * 1.4 - 0.2))
            col = tuple(int(CYAN[k] + (MAGENTA[k] - CYAN[k]) * t) for k in range(3)) + (255,)
            for dy in range(4):
                for dx in range(4):
                    gp[x + dx, y + dy] = col
    mask = Image.new("L", (big, big), 0)
    ImageDraw.Draw(mask).polygon(_hexagon(s), fill=255)
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    glow = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    glow.paste(grad, (0, 0), mask)
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(big / 45)))
    img.paste(grad, (0, 0), mask)
    d = ImageDraw.Draw(img)
    d.polygon(_hexagon(s, 3.2), fill=FILL + (255,))
    # the R, every stroke centred on its path so the joins meet
    w = 3.6 * s
    r = w / 2

    def dot(x, y):
        d.ellipse([x * s - r, y * s - r, x * s + r, y * s + r], fill=INK)

    def line(a, b):
        d.line([(a[0] * s, a[1] * s), (b[0] * s, b[1] * s)], fill=INK, width=int(w))
        dot(*a)
        dot(*b)
    cx, cy, rad = 24.5, 21.5, 4.5
    line((17, 17), (17, 31))
    line((17, 17), (cx, 17))
    line((17, 26), (cx, 26))
    line((cx, 26), (31, 31))
    d.arc([(cx - rad) * s - r, (cy - rad) * s - r, (cx + rad) * s + r, (cy + rad) * s + r], -90, 90, fill=INK, width=int(w))
    return img.resize((size, size), Image.LANCZOS)


def main() -> None:
    big = draw(256)
    big.save(STATIC / "icon.png")
    big.save(STATIC / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print(STATIC / "icon.ico")


if __name__ == "__main__":
    main()
