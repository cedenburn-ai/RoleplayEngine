"""What the dashboard shows (DESIGN.md §12h): read-only views of the campaign files, the spend log, the character
ledger and the bot's heartbeat.

Every read opens its own short read-only connection, so the dashboard can't change a world by accident and never
holds a lock the bot is waiting on. GM-only material (NPC agendas, tension pressure points, whispers, attitudes)
is included under `gm` keys and in flagged rows - the page hides it unless the spoiler switch is on, because the
person looking is usually also a player.
"""
from __future__ import annotations

import json
import re
import sqlite3
import time
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from .. import backup, jobs as jobs_mod, keys, spend
from ..config import CAMPAIGN_DIR, MODEL_ALIASES
from ..discord_bot import runtime
from ..engine import clock
from ..engine.ledger import Ledger
from ..engine.rules import sr_lite

NAME = re.compile(r"^[A-Za-z0-9_-]+$")
SKIP = spend.NOT_WORLDS


class NotFound(Exception):
    pass


# ── files ───────────────────────────────────────────────────────────────
def _ro(p: Path) -> sqlite3.Connection:
    c = sqlite3.connect(f"file:{p.resolve().as_posix()}?mode=ro", uri=True, timeout=5)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout = 5000")
    return c


def campaign_path(name: str, folder: Path | None = None) -> Path:
    folder = Path(folder or CAMPAIGN_DIR)
    p = folder / f"{name}.db"
    if not name or not NAME.match(name) or p.name in SKIP or not p.exists():
        raise NotFound(f"no campaign '{name}'")
    return p


def _has(c, table: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def bindings(folder: Path | None = None) -> dict:
    try:
        return json.loads((Path(folder or CAMPAIGN_DIR) / "discord_bindings.json").read_text())
    except (OSError, ValueError):
        return {}


def _utc(stamp: str | None) -> float | None:
    t = spend._utc(stamp)
    return t or None


def _utc_text(t: float) -> str:
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _midnight(now: float | None = None) -> float:
    return datetime.fromtimestamp(now or time.time()).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()


def bot_tables(bot_status: dict | None) -> dict[str, dict]:
    """campaign -> the bot's live table for it (from the heartbeat)."""
    s = (bot_status or {}).get("status") or {}
    return {t["campaign"]: t for t in s.get("tables", [])}


# ── the folder ──────────────────────────────────────────────────────────
def campaign_list(folder: Path | None = None) -> list[dict]:
    folder = Path(folder or CAMPAIGN_DIR)
    live = {b.get("campaign"): key for key, b in bindings(folder).items()}
    out = []
    for p in folder.glob("*.db"):
        if p.name in SKIP:
            continue
        row = {"name": p.stem, "live": p.stem in live, "channel_id": live.get(p.stem), "turns": 0, "last_at": None,
               "session": 1, "size": p.stat().st_size, "modified": p.stat().st_mtime, "pcs": 0}
        try:
            with closing(_ro(p)) as c:
                if _has(c, "turns"):
                    n, last = c.execute("SELECT COUNT(*), MAX(created_at) FROM turns WHERE status='committed'").fetchone()
                    row.update(turns=n, last_at=_utc(last), last_turn=c.execute("SELECT MAX(id) FROM turns").fetchone()[0])
                    m = c.execute("SELECT value FROM meta WHERE key='session'").fetchone()
                    row["session"] = int(m[0]) if m else 1
                    row["pcs"] = c.execute("SELECT COUNT(*) FROM entities WHERE kind='pc' AND status='active'").fetchone()[0]
        except sqlite3.Error:
            row["error"] = True
        out.append(row)
    return sorted(out, key=lambda r: (not r["live"], -(r["last_at"] or r["modified"])))


def stamp(folder: Path | None = None) -> dict[str, int]:
    """Each campaign's newest turn id - the page refreshes a view when its campaign's number moves."""
    out = {}
    for p in Path(folder or CAMPAIGN_DIR).glob("*.db"):
        if p.name in SKIP:
            continue
        try:
            with closing(_ro(p)) as c:
                last = c.execute("SELECT COALESCE(MAX(id),0), COUNT(*) FROM turns").fetchone()
                jobs = c.execute("SELECT COALESCE(MAX(updated_turn),0) FROM jobs").fetchone()[0] if _has(c, "jobs") else 0
                out[p.stem] = f"{last[0]}.{last[1]}.{jobs}"
        except sqlite3.Error:
            continue
    return out


# ── people ──────────────────────────────────────────────────────────────
def _portrait(c, campaign: str, eid: str) -> str | None:
    if not _has(c, "art"):
        return None
    row = c.execute("SELECT version FROM art WHERE entity_id=? AND status='ready' ORDER BY version DESC LIMIT 1",
                    (eid,)).fetchone()
    return f"/api/art?c={campaign}&id={eid}&v={row[0]}" if row else None


def character(c, L: Ledger, campaign: str, ent: dict, players: dict | None = None) -> dict:
    eid = ent["id"]
    s = L.stats(eid)
    props = ent.get("props") or {}
    pmax, smax = sr_lite.monitor_max(L, eid)
    skills = sorted(((k, int(v)) for k, v in s.items() if k in sr_lite.SKILLS and v > 0), key=lambda kv: -kv[1])
    gear = [{"name": h["name"], "qty": h.get("qty", 1), "kind": h["kind"]} for h in L.holdings(eid)]
    seat = (players or {}).get(ent.get("player") or eid)
    return {
        "id": eid, "name": ent["name"], "kind": ent["kind"], "description": ent.get("description", ""),
        "player": ent.get("player"), "discord_name": seat["name"] if seat else None,
        "metatype": props.get("metatype") or "", "role": props.get("archetype") or "",
        "pronouns": props.get("pronouns") or "", "concept": props.get("concept") or "",
        "portrait": _portrait(c, campaign, eid), "condition": sr_lite.condition(L, eid),
        "physical": [int(s.get("physical_damage", 0)), pmax], "stun": [int(s.get("stun_damage", 0)), smax],
        "karma": int(s.get("karma", 0)), "nuyen": int(s.get("nuyen", 0)),
        "essence": round(s.get("essence", 6.0), 2), "edge": int(s.get("edge", 0)),
        "magic": int(s.get("magic", 0)), "resonance": int(s.get("resonance", 0)),
        "attributes": {a: int(s.get(a, 0)) for a in sr_lite.ATTRIBUTES if a in s},
        "skills": skills[:8], "gear": gear[:12], "ledger": props.get("ledger"), "status": ent.get("status"),
    }


def _players(c, L: Ledger) -> dict[str, dict]:
    """PC handle -> the Discord seat (name, id, afk)."""
    return {r["handle"]: dict(r) for r in c.execute("SELECT discord_id, handle, name, afk FROM players")} \
        if _has(c, "players") else {}


def _speakers(c, L: Ledger) -> dict[str, str]:
    """handle -> the character's name (PCs by player, inhabited NPCs by id)."""
    names = {}
    for e in L.entities(kind="pc", status=None):
        names[e["player"] or e["id"]] = e["name"]
        names[e["id"]] = e["name"]
    return names


def _activity(c) -> tuple[dict, Counter]:
    """handle -> (last turn id, when) and how many turns each handle posted in."""
    last, count = {}, Counter()
    for r in c.execute("SELECT id, inputs, created_at FROM turns WHERE status='committed' ORDER BY id"):
        try:
            handles = {h for h, _ in json.loads(r["inputs"] or "[]")}
        except (ValueError, TypeError):
            continue
        for h in handles:
            last[h] = (r["id"], _utc(r["created_at"]))
            count[h] += 1
    return last, count


def player_rows(c, L: Ledger, table: dict | None) -> list[dict]:
    seats = _players(c, L)
    last, count = _activity(c)
    meta = dict(c.execute("SELECT key, value FROM meta").fetchall())
    building = {k.split(":", 1)[1] for k, v in meta.items() if k.startswith("chargen:") and v}
    active = (table or {}).get("active", {})
    now_active = set((table or {}).get("active_now", []))
    rows = []
    for handle, seat in seats.items():
        ch = L.pc_for_player(handle) or L.get(handle)
        rows.append({
            "discord_id": seat["discord_id"], "name": seat["name"] or handle, "handle": handle,
            "character": {"id": ch["id"], "name": ch["name"], "kind": ch["kind"]} if ch else None,
            "afk": bool(seat["afk"]), "building": seat["discord_id"] in building,
            "last_turn": last.get(handle, (None, None))[0], "last_at": last.get(handle, (None, None))[1],
            "turns": count.get(handle, 0), "active": handle in now_active, "active_at": active.get(handle),
        })
    return sorted(rows, key=lambda r: (not r["active"], -(r["active_at"] or r["last_at"] or 0)))


# ── turns ───────────────────────────────────────────────────────────────
def _turn(r, names: dict, privates: dict) -> dict:
    try:
        inputs = json.loads(r["inputs"] or "[]")
    except (ValueError, TypeError):
        inputs = []
    keys = r.keys()
    return {"id": r["id"], "scene_id": r["scene_id"], "at": _utc(r["created_at"]), "cost": round(r["cost"] or 0, 4),
            "session": r["session"] if "session" in keys else None,
            "inputs": [{"handle": h, "name": names.get(h, h), "text": t} for h, t in inputs],
            "narration": r["narration"] or "", "private": privates.get(r["private"]) if "private" in keys and
            r["private"] else None}


def recent_turns(c, L: Ledger, limit: int = 6) -> list[dict]:
    names = _speakers(c, L)
    privates = {e["id"]: e["name"] for e in L.entities(status=None) if e["kind"] in ("pc", "npc")}
    rows = c.execute("SELECT * FROM turns WHERE status='committed' ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [_turn(r, names, privates) for r in rows]


# ── the world's state ───────────────────────────────────────────────────
def _jobs(c, L: Ledger, campaign: str) -> list[dict]:
    out = []
    for j in jobs_mod.all_jobs(c):
        client = L.get(j["client_id"]) if j["client_id"] else None
        out.append({**j, "client": {"id": client["id"], "name": client["name"],
                                    "portrait": _portrait(c, campaign, client["id"])} if client else None})
    return out


def _tensions(c) -> list[dict]:
    if not _has(c, "tensions"):
        return []
    rows = c.execute("SELECT * FROM tensions ORDER BY CASE status WHEN 'open' THEN 0 WHEN 'shelved' THEN 1 ELSE 2 END, "
                     "pressure * stakes DESC, updated_turn DESC LIMIT 12").fetchall()
    return [{"id": r["id"], "question": r["question"], "stakes": r["stakes"], "status": r["status"],
             "pressure": round(r["pressure"], 2), "public": r["public"] or "", "resolution": r["resolution"] or "",
             "gm": {"next": r["next"] or "", "due_time": r["due_time"]}} for r in rows]


def _agendas(c, L: Ledger) -> list[dict]:
    if not _has(c, "agendas"):
        return []
    out = []
    for r in c.execute("SELECT * FROM agendas WHERE status='active' ORDER BY updated_turn DESC LIMIT 10"):
        who = L.get(r["npc_id"])
        out.append({"id": r["id"], "who": who["name"] if who else r["npc_id"], "goal": r["goal"], "steps": r["steps"]})
    return out


def _fight(c, L: Ledger, campaign: str, folder: Path) -> dict | None:
    if not _has(c, "encounters"):
        return None
    r = c.execute("SELECT * FROM encounters ORDER BY (status='active') DESC, id DESC LIMIT 1").fetchone()
    if not r:
        return None
    sides = json.loads(r["sides"] or "{}")
    positions = json.loads(r["positions"] or "{}")
    who = []
    for eid, zone in positions.items():
        e = L.get(eid)
        if e:
            who.append({"id": eid, "name": e["name"], "zone": zone, "side": sides.get(eid) or
                        ("runners" if e["kind"] == "pc" else "neutral"), "condition": sr_lite.condition(L, eid)})
    has_map = (folder / "maps" / f"{campaign}_fight_{r['id']}.png").exists()
    return {"id": r["id"], "status": r["status"], "round": r["round"], "outcome": r["outcome"],
            "started_turn": r["started_turn"], "ended_turn": r["ended_turn"], "who": who,
            "map": f"/api/dash/map?c={campaign}&id={r['id']}&t={r['round']}" if has_map else None}


def _settings(meta: dict) -> dict:
    model = meta.get("dm_model", "claude-opus-5-5")
    try:
        diff = json.loads(meta["difficulty"]).get("level", "normal") if meta.get("difficulty") else "normal"
    except ValueError:
        diff = "normal"
    return {"gm": next((k for k, v in MODEL_ALIASES.items() if v == model), model),
            "effort": meta.get("dm_effort", "medium"), "difficulty": diff,
            "world": meta.get("world", "on") == "on", "art": meta.get("art", "on") == "on",
            "companions": meta.get("companions", "idle")}


def overview(name: str, bot: dict | None = None, folder: Path | None = None) -> dict:
    folder = Path(folder or CAMPAIGN_DIR)
    p = campaign_path(name, folder)
    table = bot_tables(bot).get(name)
    with closing(_ro(p)) as c:
        L = Ledger(c)
        meta = dict(c.execute("SELECT key, value FROM meta").fetchall())
        session = int(meta.get("session", "1"))
        minutes = int(float(meta.get("clock", clock.DEFAULT_START)))
        sc = L.current_scene()
        loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
        midnight = _utc_text(_midnight())
        n_total, first, last = c.execute("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM turns "
                                         "WHERE status='committed'").fetchone()
        n_session = c.execute("SELECT COUNT(*) FROM turns WHERE status='committed' AND session=?", (session,)).fetchone()[0]
        n_today = c.execute("SELECT COUNT(*) FROM turns WHERE status='committed' AND created_at>=?",
                            (midnight,)).fetchone()[0]
        players = _players(c, L)
        party = [character(c, L, name, e, players) for e in L.entities(kind="pc")]
        jobs = _jobs(c, L, name)
        current = jobs_mod.current(c)
        nodes = c.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        cast = c.execute("SELECT COUNT(*) FROM entities WHERE kind='npc' AND tier>=1").fetchone()[0]
        out = {
            "campaign": name, "title": meta.get("campaign", name),
            "live": name in {b.get("campaign") for b in bindings(folder).values()},
            "table": table, "session": session,
            "clock": clock.fmt(minutes), "clock_short": clock.short(minutes), "part_of_day": clock.part_of_day(minutes),
            "scene": {"id": sc["id"], "title": sc["title"], "location": loc["name"] if loc else None,
                      "location_id": loc["id"] if loc else None,
                      "art": _portrait(c, name, loc["id"]) if loc else None,
                      "since_turn": sc["created_turn"]} if sc else None,
            "turns": {"total": n_total, "session": n_session, "today": n_today, "first_at": _utc(first),
                      "last_at": _utc(last)},
            "job": next((j for j in jobs if current and j["id"] == current["id"]), None),
            "jobs": jobs[::-1][:8], "has_jobs_table": _has(c, "jobs"),
            "tensions": _tensions(c), "gm": {"agendas": _agendas(c, L)},
            "fight": _fight(c, L, name, folder),
            "party": party, "players": player_rows(c, L, table),
            "recent": recent_turns(c, L, 6),
            "settings": _settings(meta),
            "counts": {"nodes": nodes, "cast": cast, "scenes": c.execute("SELECT COUNT(*) FROM scenes").fetchone()[0]},
        }
    out["spend"] = {"all": spend.campaign_total(folder, name), "today": spend.campaign_total(folder, name, _midnight())}
    return out


def people(name: str, bot: dict | None = None, folder: Path | None = None) -> dict:
    folder = Path(folder or CAMPAIGN_DIR)
    p = campaign_path(name, folder)
    table = bot_tables(bot).get(name)
    with closing(_ro(p)) as c:
        L = Ledger(c)
        players = _players(c, L)
        party = [character(c, L, name, e, players) for e in L.entities(kind="pc", status=None)]
        heat = {r["node_id"]: r["energy"] for r in c.execute("SELECT node_id, energy FROM energy")}
        mean = (sum(heat.values()) / len(heat)) if heat else 1.0
        pcs = [e["id"] for e in L.entities(kind="pc")]
        npcs = []
        from .. import seed
        sealed = seed.sealed_ids(c)                      # (only a story seed's GM half knows them yet: seed.py)
        for e in L.entities(kind="npc", status=None):
            if e["tier"] < 1:
                continue
            if e["id"] in sealed:
                continue
            att = {pc: int(L.stat(e["id"], f"attitude:{pc}", 0)) for pc in pcs
                   if c.execute("SELECT 1 FROM stats WHERE entity_id=? AND key=?", (e["id"], f"attitude:{pc}")).fetchone()}
            npcs.append({"id": e["id"], "name": e["name"], "description": e["description"], "status": e["status"],
                         "tier": e["tier"], "heat": round(heat.get(e["id"], 0) / mean, 2),
                         "condition": sr_lite.condition(L, e["id"]), "portrait": _portrait(c, name, e["id"]),
                         "gm": {"attitudes": att}})
        npcs.sort(key=lambda n: -n["heat"])
        rows = player_rows(c, L, table)
    return {"campaign": name, "players": rows, "party": party, "npcs": npcs[:24], "library": library(folder)}


def library(folder: Path | None = None) -> list[dict]:
    """The character ledger: every saved runner, and where each is checked out."""
    p = Path(folder or CAMPAIGN_DIR) / spend.LEDGER_FILE
    if not p.exists():
        return []
    with closing(_ro(p)) as c:
        if not _has(c, "runners"):
            return []
        out = []
        for r in c.execute("SELECT * FROM runners ORDER BY lower(name)"):
            data = json.loads(r["data"] or "{}")
            props = data.get("props", {})
            stats = data.get("stats", {})
            out.append({"slug": r["slug"], "name": r["name"], "owner": r["owner_name"], "shared": bool(r["shared"]),
                        "campaign": r["campaign"], "role": props.get("archetype", ""),
                        "metatype": props.get("metatype", ""), "karma": int(stats.get("karma", 0)),
                        "nuyen": int(stats.get("nuyen", 0)),
                        "portrait": f"/api/dash/portrait?slug={r['slug']}" if r["portrait"] else None,
                        "stories": len(json.loads(r["backstory"] or "[]")), "updated": _utc(r["updated_at"])})
        return out


def ledger_portrait(slug: str, folder: Path | None = None) -> Path | None:
    p = Path(folder or CAMPAIGN_DIR) / spend.LEDGER_FILE
    if not p.exists() or not NAME.match(slug or ""):
        return None
    with closing(_ro(p)) as c:
        row = c.execute("SELECT portrait FROM runners WHERE slug=?", (slug,)).fetchone()
    if not row or not row[0]:
        return None
    f = Path(row[0])
    if not f.is_absolute():
        f = Path(folder or CAMPAIGN_DIR) / f
    return f if f.exists() else None


def fight_map(name: str, enc_id: int, folder: Path | None = None) -> Path | None:
    folder = Path(folder or CAMPAIGN_DIR)
    campaign_path(name, folder)
    f = folder / "maps" / f"{name}_fight_{int(enc_id)}.png"
    return f if f.exists() else None


# ── the story ───────────────────────────────────────────────────────────
def story(name: str, scene: int | None = None, before: int | None = None, limit: int = 30,
          folder: Path | None = None) -> dict:
    p = campaign_path(name, Path(folder or CAMPAIGN_DIR))
    with closing(_ro(p)) as c:
        L = Ledger(c)
        names = _speakers(c, L)
        privates = {e["id"]: e["name"] for e in L.entities(status=None) if e["kind"] in ("pc", "npc")}
        summaries = {r["id"]: r["text"] for r in c.execute("SELECT id, text FROM nodes WHERE kind='scene'")}
        counts = {r[0]: (r[1], r[2], r[3], r[4], r[5]) for r in c.execute(
            "SELECT scene_id, COUNT(*), MIN(id), MAX(id), MIN(created_at), MIN(session) FROM turns "
            "WHERE status='committed' GROUP BY scene_id")}
        scenes = []
        for s in c.execute("SELECT * FROM scenes ORDER BY id"):
            loc = L.get(s["location_id"]) if s["location_id"] else None
            n, lo, hi, at, sess = counts.get(s["id"], (0, None, None, None, None))
            text = summaries.get(f"S{s['id']}", "")
            text = re.sub(r"^Scene: [^.]*\.\s*", "", text) if text else ""
            scenes.append({"id": s["id"], "title": s["title"], "status": s["status"], "location": loc["name"] if loc else None,
                           "turns": n, "first": lo, "last": hi, "at": _utc(at), "session": sess, "summary": text})
        current = L.current_scene()
        sid = scene if scene is not None else (current["id"] if current else (scenes[-1]["id"] if scenes else None))
        sql = "SELECT * FROM turns WHERE status='committed' AND scene_id=?"
        args: list = [sid]
        if before:
            sql += " AND id<?"
            args.append(int(before))
        rows = c.execute(sql + " ORDER BY id DESC LIMIT ?", (*args, limit + 1)).fetchall()
        more = len(rows) > limit
        turns = [_turn(r, names, privates) for r in rows[:limit]][::-1]
    return {"campaign": name, "scenes": scenes, "scene": sid, "turns": turns, "more": more,
            "current": current["id"] if current else None}


# ── spend, backups, setup ───────────────────────────────────────────────
def spend_view(campaign: str | None = None, days: int = 30, folder: Path | None = None) -> dict:
    return spend.report(folder, days=days, campaign=campaign or None)


def backups() -> dict:
    d = backup.backup_dir()
    zips = sorted(d.glob("campaigns-*.zip"), reverse=True) if d.exists() else []
    return {"dir": str(d), "last": zips[0].stat().st_mtime if zips else None,
            "every_hours": backup.EVERY // 3600, "keep": backup.KEEP,
            "files": [{"name": z.name, "size": z.stat().st_size, "at": z.stat().st_mtime} for z in zips[:20]]}


def setup() -> dict:
    """What the bot needs, present or not, and where each key comes from - never the secrets themselves (keys.py)."""
    st = keys.status()
    return {"token": runtime.token_source(), "anthropic": st["anthropic_api_key"], "openai": st["openai_api_key"],
            "config": st["config"], "config_error": st["error"], "campaigns": str(CAMPAIGN_DIR)}


# ── the canon: the story read back and reconciled (dm/canon.py) ─────────
def canon_view(name: str, folder: Path | None = None) -> dict:
    from ..dm import canon as canon_mod
    from ..dm import doubts as doubts_mod
    p = campaign_path(name, Path(folder or CAMPAIGN_DIR))
    with closing(_ro(p)) as c:
        meta = dict(c.execute("SELECT key, value FROM meta WHERE key IN (?, ?, ?)",
                              (canon_mod.KEY, canon_mod.KEY + "_prev", canon_mod.RULINGS_KEY)).fetchall())
        last = c.execute("SELECT COALESCE(MAX(id), 0) FROM turns WHERE status='committed'").fetchone()[0] or 0
        live = {r["id"]: r["text"] for r in c.execute("SELECT id, text FROM rulings WHERE status='active' "
                                                       "ORDER BY rowid")} if _has(c, "rulings") else {}
        steer = [dict(r) for r in c.execute("SELECT id, text, by_name, created_turn FROM narrative WHERE "
                                            "status='active' ORDER BY rowid")] if _has(c, "narrative") else []
        sc = c.execute("SELECT id, title FROM scenes WHERE status='active' ORDER BY id DESC LIMIT 1").fetchone()
        fr = c.execute("SELECT value FROM meta WHERE key=?", (f"frame_S{sc['id']}",)).fetchone() if sc else None
        names = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM entities")}
        dbt = doubts_mod.listing(c, last, settled=12)        # where the record doesn't add up (open, then settled)
        for d in dbt["open"] + dbt["settled"]:
            d["raised_by_name"] = doubts_mod.NAMED.get(d["raised_by"], d["raised_by"])
            d["resolved_by_name"] = doubts_mod.NAMED.get(d["resolved_by"], d["resolved_by"]) if d["resolved_by"] else None

    def load(key):
        try:
            return json.loads(meta.get(key) or "null")
        except ValueError:
            return None
    cur, prev = load(canon_mod.KEY), load(canon_mod.KEY + "_prev")
    drop = {r["id"] for r in load(canon_mod.RULINGS_KEY) or []}
    if cur:
        for r in cur.get("rulings") or []:
            r["text"], r["standing"], r["suggested"] = live.get(r["id"], ""), r["id"] in live, r["id"] in drop
    return {"canon": cur, "prev_turn": (prev or {}).get("turn"), "last_turn": last, "every": canon_mod.CANON_EVERY,
            "next_turn": (int(cur["turn"]) + canon_mod.CANON_EVERY) if cur else 15,
            "rulings": [{"id": k, "text": v} for k, v in live.items()], "narrative": steer,
            "frame": _frame_view(fr, sc, names), "doubts": dbt, "pressing_after": doubts_mod.PRESSING}


def _frame_view(row, scene, names: dict) -> dict | None:
    try:
        f = json.loads(row["value"]) if row else None
    except ValueError:
        return None
    if not f:
        return None
    for p in f.get("people") or []:
        p["name"] = names.get(p["id"], p["id"])
        for t in p.get("toward") or []:
            t["name"] = names.get(t["id"], t["id"])
    return {**f, "title": scene["title"]}
