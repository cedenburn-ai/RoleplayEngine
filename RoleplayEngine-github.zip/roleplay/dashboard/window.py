"""The dashboard's window: a chromeless app window in Edge or Chrome, so it looks and behaves like a program.

It gets a browser profile of its own (in %LOCALAPPDATA%\\RoleplayEngine), which keeps it out of your normal tabs,
history and sign-ins and lets it close cleanly. With neither browser installed it opens in the default browser.
"""
from __future__ import annotations

import os
import subprocess
import sys
import webbrowser
from pathlib import Path

CANDIDATES = (
    r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
    r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
    r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe",
    r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
    r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
    r"%LocalAppData%\Google\Chrome\Application\chrome.exe",
)
SIZE = (1500, 960)


def find_browser() -> str | None:
    if sys.platform != "win32":
        return None
    for c in CANDIDATES:
        p = Path(os.path.expandvars(c))
        if "%" not in str(p) and p.exists():
            return str(p)
    return None


def profile_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
    d = base / "RoleplayEngine" / "dashboard-window"
    d.mkdir(parents=True, exist_ok=True)
    return d


TITLE = "RoleplayEngine"         # the page's <title> - an app window shows exactly this (a tab adds " - Microsoft Edge")


def app_window_open(title: str = TITLE) -> bool | None:
    """Is a dashboard app window open (minimized counts)? None where we can't tell (not Windows).

    The window is the one thing to ask: the Edge process we launch often hands off to another and exits at once, and a
    hidden page's timers only wake about once a minute, so neither the process nor the page's hellos say it closed."""
    if sys.platform != "win32":
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def check(hwnd, _):
        n = user32.GetWindowTextLengthW(hwnd)
        if n == len(title) and user32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value == title:
                found.append(hwnd)
                return False                              # (found one: stop looking)
        return True
    user32.EnumWindows(check, 0)
    return bool(found)


def close_app_windows(title: str = TITLE, wait: float = 4.0) -> int:
    """Ask every dashboard app window to close (WM_CLOSE) and wait a moment for them to go. Returns how many there
    were. An app restart closes the old windows - they belong to the old server - and opens one fresh."""
    if sys.platform != "win32":
        return 0
    import ctypes
    import time
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def check(hwnd, _):
        n = user32.GetWindowTextLengthW(hwnd)
        if n == len(title) and user32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value == title:
                found.append(hwnd)
        return True
    user32.EnumWindows(check, 0)
    for hwnd in found:
        user32.PostMessageW(hwnd, 0x0010, 0, 0)            # WM_CLOSE
    end = time.time() + wait
    while found and app_window_open(title) and time.time() < end:
        time.sleep(0.2)
    return len(found)


def open_window(url: str, size: tuple[int, int] = SIZE) -> subprocess.Popen | None:
    """Open `url` as an app window. Returns the browser process (None if it went to the default browser)."""
    exe = find_browser()
    if not exe:
        webbrowser.open(url)
        return None
    args = [exe, f"--app={url}", f"--user-data-dir={profile_dir()}", "--no-first-run", "--no-default-browser-check",
            "--disable-background-mode", "--disable-sync", f"--window-size={size[0]},{size[1]}"]
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
    return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            creationflags=flags, close_fds=True)
