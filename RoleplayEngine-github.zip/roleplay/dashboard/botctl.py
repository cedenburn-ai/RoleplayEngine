"""Starting and stopping the Discord bot from the dashboard (DESIGN.md §5b).

The bot runs as its own detached process, so it keeps playing after the dashboard window closes and survives
whatever launched it. The dashboard never talks to it over a port. It only:
- tries the bot's lock to see whether one is up, and reads its heartbeat file (runtime.py);
- starts `python -m roleplay.discord_bot`, its output appended to campaigns/discord_bot.log;
- drops a stop request for the bot to pick up (it finishes the turn in flight first);
- ends a stuck one outright, if asked (force).

A bot started the old way (the scratchpad run_bot.py) doesn't hold the lock, so before starting one the dashboard
also looks for stray bot processes and refuses to make a second copy - two bots on one token answer every message
twice.
"""
from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from .. import keys
from ..config import CAMPAIGN_DIR, ROOT
from ..discord_bot import runtime

LOG = CAMPAIGN_DIR / "discord_bot.log"
SPAWN = "bot_spawn.json"
STALE = 25.0                     # seconds without a heartbeat before an "online" bot counts as stuck
BOT_MARKERS = ("roleplay.discord_bot", "run_bot.py")


class BotError(Exception):
    pass


def python_exe() -> str:
    """The bot wants a console-subsystem python (its output goes to the log) even if the dashboard runs windowless."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and exe.with_name("python.exe").exists():
        return str(exe.with_name("python.exe"))
    return str(exe)


def _alive(pid: int | None) -> bool:
    if not pid:
        return False
    if sys.platform == "win32":
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(handle)
        return code.value == 259                                                 # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def status(folder: Path | None = None) -> dict:
    """What the bot is doing: offline | starting | connecting | online | reconnecting | stopping | stuck."""
    d = runtime.run_dir(folder)
    up = runtime.running(folder)
    beat = runtime.read_json(d / runtime.STATUS) or {}
    spawn = runtime.read_json(d / SPAWN) or {}
    now = time.time()
    fresh = bool(beat) and beat.get("started", 0) >= spawn.get("at", 0) - 5     # this run's heartbeat, not the last
    if not up:
        state = "offline"
    elif not fresh:
        state = "starting"
    elif now - beat.get("beat", 0) > STALE:
        state = "stuck"
    else:
        state = beat.get("state") or "starting"
    out = {"state": state, "up": up, "now": now, "token": runtime.token_source(),
           "pid": (beat.get("pid") if fresh else None) or (spawn.get("pid") if up else None),
           "status": beat if up and fresh else None,
           "last": None if up else ({k: beat.get(k) for k in ("state", "detail", "started", "beat", "errors",
                                                               "last_error", "tables", "channels", "user")}
                                     if beat else None),
           "code_changed": bool(up and fresh and runtime.code_stamp() > beat.get("code", 0) + 1)}
    if up and fresh:
        out["uptime"] = now - beat.get("started", now)
    return out


def _other_install(exe: str | None) -> bool:
    """A python inside another copy of the project (its own .venv) - that copy's bot, on its own token and lock, not
    a stray of this one's (the owner trying the public copy on the machine the table plays on)."""
    if not exe:
        return False
    for d in Path(exe).parents:
        if (d / "roleplay" / "discord_bot").is_dir():
            return d.resolve() != ROOT.resolve()
    return False


def stray_bots(exclude: set[int] | None = None) -> list[dict]:
    """Bot processes the lock doesn't account for (started the old way). Windows only; [] elsewhere.

    A venv's python.exe is a little launcher that runs the real interpreter as its child, so each bot is a pair of
    processes with the same command line: `exclude` the running bot's pid and its pair is left out too. Another
    install's bots are left out too, pairs and all."""
    if sys.platform != "win32":
        return []
    cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command",
           "Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
           "Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress"]
    try:
        raw = subprocess.run(cmd, capture_output=True, text=True, timeout=20,
                             creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
        rows = json.loads(raw) if raw else []
    except (OSError, subprocess.SubprocessError, ValueError):
        return []
    rows = [r for r in (rows if isinstance(rows, list) else [rows])
            if any(m in (r.get("CommandLine") or "") for m in BOT_MARKERS)]
    theirs = {r["ProcessId"] for r in rows if _other_install(r.get("ExecutablePath"))}
    for _ in range(2):                                    # (a launcher's child runs the base python, outside it)
        theirs |= {r["ProcessId"] for r in rows if r.get("ParentProcessId") in theirs}
    rows = [r for r in rows if r["ProcessId"] not in theirs]
    known = {p for p in (exclude or set()) if p}
    spawn = (runtime.read_json(runtime.run_dir() / SPAWN) or {}).get("pid")
    if spawn and runtime.running():
        known.add(spawn)
    for _ in range(2):                                    # the known bots' launchers and children
        known |= {r["ProcessId"] for r in rows if r.get("ParentProcessId") in known}
        known |= {r["ParentProcessId"] for r in rows if r.get("ProcessId") in known}
    known.add(os.getpid())
    pairs = {r["ProcessId"]: r.get("ParentProcessId") for r in rows}
    return [{"pid": r["ProcessId"], "command": (r.get("CommandLine") or "")[:300]} for r in rows
            if r["ProcessId"] not in known and pairs.get(r["ProcessId"]) not in pairs]   # (one entry per pair)


def start(announce: bool = False, folder: Path | None = None, check_strays: bool = True) -> dict:
    if runtime.running(folder):
        raise BotError("The bot is already running.")
    why = f"{keys.problem()}, so nothing in it was read; " if keys.problem() else ""   # (a token there, unquoted)
    if not runtime.token_source():
        raise BotError(f"No bot token found - {why}{keys.how_to_set('discord_token')}.")
    if not keys.source("anthropic_api_key"):
        raise BotError(f"No Anthropic API key - {why}{keys.how_to_set('anthropic_api_key')}. The GM can't think "
                       "without it.")
    if check_strays:
        strays = stray_bots()
        if strays:
            raise BotError(f"Another bot is already running outside the dashboard (pid {strays[0]['pid']}). "
                           "Stop that one first - two copies would answer every message twice.")
    d = runtime.run_dir(folder)
    (d / runtime.CONTROL).unlink(missing_ok=True)
    args = [python_exe(), "-u", "-m", "roleplay.discord_bot"] + (["--announce"] if announce else [])
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG, "ab") as log:
        log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} started from the dashboard =====\n".encode())
    pid = _detach(args, env)
    runtime.write_json(d / SPAWN, {"pid": pid, "at": time.time(), "announce": announce})
    return {"pid": pid}


# The go-between: starts the bot with its output in the log, prints its pid and exits at once - so the bot is
# nobody's child (closing or killing whatever started the dashboard, process tree and all, can't take it along),
# and on Windows it also asks to leave any job object the dashboard was started in.
_GO_BETWEEN = r"""
import json, subprocess, sys
spec = json.loads(sys.argv[1])
log = open(spec["log"], "ab")
kw = dict(cwd=spec["cwd"], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, close_fds=True)
if sys.platform == "win32":
    flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    try:
        p = subprocess.Popen(spec["args"], creationflags=flags | subprocess.CREATE_BREAKAWAY_FROM_JOB, **kw)
    except OSError:
        p = subprocess.Popen(spec["args"], creationflags=flags, **kw)
else:
    p = subprocess.Popen(spec["args"], start_new_session=True, **kw)
print(p.pid, flush=True)
"""


def _detach(args: list[str], env: dict) -> int:
    spec = json.dumps({"args": args, "cwd": str(ROOT), "log": str(LOG)})
    flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    try:                                                  # (the go-between may leave a job object too)
        r = subprocess.run([python_exe(), "-I", "-c", _GO_BETWEEN, spec], env=env, capture_output=True, text=True,
                           timeout=30, creationflags=flags | (subprocess.CREATE_BREAKAWAY_FROM_JOB
                                                              if sys.platform == "win32" else 0))
    except OSError:
        r = subprocess.run([python_exe(), "-I", "-c", _GO_BETWEEN, spec], env=env, capture_output=True, text=True,
                           timeout=30, creationflags=flags)
    try:
        return int(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        raise BotError(f"The bot didn't start: {(r.stderr or r.stdout).strip()[-400:] or 'no output'}")


def stop(why: str = "stop", folder: Path | None = None) -> dict:
    """Ask the bot to stop; it finishes the turn in flight first. Returns at once (the dashboard watches)."""
    if not runtime.running(folder):
        return {"state": "offline"}
    runtime.request_stop(folder, why=why)
    return {"state": "stopping"}


def wait_until_down(timeout: float, folder: Path | None = None) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if not runtime.running(folder):
            return True
        time.sleep(0.5)
    return False


def force_stop(folder: Path | None = None) -> dict:
    """End the bot outright (a stuck one). Anything mid-turn is lost - the next start rolls it back."""
    s = status(folder)
    pid = s.get("pid") or (runtime.read_json(runtime.run_dir(folder) / SPAWN) or {}).get("pid")
    if not pid or not _alive(pid):
        return {"state": "offline"}
    kill(pid)
    return {"state": "stopping", "pid": pid}


def kill(pid: int) -> None:
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=20,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    else:
        os.kill(int(pid), signal.SIGTERM)


def log_since(offset: int | None, limit: int = 256_000) -> dict:
    """New log text since `offset` (bytes); with no offset, the tail. The dashboard's live log polls this."""
    if not LOG.exists():
        return {"offset": 0, "text": "", "reset": True}
    size = LOG.stat().st_size
    reset = offset is None or offset > size              # (the log was rotated or truncated)
    start_at = max(0, size - limit) if reset else offset
    with open(LOG, "rb") as f:
        f.seek(start_at)
        data = f.read(min(limit, size - start_at))
    text = data.decode("utf-8", errors="replace")
    if reset and start_at > 0:                           # start the tail on a whole line
        text = text.split("\n", 1)[1] if "\n" in text else text
    return {"offset": start_at + len(data), "text": text, "reset": reset}


def main(argv: list[str] | None = None) -> None:
    """python -m roleplay.dashboard.botctl start|stop|restart|status - the dashboard's Bot buttons, from a terminal."""
    import argparse
    ap = argparse.ArgumentParser(prog="python -m roleplay.dashboard.botctl")
    ap.add_argument("action", choices=("start", "stop", "restart", "status"), nargs="?", default="status")
    ap.add_argument("--announce", action="store_true", help="say hello in the game channel when it starts")
    args = ap.parse_args(argv)
    try:
        if args.action in ("stop", "restart") and runtime.running():
            stop(args.action)
            print("Stopping the bot (a turn in progress finishes first)...", flush=True)
            if not wait_until_down(420):
                raise BotError("It didn't stop within 7 minutes - force stop it from the dashboard's Bot page.")
            print("Stopped.")
        if args.action in ("start", "restart"):
            pid = start(args.announce)["pid"]
            print("Starting the bot...", flush=True)
            for _ in range(90):                       # until it's online - or its process is gone
                time.sleep(1)
                s = status()
                if s["state"] == "online" or (s["state"] == "offline" and not _alive(pid)):
                    break
        s = status()
        st = s.get("status") or {}
        line = f"Bot: {s['state']}"
        if s["state"] == "online":
            line += f" as {st.get('user')} - {st.get('latency_ms')} ms, pid {s['pid']}"
        elif s["state"] == "offline" and args.action in ("start", "restart"):
            line += f" - it exited while starting; see {LOG}"
        print(line)
    except BotError as exc:
        raise SystemExit(f"Bot: {exc}")


if __name__ == "__main__":
    main()
