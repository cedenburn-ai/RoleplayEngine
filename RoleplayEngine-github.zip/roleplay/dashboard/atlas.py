"""The atlas (DESIGN.md §12i): the metroplex as the story has filled it in, for the dashboard's zoomable map.

Every place the world has put on the map (engine/geo.py gives each one a lat/lon), the scenes played there, who's
where right now, the party's road through the story, the fights. Read-only, like the rest of the dashboard. Things the
party doesn't know - places they've never heard of, where NPCs are offscreen, GM-only facts - are flagged `gm`, and the
page hides them unless GM eyes is on.

The base picture is the styled metroplex (`!map restyle`, or your own campaigns/maps/custom.png), reprojected once into
Web Mercator so it lines up with the street tiles underneath it.
"""
from __future__ import annotations

import json
import math
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace

from PIL import Image

from .. import maps
from ..config import CAMPAIGN_DIR
from ..engine import geo
from ..engine.ledger import Ledger
from . import data

BASE = "atlas_base.png"


def _merc(lat: float) -> float:
    return math.log(math.tan(math.pi / 4 + math.radians(lat) / 2))


def base_image(folder: Path | None = None) -> tuple[Path, dict] | None:
    """The styled metroplex in Web Mercator (cached; redone when the source picture changes) and its bounds."""
    folder = Path(folder or CAMPAIGN_DIR)
    out, meta = folder / "maps" / BASE, folder / "maps" / (BASE + ".json")
    sources = [p for p in (maps.MAP_DIR / "custom.png", maps.MAP_DIR / "metroplex_base.png") if p.exists()]
    stamp = max((p.stat().st_mtime for p in sources), default=0.0)
    try:
        info = json.loads(meta.read_text())
        if out.exists() and info.get("stamp") == stamp:
            return out, info["bounds"]
    except (OSError, ValueError, KeyError):
        pass
    img, b = maps.base_image()                         # custom > styled > the plain schematic
    img = img.convert("RGB")
    w, h = img.size
    top, bottom = _merc(b["north"]), _merc(b["south"])
    flat = Image.new("RGB", (w, h))
    for j in range(h):                                 # each output row sits at an even step in Mercator y
        y = top - (top - bottom) * (j + 0.5) / h
        lat = math.degrees(2 * math.atan(math.exp(y)) - math.pi / 2)
        i = min(h - 1, max(0, int((b["north"] - lat) / (b["north"] - b["south"]) * h)))
        flat.paste(img.crop((0, i, w, i + 1)), (0, j))
    out.parent.mkdir(parents=True, exist_ok=True)
    flat.save(out, optimize=True)
    meta.write_text(json.dumps({"stamp": stamp, "bounds": b}))
    return out, b


def _facts(c, eid: str) -> list[dict]:
    rows = c.execute("SELECT n.id, n.text, n.visibility FROM nodes n WHERE n.kind='fact' AND n.id IN "
                     "(SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='about') "
                     "AND n.id NOT IN (SELECT old_id FROM supersedes) ORDER BY n.created_turn DESC LIMIT 6",
                     (eid, eid, eid)).fetchall()
    return [{"id": r["id"], "text": r["text"], "gm": r["visibility"] != "public"} for r in rows]


def atlas(name: str, folder: Path | None = None) -> dict:
    folder = Path(folder or CAMPAIGN_DIR)
    p = data.campaign_path(name, folder)
    with closing(data._ro(p)) as c:
        L = Ledger(c)
        g = SimpleNamespace(ledger=L, conn=c)
        try:
            known = {e["id"] for e in maps.known_places(g)}
        except Exception:                              # (an older file without everything known_places reads)
            known = set()
        scenes = L.scenes()
        cur = L.current_scene()
        turns = {r[0]: {"turns": r[1], "first": r[2], "last": r[3], "session": r[4], "at": data._utc(r[5])}
                 for r in c.execute("SELECT scene_id, COUNT(*), MIN(id), MAX(id), MIN(session), MAX(created_at) "
                                    "FROM turns WHERE status='committed' GROUP BY scene_id")}
        fights: dict[int, list] = {}
        if data._has(c, "encounters"):
            for r in c.execute("SELECT scene_id, status, outcome, round FROM encounters ORDER BY id"):
                fights.setdefault(r["scene_id"], []).append({"status": r["status"], "outcome": r["outcome"],
                                                            "rounds": r["round"]})
        roster = {s["id"]: L.roster(s["id"]) for s in scenes}

        places = []
        for e in L.entities(kind="location", status=None):
            gg = e["props"].get("geo")
            if not gg:
                continue
            here = [s for s in scenes if s["location_id"] == e["id"]]
            sc_list = [{"id": s["id"], "title": s["title"], "status": s["status"], **turns.get(s["id"], {})}
                       for s in here]
            places.append({
                "id": e["id"], "name": e["name"], "description": e["description"], "lat": gg["lat"], "lon": gg["lon"],
                "district": gg.get("district"), "art": data._portrait(c, name, e["id"]),
                "visited": bool(here), "current": bool(cur and cur["location_id"] == e["id"]),
                "scenes": sc_list, "last_at": max((s.get("at") or 0 for s in sc_list), default=None) or None,
                "fights": [f for s in here for f in fights.get(s["id"], [])],
                "facts": _facts(c, e["id"]), "gm": e["id"] not in known and not here,
            })

        def where(eid: str) -> tuple[dict | None, str | None]:
            gg = geo.geo_of(g, eid)
            sid = L.scene_of(eid)
            sc = L.scene(sid) if sid else None
            ent = L.get(eid)
            w = (ent["props"].get("whereabouts") or {}) if ent else {}
            place = w.get("place") if w.get("place") and L.get(w["place"]) else (sc["location_id"] if sc else None)
            return gg, place

        players = {r["handle"]: r["name"] for r in c.execute("SELECT handle, name FROM players")} \
            if data._has(c, "players") else {}
        party = []
        for pc in L.entities(kind="pc"):
            gg, place = where(pc["id"])
            if gg:
                party.append({"id": pc["id"], "name": pc["name"], "lat": gg["lat"], "lon": gg["lon"],
                              "place": place, "player": players.get(pc["player"] or pc["id"]),
                              "portrait": data._portrait(c, name, pc["id"])})
        cur_roster = set(roster.get(cur["id"], [])) if cur else set()
        people = []
        for npc in L.entities(kind="npc"):
            w = npc["props"].get("whereabouts") or {}
            with_party = npc["id"] in cur_roster
            if not w and not with_party:
                continue
            gg, place = where(npc["id"])
            if not gg:
                continue
            people.append({"id": npc["id"], "name": npc["name"], "lat": gg["lat"], "lon": gg["lon"], "place": place,
                           "doing": w.get("where") if not with_party else None, "with_party": with_party,
                           "portrait": data._portrait(c, name, npc["id"]), "gm": not with_party})

        trail = []
        loc_geo = {pl["id"]: pl for pl in places}
        for s in sorted(scenes, key=lambda s: (s["created_turn"], s["id"])):
            pl = loc_geo.get(s["location_id"] or "")
            if not pl or (trail and trail[-1]["place"] == pl["id"]):
                continue
            trail.append({"scene": s["id"], "title": s["title"], "place": pl["id"], "name": pl["name"],
                          "lat": pl["lat"], "lon": pl["lon"], "session": turns.get(s["id"], {}).get("session"),
                          "turn": turns.get(s["id"], {}).get("first")})
    base = base_image(folder)
    return {"campaign": name, "places": places, "party": party, "people": people, "trail": trail,
            "districts": [{"name": k, "lat": v[0], "lon": v[1], "radius": v[2]} for k, v in geo.GAZETTEER.items()],
            "base": {"url": "/api/dash/atlas-base", "bounds": base[1]} if base else None,
            "current": cur["location_id"] if cur else None}
