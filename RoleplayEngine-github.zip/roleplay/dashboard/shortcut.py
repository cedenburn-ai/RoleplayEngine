"""Make Windows shortcuts to the dashboard, with its icon.

    python -m roleplay.dashboard.shortcut               RoleplayEngine.lnk in the project folder
    python -m roleplay.dashboard.shortcut --desktop     ...and one on the desktop
    python -m roleplay.dashboard.shortcut --start-menu  ...and one in the Start menu (so it's searchable)

A shortcut can also be dragged to the taskbar to pin it.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from ..config import ROOT

ICON = Path(__file__).resolve().parent / "static" / "icon.ico"
LAUNCHER = ROOT / "RoleplayEngine.pyw"
PYTHONW = ROOT / ".venv" / "Scripts" / "pythonw.exe"


def make(where: Path) -> Path:
    """One RoleplayEngine.lnk in `where`: pythonw (the project's venv) running RoleplayEngine.pyw."""
    if sys.platform != "win32":
        raise SystemExit("Shortcuts are a Windows thing - run `python -m roleplay.dashboard` instead.")
    if not ICON.exists():
        from .icon import main as draw
        draw()
    lnk = Path(where) / "RoleplayEngine.lnk"
    target = PYTHONW if PYTHONW.exists() else Path(sys.executable).with_name("pythonw.exe")
    q = lambda p: str(p).replace("'", "''")                               # noqa: E731 (PowerShell quoting)
    script = (f"$s = (New-Object -ComObject WScript.Shell).CreateShortcut('{q(lnk)}'); "
              f"$s.TargetPath = '{q(target)}'; $s.Arguments = '\"{q(LAUNCHER)}\"'; "
              f"$s.WorkingDirectory = '{q(ROOT)}'; $s.IconLocation = '{q(ICON)},0'; "
              "$s.Description = 'RoleplayEngine - the bot, the graph browser and the numbers'; $s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], check=True,
                   capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    return lnk


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay.dashboard.shortcut")
    ap.add_argument("--desktop", action="store_true", help="also put one on the desktop")
    ap.add_argument("--start-menu", action="store_true", help="also put one in the Start menu")
    args = ap.parse_args(argv)
    print(make(ROOT))
    if args.desktop:
        print(make(Path(os.environ["USERPROFILE"]) / "Desktop"))
    if args.start_menu:
        print(make(Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs"))


if __name__ == "__main__":
    main()
