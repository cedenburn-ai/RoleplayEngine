"""python -m roleplay.dashboard [--serve] [--browser] [--port N]

    (no options)  open the dashboard in its own window. Opening it restarts it: an old dashboard server is stopped
                  (its windows close), a fresh one starts with the code on disk, and a running bot is restarted too
    --serve       just the local server - open the printed address in any browser; Ctrl+C stops it
    --browser     use the default browser instead of an app window
"""
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import sys
import time
import urllib.request
import webbrowser

from ..config import CAMPAIGN_DIR
from ..discord_bot import runtime
from . import botctl, server, window


def running_instance() -> dict | None:
    """A dashboard already serving? (its instance file, confirmed by asking it)"""
    info = runtime.read_json(CAMPAIGN_DIR / ".run" / server.INSTANCE)
    if not info or not info.get("port"):
        return None
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{info['port']}/api/dash/ping", timeout=1.5) as r:
            ping = json.loads(r.read())
        return info if ping.get("app") == server.APP and ping.get("pid") == info.get("pid") else None
    except (OSError, ValueError):
        return None


def stop_instance(info: dict, wait: float = 10.0) -> None:
    """Stop a running dashboard server: ask it to quit (with the key its page carries), and if it hasn't gone in a few
    seconds, end it. Its code may be days old - a fresh launch should never hand the table to it."""
    port, pid = info.get("port"), info.get("pid")
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2) as r:
            m = re.search(r'name="rp-key" content="([0-9a-f]+)"', r.read().decode("utf-8", "replace"))
        if m:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/dash/quit", data=b"{}", method="POST",
                                         headers={"Content-Type": "application/json", "X-RP-Key": m.group(1)})
            urllib.request.urlopen(req, timeout=2).close()
    except (OSError, ValueError):
        pass
    end = time.time() + wait
    while botctl._alive(pid) and time.time() < end:
        time.sleep(0.2)
    if botctl._alive(pid):
        try:
            os.kill(int(pid), signal.SIGTERM)             # (Windows: TerminateProcess)
        except OSError:
            pass
        time.sleep(0.5)


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay.dashboard", description="The RoleplayEngine dashboard.")
    ap.add_argument("--serve", action="store_true", help="just the server, for a browser tab (Ctrl+C stops it)")
    ap.add_argument("--browser", action="store_true", help="open in the default browser instead of an app window")
    ap.add_argument("--port", type=int, default=server.PORT, help=f"the port to try first (default {server.PORT})")
    ap.add_argument("--no-open", action="store_true", help="don't open a window (tests, or open it yourself)")
    args = ap.parse_args(argv)
    if sys.stdout is None or sys.stderr is None:        # pythonw: no console - send output to the dashboard log
        log = open(runtime.run_dir(CAMPAIGN_DIR / ".run") / "dashboard.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    mode = "serve" if args.serve else "browser" if args.browser else "window"

    app = not args.serve and not args.no_open             # opening the app (a double-click, the page's restart)
    if not args.serve:
        inst = running_instance()
        if inst:                                           # restarting the app restarts the server - with today's code
            stop_instance(inst)
        if inst and app and mode == "window":              # (the old windows belong to the old server - only then:
            window.close_app_windows()                     # another install's window has the same title)

    dash = server.Dashboard(args.port, mode)
    dash.start()
    if app and runtime.running():                          # ...and the bot (it finishes a turn in flight first)
        dash.task("bot", "Restarting the bot with the app",
                  lambda: dash.restart_bot(dash.prefs().get("announce", False)))
    if args.serve:
        print(f"RoleplayEngine dashboard: {dash.url}   (Ctrl+C stops it)", flush=True)
    elif not args.no_open:
        if mode == "window":
            dash.window = window.open_window(dash.url)
        else:
            webbrowser.open(dash.url)
    dash.wait()


if __name__ == "__main__":
    main()
