'use strict';
/* RoleplayEngine dashboard. Plain JS, no build step. The server is roleplay/dashboard/server.py. */

const KEY = document.querySelector('meta[name=rp-key]').content;
const HELLO_MS = (+document.querySelector('meta[name=rp-hello]').content || 10) * 1000;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = { get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } },
                set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* private window */ } } };

const S = {
  view: 'overview', campaign: null, campaigns: [], live: null, status: null, stamp: null, spoilers: false,
  data: {}, head: null, tasks: {}, gone: false,
  story: { scene: null, turn: null },
  spend: { c: '', days: 30 },
  flags: { status: 'open', c: '' },
  log: { offset: null, lines: [], filter: 'all', follow: true, timer: null },
};
const VIEWS = ['overview', 'map', 'story', 'people', 'spend', 'memory', 'bot', 'flags', 'canon'];
const PURPOSE_COLORS = {
  gm: '#50dcff', memory: '#a993ff', world: '#60e892', minds: '#ff4aa6', notes: '#7aa2ff', fights: '#ff5a5a',
  recap: '#ffba46', chronicle: '#f2d675', chargen: '#4fd1b5', ledger: '#8fd6ff', askgm: '#c0c8d8', art: '#ff8fc8',
  jobs: '#9be15d', sim: '#56647d', other: '#8b9ab2', history: '#2f7ea6', images: '#ff9f43',
};

// ── talking to the server ─────────────────────────────────────────────
async function api(path, opts = {}) {
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (r.status === 403 && j.reload) {                  // the dashboard was relaunched: this page holds an old key
    const n = +(sessionStorage.getItem('rp.reloads') || 0);
    if (n < 3) { sessionStorage.setItem('rp.reloads', n + 1); location.reload(); }
  }
  if (!r.ok) throw new Error(j.error || `${r.status} ${r.statusText}`);
  if (opts.method === 'POST') sessionStorage.removeItem('rp.reloads');
  return j;
}
const qs = p => { const e = Object.entries(p).filter(([, v]) => v !== undefined && v !== null && v !== '');
  return e.length ? '?' + e.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&') : ''; };
const get = (what, p = {}) => api('/api/dash/' + what + qs(p));
const post = (what, body = {}) => api('/api/dash/' + what, {
  method: 'POST', headers: { 'Content-Type': 'application/json', 'X-RP-Key': KEY }, body: JSON.stringify(body) });

// ── formatting ────────────────────────────────────────────────────────
const money = (x, d) => { x = x || 0; return '$' + x.toLocaleString(undefined, { minimumFractionDigits: d ?? (x >= 1000 ? 0 : 2), maximumFractionDigits: d ?? (x >= 1000 ? 0 : 2) }); };
const nuyen = x => '¥' + Math.round(x || 0).toLocaleString();
const clip = (s, n) => { s = String(s || ''); return s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s; };
const plain = t => String(t || '').replace(/\*\*|__|(?<!\w)\*|\*(?!\w)/g, '').replace(/^-#\s+/gm, '').replace(/\s+/g, ' ').trim();
const initials = n => (n || '?').split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
const title = s => String(s || '').replace(/_/g, ' ');
function ago(t) {
  if (!t) return '—';
  const s = Date.now() / 1000 - t;
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  const d = Math.round(s / 86400);
  return d === 1 ? 'yesterday' : `${d} days ago`;
}
function dur(s) {
  s = Math.max(0, Math.floor(s || 0));
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return d ? `${d} d ${h} h` : h ? `${h} h ${m} min` : `${m} min`;
}
const when = t => t ? new Date(t * 1000).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';
const day = s => new Date(s + 'T12:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
const portrait = (src, name, cls = '') => src ? `<img class="${cls}" src="${esc(src)}" alt="" loading="lazy">`
  : `<div class="noart ${cls}">${esc(initials(name))}</div>`;
const panel = (head, body, more = '', extra = '') =>
  `<section class="panel ${extra}"><div class="panel-head"><h2>${head}</h2>${more ? `<span class="more">${more}</span>` : ''}</div>${body}</section>`;
const tile = (k, v, s, cls = '') => `<div class="tile"><div class="k">${k}</div><div class="v ${cls}">${v}</div><div class="s">${s || '&nbsp;'}</div></div>`;
const fact = (k, v) => v ? `<dt>${k}</dt><dd>${esc(v)}</dd>` : '';
function inline(s) {
  return s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*\w])\*(?!\s)([^*\n]+?)\*(?!\w)/g, '$1<em>$2</em>');
}
function prose(text) {
  return String(text || '').replace(/\r/g, '').split(/\n{2,}/).filter(b => b.trim()).map(b => `<p>${b.split('\n').map(l =>
    /^-#\s/.test(l) ? `<span class="sub">${inline(esc(l.replace(/^-#\s+/, '')))}</span>` : inline(esc(l))).join('<br>')}</p>`).join('');
}

// ── toasts and dialogs ────────────────────────────────────────────────
function toast(msg, kind = '', sub = '', ms = 5200) {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.innerHTML = `${kind === 'busy' ? '<span class="btn sm" style="padding:0;border:0;background:none"><span class="spin"></span></span>' : ''}
    <div>${esc(msg)}${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
  $('#toasts').append(el);
  if (ms) setTimeout(() => el.remove(), ms);
  return el;
}
function confirmBox(head, body, yes = 'Yes', danger = false) {
  return new Promise(res => {
    const m = $('#modal');
    m.innerHTML = `<div class="dialog" role="dialog" aria-modal="true"><h3>${esc(head)}</h3><p>${body}</p>
      <div class="row"><button class="btn ghost" data-a="no">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-a="yes">${esc(yes)}</button></div></div>`;
    m.classList.add('on');
    const done = v => { m.classList.remove('on'); m.innerHTML = ''; document.removeEventListener('keydown', key); res(v); };
    const key = e => { if (e.key === 'Escape') done(false); if (e.key === 'Enter') done(true); };
    document.addEventListener('keydown', key);
    m.onclick = e => { const a = e.target.closest('[data-a]'); if (a) done(a.dataset.a === 'yes'); else if (e.target === m) done(false); };
    setTimeout(() => $('[data-a=yes]', m).focus(), 30);
  });
}
async function act(btn, fn, okMsg) {
  const label = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerHTML = `<span class="spin"></span>${label}`; }
  try { const r = await fn(); if (okMsg) toast(okMsg, 'ok'); return r; }
  catch (e) { toast(e.message, 'bad', '', 8000); }
  finally { if (btn) { btn.disabled = false; btn.innerHTML = label; } }
}

// ── the frame: nav, campaign, status ──────────────────────────────────
function render(html, flush = false) {
  const v = $('#view');
  v.classList.toggle('flush', flush);
  v.innerHTML = html;
}
function loading() { render('<div class="loading"><div class="spin"></div>Loading...</div>'); }
function failed(e) {
  render(`<div class="wrap"><section class="panel"><div class="empty"><b>Couldn't load this view.</b> ${esc(e.message || e)}</div>
    <button class="btn sm" onclick="refresh()">Try again</button></section></div>`);
}

function setSpoilers(on) {
  S.spoilers = on;
  document.body.classList.toggle('spoilers', on);
  $('#spoilers').checked = on;
  $('#spoilword').textContent = on ? 'on' : 'off';
  store.set('rp.spoilers', on ? '1' : '0');
  for (const a of [S.atlasMini, S.atlasPage]) if (a?.atlas?.d) a.atlas.draw();      // (GM-only places and people)
  if (S.view === 'map' && S.atlasPage?.atlas) S.atlasPage.atlas.repick();
}

function fillPicker() {
  const sel = $('#campaign');
  sel.innerHTML = S.campaigns.map(c => `<option value="${esc(c.name)}"${c.name === S.campaign ? ' selected' : ''}>`
    + `${esc(c.name)}${c.live ? '  ● live' : ''}${c.turns ? `  · ${c.turns} turns` : ''}</option>`).join('');
}
async function loadCampaigns() {
  const r = await get('campaigns');
  S.campaigns = r.campaigns;
  S.live = r.live;
  const names = S.campaigns.map(c => c.name);
  if (!names.includes(S.campaign)) {
    const asked = new URLSearchParams(location.search).get('c');          // a link straight to a world: /?c=rage#story
    const saved = store.get('rp.campaign');
    S.campaign = names.includes(asked) ? asked : names.includes(saved) ? saved
      : (r.live && names.includes(r.live) ? r.live : names[0] || null);
  }
  fillPicker();
}

function crumbs(d) {
  const c = S.campaigns.find(x => x.name === S.campaign) || {};
  $('#livechip').innerHTML = c.live ? '<span class="livechip">Live in Discord</span>' : '<span class="livechip off">Not in Discord</span>';
  $('#crumbs').innerHTML = d && d.scene ? `<span>${esc(d.scene.title)}</span><span class="faint">·</span><span>${esc(d.clock_short)}</span>` : '';
}

const BOTWORD = { online: 'Online', offline: 'Offline', starting: 'Starting', connecting: 'Connecting', reconnecting: 'Reconnecting',
  stopping: 'Stopping', stuck: 'Not responding', stopped: 'Stopped' };
function botLine(b) {
  const s = b.status || {};
  if (b.state === 'online') return `${s.latency_ms ?? '?'} ms · up ${dur(b.uptime)}`;
  if (b.state === 'offline') return b.last && b.last.beat ? `last seen ${ago(b.last.beat)}` : 'not running';
  if (b.state === 'stopping') return s.detail || 'finishing up';
  if (b.state === 'stuck') return 'no heartbeat';
  return 'one moment';
}
function updateBotPill(b) {
  const busy = (b.status?.tables || []).some(t => t.busy);
  $('#botdot').className = `dot ${b.state === 'online' && busy ? 'busy' : b.state}`;
  $('#botword').textContent = `Bot ${BOTWORD[b.state] || b.state}`;
  $('#botsub').textContent = b.state === 'online' && busy ? 'resolving a turn...' : botLine(b);
}

function handleTasks(tasks) {
  for (const t of tasks) {
    const seen = S.tasks[t.id];
    if (!seen && t.state === 'running' && !t.quiet) S.tasks[t.id] = { el: toast(t.label + '...', 'busy', '', 0), state: t.state };
    else if (!seen) S.tasks[t.id] = { state: 'shown' };
    const rec = S.tasks[t.id];
    if (rec.state === 'running' && t.state !== 'running') {
      rec.el?.remove();
      rec.state = t.state;
      if (t.state === 'done') toast(doneText(t), 'ok', typeof t.result === 'string' ? t.result : '');
      else toast(`${t.label} failed`, 'bad', t.error || '', 10000);
      if (t.kind.startsWith('jobs:') || t.kind === 'backup') refresh(true);
    } else if (!seen && t.state !== 'running') rec.state = t.state;
  }
}
const doneText = t => t.kind === 'bot' ? (t.result === 'restarted' ? 'The bot restarted' : 'The bot is starting')
  : t.kind === 'backup' ? 'Backup written' : t.kind === 'spend' ? 'Spend tallied'
  : t.kind.startsWith('jobs:') ? 'Read the story for jobs' : `${t.label} - done`;

async function poll() {
  try {
    const s = await get('status');
    if (S.gone) { S.gone = false; $('#view').style.opacity = ''; S.goneToast?.remove(); toast('Reconnected', 'ok'); hello(); }
    const prev = S.status;
    S.status = s;
    updateBotPill(s.bot);
    handleTasks(s.tasks);
    $('#relaunch').style.display = s.server?.stale ? '' : 'none';    // (newer engine code on disk than this server)
    if (prev && prev.bot.state !== s.bot.state) {
      if (s.bot.state === 'online') toast('The bot is online', 'ok', s.bot.status?.user || '');
      if (s.bot.state === 'offline' && prev.bot.state !== 'starting') toast('The bot has stopped', '', '');
      if (s.bot.state === 'offline' && prev.bot.state === 'starting') toast('The bot exited while starting', 'bad', 'See the log on the Bot page.', 9000);
    }
    const names = Object.keys(s.stamp).sort().join();
    if (S.stampNames !== undefined && names !== S.stampNames) loadCampaigns();
    S.stampNames = names;
    const st = s.stamp[S.campaign];
    if (S.stamp !== null && st !== S.stamp && ['overview', 'story', 'people'].includes(S.view)) refresh(true);
    if (S.stamp !== null && st !== S.stamp && S.view === 'memory')   // a new turn: the 3D view reloads in place, camera kept
      $('#memframe')?.contentWindow?.postMessage({ type: 'rp-refresh' }, location.origin);
    S.stamp = st;
    if (S.view === 'bot') botLive(s.bot);
  } catch (e) {
    if (!S.gone) {                                      // (it keeps trying every few seconds and picks up a relaunch)
      S.gone = true;
      $('#view').style.opacity = '.35';
      S.goneToast = toast('Lost the dashboard server - reconnecting...', 'bad',
                          'If it doesn\'t come back, open RoleplayEngine again; this window will pick it up.', 0);
    }
  }
}
const hello = () => post('hello').catch(() => {});

// ── routing ───────────────────────────────────────────────────────────
function parseHash() {
  const [view, a, b] = location.hash.replace(/^#/, '').split('/');
  return { view: VIEWS.includes(view) ? view : 'overview', a, b };
}
async function route() {
  const { view, a, b } = parseHash();
  if (view !== S.view) { stopLog(); S.data = {}; }
  S.view = view;
  $$('.nav a.item').forEach(x => x.classList.toggle('on', x.dataset.view === view));
  if (view === 'story') { if (a) S.story.scene = +a; S.story.turn = b ? +b : null; }
  if (!S.campaign && !['spend', 'bot', 'flags'].includes(view)) {
    return render(`<div class="wrap"><section class="panel"><div class="empty"><b>No campaigns yet.</b> Start the bot and type
      <b>!rp start &lt;world&gt;</b> in a Discord channel, or run <b>python -m roleplay demo --new</b>.</div></section></div>`);
  }
  if (view === 'memory' && $('#memframe')) { try { await memoryPage(); } catch (e) { console.error(e); } return; }   // (keep the flight)
  loading();
  try { await PAGES[view](); } catch (e) { console.error(e); failed(e); }
}
async function refresh(quiet = false) {
  const v = $('#view');
  const top = v.scrollTop;
  const inner = $('.transcript', v)?.scrollTop;
  try { await PAGES[S.view](quiet); } catch (e) { if (!quiet) failed(e); return; }
  if (quiet) { v.scrollTop = top; if (inner !== undefined && $('.transcript', v)) $('.transcript', v).scrollTop = inner; }
}

// ── the atlas: the city as the story has filled it in (Leaflet) ────────
const ATLAS_TILES = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';     // (no key; darkened in CSS to suit the night)
const ATLAS_LEGEND = `<div class="atlas-legend">
  <span><i style="background:#fff;box-shadow:0 0 0 2px var(--amber)"></i>where the party is</span>
  <span><i style="background:var(--amber)"></i>places they've been</span><span><i style="background:#b99554"></i>heard of</span>
  <span class="gm-hide"><i style="background:var(--magenta)"></i>unknown to them</span>
  <span><i style="background:var(--cyan);border-radius:2px;height:3px;width:14px"></i>the road so far</span>
  <span class="gm-hide"><i style="background:var(--violet);border-radius:3px"></i>NPCs offscreen</span></div>`;
function meters(a, b) {
  const R = 6371000, r = Math.PI / 180;
  const h = Math.sin((b.lat - a.lat) * r / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin((b.lon - a.lon) * r / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function travel(m) {                 // the same words the GM gets (engine/geo.py how_far): nobody counts minutes
  const far = m < 60 ? 'right here' : m < 400 ? 'a short walk' : m < 1500 ? 'a walk, or a quick drive'
    : m < 6000 ? 'a short drive' : m < 20000 ? 'across town' : 'the far side of the metroplex';
  if (m < 60) return far;
  return `${m < 1000 ? `${Math.round(m / 10) * 10} m` : `${(m / 1000).toFixed(1)} km`} · ${far}`;
}

class Atlas {
  constructor(el, { page = false, onPick = null } = {}) {
    Object.assign(this, { el, page, onPick, d: null, fitted: false, base: null, picked: null });
    this.map = L.map(el, { zoomSnap: 0.5, zoomDelta: 0.5, minZoom: 8, maxZoom: 18, scrollWheelZoom: page });
    if (!page) {                     // on the overview the page scrolls - click into the map to wheel-zoom it
      this.map.on('click', () => this.map.scrollWheelZoom.enable());
      el.addEventListener('mouseleave', () => this.map.scrollWheelZoom.disable());
    }
    L.tileLayer(ATLAS_TILES, { maxZoom: 19, className: 'atlas-tiles',
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(this.map);
    this.g = Object.fromEntries(['districts', 'trail', 'places', 'people', 'party'].map(k => [k, L.layerGroup().addTo(this.map)]));
    this.map.on('zoomend', () => this.zoomed());
    this.map.setView([47.6, -122.33], 10);
    this.zoomed();
  }
  async load(campaign) {
    this.d = await get('atlas', { c: campaign });
    this.draw();
    if (!this.fitted) { this.fit(); this.fitted = true; }
    return this.d;
  }
  zoomed() {                         // the painted Sixth World up high, the streets as you close in
    const z = this.map.getZoom();
    this.el.classList.toggle('z-far', z < 12.5);
    this.el.classList.toggle('z-near', z >= 13.5);
    if (this.base) this.base.setOpacity(z <= 11 ? 0.85 : z >= 13.5 ? 0 : 0.85 * (13.5 - z) / 2.5);
  }
  invalidate() { setTimeout(() => this.map.invalidateSize(), 60); }
  destroy() { this.map.remove(); }
  fit() {
    const pts = [...this.d.places.filter(p => S.spoilers || !p.gm), ...this.d.party].map(p => [p.lat, p.lon]);
    if (!pts.length) return this.map.setView([47.6, -122.33], 10);
    if (pts.length === 1) return this.map.setView(pts[0], 14);
    this.map.fitBounds(L.latLngBounds(pts).pad(0.35), { maxZoom: 15 });
  }
  pick(id, fly = false) {
    this.picked = id;
    this.draw();
    const p = this.d?.places.find(x => x.id === id) || null;
    if (p && fly) this.map.flyTo([p.lat, p.lon], Math.max(this.map.getZoom(), 15), { duration: 0.8 });
    if (this.onPick) this.onPick(p);
  }
  repick() { this.onPick?.(this.d?.places.find(x => x.id === this.picked && (S.spoilers || !x.gm)) || null); }
  draw() {
    const d = this.d;
    if (!d) return;
    Object.values(this.g).forEach(g => g.clearLayers());
    if (d.base && !this.base) {
      const b = d.base.bounds;
      this.base = L.imageOverlay(d.base.url, [[b.south, b.west], [b.north, b.east]], { className: 'atlas-base', interactive: false })
        .addTo(this.map);
      this.zoomed();
    }
    for (const x of d.districts) {
      L.circle([x.lat, x.lon], { radius: x.radius, color: '#50dcff', weight: 1, opacity: 0.16, fillOpacity: 0.025,
        interactive: false, className: 'district-ring' }).addTo(this.g.districts);
      L.marker([x.lat, x.lon], { icon: L.divIcon({ className: '', html: `<div class="district-label${x.radius < 1000 ? ' small' : ''}">${esc(x.name)}</div>`,
        iconSize: [0, 0] }), interactive: false, keyboard: false }).addTo(this.g.districts);
    }
    const order = {};                 // the order the story reached each place
    d.trail.forEach((t, i) => { if (!(t.place in order)) order[t.place] = i + 1; });
    if (d.trail.length > 1) {
      const pts = d.trail.map(t => [t.lat, t.lon]);
      L.polyline(pts, { color: '#50dcff', weight: 9, opacity: 0.1, interactive: false }).addTo(this.g.trail);
      L.polyline(pts, { color: '#50dcff', weight: 2.5, opacity: 0.85, dashArray: '6 8', interactive: false }).addTo(this.g.trail);
    }
    for (const p of d.places.filter(p => S.spoilers || !p.gm)) {
      const cls = ['pin', p.current && 'current', p.gm ? 'gm' : !p.visited && 'known', this.picked === p.id && 'on'].filter(Boolean).join(' ');
      const m = L.marker([p.lat, p.lon], { riseOnHover: true, title: p.name, icon: L.divIcon({ className: '', iconSize: [22, 22],
        iconAnchor: [11, 11], html: `<div class="${cls}"><i></i>${p.fights.length ? '<b>⚔</b>' : ''}</div>` }) });
      m.bindTooltip(`${order[p.id] ? `<span class="n">${order[p.id]}</span>` : ''}${esc(p.name)}`,
        { permanent: true, direction: 'right', offset: [8, 0], className: `pin-label${p.current ? ' always' : ''}${p.gm ? ' gm' : ''}` });
      m.on('click', () => this.pick(p.id));
      m.addTo(this.g.places);
    }
    const crews = {};                 // the party: their faces, stacked, where they stand
    for (const pc of d.party) (crews[`${pc.lat},${pc.lon}`] ||= []).push(pc);
    for (const crew of Object.values(crews)) {
      const w = 26 + Math.min(4, crew.length) * 24;
      const m = L.marker([crew[0].lat, crew[0].lon], { zIndexOffset: 1000, title: crew.map(c => c.name).join(', '),
        icon: L.divIcon({ className: '', iconSize: [w, 40], iconAnchor: [w / 2, 52],
          html: `<div class="party-pin">${crew.slice(0, 4).map(pc => portrait(pc.portrait, pc.name)).join('')}</div>` }) });
      m.bindTooltip(crew.map(c => `<b>${esc(c.name)}</b>${c.player ? ` <span class="muted">(${esc(c.player)})</span>` : ''}`).join('<br>'),
        { direction: 'top', offset: [0, -50] });
      m.on('click', () => crew[0].place && this.pick(crew[0].place));
      m.addTo(this.g.party);
    }
    const seen = {};                  // people out in the world (GM eyes): fanned out when several share a spot
    for (const n of d.people.filter(n => !n.with_party && (S.spoilers || !n.gm))) {
      const k = `${n.lat.toFixed(3)},${n.lon.toFixed(3)}`;
      const i = (seen[k] = (seen[k] ?? -1) + 1), ang = i * 2.4, r = i ? 18 + 7 * Math.sqrt(i) : 0;
      const m = L.marker([n.lat, n.lon], { title: n.name, icon: L.divIcon({ className: '', iconSize: [30, 30],
        iconAnchor: [15 - r * Math.cos(ang), 15 - r * Math.sin(ang)],
        html: `<div class="npc-pin ${n.gm ? 'gm' : ''}">${portrait(n.portrait, n.name)}</div>` }) });
      m.bindTooltip(`<b>${esc(n.name)}</b>${n.doing ? `<br><span class="muted">${esc(n.doing)}</span>` : ''}`,
        { direction: 'top', offset: [0, -14] });
      if (n.place) m.on('click', () => this.pick(n.place));
      m.addTo(this.g.people);
    }
  }
}

function placePopup(p) {
  return `${p.art ? `<img class="popup-art" src="${esc(p.art)}" alt="">` : ''}<b style="font-size:15px">${esc(p.name)}</b>
    <div class="small muted">${esc(p.district || '')}${p.current ? ' · <span style="color:var(--green)">the party is here</span>' : ''}</div>
    <div class="small" style="margin-top:6px">${p.visited ? `${p.scenes.length} scene${p.scenes.length > 1 ? 's' : ''} here` : 'never been'}${p.fights.length ? ` · ⚔ ${p.fights.length}` : ''}</div>
    <div style="margin-top:8px"><a href="#map/${encodeURIComponent(p.id)}">Open on the map →</a></div>`;
}
function placeSide(p, d) {
  const here = [...d.party.filter(x => x.place === p.id).map(x => ({ ...x, pc: true })), ...d.people.filter(x => x.place === p.id)];
  const crew = d.party[0];
  const dist = crew && crew.place !== p.id ? travel(meters(crew, p)) : null;
  const n = (k, w) => `${k} ${w}${k === 1 ? '' : 's'}`;
  return `${p.art ? `<img class="banner" src="${esc(p.art)}" alt="">` : ''}
    <div class="eyebrow">${esc(p.district || 'Seattle')}</div><h2>${esc(p.name)}</h2>
    <div class="row" style="margin:8px 0 10px">${p.current ? '<span class="chip green">the party is here</span>' : ''}
      ${p.visited ? `<span class="chip cyan">${n(p.scenes.length, 'scene')}</span>` : '<span class="chip">never been</span>'}
      ${p.fights.length ? `<span class="chip red">⚔ ${n(p.fights.length, 'fight')}</span>` : ''}${p.gm ? '<span class="chip magenta">unknown to them</span>' : ''}</div>
    ${dist ? `<div class="small muted">From the party: ${dist}</div>` : ''}
    ${p.description ? `<p class="muted" style="margin:10px 0 0;line-height:1.55">${esc(p.description)}</p>` : ''}
    ${here.length ? `<h3>Here now</h3><div class="row">${here.map(h => `<span class="chip ${h.pc ? 'magenta' : h.gm ? 'gm-hide' : 'cyan'}">${esc(h.name)}</span>`).join('')}</div>` : ''}
    ${p.scenes.length ? `<h3>What happened here</h3>${p.scenes.map(sc => `<a class="scene-link" href="#story/${sc.id}">${esc(sc.title)}
      <small>${sc.turns ? n(sc.turns, 'turn') : 'nothing played yet'}${sc.session ? ` · session ${sc.session}` : ''}${sc.status === 'active' ? ' · <b style="color:var(--green)">now</b>' : ''}${sc.at ? ` · ${ago(sc.at)}` : ''}</small></a>`).join('')}` : ''}
    ${p.fights.length ? `<h3>Fights</h3>${p.fights.map(f => `<div class="small" style="margin-bottom:6px">⚔ ${f.status === 'active' ? '<b style="color:var(--red)">going on now</b>' : esc(f.outcome || 'it ended')} <span class="faint">· ${n(f.rounds, 'round')}</span></div>`).join('')}` : ''}
    ${p.facts.length ? `<h3>What's known</h3>${p.facts.map(f => `<div class="small ${f.gm ? 'gm-hide' : ''}" style="margin-bottom:7px;line-height:1.5">${f.gm ? '<span class="chip magenta">GM</span> ' : ''}${esc(f.text)}</div>`).join('')}` : ''}
    <div style="margin-top:18px"><button class="btn sm ghost" id="atlas-back">← Every place</button></div>`;
}
function placeList(d, q) {
  q = (q || '').toLowerCase();
  const ps = d.places.filter(p => (S.spoilers || !p.gm) && (!q || `${p.name} ${p.district || ''}`.toLowerCase().includes(q)))
    .sort((a, b) => (b.current - a.current) || ((b.last_at || 0) - (a.last_at || 0)) || a.name.localeCompare(b.name));
  return ps.map(p => `<div class="place-row" data-place="${esc(p.id)}">${portrait(p.art, p.name)}<div style="min-width:0">
      <b>${esc(p.name)}</b><small>${esc(p.district || '')}${p.visited ? ` · ${p.scenes.length} scene${p.scenes.length > 1 ? 's' : ''}` : ' · never been'}
      ${p.current ? ' · <span style="color:var(--green)">party here</span>' : ''}${p.gm ? ' · <span style="color:var(--magenta)">unknown to them</span>' : ''}</small></div></div>`).join('')
    || '<div class="empty">No places on the map yet - they appear as the story goes.</div>';
}
function mountAtlas(slot, key, opts) {
  if (!window.L) {
    slot.outerHTML = '<div class="atlas"><div class="atlas-off">The map needs its library from the internet (Leaflet) - check the connection, then refresh.</div></div>';
    return null;
  }
  let a = S[key];
  if (a && a.campaign !== S.campaign) { a.atlas.destroy(); a = S[key] = null; }
  if (!a) {
    const el = document.createElement('div');
    el.className = 'atlas';
    a = S[key] = { el, campaign: S.campaign, atlas: null };
  }
  slot.replaceWith(a.el);
  if (!a.atlas) a.atlas = new Atlas(a.el, opts);
  else a.atlas.onPick = opts.onPick;
  a.atlas.invalidate();
  return a.atlas;
}
async function mapPage() {
  crumbs(S.head);
  render('<div class="atlas-page"><div id="atlas-slot"></div><aside class="atlas-side" id="atlas-side"></aside></div>', true);
  let atlas = null;
  const side = p => {
    const box = $('#atlas-side');
    if (!box || !atlas?.d) return;
    const d = atlas.d;
    if (p) {
      if (S.view === 'map') history.replaceState(null, '', `#map/${encodeURIComponent(p.id)}`);
      box.innerHTML = placeSide(p, d);
      $('#atlas-back', box).onclick = () => { atlas.picked = null; atlas.draw(); side(null); history.replaceState(null, '', '#map'); };
      return;
    }
    const known = d.places.filter(x => !x.gm), been = known.filter(x => x.visited);
    box.innerHTML = `<div class="eyebrow">The city so far</div><h2 style="margin-bottom:6px">${esc(S.head?.title || S.campaign)}</h2>
      <div class="small muted" style="margin-bottom:14px">${been.length} place${been.length === 1 ? '' : 's'} visited · ${known.length} on the map${d.trail.length > 1 ? ` · ${d.trail.length} stops on the road` : ''}</div>
      <input class="atlas-search" id="atlas-q" placeholder="Find a place..." value="${esc(S.atlasQ || '')}">
      <div id="atlas-list">${placeList(d, S.atlasQ)}</div><h3>Legend</h3>${ATLAS_LEGEND}`;
    const wire = () => $$('[data-place]', box).forEach(r => r.onclick = () => { atlas.pick(r.dataset.place, true); history.replaceState(null, '', `#map/${encodeURIComponent(r.dataset.place)}`); });
    $('#atlas-q', box).oninput = e => { S.atlasQ = e.target.value; $('#atlas-list', box).innerHTML = placeList(d, S.atlasQ); wire(); };
    wire();
  };
  atlas = mountAtlas($('#atlas-slot'), 'atlasPage', { page: true, onPick: side });
  if (!atlas) return;
  try { await atlas.load(S.campaign); } catch (e) { $('#atlas-side').innerHTML = `<div class="empty">Couldn't load the map: ${esc(e.message)}</div>`; return; }
  if (S.view !== 'map') return;
  const { a: placeId } = parseHash();
  if (placeId && placeId !== atlas.picked) atlas.pick(decodeURIComponent(placeId), true);
  else atlas.repick();
}

// ── overview ──────────────────────────────────────────────────────────
function monitors(p) {
  const row = (label, [dmg, max], cls) => max ? `<div class="monitor"><em>${label}</em>${Array.from({ length: max },
    (_, i) => `<i class="${i < dmg ? cls : ''}"></i>`).join('')}</div>` : '';
  return `<div class="monitors">${row('Phys', p.physical, 'p')}${row('Stun', p.stun, 's')}</div>`;
}
const fly = (id, what = 'them') => id ? `<a class="fly" href="#memory/${encodeURIComponent(id)}" title="Fly to ${esc(what)} in the 3D memory graph">3D</a>` : '';
function pcCard(p) {
  const tag = [p.metatype, title(p.role)].filter(Boolean).join(' · ');
  return `<div class="pc">${portrait(p.portrait, p.name)}<div>
    <div class="name">${esc(p.name)} ${fly(p.id, p.name)}<small>${esc(tag)}</small></div>
    <div class="who">${p.discord_name ? 'played by ' + esc(p.discord_name) : p.player ? 'seat: ' + esc(p.player) : 'nobody at the table yet'}
      ${p.condition !== 'ok' ? ` <span class="chip ${p.condition}">${p.condition}</span>` : ''}</div>
    ${monitors(p)}
    <div class="stats"><span>Karma <b>${p.karma}</b></span><span><b>${nuyen(p.nuyen)}</b></span><span>Essence <b>${p.essence}</b></span>
      ${p.magic ? `<span>Magic <b>${p.magic}</b></span>` : ''}${p.resonance ? `<span>Resonance <b>${p.resonance}</b></span>` : ''}</div>
  </div></div>`;
}
function jobPanel(d) {
  const j = d.job;
  const earlier = d.jobs.filter(x => !j || x.id !== j.id).slice(0, 5);
  let body;
  if (j) {
    body = `<div class="row" style="margin-bottom:10px"><span class="chip ${j.status}">${j.status === 'offered' ? 'on the table' : j.status}</span>
        <span class="faint small">${esc(j.id)} · since turn ${j.created_turn}${j.updated_turn > j.created_turn ? ` · moved turn ${j.updated_turn}` : ''}</span></div>
      <h3 class="job-title">${esc(j.title)}</h3>
      ${j.client ? `<div class="client">${portrait(j.client.portrait, j.client.name)}<div><b>${esc(j.client.name)}</b><small>Client</small></div></div>` : ''}
      <dl class="facts">${fact('Objective', j.objective)}${fact('Pay', j.pay)}${fact('Deadline', j.deadline)}${fact('Lately', j.progress)}</dl>`;
  } else if (!d.jobs.length && d.turns.total) {
    body = `<div class="empty"><b>No job on the books.</b> This world was played before the job tracker existed - it can read the story once to find them.</div>
      <div class="row" style="margin-top:12px"><button class="btn primary sm" data-act="backfill">Read the story for jobs</button>
      <span class="faint small">one Haiku pass over the memories · about a cent</span></div>`;
  } else {
    body = `<div class="empty"><b>Between jobs.</b> ${d.jobs.length ? 'No run is open right now.'
      : 'No job has come up yet - the memory pass files one the moment a fixer pitches it.'}</div>`;
  }
  const hist = earlier.length ? `<div class="history"><div class="small faint" style="letter-spacing:1.6px;text-transform:uppercase">Track record</div>
    ${earlier.map(x => `<div class="h"><span>${esc(x.title)}</span><span class="chip ${x.status}">${x.status}</span></div>`).join('')}</div>` : '';
  return panel('Current run', body + hist);
}
function fightPanel(d) {
  const f = d.fight;
  if (!f || f.status !== 'active') return '';
  const by = side => f.who.filter(w => w.side === side);
  const chips = (list, cls) => list.map(w => `<span class="chip ${w.condition !== 'ok' ? w.condition : cls}">${esc(w.name)} · ${esc(w.zone)}</span>`).join('');
  return panel(`Fight · round ${f.round + 1}`, `<div class="grid wide-left">
      <div>${f.map ? `<img class="fightmap" src="${esc(f.map)}" alt="The battle map">` : '<div class="empty">The battle map appears here once the bot draws it.</div>'}</div>
      <div><div class="small faint">RUNNERS</div><div class="roster">${chips(by('runners'), 'green') || '<span class="muted small">-</span>'}</div>
        <div class="small faint" style="margin-top:12px">HOSTILE</div><div class="roster">${chips(by('hostile'), 'red') || '<span class="muted small">-</span>'}</div>
        <div class="small faint" style="margin-top:12px">EVERYONE ELSE</div><div class="roster">${chips(f.who.filter(w => !['runners', 'hostile'].includes(w.side)), '') || '<span class="muted small">-</span>'}</div></div>
    </div>`, '', '');
}
function threadsPanel(d) {
  const open = d.tensions.filter(t => t.status === 'open');
  let body = open.length ? `<div class="threads">${open.slice(0, 5).map(t => `<div class="thread">
      <div class="q">${esc(t.question)}</div>
      <div class="bar"><i style="width:${Math.max(4, Math.min(100, t.pressure / 3 * 100))}%"></i></div>
      <div class="meta"><span>pressure ${t.pressure.toFixed(1)}</span><span>stakes ${'●'.repeat(t.stakes)}${'○'.repeat(Math.max(0, 3 - t.stakes))}</span>
        <span class="faint">${esc(t.id)}</span></div>
      ${t.public ? `<div class="small muted" style="margin-top:5px">${esc(t.public)}</div>` : ''}
      ${t.gm.next ? `<div class="gm-note gm-only">Next pressure point: ${esc(t.gm.next)}</div>` : ''}</div>`).join('')}</div>`
    : `<div class="empty">No open threads. The GM opens one when the story raises a question it means to come back to.</div>`;
  if (d.gm.agendas.length) body += `<div class="gm-hide" style="margin-top:18px"><div class="panel-head"><h2>Moving offscreen</h2><span class="chip magenta">GM eyes</span></div>
    ${d.gm.agendas.slice(0, 6).map(a => `<div class="small" style="margin-bottom:7px"><b>${esc(a.who)}</b> <span class="muted">${esc(a.goal)}</span></div>`).join('')}</div>`;
  return panel('Open threads', body);
}
function turnRow(t) {
  const said = t.inputs.map(i => `<b>${esc(i.name)}</b> ${esc(clip(i.text, 100))}`).join(' · ') || '<span class="muted">(the world moved on)</span>';
  const gm = esc(clip(plain(t.narration), 260));
  return `<div class="turnrow" data-scene="${t.scene_id}" data-turn="${t.id}" title="Read it in the story">
    <div class="n">T${t.id}<small>${ago(t.at)}</small></div>
    <div>${t.private ? `<span class="chip magenta">whisper · ${esc(t.private)}</span> ` : ''}
      <div class="said ${t.private ? 'gm-only' : ''}">${said}</div><div class="gmline ${t.private ? 'gm-only' : ''}">${gm}</div></div>
    <div class="cost">${money(t.cost)}</div></div>`;
}
async function overviewPage() {
  const d = await get('overview', { c: S.campaign });
  if (S.view !== 'overview') return;
  S.data.overview = d;
  S.head = d;
  crumbs(d);
  const t = d.turns, active = d.players.filter(p => p.active).length;
  const tableNote = d.table ? 'active in the last 10 min' : d.live ? (S.status?.bot.state === 'online' ? 'table opens on the first message' : 'the bot is offline') : 'not live in Discord';
  render(`<div class="wrap">
    <section class="hero ${d.scene?.art ? 'has-art' : ''}" ${d.scene?.art ? `style="--art:url('${esc(d.scene.art)}')"` : ''}>
      <div><div class="eyebrow">Session ${d.session} · ${esc(d.settings.difficulty)} · GM ${esc(d.settings.gm)}, ${esc(d.settings.effort)} effort</div>
        <h1>${esc(d.title)}</h1>
        <div class="scene">${d.scene ? `${esc(d.scene.title)}${d.scene.location ? ` <small>· ${esc(d.scene.location)}</small>` : ''}` : '<span class="muted">No scene yet</span>'}</div></div>
      <div class="hero-side"><div class="clock"><small>${esc(d.part_of_day)}</small>${esc(d.clock_short)}</div>
        ${d.live ? '<span class="livechip">Live in Discord</span>' : '<span class="livechip off">Not in Discord</span>'}</div>
    </section>
    <div class="tiles">
      ${tile('Turns', t.total.toLocaleString(), `${t.today ? `+${t.today} today · ` : ''}${t.session} this session`, 'cyan')}
      ${tile('Spend today', money(d.spend.today), `${money(d.spend.all)} on this world in all`, 'green')}
      ${tile('At the table', `${active}<span class="muted" style="font-size:19px">/${d.players.length}</span>`, tableNote)}
      ${tile('Cast', d.counts.cast.toLocaleString(), `${d.counts.nodes.toLocaleString()} memories · ${d.counts.scenes} scenes`)}
      ${tile('Last turn', t.last_at ? ago(t.last_at) : '—', t.last_at ? when(t.last_at) : 'no turns yet', 'amber')}
    </div>
    ${panel('The city', `<div id="atlas-slot"></div>${ATLAS_LEGEND}`, '<a href="#map">Open the map →</a>', 'atlas-panel')}
    <div class="grid two">${jobPanel(d)}${d.party.length ? panel('The crew', `<div class="crew">${d.party.map(pcCard).join('')}</div>`, '<a href="#people">Full sheets →</a>')
      : panel('The crew', '<div class="empty">No runners yet - players build one with <b>/newchar</b> or <b>!begin</b>.</div>')}</div>
    ${fightPanel(d)}
    <div class="grid wide-right">${threadsPanel(d)}${panel('Latest turns', d.recent.length ? `<div class="feed">${d.recent.map(turnRow).join('')}</div>`
      : '<div class="empty">No turns yet.</div>', d.recent.length ? '<a href="#story">Read the story →</a>' : '')}</div>
  </div>`);
  $$('.turnrow').forEach(r => r.onclick = () => { location.hash = `#story/${r.dataset.scene}/${r.dataset.turn}`; });
  const atlas = mountAtlas($('#atlas-slot'), 'atlasMini', { onPick: p => p && L.popup({ maxWidth: 300 })
    .setLatLng([p.lat, p.lon]).setContent(placePopup(p)).openOn(atlas.map) });
  if (atlas) atlas.load(S.campaign).catch(() => {});
  const bf = $('[data-act=backfill]');
  if (bf) bf.onclick = () => act(bf, () => post('jobs-backfill', { c: S.campaign }));
}

// ── story ─────────────────────────────────────────────────────────────
function turnBlock(t) {
  const said = t.inputs.map(i => `<div class="line"><b>${esc(i.name)}</b>${esc(i.text)}</div>`).join('');
  const body = `<div class="said">${said}</div><div class="prose">${prose(t.narration)}</div>`;
  return `<div class="turn" id="turn-${t.id}"><div class="turn-meta"><b>T${t.id}</b>${fly('T' + t.id, 'this turn')}<span>${when(t.at)}</span>
      ${t.session ? `<span>session ${t.session}</span>` : ''}<span>${money(t.cost)}</span></div>
    ${t.private ? `<div class="whisper"><div class="whisper-tag">🤫 A whisper from ${esc(t.private)}</div>
      <div class="player-only small muted" style="margin-top:6px">Hidden - turn on GM eyes to read it.</div><div class="gm-hide">${body}</div></div>` : body}</div>`;
}
async function storyPage(quiet) {
  const d = await get('story', { c: S.campaign, scene: S.story.scene });
  if (S.view !== 'story') return;
  S.data.story = d;
  S.story.scene = d.scene;
  crumbs(S.head);
  const sessions = {};
  for (const s of d.scenes) (sessions[s.session || 0] ||= []).push(s);
  const list = Object.entries(sessions).map(([n, ss]) => `<h3>${+n ? `Session ${n}` : 'Not played yet'}</h3>${ss.map(s =>
    `<button class="scene-btn ${s.id === d.scene ? 'on' : ''}" data-scene="${s.id}"><b>${esc(s.title)}</b>
      <small>${s.location ? esc(s.location) + ' · ' : ''}${s.turns} turn${s.turns === 1 ? '' : 's'}${s.status === 'active' ? ' · now' : ''}</small></button>`).join('')}`).join('');
  const sc = d.scenes.find(s => s.id === d.scene) || {};
  render(`<div class="story"><aside class="scenes">${list || '<div class="empty">No scenes yet.</div>'}</aside>
    <article class="transcript"><div class="transcript-in">
      <div class="scene-head"><div class="eyebrow">${sc.status === 'active' ? 'The scene now' : `Scene ${sc.id ?? ''}`}${sc.location ? ` · ${esc(sc.location)}` : ''}</div>
        <h2>${esc(sc.title || '')}</h2>${sc.summary ? `<p class="summary">${esc(sc.summary)}</p>` : ''}</div>
      ${d.more ? '<div style="margin-top:20px"><button class="btn sm" id="earlier">Load earlier turns</button></div>' : ''}
      <div id="turns">${d.turns.map(turnBlock).join('') || '<div class="empty">No turns in this scene yet.</div>'}</div>
    </div></article></div>`, true);
  $$('.scene-btn').forEach(b => b.onclick = () => { location.hash = `#story/${b.dataset.scene}`; });
  const earlier = $('#earlier');
  if (earlier) earlier.onclick = () => act(earlier, async () => {
    const first = d.turns[0]?.id;
    const more = await get('story', { c: S.campaign, scene: d.scene, before: first });
    const box = $('.transcript'), h = box.scrollHeight;
    $('#turns').insertAdjacentHTML('afterbegin', more.turns.map(turnBlock).join(''));
    d.turns = more.turns.concat(d.turns);
    box.scrollTop += box.scrollHeight - h;
    if (!more.more) earlier.remove();
  });
  if (!quiet) {
    const target = S.story.turn ? $(`#turn-${S.story.turn}`) : null;
    if (target) { target.scrollIntoView({ block: 'start' }); target.style.animation = 'rise .5s'; }
    else if (sc.status === 'active') $('.transcript').scrollTop = 1e9;
  }
}

// ── people ────────────────────────────────────────────────────────────
function sheet(p) {
  const attrs = Object.entries(p.attributes).filter(([k]) => !['magic', 'resonance', 'essence', 'edge'].includes(k));
  const pips = n => `<span class="pips">${Array.from({ length: Math.min(12, n) }, (_, i) => `<i class="on"></i>`).join('')}</span>`;
  return `<section class="panel"><div class="sheet">${portrait(p.portrait, p.name)}<div>
    <div class="row"><h3>${esc(p.name)}</h3>${fly(p.id, p.name)}${p.condition !== 'ok' ? `<span class="chip ${p.condition}">${p.condition}</span>` : ''}
      ${p.ledger ? '<span class="chip cyan" title="Checked out from the character ledger">ledger</span>' : ''}${p.status !== 'active' ? `<span class="chip">${esc(p.status)}</span>` : ''}</div>
    <div class="sub">${esc([p.metatype, title(p.role), p.pronouns].filter(Boolean).join(' · '))}${p.discord_name ? ` — played by ${esc(p.discord_name)}` : ''}</div>
    ${p.concept ? `<div class="small muted" style="margin:-4px 0 8px">${esc(p.concept)}</div>` : ''}
    <div class="grid wide-left" style="gap:22px"><div>
      <div class="attrs">${attrs.map(([k, v]) => `<div class="attr"><b>${v}</b><small>${k.slice(0, 3)}</small></div>`).join('')}</div>
      <div class="skills">${p.skills.map(([k, v]) => `<div class="skill"><span>${esc(title(k))}</span>${pips(v)}<b style="width:18px;text-align:right">${v}</b></div>`).join('')}</div>
    </div><div>
      ${monitors(p)}
      <div class="stats" style="margin-top:8px"><span>Karma <b>${p.karma}</b></span><span><b>${nuyen(p.nuyen)}</b></span><span>Essence <b>${p.essence}</b></span>
        <span>Edge <b>${p.edge}</b></span>${p.magic ? `<span>Magic <b>${p.magic}</b></span>` : ''}${p.resonance ? `<span>Resonance <b>${p.resonance}</b></span>` : ''}</div>
      <div class="gearlist">${p.gear.map(g => `<span class="chip plain">${esc(g.name)}${g.qty > 1 ? ` ×${g.qty}` : ''}</span>`).join('') || '<span class="muted small">No gear on file.</span>'}</div>
      ${p.description ? `<p class="small muted" style="margin:12px 0 0">${esc(p.description)}</p>` : ''}
    </div></div></div></div></section>`;
}
async function peoplePage() {
  const d = await get('people', { c: S.campaign });
  if (S.view !== 'people') return;
  crumbs(S.head);
  const players = d.players.length ? `<table class="t"><thead><tr><th>Player</th><th>Plays</th><th>Seat</th><th>Last turn</th><th class="num">Turns</th></tr></thead><tbody>
    ${d.players.map(p => `<tr><td><span class="row" style="gap:8px"><span class="dot ${p.active ? 'online' : ''}" title="${p.active ? 'active in the last 10 minutes' : ''}"></span><b>${esc(p.name)}</b></span></td>
      <td>${p.character ? esc(p.character.name) + (p.character.kind === 'npc' ? ' <span class="chip amber">NPC</span>' : '') : '<span class="muted">-</span>'}</td>
      <td>${p.building ? '<span class="chip cyan">building a runner</span>' : p.afk ? '<span class="chip">away</span>' : '<span class="chip green">playing</span>'}</td>
      <td class="muted">${p.last_turn ? `T${p.last_turn} · ${ago(p.last_at)}` : 'never'}</td><td class="num">${p.turns}</td></tr>`).join('')}</tbody></table>`
    : '<div class="empty">Nobody has joined this table yet - <b>!join</b> or <b>/join</b> in the game channel.</div>';
  const npcs = d.npcs.length ? `<div class="npcs">${d.npcs.map(n => {
    const att = Object.entries(n.gm.attitudes);
    return `<div class="npc ${['dead', 'gone'].includes(n.status) || n.condition === 'dead' ? 'dead' : ''}">${portrait(n.portrait, n.name)}<div style="min-width:0">
      <b>${esc(n.name)}</b> ${fly(n.id, n.name)}${n.condition !== 'ok' ? ` <span class="chip ${n.condition}">${n.condition}</span>` : ''}
      <p>${esc(n.description || '')}</p><div class="heat" title="How much the story is about them lately"><i style="width:${Math.min(100, n.heat * 25)}%"></i></div>
      ${att.length ? `<div class="gm-hide small" style="margin-top:6px">${att.map(([pc, v]) => `<span class="chip ${v > 0 ? 'green' : v < 0 ? 'red' : ''}">${esc(pc)} ${v > 0 ? '+' : ''}${v}</span>`).join(' ')}</div>` : ''}
    </div></div>`; }).join('')}</div>` : '<div class="empty">Nobody notable yet.</div>';
  const lib = d.library.length ? `<table class="t"><thead><tr><th>Runner</th><th>Owner</th><th>Where</th><th class="num">Karma</th><th class="num">Nuyen</th><th class="num">Stories</th></tr></thead><tbody>
    ${d.library.map(r => `<tr><td><span class="row" style="gap:10px">${portrait(r.portrait, r.name, 'mini')}<span><b>${esc(r.name)}</b><br><span class="small muted">${esc([r.metatype, title(r.role)].filter(Boolean).join(' · '))}</span></span></span></td>
      <td>${esc(r.owner || '')}${r.shared ? ' <span class="chip cyan">shared</span>' : ''}</td>
      <td>${r.campaign ? `<span class="chip ${r.campaign === S.campaign ? 'green' : 'amber'}">checked out · ${esc(r.campaign)}</span>` : '<span class="chip">on the shelf</span>'}</td>
      <td class="num">${r.karma}</td><td class="num">${nuyen(r.nuyen)}</td><td class="num">${r.stories}</td></tr>`).join('')}</tbody></table>`
    : '<div class="empty">The character ledger is empty - finished runners are saved there to play in other worlds.</div>';
  render(`<div class="wrap">
    ${panel('At the table', players)}
    ${d.party.length ? `<div class="panel-head" style="margin:6px 4px -6px"><h2>The crew</h2></div>${d.party.map(sheet).join('')}` : ''}
    ${panel('People they know', npcs, '<span class="faint small">hottest in the story first</span>')}
    ${panel('The character ledger', lib, '<span class="faint small">every runner, across every world</span>')}
  </div>`);
}

// ── spend ─────────────────────────────────────────────────────────────
function chartSvg(days, purposes) {
  const W = 1000, H = 230, L = 52, B = 26, T = 12, R = 8;
  const max = Math.max(0.05, ...days.map(d => d.total));
  const step = [0.05, 0.1, 0.25, 0.5, 1, 2, 2.5, 5, 10, 20, 25, 50, 100].find(s => max / s <= 4) || 200;
  const top = Math.ceil(max / step) * step;
  const y = v => H - B - (v / top) * (H - B - T);
  const bw = (W - L - R) / days.length;
  const order = Object.keys(PURPOSE_COLORS);
  let g = '';
  for (let v = 0; v <= top + 1e-9; v += step) g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#1e2b40"/>
    <text x="${L - 8}" y="${y(v) + 4}" fill="#55657e" font-size="11" text-anchor="end">${money(v, v < 1 ? 2 : 0)}</text>`;
  const bars = days.map((d, i) => {
    let acc = 0, out = '';
    const x = L + i * bw + bw * 0.16, w = bw * 0.68;
    for (const k of order) {
      const v = d.purposes[k];
      if (!v) continue;
      out += `<rect x="${x}" y="${y(acc + v)}" width="${w}" height="${Math.max(0.5, y(acc) - y(acc + v))}" fill="${PURPOSE_COLORS[k]}" rx="1.5"/>`;
      acc += v;
    }
    const label = (i % Math.ceil(days.length / 10) === 0 || i === days.length - 1)
      ? `<text x="${x + w / 2}" y="${H - 8}" fill="#55657e" font-size="11" text-anchor="middle">${day(d.day)}</text>` : '';
    return out + label + `<rect class="bar-hit" data-i="${i}" x="${L + i * bw}" y="${T}" width="${bw}" height="${H - B - T}"/>`;
  }).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" font-family="Bahnschrift, Segoe UI, sans-serif">${g}${bars}</svg>`;
}
function hbars(rows, labelOf, colorOf, total) {
  const max = Math.max(...rows.map(r => r.cost), 1e-9);
  return rows.map(r => `<div class="hbar"><span title="${esc(labelOf(r))}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(labelOf(r))}</span>
    <div class="track"><i style="width:${r.cost / max * 100}%;background:${colorOf(r)}"></i></div>
    <span class="num">${money(r.cost)}</span></div>`).join('');
}
async function spendPage() {
  const d = await get('spend', { c: S.spend.c, days: S.spend.days });
  if (S.view !== 'spend') return;
  crumbs(S.head);
  const P = d.purposes;
  const used = new Set(d.days.flatMap(x => Object.keys(x.purposes)));
  const legend = Object.keys(PURPOSE_COLORS).filter(k => used.has(k)).map(k => `<span><i style="background:${PURPOSE_COLORS[k]}"></i>${esc(P[k] || k)}</span>`).join('');
  const camps = d.by_campaign.map(c => `<tr><td><b>${esc(c.base)}</b>${c.archived ? ` <span class="chip">archived ${esc(c.archived.slice(0, 10))}</span>` : ''}</td>
      <td class="num">${money(c.month)}</td><td class="num"><b>${money(c.cost)}</b></td></tr>`).join('');
  const models = d.by_model.map(m => `<tr><td>${esc(m.key)}</td><td class="num">${m.calls.toLocaleString()}</td><td class="num">${money(m.month)}</td><td class="num"><b>${money(m.cost)}</b></td></tr>`).join('');
  const turns = d.top_turns.map(t => `<tr data-c="${esc(t.campaign)}" data-t="${t.turn}" style="cursor:pointer"><td>${esc(t.campaign)}</td><td>T${t.turn}</td>
      <td class="muted">${when(t.at)}</td><td class="num"><b>${money(t.cost)}</b></td></tr>`).join('');
  const options = [['', 'Every world']].concat([...new Set(d.by_campaign.map(c => c.base))].map(c => [c, c]))
    .map(([v, l]) => `<option value="${esc(v)}"${v === S.spend.c ? ' selected' : ''}>${esc(l)}</option>`).join('');
  render(`<div class="wrap">
    <div class="row"><div class="picker"><select id="spendc">${options}</select></div>
      <div class="seg" id="spendd">${[30, 60, 90].map(n => `<button data-d="${n}" class="${n === S.spend.days ? 'on' : ''}">${n} days</button>`).join('')}</div>
      <span class="faint small" style="margin-left:auto">${d.itemized_since ? `Itemized since ${when(d.itemized_since)} · earlier turns are whole-turn totals` : 'Nothing itemized yet - earlier turns are whole-turn totals'}</span></div>
    <div class="tiles spend">
      ${tile('Today', money(d.today), '', 'green')}${tile('Last 7 days', money(d.week), '')}${tile('This month', money(d.month), '', 'cyan')}
      ${tile('All time', money(d.all), `${(d.by_purpose.reduce((a, p) => a + p.calls, 0)).toLocaleString()} calls & turns`)}
      ${tile('Images', money(d.images.cost), `${d.images.count} painted · estimated`, 'amber')}
    </div>
    ${panel(`The last ${S.spend.days} days`, chartSvg(d.days, P) + `<div class="legend">${legend || '<span>Nothing spent in this window.</span>'}</div>`)}
    <div class="grid two">
      ${panel('What it went on', hbars(d.by_purpose, r => r.label, r => PURPOSE_COLORS[r.key] || '#8b9ab2') || '<div class="empty">Nothing yet.</div>')}
      ${panel('By world', camps ? `<table class="t"><thead><tr><th>World</th><th class="num">This month</th><th class="num">All time</th></tr></thead><tbody>${camps}</tbody></table>` : '<div class="empty">Nothing yet.</div>')}
    </div>
    <div class="grid two">
      ${panel('By model', models ? `<table class="t"><thead><tr><th>Model</th><th class="num">Calls</th><th class="num">This month</th><th class="num">All time</th></tr></thead><tbody>${models}</tbody></table>` : '<div class="empty">Nothing yet.</div>')}
      ${panel('Priciest turns', turns ? `<table class="t"><thead><tr><th>World</th><th>Turn</th><th>When</th><th class="num">Cost</th></tr></thead><tbody>${turns}</tbody></table>` : '<div class="empty">Nothing yet.</div>')}
    </div>
    <p class="foot">Model prices are the estimates in <b>roleplay/config.py</b> (PRICES); images are estimated per picture (IMAGE_PRICES) - OpenAI bills those
      on its own account. Spend is logged by every process that plays: the bot, the console table and the simulations.</p>
  </div>`);
  $('#spendc').onchange = e => { S.spend.c = e.target.value; refresh(); };
  $$('#spendd button').forEach(b => b.onclick = () => { S.spend.days = +b.dataset.d; refresh(); });
  $$('tr[data-t]').forEach(r => r.onclick = () => {
    if (S.campaigns.some(c => c.name === r.dataset.c)) { S.campaign = r.dataset.c; fillPicker(); S.story.scene = null; }
    location.hash = '#story';
  });
  const tip = $('#tip');
  $$('.chart .bar-hit').forEach(h => {
    h.onmousemove = e => {
      const x = d.days[+h.dataset.i];
      const rows = Object.entries(x.purposes).sort((a, b) => b[1] - a[1]).map(([k, v]) =>
        `<div class="r"><span><i style="display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:6px;background:${PURPOSE_COLORS[k] || '#888'}"></i>${esc(P[k] || k)}</span><span>${money(v)}</span></div>`).join('');
      tip.innerHTML = `<b>${day(x.day)} · ${money(x.total)}</b>${rows || '<div class="r"><span>nothing</span></div>'}`;
      tip.style.display = 'block';
      tip.style.left = Math.min(innerWidth - tip.offsetWidth - 12, e.clientX + 14) + 'px';
      tip.style.top = (e.clientY + 14) + 'px';
    };
    h.onmouseleave = () => { tip.style.display = 'none'; };
  });
}

// ── memory: the graph to fly through in 3D (or the flat browser) - roleplay/browser/static/graph3d.html ──
const memView = () => store.get('rp.memview') === '2d' ? '2d' : '3d';
async function memoryPage() {
  crumbs(S.head);
  const { a } = parseHash();                          // #memory/<node id>: open (or turn) the view to that node
  const focus = a ? decodeURIComponent(a) : '';
  const base = memView() === '2d' ? `/graph?c=${encodeURIComponent(S.campaign)}&embed=1`
    : `/graph3d?c=${encodeURIComponent(S.campaign)}&embed=1`;
  const fr = $('#memframe');
  if (fr && fr.dataset.base === base) {               // already flying this world: just turn to the node
    if (focus) fr.contentWindow?.postMessage({ type: 'rp-focus', id: focus }, location.origin);
    return;
  }
  const src = base + (focus && memView() === '3d' ? `&focus=${encodeURIComponent(focus)}` : '');
  render(`<iframe id="memframe" class="frame" title="Memory graph" allow="fullscreen; pointer-lock" allowfullscreen
    data-base="${esc(base)}" src="${esc(src)}"></iframe>`, true);
  $('#memframe').focus();
}
addEventListener('message', ev => {                   // from the graph pages in the Memory frame
  if (ev.origin !== location.origin || !ev.data || typeof ev.data !== 'object') return;
  if (ev.data.type === 'rp-view') {                   // their 2D / 3D buttons: remember the choice, switch
    store.set('rp.memview', ev.data.view === '2d' ? '2d' : '3d');
    if (S.view === 'memory') memoryPage();
  } else if (ev.data.type === 'rp-open' && typeof ev.data.hash === 'string' && ev.data.hash.startsWith('#')) {
    location.hash = ev.data.hash;                     // "read it in the story" from the 3D panel
  }
});

// ── bot ───────────────────────────────────────────────────────────────
function botState(b) {
  const s = b.status || {};
  const facts = [];
  if (s.user) facts.push(esc(s.user));
  if (b.state === 'online') facts.push(`${s.latency_ms ?? '?'} ms`, `up ${dur(b.uptime)}`);
  if (b.pid) facts.push(`pid ${b.pid}`);
  if (b.state === 'offline' && b.last?.beat) facts.push(`last heartbeat ${ago(b.last.beat)}`);
  const running = b.up;
  return `<div class="state"><span class="dot ${b.state}"></span><div><div class="big ${b.state}">${esc(BOTWORD[b.state] || b.state)}</div>
      <div class="muted" style="margin-top:6px">${facts.join(' · ') || 'The Discord bot is not running.'}</div></div></div>
    ${b.state === 'stopping' ? `<div class="banner warn">⏳ ${esc(s.detail || 'Finishing up')} - a turn in progress is allowed to finish.</div>` : ''}
    ${b.state === 'stuck' ? '<div class="banner bad">No heartbeat for a while - the bot may be frozen. Force stop it, then start it again.</div>' : ''}
    ${b.code_changed ? '<div class="banner info">The code changed since the bot started - restart it to load the update.<button class="btn sm primary" data-bot="restart">Restart now</button></div>' : ''}
    ${b.state === 'offline' && b.last?.last_error ? `<div class="banner bad">Last error: ${esc(b.last.last_error.what)}</div>` : ''}
    ${!b.token ? '<div class="banner bad">No bot token found - put discord_token in config.toml (copy config.example.toml) or set DISCORD_BOT_TOKEN.</div>' : ''}
    <div class="row" style="margin-top:18px">
      ${running ? '' : `<button class="btn go" data-bot="start">▶ Start the bot</button>`}
      ${running && b.state !== 'stopping' ? `<button class="btn primary" data-bot="restart">↻ Restart</button><button class="btn" data-bot="stop">■ Stop</button>` : ''}
      ${running && ['stopping', 'stuck', 'starting'].includes(b.state) ? '<button class="btn danger" data-bot="force">Force stop</button>' : ''}
      <label class="check"><input type="checkbox" id="announce" ${S.status?.prefs?.announce ? 'checked' : ''}> say hello in the game channel when it starts</label>
    </div>`;
}
function tablesPanel(b, bindings) {
  const live = Object.fromEntries((b.status?.tables || []).map(t => [t.channel_id, t]));
  const known = Object.fromEntries((b.last?.tables || []).map(t => [t.channel_id, t]));      // names from the last run
  const rows = Object.entries(bindings).map(([cid, bd]) => {
    const t = live[cid];
    const state = !b.up ? '<span class="chip">bot offline</span>' : !t ? '<span class="chip">opens on the next message</span>'
      : t.busy ? '<span class="chip amber">resolving a turn</span>' : t.queued.length ? `<span class="chip cyan">${t.queued.length} action${t.queued.length > 1 ? 's' : ''} queued</span>` : '<span class="chip green">waiting on players</span>';
    const k = t || b.status?.channels?.[cid] || known[cid];
    return `<tr><td><b>${k?.channel ? '#' + esc(k.channel) : 'channel …' + esc(cid.slice(-6))}</b><br><span class="small muted">${esc(k?.guild || '')}</span></td>
      <td>${esc(bd.campaign)}</td><td>${state}</td><td>${t ? (t.active_now.length ? t.active_now.map(h => `<span class="chip green">${esc(h)}</span>`).join(' ') : '<span class="muted">nobody lately</span>') : '-'}</td>
      <td class="num">${t ? money(t.spend) : '-'}</td></tr>`;
  }).join('');
  return rows ? `<table class="t"><thead><tr><th>Channel</th><th>World</th><th>Now</th><th>Active (10 min)</th><th class="num">Spent since start</th></tr></thead><tbody>${rows}</tbody></table>`
    : '<div class="empty">No channel is playing a world - type <b>!rp start &lt;world&gt;</b> in a Discord channel.</div>';
}
function logClass(l) {
  if (/traceback|error|exception|failed|fumbled|refused/i.test(l)) return 'e';
  if (/warn|⚠️|couldn't|timed out|retry/i.test(l)) return 'w';
  if (/^=====/.test(l)) return 'm';
  if (/logged in|commands ready|online/i.test(l)) return 'ok';
  if (/^\[[^\]]+\]/.test(l)) return 'i';
  return '';
}
function drawLog() {
  const box = $('#log');
  if (!box) return;
  const lines = S.log.filter === 'problems' ? S.log.lines.filter(l => ['e', 'w'].includes(logClass(l))) : S.log.lines;
  box.innerHTML = lines.slice(-1500).map(l => { const c = logClass(l); return c ? `<span class="${c}">${esc(l)}</span>` : esc(l); }).join('\n') || '<span class="m">(nothing yet)</span>';
  if (S.log.follow) box.scrollTop = box.scrollHeight;
}
async function pullLog() {
  try {
    const r = await get('log', { offset: S.log.offset ?? '' });
    if (r.reset) S.log.lines = [];
    if (r.text) {
      const parts = r.text.replace(/\r/g, '').split('\n');
      if (S.log.partial) parts[0] = S.log.partial + parts[0];
      S.log.partial = parts.pop();
      S.log.lines.push(...parts);
      if (S.log.lines.length > 4000) S.log.lines = S.log.lines.slice(-3000);
      drawLog();
    } else if (r.reset) drawLog();
    S.log.offset = r.offset;
  } catch (e) { /* the next poll tries again */ }
}
function stopLog() { clearInterval(S.log.timer); S.log.timer = null; }
function botLive(b) {
  const box = $('#botstate');
  if (!box) return;
  const sig = JSON.stringify([b.state, b.up, b.code_changed, b.status?.detail, Math.floor((b.uptime || 0) / 60), b.status?.latency_ms, b.pid]);
  if (box.dataset.sig !== sig) { box.dataset.sig = sig; box.innerHTML = botState(b); wireBot(); }
  const tb = $('#tables');
  if (tb && S.data.bot) { const html = tablesPanel(b, S.data.bot.bindings); if (tb.dataset.html !== html) { tb.dataset.html = html; tb.innerHTML = html; } }
}
function wireBot() {
  $$('[data-bot]').forEach(btn => btn.onclick = async () => {
    const what = btn.dataset.bot, announce = !!$('#announce')?.checked;
    if (what === 'start') return act(btn, () => post('bot/start', { announce }));
    if (what === 'stop' && await confirmBox('Stop the bot?', 'A turn being resolved finishes first. Anyone with an action still queued is told to post it again later. The game is offline until you start it.', 'Stop it'))
      return act(btn, () => post('bot/stop'), 'Stopping - finishing what is in flight');
    if (what === 'restart' && await confirmBox('Restart the bot?', 'It stops the polite way (a turn in progress finishes first), then starts again with the current code.', 'Restart'))
      return act(btn, () => post('bot/restart', { announce }));
    if (what === 'force' && await confirmBox('Force stop?', 'Ends the bot process right away. A turn half-resolved is lost - the next start rolls it back.', 'Force stop', true))
      return act(btn, () => post('bot/force'), 'Bot ended');
  });
  const an = $('#announce');
  if (an) an.onchange = () => post('prefs', { announce: an.checked }).then(p => { if (S.status) S.status.prefs = p; }).catch(e => toast(e.message, 'bad'));
}
async function botPage() {
  const d = await get('bot');
  if (S.view !== 'bot') return;
  S.data.bot = d;
  crumbs(S.head);
  const b = d.bot, st = d.setup, bk = d.backups;
  const check = (ok, yes, no) => ok ? `<span class="ok">✓</span> ${yes}` : `<span class="bad">✗</span> ${no}`;
  render(`<div class="wrap">
    <div class="grid wide-left">
      ${panel('Discord bot', `<div id="botstate"></div>`)}
      ${panel('Setup', `<dl class="kv">
          <dt>Config file</dt><dd>${check(st.config && !st.config_error, 'found: ' + esc(st.config), st.config_error ? esc(st.config_error) : 'no config.toml - copy config.example.toml, or use the environment variables')}</dd>
          <dt>Bot token</dt><dd>${check(st.token, 'found in ' + esc(st.token), 'not found - discord_token in config.toml, or DISCORD_BOT_TOKEN')}</dd>
          <dt>Anthropic key</dt><dd>${check(st.anthropic, 'set (' + esc(st.anthropic) + ')', 'missing - anthropic_api_key in config.toml, or ANTHROPIC_API_KEY; the GM can\'t think without it')}</dd>
          <dt>OpenAI key</dt><dd>${check(st.openai, 'set (' + esc(st.openai) + ') - portraits on', 'not set - no portraits (optional: openai_api_key in config.toml, or OPENAI_API_KEY)')}</dd>
          <dt>Worlds folder</dt><dd class="small">${esc(st.campaigns)} <a href="#" data-open="campaigns">open</a></dd>
        </dl>
        <label class="check" style="margin-top:14px"><input type="checkbox" id="autostart" ${d.prefs.autostart_bot ? 'checked' : ''}> start the bot when the dashboard opens</label>
        <div style="margin-top:12px"><button class="btn sm" id="strays">Check for other bot copies</button> <span id="straylist" class="small"></span></div>`)}
    </div>
    ${panel('Tables', `<div id="tables"></div>`)}
    <div class="grid wide-left">
      ${panel('Bot log', `<div class="row" style="margin-bottom:10px"><div class="seg" id="logf"><button data-f="all" class="${S.log.filter === 'all' ? 'on' : ''}">Everything</button>
          <button data-f="problems" class="${S.log.filter === 'problems' ? 'on' : ''}">Problems</button></div>
          <label class="check"><input type="checkbox" id="follow" ${S.log.follow ? 'checked' : ''}> follow</label>
          <a href="#" data-open="log" style="margin-left:auto" class="small">open the file</a></div><div class="log" id="log"></div>`)}
      ${panel('Backups', `<dl class="kv"><dt>Last backup</dt><dd>${bk.last ? `${ago(bk.last)} <span class="muted small">(${when(bk.last)})</span>` : '<span class="warnc">never</span>'}</dd>
          <dt>Schedule</dt><dd>daily while the bot runs · keeps ${bk.keep}</dd><dt>Folder</dt><dd class="small">${esc(bk.dir)} <a href="#" data-open="backups">open</a></dd></dl>
        <div style="margin:14px 0"><button class="btn primary sm" id="backup">Back up now</button></div>
        ${bk.files.length ? `<table class="t"><tbody>${bk.files.slice(0, 8).map(f => `<tr><td class="small">${esc(f.name)}</td><td class="small muted">${ago(f.at)}</td>
          <td class="num small">${(f.size / 1e6).toFixed(1)} MB</td></tr>`).join('')}</tbody></table>` : ''}`)}
    </div>
  </div>`);
  botLive(b);
  $('#autostart').onchange = e => post('prefs', { autostart_bot: e.target.checked }).then(() => toast(e.target.checked ? 'The bot will start with the dashboard' : 'The bot won\'t start by itself', 'ok')).catch(x => toast(x.message, 'bad'));
  $('#backup').onclick = e => act(e.currentTarget, () => post('backup'));
  $$('[data-open]').forEach(a => a.onclick = ev => { ev.preventDefault(); post('open', { what: a.dataset.open }).catch(x => toast(x.message, 'bad')); });
  $$('#logf button').forEach(btn => btn.onclick = () => { S.log.filter = btn.dataset.f; $$('#logf button').forEach(x => x.classList.toggle('on', x === btn)); drawLog(); });
  $('#follow').onchange = e => { S.log.follow = e.target.checked; if (S.log.follow) drawLog(); };
  $('#log').onscroll = e => { const el = e.target; const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    if (!atEnd && S.log.follow) { S.log.follow = false; $('#follow').checked = false; } };
  $('#strays').onclick = e => act(e.currentTarget, async () => {
    const r = await get('strays');
    $('#straylist').innerHTML = r.strays.length ? r.strays.map(s => `<span class="warnc">pid ${s.pid}</span> <button class="btn sm danger" data-kill="${s.pid}">Stop it</button>`).join(' ')
      : '<span class="ok">none - just this one</span>';
    $$('[data-kill]').forEach(k => k.onclick = async () => {
      if (await confirmBox('Stop that copy?', `Process ${k.dataset.kill} is a bot started outside the dashboard. Two copies answer every message twice.`, 'Stop it', true))
        act(k, () => post('bot/kill', { pid: +k.dataset.kill }), 'Stopped');
    });
  });
  S.log.offset = null; S.log.lines = []; S.log.partial = '';
  await pullLog();
  stopLog();
  S.log.timer = setInterval(pullLog, 2000);
}

// ── flags: what went wrong - the GM's `flag:` lines, !reportbug, and what the engine noticed (roleplay/flags.py) ──
const FLAG_SOURCES = { gm: ['GM', 'violet'], player: ['Player', 'cyan'], engine: ['Engine', 'amber'] };
async function flagsPage() {
  const d = await get('flags', { status: S.flags.status, c: S.flags.c });
  if (S.view !== 'flags') return;
  crumbs(S.head);
  const n = d.counts.by_status || {}, open = d.counts.open_by_source || {};
  const ctx = c => !c ? '' : Object.entries(c).filter(([, v]) => v !== null && v !== '' && !(Array.isArray(v) && !v.length))
    .map(([k, v]) => `<div class="small"><span class="faint">${esc(k.replace(/_/g, ' '))}:</span> ${esc(typeof v === 'string' ? v : JSON.stringify(v))}</div>`).join('');
  const rows = d.flags.map(f => {
    const [src, cls] = FLAG_SOURCES[f.source] || [f.source, ''];
    const btns = ['seen', 'fixed', 'wontfix', 'open'].filter(s => s !== f.status)
      .map(s => `<button class="btn sm ${s === 'fixed' ? 'primary' : 'ghost'}" data-id="${f.id}" data-s="${s}">${s === 'wontfix' ? "won't fix" : s === 'open' ? 'reopen' : s}</button>`).join(' ');
    return `<tr><td class="num faint">#${f.id}</td>
      <td><span class="chip ${cls}">${esc(src)}</span><div class="small faint" style="margin-top:4px">${esc(f.kind)}</div></td>
      <td><div>${esc(f.text)}</div>${f.who ? `<div class="small faint">- ${esc(f.who)}</div>` : ''}
        ${f.context ? `<details class="small" style="margin-top:4px"><summary class="faint">context</summary>${ctx(f.context)}</details>` : ''}
        ${f.note ? `<div class="small" style="margin-top:4px"><b>Note:</b> ${esc(f.note)}</div>` : ''}</td>
      <td class="small">${esc(f.campaign || '')}${f.turn ? ` · T${f.turn}` : ''}<div class="faint">${when(f.at)}</div></td>
      <td><span class="chip ${f.status === 'fixed' ? 'green' : f.status === 'open' ? 'amber' : ''}">${esc(f.status)}</span>
        <div style="margin-top:6px;display:flex;gap:4px;flex-wrap:wrap">${btns}</div></td></tr>`;
  }).join('');
  const options = [['', 'Every world']].concat(S.campaigns.map(c => [c.name, c.name]))
    .map(([v, l]) => `<option value="${esc(v)}"${v === S.flags.c ? ' selected' : ''}>${esc(l)}</option>`).join('');
  render(`<div class="wrap">
    <div class="row"><div class="picker"><select id="flagc">${options}</select></div>
      <div class="seg" id="flagst">${['open', 'seen', 'fixed', 'wontfix', 'all'].map(s => `<button data-s="${s}" class="${s === S.flags.status ? 'on' : ''}">${s === 'wontfix' ? "won't fix" : s}${n[s] ? ` (${n[s]})` : ''}</button>`).join('')}</div></div>
    <div class="tiles">
      ${tile('Open', (n.open || 0).toLocaleString(), 'waiting for a look', n.open ? 'amber' : 'green')}
      ${tile('From the GM', (open.gm || 0).toLocaleString(), 'flag: lines, still open')}
      ${tile('From players', (open.player || 0).toLocaleString(), '!reportbug, still open', 'cyan')}
      ${tile('From the engine', (open.engine || 0).toLocaleString(), 'failures, rewrites, slow turns')}
    </div>
    ${panel('Flags', rows ? `<table class="t"><thead><tr><th class="num">#</th><th>From</th><th>What</th><th>Where</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>`
      : `<div class="empty">Nothing ${S.flags.status === 'all' ? '' : esc(S.flags.status) + ' '}here.</div>`)}
    <p class="foot">The GM writes <b>flag: ...</b> when the engine gets something wrong; players use <b>!reportbug</b> or <b>/reportbug</b>; the engine
      flags failed turns, rewrites (the GM spoke for a player), tool errors, turns over two minutes and speaker tags with no one behind them.
      All of it is in <b>campaigns/flags.db</b> - from a terminal: <b>python -m roleplay.flags</b>.</p>
  </div>`);
  $('#flagc').onchange = e => { S.flags.c = e.target.value; refresh(); };
  $$('#flagst button').forEach(b => b.onclick = () => { S.flags.status = b.dataset.s; refresh(); });
  $$('button[data-id]').forEach(b => b.onclick = async () => {
    const note = b.dataset.s === 'wontfix' ? (prompt("Why not? (optional)") || null) : null;
    if (await act(b, () => post('flags/status', { id: +b.dataset.id, status: b.dataset.s, note }))) refresh();
  });
}

// ── canon: the story read back and reconciled every ~20 turns - what's settled, where people stand (dm/canon.py) ──
const VERDICTS = { keep: ['keep', 'green'], built_in: ['engine does it now', 'cyan'], stale: ['stale', 'amber'], conflicts: ['conflicts', 'magenta'] };
async function canonPage() {
  const d = await get('canon', { c: S.campaign });
  if (S.view !== 'canon') return;
  crumbs(S.head);
  const c = d.canon;
  const list = (items, cls = '') => items && items.length
    ? `<ul class="canon-list ${cls}">${items.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '<div class="empty">Nothing here.</div>';
  const foot = `<p class="foot">Every ${d.every} turns (and at the start of a session, or on <b>!reconcile</b>) the strong model reads the whole story back -
    every turn's summary, the facts, everyone's current picture, the open questions and the table's rulings - and writes this record. Contradictions it finds
    are fixed in the GM's own notes at once; the compact version rides at the top of every packet, outranking older memories. Rulings are only ever
    <i>suggested</i> for dropping - the owner takes them with <b>!rulings tidy</b>.</p>`;
  const steer = (d.narrative || []).length ? panel('Story directions from the table', `<table class="t"><tbody>${d.narrative.map(n =>
    `<tr><td class="num"><b>${esc(n.id)}</b></td><td>${esc(n.text)}</td><td class="small faint">${esc(n.by_name || '')} · T${n.created_turn}</td></tr>`).join('')}</tbody></table>`,
    '!narrative add · !narrative remove D#') : '';
  const fr = d.frame;
  const framePanel = fr ? `<div class="gm-hide">${panel(`Scene frame · ${esc(fr.title)}`, `
    ${fr.intent ? `<p><b>Why they're here:</b> ${esc(fr.intent)}</p>` : ''}${fr.pressure ? `<p><b>Pressure:</b> ${esc(fr.pressure)}</p>` : ''}
    <table class="t"><thead><tr><th>Who</th><th>Now</th><th>Wants here</th><th>Toward the others</th></tr></thead><tbody>${(fr.people || []).map(p => `<tr>
      <td><b>${esc(p.name)}</b> ${fly(p.id, p.name)}${p.wont ? `<div class="small faint">won't: ${esc(p.wont)}</div>` : ''}</td><td class="small">${esc(p.now)}</td><td class="small">${esc(p.wants_here)}</td>
      <td class="small">${(p.toward || []).map(t => `<div><b>${esc(t.name)}:</b> ${esc(t.stance)}</div>`).join('')}${(p.settled || []).length ? `<div class="faint" style="margin-top:4px">settled: ${esc(p.settled.join(' • '))}</div>` : ''}</td></tr>`).join('')}</tbody></table>
    ${(fr.retired || []).length ? `<p class="small faint">Retired as over: ${esc(fr.retired.join('; '))}</p>` : ''}`,
    `as of T${fr.turn} · !frame now`)}</div>` : '';
  // doubts: where the record doesn't add up - open ones first (the GM researches and settles them), then the latest settled (dm/doubts.py)
  const dbt = d.doubts || { open: [], settled: [] };
  const on = x => (x.about || []).map(a => a.label !== a.id ? `<b>${esc(a.label)}</b> ${fly(a.id, a.label)}` : `<code>${esc(a.id)}</code>`).join(', ');
  const doubtRow = x => `<tr><td class="num"><b>${esc(x.id)}</b></td>
    <td>${esc(x.text)}${(x.about || []).length ? `<div class="small faint" style="margin-top:3px">on ${on(x)}</div>` : ''}
      ${(x.notes || []).slice(-2).map(n => `<div class="small faint">T${n.created_turn}: ${esc(n.text)}</div>`).join('')}</td>
    <td class="small">T${x.raised_turn} · ${esc(x.raised_by_name || x.raised_by)}${x.times > 1 ? ` · ${x.times}x` : ''}</td>
    <td>${x.status === 'open' ? `<span class="chip ${x.pressing ? 'red' : 'amber'}">${x.pressing ? 'pressing' : 'open'} · ${x.age} turn${x.age === 1 ? '' : 's'}</span>`
      : `<span class="chip ${x.status === 'resolved' ? 'green' : ''}">${esc(x.status)} T${x.resolved_turn}</span><div class="small" style="margin-top:3px">${esc(x.resolution || '')}</div>
         <div class="small faint">by ${esc(x.resolved_by_name || x.resolved_by || '?')}</div>`}</td></tr>`;
  const doubtPanel = dbt.open.length || dbt.settled.length ? `<div class="gm-hide">${panel('Doubts - where the record doesn\'t add up',
    `<table class="t"><thead><tr><th class="num">#</th><th>What doesn't add up</th><th>Raised</th><th>Where it stands</th></tr></thead>
      <tbody>${dbt.open.map(doubtRow).join('')}${dbt.settled.length ? `<tr><td colspan="4" class="small faint">Recently settled (${dbt.settled.length} of ${dbt.settled_total})</td></tr>` : ''}
      ${dbt.settled.map(doubtRow).join('')}</tbody></table>`,
    `${dbt.open.length} open · pressing after ${d.pressing_after} turns · !doubts`)}</div>` : '';
  if (!c) {
    const first = d.last_turn >= d.next_turn ? 'after the next turn' : `once the story is ${d.next_turn} turns in (it's at T${d.last_turn})`;
    render(`<div class="wrap">${panel('Canon', `<div class="empty"><b>No canon yet.</b> The first read-back runs ${first},
      or type <b>!reconcile</b> at the table.</div>`)}${doubtPanel}${framePanel}${steer}${foot}</div>`);
    return;
  }
  const review = c.rulings || [];
  const could = review.filter(r => r.suggested && r.standing).length;
  const settled = (c.settled || []).map(s => `<tr><td>${esc(s.what)}</td><td class="num faint">${esc(s.since)}</td></tr>`).join('');
  const people = (c.people || []).map(p => `<tr><td><b>${esc(p.name)}</b><div class="small faint">${esc(p.id)}</div></td><td>${esc(p.stands)}</td></tr>`).join('');
  const conflicts = (c.conflicts || []).map(x => `<tr><td>${esc(x.issue)}</td><td>${esc(x.canon)}</td>
    <td class="small">${x.doubt ? `<span class="chip amber">left open as ${esc(x.doubt)}${x.reopened ? ' (reopened)' : ''}</span> - the record couldn't tell`
      : x.settled_as ? `<span class="chip">already settled as ${esc(x.settled_as)}</span> - that answer stands`
      : (x.fixes || []).map(f => `<div><code>${esc(f)}</code></div>`).join('')}</td></tr>`).join('');
  const rulings = review.map(r => {
    const [label, cls] = VERDICTS[r.verdict] || [r.verdict, ''];
    return `<tr><td class="num"><b>${esc(r.id)}</b></td><td>${esc(r.text || '')}${r.standing ? '' : ' <span class="chip">gone</span>'}</td>
      <td><span class="chip ${cls}">${esc(label)}</span></td><td class="small">${esc(r.why)}</td></tr>`;
  }).join('');
  render(`<div class="wrap">
    <div class="tiles">
      ${tile('As of', 'T' + c.turn, `read back ${when(c.at)} · now T${d.last_turn}`)}
      ${tile('Settled', (c.settled || []).length, 'never to be re-asked', 'green')}
      ${tile('Open threads', (c.open_threads || []).length, `${(c.closed_threads || []).length} closed`, 'cyan')}
      ${tile('Rulings that could go', could, `${review.length} reviewed · !rulings tidy`, could ? 'amber' : 'green')}
      ${tile('Open doubts', dbt.open.length, `${dbt.open.filter(x => x.pressing).length} pressing · ${dbt.settled_total || 0} settled`,
        dbt.open.some(x => x.pressing) ? 'red' : dbt.open.length ? 'amber' : 'green')}
    </div>
    <div class="empty player-only">The canon is the GM's notebook - spoilers. Turn on <b>GM eyes</b> to read it.</div>
    ${doubtPanel}
    ${framePanel}
    <div class="gm-hide">
    ${panel('Settled - not to be re-opened', settled ? `<table class="t"><tbody>${settled}</tbody></table>` : '<div class="empty">Nothing yet.</div>')}
    ${panel('Where everyone stands', people ? `<table class="t"><tbody>${people}</tbody></table>` : '<div class="empty">Nothing yet.</div>')}
    <div class="grid two">
      ${panel('Coming up', list(c.upcoming))}
      ${panel('Who holds what', list(c.holdings))}
      ${panel('Open threads', list(c.open_threads))}
      ${panel("Closed - don't revive", list(c.closed_threads, 'faint'))}
    </div>
    ${panel('Timeline', list(c.timeline))}
    ${conflicts ? panel('Contradictions it found', `<table class="t"><thead><tr><th>In the record</th><th>What's true</th><th>Fixed with</th></tr></thead><tbody>${conflicts}</tbody></table>`,
      (c.fixed || []).length ? `${c.fixed.length} fixes applied` : '') : ''}
    </div>
    ${steer}
    ${rulings ? panel('Rulings review', `<table class="t"><thead><tr><th class="num">#</th><th>Ruling</th><th>Verdict</th><th>Why</th></tr></thead><tbody>${rulings}</tbody></table>`) : ''}
    ${foot}
  </div>`);
}

const PAGES = { overview: overviewPage, map: mapPage, story: storyPage, people: peoplePage, spend: spendPage, memory: memoryPage, bot: botPage, flags: flagsPage, canon: canonPage };

// ── start ─────────────────────────────────────────────────────────────
async function init() {
  setSpoilers(store.get('rp.spoilers') === '1');
  $('#spoilers').onchange = e => setSpoilers(e.target.checked);
  $('#botpill').onclick = () => { location.hash = '#bot'; };
  $('#refresh').onclick = () => refresh();
  $('#relaunch').onclick = async () => {
    if (!await confirmBox('Restart the app?', 'The engine was updated. This restarts the dashboard and the bot so they run the new code - the bot finishes a turn in progress first.', 'Restart')) return;
    await post('relaunch');
    toast('Restarting...', '', 'This window closes and a fresh one opens in a few seconds.', 0);
  };
  $('#campaign').onchange = e => {
    S.campaign = e.target.value;
    store.set('rp.campaign', S.campaign);
    S.story.scene = null; S.stamp = null; S.data = {}; S.head = null;
    get('overview', { c: S.campaign }).then(d => { S.head = d; crumbs(d); }).catch(() => {});
    if (S.view === 'story' && location.hash !== '#story') location.hash = '#story'; else route();
  };
  window.addEventListener('hashchange', route);
  document.addEventListener('keydown', e => {
    if (e.target.closest('input, select, textarea') || e.ctrlKey || e.metaKey || e.altKey || $('#modal').classList.contains('on')) return;
    const i = '123456789'.indexOf(e.key);
    if (i >= 0) location.hash = '#' + VIEWS[i];
    if (e.key === 'r' || e.key === 'R') refresh();
  });
  window.addEventListener('pagehide', () => navigator.sendBeacon('/api/dash/bye?key=' + KEY));
  document.addEventListener('visibilitychange', () => {   // back from minimized: catch up at once
    if (!document.hidden) { hello(); poll(); }
  });
  await loadCampaigns();
  await poll();
  hello();
  setInterval(poll, 3000);
  setInterval(hello, HELLO_MS);
  if (S.campaign) get('overview', { c: S.campaign }).then(d => { S.head = S.head || d; crumbs(S.head); }).catch(() => {});
  await route();
}
init().catch(e => failed(e));
