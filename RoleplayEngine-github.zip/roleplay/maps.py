"""!map: the Seattle metroplex with what the party knows on it (DESIGN.md §12a).

The engine draws an accurate schematic - Puget Sound, the lakes, the islands, the highways, the
districts - in the same projection engine/geo.py uses. Once per install that schematic can be restyled
by image generation into a Sixth World map (an edit, so the coastlines stay where they are), or you can
drop in your own map image with its bounds. Labels and markers are always drawn on top by the engine,
so they're crisp and in the right place:
    campaigns/maps/metroplex_base.png        the styled base (made by `!map restyle`)
    campaigns/maps/custom.png + custom.json  your own map, with {"north", "south", "west", "east"} bounds
"""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .config import CAMPAIGN_DIR
from .engine import clock, geo

MAP_DIR = CAMPAIGN_DIR / "maps"
METRO = {"north": 48.03, "south": 47.03, "west": -122.80, "east": -121.83}   # ~73 x 111 km, 2:3
SIZE = (1024, 1536)

from .engine.coast import ISLANDS, LAKES, ROADS, SOUND   # (the shapes live with the engine: geo keeps places ashore)

LAND, WATER, GRID, ROAD, DISTRICT = (21, 25, 33), (10, 38, 54), (34, 44, 58), (92, 74, 48), (70, 96, 130)
INK, PARTY, PLACE, NPC_DOT = (214, 224, 236), (255, 70, 110), (255, 196, 64), (120, 200, 255)


def _font(size: int, bold: bool = False):
    for name in (("bahnschrift.ttf",) if not bold else ()) + ("seguisb.ttf" if bold else "segoeui.ttf",
                                                              "arialbd.ttf" if bold else "arial.ttf", "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


class Projection:
    def __init__(self, bounds: dict, size: tuple[int, int]):
        self.b, self.size = bounds, size

    def __call__(self, lat: float, lon: float) -> tuple[float, float]:
        b, (w, h) = self.b, self.size
        return ((lon - b["west"]) / (b["east"] - b["west"]) * w, (b["north"] - lat) / (b["north"] - b["south"]) * h)

    def meters_per_px(self) -> float:
        return (self.b["north"] - self.b["south"]) * 111_320 / self.size[1]


def schematic(bounds: dict = METRO, size: tuple[int, int] = SIZE, roads: bool = True) -> Image.Image:
    """Land, water, islands, highways and a faint grid - no text (labels go on last)."""
    P = Projection(bounds, size)
    img = Image.new("RGB", size, LAND)
    d = ImageDraw.Draw(img)
    step = 0.05 if P.meters_per_px() < 30 else 0.1
    lat = round(bounds["south"] / step) * step
    while lat <= bounds["north"]:
        d.line([P(lat, bounds["west"]), P(lat, bounds["east"])], fill=GRID, width=1)
        lat += step
    lon = round(bounds["west"] / step) * step
    while lon <= bounds["east"]:
        d.line([P(bounds["north"], lon), P(bounds["south"], lon)], fill=GRID, width=1)
        lon += step
    d.polygon([P(*p) for p in SOUND], fill=WATER)
    for poly in LAKES.values():
        d.polygon([P(*p) for p in poly], fill=WATER)
    for poly in ISLANDS.values():
        d.polygon([P(*p) for p in poly], fill=LAND)
    if roads:
        width = max(2, int(3 * 70 / P.meters_per_px())) if P.meters_per_px() < 70 else 2
        for line in ROADS.values():
            d.line([P(*p) for p in line], fill=ROAD, width=min(width, 8), joint="curve")
    return img


def base_image(bounds: dict = METRO, size: tuple[int, int] = SIZE) -> tuple[Image.Image, dict]:
    """The map under the labels: your own map if you supplied one, else the styled metroplex, else the
    schematic. Returns (image, the bounds it covers)."""
    custom, meta = MAP_DIR / "custom.png", MAP_DIR / "custom.json"
    if bounds is METRO and custom.exists() and meta.exists():
        b = json.loads(meta.read_text())
        img = Image.open(custom).convert("RGB")
        return img, {k: float(b[k]) for k in ("north", "south", "west", "east")}
    styled = MAP_DIR / "metroplex_base.png"
    if bounds is METRO and styled.exists():
        return Image.open(styled).convert("RGB").resize(size), bounds
    return schematic(bounds, size), bounds


RESTYLE_PROMPT = """TASK: restyle this map image. It is a georeferenced map of the Seattle metroplex in the year 2080 \
(the Shadowrun Sixth World) - markers will be drawn on top afterwards, so the geography must not move.
PRESERVE: every coastline, island, lake and highway EXACTLY where it is - same shapes, same positions, same \
proportions, same framing. Water stays water, land stays land.
STYLE: a fixer's tactical commlink map - dark charcoal land with dense glowing city texture (heaviest downtown and in \
Bellevue, sparse and dark in the barrens to the east and south), deep teal water with faint contour hatching, the \
highway lines as glowing amber traffic traces, a faint cyan grid, subtle scanlines and grime. Moody, readable, \
high contrast between land and water.
NEGATIVE: no text, no labels, no numbers, no legends, no compass rose, no borders, no logos, no people."""


def restyle(provider) -> Path:
    """One-shot: turn the schematic into a Sixth World map via an image edit. Cached forever."""
    MAP_DIR.mkdir(parents=True, exist_ok=True)
    src = MAP_DIR / "metroplex_schematic.png"
    schematic().save(src)
    data = provider.edit(src, RESTYLE_PROMPT, f"{SIZE[0]}x{SIZE[1]}")
    if not data:
        raise RuntimeError("the image provider returned nothing")
    out = MAP_DIR / "metroplex_base.png"
    out.write_bytes(data)
    return out


# ── what goes on the map ────────────────────────────────────────────────

def known_places(game, everything: bool = False) -> list[dict]:
    """Places the party knows: where they've been, and places in moments they lived through.
    (The GM view shows every place.)"""
    L = game.ledger
    if everything:
        return [e for e in L.entities(kind="location") if e["props"].get("geo")]
    pcs = [p["id"] for p in L.entities(kind="pc")]
    ids = {s["location_id"] for s in L.scenes() if s["location_id"]}
    if pcs:
        marks = ",".join("?" * len(pcs))
        ids |= {r["node_id"] for r in game.conn.execute(
            f"SELECT DISTINCT m.node_id FROM members m JOIN nodes n ON n.id=m.slice_id JOIN entities e ON e.id=m.node_id "
            f"WHERE e.kind='location' AND n.visibility='public' AND m.slice_id IN "
            f"(SELECT slice_id FROM members WHERE node_id IN ({marks}))", pcs)}
    return [e for e in (L.get(i) for i in ids) if e and e["props"].get("geo")]


def _label(d: ImageDraw.ImageDraw, xy, text: str, font, fill, halo=(8, 10, 14), anchor="lm") -> None:
    d.text(xy, text, font=font, fill=fill, anchor=anchor, stroke_width=3, stroke_fill=halo)


class Labels:
    """Places labels without overlaps: each tries a few spots around its point, stays inside the image,
    and is dropped if there's no room (so a crowded downtown reads instead of smearing)."""

    def __init__(self, d: ImageDraw.ImageDraw, size: tuple[int, int]):
        self.d, (self.W, self.H), self.boxes = d, size, []

    def reserve(self, box) -> None:
        self.boxes.append(box)

    def _fits(self, b) -> bool:
        return all(b[2] < o[0] or b[0] > o[2] or b[3] < o[1] or b[1] > o[3] for o in self.boxes)

    def place(self, x, y, text, font, fill, gap=10, around=True, force=False, anchor="mm") -> bool:
        spots = [((x + gap, y), "lm"), ((x - gap, y), "rm"), ((x, y - gap), "mb"), ((x, y + gap), "mt")] \
            if around else [((x, y), anchor)]
        for (sx, sy), anchor in spots:
            b = self.d.textbbox((sx, sy), text, font=font, anchor=anchor, stroke_width=3)
            dx = (self.W - 6 - b[2]) if b[2] > self.W - 6 else (6 - b[0]) if b[0] < 6 else 0
            b = (b[0] + dx - 2, b[1] - 2, b[2] + dx + 2, b[3] + 2)
            if force or self._fits(b):
                _label(self.d, (sx + dx, sy), text, font, fill, anchor=anchor)
                self.boxes.append(b)
                return True
        return False


def render(game, view: str = "metro", gm: bool = False, out: Path | None = None) -> Path:
    """metro: the whole metroplex. here: ~6 km around the party. gm: every place, and offscreen NPCs."""
    L = game.ledger
    sc = L.current_scene()
    here_loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    here = geo.geo_of(game, here_loc["id"]) if here_loc else None
    if view == "here" and here:
        half_lat = 2600 / 111_320
        half_lon = half_lat * 4 / 3 / max(0.3, __import__("math").cos(__import__("math").radians(here["lat"])))
        bounds = {"north": here["lat"] + half_lat, "south": here["lat"] - half_lat,
                  "west": here["lon"] - half_lon, "east": here["lon"] + half_lon}
        img, bounds = schematic(bounds, (1200, 900)), bounds
    else:
        img, bounds = base_image()
    img = img.convert("RGB")
    P = Projection(bounds, img.size)
    W, H = img.size
    scale = W / 1024
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    small, mid, big = _font(int(15 * scale)), _font(int(19 * scale)), _font(int(30 * scale), bold=True)
    inside = lambda x, y: 0 <= x <= W and 0 <= y <= H          # noqa: E731
    places = [p for p in known_places(game, everything=gm) if inside(*P(p["props"]["geo"]["lat"], p["props"]["geo"]["lon"]))]
    people = []
    if gm:                                                    # the GM's view: where offscreen people are
        for e in L.entities(kind="npc"):
            g = geo.geo_of(game, e["id"]) if e["props"].get("whereabouts") else None
            if g and inside(*P(g["lat"], g["lon"])):
                people.append((e, g))

    # markers first (glow + dots), labels after - most important labels claim space first
    for p in places:
        x, y = P(p["props"]["geo"]["lat"], p["props"]["geo"]["lon"])
        r = 6 * scale
        gd.ellipse([x - 3 * r, y - 3 * r, x + 3 * r, y + 3 * r], fill=PLACE + (70,))
    if here:
        x, y = P(here["lat"], here["lon"])
        for rr, a in ((40, 50), (26, 90), (14, 160)):
            gd.ellipse([x - rr * scale, y - rr * scale, x + rr * scale, y + rr * scale], fill=PARTY + (a,))
    img = Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(6 * scale))).convert("RGB")
    d = ImageDraw.Draw(img)
    for p in places:
        x, y = P(p["props"]["geo"]["lat"], p["props"]["geo"]["lon"])
        r = 6 * scale
        d.ellipse([x - r, y - r, x + r, y + r], fill=PLACE, outline=(20, 20, 20), width=2)
    for e, g in people:
        x, y = P(g["lat"], g["lon"])
        d.rectangle([x - 4, y - 4, x + 4, y + 4], fill=NPC_DOT)
    if here:
        x, y = P(here["lat"], here["lon"])
        d.ellipse([x - 9 * scale, y - 9 * scale, x + 9 * scale, y + 9 * scale], fill=PARTY, outline=(255, 255, 255), width=3)

    labels = Labels(d, img.size)
    title = "SEATTLE METROPLEX" if view != "here" else f"NEAR {here_loc['name'].upper()}"
    _label(d, (24 * scale, 34 * scale), title, big, INK)
    _label(d, (24 * scale, 68 * scale), clock.fmt(game.clock()) + ("  ·  GM VIEW" if gm else ""), small, (150, 170, 190))
    labels.reserve(d.textbbox((24 * scale, 34 * scale), title, font=big, anchor="lm", stroke_width=3))
    labels.reserve((0, 0, 330 * scale, 84 * scale))
    km = 10 if view != "here" else 1
    px = km * 1000 / P.meters_per_px()
    x0, y0 = 24 * scale, H - 30 * scale
    d.line([(x0, y0), (x0 + px, y0)], fill=INK, width=3)
    for xx in (x0, x0 + px):
        d.line([(xx, y0 - 6), (xx, y0 + 6)], fill=INK, width=3)
    _label(d, (x0 + px + 10, y0), f"{km} km", small, INK)
    labels.reserve((0, y0 - 16, x0 + px + 80, H))
    if here:                                                  # the party's label always lands
        x, y = P(here["lat"], here["lon"])
        who = " & ".join(p["name"] for p in L.entities(kind="pc") if p["id"] in L.roster(sc["id"])) or "You"
        labels.reserve((x - 12 * scale, y - 12 * scale, x + 12 * scale, y + 12 * scale))
        labels.place(x, y - 14 * scale, who.upper(), mid, (255, 255, 255), gap=8 * scale, force=True)
        labels.place(x, y + 4 * scale, here_loc["name"], small, PLACE, gap=14 * scale, force=True)
    for p in places:
        if here_loc and p["id"] == here_loc["id"]:
            continue
        x, y = P(p["props"]["geo"]["lat"], p["props"]["geo"]["lon"])
        labels.place(x, y, p["name"], small, PLACE, gap=10 * scale)
    for e, g in people:
        labels.place(*P(g["lat"], g["lon"]), e["name"], small, NPC_DOT, gap=8 * scale)
    # districts last: big ones first; landmarks only where there's room (the close-up shows more)
    for name, (lat, lon, radius, _) in sorted(geo.GAZETTEER.items(), key=lambda kv: -kv[1][2]):
        x, y = P(lat, lon)
        if not inside(x, y) or (view != "here" and radius < 1000):
            continue
        big_one = radius >= 1500
        labels.place(x, y, name.upper() if big_one else name, mid if big_one else small, DISTRICT, around=False)
    out = out or (game.path.parent / "maps" / f"{game.path.stem}_{view}{'_gm' if gm else ''}.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)
    return out
