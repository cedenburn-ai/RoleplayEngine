"""The flag log (DESIGN.md §12j): what went wrong, in one place the table's owner and the developer can both read.

Three sources write here:
- the GM - `flag: ...` in its <dm> block (or an aside's fixes) when the engine gets something wrong;
- the players - `!reportbug ...` / `/reportbug`, with the turn, the scene and their character attached;
- the engine itself - a turn that failed, a rewrite because the GM spoke for a player, a tool error, a slow turn, a
  GM aside that failed, a speaker tagged with an id that isn't anyone.

One SQLite file next to the campaigns (`flags.db`, like the spend log), shown on the dashboard's Flags page, and
readable from a terminal: `python -m roleplay.flags` (open ones) or `python -m roleplay.flags all`. Every flag is
written in the names the crew knows (DESIGN.md §12l): the owner reads this page and plays the stories he seeds.
"""
from __future__ import annotations

import json
import sqlite3
import sys
import time
from contextlib import closing
from pathlib import Path

from .config import CAMPAIGN_DIR

SCHEMA = """
CREATE TABLE IF NOT EXISTS flags(
    id INTEGER PRIMARY KEY, at REAL NOT NULL, campaign TEXT, turn INTEGER,
    source TEXT NOT NULL,                          -- gm | player | engine
    who TEXT, kind TEXT NOT NULL, text TEXT NOT NULL, context TEXT,
    status TEXT NOT NULL DEFAULT 'open',           -- open | seen | fixed | wontfix
    note TEXT
);
"""
FILE = "flags.db"
STATUSES = ("open", "seen", "fixed", "wontfix")
SLOW_TURN = 120                                    # seconds: a turn slower than this is worth a look


def path(folder: Path | str | None = None) -> Path:
    return Path(folder or CAMPAIGN_DIR) / FILE


def _db(folder=None) -> sqlite3.Connection:
    c = sqlite3.connect(str(path(folder)), timeout=10, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout = 10000")
    c.execute("PRAGMA journal_mode = WAL")
    c.execute("PRAGMA synchronous = NORMAL")
    c.executescript(SCHEMA)
    return c


def record(game, source: str, kind: str, text: str, who: str | None = None, turn: int | None = None,
           context: dict | None = None) -> int | None:
    """Write a flag for this game's campaign. Never raises - a flag that can't be written must not cost a turn. The
    same open flag twice in one turn is one flag. Its words and context are put in the names the crew knows first: the
    owner plays the seeded story and reads this page, and a GM flag line, a tool's input or a rewrite's quote can say
    any name (dm/spoilers.py; review 2026-10-28)."""
    try:
        folder, campaign = game.path.parent, game.path.stem
        if getattr(game, "ledger", None) is not None:
            from .dm import spoilers
            text, context = spoilers.for_flag(game, text, context)
        text = " ".join(str(text).split())[:2000]
        with closing(_db(folder)) as c:
            dup = c.execute("SELECT id FROM flags WHERE campaign=? AND turn IS ? AND kind=? AND text=? AND status='open'",
                            (campaign, turn, kind, text)).fetchone()
            if dup:
                return dup["id"]
            cur = c.execute("INSERT INTO flags(at, campaign, turn, source, who, kind, text, context) "
                            "VALUES(?,?,?,?,?,?,?,?)", (time.time(), campaign, turn, source, who, kind, text,
                                                        json.dumps(context, default=str) if context else None))
            return cur.lastrowid
    except Exception as exc:
        print(f"[flags] couldn't record a {kind} flag: {exc}", flush=True)
        return None


def _row(r) -> dict:
    d = dict(r)
    try:
        d["context"] = json.loads(d["context"]) if d.get("context") else None
    except ValueError:
        pass
    return d


def listing(folder=None, status: str | None = "open", campaign: str | None = None, limit: int = 200) -> list[dict]:
    if not path(folder).exists():
        return []
    sql, args = "SELECT * FROM flags WHERE 1=1", []
    if status:
        sql += " AND status=?"
        args.append(status)
    if campaign:
        sql += " AND campaign=?"
        args.append(campaign)
    with closing(_db(folder)) as c:
        return [_row(r) for r in c.execute(sql + " ORDER BY id DESC LIMIT ?", (*args, limit))]


def counts(folder=None) -> dict:
    """{status: n} and {source: open n}."""
    if not path(folder).exists():
        return {"by_status": {}, "open_by_source": {}}
    with closing(_db(folder)) as c:
        return {"by_status": {r["status"]: r["n"] for r in c.execute("SELECT status, COUNT(*) n FROM flags GROUP BY status")},
                "open_by_source": {r["source"]: r["n"] for r in c.execute(
                    "SELECT source, COUNT(*) n FROM flags WHERE status='open' GROUP BY source")}}


def set_status(folder, fid: int, status: str, note: str | None = None) -> dict:
    if status not in STATUSES:
        raise ValueError(f"status is one of {', '.join(STATUSES)}")
    with closing(_db(folder)) as c:
        c.execute("UPDATE flags SET status=?, note=COALESCE(?, note) WHERE id=?", (status, note, int(fid)))
        row = c.execute("SELECT * FROM flags WHERE id=?", (int(fid),)).fetchone()
    if not row:
        raise KeyError(f"no flag #{fid}")
    return _row(row)


def main(argv: list[str]) -> None:
    rows = listing(status=None if argv[:1] == ["all"] else "open")
    for f in reversed(rows):
        stamp = time.strftime("%m-%d %H:%M", time.localtime(f["at"]))
        print(f"#{f['id']:<4} {stamp}  {f['campaign'] or '-':<24} T{f['turn'] or '-':<4} {f['source']:<6} "
              f"{f['kind']:<16} [{f['status']}] {f['text']}" + (f"  ({f['who']})" if f["who"] else ""))
    print(f"-- {len(rows)} flag(s)")


if __name__ == "__main__":
    main(sys.argv[1:])
