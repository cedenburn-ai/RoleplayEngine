"""!charactersheet: a player's character - as two rendered pages (image_cards, sheetart.py), or as text cards - portrait, attributes, condition monitors, dice pools
(computed by the engine, exactly what a roll would use), gear, and where they are. Only what the
player may know: no GM notes, no NPC attitudes about them.

Cards are plain dicts (title, description, color, image, fields, footer) so Discord renders them as
embeds and the console prints them as text.
"""
from __future__ import annotations

from .engine import clock, geo
from .engine.rules import machines, magic, matrix, resonance, sr_lite

PC_COLOR, NPC_COLOR = 0x4FC3F7, 0x3498DB


def bar(filled: int, size: int) -> str:
    """A condition monitor: ▰ for boxes of damage, ▱ for boxes left."""
    filled = max(0, min(size, filled))
    return "▰" * filled + "▱" * (size - filled)


def _gear_line(item: dict, note: str | None = None) -> str:
    """note: what's wrong with it, first ('BRICKED (Deck 14/10) - no bonuses until repaired')."""
    p, bits = item["props"], [f"**{note}**"] if note else []
    if "dv" in p:
        bits.append(f"DV {p['dv']}{'S' if p.get('damage_type') == 'stun' else 'P'}" + (f" AP {p['ap']}" if p.get("ap") else ""))
    if "ammo_capacity" in p:
        bits.append(f"{item['state'].get('loaded', p['ammo_capacity'])}/{p['ammo_capacity']} rounds")
    if "armor" in p:
        bits.append(f"armor {p['armor']}")
    if "bonus" in p:
        bits.append(", ".join(f"+{v} {sr_lite.nice(k)}" for k, v in p["bonus"].items()))
    if p.get("autosoft") or p.get("mount"):
        bits.append(f"{p['autosoft']} autosoft {p.get('rating', 1)}" if p.get("autosoft") else f"{p['mount']} mount")
    if sr_lite.arriving(item):                        # bought for delivery, not here yet (shops.py)
        bits.append(f"🚚 on its way from {sr_lite.arriving(item).get('from') or 'the dealer'}")
    qty = f"{item['qty']}× " if item.get("qty", 1) > 1 else ""
    name = item["name"].split("'s ", 1)[-1] if "'s " in item["name"] else item["name"]
    return f"**{qty}{name}**" + (f" · {' · '.join(bits)}" if bits else "")


def initiative(L, eid: str) -> str:
    """'**10** + 2D6 (Reaction + Intuition; Wired reflexes 1) · **Action Phases** 2-3 a round' - how fast they are in a
    fight, as the engine rolls it: every 10 of the score is one attack, spell or grenade a round (wounds take it off)."""
    attr, n, why = sr_lite.initiative_rating(L, eid)
    if not n:
        return f"none of their own ({why[0]})"
    lo, hi = -(-(attr + n) // 10), -(-(attr + 6 * n) // 10)
    src = "; ".join([why[0]] + ([", ".join(why[1:])] if why[1:] else []))
    return (f"**{attr}** + {n}D6 ({src}) · **Action Phases** {lo if lo == hi else f'{lo}-{hi}'} a round"
            "\n-# Every 10 of Initiative is an action in a fight: one attack, spell or grenade.")


def cards(game, eid: str) -> list[dict]:
    L = game.ledger
    ent = L.require(eid)
    s = L.stats(eid)
    is_pc = ent["kind"] == "pc"
    color = PC_COLOR if is_pc else NPC_COLOR

    # ── 1. who they are ──
    art = game.art.latest(game.conn, eid, ready_only=True)
    kind = (ent["props"].get("archetype") or ent["props"].get("template") or ent["kind"]).replace("_", " ")
    head = [f"*{kind.title()}*" + ("" if is_pc else " · an NPC you are playing")]
    if ent["description"]:
        head.append(ent["description"])
    if not art:
        head.append("-# No portrait yet - one is painted after their first scene (`!art redo <name>` to ask).")
    attrs = "  ".join(f"**{sr_lite.ABBR[a]}** {int(s[a])}" for a in sr_lite.ATTRIBUTES if a in s)
    if "essence" in s:
        attrs += f"  **ESS** {s['essence']:g}"
    pmax, smax = sr_lite.monitor_max(L, eid)
    phys, stun = int(s.get("physical_damage", 0)), int(s.get("stun_damage", 0))
    pen = sr_lite.wound_penalty(L, eid)
    status = sr_lite.condition(L, eid)
    monitors = (f"`Physical` {bar(phys, pmax)} {phys}/{pmax}\n`Stun    ` {bar(stun, smax)} {stun}/{smax}\n"
                f"*{status}*" + (f" · **−{pen}** to every pool from wounds" if pen else ""))
    edge_max = int(s.get("edge", 0))
    resources = (f"**Edge** {int(s.get('edge_points', 0))}/{edge_max} · **Nuyen** ¥{int(s.get('nuyen', 0)):,}"
                 + (f" · **Karma** {int(s.get('karma', 0))}" if is_pc else ""))
    first = {"title": f"{'🎲' if is_pc else '🎭'} {ent['name']}", "description": "\n".join(head), "color": color,
             "image": art["path"] if art else None,
             "fields": [{"name": "Attributes", "value": attrs or "-", "inline": False},
                        {"name": "Initiative", "value": initiative(L, eid), "inline": False},
                        {"name": "Condition", "value": monitors, "inline": False},
                        {"name": "Resources", "value": resources, "inline": False}]}

    # ── 2. what they can do: pools the engine will actually roll ──
    rows = []
    for skill in sorted(sr_lite.SKILLS):
        if not s.get(skill):
            continue
        n, parts = sr_lite.build_pool(L, eid, skill)
        extra = [f"{label} {v:+d}" for label, v in parts[2:]]
        rows.append(f"{sr_lite.nice(skill):<13}{int(s[skill]):>2} + {sr_lite.ABBR[sr_lite.SKILLS[skill]]} "
                    f"{int(s.get(sr_lite.SKILLS[skill], 0))} = {n:>2} dice" + (f"  ({', '.join(extra)})" if extra else ""))
    skills = {"title": "Skills & dice pools", "color": color,
              "description": ("```\n" + "\n".join(rows) + "\n```" if rows else "*No trained skills.*")
                             + "\n-# Untrained skills roll the attribute − 1. Hits are 5s and 6s."}

    # ── 3. what they carry, and where they are ──
    gear = [_gear_line(i, matrix.brick_note(L, eid, i)) for i in L.holdings(eid)]     # (flag #24: a bricked deck)
    sc = L.current_scene()
    here = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    where = here["name"] if here else (sc["title"] if sc else "somewhere")
    district = (geo.geo_of(game, here["id"]) or {}).get("district") if here else None
    kit = {"title": "Gear", "color": color, "description": "\n".join(f"• {g}" for g in gear) or "*Nothing but lint.*",
           "footer": f"{clock.fmt(game.clock())} · {where}" + (f" ({district})" if district else "")}
    out = [first, skills, kit]
    if matrix.deck(L, eid)[0]:
        out.append(matrix_card(game, eid, color))
    if int(L.stat(eid, "magic", 0)) > 0:
        out.append(magic_card(game, eid, color))
    if int(L.stat(eid, "resonance", 0)) > 0:
        out.append(resonance_card(game, eid, color))
    rides = machines.owned_by(L, eid) + machines.driven_by(L, eid)      # (a crewmate's lent drone they're running too)
    if rides:
        out.append(machines_card(game, eid, rides, color))

    if is_pc:
        out.append(advancement_card(game, eid, color))
    if not is_pc:                                     # an inhabited NPC knows their own mind
        feels = game.sub.beliefs_of(eid)[:4]
        if feels:
            out.append({"title": "How you feel", "color": color,
                        "description": "\n".join(f"• {b['text']}" for b in feels)})
    return out


def resonance_card(game, eid: str, color: int) -> dict:
    """A technomancer's Resonance, complex forms (each with its fading code, and what it costs at full Resonance),
    held forms, sprites."""
    L = game.ledger
    r = int(L.stat(eid, "resonance"))

    def pool(skill: str) -> str:
        try:
            return str(sr_lite.build_pool(L, eid, skill)[0])
        except Exception:
            return "-"
    known = list(L.get(eid)["props"].get("forms") or resonance.FORMS)
    lines = [f"**Resonance {r}** · living persona rating {r} · Software {pool('software')} · Compiling "
             f"{pool('compiling')} · Fading resist {int(L.stat(eid, 'willpower')) + r} dice (Willpower + Resonance)",
             "Complex forms (fading: L = the Level you thread at, never under 2): " + " · ".join(
                 f"{resonance.form_label(k)} ({resonance.fading_value(r, resonance.FORMS[k]['fading'])} at Level {r})"
                 for k in known)]
    held = L.get(eid)["props"].get("forms_sustained") or []
    if held:
        lines.append("Holding: " + ", ".join(resonance.FORMS[h["form"]]["name"] for h in held)
                     + f" (-{2 * len(held)} dice)")
    for sp in L.entities(kind="sprite"):
        if sp["props"].get("owner") == eid:
            lines.append(f"Sprite: {sp['name']} (Level {sp['props'].get('level')}, {sp['props'].get('tasks')} task(s))")
    lines.append(f"-# No deck needed: you ARE the deck, and Matrix damage hits your mind as stun. Levels go to {2 * r}, "
                 f"and the Level caps your hits; fading is physical when your hits beat your Resonance ({r}), which "
                 f"takes a Level over {r}. Sprites: courier, crack, data, fault, machine.")
    return {"title": "Resonance", "color": color, "description": "\n".join(lines)}


def magic_card(game, eid: str, color: int) -> dict:
    """A magician's pools, the spells they know (each with its drain code, and what it costs to cast at full
    Magic), what they're holding up, and the spirits that owe them."""
    L = game.ledger
    m = int(L.stat(eid, "magic"))

    def pool(skill: str) -> str:
        try:
            return str(sr_lite.build_pool(L, eid, skill)[0])
        except Exception:
            return "-"
    resist = int(L.stat(eid, "willpower")) + int(L.stat(eid, "logic"))
    known = magic.known(L, eid) or list(magic.SPELLS)
    lines = [f"**Magic {m}** · Sorcery {pool('sorcery')} · Conjuring {pool('conjuring')} · "
             f"Drain resist {resist} dice (Willpower + Logic)",
             "Spells (drain: F = the Force you cast at, never under 2): " + " · ".join(
                 f"{magic.spell_label(k)} ({magic.drain_value(m, magic.SPELLS[k]['drain'])} at Force {m})"
                 for k in known)]
    held = L.get(eid)["props"].get("sustained") or []
    if held:
        lines.append("Holding up: " + ", ".join(magic.SPELLS[h["spell"]]["name"] for h in held)
                     + f" (-{2 * len(held)} dice to everything)")
    if L.get(eid)["props"].get("astral"):
        lines.append(f"Astral: {L.get(eid)['props']['astral']}")
    for sp in L.entities(kind="spirit"):
        if sp["props"].get("owner") == eid:
            lines.append(f"Spirit: {sp['name']} (Force {sp['props'].get('force')}, "
                         f"{sp['props'].get('services')} service(s))")
    # Live T164/T169/T172: Force 7-8 casts drained stun while this note said 'above 6 the drain turns physical' -
    # the engine (and SR5 p. 281) goes by the hits.
    lines.append(f"-# Force goes up to {2 * m}, and the Force caps your hits. Drain is physical when your hits beat "
                 f"your Magic ({m}) - that takes a Force over {m}, or Edge pushed. Tell the GM the spell and the "
                 "Force (\"Stunbolt at Force 4 on the guard\").")
    return {"title": "Magic", "color": color, "description": "\n".join(lines)}


def matrix_card(game, eid: str, color: int) -> dict:
    """A decker's deck, its damage, what each Matrix move rolls - and where they are if they're in."""
    L = game.ledger
    rating, name = matrix.deck(L, eid)
    st = matrix.current(L, eid)                       # (a run the story left behind reads as over - flag #11)
    dmg, mon = int(st.get("deck_damage", 0)), matrix.deck_monitor(rating)
    fw, living = matrix.firewall(L, eid), matrix.living(L, eid)

    def pool(skill: str, attr: str | None = None) -> str:
        try:
            return str(sr_lite.build_pool(L, eid, skill, attr)[0])
        except Exception:
            return "-"
    # The soaks on the card (flags #29, #30): the deck's Device Rating + Firewall, past a full deck your Stun; Black IC
    # skips the deck - Willpower + Firewall.
    lines = [f"**{name.split(chr(39) + 's ', 1)[-1]}** · rating {rating} (Firewall {fw})",
             "Matrix damage hits your mind as stun - no deck to fry" if living
             else f"`Deck` {bar(dmg, mon)} {dmg}/{mon}"
             + (" · **BRICKED** - no bonuses, no jacking in, until it's repaired" if matrix.bricked(L, eid) else ""),
             f"Hack {pool('hacking')} · Brute force {pool('cybercombat')} · Search {pool('electronics', 'intuition')} "
             f"· Control/data {pool('electronics')} dice (+2 in hot-sim VR)",
             f"IC defense: Intuition + Firewall = {int(L.stat(eid, 'intuition')) + fw} dice",
             f"Soak: Device Rating + Firewall = {rating + fw} dice"
             + (" (it's your Stun)" if living else " (the deck takes it; past a full deck, your Stun)")
             + f" · Black IC: Willpower + Firewall = {int(L.stat(eid, 'willpower')) + fw} dice "
               "(Physical in hot-sim VR, Stun in AR)"]
    if st.get("host"):
        h = L.get(st["host"])
        lines.append(f"**Jacked in:** {h['name'] if h else '?'} · {'hot-sim VR' if st.get('mode') == 'vr' else 'AR'} · "
                     f"access {(st.get('access') or {}).get(st['host'], 'outsider')}")
        lines.append(matrix.overwatch_line(int(st.get("overwatch", 0))))
    lines.append("-# Tell the GM what you're after (\"I jack in VR and loop the corridor cameras\") - every move is "
                 "one roll, and the host answers. Overwatch: 15 noticed, 25 alert, 40 they find you.")
    return {"title": "Matrix", "color": color, "description": "\n".join(lines)}


def machines_card(game, eid: str, rides: list[dict], color: int) -> dict:
    """Each drone/vehicle: what it is, its structure, what it rolls on its own - and with you driving (the engine's
    own pools, machines.pools: the -2 for every other machine you run there, its damage)."""
    L = game.ledger
    rig = machines.control_rig(L, eid)
    blocks = []
    for m in rides:
        s, p = L.stats(m["id"]), m["props"]
        driver = L.get(p.get("controller") or "")
        run = (f"{'jumped in' if p.get('control') == 'jumped' else 'remote'}: {driver['name']}" if driver else "autonomous")
        owner = L.get(p.get("owner") or "")
        if owner and owner["id"] != eid:
            run += f" · {owner['name']}'s"
        if p.get("delegates"):
            run += " · keys: " + ", ".join((L.get(d) or {}).get("name", d) for d in p["delegates"])
        pmax, _ = sr_lite.monitor_max(L, m["id"])
        phys = int(s.get("physical_damage", 0))
        stats = " · ".join(f"{k.title()} {int(s[k])}" for k in sr_lite.MACHINE_STATS if k in s)
        softs = ", ".join(f"{k.title()} {v}" for k, v in sr_lite.autosofts(L, m).items()) or "none"
        held = [i for i in L.holdings(m["id"]) if not (i["props"].get("autosoft") or i["props"].get("mount"))]
        lines = [f"**{m['name']}** · *{run}*",
                 f"`Structure` {bar(phys, pmax)} {phys}/{pmax} · {sr_lite.condition(L, m['id'])}",
                 f"{stats} · Autosofts: {softs} (room for {machines.soft_slots(int(s.get('pilot', 1)))})"]
        if sr_lite.arriving(m):
            lines.insert(1, f"🚚 {sr_lite.transit_note(L, m)}")
        slots = machines.mount_line(L, m)
        if slots:
            lines.append(slots.split(" - ", 1)[0])
        if held:
            lines.append("Carries: " + "; ".join(_gear_line(i) for i in held))
        lines.append("On its own: " + " · ".join(f"{verb} {n}" for verb, n in machines.pools(L, m)) + " dice")
        you = "With you remote: " + " · ".join(f"{verb} {n}" for verb, n in machines.pools(L, m, eid)) + " dice"
        if rig:
            you += " · jumped in: " + " · ".join(f"{verb} {n}" for verb, n in machines.pools(L, m, eid, "jumped")) + " dice"
        lines.append(you)
        blocks.append("\n".join(lines))
    tip = ("-# Tell the GM what they do (\"my Roto-drone covers the door\") and how you're running it - on its own "
           "Pilot when that rolls more. Lend one to a crewmate by saying so (\"Filament can run my Lynx\"); taking the "
           "controls back takes the keys back. A decker can steal one - including someone else's decker.")
    return {"title": "Drones & vehicles", "color": color, "description": "\n\n".join(blocks) + "\n" + tip}


def advancement_card(game, eid: str, color: int) -> dict:
    """Every stat with its reference number, next rating and karma cost - and how to spend it."""
    L = game.ledger
    s = L.stats(eid)
    karma = int(s.get("karma", 0))
    refs = sr_lite.advancement_refs()
    rows, learn = [], []
    for ref, key in refs.items():
        now = int(s.get(key, 0))
        if key in sr_lite.SKILLS and not now:
            if not sr_lite.advance_cost(L, eid, key)[2]:        # (no Sorcery for the mundane)
                learn.append(f"{ref} {sr_lite.nice(key)}")
            continue
        if key in sr_lite.SPECIAL and not now:
            continue
        new, cost, why = sr_lite.advance_cost(L, eid, key)
        label = sr_lite.ABBR[key] if key in sr_lite.ATTRIBUTES else sr_lite.nice(key)
        tail = "max" if why else f"{cost:>3}" + (" ✓" if cost <= karma else "")
        rows.append(f"{ref:>2}  {label:<13}{now:>2} → {new if not why else '-':<3}{tail}")
    body = (f"**Karma: {karma}**\n```\n #  stat        now → next  cost\n" + "\n".join(rows) + "\n```\n"
            + ("**Learn a skill** (2 karma, starts at 1): " + " · ".join(learn) + "\n" if learn else "")
            # (what's left to learn: nothing on an empty list, which knows them all - see magic.learnable)
            + ((f"**Learn a complex form** ({resonance.LEARN_COST} karma, `!advance form <name>`): "
                + " · ".join(resonance.form_label(k) for k in resonance.learnable(L, eid))
                + "\n") if int(s.get("resonance", 0)) > 0 and resonance.learnable(L, eid) else "")
            + ((f"**Learn a spell** ({magic.LEARN_COST} karma, `!advance spell <name>`): "
                + " · ".join(magic.spell_label(k) for k in magic.learnable(L, eid))
                + "\n") if int(s.get("magic", 0)) > 0 and magic.learnable(L, eid) else "")
            + "Spend with `!advance <#>`, e.g. `!advance 3` - ✓ means you can afford it now. Attributes cost "
              "the new rating × 5 (on the natural rating, not the chrome), skills the new rating × 2 (× 3 for the broad "
              "ones: Firearms, Close Combat, Athletics, Engineering, Conjuring). The GM awards karma for jobs done and great play.")
    return {"title": "Advancement", "color": color, "description": body}


def image_cards(game, eid: str) -> list[dict]:
    """The sheet as two rendered pages (sheetart.py). If drawing fails, the text cards still go out."""
    try:
        from . import sheetart
        page1, page2 = sheetart.render(game, eid)
    except Exception as exc:
        game.out(f"  (sheet art failed, sending text: {exc})")
        return cards(game, eid)
    ent = game.ledger.require(eid)
    color = PC_COLOR if ent["kind"] == "pc" else NPC_COLOR
    return [{"title": f"{'🎲' if ent['kind'] == 'pc' else '🎭'} {ent['name']}", "color": color, "image": str(page1)},
            {"title": "Kit, gifts & karma", "color": color, "image": str(page2),
             "footer": "!advance <#> spends karma · !sheet text for the text version · !askgm <question> for rules"}]


def text(cards_: list[dict]) -> str:
    """The same sheet for the console."""
    lines = []
    for c in cards_:
        if c.get("title"):
            lines.append(f"== {c['title']} ==")
        if c.get("description"):
            lines.append(c["description"].replace("```", "").strip())
        for f in c.get("fields") or []:
            lines.append(f"{f['name']}: {f['value']}")
        if c.get("footer"):
            lines.append(c["footer"])
        if c.get("image"):
            lines.append(f"[portrait: {c['image']}]")
        lines.append("")
    return "\n".join(lines).replace("**", "").replace("-# ", "").replace("`", "")
