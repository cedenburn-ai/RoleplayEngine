"""Backups (DESIGN.md §14a): every world, the character ledger, the art and the maps, zipped once a day.

    python -m roleplay.backup            -> backups/campaigns-YYYYmmdd-HHMMSS.zip (keeps the newest 14)

The bot runs one a day by itself and the owner can `!backup` any time. Databases are copied with SQLite's
online backup API, so a backup taken mid-session is consistent. Undo snapshots and the re-renderable
pictures (sheets, dossiers) are skipped. Set ROLEPLAY_BACKUP_DIR to put the zips on another drive or in a
synced folder.
"""
from __future__ import annotations

import os
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path

from .config import CAMPAIGN_DIR, ROOT

KEEP = 14
EVERY = 24 * 3600
SKIP_TOP = ("sheets", "dossiers", ".run", ".cache")  # re-renderable / the bot's runtime files / map tiles


def backup_dir() -> Path:
    return Path(os.environ.get("ROLEPLAY_BACKUP_DIR") or ROOT / "backups")


def last_backup(dest: Path | None = None) -> float | None:
    zips = sorted((dest or backup_dir()).glob("campaigns-*.zip"))
    return zips[-1].stat().st_mtime if zips else None


def run(campaign_dir: Path = CAMPAIGN_DIR, dest: Path | None = None, keep: int = KEEP) -> Path:
    campaign_dir, dest = Path(campaign_dir), Path(dest or backup_dir())
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / f"campaigns-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    part = out.with_suffix(".zip.part")
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(campaign_dir.rglob("*")):
            rel = p.relative_to(campaign_dir)
            if not p.is_file() or rel.parts[0] in SKIP_TOP or any(x.endswith("_undo") for x in rel.parts):
                continue
            if p.name.endswith(("-wal", "-shm", ".part")):
                continue                                  # (the snapshot below folds the WAL in)
            if p.suffix == ".db":
                snap = Path(tmp) / p.name
                src, dst = sqlite3.connect(str(p), timeout=30), sqlite3.connect(str(snap))
                try:
                    src.backup(dst)                       # consistent even while the bot is writing
                finally:
                    src.close()
                    dst.close()
                zf.write(snap, rel)
            else:
                zf.write(p, rel)
    part.replace(out)
    for old in sorted(dest.glob("campaigns-*.zip"))[:-keep]:
        old.unlink(missing_ok=True)
    return out


def due(dest: Path | None = None) -> bool:
    last = last_backup(dest)
    return last is None or time.time() - last >= EVERY


if __name__ == "__main__":
    z = run()
    print(f"{z} ({z.stat().st_size / 1e6:.1f} MB)")
