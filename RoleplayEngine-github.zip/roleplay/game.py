"""Game facade: one campaign = one SQLite file. Ties ledger, substrate, rules, art and the DM."""
from __future__ import annotations

import re
import shutil
from pathlib import Path
from types import SimpleNamespace
from typing import Callable

from . import db
from .art import PROMPT_SYSTEM as ART_PROMPT_SYSTEM
from .art import ArtDirector, story_context
from .config import DIFFICULTY, EFFORTS, MODEL_ALIASES, Settings
from .engine import clock, geo
from .engine.dice import Dice
from .engine.ledger import Ledger, LedgerError
from .engine.rules import explosives, machines, matrix, sr_lite
from .substrate.store import Substrate


class Game:
    def __init__(self, path: Path | str, settings: Settings | None = None, llm=None,
                 dice: Dice | None = None, art: ArtDirector | None = None,
                 out: Callable[[str], None] = print):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.settings = settings or Settings()
        self.conn = db.connect(self.path)
        self.ledger = Ledger(self.conn)
        self.sub = Substrate(self.conn, self.settings.knobs)
        self.dice = dice or Dice()
        self._llm = llm
        self.out = out
        self.progress: Callable[..., None] = lambda text, key=None: None   # what the turn is doing (the table's work card)
        self.active_players: set[str] = set()       # handles at the table lately (the Discord session sets it)
        self.spend_turn: int | None = None          # the turn the spend log files calls under (run_turn sets it)
        self.passed: set[str] = set()               # handles that chose to sit this turn out (the Discord table sets it)
        self.art = art or ArtDirector(self.path.parent / f"{self.path.stem}_art",
                                      self.ledger.meta("art_style") or self.settings.art_style, out=out)
        self.art.db_path = self.path
        self.art.prompt_writer = self.art.prompt_writer or self._art_prompt
        self.art.enabled = self.ledger.meta("art", "on") == "on"
        self.undo_dir = self.path.parent / f"{self.path.stem}_undo"
        m = self.settings.models                       # table settings saved with the campaign
        m.dm = self.ledger.meta("dm_model", m.dm)
        m.dm_effort = self.ledger.meta("dm_effort", m.dm_effort)
        geo.ensure_all(self)                           # campaigns from before the map: every place gets a position
        from .substrate import rumors
        rumors.tidy(self)                              # (once: rumors the old spreading told via a PC or to the dead)
        from . import graphlog
        graphlog.attach(self)                          # the per-turn graph log, campaigns/<name>_graph/ (DESIGN.md §8f)
        from . import newparty
        newparty.recover(self)                         # (a new party the bot died in the middle of: put back first)

    # ── table settings (!gmmodel, !gmeffort, !difficulty) ───────────────
    def set_dm_model(self, name: str) -> str:
        name = name.strip().lower()
        model = MODEL_ALIASES.get(name, name)
        if model not in MODEL_ALIASES.values():
            raise LedgerError(f"Unknown model '{name}'. Options: {', '.join(MODEL_ALIASES)}.")
        self.settings.models.dm = model
        self.ledger.set_meta("dm_model", model)
        return model

    def set_dm_effort(self, level: str) -> str:
        level = level.strip().lower()
        if level not in EFFORTS:
            raise LedgerError(f"Effort must be one of: {', '.join(EFFORTS)}.")
        self.settings.models.dm_effort = level
        self.ledger.set_meta("dm_effort", level)
        return level

    def difficulty(self) -> dict:
        import json
        raw = self.ledger.meta("difficulty")
        d = json.loads(raw) if raw else {"level": "normal", **{k: v for k, v in DIFFICULTY["normal"].items()}}
        return d

    def set_difficulty(self, words: list[str]) -> dict:
        """`hard` | `threshold +1` | `opposition -2` - presets, or fine-tune one dial."""
        import json
        d = self.difficulty()
        if len(words) == 1 and words[0].lower() in DIFFICULTY:
            d = {"level": words[0].lower(), **DIFFICULTY[words[0].lower()]}
        elif len(words) == 2 and words[0].lower() in ("threshold", "opposition"):
            try:
                v = int(words[1])
            except ValueError:
                raise LedgerError("Use a number, e.g. `!difficulty opposition +1`.")
            d[words[0].lower()] = max(-3, min(3, v))
            d["level"] = "custom"
            d["stance"] = d.get("stance") or DIFFICULTY["normal"]["stance"]
        else:
            raise LedgerError(f"Try `!difficulty hard` ({' / '.join(DIFFICULTY)}) or `!difficulty threshold +1` / "
                              "`!difficulty opposition -1`.")
        self.ledger.set_meta("difficulty", json.dumps(d))
        return d

    def settings_line(self) -> str:
        d = self.difficulty()
        name = next((k for k, v in MODEL_ALIASES.items() if v == self.settings.models.dm), self.settings.models.dm)
        return (f"GM: {name}, effort {self.settings.models.dm_effort} | difficulty {d['level']} "
                f"(threshold {d['threshold']:+d}, opposition {d['opposition']:+d} - in the room and the Matrix) | "
                f"offscreen world {'on' if self.world_on() else 'off'} | {self.clock_line()}")

    @property
    def llm(self):
        if self._llm is None:
            from .dm.llm import LLM
            from .spend import Sink
            self._llm = LLM(self.settings.models)
            self._llm.usage.sink = Sink(self)          # every call goes in the folder's spend log (spend.py)
        return self._llm

    def close(self) -> None:
        self.art.shutdown()
        self.conn.close()

    # ── who plays whom (DESIGN.md §4: control) ──────────────────────────
    def companions(self) -> str:
        """What happens to an AWAY player's character (`!afk`): 'gm' plays them, or they sit 'idle'. (A PC nobody holds
        at all hangs back - the GM plays only the companions someone made, with `!companion` or the builder.)"""
        return self.ledger.meta("companions", "idle")

    def set_companions(self, on: bool) -> None:
        self.ledger.set_meta("companions", "gm" if on else "idle")

    def control_of(self, eid: str) -> str:
        """'player' (a human plays them), 'gm' (the GM plays them fully) or 'idle' (an absent player's)."""
        ent = self.ledger.get(eid)
        if not ent:
            return "gm"
        seat = self.conn.execute("SELECT afk FROM players WHERE handle IN (?, ?)",
                                 (ent["player"] or "\0", eid)).fetchone()
        if seat:                                             # a Discord player holds this character
            return "player" if not seat["afk"] else self.companions()
        row = self.conn.execute("SELECT mode FROM control WHERE entity_id=?", (eid,)).fetchone()
        if row:
            return row["mode"]
        return "idle" if ent["kind"] == "pc" else "gm"             # (parked: nobody's, and nobody made them a companion)

    def set_control(self, eid: str, mode: str, handle: str | None = None) -> None:
        if mode not in ("player", "gm", "idle"):
            raise LedgerError("mode must be player, gm or idle")
        self.conn.execute("INSERT OR REPLACE INTO control(entity_id, mode, handle, since_turn) VALUES(?,?,?,?)",
                          (eid, mode, handle, self.turn_no()))

    def character_for(self, handle: str) -> dict | None:
        """The character a player handle speaks for: their PC, or an NPC they inhabit."""
        pc = self.ledger.pc_for_player(handle)
        if pc:
            return pc
        ent = self.ledger.get(handle.strip().lower()) or self.ledger.find(handle)
        if ent and ent["kind"] == "npc":
            inhabited = self.conn.execute(
                "SELECT 1 FROM players WHERE handle=? UNION SELECT 1 FROM control WHERE entity_id=? AND mode='player'",
                (ent["id"], ent["id"])).fetchone()
            if inhabited:
                return ent
        return None

    def catch_up(self, eid: str, limit: int = 5) -> str:
        """What a player taking over a character needs: the sheet, recent first-hand memories,
        and for an NPC their own feelings. Never the GM's notes."""
        L, S = self.ledger, self.sub
        lines = [sr_lite.sheet(L, eid, full=True)]
        mem = sorted(S.witnessed_slices(eid, 40), key=lambda r: -r["created_turn"])[:limit]
        if mem:
            lines.append("\nRecently (what they saw):")
            lines += [f"- {m['text']}" for m in reversed(mem)]
        if L.get(eid)["kind"] == "npc":
            for b in S.beliefs_of(eid)[:4]:
                lines.append(f"- Feels: {b['text']}")
        return "\n".join(lines)

    # ── art ─────────────────────────────────────────────────────────────
    def request_art(self, eid: str, force: bool = False, direction: str = "") -> str:
        ent = self.ledger.require(eid)
        return self.art.request(self.conn, ent, story_context(self, ent["id"]), self.turn_no(), force, direction)

    # ── story time (engine/clock.py) ────────────────────────────────────
    def clock(self) -> int:
        return int(self.ledger.meta("clock", str(clock.DEFAULT_START)))

    def set_clock(self, minutes: int) -> int:
        """Every way the clock is set - a GM `time:` line that reads, the owner's `!time`, the console - answers an
        unread time line: the packet's "set it again" note would make the GM skip the time a second time."""
        self.ledger.set_meta("clock", str(max(0, int(minutes))))
        self.ledger.set_meta(clock.MISS, "")
        return self.clock()

    def advance_clock(self, minutes: int) -> int:
        return self.set_clock(self.clock() + max(0, min(clock.MAX_STEP, int(minutes))))

    def clock_line(self) -> str:
        return clock.fmt(self.clock())

    def world_on(self) -> bool:
        return self.ledger.meta("world", "on") == "on"

    def set_world(self, on: bool) -> None:
        self.ledger.set_meta("world", "on" if on else "off")

    def world_pass(self) -> list[str]:
        """Offscreen NPCs take their moves (synchronous; the Discord table runs it in the background)."""
        from .dm.world import run_pass
        return run_pass(self)

    def set_art(self, on: bool) -> None:
        self.art.enabled = on
        self.ledger.set_meta("art", "on" if on else "off")

    def _art_prompt(self, ent: dict, story: str, framing_style: str, direction: str, edit: bool = False) -> dict:
        schema = {"type": "object", "properties": {"prompt": {"type": "string"}, "caption": {"type": "string"}},
                  "required": ["prompt", "caption"], "additionalProperties": False}
        user = (f"MODE: {'EDIT the existing image (write CHANGE / PRESERVE)' if edit else 'GENERATE a new image'}\n\n"
                f"ENTITY: {ent['name']} ({ent['kind']})\n\nPUBLIC STORY SO FAR:\n{story}\n\n"
                f"FRAMING AND STYLE: {framing_style}"
                + (f"\n\nTHE CHANGE TO MAKE: {direction}" if direction else ""))
        return self.llm.structured(self.settings.models.commit, ART_PROMPT_SYSTEM, user, schema,
                                   max_tokens=2000, effort="low", purpose="art")

    def turn_no(self) -> int:
        row = self.conn.execute("SELECT COALESCE(MAX(id), 0) AS n FROM turns").fetchone()
        return row["n"]

    # ── scenes ──────────────────────────────────────────────────────────
    def current_scene_id(self) -> int:
        scene = self.ledger.current_scene()
        if scene is None:
            raise LedgerError("No active scene. Set up a campaign first.")
        return scene["id"]

    def enter_scene(self, ids, turn: int, scene_id: int | None = None) -> list[str]:
        sid = scene_id or self.current_scene_id()
        ids = [self.ledger.require(i)["id"] for i in ids]
        ids += machines.followers(self.ledger, ids, sid)     # the drones they're running come with them (§7a)
        # and a decker's live Matrix run comes with them: live T126, Filament's camera loop rode along from S11 into
        # S12 - the scene change alone would have closed it (matrix.carry; review 2026-10-27)
        riding = [eid for eid in ids if matrix.live(self.ledger, eid)]
        for eid in ids:                              # one place at a time
            for other in self.conn.execute("SELECT scene_id FROM scene_roster WHERE entity_id=? AND scene_id<>?",
                                           (eid, sid)).fetchall():
                self.ledger.leave(other["scene_id"], [eid])
            ent = self.ledger.get(eid)
            if ent and ent["props"].get("whereabouts"):          # back on screen: the scene says where they are
                self.ledger.update_entity(eid, props={k: v for k, v in ent["props"].items() if k != "whereabouts"})
            self.sub.ensure_entity(self.ledger.get(eid), turn)
        new, prior = self.ledger.enter(sid, ids, turn)
        for eid in riding:
            matrix.carry(self.ledger, eid)
        self.sub.mark_copresence(new, prior, turn)
        return new

    def leave_scene(self, ids, scene_id: int | None = None) -> None:
        sid = scene_id or self.current_scene_id()
        self.ledger.leave(sid, [self.ledger.require(i)["id"] for i in ids])

    def new_scene(self, title: str, location_id: str | None, bring: list[str], turn: int) -> int:
        prev = self.ledger.current_scene()
        if location_id:
            location_id = self.ledger.require(location_id)["id"]
        sid = self.ledger.create_scene(title, location_id, turn)
        self.sub.ensure_scene(sid, title, turn, prev["id"] if prev else None)
        members = ([location_id] if location_id else []) + list(bring)
        if members:
            self.enter_scene(members, turn, sid)
        return sid

    def resume_scene(self, scene_id: int, bring: list[str], turn: int) -> int:
        if self.ledger.scene(scene_id) is None:
            raise LedgerError(f"No scene S{scene_id}.")
        self.ledger.activate_scene(scene_id)
        if bring:
            self.enter_scene(bring, turn, scene_id)
        return scene_id

    # ── entities ────────────────────────────────────────────────────────
    def introduce(self, kind: str, name: str, description: str = "", template: str | None = None,
                  aliases=(), owner_id: str | None = None, rating: int | None = None,
                  nuyen: int | None = None, present: bool = False, turn: int = 0,
                  where: dict | None = None, model: str | None = None) -> tuple[str, bool]:
        """Create a tracked entity, or return the existing one with that name (no duplicates)."""
        existing = self.ledger.find(name)
        if existing and existing["kind"] == kind:
            if present:
                self.enter_scene([existing["id"]], turn)
            return existing["id"], False
        if kind == "npc":
            eid = sr_lite.build_npc(self.ledger, name, template or "civilian", description, aliases, turn=turn, nuyen=nuyen)
        elif kind == "location":
            eid = self.ledger.create_entity("location", name, description, aliases=aliases, turn=turn)
            w = where or {}                           # the engine does the geography (engine/geo.py)
            sc = self.ledger.current_scene()
            geo.place(self, eid, w.get("district"), w.get("near"), w.get("bearing"), w.get("distance_m"),
                      origin=sc["location_id"] if sc else None)
        elif kind == "item":
            known = explosives.catalog(name)          # a grenade by any name comes with its real stats
            eid = self.ledger.create_entity("item", name, description, aliases=aliases, turn=turn,
                                            props=known[1] if known else None)
            if owner_id:
                self.ledger.give(self.ledger.require(owner_id)["id"], eid, 1)
        elif kind in sr_lite.MACHINES:               # drones and vehicles come from the model catalog
            eid = machines.build_machine(self.ledger, name, model or name, owner_id and self.ledger.require(owner_id)["id"],
                                         turn, description, aliases)
        elif kind == "faction":                   # an organization: acts offscreen through its people
            eid = self.ledger.create_entity("faction", name, description, aliases=aliases, turn=turn)
            self.ledger.set_stat(eid, "reach", 2)
            self.ledger.set_stat(eid, "nuyen", int(nuyen or 10000))
        elif kind == "host":
            r = max(1, min(12, int(rating or 4)))
            eid = self.ledger.create_entity("host", name, description, aliases=aliases, props={"rating": r}, turn=turn)
        else:
            raise LedgerError("kind must be npc, location, item, host, faction, drone or vehicle.")
        ent = self.ledger.get(eid)
        self.sub.ensure_entity(ent, turn)
        if present and kind in ("npc", "item", "host", "drone", "vehicle"):          # (a faction is never "in the room")
            self.enter_scene([eid], turn)
        # art is requested at the end of the entity's first turn (commit), so the story shapes it
        return eid, True

    def create_pc(self, name: str, archetype: str, player: str | None = None, description: str = "",
                  turn: int = 0) -> str:
        eid = sr_lite.build_character(self.ledger, name, archetype, player, description, turn)
        self.sub.ensure_entity(self.ledger.get(eid), turn)
        return eid

    def merge_entities(self, keep: str, drop: str, turn: int) -> str:
        """Fold a duplicate into the real entity. Memory, links, notes, gear and presence move to
        `keep`; `drop` becomes an alias and a superseded node (a diode drop -> keep), never deleted."""
        k, d = self.ledger.require(keep), self.ledger.require(drop)
        if k["id"] == d["id"]:
            raise LedgerError("Can't merge an entity into itself.")
        c, kid, did = self.conn, k["id"], d["id"]
        c.execute("BEGIN")
        try:
            for item in self.ledger.holdings(did):                       # gear moves over
                self.ledger.take(did, item["id"], item["qty"])
                self.ledger.give(kid, item["id"], item["qty"], item["state"])
            c.execute("UPDATE OR IGNORE holdings SET item_id=? WHERE item_id=?", (kid, did))
            c.execute("DELETE FROM holdings WHERE item_id=?", (did,))
            for table, col in (("scene_roster", "entity_id"), ("scene_presence", "entity_id"),
                               ("members", "node_id"), ("annotates", "target_id"), ("knows", "holder"),
                               ("knows", "node_id")):
                c.execute(f"UPDATE OR IGNORE {table} SET {col}=? WHERE {col}=?", (kid, did))
                c.execute(f"DELETE FROM {table} WHERE {col}=?", (did,))
            for link in self.sub.links_of(did):                           # links re-point to the keeper
                c.execute("DELETE FROM links WHERE id=?", (link["id"],))
                if link["other"] != kid:
                    self.sub.link(kid, link["other"], link["kind"], link["strength"], turn, link["together"])
            e = c.execute("SELECT energy FROM energy WHERE node_id=?", (did,)).fetchone()
            if e:
                if self.sub.exists(kid):
                    c.execute("UPDATE energy SET energy=energy+? WHERE node_id=?", (e["energy"], kid))
                c.execute("DELETE FROM energy WHERE node_id=?", (did,))
            if self.sub.exists(did):
                c.execute("UPDATE nodes SET kind='merged', text=? WHERE id=?",
                          (f"(merged into {kid}) {d['name']}: {d['description']}", did))
                c.execute("INSERT OR IGNORE INTO supersedes(old_id, new_id, confidence, installed_by, turn) "
                          "VALUES(?,?,1.0,'merge',?)", (did, kid, turn))
            aliases = list(dict.fromkeys(k["aliases"] + [d["name"]] + d["aliases"]))
            self.ledger.update_entity(kid, aliases=aliases)
            self.ledger.update_entity(did, status="merged", tier=0)
            self.ledger.log(turn, "merge", kid, {"dropped": did})
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
        return f"Merged {d['name']} [{did}] into {k['name']} [{kid}]."

    def resolve_mentions(self, text: str) -> list[str]:
        """Entities named in free text (names and aliases, word-boundary, longest first)."""
        low, found = text.lower(), []
        for name, eid in self.ledger.name_index():
            if eid in found or len(name) < 3:
                continue
            if re.search(rf"(?<![a-z0-9]){re.escape(name)}(?![a-z0-9])", low):
                found.append(eid)
        return found

    def on(self, conn):
        """This game read through another connection (rulings.on_side hands one out): the table's own business - the
        roster, a dossier - mustn't wait out the GM's turn on the game thread. The engine's helpers work on it the
        same as on the game."""
        v = SimpleNamespace(conn=conn, ledger=Ledger(conn), sub=Substrate(conn, self.settings.knobs), art=self.art,
                            path=self.path, llm=self.llm, settings=self.settings, out=self.out)
        for name in ("clock", "clock_line", "character_for", "find_speaker", "current_scene_id", "resolve_mentions",
                     "turn_no"):
            setattr(v, name, getattr(Game, name).__get__(v))
        return v

    def find_speaker(self, label: str, scene_id: int | None = None) -> dict | None:
        """Who a line of dialogue belongs to. The GM labels speakers the way people talk - "Berit", "Hiroshi", "the
        Sergeant" - and an exact name match missed them, so their lines went out as a gray extra with no portrait.
        Past the exact name or alias: the person whose name has the label's words in it (someone in the scene first);
        still ambiguous, nobody. Only for speaker labels - in free text "cab" or "tail" would match too much."""
        L = self.ledger
        ent = L.find(label)
        if ent:
            return ent
        hits = self.resolve_mentions(label)
        if hits:
            return L.get(hits[0])
        words = [w for w in re.findall(r"[a-z0-9']+", label.lower()) if w != "the"]
        if not words:
            return None
        people = [e for e in L.entities() if e["kind"] in ("pc", "npc")
                  and all(w in re.findall(r"[a-z0-9']+", e["name"].lower()) for w in words)]
        if len(people) > 1 and scene_id:
            here = set(L.roster(scene_id))
            people = [e for e in people if e["id"] in here] or people
        return people[0] if len(people) == 1 else None

    # ── undo ────────────────────────────────────────────────────────────
    def snapshot(self, turn_id: int) -> None:
        db.snapshot(self.conn, self.undo_dir / f"before_{turn_id:06d}.db")
        snaps = sorted(self.undo_dir.glob("before_*.db"))
        for old in snaps[:-self.settings.undo_depth]:
            old.unlink(missing_ok=True)

    def undo(self) -> str:
        snaps = sorted(self.undo_dir.glob("before_*.db")) if self.undo_dir.exists() else []
        if not snaps:
            from . import newparty
            return newparty.undo_note(self) or "Nothing to undo."      # (a new party isn't a turn - newparty.py)
        snap = snaps[-1]
        from . import narrative, rulings
        from .dm import pacing
        put_back = rulings.keep(self.conn)                  # (the table's house rules aren't part of the turn)
        put_story = narrative.keep(self.conn)               # (nor are its story directions)
        put_pacing = pacing.keep(self.conn)                 # (nor a loop complaint to the GM, or a !stuck)
        db.restore(self.conn, snap)
        put_back()
        put_story()
        put_pacing()
        snap.unlink(missing_ok=True)
        from . import graphlog
        graphlog.undone(self, int(snap.stem.split("_")[1]))   # (the graph log matches the record: its file goes too)
        return f"Undid turn {int(snap.stem.split('_')[1])}: ledger, memory and scene restored."

    def wipe_undo(self) -> None:
        shutil.rmtree(self.undo_dir, ignore_errors=True)

    # ── turns ───────────────────────────────────────────────────────────
    def run_turn(self, inputs: list[tuple[str, str]], private: str | None = None):
        from .dm.turn import run_turn
        return run_turn(self, inputs, private)

    def advance(self, eid: str, ref: str) -> dict:
        """Spend karma (sr_lite.advance) - but not mid-fight: a runner trains between jobs, not between bullets."""
        from . import encounters
        if encounters.active(self):
            raise LedgerError("Not mid-fight - karma is spent once the shooting stops.")
        return sr_lite.advance(self.ledger, self.turn_no(), eid, ref)

    def undo_target(self) -> dict | None:
        """The turn !undo would take back: {'id', 'private'} (private = a whisper's sender)."""
        snaps = sorted(self.undo_dir.glob("before_*.db")) if self.undo_dir.exists() else []
        if not snaps:
            return None
        tid = int(snaps[-1].stem.split("_")[1])
        row = self.conn.execute("SELECT private FROM turns WHERE id=?", (tid,)).fetchone()
        return {"id": tid, "private": row["private"] if row else None}

    def askdm(self, handle: str, question: str) -> str:
        from .dm.turn import askdm
        return askdm(self, handle, question)
