"""The turn divider (DESIGN.md §4): a slim neon strip between turns, so the channel reads turn by turn.

    ━━━━━━  TURN 75  ·  DAY 2  01:45  ·  GRANNY BRISK'S ROOMS  ━━━━━━

Posted after the GM's answer (the story, then any map), it opens the next turn: the players' posts that follow
belong under it. Transparent, so it sits in the chat like a rule line, and drawn small enough that Discord's
shrinking keeps it readable. `!dividers picture | line | off` (owner); `line` is the same thing as text.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

from .engine import clock
from .sheetart import CYAN, DIM, INK, MAGENTA, font

W, H = 900, 58
STYLES = ("picture", "line", "off")


def parts(game) -> tuple[int, str, str]:
    """(the turn about to start, story time, where the crew is)."""
    L = game.ledger
    scene = L.current_scene()
    where = ""
    if scene:
        loc = L.get(scene["location_id"]) if scene["location_id"] else None
        where = loc["name"] if loc else scene["title"]
    return game.turn_no() + 1, clock.short(game.clock()), where


def line(game) -> str:
    n, when, where = parts(game)
    return f"-# ━━━━━━━━  **TURN {n}**  ·  {when}" + (f"  ·  {where}" if where else "") + "  ━━━━━━━━"


def render(game, out: Path) -> Path:
    n, when, where = parts(game)
    head, tail = f"TURN {n}", "  ·  ".join(x for x in (when.upper(), where.upper()) if x)
    hf, tf = font(25, "Bold SemiCondensed"), font(21, "SemiBold SemiCondensed")
    while tf.getlength(tail) > W - 260 - hf.getlength(head) and len(tail) > 8:
        tail = tail[:-4].rstrip(" ·") + "..."
    gap = 18
    chip_w = hf.getlength(head) + gap + tf.getlength(tail) + 48
    x0, x1, cy = (W - chip_w) / 2, (W + chip_w) / 2, H / 2

    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    for a, b in ((12, x0 - 10), (x1 + 10, W - 12)):                       # the rule, either side of the chip
        g.line([(a, cy), (b, cy)], fill=CYAN + (200,), width=5)
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(4)))
    d = ImageDraw.Draw(img)
    for a, b in ((12, x0 - 10), (x1 + 10, W - 12)):
        d.line([(a, cy), (b, cy)], fill=CYAN + (255,), width=2)
    for x in (12, W - 12):                                                 # magenta end ticks
        d.line([(x, cy - 9), (x, cy + 9)], fill=MAGENTA + (255,), width=3)
    d.rounded_rectangle([x0, 6, x1, H - 6], 14, fill=(13, 19, 30, 236), outline=CYAN + (255,), width=2)
    d.text((x0 + 24, cy), head, font=hf, fill=CYAN, anchor="lm")
    d.text((x0 + 24 + hf.getlength(head) + gap, cy + 1), tail, font=tf, fill=INK if not where else DIM, anchor="lm")
    if where:                                                              # the time bright, the place a touch dimmer
        t_when = when.upper()
        d.text((x0 + 24 + hf.getlength(head) + gap, cy + 1), t_when, font=tf, fill=INK, anchor="lm")
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)
    return out
