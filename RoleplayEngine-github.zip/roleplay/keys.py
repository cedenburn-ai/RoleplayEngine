"""Where the keys come from - the one place: the Discord bot token, the Anthropic key (the GM), the OpenAI key (art).

For each key the first of these that has it wins:
    1. config.toml at the project root (or the file ROLEPLAY_CONFIG names), its [keys] table - see config.example.toml
    2. the environment variable: DISCORD_BOT_TOKEN, ANTHROPIC_API_KEY, OPENAI_API_KEY
    3. on Windows, the user environment (a window opened before `setx` ran doesn't inherit it)
    4. the Discord token only: the legacy token file - ROLEPLAY_TOKEN_FILE, else the old C# bot's
       DungeonsAndDiscords/Program.cs if it's there
Blank values and the example's placeholders ("", "...", "your-...") don't count.

A key is never printed, logged or written anywhere: source() says where one came from, never what it is. At startup
export_api_keys() puts the two API keys into os.environ (config.toml wins over a variable already set), so the
Anthropic and OpenAI SDKs and the os.environ checks around art find them. The Discord token stays in the bot's own
memory (get("discord_token")).
"""
from __future__ import annotations

import codecs
import os
import re
import sys
import tomllib
from pathlib import Path

from .config import ROOT

CONFIG = ROOT / "config.toml"
TOKEN_FILE = ROOT / "DungeonsAndDiscords" / "Program.cs"
ENV = {"discord_token": "DISCORD_BOT_TOKEN", "anthropic_api_key": "ANTHROPIC_API_KEY",
       "openai_api_key": "OPENAI_API_KEY"}
API_KEYS = ("anthropic_api_key", "openai_api_key")       # the two the SDKs read from os.environ
PLACEHOLDER = re.compile(r"\.{3,}|<[^>]*>|your[-_ ].*|change[-_ ]?me|x{3,}", re.IGNORECASE)
TOKEN_LINE = re.compile(r'DISCORD_TOKEN\s*=\s*"([^"]+)"')

_exported: dict[str, tuple[str, str]] = {}               # env var -> (what export_api_keys put there, from where)


def config_path() -> Path:
    return Path(os.environ.get("ROLEPLAY_CONFIG") or CONFIG)


def token_file() -> Path:
    return Path(os.environ.get("ROLEPLAY_TOKEN_FILE") or TOKEN_FILE)


def how_to_set(name: str) -> str:
    """The fix, for a message: config.toml first, then the variable."""
    return f"put {name} in config.toml (copy config.example.toml) or set {ENV[name]}"


def _usable(value) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value if value and not PLACEHOLDER.fullmatch(value) else None


def _where(p: Path) -> str:
    return str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p)


def _read(p: Path) -> dict:
    """The file as TOML. UTF-8 with a BOM, and UTF-16 with one, read too: Notepad's "UTF-8 with BOM" and "UTF-16 LE",
    and Windows PowerShell 5's `>` and Out-File, write those."""
    raw = p.read_bytes()
    if raw.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return tomllib.loads(raw.decode("utf-16"))
    return tomllib.loads(raw.decode("utf-8-sig"))


def _config() -> dict:
    """config.toml's [keys] table - {} with no file, or one that won't parse (problem() says why)."""
    try:
        table = _read(config_path()).get("keys")
    except (OSError, UnicodeError, tomllib.TOMLDecodeError):
        return {}
    return table if isinstance(table, dict) else {}


def problem() -> str | None:
    """What's wrong with the config file, if anything - its name and the line, never a value."""
    p = config_path()
    if not p.exists():
        return f"ROLEPLAY_CONFIG names {p}, which isn't there" if os.environ.get("ROLEPLAY_CONFIG") else None
    try:
        data = _read(p)
    except OSError as exc:
        return f"{p.name} can't be read ({exc.strerror})"
    except UnicodeError:
        return f"{p.name} isn't UTF-8 text - save it as UTF-8 (Notepad: Save as, Encoding: UTF-8)"
    except tomllib.TOMLDecodeError as exc:
        return f"{p.name} isn't valid TOML: {exc}"
    return None if isinstance(data.get("keys"), dict) else f"{p.name} has no [keys] table"


def _user_env(var: str) -> str | None:
    """Windows: the user environment, read from the registry. Nowhere else has one."""
    if sys.platform != "win32":
        return None
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            return winreg.QueryValueEx(key, var)[0]
    except OSError:
        return None


def _legacy_token() -> str | None:
    try:
        m = TOKEN_LINE.search(token_file().read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return None
    return m.group(1) if m else None


def _lookup(name: str) -> tuple[str | None, str | None]:
    """(the key, where it came from) - the first place that has it, or (None, None)."""
    var = ENV[name]
    value = _usable(_config().get(name))
    if value:
        return value, _where(config_path())
    value = _usable(os.environ.get(var))
    if value:
        put = _exported.get(var)
        return value, put[1] if put and put[0] == value else "environment"     # (where the export found it)
    value = _usable(_user_env(var))
    if value:
        return value, "user environment"
    if name == "discord_token":
        value = _usable(_legacy_token())
        if value:
            return value, _where(token_file())
    return None, None


def get(name: str) -> str | None:
    """The key itself - for the code that uses it, never for a message or a log."""
    return _lookup(name)[0]


def source(name: str) -> str | None:
    """Where the key comes from: 'config.toml', 'environment', 'user environment', the token file - or None."""
    return _lookup(name)[1]


def export_api_keys() -> list[str]:
    """Startup: the Anthropic and OpenAI keys into os.environ, config.toml winning over a variable already set.
    Returns the names of the keys it found (names, not values)."""
    found = []
    for name in API_KEYS:
        value, where = _lookup(name)
        if value:
            os.environ[ENV[name]] = value
            _exported[ENV[name]] = (value, where)
            found.append(name)
    return found


def status() -> dict:
    """For the dashboard: where each key comes from (None: not set), the config file, what's wrong with it."""
    p = config_path()
    return {**{name: source(name) for name in ENV}, "config": _where(p) if p.exists() else None, "error": problem()}
