"""Console table: play a multiplayer session from one terminal.

    python -m roleplay demo --new        fresh demo campaign (Razor, Ghost, Kaz's bar)
    python -m roleplay demo              continue it

At the prompt:
    razor: I slide the chip across the bar      queue an action for a player
    !as ghost                                   set who plain lines belong to
    (blank line) or !go                         resolve the queued actions as one turn
"""
from __future__ import annotations

import argparse
import sys
import textwrap

from . import keys
from .config import CAMPAIGN_DIR
from .engine.ledger import LedgerError
from .engine.rules import sr_lite
from .game import Game
from .setup import SEEDS, setup_demo

HELP = """Commands
  name: text             queue an in-character action/line for that player
  !as name               plain lines now belong to this player
  (blank) / !go          resolve queued actions as one turn
  !ooc text              out of character - ignored by the DM, never stored
  !askgm [name:] text    ask the system about rules/your sheet/what you remember (also !askdm)
  !sheet [name]          character sheet          !who      who is in the scene
  !scene                 scene info               !newchar NAME ARCHETYPE [player]
  !mem [T#]              the memory packet the DM saw (last turn, or any turn)
  !energy                hottest nodes            !notes ID  DM notes on a node (GM view)
  !node ID               inspect a node and its links
  !cost                  API spend                !undo     undo the last turn
  !graph [port]          open the graph browser   !merge KEEP DROP  fold a duplicate entity
  !minds                 NPCs in the scene reflect now (update how they feel)
  !recap                 "previously on..." - the Shadow Beat segment, where things stand, NPC dossiers
  !gmmodel opus|sonnet|haiku|fable     !gmeffort low|medium|high|xhigh|max
  !difficulty story|easy|normal|hard|brutal  (or: !difficulty threshold +1 / opposition -1) - the Matrix too
  !settings              show GM model, effort and difficulty
  !time [+2h|08:00]      the story clock (show, or set it)
  !rulings               the table's house rules   !ruling add TEXT | veto R# | edit R# TEXT | drop R#
  !map [here|gm|restyle] render the metroplex map (saved as a PNG)   !net [name]  the Matrix network map
  !charactersheet [name] the full sheet: attributes, monitors, dice pools, gear (alias !cs)
  !advance [name:] #     spend karma on a stat (numbers on the sheet)   !karma NAME +N [reason]
  !art [on|off|NAME]     art status / toggle / show an entity's image  !art redo NAME [what to change]
  !pov NPC               what that NPC knows: persona, agendas, witnessed, heard, beliefs (GM view)
  !world [on|off|now]    the offscreen world: agendas, hooks, offscreen events (GM view); now = run a pass
  !whisper [name:] text  a private turn: only that character (and whoever notices) will know
  !inhabit NAME          play that character yourself (a PC, or step into an NPC)
  !dmplay NAME / !idle NAME   the GM plays them / they sit idle     !companions on|off  (unclaimed PCs)
  !newparty [3 weeks] [| how it ended]   a new crew in the same world: the PCs become NPCs, the story skips ahead
                         (then !newparty confirm; !newparty undo takes it back before the new crew's first turn)
  !help                  this                     !quit
Archetypes: """ + ", ".join(sr_lite.ARCHETYPES)


def art_command(g: Game, rest: str) -> str:
    """!art | !art on/off | !art NAME | !art redo NAME [what to change]"""
    words = rest.split()
    if not words:
        rows = g.conn.execute("SELECT status, COUNT(*) AS n FROM art GROUP BY status").fetchall()
        counts = ", ".join(f"{r['n']} {r['status']}" for r in rows) or "none yet"
        return (f"  art: {'on' if g.art.enabled else 'off'} via {g.art.provider.name} {g.art.provider.model} "
                f"| images: {counts} | folder: {g.art.dir}")
    if words[0].lower() in ("on", "off"):
        g.set_art(words[0].lower() == "on")
        return f"  art {'on' if g.art.enabled else 'off'}"
    redo = words[0].lower() == "redo"
    name = words[1] if redo and len(words) > 1 else words[0]
    ent = g.ledger.find(name)
    if not ent:
        return f"  ! no entity '{name}'"
    if redo:
        how = g.request_art(ent["id"], force=True, direction=" ".join(words[2:]))
        return f"  {ent['name']}: {how} (new version; the old one is kept)"
    rec = g.art.latest(g.conn, ent["id"])
    if not rec:
        how = g.request_art(ent["id"])
        return f"  {ent['name']} has no art yet - {how}"
    return (f"  {ent['name']} v{rec['version']} [{rec['status']}] {rec['path']}\n  Caption: {rec['caption']}\n"
            f"  Prompt: {rec['prompt'][:500]}")


def wrap(text: str) -> str:
    out = []
    for para in text.split("\n"):
        out.append(textwrap.fill(para, 100) if para.strip() else "")
    return "\n".join(out)


class Console:
    def __init__(self, game: Game):
        self.game = game
        self.queue: list[tuple[str, str]] = []
        self.speaker: str | None = None
        self.last_packet = ""

    def pcs(self) -> list[dict]:
        return self.game.ledger.entities(kind="pc")

    def prompt(self) -> str:
        n = f" ({len(self.queue)} queued)" if self.queue else ""
        return f"[{self.speaker or '?'}]{n}> "

    def run(self) -> None:
        g = self.game
        scene = g.ledger.current_scene()
        print(f"\n== {g.path.stem} ==  scene S{scene['id']}: {scene['title']}" if scene else "")
        print("Players: " + ", ".join(f"{p['player']} ({p['name']})" for p in self.pcs()))
        print("Type '!help' for commands. Queue actions as 'name: text', then a blank line to resolve.\n")
        if self.pcs():
            self.speaker = self.pcs()[0]["player"]
        while True:
            try:
                line = input(self.prompt())
            except (EOFError, KeyboardInterrupt):
                print()
                break
            try:
                if not self.handle(line.strip()):
                    break
            except LedgerError as exc:
                print(f"  ! {exc}")
            except KeyboardInterrupt:
                print("\n  (interrupted - turn rolled back)")

    def handle(self, line: str) -> bool:
        g, L = self.game, self.game.ledger
        if not line or line == "!go":
            if self.queue:
                self.resolve()
            return True
        if line.startswith("((") or line.lower().startswith("!ooc"):
            print("  (ooc - the DM ignores this)")
            return True
        if line.startswith("!"):
            cmd, rest = ((line[1:].split(None, 1)) + ["", ""])[:2]   # any whitespace ends the command (phones send newlines)
            cmd, rest = cmd.lower(), rest.strip()
            cmd = {"askgm": "askdm", "ask": "askdm", "cs": "charactersheet", "spend": "advance"}.get(cmd, cmd)
            if cmd in ("quit", "exit", "q"):
                return False
            if cmd == "help":
                print(HELP)
            elif cmd == "as":
                ch = g.character_for(rest)
                if ch:
                    self.speaker = ch["player"] if ch["kind"] == "pc" else ch["id"]
                else:
                    print(f"  ! no player '{rest}' (to play an NPC: !inhabit NAME)")
            elif cmd in ("whisper", "w"):
                handle, text = self.speaker, rest
                head, sep, tail = rest.partition(":")
                ch = g.character_for(head) if sep and " " not in head.strip() else None
                if ch:
                    handle, text = (ch["player"] if ch["kind"] == "pc" else ch["id"]), tail.strip()
                ch = g.character_for(handle or "")
                if not ch or not text:
                    print("  ! usage: !whisper [name:] what you do privately")
                else:
                    print(f"  ...{ch['name']} whispers to the GM...")
                    res = g.run_turn([(handle, text)], private=ch["id"])
                    self.last_packet = res.packet
                    print("\n" + wrap(res.narration) + "\n")
                    print(f"  [T{res.turn_id} WHISPER -> memory {res.slice_id}, witnesses: "
                          f"{', '.join(e for e, r in res.info['members'].items() if r != 'location')} | ${res.cost:.3f}]")
                    self.world()
            elif cmd == "inhabit":
                ent = L.find(rest)
                if not ent or ent["kind"] not in ("pc", "npc"):
                    print("  ! who?")
                else:
                    handle = ent["player"] if ent["kind"] == "pc" else ent["id"]
                    g.set_control(ent["id"], "player", handle)
                    self.speaker = handle
                    print(f"  You are now playing {ent['name']}. Catch-up:\n" + g.catch_up(ent["id"]))
            elif cmd in ("dmplay", "idle"):
                ent = L.find(rest)
                if not ent or ent["kind"] not in ("pc", "npc"):
                    print("  ! who?")
                else:
                    g.set_control(ent["id"], "gm" if cmd == "dmplay" else "idle")
                    print(f"  {ent['name']}: {'the GM plays them now' if cmd == 'dmplay' else 'idle (present, passive)'}")
            elif cmd == "companions":
                if rest.lower() in ("on", "off"):
                    g.set_companions(rest.lower() == "on")
                print(f"  unclaimed PCs are {'played by the GM' if g.companions() == 'gm' else 'idle'}")
            elif cmd == "sheet":
                pc = L.pc_for_player(rest or self.speaker or "") or L.find(rest)
                print(sr_lite.sheet(L, pc["id"]) if pc else "  ! who?")
            elif cmd == "who":
                sid = g.current_scene_id()
                for eid in L.roster(sid):
                    e = L.get(eid)
                    played = {"player": "player", "gm": "GM-played", "idle": "idle"}[g.control_of(eid)] \
                        if e["kind"] in ("pc", "npc") else ""
                    print(f"  {e['name']} [{eid}] {e['kind']}" + (f" ({played}) - {sr_lite.condition_line(L, eid)}"
                                                                   if e["kind"] in ("pc", "npc") else ""))
            elif cmd == "scene":
                s = L.current_scene()
                print(f"  S{s['id']}: {s['title']} @ {s['location_id']}")
                node = g.sub.node(f"S{s['id']}")
                if node:
                    print(f"  {node['text']}")
            elif cmd == "newchar":
                parts = rest.split()
                if len(parts) < 2:
                    print("  usage: !newchar NAME ARCHETYPE [player]")
                else:
                    eid = g.create_pc(parts[0], parts[1], parts[2] if len(parts) > 2 else parts[0].lower(),
                                      turn=g.turn_no())
                    g.enter_scene([eid], g.turn_no())
                    print(sr_lite.sheet(L, eid))
            elif cmd == "askdm":
                handle, question = self.speaker or "", rest
                if ":" in rest[:20]:
                    handle, _, question = rest.partition(":")
                print(wrap(g.askdm(handle.strip(), question.strip())))
            elif cmd == "mem":
                if rest:
                    row = g.conn.execute("SELECT packet FROM turns WHERE id=?", (int(rest.lstrip("Tt")),)).fetchone()
                    print(row["packet"] if row and row["packet"] else "  (no packet stored for that turn)")
                else:
                    print(self.last_packet or "  (no turn yet this session)")
            elif cmd == "energy":
                mean = g.sub.system_mean() or 1
                for r in g.sub.top_energy(15):
                    print(f"  {r['energy'] / mean:5.2f}x  [{r['id']}] {r['kind']:6} {r['text'][:80]}")
            elif cmd == "notes":
                for n in g.sub.notes_for(rest, 20):
                    print(f"  [{n['id']}] (T{n['created_turn']}) {n['text']}")
            elif cmd == "node":
                node = g.sub.node(rest)
                if not node:
                    print("  ! no such node")
                else:
                    print(f"  [{node['id']}] {node['kind']}: {node['text']}")
                    print(f"  energy {g.sub.energy_of(node['id']):.3f} ({g.sub.ratio(node['id']):.2f}x mean)")
                    for link in sorted(g.sub.links_of(node["id"]), key=lambda d: -d["strength"])[:15]:
                        print(f"    -> [{link['other']}] {link['kind']} strength {link['strength']:.1f}"
                              + (f", {link['together']} scenes together" if link["together"] else ""))
            elif cmd == "cost":
                u = g._llm.usage if g._llm else None
                print(f"  this session: ${u.total:.4f} over {u.calls} calls" if u else "  this session: $0")
                if u:
                    for m, d in u.by_model.items():
                        print(f"    {m}: ${d['cost']:.4f}  in {d['in']} out {d['out']} "
                              f"cache-read {d['cache_read']} cache-write {d['cache_write']}")
                print(f"  campaign total: ${L.total_cost():.4f}")
            elif cmd == "undo":
                self.queue.clear()
                print("  " + g.undo())
            elif cmd == "gmmodel":
                if rest:
                    g.set_dm_model(rest)
                print("  " + g.settings_line())
            elif cmd == "gmeffort":
                if rest:
                    g.set_dm_effort(rest)
                print("  " + g.settings_line())
            elif cmd == "difficulty":
                if rest:
                    d = g.set_difficulty(rest.split())
                    print(f"  {d.get('stance', '')}")
                print("  " + g.settings_line())
            elif cmd == "advance":
                head, sep, tail = rest.partition(":")
                ch = g.character_for(head.strip()) if sep else g.character_for(self.speaker or "")
                print("  " + g.advance(ch["id"], (tail if sep else rest).strip())["card"]
                      if ch else "  ! who?")
            elif cmd == "karma":
                words = rest.split()
                ch = L.find(words[0]) if words else None
                if ch and len(words) >= 2:
                    print("  " + sr_lite.award_karma(L, g.turn_no(), ch["id"], int(words[1]), " ".join(words[2:])))
                else:
                    print("  " + " · ".join(f"{p['name']} {int(L.stat(p['id'], 'karma'))}" for p in L.entities(kind="pc")))
            elif cmd in ("charactersheet", "cs", "character"):
                from . import charsheet
                ch = (L.find(rest) if rest else None) or g.character_for(self.speaker or "")
                print(charsheet.text(charsheet.cards(g, ch["id"])) if ch else "  ! who?")
            elif cmd == "net":
                from . import netmap
                who = (L.find(rest) if rest else None) or g.character_for(self.speaker or "")
                print("  " + str(netmap.render(g, who["id"], gm=True)) if who else "  ! who?")
            elif cmd == "map":
                from . import maps
                view = rest.lower() or "metro"
                if view == "restyle":
                    from .art import provider_from_env
                    print("  repainting the map...", maps.restyle(provider_from_env()))
                    view = "metro"
                print("  " + str(maps.render(g, "here" if view == "here" else "metro", view == "gm")))
            elif cmd in ("rulings", "ruling"):
                from . import rulings
                verb, _, tail = rest.partition(" ")
                verb, tail = verb.lower(), tail.strip()
                if verb == "add":
                    print("  " + str(rulings.add(g, tail, "owner")["id"]))
                elif verb in ("veto", "drop"):
                    rulings.retire(g, tail, "vetoed" if verb == "veto" else "dropped", "console")
                elif verb == "edit":
                    rid, _, text = tail.partition(" ")
                    rulings.add(g, text, "owner", rid)
                print(rulings.listing(g).replace("**", ""))
            elif cmd == "time":
                if rest:
                    from .engine import clock
                    try:
                        g.set_clock(clock.parse(rest, g.clock()))
                    except ValueError as exc:
                        print(f"  ! {exc}")
                print("  " + g.clock_line())
            elif cmd == "settings":
                print("  " + g.settings_line())
            elif cmd == "art":
                print(art_command(g, rest))
            elif cmd == "merge":
                parts = rest.split()
                if len(parts) != 2:
                    print("  usage: !merge KEEP_ID DROP_ID")
                else:
                    print("  " + g.merge_entities(parts[0], parts[1], g.turn_no()))
            elif cmd == "graph":
                if getattr(self, "graph_server", None) is None:
                    from .browser.server import serve
                    port = int(rest) if rest.isdigit() else 8765
                    self.graph_server = serve(g.path, port, background=True)
                    print(f"  graph browser: http://127.0.0.1:{self.graph_server.server_port}  (auto-refreshes as you play)")
                else:
                    print(f"  graph browser already running: http://127.0.0.1:{self.graph_server.server_port}")
            elif cmd == "pov":
                ent = L.find(rest)
                if not ent:
                    print("  ! who?")
                else:
                    eid, t = ent["id"], g.turn_no()
                    from .substrate.packet import slice_line
                    print(f"  {ent['name']}'s point of view (GM eyes only)")
                    from .dm import world
                    if world.persona_line(ent):
                        print(wrap("  Persona: " + world.persona_line(ent)))
                    for a in world.agendas_of(g, eid):
                        print(f"  Agenda [{a['id']}]: {a['goal']} ({a['steps']} step(s), next ~T{a['next_turn']})")
                    att = {k.split(':', 1)[1]: v for k, v in L.stats(eid).items() if k.startswith("attitude:")}
                    if att:
                        print("  Attitudes: " + ", ".join(f"{(L.get(k) or {}).get('name', k)} {int(v):+d}" for k, v in att.items()))
                    for b in g.sub.beliefs_of(eid):
                        print(f"  Believes [{b['id']}] (T{b['created_turn']}): {b['text']}")
                    print("  Witnessed (hottest first):")
                    for row in g.sub.witnessed_slices(eid, 8):
                        print("    " + slice_line(g, row, t)[:220])
                    for h in g.sub.heard(eid, 6):
                        src = (L.get(h["source"]) or {}).get("name", "someone") if h.get("source") else "someone"
                        print(f"  Heard ({h['how']} via {src}): [{h['id']}] {h['text'][:180]}")
                    for n in g.sub.notes_for(eid, 4):
                        print(f"  DM note [{n['id']}] (T{n['created_turn']}): {n['text'][:200]}")
            elif cmd == "world":
                from .dm import world
                if rest.lower() in ("on", "off"):
                    g.set_world(rest.lower() == "on")
                elif rest.lower() == "now":
                    for line in g.world_pass() or ["  (nothing to do)"]:
                        print("  " + line)
                print(f"  offscreen world: {'on' if g.world_on() else 'off'}")
                print(wrap(world.summary(g)))
            elif cmd == "recap":
                from . import recap
                rec = recap.build(g)
                if rec is None:
                    print("  (nothing to recap yet)")
                else:
                    print(wrap(rec["broadcast"]))
                    for s in rec["standing"]:
                        print("  * " + s)
                    for d in rec["dossiers"]:
                        print(f"  dossier: {d['name']} -> {d['image']}")
            elif cmd == "minds":
                from .dm.minds import reflect_scene
                reflect_scene(g, g.current_scene_id(), g.turn_no())
            elif cmd == "newparty":
                self.new_party(rest)
            else:
                print("  ! unknown command - !help")
            return True
        # in-character input
        handle, text = self.speaker, line
        head, sep, tail = line.partition(":")
        ch = g.character_for(head) if sep and " " not in head.strip() else None
        if ch:
            handle, text = (ch["player"] if ch["kind"] == "pc" else ch["id"]), tail.strip()
        if not handle:
            print("  ! who is speaking? use 'name: text' or !as name")
            return True
        self.queue.append((handle, text))
        return True

    def resolve(self) -> None:
        inputs, self.queue = self.queue, []
        print("  ...the GM considers...")
        res = self.game.run_turn(inputs)
        self.last_packet = res.packet
        print("\n" + wrap(res.narration) + "\n")
        print(f"  [T{res.turn_id} -> memory {res.slice_id} | ${res.cost:.3f}]")
        self.world()

    def world(self) -> None:
        """The offscreen world moves after each turn (GM-side output; the console is the GM's view)."""
        for line in self.game.world_pass():
            print("  " + line)

    def new_party(self, rest: str) -> None:
        """!newparty [3 weeks] / !newparty undo - what it will do; then !newparty confirm within two minutes
        (newparty.py; the console is the owner's seat)."""
        import time
        from . import newparty
        how_long, ending = newparty.split_request(rest)          # ("3 weeks | how the old story ended")
        g, word = self.game, how_long.lower()
        if word == "confirm":
            p, self.pending_party = getattr(self, "pending_party", None), None
            if not p or p["expires"] < time.time():
                print("  ! nothing to confirm - !newparty [3 weeks] (or !newparty undo) first")
                return
            self.queue.clear()
            if p["kind"] == "undo":
                rec = newparty.undo(g)
                print(f"  the new party is taken back - {', '.join(o['name'] for o in rec['old_crew']) or 'the old crew'}"
                      f" are back, {g.clock_line()} (from {rec['backup']})")
                for n in rec.get("ledger_notes") or []:
                    print(f"  (ledger: {n})")
                return
            res = newparty.run(g, p["gap"], p["label"], ending=p["ending"])
            c = newparty.card(g, res["record"])
            print("\n" + wrap(f"{c['title']}\n{c['description']}") + "\n")
            print(wrap(newparty.owner_text(g, res)))
            return
        if word in ("undo", "back", "restore"):
            rec = newparty.can_undo(g)
            print(wrap("  " + newparty.undo_confirm_text(rec)))
            self.pending_party = {"kind": "undo", "expires": time.time() + newparty.CONFIRM_SECONDS}
        else:
            gap, label = newparty.parse_gap(how_long)
            print(wrap("  " + newparty.confirm_text(newparty.preview(g, gap, label, ending))))
            self.pending_party = {"kind": "run", "gap": gap, "label": label, "ending": ending,
                                  "expires": time.time() + newparty.CONFIRM_SECONDS}
        print("  !newparty confirm (within 2 minutes) to go ahead")


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay", description="RoleplayEngine console table")
    ap.add_argument("campaign", nargs="?", default="demo")
    ap.add_argument("--new", action="store_true", help="start the campaign fresh (deletes the existing file)")
    ap.add_argument("--seed", type=int, help="dice seed (for reproducible runs)")
    args = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if keys.problem():
        print(f"[keys] {keys.problem()} - looking in the environment instead", flush=True)
    if "anthropic_api_key" not in keys.export_api_keys():      # (as the bot does - not an SDK traceback on turn one)
        raise SystemExit(f"No Anthropic API key - the GM can't think without one: "
                         f"{keys.how_to_set('anthropic_api_key')}, and run again.")

    path = CAMPAIGN_DIR / f"{args.campaign}.db"
    if args.new and path.exists():
        path.unlink()
        for suffix in ("-wal", "-shm"):
            path.with_name(path.name + suffix).unlink(missing_ok=True)
    from .engine.dice import Dice
    game = Game(path, dice=Dice(args.seed))
    if args.new:
        game.wipe_undo()
    if game.ledger.current_scene() is None:
        if args.campaign == "demo":
            setup_demo(game)
            print("Seeded the demo campaign: Razor (street samurai, player 'razor') and Ghost (decker, player "
                  "'ghost') are back at Kaz's bar with a hot Renraku datachip.")
        elif args.campaign in SEEDS:
            SEEDS[args.campaign](game)
            print(f"Seeded the {args.campaign} campaign.")
        else:
            print(f"Empty campaign - try one of: {', '.join(SEEDS)} (with --new to start over).")
            return
    elif game.conn.execute("SELECT 1 FROM turns WHERE status='committed' AND session=?",
                           (game.ledger.session(),)).fetchone():
        print(f"Session {game.ledger.new_session()} begins. (!recap for a 'previously on...')")
    try:
        Console(game).run()
    finally:
        game.close()


if __name__ == "__main__":
    main()
