"""The battle map (DESIGN.md §6a): one picture per fight, redrawn each round from the encounter - never invented.

Zones are boxes laid out by how they connect (breadth-first from the first zone), with their cover marked and
lines where they touch. Everyone in the fight is a token: their portrait in a ring coloured by side (runners
green, hostile red, neutral grey), a damage arc, their name. This round's attacks are arrows - red for hits,
grey for misses. Every frame's footer shows the round's Initiative (who has how many actions); the last frame shows
how it ended.
"""
from __future__ import annotations

import math
from collections import deque
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageOps

from . import encounters
from .engine import clock
from .engine.rules import sr_lite
from .sheetart import AMBER, BG, CYAN, DIM, FAINT, GREEN, INK, LINE, PANEL, RED, font

BOX_W, BOX_H, GAP_X, GAP_Y, PAD = 400, 290, 90, 70, 60
SIDE_COL = {"runners": GREEN, "hostile": RED, "neutral": (150, 160, 175), "surrendered": (225, 228, 235),
            "fled": (150, 160, 175)}
COVER_COL = {"none": FAINT, "light": AMBER, "hard": CYAN}


def layout(enc: dict) -> dict[str, tuple[int, int]]:
    """Grid cells (column, row) for each zone: breadth-first from the first, columns by distance."""
    near = {z["name"]: z["near"] for z in enc["zones"]}
    names = [z["name"] for z in enc["zones"]]
    depth, order = {}, []
    for root in names:
        if root in depth:
            continue
        depth[root] = (max(depth.values()) + 1) if depth else 0
        q = deque([root])
        while q:
            cur = q.popleft()
            order.append(cur)
            for n in near.get(cur, []):
                if n not in depth:
                    depth[n] = depth[cur] + 1
                    q.append(n)
    cells, rows = {}, {}
    for name in order:
        col = depth[name]
        cells[name] = (col, rows.get(col, 0))
        rows[col] = rows.get(col, 0) + 1
    return cells


def _token(path: Path | None, size: int, ring, frac: float, out: bool, name: str = "") -> Image.Image:
    img = Image.new("RGBA", (size + 12, size + 12), (0, 0, 0, 0))
    if path and Path(path).exists():
        pic = ImageOps.fit(Image.open(path).convert("RGB"), (size, size), centering=(0.5, 0.25))
    else:
        pic = Image.new("RGB", (size, size), (40, 52, 70))
        initials = "".join(w[0] for w in name.split()[:2]).upper() or "?"
        ImageDraw.Draw(pic).text((size / 2, size / 2), initials, font=font(int(size * 0.38), "Bold"), fill=(150, 165, 190),
                                 anchor="mm")
    if out:
        pic = ImageOps.grayscale(pic).convert("RGB")
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, size - 1, size - 1], fill=255)
    img.paste(pic, (6, 6), mask)
    d = ImageDraw.Draw(img)
    d.ellipse([3, 3, size + 8, size + 8], outline=ring, width=4)
    if frac > 0:                                        # damage taken, as an arc
        d.arc([0, 0, size + 11, size + 11], -90, -90 + 360 * min(1.0, frac), fill=AMBER, width=5)
    if out:
        d.line([(14, 14), (size - 2, size - 2)], fill=RED, width=5)
    return img


def render(game, enc_id: int, out: Path | None = None) -> Path:
    L = game.ledger
    enc = encounters.get(game, enc_id)
    cells = layout(enc)
    cols = max(c for c, _ in cells.values()) + 1
    rows = max(r for _, r in cells.values()) + 1
    W = max(1100, PAD * 2 + cols * BOX_W + (cols - 1) * GAP_X)
    H = 130 + rows * BOX_H + (rows - 1) * GAP_Y + 120
    img = _canvas_w(W, H)
    d = ImageDraw.Draw(img)
    x0 = (W - (cols * BOX_W + (cols - 1) * GAP_X)) // 2

    def box(name):
        c, r = cells[name]
        x, y = x0 + c * (BOX_W + GAP_X), 110 + r * (BOX_H + GAP_Y)
        return x, y, x + BOX_W, y + BOX_H

    # title
    sc = L.scene(enc["scene_id"])
    loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    over = enc["status"] == "ended"
    title = "THE FIGHT IS OVER" if over else f"ROUND {enc['round'] + 1}"
    d.rectangle([0, 0, W, 64], fill=(13, 19, 30))
    d.line([(0, 64), (W, 64)], fill=RED if not over else GREEN, width=3)
    d.text((PAD, 32), title, font=font(34, "Bold SemiCondensed"), fill=RED if not over else GREEN, anchor="lm")
    d.text((PAD + font(34, "Bold SemiCondensed").getlength(title) + 24, 34),
           f"{loc['name'] if loc else 'the fight'}  ·  {clock.short(game.clock())}", font=font(24), fill=DIM, anchor="lm")

    # connections, then zones
    for z in enc["zones"]:
        for n in z["near"]:
            if n in cells and z["name"] < n:
                a, b = box(z["name"]), box(n)
                d.line([((a[0] + a[2]) / 2, (a[1] + a[3]) / 2), ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)],
                       fill=LINE, width=6)
    for z in enc["zones"]:
        x1, y1, x2, y2 = box(z["name"])
        d.rounded_rectangle([x1, y1, x2, y2], 14, fill=PANEL, outline=COVER_COL[z["cover"]], width=3)
        d.text((x1 + 18, y1 + 22), z["name"].upper()[:26], font=font(24, "SemiBold SemiCondensed"), fill=INK, anchor="lm")
        if z["cover"] != "none":
            tag = f"{z['cover'].upper()} COVER"
            d.text((x2 - 18, y1 + 22), tag, font=font(18, "SemiBold"), fill=COVER_COL[z["cover"]], anchor="rm")

    # tokens
    centers = {}
    by_zone: dict[str, list[str]] = {}
    for e, zname in enc["positions"].items():
        if L.get(e) and zname in cells:
            by_zone.setdefault(zname, []).append(e)
    for zname, ids in by_zone.items():
        x1, y1, x2, y2 = box(zname)
        n = len(ids)
        size = 92 if n <= 3 else 66 if n <= 4 else 54 if n <= 8 else 44     # (rows stay inside the box)
        per_row = max(1, min(n, (BOX_W - 30) // (size + 26)))
        for i, e in enumerate(ids):
            ent = L.get(e)
            cx = x1 + 20 + (i % per_row) * (size + 26) + (size + 12) / 2
            cy = y1 + 60 + (i // per_row) * (size + 46) + (size + 12) / 2
            art = game.art.latest(game.conn, e, ready_only=True)
            pmax, _ = sr_lite.monitor_max(L, e)
            frac = L.stat(e, "physical_damage") / max(1, pmax)
            status, sd = sr_lite.condition(L, e), encounters.side(game, enc, e)
            tok = _token(Path(art["path"]) if art else None, size, SIDE_COL.get(sd, SIDE_COL["neutral"]), frac,
                         status in sr_lite.OUT, ent["name"])
            if sd in encounters.GAVE_UP and status not in sr_lite.OUT:
                status = sd
            img.paste(tok, (int(cx - tok.width / 2), int(cy - tok.height / 2)), tok)
            label = ent["name"] if len(ent["name"]) <= 16 else ent["name"][:15] + "…"
            d.text((cx, cy + tok.height / 2 + 12), label, font=font(17, "SemiBold"), fill=INK, anchor="mm")
            if status != "ok":
                tint = AMBER if status == "wounded" else DIM if status in encounters.GAVE_UP else RED
                d.text((cx, cy + tok.height / 2 + 32), status, font=font(15), fill=tint, anchor="mm")
            centers[e] = (cx, cy)

    # the latest round's attacks (the round just played, or the one under way when shown mid-turn)
    rnd = max((a["round"] for a in enc["attacks"]), default=0)
    if rnd < enc["round"]:                              # nobody fired last round: no stale arrows
        rnd = -1
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    pairs: dict[tuple, int] = {}
    for a in (x for x in enc["attacks"] if x["round"] == rnd):
        if a["from"] not in centers or a["to"] not in centers:
            continue
        (ax, ay), (bx, by) = centers[a["from"]], centers[a["to"]]
        col = RED if a["hit"] else (140, 150, 165)
        length = math.hypot(bx - ax, by - ay) or 1
        # arc over the tokens in between; an exchange between two people bends to alternate sides
        key = tuple(sorted((a["from"], a["to"])))
        n = pairs[key] = pairs.get(key, -1) + 1
        (px0, py0), (px1, py1) = centers[key[0]], centers[key[1]]
        nx, ny = -(py1 - py0) / length, (px1 - px0) / length            # normal to the pair, same for both ways
        bend = (min(0.24 * length, 130) + 30 * (n // 2)) * (1 if n % 2 == 0 else -1)
        mx, my = (ax + bx) / 2 + nx * bend, (ay + by) / 2 + ny * bend
        if not 90 <= my <= H - 120:                                      # keep it on the field
            mx, my = (ax + bx) / 2 - nx * bend, (ay + by) / 2 - ny * bend
            my = min(max(my, 90), H - 120)
        pts = [((1 - u) ** 2 * ax + 2 * (1 - u) * u * mx + u ** 2 * bx, (1 - u) ** 2 * ay + 2 * (1 - u) * u * my + u ** 2 * by)
               for u in (i / 40 for i in range(41))]
        pts = [p for p in pts if math.hypot(p[0] - ax, p[1] - ay) > 56 and math.hypot(p[0] - bx, p[1] - by) > 56]
        if len(pts) < 2:
            continue
        gd.line(pts, fill=col + (90,), width=12)
        d.line(pts, fill=col, width=4)
        (px, py), (ex, ey) = pts[-2], pts[-1]
        ang = math.atan2(ey - py, ex - px)
        for sgn in (-0.45, 0.45):
            d.line([(ex, ey), (ex - 22 * math.cos(ang + sgn), ey - 22 * math.sin(ang + sgn))], fill=col, width=4)
    img = Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(6)))
    d = ImageDraw.Draw(img)

    # footer: this round's Initiative first (who has how many actions), then the latest round - or how it ended
    if over:
        foot = f"How it ended: {enc.get('outcome') or 'it ended'}"
    else:
        init = encounters.summary(game, enc)
        last = f"Round {enc['log'][-1]['round']}: {enc['log'][-1]['text']}" if enc["log"] else ""
        foot = "  |  ".join(x for x in (f"Initiative: {init}" if init else "", last) if x)
    if foot:
        f21, lines = font(21), [""]
        for word in foot.split():                       # wrap to the canvas, three lines at most
            trial = f"{lines[-1]} {word}".strip()
            if f21.getlength(trial) <= W - PAD * 2:
                lines[-1] = trial
            elif len(lines) < 3:
                lines.append(word)
            else:
                lines[-1] = lines[-1].rstrip(".,;") + "…"
                break
        for i, line in enumerate(lines):
            d.text((PAD, H - 110 + i * 27), line, font=f21, fill=DIM, anchor="lm")
    d.text((W - PAD, H - 30), "ring: green runners · red hostile · grey bystanders · white surrendered  ·  amber arc: "
                              "damage  ·  arrows: red hit, grey missed",
           font=font(16), fill=FAINT, anchor="rm")
    out = Path(out or game.path.parent / "maps" / f"{game.path.stem}_fight_{enc['id']}.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(out, optimize=True)
    return out


def _canvas_w(w: int, h: int) -> Image.Image:
    img = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(img)
    for x in range(0, w, 40):
        d.line([(x, 0), (x, h)], fill=(14, 20, 31))
    for y in range(0, h, 40):
        d.line([(0, y), (w, y)], fill=(14, 20, 31))
    return img.convert("RGBA")
