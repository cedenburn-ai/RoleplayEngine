"""Fights (DESIGN.md §6a): the engine owns the battlefield, the model narrates and sends deltas.

An encounter is a few named zones (with cover and which ones touch), who's in which zone, which side they're on,
and a short log - one line per round. The GM starts one with the `fight` tool (or `battle:` in the <dm> block, or
the engine starts one itself on the first attack, grenade, combat spell or harm someone caused - never over someone
already down, nor a spell or an accident between two runners: at_odds), and everyone rolls Initiative (SR5 p. 159) - ambushed characters roll the surprise test first
(Reaction + Intuition (3), +3 if alerted) and lose 10 Initiative and the opening beat if they miss it. One GM turn is
one Combat Turn: no turn order inside it, but every 10 points of a fighter's Initiative is one Action Phase, and each
phase holds one attack, spell or grenade - the engine refuses more (the table's ruling: a hard limit), except for
finishing off the helpless once nobody stands against you. Multiple Attacks split one phase's pool; defenses wear
down (-1 each since the defender last acted) and interrupts (parry, block, dodge, full defense) are paid from the
score. A new round's Initiative is rolled once commit knows the fight goes on. Newcomers join the fight that's on
(join), never a second one - late, they lose 10 a pass already gone.

While a fight is on, attacks pick up range and cover from the zones (same zone 0, next zone -1, two away -3,
farther -6; melee closes the distance; cover in the defender's zone adds defense dice), the memory pass reports
who moved where, and each round goes into the fight's log instead of the memory graph. When it ends - the GM says
so (never with a "not yet" while a hostile stands), nobody hostile is left standing (foes: the hostile side and
anyone the crew has hurt), the scene cuts, or three rounds pass without an attack - the whole fight becomes one
memory with everyone's part in it, and the NPCs who were there reflect on it.
"""
from __future__ import annotations

import json
import re
from collections import deque
from math import ceil

from .dm.prompts import FICTION_NOTE
from .engine import clock
from .engine.ledger import LedgerError, RulesRefusal
from .engine.rules import explosives, sr_lite

COVER_DICE = {"none": 0, "light": 2, "hard": 4}
RANGE_MOD = (0, -1, -3, -6)                 # zones apart: 0, 1, 2, 3+
RANGE_NAME = ("close", "near", "far", "extreme")
ENV_ROWS = (0, -1, -3, -6, -10)             # the Environmental Modifiers table's rows (SR5 p. 173-174)
QUIET_ROUNDS = 3                            # rounds without an attack before a fight peters out
ATTACKS_KEPT = 40                           # the attacks a fight keeps (the map draws the last round's; _trim_attacks)
MELEE = ("close_combat",)
GAVE_UP = ("surrendered", "fled")           # out of the fight without going down (their side, from then on)
FIGHTERS = ("pc", "npc", "drone", "spirit")
SURPRISE = 3                                # Reaction + Intuition (3) or caught flat-footed (SR5 p. 192)
ALERTED = 3                                 # "+3 dice pool modifier" for anyone alerted in some way (p. 192)
ALERT_TURNS = 2                             # hurt or shot at this recently: they're expecting trouble
PASS = 10                                   # every 10 points of Initiative is one Action Phase a round (p. 159)
SURPRISED = 10                              # a failed surprise test costs 10 Initiative (p. 192)
INTERRUPTS = {"full": 10, "parry": 5, "block": 5, "dodge": 5}      # Initiative they cost (p. 168, 188)
ONE_PER_TEST = ("parry", "block", "dodge")  # one of these a defense test, melee only; Full Defense goes with any
# The engine's skills are broad: Block stands in on Close Combat for Unarmed, Dodge on Athletics for Gymnastics.
INTERRUPT_SKILL = {"parry": ("close_combat", "Parry (Close Combat)"), "block": ("close_combat", "Block (Close Combat)"),
                   "dodge": ("athletics", "Dodge (Athletics)")}
# `battle end:` is for a fight that's over. Live T174: "battle end: not yet - fight continues; Fenn last Crow standing"
# ended the fight mid-fight, and T175's Manabolt opened a fresh one with a new jump. Anchored at the start, so real
# endings that merely begin with "No" or "Still" ("No one left standing", "Still bodies on the tar...") still end it.
NOT_OVER = re.compile(r"^\W*(?:it'?s\s+|it\s+is\s+)?(?:not\s+(?:yet|over|done)\b|ongoing\b|still\s+(?:going|fighting)\b|"
                      r"(?:the\s+)?(?:fight|battle|combat|shooting)\s+(?:continues|goes\s+on|is\s+still\s+on)\b)", re.I)

FIGHT_SYSTEM = FICTION_NOTE + """ You turn a finished fight from a Shadowrun session into one memory for the \
game's knowledge graph. You get the round-by-round log and how it ended. Write 60-140 words, past tense, naming \
names: how it started, the turning points, who hurt, saved, humiliated or abandoned whom, and how it ended - the \
things the people who were there would remember about each other. No dice or game terms.
Report, don't judge: write what the log shows, in the order it shows it. Never add a surrender, a plea, a motive, a \
mercy or a verdict the log doesn't state - the people who were there will judge it for themselves. In WHO, the word \
after a name is where they stood when it ended (their side, or how they left the fight), not something that happened \
before."""


class NoActionLeft(RulesRefusal):
    """An attack, spell or grenade past the fighter's Action Phases this round - the table's ruling (2026-10-24): a
    hard limit. actors: who it was turned away for; their player's called roll counts as answered (run_tool puts them
    on ctx.refused), so the roll guard doesn't send the GM back for a roll the engine just refused."""

    def __init__(self, msg: str, actors=()):
        super().__init__(msg)
        self.actors = tuple(a for a in actors if a)


def _row(r) -> dict | None:
    if not r:
        return None
    d = dict(r)
    for k in ("zones", "positions", "sides", "log", "jump", "members", "attacks", "map"):
        d[k] = json.loads(d[k]) if d.get(k) else ([] if k in ("zones", "log", "jump", "attacks") else {})
    return d


def active(game, scene_id: int | None = None) -> dict | None:
    sid = scene_id if scene_id is not None else game.current_scene_id()
    return _row(game.conn.execute("SELECT * FROM encounters WHERE scene_id=? AND status='active' ORDER BY id DESC "
                                  "LIMIT 1", (sid,)).fetchone())


def get(game, enc_id: int) -> dict | None:
    return _row(game.conn.execute("SELECT * FROM encounters WHERE id=?", (enc_id,)).fetchone())


def save(game, enc: dict) -> None:
    game.conn.execute("UPDATE encounters SET status=?, round=?, zones=?, positions=?, sides=?, log=?, jump=?, members=?, "
                      "attacks=?, quiet=?, ending=?, ended_turn=?, outcome=?, map=? WHERE id=?",
                      (enc["status"], enc["round"], json.dumps(enc["zones"]), json.dumps(enc["positions"]),
                       json.dumps(enc["sides"]), json.dumps(enc["log"]), json.dumps(enc["jump"]),
                       json.dumps(enc["members"]), json.dumps(enc["attacks"]), enc["quiet"], enc.get("ending"),
                       enc.get("ended_turn"), enc.get("outcome"), json.dumps(enc["map"]), enc["id"]))


# ── the battlefield ─────────────────────────────────────────────────────
def _zone_name(enc: dict, name: str) -> str | None:
    n = (name or "").strip().lower()
    for z in enc["zones"]:
        if z["name"].lower() == n:
            return z["name"]
    hits = [z["name"] for z in enc["zones"] if n and (n in z["name"].lower() or z["name"].lower() in n)]
    return hits[0] if len(hits) == 1 else None


def set_zones(enc: dict, zones: list[dict]) -> None:
    """zones: [{name, cover, near: [names]}]. Listed order chains them unless 'near' says otherwise."""
    clean = []
    for z in zones[:8]:
        name = (z.get("name") or "").strip()[:40]
        if not name or any(c["name"].lower() == name.lower() for c in clean):
            continue
        clean.append({"name": name, "cover": z.get("cover") if z.get("cover") in COVER_DICE else "none",
                      "near": [n for n in (z.get("near") or []) if n]})
    if not clean:
        return
    names = {c["name"].lower(): c["name"] for c in clean}
    for i, c in enumerate(clean):
        c["near"] = [names[n.lower()] for n in c["near"] if n.lower() in names and n.lower() != c["name"].lower()]
        if not any(i2 != i and (c["name"] in o["near"] or o["name"] in c["near"]) for i2, o in enumerate(clean)) and i:
            c["near"].append(clean[i - 1]["name"])                       # an island joins the one listed before it
    for c in clean:                                                      # adjacency is mutual
        for n in c["near"]:
            other = next(o for o in clean if o["name"] == n)
            if c["name"] not in other["near"]:
                other["near"].append(c["name"])
    old = {z["name"]: z for z in enc["zones"]}
    for c in clean:                                                      # (a cloud stays where it was)
        was = next((z for n, z in old.items() if n.lower() == c["name"].lower()), {})
        if was.get("smoke"):
            c["smoke"] = was["smoke"]
    enc["zones"] = clean
    fallback = clean[0]["name"]
    enc["positions"] = {e: (_zone_name(enc, z) or fallback) for e, z in enc["positions"].items()} if old else enc["positions"]


def add_zone(enc: dict, name: str, beside: str | None, cover: str = "none") -> str:
    name = name.strip()[:40]
    existing = _zone_name(enc, name)
    if existing:
        return existing
    z = {"name": name, "cover": cover if cover in COVER_DICE else "none", "near": [beside] if beside else []}
    enc["zones"].append(z)
    if beside:
        for o in enc["zones"]:
            if o["name"] == beside and name not in o["near"]:
                o["near"].append(name)
    return name


def distance(enc: dict, a: str, b: str) -> int:
    if a == b:
        return 0
    return _hops(enc, a).get(b, 3)                                       # not connected: far apart


def _hops(enc: dict, a: str, avoid=()) -> dict[str, int]:
    """Zones apart from a, for every zone it reaches - never through the zones in avoid."""
    near = {z["name"]: z["near"] for z in enc["zones"]}
    seen, q = {a: 0}, deque([a])
    while q:
        cur = q.popleft()
        for n in near.get(cur, []):
            if n not in seen and n not in avoid:
                seen[n] = seen[cur] + 1
                q.append(n)
    return seen


def zone_of(enc: dict, eid: str) -> str | None:
    return enc["positions"].get(eid)


def move(enc: dict, eid: str, zone: str) -> str:
    """Put someone in a zone - one the fiction just created joins the zone they came from."""
    known = _zone_name(enc, zone)
    if not known:
        known = add_zone(enc, zone, enc["positions"].get(eid) or (enc["zones"][0]["name"] if enc["zones"] else None))
    enc["positions"][eid] = known
    return known


def side(game, enc: dict | None, eid: str) -> str:
    """runners, hostile, neutral (or how they gave up). enc None: with no fight on, a runner or not."""
    if enc and eid in enc["sides"]:
        return enc["sides"][eid]
    ent = game.ledger.get(eid) or {}
    if ent.get("kind") == "pc" or game.control_of(eid) == "player":
        return "runners"
    owner = (ent.get("props") or {}).get("owner")
    if owner and (game.ledger.get(owner) or {}).get("kind") == "pc":
        return "runners"                                                 # a runner's drone or spirit
    return "neutral"


# ── starting: who gets the jump ─────────────────────────────────────────
def combatants(game, scene_id: int) -> list[dict]:
    L = game.ledger
    return [e for e in (L.get(x) for x in L.roster(scene_id))
            if e and e["kind"] in FIGHTERS and sr_lite.condition(L, e["id"]) not in sr_lite.OUT]


def alerted(game, eid: str, turn: int, scene_id: int) -> bool:
    """Expecting trouble - +3 on the surprise test (SR5 p. 192, "characters who have been alerted in some way"): hurt or
    shot at in the last two turns, or in a fight in this scene that ended this turn or the last. Live T172: the crew
    'ambushed' Garvey, Fenn and Gutter a turn after the barrier had slammed Garvey into a wall, and all three were
    caught flat-footed by a fresh fight's surprise test."""
    for r in game.conn.execute("SELECT kind, actor, payload FROM events WHERE turn_id>=? AND kind IN ('damage', 'attack')",
                               (turn - ALERT_TURNS,)):
        if r["actor"] == eid and r["kind"] == "damage":
            return True
        if r["kind"] == "attack" and json.loads(r["payload"] or "{}").get("target") == eid:
            return True
    for r in game.conn.execute("SELECT members, positions FROM encounters WHERE scene_id=? AND status='ended' AND "
                               "ended_turn>=?", (scene_id, turn - 1)):
        if eid in json.loads(r["members"] or "{}") or eid in json.loads(r["positions"] or "{}"):
            return True
    return False


def _surprise(game, ent: dict, alert: bool) -> tuple[bool, str]:
    """The surprise test: Reaction + Intuition (3), +3 if alerted (p. 192). (caught flat-footed?, the card's note)."""
    L = game.ledger
    n = (int(L.stat(ent["id"], "reaction", 2)) + int(L.stat(ent["id"], "intuition", 2))
         - sr_lite.wound_penalty(L, ent["id"])) if ent["kind"] != "drone" else 3
    n += ALERTED if alert else 0
    spot = sr_lite.roll(game.dice, max(0, n))
    flat = spot.hits < SURPRISE
    return flat, f"surprise {spot.hits} on {max(0, n)}d6" + (" (alerted +3)" if alert else "")


# ── Initiative: the round's action budget ───────────────────────────────
# Everything a round tracks rides on the encounter's `jump` rows (no new table): base (the attribute + the dice
# rolled), used (Action Phases spent), spent (Initiative paid for interrupts), defended (defenses since they last
# acted, p. 189), full (Full Defense on), surprise (-10 caught flat-footed), late (-10 a pass gone when they came in,
# p. 160), mid_bonus (Initiative that changed mid-round, p. 160). 'score' and 'hits' mirror the score for older
# readers (the battle map, a row from before Initiative counted).

def score(game, r: dict) -> int:
    """The Initiative Score now: the roll, less the wounds as they stand (wounds count at once, p. 160), what interrupts
    cost, -10 for a failed surprise test, -10 a pass gone for a late joiner."""
    if "base" not in r:
        return int(r.get("hits", 0))
    return int(r["base"] + r.get("mid_bonus", 0) - sr_lite.wound_penalty(game.ledger, r["id"]) - r.get("spent", 0)
               - r.get("surprise", 0) - r.get("late", 0))


def phases(game, r: dict) -> int:
    """Action Phases this round: one a pass - every 10 points of the score, rounded up (17 is 2, 22 is 3; p. 159)."""
    return 0 if r.get("out") else max(0, ceil(score(game, r) / PASS))


def _mirror(game, r: dict) -> dict:
    r["score"] = r["hits"] = score(game, r)
    return r


def _new_row(game, ent: dict, flat: bool = False, turn: int | None = None, joined: int = 0, late: int = 0) -> dict:
    """One fighter's Initiative for the round (sr_lite.initiative_rating: the attribute + the dice)."""
    attr, n, why = sr_lite.initiative_rating(game.ledger, ent["id"])
    r = sr_lite.roll(game.dice, n)
    row = {"id": ent["id"], "name": ent["name"], "attr": attr, "dice": n, "rolled": r.dice, "base": attr + sum(r.dice),
           "why": why, "flat": flat, "acted": False, "extra": max(0, n - 1), "used": 0, "spent": 0, "defended": 0,
           "full": False, "surprise": SURPRISED if flat else 0, "late": late, "mid_bonus": 0, "rolled_turn": turn}
    if joined:
        row["joined_round"] = joined
    return _mirror(game, row)


def _down_row(ent: dict, turn: int | None) -> dict:
    """Out of it this round (unconscious, dying...): no roll. If they come round they roll in late (row)."""
    return {"id": ent["id"], "name": ent["name"], "out": True, "attr": 0, "dice": 0, "base": 0, "why": [],
            "flat": False, "acted": False, "used": 0, "spent": 0, "defended": 0, "full": False, "surprise": 0,
            "late": 0, "mid_bonus": 0, "rolled_turn": turn, "score": 0, "hits": 0}


def _order(game, r: dict) -> tuple:
    """Who goes first: the flat-footed last, then the score, Edge, Reaction, Intuition (p. 159), then the name."""
    L = game.ledger
    return (bool(r.get("out")), bool(r.get("flat")), -score(game, r), -int(L.stat(r["id"], "edge", 0)),
            -int(L.stat(r["id"], "reaction", 0)), -int(L.stat(r["id"], "intuition", 0)), r["name"])


def passes_gone(enc: dict) -> int:
    """Initiative Passes already over this round, as far as the engine can tell: once anyone has spent a second
    action, the first pass is gone, and so on."""
    return max(0, max((int(j.get("used", 0)) for j in enc["jump"]), default=0) - 1)


def remote_riggers(game, ids) -> list[dict]:
    """The riggers running a machine among ids by remote control who aren't among ids themselves - Ghost in the van
    down the block, his Roto-drone in the bar (machines.followers leaves a drone where it was sent). The machine spends
    their Action Phases (budget_owner), so they roll with the fight - review: off the map, Ghost never got a row, was
    rolled the first time the drone fired, -10 'late' a pass gone, and dropped again at every new round."""
    L, order = game.ledger, list(dict.fromkeys(ids))          # (in the fight's order: the dice go the same way each time)
    out = {}
    for eid in order:
        m = L.get(eid)
        if (not m or m["kind"] not in sr_lite.MACHINES or m["props"].get("control") == "jumped"
                or sr_lite.condition(L, eid) in sr_lite.OUT):     # (a wrecked drone puts nobody in the fight)
            continue
        drv = L.get(m["props"].get("controller") or "")
        if drv and drv["id"] not in order and drv["kind"] in FIGHTERS:
            out[drv["id"]] = drv
    return list(out.values())


def _late(game, enc: dict, eid: str) -> int:
    """-10 for each pass already gone, for someone coming into the round now (p. 160) - but a rigger whose remote
    drone has been in the round has been in it as long: theirs is the drone's (budget_owner)."""
    L = game.ledger
    for j in enc["jump"]:
        p = (L.get(j["id"]) or {}).get("props") or {}
        if j["id"] != eid and p.get("controller") == eid and p.get("control") != "jumped":
            return int(j.get("late", 0))
    return PASS * passes_gone(enc)


def row(game, enc: dict, eid: str, turn: int | None = None) -> dict:
    """eid's row this round - rolled now for someone who came in since it began or came round from being down (-10
    for every pass already gone, p. 160), or for a row from before Initiative counted. The caller saves enc."""
    r = next((j for j in enc["jump"] if j["id"] == eid), None)
    if r and "base" in r and not (r.get("out") and sr_lite.condition(game.ledger, eid) not in sr_lite.OUT):
        return r
    late = _late(game, enc, eid) if not r else PASS * passes_gone(enc)
    new = _new_row(game, game.ledger.require(eid), turn=turn, late=late)
    if r:
        enc["jump"][enc["jump"].index(r)] = new
    else:
        enc["jump"].append(new)
    return new


def roll_initiative(game, enc: dict, turn: int) -> list[dict]:
    """A new Combat Turn: everyone in the fight rolls Initiative afresh, and what the last round used - actions,
    interrupts paid, defenses, Full Defense, surprise - starts over (p. 159). commit calls it once the turn's round is
    stepped and the fight is known to go on - never for a fight that's ending (it would roll dice and log an
    initiative nobody gets to use). Logged as an 'initiative' event; session posts its card after the battle map.
    The riggers running a drone in the fight from outside it roll too (remote_riggers)."""
    L = game.ledger
    rows = []
    for ent in [L.get(e) for e in enc["positions"]] + remote_riggers(game, enc["positions"]):
        if not ent or ent["kind"] not in FIGHTERS:
            continue
        eid = ent["id"]
        rows.append(_down_row(ent, turn) if sr_lite.condition(L, eid) in sr_lite.OUT else _new_row(game, ent, turn=turn))
    rows.sort(key=lambda x: _order(game, x))
    enc["jump"] = rows
    save(game, enc)
    L.log(turn, "initiative", None, {"encounter": enc["id"], "round": enc["round"] + 1,
                                     "scores": {r["id"]: r["score"] for r in rows if not r.get("out")}})
    return rows


def _entry(game, r: dict) -> str | None:
    """'Quiet Lou 17 (2 actions)', 'Pastor Garvey 3 (1 action, caught flat-footed -10)', "Filament's Roto-drone
    (remote: on Filament's actions)" - None for someone down."""
    if r.get("out"):
        return None
    if "base" not in r:
        return f"{r['name']} (rolls when they act)"
    if not r.get("dice") and not r.get("attr"):
        return f"{r['name']} ({(r.get('why') or ['no Initiative of their own'])[0]})"
    n = phases(game, r)
    bits = [f"{n} action{'s' * (n != 1)}" if n else "no action"]
    if r.get("surprise"):
        bits.append(f"caught flat-footed -{r['surprise']}")
    if r.get("late"):
        bits.append(f"came in late -{r['late']}")
    return f"{r['name']} {score(game, r)} ({', '.join(bits)})"


def summary(game, enc: dict) -> str:
    """The round's Initiative in one line, for the table: the [INITIATIVE] card and the battle map."""
    return " · ".join(e for e in (_entry(game, r) for r in enc["jump"]) if e)


def initiative_card(game, enc: dict) -> str:
    """'[INITIATIVE] Round 2: Quiet Lou 19 (2 actions) · ...' - one compact line a round (the map is already redrawn
    every round; a block a turn would bury the story)."""
    return (f"[INITIATIVE] Round {enc['round'] + 1}: {summary(game, enc)} - each 10 of Initiative is an action: one "
            "attack, spell or grenade")


def _take_sides(game, enc: dict, ambushers, hostile) -> set[str]:
    """Ambushers spring it from their side (an NPC's is hostile); `hostile` names the runners' enemies outright. Nobody
    else gets a side up front - a bystander in the room stays neutral until someone attacks them (note_attack)."""
    L = game.ledger
    amb = {e["id"] for e in (L.find(a) for a in (ambushers or [])) if e}
    for a in amb:
        enc["sides"][a] = "hostile" if side(game, enc, a) != "runners" else "runners"
    for e in (L.find(h) for h in (hostile or [])):
        if e and side(game, enc, e["id"]) not in ("runners",) + GAVE_UP:
            enc["sides"][e["id"]] = "hostile"
    return amb


# !combathelp: what a round holds, in plain words (drafted from this code and checked line by line against it,
# 2026-10-25 - keep it true when the rules here change). First line is the intro; the rest are **Heading:** lines.
HELP = [
    "Say what your runner does in plain words - one GM turn is one 3-second round; `[FIGHT]` opens a fight "
    "with round 1's Initiative, and `[INITIATIVE]` posts each round after that, below the story and the map.",
    "**Initiative:** each round, Reaction + Intuition + 1D6, +1D6 per rating of wired reflexes (5D6 max). "
    "Every 10 points is one Action Phase holding ONE attack, spell or grenade: 1-10 is 1, 11-20 is 2, 21-30 "
    "is 3, 31+ is 4, 0 or less none. Wounds lower it at once.",
    "**The cards:** scores shown have the -10 off. \"caught flat-footed -10\": failed a surprise test (ambush "
    "or arrival) - no defense roll or interrupt till they act, this round · \"came in late -10\": joined after "
    "someone's 2nd action, -10 a phase gone; earlier, free.",
    "**The crew:** Magic 8+1D6 (2 actions on a 3+, else 1) · Lou 10+2D6, wired (2, or 3 on 21+) · Filament "
    "10+1D6 (2); in hot-sim VR in a host 9+4D6 (2-4), but his body lies limp: no defense roll, and it can be "
    "finished · the air spirit 6+2D6 (1-2 of its own).",
    "**Split attacks:** \"Lou splits the katana between both guards\": one action, one pool split evenly (13 = "
    "7/6), melee targets in reach. Up to half the skill: Lou 3, Magic 2 throws, Filament none, two guns or "
    "not. Magic's bolts: up to 6 targets, each its own drain.",
    "**Thrown:** \"Lou throws the knife at the driver\": Throwing + Agility from where you stand. The knife "
    "ends up on the floor; \"Lou picks it back up\" is free. Two throws need two in hand (Lou and Magic have "
    "one knife each). Grenades: one action each, never split.",
    "**Defending:** your defense roll (Reaction + Intuition) is free, -1 per earlier defense since you acted. "
    "Extras go in your post, before the GM answers: \"parries\"/\"blocks\" (+Close Combat) or \"dodges\" "
    "(+Athletics) vs melee, -5 · \"full defense\" (+Willpower), -10.",
    "**Paying for it:** from what's left of your score when the blow lands (-10 a phase gone), so it can cost "
    "a later action: Lou at 17, both used, has 7 - a parry, not full defense. Who: Lou any · Magic dodge, "
    "full · Filament full, not vs a 2nd action · drones none.",
    "**Finishing them:** \"Lou finishes him\": kills the unconscious, dying or limp (VR, astral, jumped in), no "
    "roll - only once no enemy stands against you, and then free, like any attack on the downed. A foe "
    "finishing a downed runner pays an action. Not on drones.",
    "**Your roll, your Edge:** who you say rolls, rolls (\"Magic rolls this, Filament helps\"). Say Edge in "
    "your post: \"pushes the limit\" (+Edge dice, 6s explode) · \"Edge to reroll misses\" (spent if it can help) "
    "· \"Edge if I miss\" · \"Edge on the soak if it hurts\".",
    "**Out of actions:** post too much and the GM plays what fits, says what's left; post that again next "
    "round - nothing saves it. Unused ones are gone. Free: moving, reloading, tests, hacking, summoning, "
    "spirit orders. One each: attacks, any spell, grenades, rams.",
    "**Drones:** remote, the Roto-drone uses Filament's actions (one per shot) and 8 dice (6 with his Fly-Spy "
    "along); it stops if he drops. \"Roto-drone on autopilot\": its own 6+4D6 Initiative, 6 dice to shoot. "
    "Steel Lynx and Doberman act alone: \"Steel Lynx opens up\".",
]
FIGHT_HINT = "New to fights? !combathelp says what a round holds · !battle shows the map"


def start(game, turn: int, zones: list[dict] | None = None, positions: dict | None = None,
          ambushers: list[str] | None = None, reason: str = "", hostile: list[str] | None = None) -> tuple[dict, str]:
    """Open a fight in the current scene (or return the one already on - see join) and roll Initiative. In an
    ambush, the ambushed roll the surprise test first, +3 if they were alerted - and lose 10 Initiative if they fail
    it (p. 192). The card shows every fighter's score and Action Phases."""
    L = game.ledger
    sid = game.current_scene_id()
    enc = active(game, sid)
    if enc:
        return enc, ""
    sc = L.scene(sid)
    loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    game.conn.execute("INSERT INTO encounters(scene_id, started_turn, started_time) VALUES(?,?,?)",
                      (sid, turn, game.clock()))
    enc = active(game, sid)
    people = combatants(game, sid)
    enc["zones"] = [{"name": (loc["name"] if loc else "the room")[:40], "cover": "none", "near": []}]
    enc["positions"] = {e["id"]: enc["zones"][0]["name"] for e in people}
    if zones:
        set_zones(enc, zones)
        enc["positions"] = {e["id"]: enc["zones"][0]["name"] for e in people}
    for eid, z in (positions or {}).items():
        ent = L.find(eid)
        if ent:
            move(enc, ent["id"], z)
    amb = _take_sides(game, enc, ambushers, hostile)
    rows = []
    riggers = [e for e in remote_riggers(game, [p["id"] for p in people])        # (off the map, on the card)
               if sr_lite.condition(L, e["id"]) not in sr_lite.OUT]
    for e in people + riggers:
        flat = False
        if amb and e["id"] not in amb and side(game, enc, e["id"]) != side(game, enc, next(iter(amb))):
            flat, _ = _surprise(game, e, alerted(game, e["id"], turn, sid))
        rows.append(_new_row(game, e, flat, turn))
    rows.sort(key=lambda x: _order(game, x))
    enc["jump"] = rows
    save(game, enc)
    L.log(turn, "fight_start", None, {"encounter": enc["id"], "reason": reason, "ambush": sorted(amb),
                                      "scores": {r["id"]: r["score"] for r in rows}})
    card = ("[FIGHT] " + ("Ambush! " if amb else "") + "Initiative (each 10 is an Action Phase: one attack, spell or "
            "grenade): " + summary(game, enc)
            + "\n  The opening beat goes in that order" + (" - flat-footed characters lose 10 Initiative and can't "
                                                          "dodge it until they act" if amb else "") + "."
            + "\n  " + FIGHT_HINT)
    return enc, card


def join(game, turn: int, enc: dict, zones: list[dict] | None = None, positions: dict | None = None,
         ambushers: list[str] | None = None, hostile: list[str] | None = None) -> str:
    """A `fight` call (or an `ambush` line) while the fight is on: the people it names who haven't rolled into this
    fight yet join it this round, instead of being dropped. Live T171: the GM's fight call came back 'already on' and
    registered nobody, so the fight ended with Garvey, Fenn and Gutter up, and T172's fresh ambush caught all three
    flat-footed. Each newcomer rolls the surprise test - Reaction + Intuition (3), +3 if alerted or coming to a fight
    their own side is in (SR5 p. 193, surprise inside a running fight); ambushers don't (they spring it), and nor do
    the people already fighting (p. 189: no defenceless beat for someone engaged). Anyone who fails can't dodge until
    they act, this round, and loses 10 Initiative; everyone joining late loses 10 more for each pass already gone
    (p. 160). Returns the card ('' if nobody new joined)."""
    L = game.ledger
    if zones:
        set_zones(enc, zones)
    for eid, z in (positions or {}).items():
        ent = L.find(eid)
        if ent:
            move(enc, ent["id"], z)
    amb = _take_sides(game, enc, ambushers, hostile)
    named = dict.fromkeys(e["id"] for e in (L.find(x) for x in [*(positions or {}), *(ambushers or []), *(hostile or [])]) if e)
    rolled = {j["id"] for j in enc["jump"]}
    roster = set(L.roster(enc["scene_id"]))
    lines, rows, late = [], [], PASS * passes_gone(enc)
    for eid in named:
        ent = L.get(eid)
        if eid in rolled or not ent or ent["kind"] not in FIGHTERS or sr_lite.condition(L, eid) in sr_lite.OUT:
            continue
        enc["positions"].setdefault(eid, enc["zones"][0]["name"])
        flat, note = False, ""
        if eid not in amb and not (amb and side(game, enc, eid) == side(game, enc, next(iter(amb)))):
            mine = side(game, enc, eid)
            friends = mine in ("runners", "hostile") and any(
                o != eid and o in roster and side(game, enc, o) == mine and sr_lite.condition(L, o) not in sr_lite.OUT
                for o in enc["positions"])
            flat, note = _surprise(game, ent, friends or alerted(game, eid, turn, enc["scene_id"]))
        rows.append(_new_row(game, ent, flat, turn, joined=enc["round"], late=late))
        lines.append(ent["name"] + (f" ({note}{' - caught flat-footed' if flat else ''})" if note else ""))
    if not rows:
        save(game, enc)
        return ""
    enc["jump"] += rows
    if enc["round"] == 0:                            # (the opening beat hasn't been played: they're in its order)
        enc["jump"].sort(key=lambda x: _order(game, x))
    save(game, enc)
    L.log(turn, "fight_join", None, {"encounter": enc["id"], "joined": [r["id"] for r in rows], "ambush": sorted(amb),
                                     "scores": {r["id"]: r["score"] for r in rows}})
    return ("[FIGHT] " + ("Ambush, mid-fight! " if amb else "") + f"Joining the fight in round {enc['round'] + 1}: "
            + " · ".join(lines) + "\n  Initiative: " + " · ".join(_entry(game, r) for r in rows)
            + ("\n  Caught flat-footed: no dodge until they act, this round." if any(r["flat"] for r in rows) else ""))


def unaware(game, target: str) -> bool:
    """Caught flat-footed by surprise and hasn't acted yet: no dodge - against the opening beat (SR5 p. 192-194), or,
    for someone who joined mid-fight, for the rest of the round they joined in (p. 193). A new round's Initiative
    (roll_initiative) starts everyone clean: their next Action Phase has come."""
    enc = active(game)
    if not enc:
        return False
    r = next((j for j in enc["jump"] if j["id"] == target), None)
    return bool(r and r.get("flat") and not r.get("acted") and r.get("joined_round", 0) == enc["round"])


def opening(enc: dict, turn: int) -> bool:
    """Opened this turn and no blow struck yet (a dm-block `battle:` / `ambush` line, or a fight call before anyone
    swung): the opening beat is still to come, so the turn doesn't count as a round - otherwise the flat-footed would
    lose their beat before anyone could take it. An Action Phase spent is the round under way, blow or no blow (review:
    Sable's Armor spell spent her first phase with no attack, the turn wasn't stepped, and the next turn was 'round 1'
    again with that phase still used - her second Stunbolt was refused in a round the GM thought was fresh). So is
    Initiative paid for an interrupt: it comes off this round's score, and only a new round gives it back."""
    return (enc["started_turn"] == turn and not enc["attacks"] and not enc.get("ending")
            and not any(int(j.get("used", 0)) or int(j.get("spent", 0)) for j in enc["jump"]))


# ── the budget: one attack, spell or grenade an Action Phase ────────────
def budget_owner(game, eid: str) -> str:
    """Whose Action Phases an action spends: a remote-controlled drone acts on its rigger's (Control Device, SR5 p.
    238) - and does nothing while its rigger is out; everyone else, a jumped-in or autonomous drone too, on their own."""
    L = game.ledger
    ent = L.require(eid)
    p = ent["props"]
    drv = L.get(p.get("controller") or "") if ent["kind"] in sr_lite.MACHINES and p.get("control") != "jumped" else None
    if not drv:
        return eid
    if sr_lite.condition(L, drv["id"]) in sr_lite.OUT:
        raise NoActionLeft(f"{drv['name']} is {sr_lite.condition(L, drv['id'])} - {ent['name']} runs on "
                           f"{drv['name']}'s Action Phases (remote control) and has no Action Phase left - it does "
                           "nothing until it's set autonomous (control_drone, controller_id 'autonomous').",
                           (eid, drv["id"]))
    return drv["id"]


def ready(game, actor: str) -> None:
    """What action_check would refuse without needing a fight - checked before an attack, a cast, a ram or a grenade
    opens one, so a refused action starts nothing (DESIGN §6a: 'an invalid attack starts nothing'). Review: a remote
    drone whose rigger was out opened a fight, its [FIGHT] card went to the table, and only then did the budget turn
    the shot away - the GM saw just the refusal. Whose phases they'd be (budget_owner: nothing while a remote drone's
    rigger is out), and anyone with no Initiative of their own (a jumped-in rigger's limp body). NoActionLeft."""
    owner = budget_owner(game, actor)
    attr, n, why = sr_lite.initiative_rating(game.ledger, owner)
    if attr or n:
        return
    L = game.ledger
    lead = "" if owner == actor else (f"{L.require(actor)['name']} runs on {L.require(owner)['name']}'s Action Phases "
                                      "(remote control), and ")
    raise NoActionLeft(f"{lead}{L.require(owner)['name']} has no Action Phase - none of their own ({why[0]}).",
                       (actor, owner))


def mop_up(game, actor: str, targets) -> bool:
    """Finishing off the helpless costs no Action Phase once nobody stands against the one doing it: every target
    down or limp, none of them a player's character. The table's house rule, not the book's (SR5 counts every attack,
    p. 164) - so a 'kill the survivors' post stays one turn (live T170, T171, T175). An NPC finishing a downed runner
    spends their action like any other."""
    L = game.ledger
    if not targets:
        return False
    for t in targets:
        ent = L.get(t)
        if not ent or ent["kind"] == "pc" or game.control_of(t) == "player":
            return False
        if sr_lite.condition(L, t) not in sr_lite.OUT and not sr_lite.helpless(L, t):
            return False
    return not stands_against(game, actor)


def action_check(game, actor: str, targets=(), turn: int | None = None, hint: str = "") -> dict | None:
    """Before an attack, a spell or a grenade - before anything is rolled or spent (a round, Edge, a step toward the
    target): has the actor an Action Phase left this round? The table's ruling (2026-10-24) makes it a hard limit.
    None with no fight on; {'free': True} for mopping up (mop_up); otherwise the budget owner's (budget_owner) - and
    NoActionLeft once every phase is used, saying the rest carries into the next round. now_pass: the Initiative Pass
    this action falls in, which is what an interrupt against it is measured from (defense_parts). Live T171/T175: the
    GM gave Quiet Lou three full-pool attacks in a round the engine said held two, each at a fresh defense."""
    enc = active(game)
    if not enc:
        return None
    owner = budget_owner(game, actor)
    r = row(game, enc, owner, turn)
    used = int(r.get("used", 0))
    if mop_up(game, actor, targets):
        save(game, enc)
        return {"owner": owner, "actor": actor, "free": True, "now_pass": max(1, used)}
    n, sc = phases(game, r), score(game, r)
    save(game, enc)                                  # (a row rolled just now stays rolled)
    if used < n:
        return {"owner": owner, "actor": actor, "free": False, "now_pass": used + 1}
    L = game.ledger
    lead = "" if owner == actor else (f"{L.require(actor)['name']} runs on {r['name']}'s Action Phases (remote "
                                      "control), and ")
    if not r.get("dice") and not r.get("attr"):
        why = f"{r['name']} has no Action Phase left this round - none of their own ({(r.get('why') or ['-'])[0]})."
    elif r.get("surprise") and not n:
        why = (f"{r['name']} has no Action Phase left this round - caught flat-footed: Initiative {sc + r['surprise']}"
               f" - {r['surprise']} = {sc}.")
    elif not n:
        why = f"{r['name']} has no Action Phase left this round (Initiative {sc}: none - wounds take it off at once)."
    else:
        why = (f"{r['name']} has no Action Phase left this round (Initiative {sc}: {n} action{'s' * (n != 1)}, "
               f"{'both ' if n == 2 else 'all ' if n > 2 else ''}used).")
    raise NoActionLeft(lead + why + " What's left carries into the next round - narrate what this one held, and the "
                       "rest opens the next." + hint, (actor, owner))


def spend_action(game, check: dict | None, what: str = "") -> str:
    """The card's Action line, once the action has happened: an Action Phase off the owner's row - and their defenses
    since they last acted start over (p. 189) - 'Action Complex: Melee Attack - action 1 of 2 this round (Initiative
    17)'; or why it cost nothing. '' with no fight on."""
    if not check:
        return ""
    head = f"  Action {what} - " if what else "  Action "
    if check["free"]:
        return head + "mopping up, free (nobody stands against them: the table's house rule)"
    enc = active(game)
    if not enc:
        return ""
    r = row(game, enc, check["owner"])
    r["used"] = int(r.get("used", 0)) + 1
    r["acted"], r["defended"] = True, 0
    _mirror(game, r)
    save(game, enc)
    whose = "" if check["owner"] == check["actor"] else f"{r['name']}'s "
    return head + f"{whose}action {r['used']} of {phases(game, r)} this round (Initiative {score(game, r)})"


def defense_parts(game, tid: str, choices=(), melee: bool = False, now_pass: int = 1) -> tuple[list, list[str]]:
    """What the fight adds to one real defense test (sr_lite calls it only when one is rolled - never for the
    helpless or the unaware), and the card's notes. -1 for each defense since the defender last acted (p. 189 - it
    starts over when they act, and each round). choices: the interrupts declared for this defense (p. 168, 188) - full
    (+Willpower on every defense the rest of the round, -10 Initiative, against anything; free once it's on), and one
    of parry (+Close Combat, a melee weapon in hand), block (+Close Combat, for Unarmed) or dodge (+Athletics, for
    Gymnastics), -5 each, against melee only. Each is paid only from the score left in the pass the attack falls in
    (p. 167: 'enough Initiative Score left') - now_pass, or the defender's own later pass. Turned down, with a note and
    the plain defense: against the wrong kind of attack, before a flat-footed defender has acted, with no skill or no
    blade, without the Initiative, or for a machine (it keeps Pilot + Evasion and the -1)."""
    enc = active(game)
    want = [c for c in dict.fromkeys(str(x).strip().lower() for x in (choices or [])) if c in INTERRUPTS]
    if not enc:
        return [], ([f"{' and '.join(want).title()}: no fight on, no Initiative to pay with - plain defense"]
                    if want else [])
    L = game.ledger
    ent = L.require(tid)
    if ent["kind"] not in FIGHTERS:                      # a door, a parked car: no Initiative, so no row - review: a
        return [], ([f"{ent['name']} isn't in the fight's Initiative - plain defense"] if want else [])
    r = row(game, enc, tid)                              # katana on a steel door listed 'Steel door 2 (1 action)'
    parts, notes = [], []
    n = int(r.get("defended", 0))
    if n:
        parts.append(("Already defended", -n))           # (the card: "- Already defended 2")
    r["defended"] = n + 1
    if ent["kind"] in sr_lite.MACHINES:
        if want:
            notes.append(f"{ent['name']} is a machine - no interrupts, Pilot + Evasion only")
        save(game, enc)
        return parts, notes
    now = max(1, now_pass, int(r.get("used", 0)))

    def pay(label: str, cost: int) -> bool:
        sc = score(game, r)
        left = sc - PASS * (now - 1)
        if r.get("flat") and not r.get("acted"):
            notes.append(f"{label}: caught flat-footed - no interrupt before they act (p. 167)")
            return False
        if left < cost:
            notes.append(f"{label}: needs {cost} Initiative, {r['name']} has {max(0, left)} - plain defense")
            return False
        r["spent"] = int(r.get("spent", 0)) + cost
        n_ = phases(game, r)
        notes.append(f"{label}: Initiative {sc} -> {score(game, r)} ({n_} action{'s' * (n_ != 1)} this round, "
                     f"{int(r.get('used', 0))} used)")
        return True

    if "full" in want and not r.get("full") and pay("Full defense", INTERRUPTS["full"]):
        r["full"] = True
    if r.get("full"):
        parts.append(("Full defense (Willpower)", int(L.stat(tid, "willpower", 0))))
    one = [c for c in want if c in ONE_PER_TEST]
    if len(one) > 1:
        notes.append(f"one of parry, block or dodge a defense - {one[0]} it is")
    if one:
        c = one[0]
        skill, label = INTERRUPT_SKILL[c]
        rating = int(L.stat(tid, skill, 0))
        if not melee:
            notes.append(f"{c.title()}: only against melee - plain defense (p. 188)")
        elif not rating:
            notes.append(f"{c.title()}: {r['name']} has no {sr_lite.nice(skill)} - plain defense")
        elif c == "parry" and not any(i["props"].get("skill") == "close_combat" and "dv" in i["props"]
                                      for i in L.holdings(tid)):
            notes.append("Parry: no melee weapon in hand - block (empty hands) or dodge instead")
        elif pay(c.title(), INTERRUPTS[c]):
            parts.append((label, rating))
    _mirror(game, r)
    save(game, enc)
    return parts, notes


def check_multi(game, attacker: str, targets: list[str], skill: str, thrown: bool = False) -> None:
    """Multiple Attacks against the battlefield, before anyone moves (SR5 p. 166, 196): melee strikes go at people in
    one zone - the attacker closes in once - and a fan of throws reaches Short or Medium range only: this zone or the
    next."""
    enc = active(game)
    if not enc or len(targets) < 2:
        return
    L = game.ledger
    where = {t: zone_of(enc, t) for t in targets}
    if skill in MELEE and len(set(where.values()) - {None}) > 1:
        raise LedgerError("Melee strikes in one Action Phase go at people within reach of each other - "
                          + ", ".join(f"{L.require(t)['name']} @ {z}" for t, z in where.items())
                          + ". One zone per attack call.")
    za = zone_of(enc, attacker)
    if thrown and za:
        for t, z in where.items():
            d = distance(enc, za, z) if z else 0
            if d > 1:
                raise LedgerError(f"Several throws in one Action Phase reach Short or Medium range only (SR5 p. 166) - "
                                  f"{L.require(t)['name']} is {RANGE_NAME[min(d, 3)]} ({z}). Throw at them alone, or at "
                                  "closer targets.")


def retune(game, eid: str, before: tuple, turn: int | None = None) -> str:
    """Initiative that changes mid-round counts at once (SR5 p. 160): the attribute's difference, and any dice gained
    rolled now - or lost, rolled and taken off. Increase Reflexes landing mid-fight, or dropped; a mage projecting; a
    drone's control changing (control_drone - review: a remote drone set autonomous, as the refusal itself advised,
    kept its 0/0 'remote' row and was refused again all round; one jumped into, likewise). Someone left with none of
    their own (a rigger's body as they jump in, a drone gone back to remote) has nothing left this round: the round
    goes on in the row that acts for them. before: initiative_rating from just before the change. '' when no fight
    is on, they aren't in it yet (they'll roll the new numbers), or nothing changed; else the card's note."""
    enc = active(game)
    r = next((j for j in (enc or {}).get("jump", []) if j["id"] == eid and "base" in j and not j.get("out")), None)
    if not r:
        return ""
    attr, n, why = sr_lite.initiative_rating(game.ledger, eid)
    d_attr, d_n = attr - before[0], n - before[1]
    if not d_attr and not d_n:
        return ""
    old = score(game, r)
    r["attr"], r["dice"], r["why"] = attr, n, why
    if not attr and not n:
        r["mid_bonus"] = -int(r["base"])
        _mirror(game, r)
        save(game, enc)
        return f"  Initiative {r['name']} {old} -> none of their own this round ({why[0]})"
    dice = sr_lite.roll(game.dice, abs(d_n)).dice
    r["mid_bonus"] = int(r.get("mid_bonus", 0)) + d_attr + (1 if d_n > 0 else -1) * sum(dice)
    _mirror(game, r)
    save(game, enc)
    k = phases(game, r)
    return (f"  Initiative {r['name']} {old} -> {score(game, r)} this round ({d_attr:+d}"
            + (f", {d_n:+d}D6 rolled {' '.join(map(str, dice))}" if d_n else "") + f"): {k} action{'s' * (k != 1)}")


def acts_from(game, eid: str) -> str:
    """The row a person's own actions go on: the machine they're jumped into (it acts for them), else their own."""
    rig = sr_lite.jumped_into(game.ledger, eid)
    return rig["id"] if rig else eid


def carry_used(game, eid: str, was: str) -> None:
    """A rigger jumping in or out takes the round's used actions along (was: acts_from before the change). The
    actions are the rigger's, whichever row holds them, and the limit is a hard one (the table's ruling): Ghost,
    one action spent through his remote drone, jumps in - the drone's fresh row would otherwise hand him a second
    round's worth."""
    enc = active(game)
    now = acts_from(game, eid)
    if not enc or now == was:
        return
    rows = {j["id"]: j for j in enc["jump"] if "base" in j}
    if was in rows and now in rows:
        rows[now]["used"] = max(int(rows[now].get("used", 0)), int(rows[was].get("used", 0)))
        save(game, enc)


# ── smoke: a cloud on a zone (explosives: a smoke grenade) ──────────────
def smoke(game, zone: str | None, near: str | None, kind: str) -> str:
    """A smoke grenade's cloud settles on a zone of the fight for about 4 rounds (SR5 p. 435): the zone named, else the
    zone of the one it's thrown at (near). Live T184: there were no smoke grenades at all, and a GM modifier stops at
    -4 where heavy smoke is -6 (p. 175) - so the engine keeps the cloud and takes it off the attacks (attack_mods).
    With no fight on, the card's numbers are the GM's to apply."""
    enc = active(game)
    if not enc:
        return (f"  Cloud  no fight on: tests to see through it take {explosives.SMOKE[kind]} (heavy smoke) for a few "
                "minutes")
    check_cloud_zone(game, zone)
    z = (_zone_name(enc, zone) if zone else None) or zone_of(enc, (game.ledger.find(near or "") or {}).get("id", "")) \
        or (enc["zones"][0]["name"] if enc["zones"] else None)
    if not z:
        return "  Cloud  (no zones yet to put it on)"
    for zone in enc["zones"]:
        if zone["name"] == z:
            zone["smoke"] = {"kind": kind, "until": enc["round"] + explosives.CLOUD_ROUNDS}
    save(game, enc)
    return f"  Cloud  {z} fills with {'thermal ' if kind == 'thermal' else ''}smoke - through round {enc['round'] + explosives.CLOUD_ROUNDS}"


def check_cloud_zone(game, zone: str | None) -> None:
    """A zone named for a cloud has to be one of the fight's - checked before the grenade is used up (review E2: 'the
    loading dock', in a fight of bar/door/street, quietly filled the thrower's own zone, and nothing clears a cloud).
    No zone named: the target's or the thrower's, as before."""
    enc = active(game)
    if enc and zone and enc["zones"] and not _zone_name(enc, zone):
        raise RulesRefusal(f"No zone '{zone}' in this fight - zones: {', '.join(z['name'] for z in enc['zones'])}. "
                           "Name one of them (the grenade hasn't gone off).")


def _smoke_on(enc: dict, zone: str | None) -> str | None:
    """The cloud on a zone this round, if any ('smoke' or 'thermal')."""
    z = next((x for x in enc["zones"] if x["name"] == zone), None)
    s = (z or {}).get("smoke") or {}
    return s.get("kind") if s and int(s.get("until", 0)) >= enc["round"] + 1 else None


def thermographic(game, eid: str) -> bool:
    """Eyes that see heat: a dwarf's or a troll's, or cybereyes / goggles with thermographic vision."""
    L = game.ledger
    ent = L.get(eid) or {}
    meta = ((ent.get("props") or {}).get("metatype") or "").lower()
    from .chargen import METATYPES
    if "thermographic" in METATYPES.get(meta, {}).get("traits", ""):
        return True
    return any("thermographic" in (i["name"] + " " + str(i["props"].get("effect", ""))).lower()
               for i in sr_lite.in_hand(L, eid))


def _crossed(enc: dict, za: str, zt: str) -> list[str]:
    """Smoked zones a shot from za to zt has to pass through: between them on every shortest way (a way round the cloud
    as short as the straight one sees past it). Review E2: the card said 'through it', and a shot across a smoked
    lobby from the street to the stairs took nothing."""
    smoked = {z["name"] for z in enc["zones"] if _smoke_on(enc, z["name"])} - {za, zt}
    full = _hops(enc, za) if smoked else {}
    if zt not in full or _hops(enc, za, smoked).get(zt) == full[zt]:
        return []
    back = _hops(enc, zt)
    return [z for z in sorted(smoked) if z in full and z in back and full[z] + back[z] == full[zt]]


def smoke_part(game, enc: dict, attacker: str, za: str, zt: str, ranged: bool = True) -> tuple[str, int] | None:
    """The visibility modifier from smoke the shot or blow goes into, out of or - a shot, not a blow - through (p. 175:
    heavy smoke -6; thermographic vision a row up, -3, except against thermal smoke)."""
    clouds = [(z, _smoke_on(enc, z)) for z in dict.fromkeys((zt, za)) if _smoke_on(enc, z)]
    where = clouds[0][0] if clouds else None
    if ranged and not clouds:
        clouds = [(z, _smoke_on(enc, z)) for z in _crossed(enc, za, zt)]
        where = f"{clouds[0][0]}, between" if clouds else None
    if not clouds:
        return None
    kind = "thermal" if any(k == "thermal" for _, k in clouds) else "smoke"
    if kind == "smoke" and thermographic(game, attacker):
        return (f"Smoke ({where}; thermographic)", explosives.THERMO_SMOKE)
    return (f"Heavy {'thermal ' if kind == 'thermal' else ''}smoke ({where})", explosives.SMOKE[kind])


def environment(fog: tuple[str, int] | None, apart: int, zt: str) -> tuple[str, int] | None:
    """The one Environmental modifier for smoke and range together: only the most severe condition counts, and two
    tied at it are a row worse (-1, -3, -6, -10) - SR5 p. 173: "take only the most severe environmental condition ...
    Note that Range is an environmental modifier." Review E2: heavy smoke and extreme range added up to -12, where the
    book has -10 (and -6 at close, near and far)."""
    rng, name = RANGE_MOD[min(apart, 3)], RANGE_NAME[min(apart, 3)]
    if not fog:
        return (f"Range: {name} ({zt})", rng) if rng else None
    label, vis = fog
    if not rng:
        return fog
    if vis == rng:
        return f"{label[:-1]}; with {name} range, two at {vis}: a row worse, p. 173)", ENV_ROWS[ENV_ROWS.index(vis) + 1]
    if vis < rng:
        return f"{label[:-1]}; {name} range doesn't add, p. 173)", vis
    return f"Range: {name} ({zt}; the smoke doesn't add, p. 173)", rng


# ── during: what attacks pick up from the zones ─────────────────────────
def attack_mods(game, attacker: str, target: str, skill: str) -> tuple[list, list, list[str]]:
    """(attack parts, defense parts, notes) from the active fight; melee closes the distance; smoke blinds."""
    enc = active(game)
    if not enc:
        return [], [], []
    za, zt = zone_of(enc, attacker), zone_of(enc, target)
    if not za or not zt:
        return [], [], []
    notes, apart = [], distance(enc, za, zt)
    atk, dfn = [], []
    melee = skill in MELEE or skill == "unarmed"
    fog = smoke_part(game, enc, attacker, za, zt, ranged=not melee)
    if melee:
        if fog:
            atk.append(fog)
        if apart:
            enc["positions"][attacker] = zt
            notes.append(f"{game.ledger.require(attacker)['name']} closes in ({za} -> {zt})")
        apart = 0
    else:
        env = environment(fog, apart, zt)            # (smoke and range: one modifier, the worst - p. 173)
        if env:
            atk.append(env)
        cover = next((z["cover"] for z in enc["zones"] if z["name"] == zt), "none")
        if apart and COVER_DICE.get(cover):
            dfn.append((f"Cover: {cover} ({zt})", COVER_DICE[cover]))
    save(game, enc)
    return atk, dfn, notes


def at_odds(game, a: str, b: str) -> bool:
    """Is harm between a and b a fight? Between anyone but two runners. A runner's backswing catching a crewmate, or a
    crewmate riding into the team mage's barrier, is an accident inside the crew (review: apply_damage with Razor as
    the source and Ghost as the target opened a fight with nobody hostile in it, which couldn't end itself, and held
    the memory, the resting and the karma for three turns). Sides by who they are (no fight on yet)."""
    return a != b and not (side(game, None, a) == "runners" and side(game, None, b) == "runners")


def _trim_attacks(game, enc: dict) -> None:
    """The last ATTACKS_KEPT attacks - and, from before them, the first blow each non-runner the other side struck took,
    so a long fight still knows whom the hostiles hurt (foes: their victims are no foes of the crew's). Review: the
    plain last-40 cap forgot a hostile's early victims, who then counted as foes still standing."""
    if len(enc["attacks"]) <= ATTACKS_KEPT:
        return
    old, kept = enc["attacks"][:-ATTACKS_KEPT], enc["attacks"][-ATTACKS_KEPT:]
    struck = {a["to"] for a in kept if side(game, enc, a["from"]) != "runners"}
    first = []
    for a in old:
        if a["to"] not in struck and side(game, enc, a["from"]) != "runners" and side(game, enc, a["to"]) != "runners":
            struck.add(a["to"])
            first.append(a)
    enc["attacks"] = first + kept


def note_attack(game, attacker: str, target: str, hit: bool) -> None:
    enc = active(game)
    if not enc:
        return
    enc["attacks"].append({"round": enc["round"] + 1, "from": attacker, "to": target, "hit": bool(hit)})
    for j in enc["jump"]:
        if j["id"] == attacker:
            j["acted"] = True                            # (no longer flat-footed)
    _trim_attacks(game, enc)
    sa, st = side(game, enc, attacker), side(game, enc, target)
    if sa == "runners" and st not in ("runners",) + GAVE_UP:   # (shooting someone who gave up doesn't re-arm them)
        enc["sides"][target] = "hostile"
    if st == "runners" and sa != "runners":
        enc["sides"][attacker] = "hostile"
    for eid, role in ((attacker, "actor"), (target, "target")):
        if {"actor": 2, "target": 1}.get(role, 0) > {"actor": 2, "target": 1}.get(enc["members"].get(eid), 0):
            enc["members"][eid] = role
    enc["quiet"] = 0
    save(game, enc)


def foes(game, enc: dict) -> list[str]:
    """Who the runners are fighting: everyone on the hostile side (or who gave up), plus any NPC hurt since the fight
    began who has no side yet - unless it was the hostiles who hurt them. Live T171: the barrier crash hurt Garvey
    through apply_damage, which marks no sides, so only Joe and Spud were foes and the fight ended itself with Garvey,
    Fenn and Gutter on their feet. (Drain and bleeding are nobody's doing.) The hostiles' victims are theirs whatever
    became of the hostiles: review - Joey cut Kaz and then surrendered, and Kaz, no longer 'hurt by a hostile', turned
    into a foe still standing, so the fight couldn't end itself and a coup de grace was refused while he stood."""
    L = game.ledger
    out = [e for e, s in enc["sides"].items() if s in ("hostile",) + GAVE_UP]
    by_them = {a["to"] for a in enc["attacks"] if enc["sides"].get(a["from"]) in ("hostile",) + GAVE_UP}
    roster = set(L.roster(enc["scene_id"]))
    for r in game.conn.execute("SELECT actor, payload FROM events WHERE kind='damage' AND turn_id>=? AND actor IS NOT "
                               "NULL ORDER BY seq", (enc["started_turn"],)):
        e = r["actor"]
        if e in enc["sides"] or e in out or e in by_them or e not in roster:
            continue
        p = json.loads(r["payload"] or "{}")
        if not p.get("boxes") or p.get("resist") == "drain" or p.get("how") == "bleeding":
            continue
        if (L.get(e) or {}).get("kind") in ("npc", "spirit", "drone") and side(game, enc, e) != "runners":
            out.append(e)
    return out


def standing(game, enc: dict, foe_ids: list[str] | None = None) -> list[str]:
    """The foes still in the fight and on their feet."""
    L = game.ledger
    roster = set(L.roster(enc["scene_id"]))
    return [e for e in (foes(game, enc) if foe_ids is None else foe_ids)
            if enc["sides"].get(e, "hostile") == "hostile" and e in roster and sr_lite.condition(L, e) not in sr_lite.OUT]


def stands_against(game, eid: str) -> list[str]:
    """Who's still on their feet against eid in the fight here ([] with no fight on): for a runner, the hostiles still
    standing; for anyone else, the runners. A coup de grace (finish) and the free mop-up wait until nobody does. Only
    the hostile side counts - not the hurt with no side yet, whom foes() keeps in the fight so it doesn't end itself
    early (live T171): the table's ruling is no live threat around, and review found a bartender cut by a shattered
    mirror, 'neutral' in the GM's own packet, refusing the kill with 'Attack, or deal with them first'."""
    enc = active(game)
    if not enc:
        return []
    if side(game, enc, eid) == "runners":
        return [e for e in standing(game, enc) if enc["sides"].get(e) == "hostile"]
    L = game.ledger
    return [e for e in L.roster(enc["scene_id"]) if (L.get(e) or {}).get("kind") in FIGHTERS
            and side(game, enc, e) == "runners" and sr_lite.condition(L, e) not in sr_lite.OUT]


def request_end(game, how: str) -> bool:
    """The GM says the fight's over: it ends after this turn (False: no fight on). A line that says it ISN'T over is
    turned away while a hostile still stands (RulesRefusal) - the fight just goes on."""
    enc = active(game)
    if not enc:
        return False
    how = (how or "").strip()
    up = standing(game, enc) if NOT_OVER.match(how) else []
    if up:
        names = ", ".join((game.ledger.get(e) or {}).get("name", e) for e in up)
        raise RulesRefusal(f"the fight isn't over - {names} still stand{'s' * (len(up) == 1)}, so it goes on by itself. "
                           "`battle end:` (or fight end) is only for a fight that has ended.")
    enc["ending"] = how or "it's over"
    save(game, enc)
    return True


# ── after each turn: the round goes in the log, not the graph ───────────
def step(game, enc: dict, turn: int, summary: str, moves: list[dict], members: dict[str, str],
         layout: list[dict] | None = None, yields: list[dict] | None = None) -> str | None:
    """Advance the fight by one round. Returns how it ended, if it did. members: the turn's, from the memory pass -
    only the ones in this fight's scene join it (review: after a mid-turn cut, the alley's fight took in Joey and Kaz,
    left behind in the bar - they rolled Initiative there, sat in its packet, and would have been witnesses in its
    memory)."""
    L = game.ledger
    roster = set(L.roster(enc["scene_id"]))
    if layout and len(enc["zones"]) <= 1:
        set_zones(enc, layout)
    for m in moves or []:
        ent = L.find(m.get("id", ""))
        if ent and m.get("zone"):
            move(enc, ent["id"], m["zone"])
    for y in yields or []:                          # out of the fight without going down
        ent = L.find(y.get("id", ""))
        if ent and sr_lite.condition(L, ent["id"]) in ("unconscious", "dying", "dead"):
            continue                                # (taken down mid-escape isn't giving up - the fight did it)
        if ent and y.get("how") in GAVE_UP and side(game, enc, ent["id"]) != "runners":
            enc["sides"][ent["id"]] = y["how"]
            if y["how"] == "fled":
                enc["positions"].pop(ent["id"], None)
    for eid, role in members.items():
        ent = L.get(eid)
        if ent and ent["kind"] in FIGHTERS and role in ("actor", "target", "present") and eid in roster:
            enc["members"].setdefault(eid, "present")
            enc["positions"].setdefault(eid, enc["zones"][0]["name"])
    enc["round"] += 1
    attacked = any(a["round"] == enc["round"] for a in enc["attacks"])
    enc["quiet"] = 0 if attacked else enc["quiet"] + 1
    enc["log"].append({"round": enc["round"], "time": clock.short(game.clock()), "text": summary})
    against = foes(game, enc)
    how = enc.get("ending")
    if not how and against and not standing(game, enc, against):     # how it ended, from what became of each of them
        fate = lambda e: enc["sides"].get(e) if enc["sides"].get(e) in GAVE_UP else (     # noqa: E731
            "went down" if sr_lite.condition(L, e) in sr_lite.OUT else "left")
        how = "; ".join(f"{(L.get(e) or {}).get('name', e)} {fate(e)}" for e in against)
    if not how and enc["quiet"] >= QUIET_ROUNDS:
        how = "the fighting petered out"
    save(game, enc)
    return how


def end(game, enc: dict, turn: int, how: str, reflect: bool = True) -> str | None:
    """The whole fight becomes one memory, everyone's part in it; the NPCs who were there reflect."""
    L, S = game.ledger, game.sub
    enc["status"], enc["ended_turn"], enc["outcome"] = "ended", turn, how
    save(game, enc)
    if not enc["log"]:
        return None
    log = "\n".join(f"Round {x['round']} ({x['time']}): {x['text']}" for x in enc["log"])
    def stood(e):
        s = side(game, enc, e)
        return f"by the end: {s}" if s in GAVE_UP else s
    who = ", ".join(f"{(L.get(e) or {}).get('name', e)} ({stood(e)})" for e in enc["members"])
    try:
        text = game.llm.text(game.settings.models.commit, FIGHT_SYSTEM, f"WHO: {who}\nHOW IT ENDED: {how}\n\nLOG:\n{log}",
                             max_tokens=2500, effort=game.settings.models.commit_effort,
                             fallback=None, purpose="fights").strip()
    except Exception:
        text = ""
    if not text or text.startswith("(The system declined"):
        text = f"A fight broke out ({how}). " + " ".join(x["text"] for x in enc["log"][-4:])
    members = [(e, r) for e, r in enc["members"].items() if L.get(e)]
    sc = L.scene(enc["scene_id"])
    if sc and sc["location_id"]:
        members.append((sc["location_id"], "location"))
    sl = S.write_slice(turn, enc["scene_id"], f"The fight: {text}", members, [], story_time=game.clock())
    S.touch([sl], turn, 1.0)
    L.log(turn, "fight_end", None, {"encounter": enc["id"], "how": how, "slice": sl, "rounds": enc["round"]})
    if reflect:                                                          # (a closing scene reflects anyway)
        from .dm.minds import reflect_scene
        try:
            reflect_scene(game, enc["scene_id"], turn, set(enc["members"]))   # minds settle when the shooting stops
        except Exception as exc:
            game.out(f"  (fight: no reflection - {exc})")
    return sl


def end_for_scene(game, scene_id: int, turn: int, how: str = "the scene moved on") -> str | None:
    enc = active(game, scene_id)
    return end(game, enc, turn, enc.get("ending") or how) if enc else None


# ── what the GM sees ────────────────────────────────────────────────────
def packet_lines(game, enc: dict) -> list[str]:
    L = game.ledger
    zones = " · ".join(f"{z['name']}" + (f" ({z['cover']} cover)" if z["cover"] != "none" else "")
                       + (f" (heavy {'thermal ' if _smoke_on(enc, z['name']) == 'thermal' else ''}smoke: -6 to attacks "
                          "into, out of, in or through it)" if _smoke_on(enc, z["name"]) else "")
                       + (f" - next to {', '.join(z['near'])}" if z["near"] else "") for z in enc["zones"])
    pos = []
    for e, z in enc["positions"].items():
        ent = L.get(e)
        if ent:
            pos.append(f"{ent['name']} [{e}] {side(game, enc, e)} @ {z} ({sr_lite.condition(L, e)})")
    out = [f"\n=== FIGHT - round {enc['round'] + 1} (the engine tracks the battlefield; you narrate freely) ===",
           f"Zones: {zones}", "Positions: " + "; ".join(pos), initiative_line(game, enc)]
    joined = [j for j in enc["jump"] if enc["round"] and j.get("joined_round") == enc["round"]]
    if joined:
        out.append("Joining this round: " + ", ".join(
            j["name"] + (" - flat-footed: can't dodge until they act" if j["flat"] and not j.get("acted") else "")
            for j in joined))
    if enc["log"]:
        out.append("Lately: " + " | ".join(f"R{x['round']}: {x['text']}" for x in enc["log"][-3:]))
    out.append("Attacks pick up range and cover from the zones by themselves (same zone 0, next -1, two away -3, "
               "farther -6; melee closes in; cover in the defender's zone adds dice). For explosives: same zone = "
               "close, next zone = near, two away = far. Narrate movement plainly - the engine reads it. Newcomers "
               "(reinforcements, a second ambush) join with the fight tool (start) - never a new fight. When it's "
               "over, say so with `battle end: <how>` in the <dm> block (or the fight tool); while it isn't, say "
               "nothing.")
    out.append("Several strikes in one Action Phase = ONE attack call: target_id plus `more` (the pool splits; at most "
               "half the combat skill, rounded up; a gun fires once a phase). thrown=true: Throwing + Agility at "
               "range, and the weapon lands here. Defense is free, -1 for each defense since the defender last acted; "
               "parry / block / dodge (melee only, -5 Initiative) and full (+Willpower the rest of the round, -10) "
               "only when declared - a player's character when their player says so. Finishing off the helpless "
               "once nobody stands against you costs no action (house rule).")
    return out


def initiative_line(game, enc: dict) -> str:
    """The GM's view of the round's budget: who has how many actions, how many are used, who's defended or paid for
    a defense - a cap, not a quota."""
    bits = []
    for r in enc["jump"]:
        if r.get("out"):
            continue
        if "base" not in r or (not r.get("dice") and not r.get("attr")):
            bits.append(_entry(game, r))
            continue
        n, used = phases(game, r), int(r.get("used", 0))
        tags = [f"{used} used"] if used else []
        if r.get("defended"):
            tags.append(f"defended {r['defended']}x")
        if r.get("full"):
            tags.append("full defense on")
        bits.append(f"{r['name']} {score(game, r)} - {n} action{'s' * (n != 1)}" + (f" ({', '.join(tags)})" if tags else "")
                    + (" - flat-footed: no interrupts, can't dodge until they act" if r.get("flat") and not r.get("acted")
                       else "") + (f" - came in late -{r['late']}" if r.get("late") else ""))
    return (f"Initiative, round {enc['round'] + 1}" + (" - narrate the opening beat in this order" if enc["round"] == 0
                                                       else "")
            + " (each 10 = an Action Phase: one attack, spell or grenade; the engine refuses more - a cap, not a "
              "quota: unused phases just pass): " + (" · ".join(bits) or "nobody yet"))


def commit_lines(game, enc: dict) -> str:
    """For the memory pass: the battlefield as it stood before this turn."""
    L = game.ledger
    return ("FIGHT IN PROGRESS - zones: " + "; ".join(z["name"] for z in enc["zones"])
            + "\nPositions: " + "; ".join(f"{(L.get(e) or {}).get('name', e)} [{e}] @ {z}" for e, z in enc["positions"].items())
            + ("\nThe layout is still a placeholder - propose 2-5 zones in combat.zones." if len(enc["zones"]) <= 1 else ""))
