"""In-game shops (DESIGN.md §7f): places in the story that sell gear.

When the runners walk into a gun shop, a pawnshop, a street doc's clinic or a talismonger's, the GM stocks it with
`open_shop`: it picks what fits the place from the gear catalog (chargen.CATALOG, at SR5's prices) and a markup, and
the engine sets the prices and stock and keeps them on the location (props.shop). An online dealer or a fixer on the
phone is a remote shop: stocked on the dealer's own entity, listed in the scene where the runners are looking, and
everything it sells comes by courier. Players see it with `!shop` and buy with `!buy`, or say so in the story and the
GM calls `buy`. Either way the engine charges the nuyen and delivers: gear to the character (or straight onto their
drone), drones built as the book's bare frames, cyberware installed (Essence paid, Magic/Resonance lost for it,
attributes raised).

Availability (SR5 p. 417-418) is a soft gate, the table's call (2026-10-24): it shows everywhere; a legal shop can't
stock anything Forbidden; a restricted or forbidden item at a dealer who asks no questions takes the dealer's search
when it's stocked - their Negotiation + Charisma against its Availability - and the net hits set how soon it arrives,
coarsely ("tomorrow morning", "in a few days"). Nothing fails at the checkout: what's listed can be bought. What has to
be delivered is held, in transit, and can't be used until the story clock gets there (arrivals, from commit).
"""
from __future__ import annotations

import json
import math
import re

from .chargen import AUG_MAX, CATALOG, CATEGORIES, avail_of, avail_text
from .engine import clock
from .engine.ledger import LedgerError
from .engine.rules import machines, sr_lite

MARKUP = (0.6, 2.0)
MAX_ITEMS = 16
DEALER_POOL = 8                 # a dealer's Negotiation + Charisma when nobody's on file to roll it (a pro: 4 + 4)
COURIER_HOURS = 3               # an order from a remote dealer still has to get there - a courier drop, the same day
EXTRA_DIE = 0.25                # each extra 25% paid over the list price is a die on the search, up to 12 (p. 418)
EXTRA_MAX = 12
# p. 418, Delivery Times: up to 100¥ 6 hours, to 1,000 a day, to 10,000 two days, to 100,000 a week, more a month
DELIVERY = ((100, 6), (1000, 24), (10000, 48), (100000, 168), (None, 720))
REMOTE = "remote_shops"         # meta: the entities with a remote shop open (where() finds their listings)
TRANSIT = "in_transit"          # meta: what's bought and still on its way (arrivals())


def catalog_lines() -> str:
    """The catalog as the GM sees it in the tool description."""
    out = []
    for cat in CATEGORIES:
        out.append(f"{cat}: " + ", ".join(f"{k} ({v['name']}, {v['cost']}" + (f", {v['avail']}" if v.get("avail") else "")
                                          + ")" for k, v in CATALOG.items() if v["cat"] == cat))
    return "; ".join(out)


def _price(key: str, markup: float) -> int:
    return max(10, int(round(CATALOG[key]["cost"] * markup / 10.0)) * 10)


def _clamp(markup) -> float:
    return max(MARKUP[0], min(MARKUP[1], float(markup or 1.0)))


def _ids(game, key: str) -> list[str]:
    try:
        return list(json.loads(game.ledger.meta(key, "[]") or "[]"))
    except ValueError:
        return []


def _set_ids(game, key: str, ids) -> None:
    game.ledger.set_meta(key, json.dumps(list(dict.fromkeys(ids))))


# ── the dealer's search: Availability (p. 418) ──────────────────────────
def base_hours(cost: int) -> int:
    """The Delivery Times table's time for an item at this price (p. 418)."""
    return next(h for top, h in DELIVERY if top is None or cost <= top)


def search(game, pool: int, key: str, markup: float = 1.0) -> dict:
    """The dealer looks for it: an opposed test of their Negotiation + Charisma against the item's Availability, +1 die
    for every 25% paid over the list price (the markup; at most 12). Net hits divide the delivery time, a tie doubles
    it, and a miss makes it three times as long (the first search came up dry, the retry waits twice the time) - it
    still comes: the table's soft gate, nothing fails at the checkout. A glitch draws attention (p. 418), the GM's to
    play. Returns {pool, hits, against, their, net, hours, glitch}."""
    item = CATALOG[key]
    n = avail_of(item)[0]
    extra = min(EXTRA_MAX, max(0, int(round((markup - 1.0) / EXTRA_DIE, 6))))
    mine, theirs = sr_lite.roll(game.dice, pool + extra), sr_lite.roll(game.dice, n)
    net, base = mine.hits - theirs.hits, base_hours(item["cost"])
    hours = math.ceil(base / net) if net > 0 else base * (2 if net == 0 else 3)
    return {"pool": pool + extra, "extra": extra, "hits": mine.hits, "against": n, "their": theirs.hits, "net": net,
            "hours": hours, "glitch": "critical" if mine.crit_glitch else ("glitch" if mine.glitch else "")}


def _dealer(game, holder: dict, contact_id: str | None) -> tuple[int, str, str | None]:
    """(pool, who, contact id): the contact who finds the gear rolls it - their Negotiation + Charisma (p. 418,
    Contacts and Availability), not the buyer's. A shop on an NPC's own entity is theirs; otherwise a dealer's 8."""
    L = game.ledger
    who = L.require(contact_id) if contact_id else (holder if holder["kind"] == "npc" else None)
    if who and who["kind"] in ("npc", "pc"):
        n, _ = sr_lite.build_pool(L, who["id"], "negotiation", "charisma")
        return n, who["name"], who["id"]
    return DEALER_POOL, "the dealer", None


def arrives(game, hours: int) -> int:
    """When something ordered now gets here: the story's next part of day after that many hours (never a minute)."""
    return clock.snap(game.clock() + int(hours) * 60)


def when(game, hours: int) -> str:
    """'tomorrow morning', 'in a few days' - for an order placed now."""
    return clock.ahead(arrives(game, hours), game.clock())


# ── stocking ────────────────────────────────────────────────────────────
def stock(game, location_id: str, name: str, kind: str, items: list, markup: float = 1.0, turn: int = 0,
          legal: bool = False, remote: bool = False, contact_id: str | None = None) -> tuple[dict, list[str]]:
    """Stock (or restock) a shop. items: catalog keys, or {"key", "stock", "markup"} (one item priced apart from the
    rest - a refurb discount, an under-the-counter gun). Unknown keys are skipped and returned; so is anything
    Forbidden at a legal shop. remote: an online dealer or a fixer's call - it lives on the dealer's own entity (a
    place, an NPC, a faction), never the room the runners are in, and is listed in the scene where it was opened.
    Restricted and forbidden items at a shop that isn't legal take the contact's search now (search()). Returns
    (shop, skipped)."""
    L = game.ledger
    holder = L.require(location_id)
    sid = game.current_scene_id()
    here = (L.scene(sid) or {}).get("location_id")
    if remote:
        if holder["kind"] not in ("location", "npc", "faction"):
            raise LedgerError(f"{holder['name']} can't run a shop - a remote dealer is a place, an NPC or a faction.")
        if holder["id"] == here:
            raise LedgerError(f"{holder['name']} is where the runners are standing - an online dealer or a fixer's call "
                              "is open_shop(remote=true) on the dealer's own entity: introduce the dealer (their place "
                              "or the fixer) and stock that.")
    elif holder["kind"] != "location":
        raise LedgerError(f"{holder['name']} isn't a place - shops live at locations (a fixer's call or an online "
                          "dealer is remote: true on the dealer).")
    markup = _clamp(markup)
    pool, who, contact = _dealer(game, holder, contact_id)
    # A restock keeps the searches already made by the same contact: live, BarrensBolt was restocked four times in five
    # turns (T181-T185) - re-rolling each time would let a slow find be fished for a fast one.
    before = holder["props"].get("shop") or {}
    kept = {k: v["search"] for k, v in (before.get("items") or {}).items()
            if v.get("search") and before.get("contact") == contact}
    inv, skipped = {}, []
    for it in items[:MAX_ITEMS]:
        key = (it.get("key") if isinstance(it, dict) else it or "").strip().lower()
        if key not in CATALOG:
            skipped.append(key)
            continue
        item = CATALOG[key]
        n, letter = avail_of(item)
        if legal and letter == "F":
            skipped.append(f"{key} ({item['avail']}: Forbidden - a legal shop can't stock it)")
            continue
        mk = _clamp(it.get("markup") or markup) if isinstance(it, dict) else markup
        default = 6 if item.get("max", 1) > 1 else (1 if item["cost"] >= 4000 else 2)
        qty = int(it.get("stock") or default) if isinstance(it, dict) else default
        offer = {"price": _price(key, mk), "stock": max(1, min(20, qty))}
        if mk != markup:
            offer["markup"] = round(mk, 2)
        if letter and not legal:                      # off the books: the dealer has to find it
            found = dict(kept[key], kept=True) if key in kept else search(game, pool, key, mk)
            offer.update(hours=found["hours"], search=found)
        if remote:
            offer["hours"] = max(offer.get("hours", 0), COURIER_HOURS)
        inv[key] = offer
    if not inv:
        raise LedgerError("None of those can be stocked here - use the catalog's keys (e.g. heavy-pistol, "
                          "armored-jacket)" + (f"; skipped: {', '.join(skipped)}" if skipped else "") + ".")
    shop = {"name": name.strip() or holder["name"], "kind": kind.strip() or "shop", "markup": round(markup, 2),
            "items": inv, "turn": turn, "legal": bool(legal), "remote": bool(remote), "contact": contact, "by": who}
    if remote:
        shop["scene"] = sid
        _set_ids(game, REMOTE, _ids(game, REMOTE) + [holder["id"]])
    L.update_entity(holder["id"], props={**holder["props"], "shop": shop})
    L.log(turn, "shop_stocked", holder["id"], {"items": list(inv), "markup": shop["markup"], "legal": shop["legal"],
                                               "remote": shop["remote"],
                                               "searches": {k: v["search"] for k, v in inv.items() if v.get("search")}})
    return shop, skipped


def search_lines(game, shop: dict) -> list[str]:
    """The dealer's searches, for the GM's open_shop result: who rolled what, and when each would come."""
    out = []
    for k, v in shop["items"].items():
        s = v.get("search")
        if not s:
            continue
        out.append(f"{k} ({CATALOG[k]['avail']}): {shop.get('by', 'the dealer')} {s['pool']}d6"
                   + (f" (+{s['extra']} for the markup)" if s.get("extra") else "")
                   + f" -> {s['hits']} vs Availability {s['against']}d6 -> {s['their']}: "
                   + ("found" if s["net"] > 0 else "a tie - slow" if s["net"] == 0 else "came up dry first - slower")
                   + f", arrives {when(game, v['hours'])} if bought now"
                   + (" (the earlier search stands)" if s.get("kept") else
                      {"glitch": " - the inquiries drew attention (SR5 p. 418: yours to play)",
                       "critical": " - CRITICAL GLITCH: the inquiries drew the wrong people's attention (p. 418)"}.get(
                          s.get("glitch") or "", "")))
    return out


# ── where to buy ────────────────────────────────────────────────────────
def shops_for(game, eid: str) -> list[tuple[dict, dict]]:
    """Every shop this character can buy from right now, newest first: the one at the place they're standing, and the
    remote dealers listed in their scene (live T181-T187: BarrensBolt's online listings had to be stocked onto
    Castellano's Hardware, the room the crew was in, where they stayed as SHOP HERE)."""
    L = game.ledger
    sid = L.scene_of(eid)
    scene = L.scene(sid) if sid else None
    out = []
    loc = L.get(scene["location_id"]) if scene and scene["location_id"] else None
    if loc and loc["props"].get("shop"):
        out.append((loc, loc["props"]["shop"]))
    for hid in _ids(game, REMOTE):
        h = L.get(hid)
        shop = (h or {}).get("props", {}).get("shop") or {}
        if h and shop.get("remote") and sid is not None and shop.get("scene") == sid and h["id"] != (loc or {}).get("id"):
            out.append((h, shop))
    return sorted(out, key=lambda hs: -int(hs[1].get("turn") or 0))


def where(game, eid: str, shop_id: str | None = None) -> tuple[dict, dict] | tuple[None, None]:
    """The shop this character buys from: shop_id's (a remote dealer from anywhere; a shop at a place only while
    they're there), else the newest one open to them (shops_for)."""
    L = game.ledger
    if shop_id:
        h = L.require(shop_id)
        shop = h["props"].get("shop")
        if not shop:
            raise LedgerError(f"{h['name']} has no shop open - open_shop first.")
        if shop.get("remote") or any(x["id"] == h["id"] for x, _ in shops_for(game, eid)):
            return h, shop
        raise LedgerError(f"{shop['name']} is at {h['name']} - {L.require(eid)['name']} isn't there.")
    found = shops_for(game, eid)
    return found[0] if found else (None, None)


def find(game, eid: str, ref: str) -> str | None:
    """A shop open to this character by (part of) its or its holder's name - for `!shop <name>`."""
    ref = (ref or "").strip().lower()
    for h, shop in shops_for(game, eid):
        if ref and (ref in shop["name"].lower() or ref in h["name"].lower() or ref == h["id"]):
            return h["id"]
    return None


def _open_names(game, eid: str) -> str:
    return ", ".join(s["name"] for _, s in shops_for(game, eid)) or "none"


def look(game, eid: str, ref: str = "") -> str | None:
    """The shop `!shop <name>` shows (its holder's id; None: where()'s default) - a name that matches no open shop is
    refused rather than quietly showing another one's menu."""
    if not (ref or "").strip():
        return None
    pick = find(game, eid, ref)
    if not pick:
        raise LedgerError(f"No shop '{ref.strip()}' open to {game.ledger.require(eid)['name']} - open: "
                          f"{_open_names(game, eid)}.")
    return pick


def chosen(game, eid: str, ref: str, seen: str | None = None, named: str | None = None) -> str | None:
    """The shop a player's `!buy` means (its holder's id; None: where()'s default): the one named (`from <shop>`),
    else the one their last `!shop` card showed while it's still open to them - its numbers are that card's (review
    E2: `!shop kaz` showed Kaz's `1` Armored jacket, then `!buy 1` charged 5,000¥ for BarrensBolt's Roto-drone, the
    newest shop's 1). With two or more open and no card to go by, a bare number could be either's: refused."""
    if named:
        return look(game, eid, named)
    open_ = shops_for(game, eid)
    if seen and any(h["id"] == seen for h, _ in open_):
        return seen
    if len(open_) > 1 and (ref or "").strip().isdigit():
        raise LedgerError(f"More than one shop is open ({_open_names(game, eid)}) - `!shop <name>` shows one's "
                          "numbers, or say which: `!buy <#> from <shop>`.")
    return None


def menu(shop: dict) -> list[tuple[int, str]]:
    keys = sorted(shop["items"], key=lambda k: (CATEGORIES.index(CATALOG[k]["cat"]), CATALOG[k]["cost"]))
    return [(i + 1, k) for i, k in enumerate(keys)]


def _resolve(shop: dict, ref: str) -> str | None:
    ref = ref.strip().lower()
    nums = dict(menu(shop))
    if ref.isdigit():
        return nums.get(int(ref))
    if ref in shop["items"]:
        return ref
    for test in (lambda k, n: k.startswith(ref), lambda k, n: any(w.startswith(ref) for w in re.findall(r"[a-z0-9]+", n)),
                 lambda k, n: ref in n):
        hits = [k for k in shop["items"] if ref and test(k, CATALOG[k]["name"].lower())]
        if hits:
            return hits[0] if len(hits) == 1 else None
    return None


# ── buying ──────────────────────────────────────────────────────────────
def _onto(game, ent: dict, item: dict, ref: str | None) -> dict | None:
    """The machine a purchase goes straight onto: the one named (the buyer's own, or one they drive or hold the keys
    to), or - for an autosoft or a mount, which only goes on a drone - the buyer's only one with room."""
    L = game.ledger
    p = item.get("props") or {}
    theirs = [m for m in machines._machines(L) if machines.commands(L, m, ent["id"])]
    if ref:
        m = L.find(ref)
        if m is None or m["kind"] not in sr_lite.MACHINES:
            low = ref.strip().lower()
            hits = [x for x in theirs if low in x["name"].lower()]
            m = hits[0] if len(hits) == 1 else None
        if m is None:
            raise LedgerError(f"No drone or vehicle '{ref}' - {ent['name']}'s: "
                              + (", ".join(f"{x['name']} [{x['id']}]" for x in theirs) or "none") + ".")
        if not machines.commands(L, m, ent["id"]):
            raise LedgerError(f"{m['name']} isn't {ent['name']}'s to load - it goes onto a machine they own, drive or "
                              "hold the keys to.")
        machines.check_load(L, m, {"name": item["name"], "props": p})
        return m
    if not (p.get("autosoft") or p.get("mount")):
        return None
    fits = []
    for m in theirs:
        try:
            machines.check_load(L, m, {"name": item["name"], "props": p})
            fits.append(m)
        except LedgerError:
            pass
    if len(fits) == 1:
        return fits[0]
    named = ", ".join(f"{m['name']} [{m['id']}]" for m in fits)
    raise LedgerError(f"{item['name']} goes onto a drone - " + (
        f"which one? onto: {named}" if fits
        else f"none of {ent['name']}'s has room for it" if theirs else f"{ent['name']} has none") + ".")


def _pending_essence(L, eid: str) -> float:
    """Essence already spoken for: chrome bought and still on its way (installed when it gets here)."""
    return sum(float(i["props"].get("essence", 0)) * int(i.get("qty", 1) or 1) for i in L.holdings(eid)
               if i["props"].get("install") and sr_lite.arriving(i))


def _install(L, ent: dict, item: dict, qty: int) -> str:
    """Cyberware goes in: Essence paid, Magic or Resonance lost for each point (rounded up), attribute chrome raised up
    to the natural maximum + 4. Returns the card's note."""
    note = ""
    ess = float(L.stat(ent["id"], "essence", 6.0))
    after = round(ess - item["ess"] * qty, 2)
    L.set_stat(ent["id"], "essence", after)
    for gift_key in ("magic", "resonance"):
        g = int(L.stat(ent["id"], gift_key, 0))
        lost = math.ceil(6.0 - after - 1e-9) - math.ceil(6.0 - ess - 1e-9)
        if g and lost > 0:
            L.set_stat(ent["id"], gift_key, max(0, g - lost))
            note += f" {gift_key.title()} {g} -> {max(0, g - lost)} (the chrome costs them)."
    for a, v in item.get("attrs", {}).items():
        cur = int(L.stat(ent["id"], a))
        L.set_stat(ent["id"], a, min(sr_lite.attr_cap(L, ent["id"], a) + AUG_MAX, cur + v * qty))
        note += f" {sr_lite.ABBR[a]} {cur} -> {int(L.stat(ent['id'], a))}."
    return note


def buy(game, buyer: str, ref: str, qty: int = 1, turn: int = 0, shop_id: str | None = None,
        onto: str | None = None) -> dict:
    """A runner buys from a shop open to them (where): the engine checks the stock and their nuyen, charges them and
    delivers - at once off the shelf, or in transit (a remote dealer's courier, a restricted item the dealer had to
    find): held, unusable until it arrives. onto: a drone or vehicle they own, drive or hold the keys to - a gun on a
    free mount, grenades aboard, a mount, an autosoft (machines.check_load). Nothing listed fails for its
    Availability: that was the dealer's search, when the shop was stocked."""
    L = game.ledger
    ent = L.require(buyer)
    holder, shop = where(game, ent["id"], shop_id)
    if not shop:
        raise LedgerError(f"{ent['name']} isn't anywhere that sells gear - find a shop, a fixer or a street doc.")
    key = _resolve(shop, ref)
    if not key:
        raise LedgerError(f"{shop['name']} doesn't sell '{ref}' - `!shop` shows what's on offer.")
    item, offer = CATALOG[key], shop["items"][key]
    qty = max(1, int(qty or 1))
    if qty > offer["stock"]:
        raise LedgerError(f"{shop['name']} only has {offer['stock']} {item['name']}.")
    total = offer["price"] * qty
    cash = int(L.stat(ent["id"], "nuyen"))
    if total > cash:
        raise LedgerError(f"{item['name']} costs {total:,}¥ - {ent['name']} has {cash:,}¥.")
    target = None if item.get("machine") or item.get("ess") else _onto(game, ent, item, onto)
    if target and qty > 1 and not (item.get("props") or {}).get("explosive"):
        raise LedgerError(f"One {item['name']} at a time onto {target['name']}.")
    hours = int(offer.get("hours") or 0)
    until = arrives(game, hours) if hours else None
    if item.get("ess"):
        after = round(float(L.stat(ent["id"], "essence", 6.0)) - _pending_essence(L, ent["id"]) - item["ess"] * qty, 2)
        if after < 0.5:
            raise LedgerError(f"Installing {item['name']} would drop {ent['name']}'s Essence to {after} - "
                              "the street doc won't risk it below 0.5.")
    L.set_stat(ent["id"], "nuyen", cash - total)
    transit = {"in_transit": {"until": until, "from": shop["name"]}} if until else {}
    note, made = "", []
    if item.get("machine"):
        for _ in range(qty):
            mid = machines.build_machine(L, f"{ent['name']}'s {item['name']}", item["machine"], ent["id"], turn,
                                         equipped=False)                 # the book's frame, nothing bundled (§7a)
            if transit:
                L.update_entity(mid, props={**L.require(mid)["props"], **transit})
            made.append(mid)
    else:
        props = dict(item.get("props", {}))
        if item.get("ess"):
            props.update(augmentation=True, essence=item["ess"])
            if item.get("effect") or item.get("attrs"):
                props["effect"] = item.get("effect") or ", ".join(f"+{v} {a.title()}" for a, v in item["attrs"].items())
            if transit:
                props["install"] = key                # (installed when it arrives: arrivals)
            else:
                note = _install(L, ent, item, qty)
        props.update(transit)
        if target:
            machines.settle_mounts(L, target, turn)
        iid = L.create_entity("item", f"{ent['name']}'s {item['name']}", item["name"], tier=0, props=props, turn=turn)
        cap = props.get("ammo_capacity")
        L.give((target or ent)["id"], iid, qty, {"loaded": cap} if cap else {})
        made.append(iid)
    if transit:
        _set_ids(game, TRANSIT, _ids(game, TRANSIT) + made)
    offer["stock"] -= qty
    if offer["stock"] <= 0:
        del shop["items"][key]
    L.update_entity(holder["id"], props={**L.require(holder["id"])["props"], "shop": shop})
    L.log(turn, "purchase", ent["id"], {"item": key, "qty": qty, "paid": total, "shop": holder["id"], "entities": made}
          | ({"until": until} if until else {}) | ({"onto": target["id"]} if target else {}))
    what = f"{qty}× {item['name']}" if qty > 1 else item["name"]
    tail = f" Straight onto {target['name']}." if target else ""
    if until:
        tail += (f" On its way from {shop['name']} - arrives {clock.ahead(until, game.clock())}"
                 + (" (installed then)" if item.get("ess") else "") + ".")
    return {"card": f"[SHOP] {ent['name']} buys {what} at {shop['name']} for {total:,}¥ "
                    f"({cash - total:,}¥ left).{note}{tail}", "item": key, "paid": total, "entities": made,
            "until": until}


def _recipient(L, ent: dict) -> dict | None:
    """Whose delivery this is: the one holding it (a drone's owner, for what's aboard their drone), or a machine's
    owner. None: nobody holds it any more."""
    if ent["kind"] in sr_lite.MACHINES:
        return L.get(ent["props"].get("owner") or "")
    holders = L.holders(ent["id"])
    h = L.get(holders[0]) if holders else None
    if h and h["kind"] in sr_lite.MACHINES:
        return L.get(h["props"].get("owner") or "") or h
    return h


def _install_refused(L, ent: dict | None, item: dict, qty: int) -> str | None:
    """Why chrome that's arrived can't go in, if it can't: it isn't in a person, or they're at the Essence floor -
    checked again now, against whoever holds it (buy checked the buyer; a runner back from another world's chrome has
    their Essence from there)."""
    if not ent or ent["kind"] not in ("pc", "npc"):
        return f"{(ent or {}).get('name', 'nobody')} isn't someone it can go into"
    after = round(float(L.stat(ent["id"], "essence", 6.0)) - item["ess"] * qty, 2)
    if after < 0.5:
        return f"it would drop {ent['name']}'s Essence to {after} - the street doc won't risk it below 0.5"
    return None


def arrivals(game, turn: int) -> list[str]:
    """What was bought for delivery and has arrived now the story clock has got there: it's usable from here on, and
    chrome is installed. (commit calls this after the turn's time has passed.) Returns the [SHOP] cards. A delivery
    for a runner who's left this world (character ledger: checked in) waits for them to come back, and one nobody
    holds any more is dropped without a card (review E2: a returned runner's gear was announced as it 'arrived' into
    no one's hands)."""
    L, now = game.ledger, game.clock()
    cards, waiting = [], []
    for eid in _ids(game, TRANSIT):
        ent = L.get(eid)
        t = sr_lite.arriving(ent)
        if not t:
            continue
        who = _recipient(L, ent)
        if who is None or (ent["kind"] in sr_lite.MACHINES and ent.get("status") != "active"):
            continue                                  # (nobody to bring it to: off the list, quietly)
        if int(t.get("until") or 0) > now or who.get("status") != "active":
            waiting.append(eid)
            continue
        note, key, done = "", ent["props"].get("install"), ("in_transit", "install")
        if key in CATALOG:
            body = L.get(L.holders(eid)[0])           # (it goes into whoever holds it - never a drone's owner)
            qty = next((i["qty"] for i in L.holdings(body["id"]) if i["id"] == eid), 1)
            why = _install_refused(L, body, CATALOG[key], qty)
            if why:                                   # (here, not in them: props.install stays, so in_hand skips it -
                done, note = ("in_transit",), f" Not installed: {why}."      # the GM's to sort out)
            else:
                note = " Installed:" + (_install(L, body, CATALOG[key], qty) or " done.")
        L.update_entity(eid, props={k: v for k, v in ent["props"].items() if k not in done})
        L.log(turn, "delivered", eid, {"from": t.get("from"), "until": t.get("until")})
        cards.append(f"[SHOP] {ent['name']} arrives" + (f" from {t['from']}" if t.get("from") else "") + f".{note}")
    _set_ids(game, TRANSIT, waiting)
    return cards


# ── what the table and the GM see ───────────────────────────────────────
def _offer_bits(game, key: str, offer: dict) -> str:
    """'Avail 10R · arrives in a few days' for one offer."""
    bits = [avail_text(CATALOG[key])]
    if offer.get("hours"):
        bits.append(f"arrives {when(game, offer['hours'])}")
    return " · ".join(b for b in bits if b)


def card(game, eid: str | None, shop_id: str | None = None) -> dict:
    """The shop open to a character (where), as a card."""
    found = shops_for(game, eid) if eid else []
    holder, shop = where(game, eid, shop_id) if eid else (None, None)
    if not shop:
        return {"title": "🛒 Nothing for sale here", "color": 0x95A5A6,
                "description": "Ask around in the story - a fixer, a gun shop, a pawnshop, a street doc, a "
                               "talismonger, an online dealer - and the GM will open their doors."}
    lines, cat = [], None
    for n, k in menu(shop):
        item, offer = CATALOG[k], shop["items"][k]
        if item["cat"] != cat:
            cat = item["cat"]
            lines.append(f"**{cat}**")
        extra = f" · Essence {item['ess']}" if item.get("ess") else ""
        bits = _offer_bits(game, k, offer)
        lines.append(f"`{n}` {item['name']} - **{offer['price']:,}¥**{extra}" + (f" · {bits}" if bits else "")
                     + (f"  ({offer['stock']} left)" if offer["stock"] > 1 else ""))
    cash = int(game.ledger.stat(eid, "nuyen"))
    how = (f"*{shop['kind']}* - {'remote: everything comes by courier' if shop.get('remote') else 'at ' + holder['name']}"
           + (" · a legal shop" if shop.get("legal") else ""))
    others = [s["name"] for h, s in found if h["id"] != holder["id"]]
    foot = (f"You have {cash:,}¥ · !buy <#> (or !buy <#> x2, !buy <#> onto <drone>) · or just tell the GM what you're "
            "buying" + (f" · also open: {', '.join(others)} (!shop <name>)" if others else ""))
    return {"title": f"🛒 {shop['name']}", "color": 0x2ECC71,
            "description": how + "\n\n" + "\n".join(lines)
                           + "\n\n-# Avail: R restricted, F forbidden - the dealer's search set when it comes.",
            "footer": foot}


def _transit_lines(game) -> list[str]:
    L = game.ledger
    out = []
    for eid in _ids(game, TRANSIT)[:8]:
        ent = L.get(eid)
        if ent and sr_lite.arriving(ent):
            whose = L.holders(eid)
            who = (L.get(whose[0]) or {}).get("name") if whose else (L.get(ent["props"].get("owner") or "") or {}).get("name")
            out.append(f"{ent['name']} [{eid}]" + (f" (for {who})" if who and who not in ent["name"] else "")
                       + f" - {sr_lite.transit_note(L, ent)}")
    return out


def packet_lines(game, location_id: str | None, scene_id: int | None = None) -> list[str]:
    """The GM's view: the shop here, the remote dealers listed in this scene, and what's on its way to the crew."""
    L = game.ledger
    out = []
    loc = L.get(location_id) if location_id else None
    shops = [(loc, loc["props"]["shop"])] if loc and loc["props"].get("shop") else []
    for hid in _ids(game, REMOTE):
        h = L.get(hid)
        s = (h or {}).get("props", {}).get("shop") or {}
        if (h and s.get("remote") and scene_id is not None and s.get("scene") == scene_id
                and h["id"] != (loc or {}).get("id")):
            shops.append((h, s))
    for h, shop in shops:
        items = "; ".join(f"{CATALOG[k]['name']} {v['price']}¥" + (f" x{v['stock']}" if v["stock"] > 1 else "")
                          + (f" ({_offer_bits(game, k, v)})" if _offer_bits(game, k, v) else "")
                          for k, v in shop["items"].items())
        head = ("SHOP ON THE LINE" if shop.get("remote") else "SHOP HERE")
        out += [f"\n=== {head}: {shop['name']} [{h['id']}] ({shop['kind']}, markup {shop['markup']}"
                + (", legal: no Forbidden gear" if shop.get("legal") else "")
                + (", remote: courier delivery" if shop.get("remote") else "") + ") ===",
                f"{items or '(sold out)'}"]
    if shops:
        out.append("Runners can see it with !shop and buy with !buy; when one buys in the fiction, call buy (shop_id "
                   "for a remote dealer from anywhere, onto_id to put it straight on their drone). Restock or change it "
                   "with open_shop. Availability is the dealer's search, already made: what's listed can be bought, "
                   "and what has to be delivered arrives when the story clock gets there.")
    moving = _transit_lines(game)
    if moving:
        out.append("\n=== ON THE WAY (bought, held, not usable until it arrives - narrate the courier then) ===")
        out += moving
    return out
