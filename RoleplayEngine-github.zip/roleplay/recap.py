"""The session recap (DESIGN.md §12d): "previously on", as a segment of a pirate trid show.

Three parts, all built from what the players' characters actually saw (public slices, scene summaries,
public facts, and the public side of the open tensions) - never GM notes, personas, offscreen moves or
secrets:
- the anchor's broadcast: the story so far in a news voice, in order, ending on the open question;
- where things stand: location, time, money, open threads the crew knows about;
- a dossier for each NPC the crew dealt with lately - laid out by dossier.py around their portrait.

It posts by itself when a new session begins (after the 3-hour gap) and on `!recap`.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from . import dossier
from .dm import tensions
from .engine import clock
from .engine.rules import sr_lite
from .dm.prompts import FICTION_NOTE

ANCHOR = {
    "name": "Sally Calloway",
    "show": "Shadow Beat",
    "outlet": "pirate trid broadcast out of the Ork Underground",
    "signoff": "Stay frosty, Seattle. This has been Sally Calloway, Shadow Beat.",
    "look": "a sharp-eyed woman in her forties with a silver undercut, a vintage microphone wired to a datajack, "
            "at a cluttered makeshift news desk in an underground studio, monitors and neon signage behind her",
}
WINDOW = 40            # public turns the recap reads (scene summaries cover the rest)
DOSSIERS = 4           # NPCs per recap
ROLE_WEIGHT = {"actor": 2.0, "target": 2.0, "present": 1.0, "mentioned": 0.3}

RECAP_SYSTEM = FICTION_NOTE + """ You write the "previously on" for a Shadowrun tabletop campaign played over Discord, for players \
coming back after days away. It's framed as a segment of {show}, a {outlet}, hosted by {name}, who covers the street \
stories the corp news won't touch. Use ONLY what you're given: these are events the players' characters lived \
through. Never invent events, names or outcomes, and never guess at secrets.

broadcast: {name}'s segment, 150-230 words, present tense, a punchy trid-news voice with a little street slang. Open \
with her sign-on ("This is {name}, {show}..."). Recount what happened in order, naming the crew and the people they \
dealt with, so a player who forgot everything knows where the story stands. End on the open question or threat, \
then her sign-off: "{signoff}"

standing: 3-6 short lines - where the crew is now and the story time, what they carry, owe or are owed, and the open \
threads they know about.

dossiers: one per person under PEOPLE, by id, from the crew's point of view:
""" + "{fields}"
DOSSIER_FIELDS = """- alias: a street name, or how the crew knows them if the name on file isn't a real name; else "".
- affiliation: who they work for or with, short ("Fixer, Tacoma"; "Ironwood Freight Holdings"; "Unknown").
- status: a rubber stamp, 1-2 words, uppercase: CONTACT, ALLY, CLIENT, HOSTILE, AT LARGE, WATCHING, MISSING, \
DECEASED, UNKNOWN... (for one of the crew: RUNNER)
- who: 1-3 sentences - who they are as far as the crew knows: role, look, manner.
- lately: 1-3 sentences - what went on between them and the crew recently, and where it stands (debts, deals, threats)."""

FILE_SYSTEM = FICTION_NOTE + """ You keep the crew's files in a Shadowrun tabletop campaign played over Discord. Write one \
subject dossier from the crew's point of view, using ONLY what you're given - what the player characters saw and \
learned. Never invent events, names or outcomes, and never guess at secrets: if the crew doesn't know, the file \
doesn't either.
""" + DOSSIER_FIELDS


def schema() -> dict:
    s = {"type": "string"}
    return {"type": "object", "properties": {
        "broadcast": s,
        "standing": {"type": "array", "items": s},
        "dossiers": {"type": "array", "items": {"type": "object", "properties": {
            "id": s, "alias": s, "affiliation": s, "status": s, "who": s, "lately": s},
            "required": ["id", "alias", "affiliation", "status", "who", "lately"], "additionalProperties": False}}},
        "required": ["broadcast", "standing", "dossiers"], "additionalProperties": False}


def anchor(game) -> dict:
    try:
        return {**ANCHOR, **json.loads(game.ledger.meta("anchor") or "{}")}
    except ValueError:
        return dict(ANCHOR)


def anchor_image(game) -> Path | None:
    """The anchor's portrait: painted once and shared by every campaign in the folder (her webhook avatar)."""
    p = game.ledger.meta("anchor_image")
    if p and Path(p).exists():
        return Path(p)
    a = anchor(game)
    path = game.path.parent / "anchor" / f"{re.sub(r'[^a-z0-9]+', '-', a['name'].lower()).strip('-')}.png"
    if path.exists():
        return path
    if not game.art.active:
        return None
    prompt = (f"Portrait of {a['name']}, host of {a['show']}, a {a['outlet']} in 2080s Shadowrun Seattle: "
              f"{a['look']}. Head and shoulders, looking into the camera, cinematic cyberpunk lighting. "
              f"{game.art.style}")
    try:
        data = game.art.provider.generate(prompt, "1024x1024")
    except Exception as exc:
        game.out(f"  (recap: no anchor portrait - {exc})")
        return None
    if not data:
        return None
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path


def gather(game) -> dict | None:
    """Everything the recap may use - the public record only."""
    L, S = game.ledger, game.sub
    rows = [dict(r) for r in game.conn.execute(
        "SELECT id, text, scene_id, created_turn, story_time FROM nodes WHERE kind='slice' AND visibility='public' "
        "ORDER BY created_turn DESC LIMIT ?", (WINDOW,))][::-1]
    if not rows:
        return None
    scene_ids = sorted({r["scene_id"] for r in rows if r["scene_id"]})
    scenes = [S.node(f"S{s}") for s in scene_ids]
    ids = [r["id"] for r in rows]
    score: dict[str, float] = {}
    for i, r in enumerate(rows):
        recency = 0.5 + i / len(rows)
        for m, role in S.members_of(r["id"]):
            ent = L.get(m)
            if ent and ent["kind"] == "npc" and ent["tier"] >= 1:
                score[m] = score.get(m, 0.0) + ROLE_WEIGHT.get(role, 0.0) * recency
    people = []
    for eid in sorted(score, key=lambda e: -score[e])[:DOSSIERS]:
        if score[eid] < 1.0:
            continue
        ent = L.get(eid)
        theirs = [r for r in rows if any(m == eid and role in ("actor", "target", "present")
                                         for m, role in S.members_of(r["id"]))]
        last = theirs[-1] if theirs else None
        where = ""
        if last and last["scene_id"]:
            loc = L.get((L.scene(last["scene_id"]) or {}).get("location_id") or "")
            where = loc["name"] if loc else ""
        when = clock.short(last["story_time"]) if last and last["story_time"] is not None else ""
        facts = [f["text"] for f in S.facts_for(eid, 6) if f.get("visibility", "public") == "public"][:4]
        people.append({"id": eid, "name": ent["name"], "description": ent["description"],
                       "condition": sr_lite.condition(L, eid), "facts": facts,
                       "moments": [r["text"] for r in theirs[-6:]],
                       "last_seen": "\n".join(x for x in (where, when) if x)})
    sc = L.current_scene()
    loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    crew = [f"{p['name']} ({p['props'].get('archetype', 'runner')}) - {sr_lite.condition_line(L, p['id'])}, "
            f"{int(L.stat(p['id'], 'nuyen')):,} nuyen" for p in L.entities(kind="pc")]
    return {"now": game.clock_line(), "where": loc["name"] if loc else "", "crew": crew,
            "scenes": [s["text"] for s in scenes if s], "turns": rows, "people": people,
            "threads": tensions.public_lines(game), "ids": ids}


def _user(g: dict) -> str:
    parts = [f"STORY TIME NOW: {g['now']}" + (f" · the crew is at {g['where']}" if g["where"] else ""),
             "THE CREW:\n" + "\n".join(f"- {c}" for c in g["crew"]),
             "SCENES (oldest first):\n" + "\n".join(f"- {s}" for s in g["scenes"]),
             "TURNS (oldest first):\n" + "\n".join(
                 f"- ({clock.short(r['story_time']) if r['story_time'] is not None else 'T' + str(r['created_turn'])}) "
                 f"{r['text']}" for r in g["turns"])]
    if g["threads"]:
        parts.append("OPEN THREADS THE CREW KNOWS ABOUT:\n" + "\n".join(f"- {t}" for t in g["threads"]))
    if g["people"]:
        parts.append("PEOPLE (write a dossier for each, by id):\n" + "\n".join(
            f"[{p['id']}] {p['name']} - {p['description']} (condition: {p['condition']})"
            + "".join(f"\n  fact: {f}" for f in p["facts"])
            + "".join(f"\n  with the crew: {m}" for m in p["moments"]) for p in g["people"]))
    return "\n\n".join(parts)


def _alias(d: dict, name: str) -> str:
    """'Known as' only when it says something the name doesn't (Haiku likes to repeat the name)."""
    alias = (d.get("alias") or "").strip()
    return "" if alias.lower() in ("", name.lower()) else alias


def file_no(game, eid: str) -> str:
    return f"{game.path.stem[:2].upper()}-{int(hashlib.sha1(eid.encode()).hexdigest()[:6], 16) % 10000:04d}"


def build(game) -> dict | None:
    """The whole package: anchor, broadcast, standing lines, and rendered dossiers. None if nothing happened yet."""
    g = gather(game)
    if g is None:
        return None
    a = anchor(game)
    data = game.llm.structured(game.settings.models.dm, RECAP_SYSTEM.format(**a, fields=DOSSIER_FIELDS), _user(g),
                               schema(), max_tokens=6000, effort="low", fallback=game.settings.models.commit,
                               purpose="recap")
    from .dm import spoilers                         # (the table reads it: never a name it hasn't learned - §12l)
    say = lambda s: spoilers.answer(game, str(s or ""), "The recap", game.turn_no())        # noqa: E731
    data = {**data, "broadcast": say(data.get("broadcast")), "standing": [say(s) for s in data.get("standing", [])],
            "dossiers": [{k: say(v) if k != "id" else v for k, v in d.items()} for d in data.get("dossiers", [])]}
    by_id = {p["id"]: p for p in g["people"]}
    out_dir = game.path.parent / "dossiers"
    files = []
    for d in data.get("dossiers", []):
        p = by_id.get(d.get("id", ""))
        if not p:
            continue
        art = game.art.latest(game.conn, p["id"], ready_only=True)
        card = {"name": p["name"], "alias": _alias(d, p["name"]), "affiliation": d.get("affiliation", ""),
                "last_seen": p["last_seen"], "status": d.get("status", ""), "who": d.get("who", ""),
                "lately": d.get("lately", "")}
        path = dossier.render(card, Path(art["path"]) if art else None,
                              out_dir / f"{game.path.stem}_{p['id']}.png", file_no(game, p["id"]),
                              f"Compiled {clock.short(game.clock())}")
        files.append(card | {"id": p["id"], "image": str(path)})
    return {"anchor": a, "anchor_image": anchor_image(game), "broadcast": data.get("broadcast", "").strip(),
            "standing": [s for s in data.get("standing", []) if s.strip()], "dossiers": files}


def previous_session_turns(game) -> int:
    """Public turns in the session before this one (a new session recaps only after real play)."""
    s = game.ledger.session() - 1
    return game.conn.execute("SELECT COUNT(*) FROM turns WHERE status='committed' AND session=? AND private IS NULL",
                             (s,)).fetchone()[0]


# ── one file, on demand (`!dossier <name>`) ─────────────────────────────
PERSON = {"type": "object", "properties": {k: {"type": "string"} for k in
                                          ("alias", "affiliation", "status", "who", "lately")},
          "required": ["alias", "affiliation", "status", "who", "lately"], "additionalProperties": False}
FILE_KINDS = ("npc", "pc", "faction")


def subject(game, eid: str) -> dict | None:
    """One person (or outfit) as the crew knows them - the public record only: the public moments they were part of,
    the public facts about them, how they look. None if the crew has never crossed paths with them."""
    L, S = game.ledger, game.sub
    ent = L.get(eid)
    if not ent or ent["kind"] not in FILE_KINDS:
        return None
    rows = [dict(r) for r in game.conn.execute(
        "SELECT n.id, n.text, n.scene_id, n.created_turn, n.story_time, m.role FROM nodes n JOIN members m "
        "ON m.slice_id=n.id WHERE n.kind='slice' AND n.visibility='public' AND m.node_id=? AND m.role<>'recalled' "
        "ORDER BY n.created_turn", (eid,))]
    facts = [f["text"] for f in S.facts_for(eid, 6) if f.get("visibility", "public") == "public"][:4]
    if not rows and not facts:
        return None
    seen = [r for r in rows if r["role"] in ("actor", "target", "present")]
    last = seen[-1] if seen else None
    where = ""
    if last and last["scene_id"]:
        loc = L.get((L.scene(last["scene_id"]) or {}).get("location_id") or "")
        where = loc["name"] if loc else ""
    when = clock.short(last["story_time"]) if last and last["story_time"] is not None else ""
    p = ent["props"]
    art = game.art.latest(game.conn, eid, ready_only=True)
    condition = sr_lite.condition(L, eid) if ent["kind"] != "faction" else "-"
    return {"id": eid, "name": ent["name"], "kind": ent["kind"], "description": ent["description"],
            "role": (p.get("archetype") or p.get("template") or "").replace("_", " "), "condition": condition,
            "facts": facts, "moments": [r["text"] for r in rows[-8:]],
            "last_seen": "\n".join(x for x in (where, when) if x), "portrait": art["path"] if art else None,
            "key": "|".join(map(str, (ent["name"], rows[-1]["id"] if rows else "", len(facts), condition,
                                      art["version"] if art else 0)))}


def known_people(game, limit: int = 60) -> list[str]:
    """Everyone the crew has a file on, the most recently seen first (for the list and slash autocomplete)."""
    rows = game.conn.execute(
        "SELECT m.node_id, MAX(n.created_turn) AS t FROM members m JOIN nodes n ON n.id=m.slice_id "
        "JOIN entities e ON e.id=m.node_id WHERE n.kind='slice' AND n.visibility='public' AND m.role<>'recalled' "
        f"AND e.kind IN ({','.join('?' * len(FILE_KINDS))}) AND e.tier>=1 GROUP BY m.node_id ORDER BY t DESC LIMIT ?",
        (*FILE_KINDS, limit)).fetchall()
    return [game.ledger.get(r["node_id"])["name"] for r in rows]


def file_on(game, eid: str) -> dict | None:
    """The crew's file on someone, for the table: Haiku writes it from the public record, dossier.py draws it around
    their portrait. Kept until something new happens with them (a new public moment or fact, their condition, a new
    portrait), so asking again is instant and free. None if the crew has no file on them."""
    p = subject(game, eid)
    if p is None:
        return None
    out = game.path.parent / "dossiers" / f"{game.path.stem}_{eid}_file.png"
    try:
        kept = json.loads(game.ledger.meta(f"dossier:{eid}") or "{}")
    except ValueError:
        kept = {}
    if kept.get("key") == p["key"] and kept.get("card") and out.exists():
        return kept["card"] | {"image": str(out)}
    crew = ", ".join(e["name"] for e in game.ledger.entities(kind="pc")) or "(none)"
    user = (f"STORY TIME NOW: {game.clock_line()}\nTHE CREW: {crew}\n\n"
            f"SUBJECT [{eid}]: {p['name']} ({p['kind']}{', ' + p['role'] if p['role'] else ''}) - {p['description']}"
            f" (condition: {p['condition']})"
            + "".join(f"\n  fact: {f}" for f in p["facts"])
            + ("\n\nWHAT THE CREW SAW AND HEARD OF THEM (oldest first):\n" + "\n".join(f"- {m}" for m in p["moments"])
               if p["moments"] else ""))
    d = game.llm.structured(game.settings.models.commit, FILE_SYSTEM, user, PERSON, max_tokens=1500, effort="low",
                            purpose="dossier")
    from .dm import spoilers                         # (the table reads it, as the recap's own dossiers: §12l)
    say = lambda s: spoilers.answer(game, str(s or ""), "!dossier's file", game.turn_no())        # noqa: E731
    card = {"name": p["name"], "alias": say(_alias(d, p["name"])), "affiliation": say(d.get("affiliation", "")),
            "last_seen": p["last_seen"], "status": say(d.get("status", "")), "who": say(d.get("who", "")),
            "lately": say(d.get("lately", ""))}
    dossier.render(card, Path(p["portrait"]) if p["portrait"] else None, out, file_no(game, eid),
                   f"Compiled {clock.short(game.clock())}")
    game.ledger.set_meta(f"dossier:{eid}", json.dumps({"key": p["key"], "card": card}))
    return card | {"image": str(out)}
