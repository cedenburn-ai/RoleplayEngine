"""RoleplayEngine: an AI game master whose world remembers (see DESIGN.md)."""
