"""A new party in the same world (DESIGN.md §7i, built 2026-10-27): the owner's `!rp newparty [3 weeks]`.

The owner, after the first story: "I want to leave the world, that shit is awesome." `!rp restart` boxes the whole world
up; this keeps the world and changes the crew, in this order:
  1. a backup first - the campaign file and the character ledger, side by side (backups/newparty/<world>-<stamp>/)
  2. the scene closes the way a scene closes - while the crew are still the crew, so the NPCs settle their views of
     them: the dying left alone die, minds reflect, the notebook folds, word gets around, a summary - and a new one
     opens for the new chapter
  3. the old crew become the GM's characters. Their progress and a backstory go home to the character ledger, which
     lets them go (back on the shelf for other worlds; never into this one again - check_out turns the name away
     here), but they stay in this world with everything: sheet, gear, drones, money, history, links, what everyone
     thinks of them. One cheap read each (the world model) gives them a mind like the world's NPCs have: a persona,
     a view of the people they actually dealt with - from what they witnessed and heard (the witness scope,
     dm/witness.py), never the GM's notes - a goal that follows from where their story left them, somewhere to be,
     and an epilogue the table can read. They're offscreen actors now, and the world moves them.
  4. the story skips ahead and the world catches up: a few offscreen passes spread across the gap (never one an hour),
     with bigger budgets than a turn's. Then what the clock's rules already do with time: wounds mend, deliveries
     land, held spells drop, strong feelings cool. Deadlines that fall in the gap are the world's - a due tension
     fires on the next turn, as it would after any skip; agendas come due and the passes move them.
  5. a new session, a note for the GM on each of them, the canon told, and the new crew's session zero: `!newchar`
     or `!characterledger checkout <runner>`, then `!begin` - the GM's opening, as a new campaign's.
A reset isn't a turn. !undo can't reach back across it (the undo snapshots from before it move into the backup), and
`!rp newparty undo` puts the backup back - until the new crew's first turn (after that, !undo back to it first).
The graph log (graphlog/) carries on: the turn numbers keep going, the reset's touches ride into the next turn's file
as 'between', and a mark (process.marks, marks.jsonl) says the crew changed and the clock jumped.
A reset the bot dies in the middle of (a force-stop mid-catch-up: no except runs) is found when the world next opens -
its record goes in as 'running' before the first change - and put back from the backup the way a failed one is
(recover). The ledger rows go back only while they're as the reset left them: a runner another world has taken since
is that world's (review 2026-10-27).
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from . import charledger, db
from .dm import world
from .dm.llm import fan_out
from .dm.prompts import FICTION_NOTE
from .dm.witness import Scope
from .engine import clock, geo
from .engine.ledger import LedgerError
from .engine.rules import magic, sr_lite

KEY = "newparty"                          # meta: every new party this world has had, newest last (JSON list)
DEFAULT_GAP, DEFAULT_LABEL = 21 * clock.DAY, "three weeks"
MIN_GAP, MAX_GAP = clock.DAY, 365 * clock.DAY
PASS_EVERY = 5 * clock.DAY                # one offscreen pass for each stretch this long of the gap...
MAX_PASSES = 4                            # ...never more: a month or a year, the world catches up in four
CATCHUP_AGENTS, CATCHUP_PERSONAS = 6, 3   # per catch-up pass (a turn's pass is 3 and 2): the old crew and whoever's due
PEOPLE_MAX = 12                           # the people an old PC gets a view of: the ones they shared most moments with
LATELY = 30                               # their last moments, in their read
SCENES_MAX = 24                           # the scenes they were in, summarised (the oldest drop first)
HEARD_MAX = 8
CONFIRM_SECONDS = 120                     # the owner's ✅ waits this long (as !rp restart's)
CARD_MAX = 4000                           # the table's card: under Discord's 4,096 for an embed
RUNNING = "running"                       # a record's status while its reset is under way (done records have none)
RUNNING_STALE = 30 * 60                   # a reset 'running' this long is dead whatever its pid says (one takes minutes)
_IN_FLIGHT: set[str] = set()              # the worlds this process is resetting right now (run's try/finally)
PICTURE_OLD_MAX = 700                     # their picture as a PC, kept in the new one as history (clipped)
CANON_GAP_MAX = 40                        # the gap's offscreen moments the canon read-back is shown (the oldest drop)
FALLBACK_GOAL = "make a living on their own now that the crew has gone its separate ways"
# The world's agents read "the player characters are at <the scene>". During the catch-up there are none - the old
# crew split up and the new one isn't together - so the chapter's scene says so while the passes run.
CATCHUP_WHERE = "no scene - the old crew has split up and the new crew hasn't come together yet"
NUMBER_WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine",
                10: "ten", 11: "eleven", 12: "twelve"}

MIND_SYSTEM = FICTION_NOTE + """ A player character in a long Shadowrun tabletop campaign is leaving the players' \
hands: their player is starting a new character, and this one stays in the world as an NPC the game master plays - \
with their whole history. You get who they are (as their player built and played them), what they lived through (the \
moments they witnessed, what they heard second-hand) and the people they dealt with. Write who they are from here on.
- persona: their character bible, like any NPC the GM plays - true to how their player built and played them (the \
concept, the temperament, the voice), never contradicting the record. One short sentence per field (under 25 words), \
third person, present tense; at most two loose threads in hooks. affiliations: organizations they CURRENTLY belong to \
- usually none (a runner works for themselves).
- beliefs: how they feel about the people listed - only from what they witnessed or heard, since they know nothing \
else. attitude runs from -3 (would hurt them) through 0 to +3 (would take a bullet for them); belief is one or two \
sentences in their frame of mind, third person, the holder by name ("<their name> thinks <the person> ..." - never \
"<the person> thinks"). Use the ids in brackets; skip anyone who left no mark on them.
- goal: what they chase now the crew has gone its separate ways, following from where their story left them - debts, \
promises, people they care about, money, enemies. One concrete goal a person would pursue for weeks; targets = the \
ids of the people, places or organizations it's about.
- whereabouts: where they go when the crew splits up. where = a short phrase; place = the id of a place they know or \
one of the districts (or "").
- epilogue: one sentence the players will read, past tense, naming them: what became of them as the crew went its \
separate ways. Nothing secret - no plans, no hidden motives."""


def mind_schema() -> dict:
    s, i = {"type": "string"}, {"type": "integer"}
    belief = {"type": "object", "properties": {"about": s, "attitude": i, "belief": s},
              "required": ["about", "attitude", "belief"], "additionalProperties": False}
    goal = {"type": "object", "properties": {"goal": s, "targets": {"type": "array", "items": s}},
            "required": ["goal", "targets"], "additionalProperties": False}
    where = {"type": "object", "properties": {"where": s, "place": s}, "required": ["where", "place"],
             "additionalProperties": False}
    props = {"persona": world.persona_schema(), "beliefs": {"type": "array", "items": belief}, "goal": goal,
             "whereabouts": where, "epilogue": s}
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


# ── the record ──────────────────────────────────────────────────────────
def records(game) -> list[dict]:
    """Every new party this world has had (a reset under way last, as 'running')."""
    try:
        return json.loads(game.ledger.meta(KEY) or "[]")
    except ValueError:
        return []


def last(game) -> dict | None:
    """The newest new party that went through (one under way, or that died part-way, isn't a chapter)."""
    r = [x for x in records(game) if x.get("status") != RUNNING]
    return r[-1] if r else None


def running(game) -> dict | None:
    """A reset under way - or one that died part-way (the record goes in before the first change and becomes the
    chapter's at the end; recover puts a dead one back)."""
    r = records(game)
    return r[-1] if r and r[-1].get("status") == RUNNING else None


def _flight(game) -> str:
    return str(game.path.resolve())


def _alive(game, rec: dict) -> bool:
    """Is that reset still going? This process knows its own (_IN_FLIGHT: the game thread runs one thing at a time, so
    a record of ours it isn't running died); another process's, by its pid - and none runs for half an hour."""
    if rec.get("pid") == os.getpid():
        return _flight(game) in _IN_FLIGHT
    if time.time() - float(rec.get("at") or 0) > RUNNING_STALE:
        return False
    return _pid_alive(int(rec.get("pid") or 0))


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":                               # (os.kill on Windows terminates: ask the kernel instead)
        import ctypes
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        h = k.OpenProcess(0x1000, False, pid)         # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ctypes.get_last_error() == 5       # (access denied: it's there, not ours to look at)
        try:
            code = ctypes.c_ulong()
            return bool(k.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259   # STILL_ACTIVE
        finally:
            k.CloseHandle(h)
    try:
        os.kill(pid, 0)
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def pending(game) -> dict | None:
    """The newest new party, while the new crew hasn't played its first turn (their session zero); else None."""
    rec = last(game)
    if not rec:
        return None
    played = game.conn.execute("SELECT 1 FROM turns WHERE status='committed' AND id>? LIMIT 1",
                               (int(rec["turn"]),)).fetchone()
    return None if played else rec


def chapter_turn(game) -> int:
    """The turn the current chapter starts after (0: the world's first). The table's 'has the story started?'"""
    rec = last(game)
    return int(rec["turn"]) if rec else 0


def default_root() -> Path:
    from .backup import backup_dir
    return backup_dir() / "newparty"


def in_words(label: str) -> str:
    """'3 weeks' -> 'three weeks'."""
    head, _, rest = label.partition(" ")
    if head.isdigit() and int(head) in NUMBER_WORDS:
        head = NUMBER_WORDS[int(head)]
    return f"{head} {rest}".strip()


def title(label: str) -> str:
    """'three weeks' -> 'Three weeks later' (the chapter's scene, the card)."""
    w = in_words(label)
    return f"{w[:1].upper()}{w[1:]} later"


def parse_gap(text: str | None) -> tuple[int, str]:
    """'3 weeks', 'a month', 'ten days', 'six months later' -> (story minutes, the words). Empty: three weeks."""
    s = " ".join((text or "").lower().replace("later", " ").split()).strip(" ,.")
    if not s:
        return DEFAULT_GAP, DEFAULT_LABEL
    try:
        minutes = clock.parse(f"{s} later", 0)
    except ValueError:
        raise LedgerError(f"How long does the story skip? `!rp newparty 3 weeks` (a day to a year) - "
                          f"'{(text or '').strip()}' doesn't read as a stretch of time.") from None
    if not MIN_GAP <= minutes <= MAX_GAP:
        raise LedgerError("A new party skips between a day and a year - `!rp newparty 3 weeks`.")
    return minutes, s


def split_request(text: str | None) -> tuple[str, str]:
    """'3 weeks | the crew slipped out the back before Lim's convoy pulled up' -> (the gap's words, how it ended)."""
    gap, _, ending = (text or "").partition("|")
    return gap.strip(), " ".join(ending.split())


def passes_for(gap: int) -> int:
    return max(1, min(MAX_PASSES, math.ceil(gap / PASS_EVERY)))


def crew(game) -> list[dict]:
    """The crew that's leaving: every player character still in the story."""
    return game.ledger.entities(kind="pc")


def refusal(game) -> str | None:
    """Why a new party can't happen right now (None: it can)."""
    from . import encounters
    run_ = running(game)
    if run_:
        return ("A new party is under way right now - once it's done, ask again." if _alive(game, run_) else
                f"A new party (after T{run_['turn']}) died part-way - `!rp newparty undo` puts its backup back first.")
    if game.ledger.current_scene() is None:
        return "There's no story here yet - `!rp start <world>` and play it first."
    if game.turn_no() == 0:
        return "Nothing's been played yet - the crew can just `!begin`."
    if encounters.active(game):
        return "A fight is on - finish it first: a new party starts between scenes."
    rec = pending(game)
    if rec:
        return (f"The last new party (after T{rec['turn']}) hasn't opened yet - `!begin` with the new crew, or "
                "`!rp newparty undo` takes it back.")
    return None


def preview(game, gap: int = DEFAULT_GAP, label: str = DEFAULT_LABEL, ending: str = "") -> dict:
    """What a new party would do (reads only) - for the owner's confirm. Raises LedgerError if it can't happen."""
    why = refusal(game)
    if why:
        raise LedgerError(why)
    L = game.ledger
    scene = L.current_scene()
    old = crew(game)
    k = passes_for(gap)
    npcs = [e for e in (L.get(x) for x in L.roster(scene["id"])) if e and e["kind"] == "npc" and e["tier"] >= 1]
    calls = 2 * len(old) + len(npcs) + 2 + k * (CATCHUP_AGENTS + CATCHUP_PERSONAS)
    return {"campaign": game.path.stem, "crew": [p["name"] for p in old], "gap": gap, "label": label,
            "title": title(label), "clock_from": game.clock(), "clock_to": game.clock() + gap, "passes": k,
            "calls": calls, "scene": scene["title"], "session": L.session() + 1, "turn": game.turn_no(),
            "backup": str(default_root()), "ending": ending}


def confirm_text(plan: dict) -> str:
    names = ", ".join(f"**{n}**" for n in plan["crew"])
    ending = (f"**How it ended:** {plan['ending']} - everyone who was there remembers it.\n" if plan.get("ending") else
              "-# How did the old story end? Add it after a `|` (`!rp newparty 3 weeks | the crew slipped out the back "
              "before the convoy pulled up`) and everyone who was there remembers it - else the scene just closes.\n")
    return ((f"{names} become the GM's characters - they keep everything (sheet, gear, drones, money, history, who "
             "they know), get a mind and a goal of their own, and the world moves them. Their progress and a "
             "backstory go home to the character ledger, which lets them go: back on the shelf for other worlds "
             "(not this one - they live here now).\n" if plan["crew"] else
             "Nobody's playing a runner here, so no one changes hands.\n")
            + f"**The story skips {in_words(plan['label'])}:** {clock.fmt(plan['clock_from'])} → "
              f"{clock.fmt(plan['clock_to'])}. The scene \"{plan['scene']}\" closes and the offscreen world catches up "
              f"in {plan['passes']} pass{'es' * (plan['passes'] != 1)}.\n"
            + ending
            + f"**Session {plan['session']}** for the new crew: `!newchar` or `!characterledger checkout <runner>`, "
              "then `!begin`.\n"
            + f"A backup of the world and the character ledger goes to `{plan['backup']}` first; `!rp newparty undo` "
              f"puts it back until the new crew's first turn. Up to ~{plan['calls']} quick model calls (Haiku, a few "
              "cents), then one canon read-back. The table pauses a minute or two.")


# ── the backup ──────────────────────────────────────────────────────────
RESTORE_TEXT = """A new party in {campaign}, {when}: the world and the character ledger as they were just before it.

The way back, from Discord (the owner): `!rp newparty undo` - it restores {campaign}.db from here and puts the old
crew's rows back in the character ledger. It works until the new crew plays its first turn; after that, `!undo`
(owner) back to the start of the new chapter first.
By hand: stop the bot, copy {campaign}.db over campaigns/{campaign}.db (delete its -wal and -shm files first). The
character ledger copy here is the whole shelf at that moment - copying it back would also undo what other worlds
saved since, so put back only the rows of: {crew}.
undo/ holds the !undo snapshots from before the new party (!undo can't reach back across it).
"""


def backup(game, folder: Path, crew_names: list[str]) -> Path:
    """The campaign file and the character ledger, copied with SQLite's backup API (consistent mid-session)."""
    folder.mkdir(parents=True, exist_ok=True)
    db.snapshot(game.conn, folder / game.path.name)
    src = charledger.path(game)
    if src.exists():
        a, b = sqlite3.connect(str(src), timeout=30), sqlite3.connect(str(folder / src.name))
        try:
            a.backup(b)
        finally:
            a.close()
            b.close()
    (folder / "README.txt").write_text(RESTORE_TEXT.format(campaign=game.path.stem, when=time.strftime("%Y-%m-%d %H:%M"),
                                                          crew=", ".join(crew_names) or "(nobody)"), encoding="utf-8")
    return folder


def _usage(game) -> tuple[int, float]:
    u = getattr(game.llm, "usage", None)
    return int(getattr(u, "calls", 0) or 0), float(getattr(u, "total", 0.0) or 0.0)


# ── the reset ───────────────────────────────────────────────────────────
def run(game, gap: int = DEFAULT_GAP, label: str = DEFAULT_LABEL, backup_root: Path | str | None = None,
        passes: int | None = None, ending: str = "") -> dict:
    """The whole new party (the module docstring), on the game thread. `ending`: the owner's word on how the old
    story ended - a moment everyone still in the scene witnessed, before it closes. Returns the record plus what
    happened (for the owner's summary). Anything going wrong puts the backup back: the world and the ledger as they
    were."""
    why = refusal(game)
    if why:
        raise LedgerError(why)
    old = crew(game)
    folder = backup(game, Path(backup_root or default_root()) / f"{game.path.stem}-{time.strftime('%Y%m%d-%H%M%S')}",
                    [p["name"] for p in old])
    rows = charledger.raw_rows(game, [p["props"].get("ledger") for p in old])
    rec_ = game.sub.recorder
    cp = rec_.checkpoint() if rec_ is not None else None
    seq0 = game.conn.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]   # (the reset's lines: after)
    from .graphlog import minds as graph_minds        # (and its rows: the catch-up's goals, hooks, hearsay, newcomers
    rows0 = graph_minds.watermark(game.conn)           # write no line - above this, they're the reset's)
    calls0, cost0 = _usage(game)
    # Before the first change (review 2026-10-27: a force-stop mid-catch-up ran no rollback, left the crew NPCs and
    # the ledger letting them go with no record of it - and !undo put a pre-reset snapshot over that): the record,
    # as running - recover() finds it if this never finishes - and the !undo snapshots, into the backup.
    run_rec = {"status": RUNNING, "turn": game.turn_no(), "at": time.time(), "pid": os.getpid(), "backup": str(folder),
               "gap": gap, "label": label, "clock_from": game.clock(), "graph_buffer": list(cp) if cp else None,
               "old_crew": [{"id": p["id"], "name": p["name"], "ledger": p["props"].get("ledger")} for p in old],
               "let": {}}
    _IN_FLIGHT.add(_flight(game))
    try:
        try:
            _save(game, run_rec)
            _park_undo(game, folder)
            res = _reset(game, old, gap, label, folder, passes, " ".join((ending or "").split()), run_rec)
            res["record"].update(graph_buffer=list(cp) if cp else None, let=run_rec["let"])
            _save(game, res["record"])                 # (done: the running record becomes the chapter's)
        except BaseException:
            _rollback(game, folder, rows, cp, run_rec["let"])
            raise
    finally:
        _IN_FLIGHT.discard(_flight(game))
    if rec_ is not None:
        rec_.mark({"kind": "new-party", "turn": res["record"]["turn"], "story_time_from": res["record"]["clock_from"],
                   "story_time_to": res["record"]["clock_to"], "gap_minutes": gap,
                   "former_pcs": [o["id"] for o in res["record"]["old_crew"]],
                   "scene_closed": res["record"]["scene_closed"], "scene_opened": res["record"]["scene_opened"],
                   "session": res["record"]["session"], "passes": len(res["record"]["passes"]), "events_after": seq0,
                   "rows_after": rows0})
    calls, cost = _usage(game)
    res.update(calls=calls - calls0, cost=cost - cost0)
    return res


def _save(game, rec: dict) -> None:
    """Add the record - in place of the running one, if that's the newest (the reset under way: progress, or done)."""
    r = records(game)
    if r and r[-1].get("status") == RUNNING:
        r = r[:-1]
    game.ledger.set_meta(KEY, json.dumps(r + [rec]))


def _park_undo(game, folder: Path) -> None:
    """!undo can't reach back across a new party: its snapshots move into the backup before the first change (left
    behind, !undo would put a world from before the reset over a half-reset one, the ledger already letting go)."""
    snaps = sorted(game.undo_dir.glob("before_*.db")) if game.undo_dir.exists() else []
    if not snaps:
        return
    try:
        (folder / "undo").mkdir(exist_ok=True)
        for p in snaps:
            shutil.move(str(p), str(folder / "undo" / p.name))
    except OSError as exc:
        game.wipe_undo()
        game.out(f"  (new party: the undo snapshots couldn't move into the backup ({exc}) - cleared instead)")


def _unpark_undo(game, folder: Path) -> None:
    """The !undo snapshots back where !undo finds them (the new party taken back, rolled back or put back)."""
    if (folder / "undo").exists():
        game.undo_dir.mkdir(parents=True, exist_ok=True)
        for p in sorted((folder / "undo").glob("before_*.db")):
            shutil.move(str(p), str(game.undo_dir / p.name))


# ── the old crew's ledger rows: back only while nobody has taken them ─────
def _fingerprint(row: dict | None) -> str | None:
    """A ledger row (as stored) by what matters to the way back: the sheet, the backstory, the checkout."""
    if not row:
        return None
    return hashlib.blake2b(json.dumps([row.get("data"), row.get("backstory"), row.get("campaign"),
                                       row.get("entity_id")]).encode("utf-8"), digest_size=8).hexdigest()


def _left(rec: dict) -> dict[str, str | None]:
    """The old crew's ledger rows the reset wrote: {slug: how it left them} (None: let_go began, never finished)."""
    if isinstance(rec.get("let"), dict):
        return dict(rec["let"])
    return {o["ledger"]: None for o in rec.get("old_crew") or [] if o.get("ledger")}


def _as_left(game, row: dict | None, fp: str | None) -> bool:
    """Is a live ledger row still as the reset left it? (Without a fingerprint: still on the shelf, or here.)"""
    if not row:
        return False
    return _fingerprint(row) == fp if fp else row["campaign"] in (None, game.path.stem)


def _taken(game, rec: dict) -> list[dict]:
    """The old crew the ledger has let another world check out since the reset (their rows as they stand)."""
    left = _left(rec)
    return [r for r in charledger.raw_rows(game, list(left))
            if r["campaign"] not in (None, game.path.stem) and not _as_left(game, r, left[r["slug"]])]


def _backup_ledger(folder: Path, name: str) -> dict[str, dict]:
    """The backup's copy of the character ledger, read-only: {slug: the row as stored} ({} without one)."""
    copy = folder / name
    if not copy.exists():
        return {}
    c = sqlite3.connect(f"file:{copy.as_posix()}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    try:
        return {r["slug"]: dict(r) for r in c.execute("SELECT * FROM runners")}
    except sqlite3.Error:
        return {}
    finally:
        c.close()


def _put_back(game, rows: list[dict], left: dict[str, str | None]) -> tuple[list[dict], list[dict]]:
    """The old crew's rows from before the reset, back - each one the reset wrote and nobody has touched since.
    Returns (put back, moved on: the live rows left as the ledger has them). A runner the shelf let go is another
    world's to take: written back blind, one checked out elsewhere was booked in two worlds and that world's synced
    progress was lost (review 2026-10-27)."""
    live = {r["slug"]: r for r in charledger.raw_rows(game, [r["slug"] for r in rows])}
    back, moved = [], []
    for r in rows:
        if r["slug"] not in left or r["slug"] not in live:
            continue                                  # (the reset never wrote it)
        if _as_left(game, live[r["slug"]], left[r["slug"]]):
            back.append(r)
        else:
            moved.append(live[r["slug"]])
    charledger.put_rows(game, back)
    return back, moved


def _rollback(game, folder: Path, rows: list[dict], cp, left: dict | None = None) -> list[dict]:
    """A reset that failed half way, or died part-way (recover): the world from the backup (it predates the running
    record, so that goes too), the old crew's ledger rows as they were - the ones nobody took meanwhile - the !undo
    snapshots and the graph buffer. Returns the rows that had moved on (left alone)."""
    moved = []
    try:
        db.restore(game.conn, folder / game.path.name)
        _, moved = _put_back(game, rows, left or {})
        for r in moved:
            game.out(f"  (new party rolled back: {r['name']}'s ledger row moved on meanwhile (checked out to "
                     f"{r['campaign'] or 'nobody'}) - left as the ledger has it)")
        _unpark_undo(game, folder)
        if game.sub.recorder is not None:
            game.sub.recorder.rewind(cp)
            game.sub.recorder.prev = None
    except Exception as exc:                      # (the backup and its README are the way back by hand)
        game.out(f"  (new party: couldn't roll back by itself - {exc}; the backup is in {folder})")
    return moved


def recover(game) -> dict | None:
    """Game.__init__: a reset that died part-way - the bot force-stopped mid-catch-up, a crash, a power cut; no except
    ran, so nothing rolled back - is put back from its backup as a failed one is. Returns that record, or None (none
    there, or still running in another process). Never stops a world opening."""
    try:
        rec = running(game)
        if not rec or _alive(game, rec):
            return None
        folder = Path(rec["backup"])
        if not (folder / game.path.name).exists():
            game.out(f"  (new party: the reset after T{rec['turn']} died part-way and its backup isn't there any more "
                     f"({folder}) - put the world back by hand)")
            return None
        left = _left(rec)
        rows = [r for s, r in _backup_ledger(folder, charledger.path(game).name).items() if s in left]
        moved = _rollback(game, folder, rows, rec.get("graph_buffer"), left)
        rec["moved_on"] = [r["name"] for r in moved]
        game.out(f"  (new party: the reset after T{rec['turn']} died part-way - the world is put back from {folder})")
        from . import flags
        flags.record(game, "engine", "new party died part-way",
                     f"The new party after T{rec['turn']} never finished (the bot went down mid-reset); the world was "
                     f"put back from its backup ({folder})."
                     + (f" Ledger rows another world had taken meanwhile were left alone: {', '.join(rec['moved_on'])}."
                        if moved else ""), turn=rec["turn"])
        return rec
    except Exception as exc:
        try:
            game.out(f"  (new party: a reset that died part-way couldn't be put back - {exc}; see its backup's README)")
        except Exception:
            pass
        return None


def _reset(game, old: list[dict], gap: int, label: str, folder: Path, passes: int | None, ending: str = "",
           run_rec: dict | None = None) -> dict:
    L, S = game.ledger, game.sub
    t, start = game.turn_no(), game.clock()
    scene = L.current_scene()
    sid = scene["id"]
    seats = {r["handle"]: r["name"] for r in game.conn.execute("SELECT handle, name FROM players")}
    roster = L.roster(sid)
    ended = _ending(game, sid, t, [p["id"] for p in old], roster, ending) if ending else None
    w0 = _count_offscreen(game)
    closed = _close_scene(game, sid, t)              # (while they're still the crew: the NPCs settle their views)
    new_sid = game.new_scene(title(label), None, [], t)
    game.conn.execute("UPDATE scenes SET status='closed', closed_turn=? WHERE id=?", (t, sid))
    parked = _close_parked(game, t, sid)
    crew_out = [_retire(game, p, t, seats, run_rec) for p in old]
    _minds(game, crew_out, t, label, scene, ending)
    seq = game.conn.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]
    for o in crew_out:                               # offscreen actors from here on, first in line, nothing stale owed
        game.conn.execute("INSERT OR REPLACE INTO world_actors(npc_id, last_turn, last_time, last_seq) "
                          "VALUES(?, 0, NULL, ?)", (o["id"], seq))
    session = L.new_session()
    h0 = game.conn.execute("SELECT COUNT(*) FROM hooks").fetchone()[0]
    moves, stops = _catch_up(game, new_sid, start, gap, passes)
    hooks = game.conn.execute("SELECT COUNT(*) FROM hooks").fetchone()[0] - h0
    mended = _time_passes(game, gap, t, [o["id"] for o in crew_out] + roster, label)
    jobs_left = _jobs(game, t, [o["name"] for o in crew_out])
    for o in crew_out:                               # (before the note: a picture folds the notes written so far)
        _picture(game, o, t, label)
    _tell_gm(game, crew_out, t, label, scene["title"], ending, start)
    rec = {"turn": t, "at": time.time(), "gap": gap, "label": label, "title": title(label), "clock_from": start,
           "clock_to": game.clock(), "session": session, "scene_closed": sid, "scene_closed_title": scene["title"],
           "scenes_parked_closed": parked,
           "scene_opened": new_sid, "backup": str(folder), "passes": stops, "ending": ending, "ending_id": ended,
           "world_moves": _count_offscreen(game) - w0 - len([o for o in crew_out if o.get("moment")]),
           "hooks": hooks,
           "old_crew": [{k: o.get(k) for k in ("id", "name", "ledger", "ledger_state", "player", "owner", "epilogue",
                                              "goal", "agenda", "where", "jacked_out")} for o in crew_out]}
    return {"record": rec, "crew": crew_out, "closed": closed, "moves": moves, "mended": mended, "jobs": jobs_left}


def _count_offscreen(game) -> int:
    return game.conn.execute("SELECT COUNT(*) FROM nodes WHERE kind='slice' AND visibility='offscreen'").fetchone()[0]


def _close_scene(game, sid: int, t: int) -> dict:
    """What commit does when a scene ends (dm/commit.py): the dying left alone die, minds reflect, the notebook
    folds, word gets around, the summary is written and energy renormalized. Feelings cool after the skip."""
    from .dm.clarify import fold_scene
    from .dm.commit import close_scene, left_to_die
    from .dm.minds import reflect_scene
    from .substrate.rumors import spread_rumors
    dead = left_to_die(game, sid, t)
    beliefs = reflect_scene(game, sid, t)
    folded = fold_scene(game, sid, t)
    rumors = spread_rumors(game, sid, t)
    close_scene(game, sid, t)
    return {"dead": dead, "beliefs": beliefs, "folded": folded, "rumors": rumors}


def _close_parked(game, t: int, sid: int) -> list[int]:
    """Every scene the old crew left parked closes with the chapter's. A party arriving somewhere resumes that place's
    newest scene that isn't closed (commit.auto_cut) - with its old roster, its frame (WHY THEY'RE HERE, written for
    the old crew), its RECENTLY and the GM's last narration there: the new crew walked into the old crew's Boathouse
    (review 2026-10-27). Their close already ran when the crew left them (commit closes the scene left behind), and
    who was there stays 'last seen' there (Ledger.scene_of reads closed scenes too). Their frames go, the chapter's
    own with them. Returns the ids closed."""
    from .dm import frame
    ids = [r[0] for r in game.conn.execute("SELECT id FROM scenes WHERE status='parked' ORDER BY id")]
    game.conn.execute("UPDATE scenes SET status='closed', closed_turn=COALESCE(closed_turn, ?) WHERE status='parked'",
                      (t,))
    for x in ids + [sid]:
        game.conn.execute("DELETE FROM meta WHERE key=?", (frame._key(x),))
    return ids


def _ending(game, sid: int, t: int, crew_ids: list[str], roster: list[str], text: str) -> str:
    """The owner's word on how the old story ended: the closing scene's last moment, lived by everyone still in it -
    the crew, the NPCs up and about there, the place - so the scene's summary, the world's minds and the old crew's
    own read all start from it. Public (the table said it): recaps tell it, and it's in the scene's record."""
    L, S = game.ledger, game.sub
    loc = (L.scene(sid) or {}).get("location_id")
    members = [(x, "actor") for x in crew_ids if x in roster]
    members += [(x, "present") for x in roster if (L.get(x) or {}).get("kind") == "npc"
                and sr_lite.condition(L, x) not in sr_lite.OUT]
    members += [(loc, "location")] if loc else []
    wid = S.write_offscreen(t, text, members, None, story_time=game.clock())
    S.set_visibility(wid, "public")
    game.conn.execute("UPDATE nodes SET scene_id=? WHERE id=?", (sid, wid))
    S.touch([wid], t, 1.0)                           # (a moment the story lived: a slice's deposit)
    return wid


def _retire(game, ent: dict, t: int, seats: dict, run_rec: dict | None = None) -> dict:
    """One of the old crew becomes the GM's: home to the ledger (which lets them go), off the table, an NPC - every
    record kept (stats, gear, holdings, drones, history, links, the beliefs others hold about them). run_rec: the
    running record, told which ledger rows the reset wrote and how it left them (the way back writes only those)."""
    L, S = game.ledger, game.sub
    eid = ent["id"]
    key = ent["props"].get("ledger")
    r = charledger.get(game, ent["name"]) if key else None
    if key and run_rec is not None:                  # (saved first: a kill inside let_go still finds the row the reset's)
        run_rec["let"][key] = None
        _save(game, run_rec)
    story = charledger.let_go(game, eid)             # last progress and a backstory home; the ledger lets them go
    if key and run_rec is not None:
        if story is None:                            # (this world didn't hold their checkout: the row wasn't written)
            run_rec["let"].pop(key, None)
        else:
            run_rec["let"][key] = _fingerprint((charledger.raw_rows(game, [key]) or [None])[0])
        _save(game, run_rec)
    for x in [row[0] for row in game.conn.execute("SELECT scene_id FROM scene_roster WHERE entity_id=?", (eid,))]:
        L.leave(x, [eid])
    jacked = _jack_out(game, eid, t)
    player = seats.get(ent["player"] or "\0") or seats.get(eid) or (r or {}).get("owner_name")
    game.conn.execute("DELETE FROM players WHERE handle IN (?, ?)", (ent["player"] or "\0", eid))
    game.conn.execute("DELETE FROM control WHERE entity_id=?", (eid,))
    ent = L.get(eid)
    props = {k: v for k, v in ent["props"].items() if k not in ("ledger", "whereabouts")}
    props["template"] = props.get("archetype") or "runner"        # (what the packet and the world call them: a role)
    props["former_pc"] = {"turn": t, "ledger": key, "player": player, "handle": ent["player"]}
    L.update_entity(eid, kind="npc", tier=2, player=None, props=props)
    S.ensure_entity(L.get(eid), t)
    L.log(t, "new_party", eid, {"was": "pc", "ledger": key, "backstory": bool(story)})
    return {"id": eid, "name": ent["name"], "ledger": key, "player": player, "owner": (r or {}).get("owner_name"),
            "ledger_state": None if not key else ("home" if story is not None else "unlinked"), "backstory": story,
            "jacked_out": jacked}


def _jack_out(game, eid: str, t: int) -> str | None:
    """Weeks go by: nobody stays logged into a host. The Matrix's own clean logout (the host stands its IC down)."""
    from .engine.rules import matrix
    st = matrix.state(game.ledger, eid)
    host = st.get("host")
    if not host:
        return None
    matrix._disconnect(game.ledger, game.dice, t, eid, st, forced=False)
    return (game.ledger.get(host) or {}).get("name", host)


# ── their minds ─────────────────────────────────────────────────────────
def _people(game, eid: str, sc: Scope) -> list[tuple[int, dict, dict]]:
    """The people they dealt with: (moments shared first-hand, the person, the latest of those moments) - only the
    moments they hold (sc.witnessed: never someone else's whisper), most shared first."""
    roles = game.settings.knobs.witness_roles
    marks = ",".join("?" * len(roles))
    shared: dict[str, dict[str, dict]] = {}
    for r in game.conn.execute(
            f"SELECT y.node_id, n.id, n.created_turn, n.text FROM members x JOIN members y ON y.slice_id=x.slice_id "
            f"JOIN nodes n ON n.id=x.slice_id WHERE x.node_id=? AND x.role IN ({marks}) AND y.role IN ({marks}) "
            f"AND y.node_id<>?", (eid, *roles, *roles, eid)):
        if r[1] in sc.witnessed:
            shared.setdefault(r[0], {})[r[1]] = {"id": r[1], "turn": r[2], "text": r[3]}
    out = []
    for x, moments in shared.items():
        e = game.ledger.get(x)
        if e and e["kind"] in ("pc", "npc") and e["status"] == "active":
            out.append((len(moments), e, max(moments.values(), key=lambda m: m["turn"])))
    out.sort(key=lambda p: (-p[0], -p[2]["turn"]))
    return out[:PEOPLE_MAX]


def _mind_prompt(game, o: dict, label: str, scene: dict, crew_ids: set[str] = frozenset(),
                 ending: str = "") -> tuple[str, list[str]]:
    """Their read: who they are, what they lived (their witness scope), the people they dealt with. Returns (the
    prompt, the ids a belief may be about)."""
    L, S = game.ledger, game.sub
    eid = o["id"]
    ent = L.get(eid)
    p = ent["props"]
    sc = Scope(game, eid)
    people = _people(game, eid, sc)
    known = sc.known()
    orgs = [e for e in (L.get(x) for x in known) if e and e["kind"] == "faction"]
    places = sorted((e for e in (L.get(x) for x in known) if e and e["kind"] == "location"),
                    key=lambda e: -S.energy_of(e["id"]))[:15]
    moments = sorted((S.node(x) for x in sc.witnessed), key=lambda n: (n["created_turn"], n["id"]))
    scenes = sorted((S.node(x) for x in sc.scenes if S.exists(x)), key=lambda n: n["scene_id"] or 0)
    loc = L.get(scene["location_id"]) if scene.get("location_id") else None
    what = " ".join(x for x in (p.get("metatype"), (p.get("archetype") or "runner").replace("_", " ")) if x)
    lines = [f"FORMER PLAYER CHARACTER: {ent['name']} [{eid}] - {what}, {p.get('pronouns') or 'they/them'}"
             + (f"; played by {o['player']}" if o.get("player") else ""),
             f"DESCRIPTION: {ent['description'] or '(none)'}"]
    if p.get("concept"):
        lines.append(f"CONCEPT (how their player built them): {p['concept']}")
    lines.append(f"\nSHEET:\n{sr_lite.sheet(L, eid)}")
    lines.append(f"\nWHERE THEIR STORY LEFT THEM: \"{scene['title']}\"" + (f" at {loc['name']}" if loc else "")
                 + f", {clock.fmt(game.clock())}. The crew goes its separate ways here, and the story skips "
                   f"{in_words(label)}." + (f" HOW IT ENDED (the table's word): {ending}" if ending else ""))
    if o.get("backstory"):
        lines.append(f"\nTHEIR STORY, IN SHORT: {o['backstory']}")
    if scenes:
        lines.append("\nTHE SCENES THEY WERE IN (oldest first):\n" + "\n".join(
            f"- [{n['id']}] {(n['text'] or '')[:300]}" for n in scenes[-SCENES_MAX:]))
    if moments:
        lines.append("\nTHE LAST MOMENTS THEY LIVED (oldest first):\n" + "\n".join(
            f"- [{n['id']}] {(n['text'] or '')[:300]}" for n in moments[-LATELY:]))
    heard = sorted(sc.heard.values(), key=lambda h: h["turn"])[-HEARD_MAX:]
    if heard:
        lines.append("\nWHAT THEY HEARD (second-hand):\n" + "\n".join(
            f"- ({h['how']}) {((S.node(h['node_id']) or {}).get('text') or '')[:200]}" for h in heard))
    if people:
        who = lambda e: ("one of the crew, going their own way too" if e["id"] in crew_ids      # noqa: E731
                         else "a player character" if e["kind"] == "pc" else "NPC")
        lines.append("\nTHE PEOPLE THEY DEALT WITH (moments shared first-hand; the latest):\n" + "\n".join(
            f"- {e['name']} [{e['id']}] ({who(e)}) - "
            f"{(e['description'] or '')[:140]} - {n} moment{'s' * (n != 1)}; last [{m['id']}]: {(m['text'] or '')[:160]}"
            for n, e, m in people))
    if orgs:
        lines.append("ORGANIZATIONS THEY KNOW OF: " + ", ".join(f"{e['name']} [{e['id']}]" for e in orgs))
    if places:
        lines.append("PLACES THEY KNOW: " + ", ".join(f"{e['name']} [{e['id']}]" for e in places))
    lines.append("DISTRICTS: " + ", ".join(geo.GAZETTEER))
    lines.append(f"MONEY: {int(L.stat(eid, 'nuyen')):,} nuyen · karma {int(L.stat(eid, 'karma'))}")
    # (live 2026-10-27, the system prompt's example naming Magic: all nine of Quiet Lou's came back "Magic thinks
    #  Magic's plan...", "Rook thinks Rook pays fair" - the person as the holder)
    lines.append(f"BELIEFS ARE {ent['name'].upper()}'S: each one reads \"{ent['name']} thinks <the person> ...\".")
    return "\n".join(lines), [e["id"] for _, e, _ in people] + [e["id"] for e in orgs]


def _minds(game, crew_out: list[dict], t: int, label: str, scene: dict, ending: str = "") -> None:
    """One read each, side by side (the world model, like an offscreen mind's); written on the game thread."""
    if not crew_out:
        return
    ids = {o["id"] for o in crew_out}
    jobs = [(o, *_mind_prompt(game, o, label, scene, ids, ending)) for o in crew_out]
    answers = fan_out(lambda user: game.llm.structured(game.settings.models.world, MIND_SYSTEM, user, mind_schema(),
                                                       max_tokens=6000, effort=game.settings.models.world_effort,
                                                       purpose="minds"), [j[1] for j in jobs])
    for (o, _, allowed), data in zip(jobs, answers):
        if isinstance(data, BaseException) or not isinstance(data, dict):
            o["mind_error"] = str(data)            # (a goal of their own anyway; their persona comes the world's way)
            data = {}
        _apply_mind(game, o, data, set(allowed), t)


def _clean(v) -> str:
    return " ".join(str(v or "").split())


def _apply_mind(game, o: dict, data: dict, allowed: set[str], t: int) -> None:
    L, S = game.ledger, game.sub
    eid = o["id"]
    if isinstance(data.get("persona"), dict):       # (the world's own persona apply: affiliations join their factions)
        o["persona"] = world.apply(game, world.Job("persona", eid, "", t), data["persona"])
    beliefs = []
    for b in (data.get("beliefs") or [])[:PEOPLE_MAX]:
        about = L.find(_clean(b.get("about")).strip("[]"))
        text = _clean(b.get("belief"))
        if not about or about["id"] not in allowed or not text:
            continue                                # (only the people they actually dealt with)
        try:
            att = max(-3, min(3, int(b.get("attitude") or 0)))
        except (TypeError, ValueError):
            att = 0
        bid = S.add_belief(eid, about["id"], text, t, story_time=game.clock())
        L.set_stat(eid, f"attitude:{about['id']}", att)
        L.log(t, "belief", eid, {"about": about["id"], "attitude": att, "belief": bid, "by": "newparty"})
        beliefs.append({"id": bid, "about": about["id"], "name": about["name"], "attitude": att})
    goal = data.get("goal") or {}
    g = _clean(goal.get("goal")) or FALLBACK_GOAL
    targets = [str(x) for x in goal.get("targets") or [] if L.find(str(x))]
    aid = world.add_agenda(game, eid, g, targets, t, by="newparty")
    w = data.get("whereabouts") or {}
    if _clean(w.get("where")):
        world.move(game, eid, _clean(w.get("where")), _clean(w.get("place")) or None)
    spot = (L.get(eid)["props"].get("whereabouts") or {}).get("place")
    spot = L.get(spot) if spot else None
    epilogue = _clean(data.get("epilogue"))
    wid = None
    if epilogue:                                    # what they did as the crew split: a moment they lived, offscreen
        wid = S.write_offscreen(t, epilogue, [(eid, "actor")] + ([(spot["id"], "location")] if spot and
                                                                  spot["kind"] == "location" else []),
                                None, story_time=game.clock())
    S.touch([b["id"] for b in beliefs] + [aid] + ([wid] if wid else []), t, game.settings.knobs.retrieval_quantum)
    o.update(beliefs=beliefs, goal=g, agenda=aid, epilogue=epilogue, moment=wid,
             where=(L.get(eid)["props"].get("whereabouts") or {}).get("where"))


# ── the skip ────────────────────────────────────────────────────────────
@contextmanager
def _catch_up_budget(game, sid: int):
    """Bigger offscreen budgets for the catch-up, and the chapter's scene saying there's no crew about - both put
    back after (a turn's pass stays a turn's)."""
    k = game.settings.knobs
    was = (k.world_agents_per_pass, k.world_personas_per_pass)
    name = game.ledger.scene(sid)["title"]
    k.world_agents_per_pass, k.world_personas_per_pass = max(was[0], CATCHUP_AGENTS), max(was[1], CATCHUP_PERSONAS)
    game.conn.execute("UPDATE scenes SET title=? WHERE id=?", (CATCHUP_WHERE, sid))
    try:
        yield
    finally:
        k.world_agents_per_pass, k.world_personas_per_pass = was
        game.conn.execute("UPDATE scenes SET title=? WHERE id=?", (name, sid))


def _catch_up(game, sid: int, start: int, gap: int, passes: int | None) -> tuple[list[str], list[int]]:
    """The clock moves across the gap in a few steps, and the offscreen world takes a pass at each. Returns the
    passes' lines and the story times they ran at."""
    k = max(1, int(passes or passes_for(gap)))
    if not world.enabled(game):
        game.set_clock(start + gap)
        return ["(the offscreen world is off - `!world on` - so nobody moved in the gap)"], []
    lines, stops = [], []
    with _catch_up_budget(game, sid):
        for i in range(1, k + 1):
            game.set_clock(start + gap * i // k)
            stops.append(game.clock())
            got = world.run_pass(game)
            lines.append(f"-- {clock.fmt(game.clock())}: {len(got)} line{'s' * (len(got) != 1)} --")
            lines += got
    return lines, stops


def _time_passes(game, gap: int, t: int, ids: list[str], label: str) -> list[str]:
    """What the clock's rules do with the time that went by (commit.time_passes, sr_lite.recover): the people who
    were on screen rest - a month or more mends everyone; nobody holds a spell for weeks; what was bought is
    delivered; strong feelings cool."""
    from . import shops
    from .dm.minds import cool
    L = game.ledger
    why = f"{in_words(label)} went by"
    people = [i for i in dict.fromkeys(ids) if (L.get(i) or {}).get("kind") in ("pc", "npc")]
    if gap >= sr_lite.MEND_ALL:
        people += [e["id"] for e in L.entities(kind="npc") if e["id"] not in people]
    out = []
    for eid in people:
        out += sr_lite.recover(L, game.dice, t, eid, gap, why)
    for e in L.entities(kind="npc") + L.entities(kind="pc"):
        if e["props"].get("sustained"):
            try:
                out.append(magic.end_spell(L, e["id"], None, t, why=why))
            except LedgerError:
                pass
    out += shops.arrivals(game, t)
    out += [f"[MINDS] time cooled: {x}" for x in cool(game, t)]
    return out


def _jobs(game, t: int, names: list[str]) -> list[str]:
    """The crew's open runs stay with the crew that took them: off the new crew's job board."""
    from . import jobs
    left = []
    for j in jobs.open_jobs(game):
        note = f"[left with the old crew ({', '.join(names) or 'nobody'}) at the new party, T{t}]"
        game.conn.execute("UPDATE jobs SET status='dropped', progress=?, updated_turn=?, closed_turn=? WHERE id=?",
                          (f"{j['progress']} {note}".strip(), t, t, j["id"]))
        left.append(f"{j['id']} {j['title']}")
    return left


def _picture(game, o: dict, t: int, label: str) -> str:
    """A fresh current picture for each of the old crew (it supersedes the PC-era one): the packet prints it under
    their persona wherever they're about, and the frame pass and the canon read-back read it. Left as it was, it said
    'GM-run companion', 'holding the door', 'sustaining a Physical Barrier' three weeks on (review 2026-10-27). Who
    they are now, what they want, where they are, how they left; their ties as a PC kept below as history."""
    L, S = game.ledger, game.sub
    e = L.get(o["id"])
    p = world.persona(e) or {}
    old = S.clarification(o["id"])
    who = " ".join(_clean(p.get(k)) for k in ("temperament", "voice", "motivations") if _clean(p.get(k)))
    feels = "; ".join(f"{b['name']} ({int(L.stat(o['id'], 'attitude:' + b['about'])):+d})"   # (as time cooled them)
                      for b in o.get("beliefs") or [])
    where = ((e["props"].get("whereabouts") or {}).get("where") or o.get("where"))      # (the gap may have moved them)
    lines = [f"{e['name'].upper()} - an NPC the GM plays since the new party after T{t} (until then "
             f"{o.get('player') or 'a player'}'s player character); {in_words(label)} went by, it's "
             f"{clock.fmt(game.clock())}."]
    if e["description"]:
        lines.append(f"LOOKS: {_clip(_clean(e['description']), 300)}")
    if who:
        lines.append(f"WHO THEY ARE: {who}")
    lines.append("WANTS NOW" + (f" [{o['agenda']}]" if o.get("agenda") else "") + f": {o.get('goal') or FALLBACK_GOAL}")
    if where:
        lines.append(f"WHERE: {where}")
    if o.get("epilogue"):
        lines.append(f"AS THE CREW SPLIT: {o['epilogue']}")
    if feels:
        lines.append(f"HOW THEY FEEL NOW: {feels}")
    lines.append("What they were doing as a player character - plans, held spells, a Matrix session, where they stood "
                 "at the split - ended with the skip. Their sheet, gear, money and history are theirs; what they did "
                 "stands.")
    if old:
        lines.append(f"THEIR TIES AND STORY AS A PC (the picture of T{old['created_turn']} - history now, not where "
                     f"they are): {_clip(_clean(old['text']), PICTURE_OLD_MAX)}")
    return S.clarify(o["id"], "\n".join(lines), t, by="newparty")


def _tell_gm(game, crew_out: list[dict], t: int, label: str, scene_title: str, ending: str = "",
             start: int | None = None) -> None:
    """A note riding each of them (the GM sees it whenever they're about), and the canon told at once - the next
    read-back writes it properly (the table kicks one off after a new party; canon.gather shows it the skip). The
    canon is a record of 'now' at the top of every packet, outranking older memories: what it said before the skip is
    marked so - everyone's stand, what was coming, the open threads - and the skip itself, with how it ended, goes in
    SETTLED and the TIMELINE (review 2026-10-27: three weeks on, it still had Lim's convoy five minutes out)."""
    S = game.sub
    for o in crew_out:
        S.add_note([o["id"]], f"A player character until the new party after T{t} ({o.get('player') or 'a player'}'s"
                              f"); the GM plays {o['name']} now - an NPC with a goal of their own"
                              + (f" [{o['agenda']}]: {o['goal']}" if o.get("agenda") else "")
                              + ". Everything they did stands. The new crew may cross paths with them but isn't bound "
                                "to their business.", t)
    from .dm import canon
    c = canon.current(game)
    if not c:
        return
    skip = f"(before the {in_words(label)} skip)"
    names = ", ".join(o["name"] for o in crew_out)
    c.setdefault("settled", []).append({"what": f"After \"{scene_title}\" "
                                                + (f"(how it ended: {ending}) " if ending else "")
                                                + (f"the crew went its separate ways: {names} are NPCs the GM plays "
                                                   "now, each with their own goals; " if crew_out else
                                                   "the story moved on; ")
                                                + f"{in_words(label)} later a new crew takes the table",
                                        "since": f"T{t}"})
    c.setdefault("timeline", []).append(f"{clock.fmt(start if start is not None else game.clock())} → "
                                        f"{clock.fmt(game.clock())}: the story skipped {in_words(label)} after "
                                        f"\"{scene_title}\"" + (f" - {ending}" if ending else ""))
    ids = {o["id"]: o for o in crew_out}
    for p in c.get("people") or []:
        o = ids.get(p.get("id"))
        if o:
            p["stands"] = (f"no longer a player character - an NPC the GM plays since T{t}; wants: {o.get('goal')}"
                           + (f"; at {o['where']}" if o.get("where") else ""))
        elif p.get("stands") and not str(p["stands"]).startswith("(before"):
            p["stands"] = f"{skip} {p['stands']}"
    for k in ("upcoming", "open_threads"):
        c[k] = [x if str(x).startswith("(before") else f"{skip} {x}" for x in c.get(k) or []]
    game.ledger.set_meta(canon.KEY, json.dumps(c))


def canon_lines(game, start: int) -> str:
    """For canon.gather: each new party inside the stretch of turns the read-back reads (after T`start`). Its TURNS
    run straight from the old crew's last to the new crew's first, and the latest turns win - so without this the
    read-back wrote where people stood before the skip: no ending, nothing the world did in the gap (review
    2026-10-27). The skip, how it ended, the old crew's new lives and the gap's offscreen moments, in story order."""
    out = []
    for rec in records(game):
        if rec.get("status") == RUNNING or int(rec.get("turn") or 0) < start:
            continue
        t, a, b = int(rec["turn"]), rec.get("clock_from"), rec.get("clock_to")
        lines = [f"\n\nA NEW PARTY AFTER T{t} - the crew changed and the story skipped {in_words(rec['label'])} "
                 f"({clock.fmt(a)} → {clock.fmt(b)}). It is newer than every turn up to T{t}: write where people "
                 f"stand, what's coming and what's open AS OF AFTER THE SKIP; the turns after T{t} are the new crew's."]
        if rec.get("ending"):
            lines.append(f"How the old story ended (the table's word): {rec['ending']}")
        for o in rec.get("old_crew") or []:
            lines.append(f"- {o['name']} [{o['id']}]: no longer a player character - an NPC the GM plays; wants: "
                         f"{o.get('goal') or '?'}" + (f"; at {o['where']}" if o.get("where") else "")
                         + (f". {o['epilogue']}" if o.get("epilogue") else ""))
        moments = game.conn.execute(
            "SELECT id, text, story_time FROM nodes WHERE kind='slice' AND id LIKE 'W%' AND created_turn=? AND "
            "visibility IN ('offscreen', 'public') AND story_time BETWEEN ? AND ? ORDER BY story_time, rowid",
            (t, a, b)).fetchall()
        if moments:
            lines.append("WHAT HAPPENED OFFSCREEN IN THE GAP (story order):")
            lines += [f"- [{m['id']}] ({clock.fmt(m['story_time'])}) {_clip(_clean(m['text']), 240)}"
                      for m in moments[-CANON_GAP_MAX:]]
        out.append("\n".join(lines))
    return "".join(out)


# ── what the table sees, what the owner sees ────────────────────────────
def opening(game, crew_text: str, pitch: str = "") -> str:
    """The stage direction for the new crew's first turn (`!begin`), while a new party waits to open; else ""."""
    rec = pending(game)
    if not rec:
        return ""
    old = ", ".join(o["name"] for o in rec["old_crew"])
    return (f"A new chapter in a world already in motion: {in_words(rec['label'])} after \"{rec['scene_closed_title']}\" "
            f"- it's {clock.fmt(game.clock())}. "
            + (f"How the old story ended: {rec['ending']} " if rec.get("ending") else "")
            + (f"The old crew ({old}) went their separate ways; they're NPCs you play now, living their own lives - "
               "bring one in only if it fits. " if old else "")
            + f"Open the story for this NEW crew - {crew_text}. "
            + (f"The players asked for: {pitch}. " if pitch else "Give them a job hook that fits who they are. ")
            + "Start somewhere that suits them (one of their places, a bar, a fixer's back room), bring in a fixer or "
              "a Mr. Johnson with the job, and stop when the players have to respond. The world's open tensions, hooks "
              "and threads are still out there - use what fits this crew"
            + (", but they aren't bound to the old crew's business" if old else "")
            + ". Don't decide anything for the player characters.")


def card(game, rec: dict) -> dict:
    """The table's card: in the fiction's voice, what changed, and how to join."""
    lines = [f"*{clock.fmt(rec['clock_from'])} → {clock.fmt(rec['clock_to'])}. The city didn't wait.*"]
    if rec.get("ending"):
        lines.append(f"\n**How it ended:** {rec['ending']}")
    if rec["old_crew"]:
        lines.append("\n**The old crew went their separate ways** - they're still out there (the GM plays them now), "
                     "and you may cross paths:")
        lines += [f"• **{o['name']}** - {_clip(o.get('epilogue') or 'went their own way.', 300)}" for o in rec["old_crew"]]
    if rec.get("world_moves"):
        lines.append(f"-# The world moved on: {rec['world_moves']} thing{'s' * (rec['world_moves'] != 1)} happened "
                     "out of sight.")
    try:
        shelf = [r["name"] for r in charledger.runners(game) if not r["campaign"] and not game.ledger.find(r["name"])]
    except sqlite3.Error:
        shelf = []
    lines.append("\n**A new crew** - everyone brings a runner:\n• `!newchar` build one with the GM  ·  `!pregen "
                 "[concept]` let the GM roll one up\n• `!characterledger checkout <runner>` bring one off the shelf"
                 + (f" ({', '.join(shelf[:6])})" if shelf else "")
                 + "\nThen `!begin` - add what kind of run you want (`!begin a quiet data job`) - and the GM opens "
                   "the new story.")
    return {"title": f"⏳ {rec['title']}...", "description": "\n".join(lines)[:CARD_MAX], "color": 0xF1C40F,
            "footer": f"{clock.fmt(rec['clock_to'])} · session {rec['session']}"}


def _clip(s: str, n: int = 220) -> str:
    return s if len(s) <= n else s[:n - 1] + "…"


def owner_text(game, res: dict) -> str:
    """The owner's summary (by DM - it names the world's moves): the backup, who became whose, the skip, the world."""
    rec = res["record"]
    out = [f"**A new party in {game.path.stem}** - after T{rec['turn']}: {clock.fmt(rec['clock_from'])} → "
           f"{clock.fmt(rec['clock_to'])} ({in_words(rec['label'])})",
           f"💾 Backup: `{rec['backup']}` - the world and the character ledger, from just before. `!rp newparty undo` "
           "puts it all back until the new crew's first turn (after that, `!undo` back to it first)."]
    if res["crew"]:
        out.append("\n**The old crew - the GM's now:**")
    for o in res["crew"]:
        ledger = {"home": f"progress and a backstory home, back on the ledger's shelf ({o.get('owner') or 'theirs'})",
                  "unlinked": "the ledger had already let them go - unlinked here", None: "not in the character ledger"}
        now = {b["about"]: int(game.ledger.stat(o["id"], f"attitude:{b['about']}")) for b in o.get("beliefs") or []}
        feels = ", ".join(f"{b['name']} {now[b['about']]:+d}"         # (as the gap cooled them - the picture's numbers)
                          + (f" (was {b['attitude']:+d})" if now[b["about"]] != b["attitude"] else "")
                          for b in o.get("beliefs") or [])
        out.append(f"• **{o['name']}** [{o['id']}] - {ledger[o.get('ledger_state')]}"
                   + (f"; jacked out of {o['jacked_out']}" if o.get("jacked_out") else "")
                   + (f"\n  {_clip(o['persona'][0].split(': ', 1)[-1], 200)}" if o.get("persona") else "")
                   + f"\n  goal [{o.get('agenda')}]: {o.get('goal')}"
                   + (f"\n  at: {o['where']}" if o.get("where") else "")
                   + (f"\n  feels: {feels}" if feels else "")
                   + (f"\n  (their read failed - {o['mind_error'][:120]}; the world writes their persona)"
                      if o.get("mind_error") else ""))
    c = res["closed"]
    out.append(f"\n**Scene** S{rec['scene_closed']} \"{rec['scene_closed_title']}\" closed ({len(c['beliefs'])} "
               f"belief{'s' * (len(c['beliefs']) != 1)} settled, {len(c['folded'])} picture{'s' * (len(c['folded']) != 1)}"
               f" folded, {c['rumors']} rumor{'s' * (c['rumors'] != 1)}"
               + (f", {len(c['dead'])} left to die" if c["dead"] else "") + f") → S{rec['scene_opened']} "
               f"\"{rec['title']}\". Session {rec['session']}."
               + (f" The {len(rec['scenes_parked_closed'])} scene(s) the old crew left parked closed too (a new crew "
                  "arriving there starts a fresh one)." if rec.get("scenes_parked_closed") else ""))
    stops = ", ".join(clock.fmt(s) for s in rec["passes"])
    moves = [m for m in res["moves"] if not m.startswith("--")]
    out.append(f"\n**The world caught up** in {len(rec['passes'])} pass{'es' * (len(rec['passes']) != 1)}"
               + (f" ({stops})" if stops else "") + f": {rec['world_moves']} offscreen moment(s), "
               f"{rec.get('hooks', 0)} new hook(s) waiting for the GM")
    out += [_clip(m) for m in res["moves"][:40]]
    if len(res["moves"]) > 40:
        out.append(f"... and {len(res['moves']) - 40} more (`!world` has it all)")
    if res["mended"]:
        out.append("\n**Time passed:** " + " · ".join(_clip(m.split("\n")[0], 140) for m in res["mended"][:12]))
    if res["jobs"]:
        out.append("**Runs left with the old crew:** " + ", ".join(res["jobs"]))
    out.append(f"\n{res.get('calls', 0)} model call(s) · ${res.get('cost', 0.0):.3f}" + ("" if moves else
                                                                                       " · the world stayed quiet"))
    return "\n".join(out)


# ── the way back ────────────────────────────────────────────────────────
def undo_note(game) -> str | None:
    """What !undo says when it finds nothing to take back right after a new party (it isn't a turn)."""
    rec = last(game)
    if rec and game.turn_no() == int(rec["turn"]):
        return (f"Nothing to undo - the new party after T{rec['turn']} isn't a turn: `!rp newparty undo` (the owner) "
                "takes it back.")
    return None


def can_undo(game) -> dict:
    """The newest new party, if it can still be taken back (no turn played since; none of the old crew checked out to
    another world meanwhile) - or one that died part-way; else LedgerError saying why."""
    rec = running(game)
    if rec and _alive(game, rec):
        raise LedgerError("A new party is under way right now - once it's done, ask again.")
    if not rec:
        rec = last(game)
        if not rec:
            raise LedgerError("No new party here to take back.")
        now = game.turn_no()
        if now != int(rec["turn"]):
            raise LedgerError(f"The new crew has played since (T{int(rec['turn']) + 1}-T{now}) - `!undo` back to the "
                              "start of the new chapter first, then `!rp newparty undo`.")
    if not (Path(rec["backup"]) / game.path.name).exists():
        raise LedgerError(f"The backup isn't there any more ({rec['backup']}).")
    taken = _taken(game, rec)
    if taken and rec.get("status") != RUNNING:        # (a half-reset world goes back whatever: their rows are left be)
        raise LedgerError("The character ledger has let " + ", ".join(
            f"**{r['name']}** go to **{r['campaign']}**" for r in taken) + " since the new party - taken back now, "
            "they'd be booked in two worlds. Return them there first (`!characterledger return` in that world, or "
            f"the owner's `!characterledger release {taken[0]['name']}`), then `!rp newparty undo`.")
    return rec


def undo_confirm_text(rec: dict) -> str:
    names = ", ".join(f"**{o['name']}**" for o in rec["old_crew"]) or "the old crew"
    died = (f"The new party after T{rec['turn']} died part-way (the bot went down mid-reset). "
            if rec.get("status") == RUNNING else "")
    return (died + f"This puts back `{rec['backup']}`: the world as it was just before the new party "
            f"({clock.fmt(rec['clock_from'])}) - {names} at the table again, and the skip and the world's moves in the "
            "gap gone. The character ledger gets their rows back as they were (one who played another world since "
            "comes back with that newer sheet); runners checked out or made here since go back to the shelf. The "
            "table's house rules and story directions stay.")


def _home_again(game, moved: list[dict]) -> list[str]:
    """The old crew whose rows moved on since the reset (left alone): one played in another world and back on the
    shelf checks out here again - the same character, the newer sheet (charledger.check_out's way back into a world
    they left); one still out elsewhere stays there. Returns what happened, for the owner."""
    notes = []
    for r in moved:
        if r["campaign"]:
            notes.append(f"{r['name']} is checked out to {r['campaign']} - left there")
            continue
        try:
            charledger.check_out(game, r["name"], r["owner_id"], game.turn_no())
            notes.append(f"{r['name']} played in another world since - back here with that newer sheet")
        except LedgerError as exc:
            notes.append(f"{r['name']} stays on the shelf ({exc})")
    return notes


def undo(game) -> dict:
    """Put the backup back: the world as it was just before the new party (the table's house rules and story
    directions since stay, as !undo keeps them), the old crew's rows in the character ledger, the !undo snapshots.
    A row that moved on - played in another world and back on the shelf - isn't written over: the runner checks out
    here again with that newer sheet. Runners checked out here since that the backup doesn't have checked out here go
    back on the shelf. rec['ledger_notes'] says what the ledger did that isn't plain. A reset that died part-way is
    put back the way a failed one rolls back (recover)."""
    from . import narrative, rulings
    rec = can_undo(game)
    folder = Path(rec["backup"])
    left = _left(rec)
    shelf = _backup_ledger(folder, charledger.path(game).name)
    rows = [r for s, r in shelf.items() if s in left]
    if rec.get("status") == RUNNING:
        rec["ledger_notes"] = _home_again(game, _rollback(game, folder, rows, rec.get("graph_buffer"), left))
        return rec
    put_back, put_story = rulings.keep(game.conn), narrative.keep(game.conn)
    db.restore(game.conn, folder / game.path.name)
    put_back()
    put_story()
    _, moved = _put_back(game, rows, left)
    notes = _home_again(game, moved)
    here = game.path.stem
    for r in charledger.raw_rows(game, [x["slug"] for x in charledger.runners(game) + charledger.runners(game, True)]):
        if r["campaign"] != here or r["slug"] in left:
            continue
        b = shelf.get(r["slug"])                     # (decided by the backup's ledger, not by who the world has now:
        if b and b["campaign"] == here:              # a departed runner checked back in kept a stale checkout)
            if b["entity_id"] != r["entity_id"]:
                charledger.put_rows(game, [{**r, "campaign": b["campaign"], "entity_id": b["entity_id"]}])
            continue
        charledger.put_rows(game, [{**r, "campaign": None, "entity_id": None}])     # (back on the shelf)
    _unpark_undo(game, folder)
    rec["ledger_notes"] = notes
    rec_ = game.sub.recorder
    if rec_ is not None:                             # (the reset's touches and its mark described a record that's gone)
        rec_.rewind(rec.get("graph_buffer"))
        rec_.prev = None
        try:
            from .graphlog import fmt
            fmt.append_mark(rec_.dir, {"kind": "new-party-undone", "turn": rec["turn"], "at": time.time()})
        except OSError:
            pass
    return rec
