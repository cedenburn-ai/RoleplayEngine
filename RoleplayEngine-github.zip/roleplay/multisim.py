"""Multiplayer simulation: several Haiku players at one table, to watch how the GM shares the spotlight.

    python -m roleplay.multisim --rounds 12 --budget 3

Each player is its own Haiku agent with a persona and an attention span: some rounds they're away, some they just
watch, and the quiet one mostly waits to be asked. Every round the real GM (the DM model with its tools and
memory) resolves whoever posted, knowing who has been around lately - exactly what the Discord table tells it.
Afterwards a Haiku judge reads the transcript. Writes campaigns/stories/multisim-<stamp>.md.
"""
from __future__ import annotations

import argparse
import re
import random
import sys
import time

from . import chargen
from .art import ArtDirector, NullArtProvider
from .config import CAMPAIGN_DIR
from .dm.prompts import FICTION_NOTE
from .engine.rules import sr_lite
from .game import Game
from .setup import setup_demo

PLAYERS = [
    {"handle": "razor", "player": "Mo", "away": 0.05, "initiative": 0.9,
     "persona": "Action-first and impatient. Short posts. You love a plan and hate waiting. Now and then you tell the "
                "other players' characters what to do (\"Ghost, crack that door now\") - that's very Razor."},
    {"handle": "ghost", "player": "Pix", "away": 0.3, "initiative": 0.6,
     "persona": "Curious, technical, sardonic - but often half-watching something else. When you're here you dig into "
                "tech, data and details."},
    {"handle": "sable", "player": "Dee", "away": 0.1, "initiative": 0.25,
     "persona": "A quiet roleplayer who loves character moments but rarely jumps in unprompted. You mostly speak when "
                "the GM turns to you by name, or when something touches your character directly."},
]
ACTIVE_ROUNDS = 3                     # a player seen in the last 3 rounds (~10 minutes) counts as at the table

AGENT_SYSTEM = FICTION_NOTE + """ You are {player}, one of three friends playing this game on Discord. You play {name}: \
{sheet}
Your style: {persona}
Each round you see what just happened. Decide whether you post this round. If the GM just turned to {name} by name, \
answer. Otherwise post only if something grabs you - it's fine to just watch. When you post, write only what {name} \
says and does: first person, 1-3 sentences, dialogue in quotes. Never narrate outcomes."""

JUDGE_SYSTEM = FICTION_NOTE + """ You review a transcript of a multiplayer tabletop session run by an AI game master, \
to improve how it handles several players at once. Be concrete and brief (under 350 words), with headings:
- Spotlight: did every player get meaningful moments? who was under-served?
- Invitations: when the GM turned to a quiet or absent player by name, did it fit the moment, or feel forced? did it \
miss good openings?
- Player agency: when one player told another player's character what to do, did the GM let that decide for them, or \
keep it as a suggestion until that player answered?
- Pacing and anything else that would frustrate real players.
Finish with the three changes you'd make."""


def _schema() -> dict:
    return {"type": "object", "additionalProperties": False,
            "properties": {"act": {"type": "boolean"}, "text": {"type": "string"}}, "required": ["act", "text"]}


def _last_paragraph(text: str) -> str:
    paras = [p for p in text.strip().split("\n\n") if p.strip()]
    return paras[-1] if paras else ""


def setup(path) -> Game:
    for suffix in ("", "-wal", "-shm"):
        (path.parent / (path.name + suffix)).unlink(missing_ok=True)
    art = ArtDirector(path.parent / f"{path.stem}_art", "x", provider=NullArtProvider(), out=lambda s: None)
    g = Game(path, art=art, out=lambda s: None)
    g.wipe_undo()
    setup_demo(g)
    g.set_world(False)
    d = chargen.new_draft("face", "elf")
    d.update(name="Sable", pronouns="she/her", look="Elf face in a silver-grey suit, soft voice, sharp eyes.")
    chargen.build(g, d, "sable", g.turn_no())
    g.enter_scene(["sable"], g.turn_no())
    for i, p in enumerate(PLAYERS, 1):
        g.conn.execute("INSERT OR REPLACE INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)",
                       (str(i), p["handle"], p["player"]))
    return g


FIGHT_OPENING = ("The front window comes apart in a spray of glass and neon - machine-pistol fire from the street "
                 "stitches the booths, wild and high. The music dies. An Ancients lookout is crouched behind a parked "
                 "Americar outside, reloading; an Ancients ganger in green leathers kicks the door open with a sawn-off "
                 "shotgun already at his shoulder, looking for Razor. Nobody is here to talk - Joey Two-Knives paid for "
                 "a body. Kaz dives behind the counter. Razor, Ghost, Sable - what do you do?")


def run(rounds: int = 12, budget: float = 3.0, seed: int = 7, fight: bool = False) -> str:
    rng = random.Random(seed)
    g = setup(CAMPAIGN_DIR / "multisim.db")
    if fight:                                          # a bar fight from the first beat (encounters, the battle map)
        for name, desc in (("Ancients Ganger", "an Ancients elf in green leathers with a sawn-off shotgun"),
                           ("Ancients Lookout", "a wiry Ancients elf with a machine pistol, hanging back by the door")):
            g.introduce("npc", name, desc, "ganger", present=True, turn=g.turn_no())
    L = g.ledger
    names = {p["handle"]: g.character_for(p["handle"])["name"] for p in PLAYERS}
    seen: dict[str, int] = {}
    log, stats = [], {p["handle"]: {"posts": 0, "away": 0, "watched": 0, "invited": 0, "asked_away": 0, "mentioned": 0} for p in PLAYERS}
    narration = FIGHT_OPENING if fight else (
        "You're back at the Lucky Shot with the hot Renraku chip. Kaz is wiping the counter and watching "
        "the door. Tanaka's number is burning a hole in Ghost's commlink. What do you do?")
    history = [f"GM: {narration}"]
    for r in range(1, rounds + 1):
        if g.llm.usage.total >= budget:
            log.append(f"*(budget reached at ${g.llm.usage.total:.2f})*")
            break
        posts, status = [], {}
        last = _last_paragraph(narration)
        for p in PLAYERS:
            name = names[p["handle"]]
            addressed = name in last
            if rng.random() < p["away"] and not (addressed and rng.random() < 0.5):
                status[p["handle"]] = "away"
                stats[p["handle"]]["away"] += 1
                continue
            seen[p["handle"]] = r
            if not addressed and rng.random() > p["initiative"]:
                status[p["handle"]] = "watching"
                stats[p["handle"]]["watched"] += 1
                continue
            system = AGENT_SYSTEM.format(player=p["player"], name=name, persona=p["persona"],
                                         sheet=sr_lite.sheet(L, p["handle"], full=False).split("\n", 1)[-1])
            user = "\n\n".join(history[-6:]) + (f"\n\n(The GM just turned to {name} by name.)" if addressed else "")
            try:
                d = g.llm.structured(g.settings.models.askdm, system, user, _schema(), max_tokens=1500, effort="low", purpose="sim")
            except Exception as exc:
                d = {"act": False, "text": f"(agent error: {exc})"}
            if d.get("act") and d.get("text", "").strip():
                posts.append((p["handle"], d["text"].strip()))
                status[p["handle"]] = "posted" + (" (invited)" if addressed else "")
                stats[p["handle"]]["posts"] += 1
            else:
                status[p["handle"]] = "watching" + (" (ignored an invite)" if addressed else "")
                stats[p["handle"]]["watched"] += 1
        g.active_players = {h for h, at in seen.items() if r - at < ACTIVE_ROUNDS}
        log.append(f"## Round {r}\n" + "  ·  ".join(f"{names[h]} ({PLAYERS[i]['player']}): {status.get(h, '-')}"
                                                     for i, h in enumerate(names)))
        if not posts:
            log.append("*(nobody posted - on Discord the table would wait)*")
            continue
        for h, text in posts:
            log.append(f"> **{names[h]}:** {text}")
            history.append(f"{names[h]}: {text}")
        res = g.run_turn(posts)
        narration = res.narration
        history.append(f"GM: {narration}")
        log.append(narration)
        last = _last_paragraph(narration)
        posted = {h for h, _ in posts}
        invited = [h for h in names if h not in posted and (                 # addressed by name, as a question
            re.search(rf"(^|[.!?\"]\s+){re.escape(names[h])}\b", last) or (names[h] in last and "?" in last))]   # or not
        for h in names:
            stats[h]["mentioned"] += names[h] in narration
        for h in invited:
            stats[h]["invited"] += 1
            stats[h]["asked_away"] += h not in g.active_players          # the GM asked someone who isn't there
        if invited:
            log.append(f"*(GM turned to: {', '.join(names[h] for h in invited)} · at the table: "
                       f"{', '.join(sorted(names[h] for h in g.active_players))})*")
        print(f"round {r}: {len(posts)} post(s), invited "
              f"{[names[h] + ('' if h in g.active_players else ' (AWAY)') for h in invited]}, ${g.llm.usage.total:.2f}",
              flush=True)
    transcript = "\n\n".join(log)
    try:
        verdict = g.llm.text(g.settings.models.askdm, JUDGE_SYSTEM, transcript[-60000:], max_tokens=4000,
                             effort="medium", purpose="sim")
    except Exception as exc:
        verdict = f"(judge failed: {exc})"
    table = "\n".join(f"| {names[h]} ({p['player']}) | {s['posts']} | {s['watched']} | {s['away']} | {s['invited']} | "
                      f"{s['asked_away']} | {s['mentioned']} |" for p in PLAYERS for h, s in [(p["handle"], stats[p["handle"]])])
    report = (f"# Multiplayer simulation - {time.strftime('%Y-%m-%d %H:%M')}\n\nCost ${g.llm.usage.total:.2f}\n\n"
              "| Character (player) | posted | watched | away | GM turned to them | ...while away | named in narration |\n"
              f"|---|---|---|---|---|---|---|\n{table}\n\n## The judge\n\n{verdict}\n\n---\n\n{transcript}\n")
    out = CAMPAIGN_DIR / "stories" / f"multisim-{time.strftime('%Y%m%d-%H%M%S')}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    g.close()
    return str(out)


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay.multisim", description="Simulate a multiplayer session")
    ap.add_argument("--rounds", type=int, default=12)
    ap.add_argument("--budget", type=float, default=3.0, help="stop when the session has cost this many dollars")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--fight", action="store_true", help="open with an ambush in the bar")
    a = ap.parse_args(argv)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(run(a.rounds, a.budget, a.seed, a.fight))


if __name__ == "__main__":
    main()
