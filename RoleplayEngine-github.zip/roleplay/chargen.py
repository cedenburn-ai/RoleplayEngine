"""Character creation (DESIGN.md §7c): a point-buy runner that the GM walks a player through.

The engine owns the budgets and the rules; the GM (a cheap model) only *proposes* a build from the player's
concept, and every proposal is repaired here before the player sees it. The conversation lives in
discord_bot/chargen_flow.py. This module is pure: a draft dict in, a draft dict (or a PC) out.

SR-lite chargen, simplified from SR5's priorities:
- attributes start at 1 (+ the metatype's free bonuses); 22 points to raise them; natural max 6 (metatypes shift it);
- skills: 26 points, max 6 each at creation;
- mages and technomancers get Magic / Resonance 6 and fewer nuyen (their gift is their priority);
- gear from the catalog at SR5's prices; augmentations cost Essence, and every Essence point lost costs Magic/Resonance;
  nothing over Availability 12 (SR5 p. 62, 417);
- whatever nuyen is left comes along as cash, up to 5,000.
"""
from __future__ import annotations

import math
import re
from collections import Counter

from .engine.ledger import LedgerError
from .engine.rules import machines, sr_lite

BASE_ATTRS = ("body", "agility", "reaction", "strength", "willpower", "logic", "intuition", "charisma")
ATTR_POINTS = 22
SKILL_POINTS = 26
SKILL_MAX = 6
# The book's Resources, now that the gear is at the book's prices (2026-10-24): Priority B for everyone else, D for a
# mage or technomancer - Magic or Resonance 6 takes Priority A (SR5 p. 65). (It was 15,000 / 9,000 for a catalog
# priced about a tenth of the book's at the top end.)
NUYEN = 275_000
NUYEN_AWAKENED = 50_000
CASH_CAP = 5000
AVAIL_MAX = 12                  # "an Availability greater than 12" can't be bought at character creation (p. 62, 417)
SPELL_PICKS = 6
FORM_PICKS = 4
AUG_MAX = 4                     # augmentations can push an attribute this far past its natural max

METATYPES = {
    "human": {"bonus": {}, "max": {}, "edge": 4, "traits": "", "blurb": "+1 Edge (4); no limits, no gifts"},
    "elf": {"bonus": {"agility": 1, "charisma": 2}, "max": {"agility": 7, "charisma": 8}, "edge": 3,
            "traits": "low-light vision", "blurb": "+1 Agility, +2 Charisma; low-light vision"},
    "dwarf": {"bonus": {"body": 2, "strength": 1, "willpower": 1}, "max": {"body": 8, "strength": 7, "willpower": 7,
                                                                           "reaction": 5},
              "edge": 3, "traits": "thermographic vision, toxin resistance",
              "blurb": "+2 Body, +1 Strength, +1 Willpower; Reaction max 5; thermographic vision"},
    "ork": {"bonus": {"body": 3, "strength": 2}, "max": {"body": 9, "strength": 8, "logic": 5, "charisma": 5}, "edge": 3,
            "traits": "low-light vision", "blurb": "+3 Body, +2 Strength; Logic and Charisma max 5; low-light vision"},
    "troll": {"bonus": {"body": 4, "strength": 4}, "max": {"body": 10, "strength": 10, "agility": 5, "logic": 5,
                                                           "intuition": 5, "charisma": 4},
              "edge": 3, "traits": "thermographic vision, long reach, dermal deposits",
              "blurb": "+4 Body, +4 Strength; Agility/Logic/Intuition max 5, Charisma max 4; thermographic vision"},
}
ROLES = {
    "street_samurai": "chromed-up muscle: guns, blades, wired reflexes",
    "decker": "Matrix intruder with a cyberdeck and a drone for eyes",
    "rigger": "jacks into drones and vehicles through a control rig",
    "mage": "hermetic spellcaster and summoner (Magic 6, less nuyen)",
    "technomancer": "the Matrix in their head: no deck, complex forms, sprites (Resonance 6, less nuyen)",
    "face": "talker, liar, negotiator - the one who gets you in the door",
}
ROLE_SHOW = {                    # (icon, name, what they're for at the table)
    "street_samurai": ("🗡️", "Street Samurai", "the one who walks in first: guns, blades, wired reflexes"),
    "decker": ("💻", "Decker", "breaks into hosts with a cyberdeck - cameras, doors, drones, paydata"),
    "rigger": ("🚗", "Rigger", "drives and flies drones and vehicles from inside their head"),
    "mage": ("🔮", "Mage", "casts spells and summons spirits - powerful, but less money for gear"),
    "technomancer": ("📡", "Technomancer", "the Matrix answers their mind - no deck, complex forms, sprites"),
    "face": ("🎭", "Face", "talks, lies and bargains the team through the door"),
}
META_SHOW = {"human": "🧑", "elf": "🧝", "dwarf": "⛏️", "ork": "🐗", "troll": "🧌"}
ATTR_HELP = {"body": "toughness, soaking damage", "agility": "guns, blades, sneaking", "reaction": "reflexes, "
             "driving, dodging", "strength": "melee, lifting", "willpower": "grit, resisting magic and drain",
             "logic": "hacking, tech, medicine", "intuition": "noticing things, gut calls", "charisma": "talking "
             "people around"}
SKILL_GROUPS = (("Combat", ("firearms", "close_combat", "throwing")),
                ("Moving", ("athletics", "stealth", "piloting", "survival")),
                ("Talking", ("con", "negotiation", "intimidation", "etiquette", "streetwise")),
                ("Tech", ("hacking", "cybercombat", "electronics", "engineering", "first_aid")),
                ("Senses", ("perception",)),
                ("Magic", ("sorcery", "conjuring")),
                ("Resonance", ("software", "compiling")))


def options_text() -> str:
    """The roles and metatypes, for people who don't know Shadowrun yet."""
    roles = "\n".join(f"{icon} **{i + 1}  {name}** - {what}"
                       for i, (icon, name, what) in enumerate(ROLE_SHOW.values()))
    metas = "\n".join(f"{META_SHOW[m]} **{m.title()}** - {v['blurb']}" for m, v in METATYPES.items())
    return f"**Roles** - what you do on a run\n{roles}\n\n**Metatypes** - what you are\n{metas}"


AWAKENED = {"mage": "magic", "technomancer": "resonance"}
GIFT_SKILLS = {"sorcery": "mage", "conjuring": "mage", "software": "technomancer", "compiling": "technomancer"}


def _w(name, dv, cost, avail, skill="firearms", ap=0, ammo=None, dtype="physical", accuracy=0, smartgun=False,
       heavy=False):
    """AP is the book's (SR5 p. 422-429) - the engine scales it to our lighter armor (sr_lite.scaled_ap). A gun's size
    is the weapon mount it needs on a drone: standard holds an assault rifle or smaller, heavy anything (p. 461)."""
    props = sr_lite._weapon(name, dv, skill, ap, ammo, dtype, accuracy)[1]
    if smartgun:
        props["smartgun"] = True                     # a smartlink works with it
    if skill == "firearms":
        props["size"] = "heavy" if heavy else "standard"
    return {"name": name, "cat": "Weapons", "cost": cost, "avail": avail, "props": props}


def _g(kind, cost, avail):
    from .engine.rules.explosives import catalog
    name, props = catalog(kind)
    return {"name": name, "cat": "Weapons", "cost": cost, "avail": avail, "props": props, "max": 6}


def _soft(kind, rating=3):
    """An autosoft (p. 269, 442): Avail Rating x 2, Rating x 500. It loads onto a drone (shops: buy onto it), which
    runs half its Pilot of them, rounded up. Generic here - the book ties Targeting to a weapon and the rest to a
    model (live T188: the drones came with 3-4 free ones on 2 slots)."""
    return {"name": f"{kind.title()} autosoft ({rating})", "cat": "Drones & vehicles", "cost": rating * 500,
            "avail": str(rating * 2), "props": {"autosoft": kind, "rating": rating}, "max": 4}


# Book prices (SR5, the owner's call 2026-10-24: "full book prices") and the book's Availability - a number, R restricted,
# F forbidden (p. 417). Cyberware at Rating 1 unless the name says otherwise, with the book's Essence. Weapons carry
# this table's damage scale (about 0.6 of the book's) and the book's AP; armor a third of the book's rating.
CATALOG: dict[str, dict] = {
    "hold-out": _w("Streetline Special", 3, 120, "4R", ammo=6),                       # p. 425
    "light-pistol": _w("Colt America L36", 4, 320, "4R", ammo=11),
    "heavy-pistol": _w("Ares Predator V", 5, 725, "5R", ap=-1, ammo=15, accuracy=2, smartgun=True),
    "heavy-revolver": _w("Ruger Super Warhawk", 5, 400, "4R", ap=-2, ammo=6),
    "smg": _w("HK-227", 5, 730, "8R", ammo=28, accuracy=1, smartgun=True),           # p. 427
    "shotgun": _w("Enfield AS-7", 7, 1100, "12F", ap=-1, ammo=10),
    "assault-rifle": _w("Ares Alpha", 7, 2650, "11F", ap=-2, ammo=42, smartgun=True),
    "sniper-rifle": _w("Ranger Arms SM-5", 9, 28000, "16F", ap=-5, ammo=15, accuracy=2, heavy=True),
    "knife": _w("Combat knife", 3, 300, "4", "close_combat", ap=-3),                 # p. 422
    "katana": _w("Katana", 6, 1000, "9R", "close_combat", ap=-3),
    "stun-baton": _w("Stun baton", 5, 750, "6R", "close_combat", ap=-5, dtype="stun"),
    # Throwing knife / shuriken: (STR+1)P, AP -1, 25¥ each, Avail 4R (SR5 p. 424) - a step under the combat knife's
    # (STR+2)P here, as the engine scales its blades. Thrown with Throwing + Agility, and they land where they fall.
    "throwing-knife": {**_w("Throwing knife", 2, 25, "4R", "throwing", ap=-1), "max": 6},
    "shuriken": {**_w("Shuriken", 2, 25, "4R", "throwing", ap=-1), "max": 6},
    "he-grenade": _g("HE grenade", 100, "11F"),                                         # p. 435
    "frag-grenade": _g("frag grenade", 100, "11F"),
    "flash-bang": _g("flash-bang", 100, "6R"),
    "smoke-grenade": _g("smoke grenade", 40, "4R"),
    "thermal-smoke": _g("thermal smoke grenade", 60, "6R"),
    "gas-grenade": _g("CS gas grenade", 240, "10R"),                                    # 40 + the CS (p. 409): 2 + 8R
    # Ingram Valiant LMG: 9P AP-2, 50 (c), 12F, 5,800 (p. 430) - 6 at our scale. It needs a heavy mount on a drone.
    "lmg": _w("Ingram Valiant", 6, 5800, "12F", ap=-2, ammo=50, accuracy=1, heavy=True),
    "synthleather": {"name": "Armor clothing", "cat": "Armor", "cost": 450, "avail": "2", "props": {"armor": 2}},
    "lined-coat": {"name": "Lined coat", "cat": "Armor", "cost": 900, "avail": "4", "props": {"armor": 3}},
    "armored-suit": {"name": "Actioneer business clothes", "cat": "Armor", "cost": 1500, "avail": "8",
                     "props": {"armor": 3}},
    "armored-jacket": {"name": "Armored jacket", "cat": "Armor", "cost": 1000, "avail": "2", "props": {"armor": 4}},
    "full-body": {"name": "Full body armor (with helmet)", "cat": "Armor", "cost": 2500, "avail": "14R",
                  "props": {"armor": 6}},                                               # 2,000 + the helmet's 500
    "medkit": {"name": "Medkit (Rating 2)", "cat": "Gear", "cost": 500, "avail": "2",
               "props": {"bonus": {"first_aid": 2}}},
    # Cyberdecks (p. 439) by the Device Rating the engine gives them: all restricted (they carry hot-sim modules).
    "deck-1": {"name": "Erika MCD-1", "cat": "Matrix & rigging", "cost": 49500, "avail": "3R",
               "props": {"deck": 1, "bonus": {"hacking": 1}}},
    "deck-2": {"name": "Microtronica Azteca 200", "cat": "Matrix & rigging", "cost": 110250, "avail": "6R",
               "props": {"deck": 2, "bonus": {"hacking": 1, "electronics": 1}}},
    "deck-3": {"name": "Novatech Navigator", "cat": "Matrix & rigging", "cost": 205750, "avail": "9R",
               "props": {"deck": 3, "bonus": {"hacking": 1, "cybercombat": 1, "electronics": 1}}},
    "deck-4": {"name": "Sony CIY-720", "cat": "Matrix & rigging", "cost": 345000, "avail": "12R",
               "props": {"deck": 4, "bonus": {"hacking": 2, "cybercombat": 2, "electronics": 1}}},
    "control-rig-1": {"name": "Control rig (1)", "cat": "Matrix & rigging", "cost": 43000, "avail": "5R", "ess": 1.0,
                      "props": {"control_rig": 1}},                                     # p. 452-453
    "control-rig": {"name": "Control rig (2)", "cat": "Matrix & rigging", "cost": 97000, "avail": "10R", "ess": 2.0,
                    "props": {"control_rig": 2}},
    # Drones (p. 466) and vehicles (p. 462-464) are sold as the book's frame: no gun, no autosofts - the Doberman comes
    # with a standard weapon mount and the Steel Lynx a heavy one; the rest is bought below (p. 461, 442).
    "fly-spy": {"name": "MCT Fly-Spy", "cat": "Drones & vehicles", "cost": 2000, "avail": "8", "machine": "fly-spy"},
    "crawler": {"name": "Crawler", "cat": "Drones & vehicles", "cost": 4000, "avail": "4", "machine": "crawler"},
    "roto-drone": {"name": "Roto-drone", "cat": "Drones & vehicles", "cost": 5000, "avail": "6", "machine": "roto-drone"},
    "doberman": {"name": "Doberman", "cat": "Drones & vehicles", "cost": 5000, "avail": "4R", "machine": "doberman"},
    "steel-lynx": {"name": "Steel Lynx", "cat": "Drones & vehicles", "cost": 25000, "avail": "10R",
                   "machine": "steel lynx"},
    "scorpion": {"name": "Harley-Davidson Scorpion", "cat": "Drones & vehicles", "cost": 12000, "avail": "",
                 "machine": "scorpion"},
    "americar": {"name": "Ford Americar", "cat": "Drones & vehicles", "cost": 16000, "avail": "", "machine": "americar"},
    "bulldog": {"name": "GMC Bulldog", "cat": "Drones & vehicles", "cost": 35000, "avail": "", "machine": "bulldog"},
    "weapon-mount": {"name": "Weapon mount (standard)", "cat": "Drones & vehicles", "cost": 2500, "avail": "8F",
                     "props": {"mount": "standard"}, "max": 2},
    "heavy-mount": {"name": "Weapon mount (heavy)", "cat": "Drones & vehicles", "cost": 5000, "avail": "14F",
                    "props": {"mount": "heavy"}, "max": 2},
    "autosoft-targeting": _soft("targeting"),
    "autosoft-evasion": _soft("evasion"),
    "autosoft-maneuvering": _soft("maneuvering"),
    "autosoft-clearsight": _soft("clearsight"),
    "autosoft-stealth": _soft("stealth"),
    # Foci (p. 326): a power focus Force x 18,000, (Force x 4)R; a spirit (summoning) focus Force x 4,000, (Force x 3)R.
    "power-focus-1": {"name": "Power focus (1)", "cat": "Magic", "cost": 18000, "avail": "4R",
                      "props": {"bonus": {"sorcery": 1}}, "needs": "magic"},
    "power-focus-2": {"name": "Power focus (2)", "cat": "Magic", "cost": 36000, "avail": "8R",
                      "props": {"bonus": {"sorcery": 2}}, "needs": "magic"},
    "summoning-focus": {"name": "Summoning focus (2)", "cat": "Magic", "cost": 8000, "avail": "6R",
                        "props": {"bonus": {"conjuring": 2}}, "needs": "magic"},
    # Cyberware (p. 451-456) at the book's Essence; cybereyes are Rating 1 (4,000) with low-light (1,500) and vision
    # magnification (2,000) in their capacity.
    "datajack": {"name": "Datajack", "cat": "Augmentations", "cost": 1000, "avail": "2", "ess": 0.1,
                 "effect": "jack in without trodes"},
    "smartlink": {"name": "Smartlink", "cat": "Augmentations", "cost": 4000, "avail": "8R", "ess": 0.2,
                  "props": {"bonus": {"firearms": 2}}},
    "cybereyes": {"name": "Cybereyes (low-light, vision mag)", "cat": "Augmentations", "cost": 7500, "avail": "4",
                  "ess": 0.2, "props": {"bonus": {"perception": 1}}},
    "pheromones": {"name": "Tailored pheromones", "cat": "Augmentations", "cost": 31000, "avail": "4R", "ess": 0.2,
                   "props": {"bonus": {"con": 1, "negotiation": 1, "etiquette": 1}}},
    "wired-reflexes": {"name": "Wired reflexes", "cat": "Augmentations", "cost": 39000, "avail": "8R", "ess": 2.0,
                       "attrs": {"reaction": 1}, "props": {"initiative_dice": 1},
                       "effect": "+1 Reaction, +1 initiative die"},
    "muscle-replacement": {"name": "Muscle replacement", "cat": "Augmentations", "cost": 25000, "avail": "5R",
                           "ess": 1.0, "attrs": {"strength": 1, "agility": 1}},
}
CATEGORIES = ("Weapons", "Armor", "Gear", "Matrix & rigging", "Drones & vehicles", "Magic", "Augmentations")
KITS = {
    "street_samurai": ["heavy-pistol", "katana", "armored-jacket", "he-grenade", "he-grenade", "smartlink",
                       "wired-reflexes", "muscle-replacement"],
    # (the book's decker carries a Device Rating 2 deck, p. 120; a 3 still leaves change from Priority B)
    "decker": ["deck-3", "light-pistol", "lined-coat", "fly-spy", "autosoft-clearsight", "autosoft-stealth",
               "datajack"],
    # the drones come bare: the Roto-drone gets a mount and two autosofts, the Fly-Spy its two; the HK-227 goes on the
    # mount in play (mount_weapon)
    "rigger": ["control-rig", "light-pistol", "armored-jacket", "roto-drone", "fly-spy", "weapon-mount", "smg",
               "autosoft-targeting", "autosoft-evasion", "autosoft-clearsight", "autosoft-stealth"],
    "mage": ["power-focus-2", "light-pistol", "lined-coat"],
    "technomancer": ["heavy-revolver", "lined-coat", "medkit"],
    "face": ["pheromones", "hold-out", "armored-suit", "americar"],
}


def avail_of(item: dict) -> tuple[int, str]:
    """(the Availability number, '' / 'R' / 'F') - '10R' is (10, 'R'), '' (anyone can buy it) is (0, '')."""
    m = re.match(r"\s*(\d*)\s*([RF]?)", str(item.get("avail") or ""), re.I)
    return (int(m.group(1) or 0), m.group(2).upper()) if m else (0, "")


def avail_text(item: dict) -> str:
    """'Avail 10R' for the cards; '' for what anyone can buy."""
    return f"Avail {item['avail']}" if item.get("avail") else ""


# ── the numbers ─────────────────────────────────────────────────────────

def base(d: dict, a: str) -> int:
    return 1 + METATYPES[d["metatype"]]["bonus"].get(a, 0)


def cap(d: dict, a: str) -> int:
    return METATYPES[d["metatype"]]["max"].get(a, 6)


def attr_left(d: dict) -> int:
    return ATTR_POINTS - sum(d["attrs"][a] - base(d, a) for a in BASE_ATTRS)


def skill_left(d: dict) -> int:
    return SKILL_POINTS - sum(d["skills"].values())


def budget(d: dict) -> int:
    return NUYEN_AWAKENED if d["role"] in AWAKENED else NUYEN


def spent(d: dict) -> int:
    return sum(CATALOG[k]["cost"] * q for k, q in d["gear"].items())


def essence(d: dict) -> float:
    return round(6.0 - sum(CATALOG[k].get("ess", 0) * q for k, q in d["gear"].items()), 2)


def kit_plan(d: dict) -> tuple[list[tuple[str, int]], list[str]]:
    """Where the draft's autosofts and weapon mounts go: ([(catalog key, index of the drone it loads onto)], [keys with
    no drone that has room]). Drones come as bare frames now, so these are what make them work - in the order bought,
    each onto the first drone with room (autosofts: half its Pilot, rounded up, p. 269; mounts: its slots, p. 461)."""
    frames = []
    for k, q in d["gear"].items():
        if CATALOG[k].get("machine"):
            m = machines.MODELS[CATALOG[k]["machine"]]
            frames += [{"softs": set(), "room": machines.soft_slots(m["stats"]["pilot"]), "slots": m["slots"],
                        "used": sum(machines.MOUNT_SLOTS[x] for x in m["mounts"])} for _ in range(q)]
    placed, left = [], []
    for k, q in d["gear"].items():
        p = CATALOG[k].get("props") or {}
        for _ in range(q if (p.get("autosoft") or p.get("mount")) else 0):
            if p.get("autosoft"):
                i = next((i for i, f in enumerate(frames) if p["autosoft"] not in f["softs"]
                          and len(f["softs"]) < f["room"]), None)
                if i is not None:
                    frames[i]["softs"].add(p["autosoft"])
            else:
                need = machines.MOUNT_SLOTS[p["mount"]]
                i = next((i for i, f in enumerate(frames) if f["used"] + need <= f["slots"]), None)
                if i is not None:
                    frames[i]["used"] += need
            if i is None:
                left.append(k)
            else:
                placed.append((k, i))
    return placed, left


def gift(d: dict) -> int:
    """Magic or Resonance after augmentations: every Essence point lost (rounded up) costs one."""
    if d["role"] not in AWAKENED:
        return 0
    return max(0, 6 - math.ceil(6.0 - essence(d) - 1e-9))


def augmented(d: dict) -> dict[str, int]:
    out = {a: d["attrs"][a] for a in BASE_ATTRS}
    for k, q in d["gear"].items():
        for a, v in CATALOG[k].get("attrs", {}).items():
            out[a] = min(cap(d, a) + AUG_MAX, out[a] + v * q)
    return out


def _fit(values: dict[str, int], floors: dict[str, int], caps: dict[str, int], points: int) -> dict[str, int]:
    """Clamp to floor..cap, then trim the lowest (or top up the highest) until exactly within budget."""
    out = {k: max(floors.get(k, 0), min(caps[k], int(v))) for k, v in values.items()}
    used = lambda: sum(out[k] - floors.get(k, 0) for k in out)                      # noqa: E731
    while used() > points:
        k = min((k for k in out if out[k] > floors.get(k, 0)), key=lambda k: (out[k], k))
        out[k] -= 1
    order = sorted(out, key=lambda k: (-values.get(k, 0), k))
    while used() < points and any(out[k] < caps[k] for k in order if values.get(k, 0) > floors.get(k, 0)):
        for k in order:
            if used() < points and out[k] < caps[k] and values.get(k, 0) > floors.get(k, 0):
                out[k] += 1
    return out


def fit_attrs(d: dict, wanted: dict[str, int]) -> dict[str, int]:
    floors = {a: base(d, a) for a in BASE_ATTRS}
    want = {a: max(int(wanted.get(a, 1)), floors[a]) for a in BASE_ATTRS}
    return _fit(want, floors, {a: cap(d, a) for a in BASE_ATTRS}, ATTR_POINTS)


def fit_skills(d: dict, wanted: dict[str, int]) -> dict[str, int]:
    ok = {k: int(v) for k, v in wanted.items() if k in sr_lite.SKILLS and int(v) > 0
          and GIFT_SKILLS.get(k, d["role"]) == d["role"]}
    out = _fit(ok, {}, {k: SKILL_MAX for k in ok}, min(SKILL_POINTS, sum(min(SKILL_MAX, v) for v in ok.values())))
    return {k: v for k, v in out.items() if v > 0}


def new_draft(role: str = "street_samurai", metatype: str = "human") -> dict:
    d = {"step": "concept", "name": "", "pronouns": "", "metatype": metatype, "role": role, "attrs": {},
         "skills": {}, "spells": [], "forms": [], "gear": {}, "concept": "", "look": "", "pitch": "",
         "name_ideas": [], "picks": {}}
    return apply_role(d, role)


def apply_role(d: dict, role: str) -> dict:
    """A role's starting build, fitted to the metatype: its attribute and skill spread, kit and gifts."""
    if role not in ROLES:
        raise LedgerError(f"No role '{role}'. Roles: {', '.join(ROLES)}.")
    arch = sr_lite.ARCHETYPES[role]
    d["role"] = role
    d["attrs"] = fit_attrs(d, arch["attrs"])
    d["skills"] = fit_skills(d, arch["skills"])
    d["spells"] = list(arch.get("spells", []))[:SPELL_PICKS]
    d["forms"] = list(arch.get("forms", []))[:FORM_PICKS]
    d["gear"] = {}
    for k in KITS[role]:
        d["gear"][k] = d["gear"].get(k, 0) + 1
    return d


def set_metatype(d: dict, metatype: str) -> dict:
    if metatype not in METATYPES:
        raise LedgerError(f"No metatype '{metatype}'. Options: {', '.join(METATYPES)}.")
    wanted = dict(d["attrs"])
    d["metatype"] = metatype
    d["attrs"] = fit_attrs(d, wanted)
    return d


def problems(d: dict) -> list[str]:
    out = []
    if not d["name"]:
        out.append("no name yet")
    left = attr_left(d)
    if left < 0:
        out.append(f"attributes are {-left} point(s) over")
    for a in BASE_ATTRS:
        if not base(d, a) <= d["attrs"][a] <= cap(d, a):
            out.append(f"{a.title()} must be {base(d, a)}-{cap(d, a)}")
    if skill_left(d) < 0:
        out.append(f"skills are {-skill_left(d)} point(s) over")
    for k, v in d["skills"].items():
        if v > SKILL_MAX:
            out.append(f"{sr_lite.nice(k)} is over {SKILL_MAX}")
        if GIFT_SKILLS.get(k, d["role"]) != d["role"]:
            out.append(f"{sr_lite.nice(k)} needs a {GIFT_SKILLS[k]}")
    if spent(d) > budget(d):
        out.append(f"gear is {spent(d) - budget(d):,} nuyen over")
    if essence(d) < 0.5:
        out.append("too much chrome: Essence would drop below 0.5")
    if d["role"] in AWAKENED and gift(d) < 1:
        out.append(f"that much chrome burns out your {AWAKENED[d['role']].title()}")
    for k in d["gear"]:
        if CATALOG[k].get("needs") == "magic" and d["role"] != "mage":
            out.append(f"{CATALOG[k]['name']} needs a mage")
        if avail_of(CATALOG[k])[0] > AVAIL_MAX:
            out.append(f"{CATALOG[k]['name']} is Availability {CATALOG[k]['avail']} - over {AVAIL_MAX} at creation")
    for k in dict.fromkeys(kit_plan(d)[1]):
        out.append(f"{CATALOG[k]['name']} needs a drone with room for it")
    if d["role"] == "mage" and len(d["spells"]) > SPELL_PICKS:
        out.append(f"pick at most {SPELL_PICKS} spells")
    if d["role"] == "technomancer" and len(d["forms"]) > FORM_PICKS:
        out.append(f"pick at most {FORM_PICKS} complex forms")
    # (an empty list on the sheet means every spell or form - live review: toggling every pick off built a caster who
    # knew all 16 spells, past the six-pick limit)
    if d["role"] == "mage" and not d["spells"]:
        out.append("pick at least one spell")
    if d["role"] == "technomancer" and not d["forms"]:
        out.append("pick at least one complex form")
    return out


# ── player edits: "agility +1, logic -1" / "hacking 6, stealth +2" ──────

ABBREV = {v.lower(): k for k, v in sr_lite.ABBR.items()}
EDIT = re.compile(r"([a-z][a-z _]*?)\s*([+-]?\s*\d+)")


def _name_of(word: str, names) -> str | None:
    w = word.strip().lower().replace(" ", "_")
    if w in names:
        return w
    if w in ABBREV and ABBREV[w] in names:
        return ABBREV[w]
    hits = [n for n in names if n.startswith(w)] if len(w) >= 3 else []
    return hits[0] if len(hits) == 1 else None


def edit(d: dict, what: str, text: str) -> list[str]:
    """Apply edits to attributes or skills; each change is checked against caps and the budget."""
    names = BASE_ATTRS if what == "attrs" else tuple(sr_lite.SKILLS)
    table = d["attrs"] if what == "attrs" else d["skills"]
    notes = []
    pairs = EDIT.findall(text.lower())
    if not pairs:
        return [f"Try something like `{'agility +1, logic -1' if what == 'attrs' else 'stealth +2, con 3'}`."]
    for word, num in pairs:
        key = _name_of(word, names)
        if not key:
            notes.append(f"'{word.strip()}' isn't a{'n attribute' if what == 'attrs' else ' skill'}")
            continue
        num = num.replace(" ", "")
        cur = table.get(key, 0)
        new = cur + int(num) if num[0] in "+-" else int(num)
        if what == "attrs":
            lo, hi = base(d, key), cap(d, key)
        else:
            lo, hi = 0, SKILL_MAX
            if GIFT_SKILLS.get(key, d["role"]) != d["role"] and new > 0:
                notes.append(f"{sr_lite.nice(key)} needs a {GIFT_SKILLS[key]}")
                continue
        if not lo <= new <= hi:
            notes.append(f"{sr_lite.nice(key)} has to stay {lo}-{hi}")
            continue
        left = (attr_left(d) if what == "attrs" else skill_left(d)) - (new - cur)
        if left < 0:
            notes.append(f"{sr_lite.nice(key)} {new} is {-left} point(s) over budget")
            continue
        if what == "skills" and new == 0:
            table.pop(key, None)
        else:
            table[key] = new
    return notes


def attrs_text(d: dict) -> str:
    return "  ".join(f"{sr_lite.ABBR[a]} {d['attrs'][a]}" for a in BASE_ATTRS)


def skills_text(d: dict) -> str:
    return ", ".join(f"{sr_lite.nice(k)} {v}" for k, v in sorted(d["skills"].items(), key=lambda kv: -kv[1]))


def set_all(d: dict, what: str, text: str) -> list[str]:
    """A whole spread at once (a form submits everything together): checked as a set, applied only if it fits.
    Attributes left out keep their value; skills left out are dropped."""
    names = BASE_ATTRS if what == "attrs" else tuple(sr_lite.SKILLS)
    new = dict(d["attrs"]) if what == "attrs" else {}
    errors = []
    for word, num in EDIT.findall(text.lower()):
        key = _name_of(word, names)
        if not key:
            errors.append(f"'{word.strip()}' isn't a{'n attribute' if what == 'attrs' else ' skill'}")
            continue
        new[key] = int(num.replace(" ", "").lstrip("+"))
    for key, v in new.items():
        if what == "attrs" and not base(d, key) <= v <= cap(d, key):
            errors.append(f"{sr_lite.ABBR[key]} has to be {base(d, key)}-{cap(d, key)}")
        if what == "skills":
            if not 0 <= v <= SKILL_MAX:
                errors.append(f"{sr_lite.nice(key)} has to be 0-{SKILL_MAX}")
            elif v and GIFT_SKILLS.get(key, d["role"]) != d["role"]:
                errors.append(f"{sr_lite.nice(key)} needs a {GIFT_SKILLS[key]}")
    used = (sum(new[a] - base(d, a) for a in BASE_ATTRS) if what == "attrs" else sum(new.values()))
    budget = ATTR_POINTS if what == "attrs" else SKILL_POINTS
    if used > budget:
        errors.append(f"that's {used} points - you have {budget}")
    if not errors:
        if what == "attrs":
            d["attrs"] = new
        else:
            d["skills"] = {k: v for k, v in new.items() if v > 0}
    return errors


def set_category(d: dict, cat: str, keys: list[str]) -> list[str]:
    """Make one gear category exactly these items (one each; already-owned quantities are kept)."""
    notes = []
    for k in [k for k in d["gear"] if CATALOG[k]["cat"] == cat and k not in keys]:
        del d["gear"][k]
    for k in keys:
        if k in CATALOG and CATALOG[k]["cat"] == cat and k not in d["gear"]:
            notes += shop(d, "buy", k)
    return notes


def gear_menu(d: dict) -> list[tuple[int, str]]:
    """Numbered (stable) catalog lines the player can buy from."""
    out, n = [], 0
    for cat in CATEGORIES:
        for k, item in CATALOG.items():
            if item["cat"] != cat:
                continue
            n += 1
            if item.get("needs") == "magic" and d["role"] != "mage":
                continue
            out.append((n, k))
    return out


def _key(d: dict, ref: str) -> str | None:
    ref = ref.strip().lower()
    nums = dict(gear_menu(d))
    if ref.isdigit():
        return nums.get(int(ref))
    if ref in CATALOG:
        return ref
    for test in (lambda k, n: k.startswith(ref),                               # most specific first
                 lambda k, n: any(w.startswith(ref) for w in re.findall(r"[a-z0-9]+", n)),
                 lambda k, n: ref in n):
        hits = [k for k, item in CATALOG.items() if ref and test(k, item["name"].lower())]
        if hits:
            return hits[0] if len(hits) == 1 else None
    return None


def shop(d: dict, verb: str, text: str) -> list[str]:
    """'buy 3', 'buy 12 x2', 'sell katana'."""
    notes = []
    for part in re.split(r",|\band\b", text):
        m = re.match(r"\s*(.+?)(?:\s*x\s*(\d+))?\s*$", part)
        if not m or not m.group(1).strip():
            continue
        k = _key(d, m.group(1))
        qty = int(m.group(2) or 1)
        if not k:
            notes.append(f"No item '{m.group(1).strip()}' - use the numbers from the list")
            continue
        item = CATALOG[k]
        if verb == "sell":
            have = d["gear"].get(k, 0)
            if not have:
                notes.append(f"You don't have {item['name']}")
                continue
            d["gear"][k] = have - min(qty, have)
            if not d["gear"][k]:
                del d["gear"][k]
            continue
        if item.get("needs") == "magic" and d["role"] != "mage":
            notes.append(f"{item['name']} needs a mage")
            continue
        if avail_of(item)[0] > AVAIL_MAX:
            notes.append(f"{item['name']} is Availability {item['avail']} - nothing over {AVAIL_MAX} at creation "
                         "(find it in play)")
            continue
        limit = item.get("max", 1)
        if d["gear"].get(k, 0) + qty > limit:
            notes.append(f"{item['name']}: at most {limit}")
            continue
        if spent(d) + item["cost"] * qty > budget(d):
            notes.append(f"{item['name']} costs {item['cost'] * qty:,} - you have {budget(d) - spent(d):,} left")
            continue
        if essence(d) - item.get("ess", 0) * qty < 0.5:
            notes.append(f"{item['name']} would take your Essence below 0.5")
            continue
        stranded = Counter(kit_plan(d)[1])
        d["gear"][k] = d["gear"].get(k, 0) + qty
        # An autosoft or a mount with no drone to go on - or one that pushes kit already placed off its drone: the
        # plan places in the order bought, so a second Targeting evicted the Stealth after it (review E2), and the
        # draft failed for an item the player never touched.
        if Counter(kit_plan(d)[1]) - stranded:
            d["gear"][k] -= qty
            if not d["gear"][k]:
                del d["gear"][k]
            notes.append(f"{item['name']} goes onto a drone, and none of yours has room for it - "
                         + ("buy the drone first" if not any(CATALOG[g].get("machine") for g in d["gear"])
                            else "sell some of their kit first, or buy another drone"))
    return notes


def toggle(d: dict, field: str, text: str) -> list[str]:
    """Spells or complex forms by number: '2 5 7' toggles them."""
    from .engine.rules import magic, resonance
    names = list(magic.SPELLS if field == "spells" else resonance.FORMS)
    limit = SPELL_PICKS if field == "spells" else FORM_PICKS
    notes = []
    for tok in re.findall(r"\d+", text):
        i = int(tok) - 1
        if not 0 <= i < len(names):
            notes.append(f"No #{tok}")
            continue
        key = names[i]
        if key in d[field]:
            d[field].remove(key)
        elif len(d[field]) >= limit:
            notes.append(f"Already {limit} picked - drop one first")
        else:
            d[field].append(key)
    return notes


# ── the GM's proposal ───────────────────────────────────────────────────

SUGGEST_SYSTEM = """You are the GM of a Shadowrun game helping a player build a character from their concept. \
Propose ONE complete, legal build that fits the concept and plays well at the table.

Rules (SR-lite):
- metatypes: {metatypes}
- roles: {roles}
- attributes ({attrs}) start at 1 plus the metatype bonus; spend exactly {attr_points} points raising them; natural \
max 6 unless the metatype says otherwise.
- skills: {skill_points} points, max {skill_max} each. Skills: {skills}. Sorcery/Conjuring only for a mage; \
Software/Compiling only for a technomancer.
- mages pick up to {spells} spells; technomancers up to {forms} complex forms.
- nuyen: {nuyen:,} ({nuyen_awakened:,} for a mage or technomancer) - SR5's own prices. Augmentations cost Essence \
(start 6); a mage or technomancer loses 1 Magic/Resonance per Essence point lost, so give them little or no chrome. \
Nothing over Availability {avail_max}.
- gear catalog (key: name - price, Availability): {catalog}
- drones come as bare frames: a drone needs its autosofts bought (Pilot 3 runs two: targeting and evasion for a \
fighter, clearsight and stealth for a spy) and a weapon mount before it can carry a gun.

Armor doesn't stack: buy one armor item. Also: pitch (2-3 sentences in the GM's voice, to the player: who this \
runner is and why this build), three name ideas that suit the concept (street names welcome), a look (1-2 sentences \
of appearance a portrait artist can paint) and a personality (one sentence). Don't assume the character's gender or \
pronouns unless the concept states them - the player picks pronouns next - so write the look and personality as \
third-person description with no pronouns ("Broad-shouldered ork with a faded Lone Star tattoo..."; "Dry, \
disciplined, still thinks like a cop")."""


def suggest_schema() -> dict:
    from .engine.rules import magic, resonance
    s = {"type": "string"}
    return {"type": "object", "additionalProperties": False, "properties": {
        "pitch": s, "name_ideas": {"type": "array", "items": s},
        "metatype": {"type": "string", "enum": list(METATYPES)}, "role": {"type": "string", "enum": list(ROLES)},
        "attrs": {"type": "object", "additionalProperties": False, "required": list(BASE_ATTRS),
                  "properties": {a: {"type": "integer"} for a in BASE_ATTRS}},
        "skills": {"type": "array", "items": {"type": "object", "additionalProperties": False,
                                              "required": ["skill", "rating"],
                                              "properties": {"skill": {"type": "string", "enum": list(sr_lite.SKILLS)},
                                                             "rating": {"type": "integer"}}}},
        "gear": {"type": "array", "items": {"type": "string", "enum": list(CATALOG)}},
        "spells": {"type": "array", "items": {"type": "string", "enum": list(magic.SPELLS)}},
        "forms": {"type": "array", "items": {"type": "string", "enum": list(resonance.FORMS)}},
        "look": s, "personality": s},
        "required": ["pitch", "name_ideas", "metatype", "role", "attrs", "skills", "gear", "spells", "forms", "look",
                     "personality"]}


def suggest(game, concept: str) -> dict:
    from .engine.rules import magic, resonance
    system = SUGGEST_SYSTEM.format(
        metatypes="; ".join(f"{k} ({v['blurb']})" for k, v in METATYPES.items()),
        roles="; ".join(f"{k} ({v})" for k, v in ROLES.items()), attrs=", ".join(BASE_ATTRS),
        attr_points=ATTR_POINTS, skill_points=SKILL_POINTS, skill_max=SKILL_MAX, skills=", ".join(sr_lite.SKILLS),
        spells=SPELL_PICKS, forms=FORM_PICKS, nuyen=NUYEN, nuyen_awakened=NUYEN_AWAKENED, avail_max=AVAIL_MAX,
        catalog="; ".join(f"{k}: {v['name']} - {v['cost']}" + (f", {v['avail']}" if v.get("avail") else "")
                          + (f" (Essence {v['ess']})" if v.get("ess") else "") for k, v in CATALOG.items()))
    del magic, resonance
    return game.llm.structured(game.settings.models.askdm, system, f"The player's concept: {concept}",
                               suggest_schema(), max_tokens=3000, effort="low", purpose="chargen")


def apply_suggestion(d: dict, s: dict) -> dict:
    """Take the GM's proposal - repaired to legality by the engine, never trusted as-is."""
    d["metatype"] = s.get("metatype") if s.get("metatype") in METATYPES else d["metatype"]
    apply_role(d, s.get("role") if s.get("role") in ROLES else d["role"])
    d["attrs"] = fit_attrs(d, s.get("attrs") or d["attrs"])
    wanted = {r["skill"]: r["rating"] for r in s.get("skills", []) if isinstance(r, dict) and r.get("skill")}
    if wanted:
        d["skills"] = fit_skills(d, wanted)
    if d["role"] == "mage" and s.get("spells"):
        d["spells"] = list(dict.fromkeys(s["spells"]))[:SPELL_PICKS]
    if d["role"] == "technomancer" and s.get("forms"):
        d["forms"] = list(dict.fromkeys(s["forms"]))[:FORM_PICKS]
    if s.get("gear"):
        d["gear"] = {}
        for k in sorted(s["gear"], key=lambda k: not CATALOG.get(k, {}).get("machine")):   # (drones before what
            if k in CATALOG:                                                               # goes onto them)
                shop(d, "buy", k)
    d["pitch"] = (s.get("pitch") or "").strip()
    d["name_ideas"] = [n for n in (s.get("name_ideas") or []) if n][:3]
    d["look"] = " ".join(x for x in ((s.get("look") or "").strip(), (s.get("personality") or "").strip()) if x)
    d["picks"] = {"metatype": d["metatype"], "role": d["role"]}
    return d


# ── into the world ──────────────────────────────────────────────────────

def describe(d: dict) -> str:
    meta = d["metatype"]
    base_text = d["look"] or f"A {meta} {d['role'].replace('_', ' ')}."
    return base_text + (f" ({d['pronouns']})" if d["pronouns"] else "")


def build(game, d: dict, handle: str, turn: int) -> str:
    """The finished draft becomes a PC: stats, skills, gifts, gear, chrome and drones."""
    bad = problems(d)
    if bad:
        raise LedgerError("Not done yet: " + "; ".join(bad) + ".")
    L = game.ledger
    if L.find(d["name"]):
        raise LedgerError(f"Someone called {d['name']} already exists - pick another name.")
    props = {"archetype": d["role"], "metatype": d["metatype"], "pronouns": d["pronouns"], "concept": d["concept"]}
    if d["role"] == "mage":
        props["spells"] = list(d["spells"])
    if d["role"] == "technomancer":
        props["forms"] = list(d["forms"])
    eid = L.create_entity("pc", d["name"], describe(d), tier=2, player=handle, props=props, turn=turn)
    attrs = augmented(d) | {"edge": METATYPES[d["metatype"]]["edge"]}
    if d["role"] in AWAKENED:
        attrs[AWAKENED[d["role"]]] = gift(d)
    gear, drones = [], []
    for k, q in d["gear"].items():
        item = CATALOG[k]
        if item.get("machine"):
            drones += [item["machine"]] * q
            continue
        if (item.get("props") or {}).get("autosoft") or (item.get("props") or {}).get("mount"):
            continue                                  # (they go onto the drones: kit_plan, below)
        props_ = dict(item.get("props", {}))
        if item["cat"] == "Augmentations" or item.get("ess"):
            props_.update(augmentation=True, essence=item.get("ess", 0))
            if item.get("effect") or item.get("attrs"):
                props_["effect"] = item.get("effect") or ", ".join(f"+{v} {a.title()}" for a, v in item["attrs"].items())
        gear.append((item["name"], props_, q))
    block = {"attrs": attrs, "skills": dict(d["skills"]), "essence": essence(d), "gear": gear, "drones": [],
             "nuyen": min(CASH_CAP, budget(d) - spent(d))}
    sr_lite._apply_block(L, eid, block, turn, d["name"], tag_items=True)
    built = [machines.build_machine(L, f"{d['name']}'s {machines.MODELS[key]['name']}", key, eid, turn, equipped=False)
             for key in drones]                       # bought frames: no free gun or autosofts (§7a)
    for k, i in kit_plan(d)[0]:
        item = CATALOG[k]
        iid = L.create_entity("item", f"{d['name']}'s {item['name']}", item["name"], tier=0,
                              props=dict(item["props"]), turn=turn)
        L.give(built[i], iid, 1)
    L.set_stat(eid, "karma", 0)
    game.sub.ensure_entity(L.get(eid), turn)
    return eid
