"""Chronicles (DESIGN.md §8b): the story retold from inside one character's head.

The substrate already scopes memory to witnesses, so every character has their own record of the same events:
the turns they lived through first-hand (whispers included, if they were the one whispering or noticed), the
moves they made offscreen while no player watched (W# slices they're a member of), what they heard and from
whom (hearsay can be wrong), and how their feelings about people changed (beliefs, superseded ones included -
that's the arc). A chronicle lays that out in story order and has the GM retell it in their voice, knowing only
what they knew. Kaz's night and Razor's night at the Lucky Shot are different stories.
"""
from __future__ import annotations

from .dm.prompts import FICTION_NOTE
from .engine import clock

CHRONICLE_SYSTEM = FICTION_NOTE + """ You retell a Shadowrun campaign from inside one character's head. Use ONLY \
the record you're given: what they witnessed first-hand, what they did when nobody else was watching, what they \
heard (and from whom - hearsay can be wrong), and how their feelings changed. They know nothing else: if the record \
never shows them learning something, they don't know it - let them guess, misread and worry where it leaves gaps, \
the way people do. Write in first person, in their voice (persona and description below), past tense, in scenes, \
600-900 words, with a short title on the first line. Keep the real order of events and the story times. No game \
mechanics, dice or ids."""


def record(game, eid: str) -> dict:
    """Everything one character lived, heard and felt - in the order it happened to them."""
    L, S = game.ledger, game.sub
    ent = L.require(eid)
    items = []
    for m in S.witnessed_slices(eid, 400):
        vis = m.get("visibility") or "public"
        tag = {"offscreen": "on my own, unseen", "private": "a private moment"}.get(vis, "I was there")
        when = clock.short(m["story_time"]) if m.get("story_time") is not None else f"turn {m['created_turn']}"
        items.append((m["created_turn"], 0, f"({when}, {tag}) {m['text']}"))
    for h in game.conn.execute("SELECT k.turn, k.how, k.source, n.text FROM knows k JOIN nodes n ON n.id=k.node_id "
                               "WHERE k.holder=?", (eid,)):
        src = (L.get(h["source"]) or {}).get("name", "someone") if h["source"] else "someone"
        heard = ("on the line" if h["how"] == "on the line" else
                 f"a rumor through {src}" if h["how"] == "rumor" else f"told by {src}")
        items.append((h["turn"], 1, f"(heard, {heard}) "
                                    f"{h['text']}"))
    for b in game.conn.execute(
            "SELECT n.id, n.text, n.created_turn FROM nodes n WHERE n.kind='belief' AND n.id IN "
            "(SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='holds')", (eid,) * 3):
        items.append((b["created_turn"], 2, f"(what I came to feel) {b['text']}"))
    items.sort(key=lambda t: (t[0], t[1]))
    from .dm import world
    return {"name": ent["name"], "kind": ent["kind"], "description": ent["description"],
            "pronouns": ent["props"].get("pronouns", ""), "persona": world.persona_line(ent) or "",
            "lines": [t[2] for t in items]}


def write(game, eid: str, max_lines: int = 160) -> str:
    r = record(game, eid)
    if not r["lines"]:
        return f"{r['name']} hasn't lived through anything in this story yet."
    user = (f"CHARACTER: {r['name']} ({r['kind']})" + (f", {r['pronouns']}" if r["pronouns"] else "")
            + f"\nDESCRIPTION: {r['description']}" + (f"\nPERSONA: {r['persona']}" if r["persona"] else "")
            + "\n\nTHEIR RECORD (in the order it happened to them):\n" + "\n".join(f"- {x}" for x in r["lines"][-max_lines:]))
    from .dm import spoilers                         # (never a name the table hasn't learned - §12l)
    return spoilers.answer(game, game.llm.text(game.settings.models.dm, CHRONICLE_SYSTEM, user, max_tokens=8000,
                                               effort="low", fallback=game.settings.models.commit,
                                               purpose="chronicle").strip(), "A chronicle", game.turn_no())


def save(game, eid: str) -> str:
    """Write it and keep a copy next to the campaign (campaigns/stories/<world>-pov-<who>.md)."""
    text = write(game, eid)
    out = game.path.parent / "stories" / f"{game.path.stem}-pov-{eid}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    return text
