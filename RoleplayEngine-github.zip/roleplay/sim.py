"""Physics lab: replay a recorded campaign's turn structure under different touch policies.

    python -m roleplay.sim autoplay_v1

No API calls. Takes the real hypergraph a session produced (which nodes were born when, who was in
each turn, what each turn recalled) and re-runs the energy physics with alternative rules, so the
forgetting rate and the warm-set regime (V5 §7: drain / stable / lump) can be tuned offline.
"""
from __future__ import annotations

import argparse
import math
import sqlite3
import sys
from dataclasses import replace
from pathlib import Path

from .config import CAMPAIGN_DIR, Knobs
from .substrate.physics import EnergyGraph, touch_all

POLICIES = {
    # name: (slice quantum, member quantum, retrieval quantum, renormalize at scene change)
    "v1 (every member full)": (1.0, 1.0, 1.0, False),
    "v2 (slice + retrieval 0.5)": (1.0, 0.0, 0.5, False),
    "slice only": (1.0, 0.0, 0.0, False),
    "v2 + members 0.25": (1.0, 0.25, 0.5, False),
    "gentle (slice + retrieval 0.25)": (1.0, 0.0, 0.25, False),
}


def load_structure(path: Path):
    c = sqlite3.connect(str(path))
    c.row_factory = sqlite3.Row
    nodes = {r["id"]: dict(r) for r in c.execute("SELECT id, kind, created_turn, scene_id, text FROM nodes "
                                                 "WHERE kind NOT IN ('note','merged')")}
    links = [dict(r) for r in c.execute("SELECT id, a, b, kind, strength FROM links")]
    members = {}
    for r in c.execute("SELECT slice_id, node_id, role FROM members"):
        members.setdefault(r["slice_id"], []).append((r["node_id"], r["role"]))
    committed = {f"T{r['id']}" for r in c.execute("SELECT id FROM turns WHERE status IN ('committed','seed')")}
    c.close()
    slices = sorted((n for n in nodes.values() if n["kind"] == "slice" and n["id"] in committed),
                    key=lambda n: n["created_turn"])
    return nodes, links, members, slices


def gini(values: list[float]) -> float:
    v = sorted(values)
    n, total = len(v), sum(v)
    if not n or not total:
        return 0.0
    return 2 * sum((i + 1) * x for i, x in enumerate(v)) / (n * total) - (n + 1) / n


def simulate(path: Path, policy: tuple, knobs: Knobs, watch: list[str]) -> dict:
    nodes, links, members, slices = load_structure(path)
    q_slice, q_member, q_retrieval, renorm = policy
    born = {nid: n["created_turn"] for nid, n in nodes.items()}
    energy: dict[str, float] = {}
    live_links: list[tuple] = []
    pending = sorted(links, key=lambda l: max(born.get(l["a"], 0), born.get(l["b"], 0)))
    rows, last_scene, li = [], None, 0
    for s in slices:
        t = s["created_turn"]
        mean = (sum(energy.values()) / len(energy)) if energy else knobs.bootstrap_energy
        for nid, b in born.items():                       # births up to this turn, at the mean
            if b <= t and nid not in energy:
                energy[nid] = mean
        while li < len(pending) and max(born.get(pending[li]["a"], 0), born.get(pending[li]["b"], 0)) <= t:
            l = pending[li]
            if l["a"] in energy and l["b"] in energy:
                live_links.append((l["id"], l["a"], l["b"], l["strength"]))
            li += 1
        if renorm and last_scene is not None and s["scene_id"] != last_scene:
            m = sum(energy.values()) / len(energy)
            energy = {k: v / m for k, v in energy.items()}
        last_scene = s["scene_id"]
        g = EnergyGraph(energy, live_links)
        mem = members.get(s["id"], [])
        touch_all(g, knobs, [s["id"]], q_slice)
        if q_member:
            touch_all(g, knobs, [n for n, r in mem if r in ("actor", "target", "present")], q_member)
        if q_retrieval:
            touch_all(g, knobs, [n for n, r in mem if r in ("recalled", "mentioned")], q_retrieval)
        energy = g.energy
        vals = list(energy.values())
        m = sum(vals) / len(vals)
        rows.append({"turn": t, "mean": m, "n": len(vals), "warm": sum(1 for v in vals if v >= m) / len(vals),
                     "gini": gini(vals), "top5": sum(sorted(vals, reverse=True)[:5]) / sum(vals),
                     **{w: energy.get(w, 0) / m for w in watch}})
    growth =(rows[-1]["mean"] / rows[0]["mean"]) ** (1 / max(1, len(rows) - 1)) if rows and rows[0]["mean"] else 0
    half_life = math.log(2) / math.log(growth) if growth > 1 else float("inf")
    return {"rows": rows, "growth": growth, "half_life": half_life}


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay.sim")
    ap.add_argument("campaign", nargs="?", default="autoplay_v1")
    ap.add_argument("--watch", nargs="*", default=["T2", "kaz", "joey-two-knives", "tanaka"])
    args = ap.parse_args(argv)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    path = CAMPAIGN_DIR / f"{args.campaign}.db" if not args.campaign.endswith(".db") else Path(args.campaign)
    knobs = Knobs()
    print(f"# Physics lab: {path.stem}\n")
    print("Growth = mean multiplier per turn. Half-life = turns for an untouched node's heat to halve.\n")
    print("| policy | growth/turn | half-life | final warm % | final gini | top-5 share | "
          + " | ".join(f"{w} heat" for w in args.watch) + " |")
    print("|---|---|---|---|---|---|" + "---|" * len(args.watch))
    results = {}
    for name, pol in POLICIES.items():
        r = simulate(path, pol, knobs, args.watch)
        results[name] = r
        last = r["rows"][-1]
        print(f"| {name} | {r['growth']:.3f}x | {r['half_life']:.1f} | {100 * last['warm']:.0f}% | {last['gini']:.2f} | "
              f"{last['top5']:.2f} | " + " | ".join(f"{last[w]:.2f}x" for w in args.watch) + " |")
    for name, r in results.items():
        print(f"\n## {name}\n")
        print("| turn | nodes | mean | warm % | gini | " + " | ".join(args.watch) + " |")
        print("|---|---|---|---|---|" + "---|" * len(args.watch))
        for row in r["rows"]:
            print(f"| {row['turn']} | {row['n']} | {row['mean']:.3g} | {100 * row['warm']:.0f}% | {row['gini']:.2f} | "
                  + " | ".join(f"{row[w]:.2f}" for w in args.watch) + " |")


if __name__ == "__main__":
    main()
