"""The spend log (DESIGN.md §12g): every model call the engine makes, itemized, for the whole campaign folder.

One SQLite file next to the campaigns (`usage.db`) gets a row per call: when, which campaign, what for (the
`purpose` each call site names - gm, memory, world, minds, recap...), which model, the tokens, and the dollars at
config.PRICES (estimates). Every process writes to it - the Discord bot, the console table, the simulations - and
the dashboard reads it.

Two things come from elsewhere, so the totals cover everything:
- turns played before this log existed (or by a process still running older code) come in from each campaign's
  `turns.cost`, one row per turn (`turn_history`, filled by `backfill`, which skips any turn the log itemized);
- images are counted from the campaigns' `art` tables and priced at config.IMAGE_PRICES (estimates - OpenAI
  bills them on its own account).
"""
from __future__ import annotations

import re
import sqlite3
import threading
import time
from collections import defaultdict
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import CAMPAIGN_DIR, IMAGE_PRICES

FILE = "usage.db"
LEDGER_FILE = "character_ledger.db"
NOT_WORLDS = (FILE, LEDGER_FILE, "flags.db")      # the shared files next to the worlds (flags.FILE)
SCHEMA = """
CREATE TABLE IF NOT EXISTS calls(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    at REAL NOT NULL,                              -- unix time
    campaign TEXT NOT NULL, purpose TEXT NOT NULL, model TEXT NOT NULL,
    input INTEGER NOT NULL DEFAULT 0, output INTEGER NOT NULL DEFAULT 0,
    cache_read INTEGER NOT NULL DEFAULT 0, cache_write INTEGER NOT NULL DEFAULT 0,
    cost REAL NOT NULL DEFAULT 0,
    turn INTEGER                                   -- the turn it belongs to (or the last one, between turns)
);
CREATE INDEX IF NOT EXISTS idx_calls_at ON calls(at);
CREATE INDEX IF NOT EXISTS idx_calls_turn ON calls(campaign, turn);
CREATE TABLE IF NOT EXISTS turn_history(           -- turns from before itemizing: one row each, from turns.cost
    campaign TEXT NOT NULL, turn INTEGER NOT NULL, at REAL NOT NULL, cost REAL NOT NULL,
    PRIMARY KEY(campaign, turn)
);
"""

PURPOSES = {                                       # what each purpose is called on the dashboard
    "gm": "Game master",
    "memory": "Memory pass",
    "world": "Offscreen world",
    "minds": "NPC minds",
    "notes": "GM notebook",
    "fights": "Fight memories",
    "recap": "Recaps",
    "canon": "Canon (sleep cycle)",
    "frame": "Scene frame",
    "dossier": "Dossiers",
    "aside": "GM asides",
    "pacing": "Pacing checks",
    "calls": "Called-roll reads",
    "chronicle": "Chronicles",
    "chargen": "Character builder",
    "ledger": "Character ledger",
    "askgm": "Player questions",
    "art": "Art prompts",
    "jobs": "Job tracker",
    "sim": "Simulations",
    "seed": "Story seeds",
    "other": "Other",
    "history": "Earlier turns (not itemized)",
    "images": "Images (estimated)",
}
ARCHIVED = re.compile(r"-(\d{8})-(\d{6})$")         # campaigns/archive/<name>-YYYYmmdd-HHMMSS.db

_ready: set[str] = set()
_lock = threading.Lock()


def path(folder: Path | None = None) -> Path:
    return Path(folder or CAMPAIGN_DIR) / FILE


def _connect(p: Path) -> sqlite3.Connection:
    c = sqlite3.connect(str(p), timeout=10, isolation_level=None)
    c.execute("PRAGMA busy_timeout = 10000")
    c.execute("PRAGMA synchronous = NORMAL")               # (see db.connect)
    key = str(p.resolve())
    if key not in _ready:
        with _lock:
            c.execute("PRAGMA journal_mode = WAL")
            c.executescript(SCHEMA)
            _ready.add(key)
    return c


# ── writing ─────────────────────────────────────────────────────────────
def record(folder: Path, campaign: str, purpose: str, model: str, inp: int = 0, out: int = 0, cache_read: int = 0,
           cache_write: int = 0, cost: float = 0.0, turn: int | None = None, at: float | None = None) -> None:
    """File one call. Never raises: the log must never cost anyone a turn."""
    try:
        with closing(_connect(path(folder))) as c:
            c.execute("INSERT INTO calls(at, campaign, purpose, model, input, output, cache_read, cache_write, cost, "
                      "turn) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (at or time.time(), campaign, purpose or "other", model or "?", int(inp), int(out),
                       int(cache_read), int(cache_write), float(cost), turn))
    except Exception:
        pass


class Sink:
    """Plugged into an LLM's Usage (Game.llm does it): files each call under the game's campaign and turn."""

    def __init__(self, game):
        self.game = game
        self.folder, self.campaign = game.path.parent, game.path.stem

    def __call__(self, model: str, purpose: str, inp: int, out: int, cache_read: int, cache_write: int,
                 cost: float) -> None:
        record(self.folder, self.campaign, purpose, model, inp, out, cache_read, cache_write, cost,
               getattr(self.game, "spend_turn", None))


# ── the folder's campaigns ──────────────────────────────────────────────
def base_name(stem: str) -> str:
    """'myworld-20261014-195002' (an archived world) -> 'myworld'."""
    return ARCHIVED.sub("", stem)


def archived_on(stem: str) -> datetime | None:
    m = ARCHIVED.search(stem)
    return datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S") if m else None


def campaign_files(folder: Path | None = None) -> list[Path]:
    """Every world in the folder, then the archived ones (never the character ledger or this log)."""
    folder = Path(folder or CAMPAIGN_DIR)
    live = sorted(p for p in folder.glob("*.db") if p.name not in NOT_WORLDS)
    return live + sorted((folder / "archive").glob("*.db"))


def _ro(p: Path) -> sqlite3.Connection:
    c = sqlite3.connect(f"file:{p.resolve().as_posix()}?mode=ro", uri=True, timeout=5)
    c.execute("PRAGMA busy_timeout = 5000")
    return c


def _has(c: sqlite3.Connection, table: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _utc(stamp: str | None) -> float:
    """SQLite's CURRENT_TIMESTAMP ('2026-10-14 01:43:02', UTC) -> unix time."""
    try:
        return datetime.strptime(stamp[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except (TypeError, ValueError):
        return 0.0


def backfill(folder: Path | None = None) -> int:
    """Bring in turns the log didn't itemize - played before it existed, or by a process on older code - one row
    per turn from `turns.cost`. Skips any turn that has itemized calls. Idempotent; returns the rows added."""
    folder = Path(folder or CAMPAIGN_DIR)
    added = 0
    with closing(_connect(path(folder))) as log:
        for p in campaign_files(folder):
            try:
                with closing(_ro(p)) as src:
                    if not _has(src, "turns"):
                        continue
                    rows = src.execute("SELECT id, cost, created_at FROM turns WHERE status='committed' AND cost > 0"
                                       ).fetchall()
            except sqlite3.Error:
                continue
            stem, base = p.stem, base_name(p.stem)
            done = {r[0] for r in log.execute("SELECT turn FROM turn_history WHERE campaign=?", (stem,))}
            for tid, cost, created in rows:
                if tid in done:
                    continue
                at = _utc(created)
                itemized = log.execute("SELECT 1 FROM calls WHERE campaign=? AND turn=? AND at BETWEEN ? AND ? LIMIT 1",
                                       (base, tid, at - 600, at + 6 * 3600)).fetchone()
                if itemized:
                    continue
                log.execute("INSERT OR IGNORE INTO turn_history(campaign, turn, at, cost) VALUES(?,?,?,?)",
                            (stem, tid, at, cost))
                added += 1
    return added


def images(folder: Path | None = None) -> list[dict]:
    """Every image the art director painted, priced at IMAGE_PRICES (adopted files from earlier runs cost nothing)."""
    out = []
    for p in campaign_files(folder):
        try:
            with closing(_ro(p)) as c:
                if not _has(c, "art"):
                    continue
                rows = c.execute("SELECT entity_id, model, provider, created_at, created_turn FROM art "
                                 "WHERE status='ready' AND provider IS NOT NULL AND provider NOT IN ('adopted', 'none')"
                                 ).fetchall()
        except sqlite3.Error:
            continue
        for eid, model, provider, created, turn in rows:
            out.append({"at": _utc(created), "campaign": p.stem, "purpose": "images", "model": model or provider,
                        "cost": IMAGE_PRICES.get(model or "", IMAGE_PRICES["default"]), "turn": turn})
    return out


# ── reading ─────────────────────────────────────────────────────────────
def items(folder: Path | None = None) -> list[dict]:
    """Everything spent, one dict per call / pre-log turn / image: at, campaign, purpose, model, cost, turn."""
    folder = Path(folder or CAMPAIGN_DIR)
    out: list[dict] = []
    if path(folder).exists():
        with closing(_connect(path(folder))) as c:
            c.row_factory = sqlite3.Row
            out += [dict(r) for r in c.execute("SELECT at, campaign, purpose, model, cost, turn, input, output, "
                                               "cache_read, cache_write FROM calls")]
            out += [{"at": r["at"], "campaign": r["campaign"], "purpose": "history", "model": "", "cost": r["cost"],
                     "turn": r["turn"]} for r in c.execute("SELECT * FROM turn_history")]
    return out + images(folder)


def _day(at: float) -> str:
    return datetime.fromtimestamp(at).strftime("%Y-%m-%d")             # the local day


def report(folder: Path | None = None, days: int = 30, campaign: str | None = None,
           now: float | None = None) -> dict:
    """The dashboard's spend view. `campaign` narrows it to one world (its archived copies included)."""
    folder = Path(folder or CAMPAIGN_DIR)
    now = now or time.time()
    rows = items(folder)
    if campaign:
        rows = [r for r in rows if base_name(r["campaign"]) == campaign]
    today = datetime.fromtimestamp(now).replace(hour=0, minute=0, second=0, microsecond=0)
    t_today = today.timestamp()
    t_week = (today - timedelta(days=6)).timestamp()
    t_month = today.replace(day=1).timestamp()
    total = lambda rs: round(sum(r["cost"] for r in rs), 4)             # noqa: E731

    span = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days - 1, -1, -1)]
    by_day: dict[str, dict[str, float]] = {d: defaultdict(float) for d in span}
    for r in rows:
        d = _day(r["at"])
        if d in by_day:
            by_day[d][r["purpose"]] += r["cost"]

    def grouped(key) -> list[dict]:
        acc: dict[str, dict] = {}
        for r in rows:
            k = key(r)
            a = acc.setdefault(k, {"key": k, "cost": 0.0, "month": 0.0, "calls": 0})
            a["cost"] += r["cost"]
            a["calls"] += 1
            if r["at"] >= t_month:
                a["month"] += r["cost"]
        return sorted(({**a, "cost": round(a["cost"], 4), "month": round(a["month"], 4)} for a in acc.values()),
                      key=lambda a: -a["cost"])

    turns: dict[tuple, dict] = {}
    for r in rows:
        if r.get("turn") is None or r["purpose"] in ("images", "sim"):
            continue
        t = turns.setdefault((r["campaign"], r["turn"]), {"campaign": r["campaign"], "turn": r["turn"], "cost": 0.0,
                                                         "at": r["at"], "itemized": r["purpose"] != "history"})
        t["cost"] += r["cost"]
        t["at"] = min(t["at"], r["at"])
    live = [r["at"] for r in rows if r["purpose"] not in ("history", "images")]
    by_campaign = grouped(lambda r: r["campaign"])
    for c in by_campaign:
        when = archived_on(c["key"])
        c["base"] = base_name(c["key"])
        c["archived"] = when.isoformat(timespec="minutes") if when else None
    return {
        "today": total(r for r in rows if r["at"] >= t_today),
        "week": total(r for r in rows if r["at"] >= t_week),
        "month": total(r for r in rows if r["at"] >= t_month),
        "all": total(rows),
        "days": [{"day": d, "total": round(sum(v.values()), 4), "purposes": {k: round(x, 4) for k, x in v.items()}}
                 for d, v in by_day.items()],
        "by_purpose": [{**g, "label": PURPOSES.get(g["key"], g["key"])} for g in grouped(lambda r: r["purpose"])],
        "by_model": grouped(lambda r: r["model"] or "(per turn)"),
        "by_campaign": by_campaign,
        "top_turns": sorted(({**t, "cost": round(t["cost"], 4)} for t in turns.values()),
                            key=lambda t: -t["cost"])[:12],
        "itemized_since": min(live) if live else None,
        "images": {"count": sum(1 for r in rows if r["purpose"] == "images"),
                   "cost": total(r for r in rows if r["purpose"] == "images")},
        "purposes": PURPOSES,
    }


def campaign_total(folder: Path | None, campaign: str, since: float = 0.0) -> float:
    """Quick total for one world (no images), for the overview."""
    folder = Path(folder or CAMPAIGN_DIR)
    if not path(folder).exists():
        return 0.0
    with closing(_connect(path(folder))) as c:
        a = c.execute("SELECT COALESCE(SUM(cost),0) FROM calls WHERE campaign=? AND at>=?", (campaign, since)).fetchone()[0]
        b = c.execute("SELECT COALESCE(SUM(cost),0) FROM turn_history WHERE campaign=? AND at>=?",
                      (campaign, since)).fetchone()[0]
    return round(a + b, 4)


if __name__ == "__main__":                       # python -m roleplay.spend  -> backfill and a one-line summary
    n = backfill()
    r = report()
    print(f"{n} earlier turn(s) brought in. Today ${r['today']:.2f} · this month ${r['month']:.2f} · all ${r['all']:.2f}")
