"""NPC dossiers for the session recap (DESIGN.md §12d): a manila folder on a dark desk, the NPC's portrait
taped to the sheet slightly askew, and the typed file - who they are, what's been going on with them,
last seen, a status stamp. Laid out by Pillow from fields the recap fills in, so nothing on it is invented by
an image model; the photo is the portrait the art system already painted.
"""
from __future__ import annotations

import hashlib
import random
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

W, H = 1400, 1000
INK = (34, 32, 36)
FADED = (104, 96, 88)
RED_INK = (176, 32, 30)
BLUE_INK = (38, 68, 150)
GRAY_INK = (78, 78, 82)
PAPER = (238, 232, 214)
MANILA = (205, 170, 106)
MANILA_DARK = (176, 141, 80)


def _font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont:
    for name in (("courbd.ttf", "consolab.ttf") if bold else ("cour.ttf", "consola.ttf")) + ("DejaVuSansMono.ttf",):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def stamp_ink(status: str) -> tuple[int, int, int]:
    s = (status or "").lower()
    if any(w in s for w in ("dead", "deceased", "killed", "flatlined")):
        return (120, 18, 18)
    if any(w in s for w in ("large", "hostile", "wanted", "danger", "enemy", "threat", "hunting")):
        return RED_INK
    if any(w in s for w in ("contact", "ally", "active", "friendly", "employer", "fixer", "client")):
        return BLUE_INK
    return GRAY_INK


def _rng(key: str) -> random.Random:
    return random.Random(int(hashlib.sha1(key.encode()).hexdigest()[:8], 16))   # same file, same coffee ring


def _desk() -> Image.Image:
    img = Image.new("RGB", (W, H), (26, 23, 24))
    grain = Image.effect_noise((W, H), 18).convert("RGB")
    img = Image.blend(img, grain, 0.06)
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse([-300, -380, 700, 420], fill=(255, 40, 140, 46))        # neon through the blinds
    g.ellipse([900, 640, 1800, 1400], fill=(30, 200, 255, 34))
    img = Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(120)))
    return img


def _shadow(size: tuple[int, int], box, radius: int, blur: int, alpha: int) -> Image.Image:
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(box, radius, fill=(0, 0, 0, alpha))
    return layer.filter(ImageFilter.GaussianBlur(blur))


def _photo(photo: Path | None, w: int, h: int) -> Image.Image:
    """A print with a white border: the portrait cropped to the head and shoulders, a little faded."""
    if photo and Path(photo).exists():
        src = Image.open(photo).convert("RGB")
        top = 0.0 if src.height > src.width else 0.5            # portraits: keep the face (top of the frame)
        pic = ImageOps.fit(src, (w, h), method=Image.LANCZOS, centering=(0.5, top * 0.6 + 0.12))
        pic = ImageEnhance.Color(pic).enhance(0.82)
        pic = ImageEnhance.Contrast(pic).enhance(0.95)
    else:
        pic = Image.new("RGB", (w, h), (92, 94, 98))
        d = ImageDraw.Draw(pic)
        d.ellipse([w * 0.32, h * 0.18, w * 0.68, h * 0.48], fill=(60, 62, 66))
        d.rounded_rectangle([w * 0.18, h * 0.5, w * 0.82, h * 1.05], 60, fill=(60, 62, 66))
        d.text((w / 2, h * 0.88), "NO PHOTO ON FILE", font=_font(20), fill=(210, 210, 210), anchor="mm")
    border = 16
    card = Image.new("RGB", (w + border * 2, h + border * 2 + 10), (244, 242, 236))
    card.paste(pic, (border, border))
    return card


def _tape(rng: random.Random, length: int = 176, width: int = 50) -> Image.Image:
    """A strip of matte tape: translucent, faintly streaked, with torn ends."""
    img = Image.new("RGBA", (length, width), (0, 0, 0, 0))
    teeth = 7
    left = [(rng.uniform(0, 7), width * i / teeth) for i in range(teeth + 1)]
    right = [(length - rng.uniform(0, 7), width * i / teeth) for i in range(teeth, -1, -1)]
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).polygon(left + right, fill=255)
    body = Image.new("RGBA", img.size, (226, 214, 168, 170))                        # yellowed with age
    streaks = Image.effect_noise(img.size, 30).convert("L").resize((length // 6, width)).resize(img.size)
    body.putalpha(Image.eval(streaks, lambda v: 150 + v // 7))
    img.paste(body, (0, 0), mask)
    edge = ImageDraw.Draw(img)
    edge.line([(4, 1), (length - 4, 1)], fill=(255, 252, 235, 140), width=2)       # a catch of light on the edge
    edge.line([(4, width - 2), (length - 4, width - 2)], fill=(140, 126, 90, 110), width=2)
    return img


def _stick(img: Image.Image, tape: Image.Image, angle: float, center: tuple[float, float]) -> None:
    t = tape.rotate(angle, resample=Image.BICUBIC, expand=True)
    x, y = int(center[0] - t.width / 2), int(center[1] - t.height / 2)
    shade = Image.new("RGBA", img.size, (0, 0, 0, 0))
    shade.paste(Image.new("RGBA", t.size, (0, 0, 0, 60)), (x + 2, y + 3), t)
    img.alpha_composite(shade.filter(ImageFilter.GaussianBlur(2)))
    img.alpha_composite(t, (x, y))


def _stamp(text: str, ink: tuple[int, int, int]) -> Image.Image:
    font = _font(54)
    tw = int(font.getlength(text))
    img = Image.new("RGBA", (tw + 70, 120), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    a = 190
    d.rounded_rectangle([4, 4, tw + 66, 116], 10, outline=ink + (a,), width=6)
    d.rounded_rectangle([14, 14, tw + 56, 106], 6, outline=ink + (a,), width=2)
    d.text(((tw + 70) / 2, 62), text, font=font, fill=ink + (a,), anchor="mm")
    # worn rubber: knock out specks so it reads as ink, not a sticker
    rng = _rng(text)
    px = img.load()
    for _ in range(int(img.width * img.height * 0.05)):
        x, y = rng.randrange(img.width), rng.randrange(img.height)
        r, g, b, al = px[x, y]
        if al:
            px[x, y] = (r, g, b, int(al * 0.25))
    return img


def _wrap(d: ImageDraw.ImageDraw, text: str, font, width: int) -> list[str]:
    chars = max(10, int(width / max(1.0, font.getlength("M"))))
    lines = []
    for para in (text or "").split("\n"):
        lines += textwrap.wrap(para, chars) or [""]
    return lines


def render(card: dict, photo: Path | None, out: Path, file_no: str = "", footer: str = "") -> Path:
    """card: name, alias, affiliation, last_seen, status, who, lately."""
    rng = _rng(card.get("name", "") + file_no)
    img = _desk()

    # the folder: back cover, tab, front
    img.alpha_composite(_shadow((W, H), [78, 118, 1342, 968], 18, 18, 170))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([96, 58, 492, 140], 14, fill=MANILA_DARK)
    d.text((126, 92), f"SUBJECT FILE{'  ' + file_no if file_no else ''}", font=_font(24), fill=(84, 60, 26),
           anchor="lm")
    d.rounded_rectangle([64, 104, 1336, 960], 16, fill=MANILA_DARK)
    d.rounded_rectangle([70, 112, 1330, 952], 14, fill=MANILA)

    # the sheet
    img.alpha_composite(_shadow((W, H), [116, 146, 1296, 932], 4, 8, 120))
    paper = Image.new("RGB", (1170, 778), PAPER)
    paper = Image.blend(paper, Image.effect_noise(paper.size, 22).convert("RGB"), 0.05)
    img.paste(paper, (120, 144))
    d = ImageDraw.Draw(img)
    d.text((150, 178), "SHADOW BEAT // SUBJECT DOSSIER", font=_font(22), fill=FADED, anchor="lm")
    d.text((1262, 178), "CONFIDENTIAL", font=_font(22), fill=RED_INK, anchor="rm")
    d.line([(150, 198), (1262, 198)], fill=(170, 160, 140), width=2)

    # coffee ring, because every good file has one
    cx, cy = rng.choice([(1288, 934), (112, 930), (1300, 128)])            # on the folder's edges, off the text
    ring = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(ring).ellipse([cx - 78, cy - 70, cx + 78, cy + 70], outline=(120, 82, 40, 70), width=7)
    img.alpha_composite(ring.filter(ImageFilter.GaussianBlur(1.5)))

    # the photo, taped on slightly askew
    print_ = _photo(photo, 330, 420)
    angle = rng.uniform(-5.5, -2.5)
    rot = print_.convert("RGBA").rotate(angle, resample=Image.BICUBIC, expand=True)
    px, py = 150, 222
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shadow.paste(Image.new("RGBA", rot.size, (0, 0, 0, 120)), (px + 8, py + 12), rot)
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(7)))
    img.alpha_composite(rot, (px, py))
    _stick(img, _tape(rng), rng.uniform(-7, 5), (px + rot.width / 2 + rng.uniform(-20, 20), py + 14))
    _stick(img, _tape(rng, 120, 44), rng.uniform(-48, -38), (px + rot.width - 22, py + rot.height - 26))

    # last seen, under the photo
    d = ImageDraw.Draw(img)
    label, value = _font(18), _font(20)
    seen = (card.get("last_seen") or "").strip()
    left_y = py + rot.height + 20
    if seen:
        y = left_y
        d.text((152, y), "LAST SEEN", font=label, fill=FADED)
        y += 24
        for line in _wrap(d, seen, value, 380)[:3]:
            d.text((152, y), line, font=value, fill=INK)
            y += 25
        left_y = y

    # the typed file: name, who they're known as / with, then the story so far
    x0, x1 = 560, 1258
    d.text((x0, 232), (card.get("name") or "?").upper(), font=_font(46), fill=INK, anchor="lt")
    y = 292
    for key, title in (("alias", "KNOWN AS"), ("affiliation", "AFFILIATION")):
        text = (card.get(key) or "").strip()
        if not text:
            continue
        lines = _wrap(d, text, value, x1 - x0 - 170)[:2]
        d.text((x0, y + 2), title, font=label, fill=FADED)
        for line in lines:
            d.text((x0 + 170, y), line, font=value, fill=INK)
            y += 25
        y += 6
    d.line([(x0, y + 4), (x1, y + 4)], fill=(190, 180, 160), width=1)
    top = y + 24
    for size in (23, 21, 20, 19, 18):
        body, head = _font(size, bold=False), _font(size)
        lh = int(size * 1.34)
        blocks = [("WHO THEY ARE", _wrap(d, card.get("who", ""), body, x1 - x0)),
                  ("LATELY", _wrap(d, card.get("lately", ""), body, x1 - x0))]
        need = sum(lh + 10 + len(lines) * lh + 22 for _, lines in blocks)
        if top + need <= 890 or size == 18:
            break
    y = top
    for title, lines in blocks:
        d.text((x0, y), title, font=head, fill=RED_INK)
        y += lh + 10
        for line in lines:
            if y > 890:
                break
            d.text((x0, y), line, font=body, fill=INK)
            y += lh
        y += 22
    if footer:
        d.text((1262, 904), footer, font=_font(15, bold=False), fill=FADED, anchor="rm")

    # the status stamp, slammed on at an angle
    status = (card.get("status") or "").strip().upper()
    if status:
        st = _stamp(status[:18], stamp_ink(status)).rotate(rng.uniform(5, 11), resample=Image.BICUBIC, expand=True)
        if 896 - (y - 10) >= st.height:                          # room in the white space under the file
            img.alpha_composite(st, (1250 - st.width - rng.randrange(0, 40), max(y - 10, 640)))
        else:                                                    # no room: under the photo, off the page edge
            st = st.resize((int(st.width * 0.78), int(st.height * 0.78)), Image.LANCZOS)
            img.alpha_composite(st, (min(150, x0 - st.width - 10), min(left_y + 4, 958 - st.height)))

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(out, optimize=True)
    return out
