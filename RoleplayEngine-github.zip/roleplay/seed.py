"""Story seeds (DESIGN.md §12l, built 2026-10-27): the owner writes a story in prose and the engine reads it into the
world - `!seed night-ferry` at the table, or `python -m roleplay.seed <campaign> <files...>` at the console.

The owner: "Can I seed the world with a story?" A seed is prose: the player-safe story (the opening the new crew walks
into) and the GM's secrets behind it - a file named *GM* or *SECRET*, or a section headed 'for the GM only'. It comes
from seeds/<name>*.md, from files attached to `!seed`, or pasted after it. The owner plays in it, so nothing from the
GM's half may reach anything a player sees.

  read     one strong call (the GM's model): the story and the world as it stands - its people, outfits, places,
           latest scenes and record - into a plan grounded in what exists: new people with personas, outfits, places,
           ties to who's on file (never a duplicate), facts public or GM-only, who knows what, feelings, goals, hooks,
           open questions, a job, offscreen events that already happened, contradictions, and the opening scene.
  review   no writes: every name resolved against the world, and the secret guard - each public line checked against
           the GM file's names (true names, the people and outfits the crew hasn't heard of, the plan's secret words,
           the GM text's own proper nouns). A public fact that names one is filed GM-only; an opening that does falls
           back to the author's own words; a person filed under a name the player-safe story never says is sealed.
           What the story says against the record (someone dead on file riding again) is held back as a doubt (X#,
           raised by 'seed') - never filed over it.
  preview  spoiler-free unless asked: counts by kind, the public items in full, the GM-only ones as counts.
           `!seed preview full` sends the owner the whole plan by DM. `!seed confirm` / `!seed cancel` within two
           minutes, like `!rp restart`.
  apply    one transaction through the engine's own paths, after a backup (campaigns/<world>_seeds/) and an undo
           point: the seed is a turn of its own (status 'seed'), so `!undo` takes it back like one.
  open     when the crew is here (`!begin`, or their first post) they're placed in the seed's scene and the opening is
           posted as its first turn, their real names in the slots the story gave them ('Marco', 'his partner'). The
           players act from there; the GM runs the rest from the seed's notes.

Where the GM's half lives, and why each is safe: pictures and notes (GM-only kinds, never at the table), personas,
goals and hooks, beliefs, offscreen W# events, tensions' next steps (the aside's recall at the table leaves them out),
doubts (linked to the seed's own W#, so they're marked offscreen and never asked of the table). Who only the GM's half
knows is sealed (meta seed:sealed): off the dashboard's people list and the aside's lookups until play brings the crew
to them - and someone sealed for their name is on file under a handle the crew could use, the name GM-only, so meeting
them never says it. What play writes after the opening is guarded too (dm/spoilers.py, 2026-10-28): apply keeps the
review's terms and the read's secret words (meta seed:terms) and the names behind the handles (props true_name,
gm_names - and every label the GM file gives anyone, a public NPC's nickname too), and the guard holds every public
line to them until play reveals a name.
"""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import time
import weakref
from dataclasses import dataclass
from pathlib import Path

from .engine import clock
from .engine.ledger import LedgerError

SEEDS_DIR = Path(__file__).resolve().parent.parent / "seeds"
TTL = 120                          # seconds to confirm a read (like !rp restart)
# Each part's output budget. Under ~21,000: LLM.structured doesn't stream, and the SDK refuses a non-streaming call
# whose max_tokens it reckons could run past ten minutes (the first live read, 32,000, never left the machine).
PLAN_TOKENS = 16000
TEXT_SUFFIXES = (".md", ".txt", ".markdown")
MAX_FILE = 200_000                 # bytes per attached file
FILE_MARK = re.compile(r"^<<<(file|skipped): (.*?)>>>[ \t]*$", re.MULTILINE)    # with_files' blocks
GM_FILE = re.compile(r"(?<![a-z])gm(?![a-z])|secret", re.IGNORECASE)      # night-ferry.GM-SECRETS.md
GM_HEAD = re.compile(r"\b(?:for the gm(?: only)?|gm[ -]only|gm eyes only|for gm eyes)\b", re.IGNORECASE)
SLOT = re.compile(r"\{(PC\d+)\}")
NAME = re.compile(r"^[A-Za-z0-9_-]+$")
TEMPLATES = ("civilian", "contact", "expert", "ganger", "security", "operative")
ROLES = ("actor", "target", "present", "location")
LIMITS = {"location": 10, "faction": 8, "npc": 24, "tie": 30, "fact": 60, "event": 20, "feeling": 40, "agenda": 20,
          "hook": 16, "tension": 8, "doubt": 12, "present": 12, "moment": 16, "cast": 6, "secret": 80}
META_OPENING = "seed:opening"      # the opening waiting for its crew (JSON)
META_APPLIED = "seed:applied"      # every seed read into this world: title, turn, scene, intent, arc (for the canon)
META_SEALED = "seed:sealed"        # ids only the GM's half of a seed knows (sealed_ids)
META_TERMS = "seed:terms"          # {terms, secret_words, cased}: every seed's (review's), for the guard (spoilers.py)
# The roles in a public moment that don't mean the crew met someone: a memory reached back for, and being talked about
# - the memory pass filing a sealed NPC 'mentioned' unsealed him (review 2026-10-28, the first seed's rehearsal).
NOT_MET = ("recalled", "mentioned")
WAITING = "Another story's opening is still waiting for its crew - `!begin` plays it first (`!seed status`)"
READ_HEAD = "STORY TO READ INTO THE WORLD"
ADAPT_HEAD = "OPENING TO ADAPT"
# Words that are never a secret on their own: titles, an outfit's generic words, the days - "Sergeant Mara Quist"
# guards Mara and Quist, not every sergeant.
COMMON = frozenset("""the a an and of in on at to for by with from mr mrs ms dr doctor mister missus sir madam
lieutenant lt sergeant sgt captain capt officer detective inspector chief commander agent deputy boss old young
company services service corp corporation inc ltd llc group lot holdings partners associates office offices precinct
street road avenue strip bar club shop store seattle metroplex lone star day days night week weeks
monday tuesday wednesday thursday friday saturday sunday morning afternoon evening""".split())
_TOKEN = re.compile(r"[A-Za-z][A-Za-z']*")
MIN_NAME = 3                       # a shorter name or alias ('Lo') says nothing: it sits inside 'Lone Star' and 'slow'
# Someone sealed for their name is filed under a handle the crew could use - what anyone sees of them, cut to its
# first clause ("riders in lantern-red scarves who watch the pier" -> "the riders in lantern-red scarves") - and the
# name goes to true_name: an entity's name and id are what every view shows once the crew meets them.
HANDLE_WORDS = 8
HANDLE_CUT = re.compile(r",|;|:| - | who | whose | that | which ")
HANDLE_TAIL = frozenset("a an the of in on at to for from by with and or".split())
UNSEEN = {"npc": "someone the crew hasn't met", "faction": "an outfit the crew hasn't heard of",
          "location": "a place the crew hasn't heard of"}
UNREAD_WAIT = clock.DAY            # a goal whose due the clock can't read ('next Friday') waits a day, never moves now
# The labels the GM file gives someone beside a name of theirs (gm_labels): a quoted nickname - `**"Nick" (Real Name)**`,
# `Real Name ("Nick")`, `First "Nick" Last` - or one they go by ('known as "Nick"', 'the crew calls her Nick').
LABEL = r"[\"“]([A-Z][A-Za-z'’-]+(?: [A-Z][A-Za-z'’-]+){0,2})[\"”]"
GOES_BY = r"(?:a\.?k\.?a\.?|known as|nicknamed|goes by|calls? (?:them|him|her|it))"   # (never a bare "called")
PARTICLES = frozenset("de la le di du da st mc al el".split())   # (never a two-letter surname on its own)


def _s(v, n: int | None = None) -> str:
    v = " ".join(str(v or "").split()) if not isinstance(v, str) else v.strip()
    return v if n is None or len(v) <= n else v[:n - 3].rsplit(" ", 1)[0] + "..."


def _list(v) -> list:
    return [x for x in v if x is not None] if isinstance(v, list) else []


def _int(v, lo: int, hi: int, default: int = 0) -> int:
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return default


def _words(text: str) -> set[str]:
    """Lowercase words, hyphens split ('Night-Ferry' -> night, ferry), possessives off."""
    return {re.sub(r"['’]s$", "", w.lower()).strip("'") for w in _TOKEN.findall(text or "")} - {""}


def _says(text: str, phrase: str) -> bool:
    """Does the text hold the phrase as whole words (any case)? 'Sam' isn't in 'same', nor 'Ned' in 'turned'."""
    return bool(phrase) and re.search(rf"(?<![A-Za-z0-9]){re.escape(phrase)}(?![A-Za-z0-9])", text or "",
                                      re.IGNORECASE) is not None


def handle_for(kind: str, description: str) -> str:
    """A name the crew could use for someone sealed for their name (HANDLE_WORDS): what anyone sees of them, else what
    they are to the crew (UNSEEN)."""
    words = HANDLE_CUT.split(description or "", 1)[0].split()
    if words and words[0].lower() in ("a", "an", "the", "some", "one"):
        words = words[1:]
    words = words[:HANDLE_WORDS]
    while words and words[-1].lower().strip(".") in HANDLE_TAIL:
        words.pop()
    text = " ".join(words).strip(" .")
    return f"the {text}" if text else UNSEEN[kind]


# ── the story's documents ───────────────────────────────────────────────

@dataclass
class Doc:
    name: str
    text: str
    gm: bool            # the GM's secrets: never anything a player sees


def split(name: str, text: str) -> list[Doc]:
    """One file -> its parts: all GM-only when its name says so (GM, SECRET), else player-safe up to a section headed
    'for the GM only' (a heading, a bold line, or a short line on its own) and GM-only from there on."""
    text = (text or "").replace("\r\n", "\n").strip()
    if not text:
        return []
    if GM_FILE.search(Path(name).name):
        return [Doc(name, text, True)]
    lines = text.split("\n")
    for i, line in enumerate(lines):
        bare = line.strip()
        if GM_HEAD.search(bare) and (bare.startswith(("#", "**", "__")) or len(bare) <= 80):
            before, after = "\n".join(lines[:i]).strip(), "\n".join(lines[i:]).strip()
            return ([Doc(name, before, False)] if before else []) + [Doc(f"{name} (for the GM)", after, True)]
    return [Doc(name, text, False)]


def parse(rest: str) -> tuple[list[Doc], list[str]]:
    """What follows `!seed` -> (the documents, the files skipped). Attached files arrive as <<<file: name>>> blocks
    (with_files); text pasted before them is a document of its own."""
    parts = FILE_MARK.split(rest or "")
    docs, skipped = split("pasted", parts[0]), []
    for i in range(1, len(parts) - 2, 3):
        kind, name, body = parts[i], parts[i + 1].strip() or "file", parts[i + 2]
        if kind == "skipped":
            skipped.append(name)
        else:
            docs += split(name, body)
    return docs, skipped


async def with_files(text: str, attachments) -> str:
    """bot.on_message's hook: a `!seed` message's attached .md / .txt files ride into the command as <<<file: name>>>
    blocks (anything else, or too big, as <<<skipped: name>>>) - so pasted text and files read the same way."""
    out = [text]
    for a in attachments or []:
        name = re.sub(r"[\r\n<>]", "", str(getattr(a, "filename", "") or "file"))
        if not name.lower().endswith(TEXT_SUFFIXES) or int(getattr(a, "size", 0) or 0) > MAX_FILE:
            out.append(f"<<<skipped: {name}>>>")
            continue
        data = await a.read()
        out.append(f"<<<file: {name}>>>\n" + data.decode("utf-8", errors="replace"))
    return "\n".join(out)


def available(folder: Path | None = None) -> list[str]:
    """The seeds in seeds/, by name - night-ferry.md and night-ferry.GM-SECRETS.md are one seed."""
    folder = folder or SEEDS_DIR
    if not folder.exists():
        return []
    return sorted({p.name.split(".")[0] for p in folder.iterdir() if p.suffix.lower() in TEXT_SUFFIXES})


def from_seeds(name: str, folder: Path | None = None) -> list[Doc]:
    """`!seed night-ferry`: seeds/night-ferry*.md - the player-safe file first."""
    folder = folder or SEEDS_DIR
    name = name.strip()
    if name.lower().endswith(TEXT_SUFFIXES):
        name = name.rsplit(".", 1)[0]
    if not NAME.match(name):
        raise LedgerError("A seed's name is letters, numbers, - and _ (`!seed list` shows them).")
    files = sorted((p for p in folder.glob(f"{name}*") if p.suffix.lower() in TEXT_SUFFIXES
                    and p.name.split(".")[0].lower() == name.lower()),
                   key=lambda p: (GM_FILE.search(p.name) is not None, p.name))
    if not files:
        have = available(folder)
        raise LedgerError(f"No seed called '{name}' in seeds/" + (f" - there's {', '.join(have)}." if have else "."))
    docs = []
    for p in files:
        docs += split(p.name, p.read_text(encoding="utf-8", errors="replace"))
    return docs


def from_files(paths) -> list[Doc]:
    docs = []
    for p in map(Path, paths or []):
        docs += split(p.name, p.read_text(encoding="utf-8", errors="replace"))
    return docs


def _label(docs: list[Doc]) -> str:
    return ", ".join(dict.fromkeys(d.name.replace(" (for the GM)", "") for d in docs)) or "the story"


# ── read: one strong call ───────────────────────────────────────────────

def _obj(**props) -> dict:
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def _arr(item: dict) -> dict:
    return {"type": "array", "items": item}


# The read is three calls - the API compiles each schema to a grammar with a size limit, and the whole plan is far past
# it (tests/test_live_schemas.py). The cast comes first; the threads and the opening are read against it, side by side.
# Lists of pairs ride as strings ("who | source", "Outfit (role)") for the same reason.
PARTS = {"cast": ("title", "people", "outfits", "places", "ties"),
         "threads": ("secret_words", "facts", "events", "feelings", "agendas", "hooks", "contradictions"),
         "opening": ("intent", "arc", "opening", "tensions", "job")}


def plan_schema(part: str = "cast") -> dict:
    """What one part of the read returns (tests/test_live_schemas.py checks the API compiles each)."""
    from .dm import world
    s, i, b = {"type": "string"}, {"type": "integer"}, {"type": "boolean"}
    ids = _arr(s)
    persona = _obj(**{f: s for f in world.PERSONA_FIELDS})
    profile = _obj(**{f: i if f in ("reach", "funds") else s for f in world.FACTION_FIELDS})
    props = dict(
        title=s, intent=s, arc=s, secret_words=ids,
        people=_arr(_obj(key=s, name=s, true_name=s, description=s,
                         template={"type": "string", "enum": list(TEMPLATES)}, known=b, secret=s, dead=b, where=s,
                         place=s, persona=persona)),
        outfits=_arr(_obj(key=s, name=s, true_name=s, description=s, known=b, secret=s, profile=profile)),
        places=_arr(_obj(key=s, name=s, description=s, district=s, near=s, known=b, secret=s)),
        ties=_arr(_obj(id=s, role=s, joins=ids, where=s, place=s, dead=b)),
        facts=_arr(_obj(text=s, about=ids, public=b, known_by=ids)),
        events=_arr(_obj(text=s, days_before=i, who=ids, known_by=ids)),
        feelings=_arr(_obj(holder=s, about=s, attitude=i, belief=s)),
        agendas=_arr(_obj(who=s, goal=s, targets=ids, due=s)),
        hooks=_arr(_obj(source=s, text=s, about=ids)),
        tensions=_arr(_obj(question=s, public=s, about=ids, stakes=i, due=s, next=s)),
        job=_obj(offered=b, title=s, client=s, objective=s, pay=s, deadline=s),
        contradictions=_arr(_obj(ids=ids, story=s, record=s)),
        opening=_obj(title=s, place=s, time=s, present=ids, in_moment=ids, cast=ids, narration=s, summary=s,
                     gm_first=s))
    return _obj(**{k: props[k] for k in PARTS[part]})


def _pair(v, keys=("who", "role")) -> tuple[str, str]:
    """'who | source', 'Outfit (role)', 'PC1 | Marco' (or the same as an object) -> its two halves."""
    if isinstance(v, dict):
        return _s(v.get(keys[0])), _s(v.get(keys[1]))
    v = _s(v)
    if "|" in v:
        a, _, b = v.partition("|")
        return a.strip(), b.strip()
    m = re.fullmatch(r"(.+?)\s*\((.*)\)", v)
    return (m.group(1).strip(), m.group(2).strip()) if m else (v, "")


def _memberships(v) -> list[tuple[str, str]]:
    """'Outfit (role); Outfit (role)' (or a list of them) -> [(outfit, role)]."""
    items = v if isinstance(v, list) else re.split(r"\s*;\s*", _s(v))
    out = [_pair(x, ("name", "role")) for x in items if x]
    return [(n, r or "member") for n, r in out if n and n.lower() not in ("none", "-", "n/a")]


_JOB = """You are the game master's prep partner for a long-running Shadowrun campaign played on Discord. The \
campaign's owner wrote a story to seed the world with, and you are reading it into a plan the engine files - who and \
what it brings in, what is true, who knows what, what everyone wants, the open questions, the offscreen events that \
already happened, and the opening scene the crew of player characters starts in. THE WORLD AS IT STANDS is the live \
campaign: ground everything in it. The plan is read in three parts; this is one of them (THIS PART, below)."""

_FIELDS = {
    "cast": """THIS PART: THE CAST - who and what the story brings in, and who on file it touches.
- key: a short handle you use for that person, outfit or place everywhere in the plan. Refer to anyone on file by \
their [id], and to anything new by its key.
- title: the story's name.
- people (only who isn't on file): name (as filed - see TWO HALVES), true_name ("" when their name isn't secret), \
description (what anyone sees: look, manner, trade - never their secret), template (civilian; contact - a fixer, \
broker or informant; expert; ganger; security - a guard or a cop; operative - an elite professional), known, secret \
(GM-only: who they really are, what they hide, what they know), dead (dead by the end of the opening), where and \
place (where they are when the story opens: words, and a place key, an [id] or a district; "" for anyone in the \
opening scene), persona (their character bible as the GM plays them: one short sentence a field, third person, \
present tense; hooks: one or two threads separated by ';'; affiliations: the outfits they belong to now, as \
'Outfit (role)', separated by ';' - by name or key; "" for none).
- outfits (gangs, crews, companies, a cop's side business - only what isn't on file): name, true_name, description \
(what the street knows; "" if nothing), known, secret, profile (summary, wants, methods, resources, territory, \
leadership, rivals, secret - one short sentence each; reach 1 a small crew .. 4 a precinct .. 6 a megacorp; funds \
in nuyen for street business).
- places (only what isn't on file): name, description (what you see there), district (one of DISTRICTS, or ""), near \
(a place key or [id] it's close to, or ""), known, secret.
- ties (anyone, any outfit or place on file the story touches): id, role (GM-only: what they are and did in this \
story, what they know), joins (outfits they belong to now, as 'Outfit (role)'), where and place (where they are now; \
"" if unchanged), dead (true only when the story says they're dead).""",
    "threads": """THIS PART: THE THREADS - what is true, who knows it, what everyone wants. THE CAST below is part \
one: use its keys, and [id]s for anyone on file.
- secret_words: every name, alias and telling phrase in the GM-only half the players must not see (real names, the \
hidden boss and what he is, front companies, who the informant is, who the client is).
- facts: text (one thing that's true), about (keys and [id]s), public (true only when the street or the crew could \
know it from the player-safe story or the public record), known_by (who knows it, as 'who | who told them' - just \
'who' when they saw it or it's street talk). The player characters know what the opening shows them: never list them.
- events: what already happened offscreen, away from the crew, BEFORE the opening scene (the deal, the meeting, the \
threat, the sale): text (past tense, naming them), days_before (days before the opening; 0 = earlier that day), who \
(as 'who | role', the role actor, target, present, or location for where it happened), known_by. Never anything the \
opening shows - the crew sees that happen, and the opening's own turn records it (its truth beneath - who gave the \
order - is a fact or a GM-only fact).
- feelings: an NPC's view of someone - holder, about, attitude (-3 to +3), belief (one sentence: "<holder> thinks ...").
- agendas: what someone or some outfit is pursuing - who, goal, targets, due (when they next move, counted from the \
opening, in the clock's words: "tonight", "tomorrow evening", "7 days later, afternoon"; "" for right away; never a \
weekday - the clock has none).
- hooks: what could land on the crew - source (who it comes from), text (one or two sentences for the GM: who, what, \
when or where), about.
- contradictions: where the story disagrees with the record - ids (the record's side: [id]s, T#, F#, W#), story \
(what the story says), record (what the record says). Leave the disputed part out of everything else.""",
    "opening": """THIS PART: THE OPENING - the new crew's first scene, the open questions and the job. THE CAST below \
is part one: use its keys, and [id]s for anyone on file.
- intent (GM-only, two or three sentences: what this story is and what it's for), arc (GM-only: how it can go - the \
pressure, the turns, the ways it can end).
- opening (title and narration "" when the story has none): title, place (a key or [id]), time (when it opens, \
counted from STORY TIME NOW in the clock's words - "afternoon", "tomorrow evening", "3 days later, afternoon"; "" \
keeps the clock; never earlier than now), present (who is in the scene when the players take over - not the player \
characters), in_moment (who the crew saw in the opening, as 'who | role' with role actor, target, present or location, \
under the names they'd know them by - never someone whose being there is a secret), cast (the player characters as \
the story names them, in order, as 'PC1 | Marco', 'PC2 | his partner'), narration (the opening in the author's own \
words, as written - only the cast changes: each player character becomes their slot token {PC1}, {PC2} wherever the \
story names or means them; drop headings and notes; nothing from the GM-only half), summary (one public sentence of \
what happened, with the slot tokens), gm_first (GM-only: what the GM does first once the players act).
- tensions: the story's open questions. question (it shows on the table's own dashboard: phrase it as the crew could \
ask it, no secret names - the secret goes in next), public (what the crew knows of it, "" if nothing yet), about, \
stakes 1-3, due (when it comes to a head, counted from the opening: rent due next Friday is "7 days later, \
afternoon" - never a weekday, the clock has none), next (GM-only: the next pressure point).
- job: offered (the story offers the crew a job), title, client (who offers it as the crew sees them - the face, never \
a secret client), objective, pay, deadline - each as the crew heard it.""",
}


def _system(part: str = "cast") -> str:
    from .dm.prompts import FICTION_NOTE
    return FICTION_NOTE + " " + _JOB + """

TWO HALVES. THE PLAYER-SAFE STORY may be read by the players - the owner plays in this story too. THE GM-ONLY STORY \
is the truth behind it: who is really behind it, the people, the money, the clues, the arc. Nothing from the GM-only \
half may reach anything public:
- Public lines - a new person's, outfit's or place's name and description, a public fact, a tension's question and \
public line, the job, the opening's title, narration and summary - come only from the player-safe story and what the \
world's public record already shows. When unsure, it's GM-only.
- A name the player-safe story never says - a real name, an outfit's own name, a front company - is GM-only. File the \
person or outfit under a handle the crew could use from what they saw ("the woman with the slate", "the ork with the \
chrome arm", "the grey coats") and put the real name in true_name. known: false for anyone, any outfit and any place \
the player-safe story never shows - the crew hasn't heard of them.
- The engine checks every public line against the plan's secret_words and against every name the player-safe story \
doesn't use: a line that slips is filed GM-only.

THE WORLD. Never duplicate what's on file: anyone, any outfit or place already in THE WORLD is a tie by its [id]. \
people, outfits and places are only for what isn't on file. Never rewrite who someone on file is. Where the story \
disagrees with the record - someone dead on file alive in the story, a fact on file saying otherwise, a time that \
doesn't fit - don't file the story's version: it's a contradiction (the threads part lists them), the disputed part \
stays out of everything else, and the GM settles it.

""" + _FIELDS[part]


def gather(game, docs: list[Doc]) -> dict:
    """The read's input, on the game thread: the world as it stands - what to link to and never duplicate - and the
    story in its two halves."""
    from . import jobs
    from .dm import world
    from .engine import geo
    from .engine.rules import sr_lite
    L, conn = game.ledger, game.conn
    out = [READ_HEAD, f"\n=== THE WORLD AS IT STANDS (the live campaign - link to these [id]s, never duplicate them) "
                      f"===\nSTORY TIME NOW: {clock.fmt(game.clock())} (session {L.session()})"]
    pcs = L.entities(kind="pc")
    out.append("\nPLAYER CHARACTERS ON FILE (the new crew may not be made yet - the opening's cast slots stand for "
               "whoever sits down):\n" + ("\n".join(
                   f"- [{p['id']}] {p['name']} ({(p['props'].get('archetype') or 'runner').replace('_', ' ')}) - "
                   f"{_s(p['description'], 160)}" for p in pcs) or "(none yet)"))
    orgs = []
    for f in L.entities(kind="faction"):
        crew = ", ".join(m["name"] for m, _ in world.members_of(game, f["id"])[:6])
        orgs.append(f"- [{f['id']}] {f['name']} - {_s(f['description'], 160)}" + (f" (members: {crew})" if crew else ""))
    out.append("\nOUTFITS ON FILE:\n" + ("\n".join(orgs) or "(none)"))
    people = []
    for e in L.entities(kind="npc"):
        if e["tier"] < 1:
            continue
        cond = sr_lite.condition(L, e["id"])
        groups = ", ".join(f["name"] for f, _ in world.factions_of(game, e["id"]))
        people.append(f"- [{e['id']}] {e['name']} ({e['props'].get('template', 'civilian')}"
                      + (f", {cond.upper()}" if cond != "ok" else "") + (f"; {groups}" if groups else "")
                      + f") - {_s(e['description'], 160)}")
    out.append("\nPEOPLE ON FILE (DEAD means dead in the ledger):\n" + ("\n".join(people) or "(none)"))
    places = [f"- [{p['id']}] {p['name']}" + (f" ({p['props']['geo']['district']})" if (p["props"].get("geo") or {})
                                              .get("district") else "") + f" - {_s(p['description'], 140)}"
              for p in L.entities(kind="location")]
    out.append("\nPLACES ON FILE:\n" + ("\n".join(places) or "(none)"))
    out.append("DISTRICTS: " + ", ".join(geo.GAZETTEER))
    scenes = [f"- S{s['id']} \"{s['title']}\"" + (f" at {(L.get(s['location_id']) or {}).get('name', s['location_id'])}"
                                                  if s["location_id"] else "") + f" ({s['status']}, from T{s['created_turn']})"
              for s in L.scenes()[-8:][::-1]]
    out.append("\nLATEST SCENES (newest first):\n" + ("\n".join(scenes) or "(none)"))
    rows = conn.execute("SELECT id, text, story_time, created_turn FROM nodes WHERE kind='slice' AND "
                        "visibility='public' ORDER BY created_turn DESC LIMIT 30").fetchall()[::-1]
    out.append("\nTHE RECENT RECORD (public turns, oldest first):\n" + ("\n".join(
        f"- [{r['id']}] ({clock.short(r['story_time']) if r['story_time'] is not None else 'T' + str(r['created_turn'])}"
        f") {_s(r['text'], 300)}" for r in rows) or "(nothing played yet)"))
    facts = conn.execute("SELECT id, text FROM nodes WHERE kind='fact' AND visibility='public' AND id NOT IN "
                         "(SELECT old_id FROM supersedes) ORDER BY created_turn DESC LIMIT 40").fetchall()[::-1]
    out.append("\nFACTS ON FILE (public, latest):\n" + ("\n".join(f"- [{r['id']}] {_s(r['text'], 240)}" for r in facts)
                                                        or "(none)"))
    away = conn.execute("SELECT id, text FROM nodes WHERE kind='slice' AND visibility='offscreen' ORDER BY "
                        "created_turn DESC, rowid DESC LIMIT 12").fetchall()[::-1]
    if away:
        out.append("\nOFFSCREEN LATELY (GM-only):\n" + "\n".join(f"- [{r['id']}] {_s(r['text'], 240)}" for r in away))
    qs = [f"- [{t['id']}] {t['question']}" + (f" (the crew knows: {t['public']})" if t["public"] else "")
          for t in conn.execute("SELECT * FROM tensions WHERE status IN ('open', 'shelved')")]
    if qs:
        out.append("\nOPEN QUESTIONS:\n" + "\n".join(qs))
    open_jobs = jobs.open_jobs(game)
    if open_jobs:
        out.append("\nOPEN JOBS:\n" + "\n".join(f"- [{j['id']}] {j['status']}: {j['title']} - {j['objective']}"
                                                for j in open_jobs))
    for gm, head in ((False, "THE PLAYER-SAFE STORY (the players may read this; the opening comes from it)"),
                     (True, "THE GM-ONLY STORY (secrets - nothing from here may reach anything public)")):
        part = [d for d in docs if d.gm == gm]
        out.append(f"\n=== {head} ===")
        out += [f"--- {d.name} ---\n{d.text}" for d in part] or ["(none)"]
    return {"text": "\n".join(out)}


def think(game, gathered: dict) -> dict:
    """The read (off the game thread), on the GM's model: the cast first, then the threads and the opening side by
    side against it. Returns the whole plan."""
    from concurrent.futures import ThreadPoolExecutor
    m = game.settings.models

    def part(name: str, extra: str = "") -> dict:
        data = game.llm.structured(m.dm, _system(name), f"{gathered['text']}{extra}\n\n(Now the {name} part.)",
                                   plan_schema(name), max_tokens=PLAN_TOKENS, effort="medium", fallback=m.commit,
                                   purpose="seed")
        return {k: data.get(k) for k in PARTS[name]} if isinstance(data, dict) else {}
    cast = part("cast")
    extra = "\n\n=== THE CAST (part one - use these keys) ===\n" + json.dumps(cast, ensure_ascii=False)
    with ThreadPoolExecutor(max_workers=2) as pool:
        threads, opening = pool.map(lambda n: part(n, extra), ("threads", "opening"))
    return {**cast, **threads, **opening}


# ── the secret guard ────────────────────────────────────────────────────

def vocabulary(game, player: str) -> set[str]:
    """Every word the players could have met: the player-safe story's and the world's public record's (less the people
    and outfits an earlier seed sealed - an entity's node is public, its name may not be)."""
    words, sealed = _words(player), sealed_ids(game.conn)
    for nid, text in game.conn.execute("SELECT id, text FROM nodes WHERE visibility='public' AND kind IN "
                                       "('slice', 'fact', 'entity', 'scene')"):
        if nid not in sealed:
            words |= _words(text)
    return words


def secret_terms(player: str, gm: str, names, public: set[str]) -> list[str]:
    """The words no public line may hold: the names given (true names, who and what the crew hasn't heard of, the
    plan's secret words) and the GM text's own proper nouns (a capitalized word mid-sentence that is never written in
    lowercase) - less anything the player-safe story says, the world's public record holds, or COMMON."""
    lower = set(re.findall(r"(?<![A-Za-z])[a-z][a-z']+", f"{player}\n{gm}"))
    proper = [m.group() for m in re.finditer(r"(?<=[A-Za-z0-9,] )[A-Z][A-Za-z']{2,}", gm)
              if m.group().lower() not in lower]
    out: list[str] = []
    for phrase, own in [(n, True) for n in names] + [(p, False) for p in proper]:
        phrase = " ".join(str(phrase or "").split()).strip(" .,;:'\"*_()[]")
        if len(phrase) < 3 or _says(player, phrase):     # (whole words: the story's 'same' doesn't say 'Sam')
            continue
        toks = [re.sub(r"['’]s?$", "", t) for t in _TOKEN.findall(phrase)]
        # (O'Malley guards Malley too; and a true name's two-letter surname - Kim Ng's Ng - is one, the guard's to cut
        # capitalized only: never a particle)
        toks += [x for t in toks if re.search(r"[A-Za-z]'[A-Za-z]", t) for x in t.split("'")[1:] if len(x) >= 3]
        short = toks[-1:] if own and len(toks) > 1 and re.fullmatch(r"[A-Z][a-z]", toks[-1]) else []
        rare = [t for t in toks if (len(t) >= 3 or t in short and t.lower() not in PARTICLES)
                and t.lower() not in COMMON and t.lower() not in public and (own or t.lower() not in lower)]
        if len(toks) > 1 and rare:
            out.append(phrase)                         # (the whole name: "Northgate Holdings Trust")
        out += rare
    seen: set[str] = set()
    return sorted((t for t in out if not (t.lower() in seen or seen.add(t.lower()))), key=len, reverse=True)


def plain_words(player: str, gm: str, terms) -> list[str]:
    """The one-word terms the seed's own texts also use as a plain lowercase word - the guard cuts them only
    capitalized (dm/spoilers.py): "a crime syndicate" is no outfit's name."""
    lower = set(re.findall(r"(?<![A-Za-z])[a-z][a-z']+", f"{player}\n{gm}"))
    return sorted(t for t in terms if " " not in t and not t.islower() and t.lower() in lower)


def gm_labels(gm: str, anchors, player: str, taken) -> list[str]:
    """The labels the GM file gives someone beside a name of theirs (`anchors`: their true name, the read's name, the
    name on file) - LABEL's and GOES_BY's shapes. Less a name the player-safe story says as one (capitalized, mid-
    sentence: "the Bosun"), a name on file or in the seed (`taken`), COMMON. Review 2026-10-28: a GM-only label for a
    public NPC in the GM file - a plain word, capitalized - was never guarded, and the GM said it at the table."""
    out: list[str] = []
    for a in dict.fromkeys(" ".join(str(x or "").split()) for x in anchors):
        if len(a) < MIN_NAME:
            continue
        name = re.escape(a).replace(r"\ ", r"\s+")
        shapes = [rf"{LABEL}[\s*_]*(?:\(|,|-|–|—)\s*[*_]*(?i:{name})",          # "Nick" (Real Name)
                  rf"(?i:{name})[*_]*\s*\(\s*[*_]*{LABEL}",                      # Real Name ("Nick")
                  rf"(?i:{name}[^.\n]{{0,60}}?\b{GOES_BY})\s+[*_\"“]*"           # known as "Nick"
                  rf"([A-Z][A-Za-z'’-]+(?: [A-Z][A-Za-z'’-]+){{0,2}})"]
        if " " in a:                                                       # First "Nick" Last
            first, rest = (re.escape(x).replace(r"\ ", r"\s+") for x in a.split(" ", 1))
            shapes.append(rf"(?<![A-Za-z])(?i:{first})\s+{LABEL}\s+(?i:{rest})")
        for shape in shapes:
            for m in re.finditer(shape, gm):
                lab = " ".join(m.group(1).split()).strip(" .,'’")
                if len(lab) >= MIN_NAME and lab not in out:
                    out.append(lab)
    bare = lambda x: x[4:] if x.lower().startswith("the ") else x            # noqa: E731 ("The Bosun" is "Bosun")
    taken = {bare(x).lower() for x in taken if x}
    return [x for x in out if bare(x).lower() not in taken and x.lower() not in COMMON
            and not re.search(rf"(?<=[A-Za-z0-9,;] ){re.escape(bare(x))}(?![A-Za-z0-9])", player)]


def leaks(text: str, terms) -> list[str]:
    """The secret terms a line holds (whole words, any case)."""
    t = text or ""
    return [w for w in terms if re.search(rf"(?<![A-Za-z0-9]){re.escape(w)}(?![A-Za-z0-9])", t, re.IGNORECASE)]


def unsupported(text: str, vocab: set[str]) -> list[str]:
    """Names in a line that the players have never met: capitalized words outside the player-safe story and the public
    record. The opening and a known name may hold none - the narration is the author's words, and a name the story
    never says came from somewhere else."""
    bare = SLOT.sub(" ", text or "")
    return [w for w in dict.fromkeys(re.sub(r"['’]s?$", "", m) for m in re.findall(r"[A-Z][A-Za-z']{2,}", bare))
            if w.lower() not in vocab and w.lower() not in COMMON]       # ("the Crows' clubhouse" is the Crows)


def author_text(player: str, cast: list[dict]) -> str:
    """The fallback opening: the player-safe story itself, headings and rules out, each cast name as its slot."""
    keep = [line for line in player.split("\n")
            if not line.strip().startswith("#") and not re.fullmatch(r"\s*[-*_]{3,}\s*", line)]
    text = re.sub(r"\n{3,}", "\n\n", "\n".join(keep)).strip()
    for c in cast:
        if c["story_name"]:
            text = re.sub(rf"(?<![A-Za-z]){re.escape(c['story_name'])}(?![A-Za-z])", "{" + c["slot"] + "}", text,
                          flags=re.IGNORECASE)
    return text


# ── review: the plan against the world, no writes ───────────────────────

def review(game, docs: list[Doc], plan: dict) -> dict:
    """Resolve the plan against the world as it stands and guard every public line. Returns the work apply files and
    the preview shows: refs are ids on file, or '+key' for what the seed brings in."""
    from .engine.rules import sr_lite
    from .substrate.store import SLICE_RE, norm_id
    L, S = game.ledger, game.sub
    plan = plan if isinstance(plan, dict) else {}
    player = "\n\n".join(d.text for d in docs if not d.gm)
    gm = "\n\n".join(d.text for d in docs if d.gm)
    w: dict = {"title": _s(plan.get("title"), 120) or _label(docs), "intent": _s(plan.get("intent")),
               "arc": _s(plan.get("arc")), "files": [(d.name, d.gm) for d in docs], "people": [], "outfits": [],
               "places": [], "ties": [], "facts": [], "notes": [], "events": [], "feelings": [], "agendas": [],
               "hooks": [], "tensions": [], "job": None, "doubts": [], "opening": None, "problems": [],
               "guarded": [], "linked": [], "names": {}, "keys": {}}
    keys, names = w["keys"], w["names"]
    ties: dict[str, dict] = {}

    def claim(handles, ref: str) -> None:
        for h in handles:
            h = _s(h).lower().strip("[]")
            for v in (h, h[4:] if h.startswith("the ") else ""):      # ("The Bosun" answers to "Bosun" too)
                if v and v not in keys:
                    keys[v] = ref

    def tie(eid: str) -> dict:
        if eid not in ties:
            ent = L.get(eid)
            ties[eid] = {"id": eid, "kind": ent["kind"], "role": "", "joins": [], "where": "", "place": "",
                         "dead": False, "uses": []}
            names[eid] = ent["name"]
        return ties[eid]

    # what the seed brings in - unless it's on file already, then it's a tie (never a duplicate)
    for kind, field_, cap in (("location", "places", "location"), ("faction", "outfits", "faction"),
                              ("npc", "people", "npc")):
        for it in _list(plan.get(field_))[:LIMITS[cap]]:
            if not isinstance(it, dict):
                continue
            name, true = _s(it.get("name"), 80) or _s(it.get("key"), 80), _s(it.get("true_name"), 80)
            if not name:
                continue
            if true.lower() == name.lower():
                true = ""
            found = L.find(name) or (L.find(true) if true else None)
            if found and found["kind"] == kind:
                t = tie(found["id"])
                t["role"] = " ".join(x for x in (t["role"], _s(it.get("secret"))) if x)
                t["joins"] += _memberships((it.get("persona") or {}).get("affiliations"))
                t["where"], t["place"] = t["where"] or _s(it.get("where")), t["place"] or _s(it.get("place"))
                t["dead"] = t["dead"] or bool(it.get("dead"))
                claim([it.get("key"), name, true], found["id"])
                w["linked"].append(found["id"])
                continue
            ref = "+" + (_s(it.get("key")) or name).lower()
            if any(x["ref"] == ref for x in w["people"] + w["outfits"] + w["places"]):
                continue
            e = {"ref": ref, "kind": kind, "name": name, "true_name": true, "description": _s(it.get("description"), 400),
                 "secret": _s(it.get("secret")), "sealed": not it.get("known", True)}
            if kind == "npc":
                e.update(template=sr_lite.npc_template(it.get("template")) or "civilian", dead=bool(it.get("dead")),
                         where=_s(it.get("where"), 200), place=_s(it.get("place")),
                         persona=it.get("persona") if isinstance(it.get("persona"), dict) else {})
            elif kind == "faction":
                e["profile"] = it.get("profile") if isinstance(it.get("profile"), dict) else {}
            else:
                e.update(district=_s(it.get("district")), near=_s(it.get("near")))
            w[field_].append(e)
            names[ref] = name
            claim([it.get("key"), name, true], ref)

    def ref(x) -> str | None:
        """A key, a name or an [id] -> its ref. A handle with words after it ("The Bosun, for a client he won't
        name") is read by its lead too - the live read wrote the job's client that way."""
        h = _s(x).strip().strip("[]")
        if not h:
            return None
        for cand in dict.fromkeys([h] + [h.split(cut)[0].strip() for cut in (",", " (", " - ", " for ", ";")
                                         if cut in h]):
            if cand.lower() in keys:
                return keys[cand.lower()]
            ent = L.find(cand)
            if ent:
                names.setdefault(ent["id"], ent["name"])
                return ent["id"]
        nid = norm_id(h)
        return nid if SLICE_RE.match(nid) and S.exists(nid) else None

    def kind_of(r: str | None) -> str | None:
        if not r:
            return None
        if r.startswith("+"):
            return next((e["kind"] for e in w["people"] + w["outfits"] + w["places"] if e["ref"] == r), None)
        ent = L.get(r)
        return ent["kind"] if ent else "node"

    dead = {e["id"] for e in L.entities(kind="npc") if sr_lite.condition(L, e["id"]) == "dead"}

    def alive(r: str | None, what: str) -> bool:
        """An NPC dead on file can't act in the story: the use goes on a doubt instead (the record wins)."""
        if r in dead:
            tie(r)["uses"].append(what)
            return False
        return True

    def actor(x, what: str) -> str | None:
        r = ref(x)
        if kind_of(r) not in ("npc", "faction"):
            if _s(x):
                w["problems"].append(f"{what}: no one on file or in the seed called '{_s(x)}'")
            return None
        return r if alive(r, what) else None

    for it in _list(plan.get("ties"))[:LIMITS["tie"]]:
        if not isinstance(it, dict):
            continue
        r = ref(it.get("id"))
        if not r or r.startswith("+") or kind_of(r) == "node":
            w["problems"].append(f"tie: nobody on file as '{_s(it.get('id'))}'")
            continue
        t = tie(r)
        t["role"] = " ".join(x for x in (t["role"], _s(it.get("role"))) if x)
        t["joins"] += _memberships(it.get("joins"))
        t["where"], t["place"] = _s(it.get("where"), 200) or t["where"], _s(it.get("place")) or t["place"]
        t["dead"] = t["dead"] or bool(it.get("dead"))
        if r not in w["linked"]:
            w["linked"].append(r)
    for t in ties.values():
        if t["kind"] == "npc" and (t["joins"] or t["where"]) and not alive(t["id"], "back in the story"
                                                                          + (f": {t['role']}" if t["role"] else "")):
            t["joins"], t["where"], t["role"] = [], "", ""      # (their part waits on the doubt, never filed over it)

    def joins(pairs, who: str) -> tuple[list[tuple[str, str]], list[str]]:
        """'Outfit (role)' pairs -> [(ref, role)] for the outfits on file or in the seed, and the rest as text. apply
        never brings in an outfit review hasn't seen: a name the read slipped ('the Hook Street crew') would be a public
        faction, unsealed and unguarded, under the GM's own word."""
        got, lost = [], []
        for n, role in pairs:
            plain = n[4:].strip() if n.lower().startswith("the ") else n
            r = next((x for x in (ref(n), ref(plain), ref(f"the {plain}")) if kind_of(x) == "faction"), None)
            if r and r not in [x for x, _ in got]:
                got.append((r, role))
            elif not r:
                lost.append(f"{n} ({role})")
                w["problems"].append(f"{who} belongs to '{n}': no outfit on file or in the seed by that name - "
                                     "not filed")
        return got, lost
    for e in w["people"]:
        e["joins"], lost = joins(_memberships(e["persona"].get("affiliations")), e["name"])
        if lost:
            e["secret"] = " ".join(x for x in (e["secret"], f"(The story has them in {'; '.join(lost)} - no such "
                                                            "outfit on file or in the seed, so not filed.)") if x)
    for t in ties.values():
        t["joins"], lost = joins(t["joins"], names[t["id"]])
        if lost:
            t["role"] = " ".join(x for x in (t["role"], f"(The story has them in {'; '.join(lost)} - no such outfit "
                                                        "on file or in the seed, so not filed.)") if x)

    # the secret guard: what the crew could know, and what no public line may say
    vocab = vocabulary(game, player)
    new = w["people"] + w["outfits"] + w["places"]
    for e in new:
        e["read"] = e["name"]                       # (the read's own name for them, before any handle)
    for e in new:                                   # a name the player-safe story never says is the GM's: sealed
        if not e["sealed"] and unsupported(e["name"], vocab):
            e["sealed"] = True
    explicit = [_s(x) for x in _list(plan.get("secret_words"))[:LIMITS["secret"]]]
    w["secret_words"] = [x for x in explicit if x]     # (the read's own: what the spoiler guard cuts besides names)
    explicit += [e["true_name"] for e in new if e["true_name"]] + [e["name"] for e in new if e["sealed"]]
    terms = secret_terms(player, gm, explicit, vocab)
    for e in new:
        if not e["sealed"] and leaks(e["name"], terms):
            e["sealed"] = True
    terms = secret_terms(player, gm, explicit + [e["name"] for e in new if e["sealed"]], vocab)
    w["terms"], w["sealed"] = terms, [e["ref"] for e in new if e["sealed"]]
    w["cased"] = plain_words(player, gm, terms)
    sealed = set(w["sealed"])
    taken = {e["name"].lower() for e in new}
    for e in new:
        # what anyone sees of them goes public the moment the crew meets them: never a secret word - and for the
        # sealed (the GM's half wrote it) never a name the players haven't met
        d = e["description"]
        if d and (leaks(d, terms) or (e["sealed"] and unsupported(d, vocab))):
            w["guarded"].append(("description", e["name"]))
            e["secret"] = " ".join(x for x in (e["secret"], f"(What the read wrote as their public description: "
                                                            f"{d})") if x)
            e["description"] = ""
        if not (e["sealed"] and (unsupported(e["name"], vocab) or leaks(e["name"], terms))):
            continue
        # sealed for their name: meeting them unseals who they are, never what the GM's half calls them
        secret, base = e["name"], handle_for(e["kind"], e["description"])
        name, n = base, 2
        while name.lower() in taken or L.find(name) or (name.lower().startswith("the ") and L.find(name[4:])):
            name, n = f"{base} #{n}", n + 1
        taken.add(name.lower())
        if e["true_name"]:
            e["secret"] = " ".join(x for x in (f"(The story's GM file calls them {secret}.)", e["secret"]) if x)
            e["gm_name"] = secret
        else:
            e["true_name"] = secret
        e["name"], e["handled"] = name, True
        names[e["ref"]] = name
        claim([name], e["ref"])
    # every label the GM file gives anyone, handled or not - the spoiler guard's (props gm_names): a public NPC's
    # nickname is as much the GM's as a real name
    # (someone else's name, real or on file, is never their label)
    taken = [e["name"] for e in new] + [e["read"] for e in new if not e.get("handled")] + [
        e["true_name"] for e in new] + [e["name"] for e in L.entities(status=None)]
    for e in new:
        e["gm_names"] = list(dict.fromkeys(([e["gm_name"]] if e.get("gm_name") else [])
                                           + gm_labels(gm, [e["true_name"], e["read"], e["name"]], player, taken)))
    for t in ties.values():
        ent = L.get(t["id"])
        t["gm_names"] = gm_labels(gm, [(ent["props"] or {}).get("true_name"), ent["name"]], player, taken)
    if leaks(w["title"], terms) or unsupported(w["title"], vocab):     # (it rides on the turns the table can read)
        w["title"] = "the story seed"

    def clean(text: str, what: str) -> bool:
        hits = leaks(text, terms)
        if hits:
            w["guarded"].append((what, _s(text, 120)))
        return not hits

    def knowers(v) -> list[tuple[str, str | None]]:
        out = []
        for k in _list(v):
            who, source = _pair(k, ("who", "source"))
            h = actor(who, "knows")
            if h and h not in [x for x, _ in out]:
                out.append((h, ref(source) if source else None))
        return out

    def about(v) -> list[str]:
        return [r for r in dict.fromkeys(ref(x) for x in _list(v)) if r]

    for f in _list(plan.get("facts"))[:LIMITS["fact"]]:
        if not isinstance(f, dict) or not _s(f.get("text")):
            continue
        item = {"text": _s(f["text"], 600), "about": about(f.get("about")), "known_by": knowers(f.get("known_by"))}
        public = bool(f.get("public")) and clean(item["text"], "fact")
        (w["facts"] if public else w["notes"]).append(item)

    # the clock: when the story opens (apply moves it there), and every due counted from that. The clock has no
    # weekdays - "next Friday" is a line it can't read, and the owner is told rather than the goal moving at once.
    o = plan.get("opening") if isinstance(plan.get("opening"), dict) else {}
    has_opening = bool(_s(o.get("narration")) or _s(o.get("title")))
    now = game.clock()
    at = _due(_s(o.get("time")), now) if has_opening else None
    start = at if at is not None and at > now else now

    def unread(text: str, what: str, then: str) -> bool:
        if text and _due(text, start) is None:
            w["problems"].append(f"{what}: the clock can't read '{text}' - {then}")
            return True
        return False
    if has_opening:
        unread(_s(o.get("time")), "the opening's time", "the clock stays where it is")

    def died(r: str) -> int | None:
        """When the ledger killed them, in story time (None when it can't tell)."""
        row = game.conn.execute("SELECT turn_id FROM events WHERE kind='damage' AND actor=? AND payload LIKE "
                                "'%\"dead\"%' ORDER BY seq DESC LIMIT 1", (r,)).fetchone()
        node = S.node(f"T{row[0]}") if row and row[0] else None
        return node["story_time"] if node and node["story_time"] is not None else None
    for ev in sorted((e for e in _list(plan.get("events"))[:LIMITS["event"]] if isinstance(e, dict)
                      and _s(e.get("text"))), key=lambda e: -_int(e.get("days_before"), 0, 3650)):
        who = []
        for m in _list(ev.get("who")):
            name, role = _pair(m)
            r = ref(name)
            if r and kind_of(r) != "pc" and r not in [x for x, _ in who]:
                who.append((r, role.lower() if role.lower() in ROLES else "present"))
        text, days = _s(ev["text"], 600), _int(ev.get("days_before"), 0, 3650)
        when = max(0, start - days * clock.DAY)
        # someone dead on file acting or there after their death: the record wins - the event waits on their doubt
        gone = {r: died(r) for r, _ in who if r in dead}
        ghosts = [r for r, role in who if r in gone and role in ("actor", "present")
                  and not (gone[r] is not None and when < gone[r])]
        if ghosts:
            for r in ghosts:
                alive(r, f"offscreen, {days} day(s) before the opening: {text}")
            continue
        w["events"].append({"text": text, "days": days, "who": who, "known_by": knowers(ev.get("known_by"))})
    for f in _list(plan.get("feelings"))[:LIMITS["feeling"]]:
        if not isinstance(f, dict) or not _s(f.get("belief")):
            continue
        h, a = actor(f.get("holder"), "feels"), ref(f.get("about"))
        if h and a and a != h and kind_of(a) in ("pc", "npc", "faction") and kind_of(h) == "npc":
            w["feelings"].append({"holder": h, "about": a, "attitude": _int(f.get("attitude"), -3, 3),
                                  "belief": _s(f["belief"], 300)})
    for a in _list(plan.get("agendas"))[:LIMITS["agenda"]]:
        if isinstance(a, dict) and _s(a.get("goal")):
            who = actor(a.get("who"), "wants")
            if who:
                w["agendas"].append({"who": who, "goal": _s(a["goal"], 300), "targets": about(a.get("targets")),
                                     "due": _s(a.get("due"))})
                unread(_s(a.get("due")), f"{names.get(who, who)}'s goal '{_s(a['goal'], 80)}'",
                       "it waits a day instead of moving at once")
    for h in _list(plan.get("hooks"))[:LIMITS["hook"]]:
        if isinstance(h, dict) and _s(h.get("text")):
            src = actor(h.get("source"), "a hook")
            if src:
                w["hooks"].append({"source": src, "text": _s(h["text"], 500), "about": about(h.get("about"))})
    for q in _list(plan.get("tensions"))[:LIMITS["tension"]]:
        if not isinstance(q, dict) or not _s(q.get("question")):
            continue
        item = {"question": _s(q["question"], 300), "public": _s(q.get("public"), 300), "about": about(q.get("about")),
                "stakes": _int(q.get("stakes"), 1, 3, 2), "due": _s(q.get("due")), "next": _s(q.get("next"), 300),
                "note": ""}
        if item["public"] and not clean(item["public"], "an open question's public line"):
            item["note"], item["public"] = f"What the crew was to know of it: {item['public']}", ""
        if not clean(item["question"], "an open question"):   # (the question shows on the dashboard)
            item["note"] = " ".join(x for x in (f"The question in full: {item['question']}", item["note"]) if x)
            item["question"] = item["public"] or f"What the story '{w['title']}' left open"
        unread(item["due"], f"the open question '{_s(q['question'], 80)}'", "it has no deadline")
        w["tensions"].append(item)
    j = plan.get("job") if isinstance(plan.get("job"), dict) else {}
    if j.get("offered") and _s(j.get("title")):
        job = {k: _s(j.get(k), 300) for k in ("title", "objective", "pay", "deadline")}
        for k in list(job):
            if job[k] and not clean(job[k], f"the job's {k}"):
                job[k] = ""
        client = ref(j.get("client"))
        job["client"] = client if client and client not in sealed and kind_of(client) in ("npc", "faction") else None
        job["title"] = job["title"] or "The job from the opening"
        w["job"] = job
    for c in _list(plan.get("contradictions"))[:LIMITS["doubt"]]:
        if not isinstance(c, dict) or not (_s(c.get("story")) or _s(c.get("record"))):
            continue
        ids = [r for r in about(c.get("ids")) if not r.startswith("+")]
        w["doubts"].append({"text": f"The story seed '{w['title']}' says: {_s(c.get('story'))} The record: "
                                    f"{_s(c.get('record'))}", "ids": ids})

    # the opening - only who and what the crew could see, under the names they'd know
    if has_opening:
        cast = []
        for n, c in enumerate(_list(o.get("cast"))[:LIMITS["cast"]]):
            slot, story = _pair(c, ("slot", "story_name"))
            slot = slot.upper().strip("{} ")
            slot = slot if re.fullmatch(r"PC\d+", slot) and slot not in [x["slot"] for x in cast] else f"PC{n + 1}"
            cast.append({"slot": slot, "story_name": _s(story, 60)})
        place = ref(o.get("place"))
        if kind_of(place) != "location":
            w["problems"].append(f"the opening's place '{_s(o.get('place'))}' isn't a place")
            place = None
        elif place in sealed:                         # the crew stands there: it can't be the GM's alone
            spot = next(e for e in w["places"] if e["ref"] == place)
            if spot.get("handled"):                   # (its name is the GM's: no place, rather than the secret one)
                place = None
            else:
                sealed.discard(place)
                w["sealed"].remove(place)
                spot["sealed"] = False

        def seen(r: str | None) -> bool:
            """Someone the crew could have seen as who they are: what the seed brings in that isn't sealed, or someone
            on file the player-safe story names - as a whole name, MIN_NAME letters or more ('Lo' isn't in 'Lone
            Star'). An outrider in a scratched-out cut is anyone, to them; a scene, turn or fact id is no one."""
            if not r or r in sealed or kind_of(r) == "pc":
                return False
            if r.startswith("+"):
                return True
            ent = L.get(r)
            if not ent:
                return False
            return any(_says(player, n) for n in [ent["name"]] + ent["aliases"] if n and len(n) >= MIN_NAME)
        present = [r for r in dict.fromkeys(ref(x) for x in _list(o.get("present"))[:LIMITS["present"]])
                   if seen(r) and kind_of(r) == "npc" and alive(r, "is in the opening scene")]
        moment = []
        for m in _list(o.get("in_moment"))[:LIMITS["moment"]]:
            name, role = _pair(m)
            r = ref(name)
            if seen(r) and r not in [x for x, _ in moment] and (kind_of(r) == "location" or alive(r, "is in the "
                                                                                                  "opening")):
                moment.append((r, role.lower() if role.lower() in ROLES else "present"))
        title = _s(o.get("title"), 100)
        if not title or leaks(title, terms) or unsupported(title, vocab):
            title = "Opening"
        narration = (o.get("narration") or "").strip()
        if not narration or leaks(narration, terms) or unsupported(narration, vocab):
            if narration:
                w["guarded"].append(("the opening", "the read's narration - the author's own words stand in"))
            narration = author_text(player, cast)
        summary = _s(o.get("summary"), 400)
        if summary and (leaks(summary, terms) or unsupported(summary, vocab)):
            w["guarded"].append(("the opening's summary", _s(summary, 120)))
            summary = ""
        deaths = [e["ref"] for e in w["people"] if e.get("dead") and e["ref"] in [x for x, _ in moment]]
        w["opening"] = {"title": title, "place": place, "time": _s(o.get("time")), "present": present,
                        "moment": moment, "cast": cast, "narration": narration, "summary": summary,
                        "gm_first": _s(o.get("gm_first")), "deaths": deaths}

    # a public fact never links to who's sealed (sealed_ids: a public fact about them means the crew has met them -
    # in the tests' night-ferry story, "the flyers are for a fight nobody has heard of" about the smuggler would unseal
    # him before anyone played). The street knows the fact; that it's about them rides a GM note on them.
    for f in w["facts"]:
        hid = [r for r in f["about"] if r in sealed]
        if hid:
            f["about"] = [r for r in f["about"] if r not in sealed]
            w["notes"].append({"text": f"The street knows this, not that it touches them: {f['text']}", "about": hid,
                               "known_by": []})

    # the record wins: a death the story claims that the ledger hasn't, and anyone dead on file it brings back
    for t in ties.values():
        ent = L.get(t["id"])
        cond = sr_lite.condition(L, t["id"]) if ent["kind"] == "npc" else None
        if t["dead"] and cond and cond != "dead":
            w["doubts"].append({"text": f"The story seed '{w['title']}' has {ent['name']} dead; the ledger has them "
                                        f"{cond}.", "ids": [t["id"]]})
        if t["uses"]:
            when = game.conn.execute("SELECT turn_id FROM events WHERE kind='damage' AND actor=? AND payload LIKE "
                                     "'%\"dead\"%' ORDER BY seq DESC LIMIT 1", (t["id"],)).fetchone()
            ids = [t["id"]] + ([f"T{when[0]}"] if when and S.exists(f"T{when[0]}") else [])
            w["doubts"].append({"text": f"The story seed '{w['title']}' has {ent['name']} alive "
                                        f"({'; '.join(dict.fromkeys(t['uses']))}); the ledger has {ent['name']} dead"
                                        + (f" since T{when[0]}" if when else "") + ". Held back until it's settled.",
                                "ids": ids})
    w["ties"] = list(ties.values())
    return w


# ── preview ─────────────────────────────────────────────────────────────

SEED_COLOR = 0x2ECC71


def _n(k: int, one: str, many: str | None = None) -> str:
    return f"{k} {one if k == 1 else (many or one + 's')}"


def counts(w: dict) -> dict:
    new = w["people"] + w["outfits"] + w["places"]
    return {"people": len(w["people"]), "outfits": len(w["outfits"]), "places": len(w["places"]),
            "public_facts": len(w["facts"]), "gm_facts": len(w["notes"]), "events": len(w["events"]),
            "feelings": len(w["feelings"]), "agendas": len(w["agendas"]), "hooks": len(w["hooks"]),
            "tensions": len(w["tensions"]), "job": 1 if w["job"] else 0, "doubts": len(w["doubts"]),
            "ties": len(w["ties"]), "sealed": sum(1 for e in new if e["sealed"]),
            "identities": sum(1 for e in w["people"] if e["true_name"] or e["sealed"]),
            "hearsay": sum(len(x["known_by"]) for x in w["facts"] + w["notes"] + w["events"]),
            "guarded": len(w["guarded"])}


def preview(game, w: dict, full: bool = False) -> list[dict]:
    """The plan as cards. Spoiler-free unless full: the public items in full, the GM-only ones only as counts."""
    L, c = game.ledger, counts(w)
    name = lambda r: w["names"].get(r) or (L.get(r) or {}).get("name") or r          # noqa: E731
    files = "  ·  ".join(f"`{n}`" + (" (GM-only)" if gm else "") for n, gm in w["files"])
    adds = ", ".join(x for x in (_n(c["people"], "person", "people"), _n(c["outfits"], "outfit"),
                                 _n(c["places"], "place"), _n(c["public_facts"], "public fact"),
                                 _n(c["tensions"], "open question"), "a job" if c["job"] else "") if x)
    sealed = ", ".join(x for x in (_n(c["identities"], "secret identity", "secret identities") + " sealed",
                                   _n(c["gm_facts"], "GM-only fact"), _n(c["events"], "offscreen event"),
                                   _n(c["agendas"], "goal"), _n(c["hooks"], "hook"), _n(c["feelings"], "feeling"),
                                   _n(c["hearsay"], "who-knows-what"),
                                   _n(c["sealed"], "name") + " the crew hasn't heard"))
    head = [f"From {files}", f"**Adds:** {adds}", f"**GM-only:** {sealed}",
            f"**Touches** {_n(c['ties'], 'person or place', 'people and places')} already in the world."]
    if c["doubts"]:
        head.append(f"**Doubts:** {_n(c['doubts'], 'place', 'places')} the story disagrees with the record - held back "
                    "and raised for the GM (`!doubts`, by DM - spoilers).")
    if c["guarded"]:
        head.append(f"⚠️ {_n(c['guarded'], 'public line')} named something only the GM's half knows - "
                    "kept GM-only.")
    if w["problems"] and not full:                    # (their words can be the GM's: only how many, here)
        head.append(f"⚠️ {_n(len(w['problems']), 'thing')} the engine couldn't place or the clock can't read (a "
                    "weekday, an outfit nobody listed) - not filed as written; `!seed preview full` lists them by DM.")
    cards = [{"title": f"🌱 Seed: {w['title']}" + (" - the whole plan (spoilers)" if full else " - preview"),
              "description": "\n".join(head), "color": SEED_COLOR}]
    who = []
    for e in w["people"] + w["outfits"] + w["places"]:
        if e["sealed"] and not full:
            continue
        label = {"npc": e.get("template", ""), "faction": "outfit", "location": "place"}[e["kind"]]
        line = f"• **{e['name']}** ({label}" + (", dies in the opening" if e.get("dead") else "") + ")"
        line += f" - {e['description']}" if e["description"] else ""
        if full:
            line += "".join(f"\n  ↳ {k}: {v}" for k, v in (("SEALED", "the crew hasn't heard of them" if e["sealed"]
                                                             else ""), ("real name", e["true_name"]),
                                                            ("secret", e["secret"])) if v)
        who.append(line)
    if who:
        cards.append({"title": "👥 Who and what it brings in" + ("" if full else " (as the crew would know them)"),
                      "description": "\n".join(who), "color": SEED_COLOR})
    if w["facts"]:
        cards.append({"title": "📜 What the street knows (public facts)",
                      "description": "\n".join(f"• {f['text']}" for f in w["facts"]), "color": SEED_COLOR})
    o = w["opening"]
    if o:
        body = [f"**{o['title']}** at **{name(o['place']) if o['place'] else '(no place)'}**"
                + (f" · {o['time']}" if o["time"] else ""),
                "Here when the players take over: " + (", ".join(name(r) for r in o["present"]) or "nobody else"),
                "The crew: " + (", ".join(f"{x['slot']} = *{x['story_name']}*" for x in o["cast"]) or "-")
                + " - the runners at the table fill these, a named one by name first",
                "The GM's first move is set (GM-only)." if o["gm_first"] and not full else ""]
        if w["job"]:
            j = w["job"]
            body.append(f"**Job:** {j['title']}" + (f" for {name(j['client'])}" if j["client"] else "")
                        + "".join(f" · {k}: {j[k]}" for k in ("objective", "pay", "deadline") if j[k]))
        public_qs = [q["public"] for q in w["tensions"] if q["public"]]
        if public_qs:
            body.append("**What the crew knows is open:** " + " · ".join(public_qs))
        cards.append({"title": "🎬 The opening", "description": "\n".join(x for x in body if x), "color": SEED_COLOR})
        from .discord_bot.render import EMBED_LIMIT, chunks
        parts = chunks(o["narration"], EMBED_LIMIT - 200)
        cards += [{"title": f"📖 Opening narration ({k + 1}/{len(parts)})" if len(parts) > 1 else "📖 Opening narration",
                   "description": p, "color": SEED_COLOR} for k, p in enumerate(parts)]
    if full:
        cards += _full_cards(game, w, name)
    return cards


def _full_cards(game, w: dict, name) -> list[dict]:
    """Everything GM-only, for the owner who isn't playing (by DM)."""
    from .discord_bot.render import EMBED_LIMIT, chunks
    rows = [f"**Intent:** {w['intent']}", f"**Arc:** {w['arc']}"]
    rows += [f"**Tie:** {name(t['id'])} - {t['role']}" + (f" · joins {', '.join(name(r) for r, _ in t['joins'])}"
                                                         if t["joins"] else "")
             + (f" · now: {t['where']}" if t["where"] else "") for t in w["ties"]]
    rows += [f"**GM fact:** {f['text']}" for f in w["notes"]]
    rows += [f"**Offscreen, {e['days']} day(s) before:** {e['text']}" for e in w["events"]]
    rows += [f"**Feels:** {name(f['holder'])} -> {name(f['about'])} {f['attitude']:+d}: {f['belief']}"
             for f in w["feelings"]]
    rows += [f"**Goal:** {name(a['who'])}: {a['goal']}" + (f" (next: {a['due']})" if a["due"] else "")
             for a in w["agendas"]]
    rows += [f"**Hook:** from {name(h['source'])}: {h['text']}" for h in w["hooks"]]
    rows += [f"**Question:** {q['question']}" + (f" · next: {q['next']}" if q["next"] else "")
             + (f" · {q['note']}" if q["note"] else "") for q in w["tensions"]]
    rows += [f"**Doubt:** {d['text']}" for d in w["doubts"]]
    if w["opening"] and w["opening"]["gm_first"]:
        rows.append(f"**The GM's first move:** {w['opening']['gm_first']}")
    rows += [f"**Kept GM-only ({what}):** {text}" for what, text in w["guarded"]]
    rows += [f"**Couldn't place:** {p}" for p in w["problems"]]
    rows.append(f"**Secret words guarded:** {', '.join(w['terms'][:60])}")
    return [{"title": "🔒 GM-only" + (f" ({k + 1})" if k else ""), "description": part, "color": 0x95A5A6}
            for k, part in enumerate(chunks("\n".join(rows), EMBED_LIMIT - 100))]


def preview_text(game, w: dict, full: bool = False) -> str:
    """The same, for the console."""
    return "\n\n".join(f"== {c['title']} ==\n{c['description']}" for c in preview(game, w, full)).replace("**", "")


# ── apply ───────────────────────────────────────────────────────────────

def _kill(game, eid: str, turn: int) -> None:
    """Dead in the story: the ledger's own death - a full physical track and past it."""
    from .engine.rules import sr_lite
    L = game.ledger
    pmax, _ = sr_lite.monitor_max(L, eid)
    boxes = int(pmax + L.stat(eid, "body", 2) + 1)
    L.set_stat(eid, "physical_damage", boxes)
    L.log(turn, "damage", eid, {"boxes": boxes, "type": "physical", "status": "dead", "by": "seed"})


def _due(text: str, base: int) -> int | None:
    if not text:
        return None
    try:
        return clock.parse(text, base)
    except ValueError:
        return None


def applied(game) -> list[dict]:
    try:
        v = json.loads(game.ledger.meta(META_APPLIED) or "[]")
    except ValueError:
        return []
    return v if isinstance(v, list) else []


def apply(game, docs: list[Doc], plan: dict, seed: str = "") -> dict:
    """File the plan through the engine's own paths, in one transaction, after a backup and an undo point. Returns
    what was filed (spoiler-free counts and GM-only lines)."""
    from . import db
    from .dm import doubts, tensions, world
    L, S, conn = game.ledger, game.sub, game.conn
    w = review(game, docs, plan)
    if w["opening"] and pending(game):
        raise LedgerError(WAITING + ".")
    slug = re.sub(r"[^a-z0-9]+", "-", (seed or w["title"]).lower()).strip("-")[:40] or "seed"
    t = game.turn_no() + 1
    backup = game.path.parent / f"{game.path.stem}_seeds" / f"before_{slug}_{time.strftime('%Y%m%d-%H%M%S')}.db"
    db.snapshot(conn, backup)                      # (a copy kept for good - the undo points roll over)
    game.snapshot(t)                               # the undo point: !undo takes the seed back like a turn
    made: dict[str, str] = {}
    tag = f"Seed '{w['title']}'"
    lines: list[str] = []

    def eid(r: str | None) -> str | None:
        return made.get(r) if r and r.startswith("+") else r

    def ids(refs) -> list[str]:
        return [x for x in (eid(r) for r in refs) if x]

    def sealing(e: dict, xid: str) -> str:
        """The GM's line on a real name behind a handle, and on who's sealed - so the packet says the crew doesn't
        know them, and the GM's own narration isn't the next leak."""
        bits = [f"Real name: {e['true_name']} - secret until the story reveals it (then `name {xid}: "
                f"{e['true_name']}`)." if e["true_name"] else ""]
        if e["sealed"] and e.get("handled"):
            bits.append(f"SEALED: the crew knows this one only as '{e['name']}', if they've seen them at all - the "
                        f"name {e['true_name']} and what they really are stay out of what the players hear until the "
                        "story reveals them.")
        elif e["sealed"]:
            bits.append("SEALED: the crew hasn't met or heard of this one yet - keep who they are out of what the "
                        "players hear until the story brings them in.")
        return " ".join(x for x in bits if x)

    from . import graphlog
    graphlog.before_seed(game)                     # (its minds file tells its own changes from what came before)
    conn.execute("BEGIN")
    try:
        now = game.clock()
        o = w["opening"]
        when = _due(o["time"], now) if o else None
        if when is not None and when > now:          # (never back: the record already happened)
            game.set_clock(when)
        start = game.clock()
        for p in w["places"]:
            near = eid(p["near"]) if p["near"] else None
            lid, _ = game.introduce("location", p["name"], p["description"], turn=t,
                                    where={"district": p["district"] or None, "near": near})
            made[p["ref"]] = lid
            secret = " ".join(x for x in (sealing(p, lid), p["secret"]) if x)
            if secret:
                S.add_note([lid], f"{tag}: {secret}", t)
        for f in w["outfits"]:
            fid = world.ensure_faction(game, f["name"], t) or game.introduce("faction", f["name"], turn=t)[0]
            made[f["ref"]] = fid
            ent, prof = L.get(fid), f["profile"]
            if f["description"] and not ent["description"]:
                L.update_entity(fid, description=f["description"])
            if not world.persona(ent) and prof:
                L.update_entity(fid, props={**L.get(fid)["props"],
                                            "persona": {k: _s(prof.get(k)) for k in world.FACTION_FIELDS}})
                L.set_stat(fid, "reach", _int(prof.get("reach"), 1, 6, 2))
                L.set_stat(fid, "nuyen", _int(prof.get("funds"), 0, 10_000_000, 10000))
            S.ensure_entity(L.get(fid), t)
            secret = " ".join(x for x in (sealing(f, fid), f["secret"]) if x)
            if secret:
                S.add_note([fid], f"{tag}: {secret}", t)
        pictures: dict[str, list[str]] = {}
        for p in w["people"]:
            nid, created = game.introduce("npc", p["name"], p["description"], p["template"], turn=t)
            made[p["ref"]] = nid
            ent = L.get(nid)
            pictures[nid] = [x for x in (p["secret"], sealing(p, nid)) if x]
            if world.persona(ent) or not p["persona"]:
                continue
            pers = p["persona"]                       # (the read's one-line lists -> world.persona's own shape)
            bible = {k: _s(pers.get(k)) for k in world.PERSONA_FIELDS}
            threads = pers.get("hooks")
            bible["hooks"] = ([_s(x) for x in threads] if isinstance(threads, list)
                              else [x for x in re.split(r"\s*;\s*", _s(threads)) if x])
            joined = [(eid(r), role) for r, role in p["joins"][:2]      # (review resolved them: never a new outfit)
                      if (L.get(eid(r) or "") or {}).get("kind") == "faction"]
            bible["affiliations"] = [{"name": L.get(f)["name"], "role": role} for f, role in joined]
            L.update_entity(nid, props={**ent["props"], "persona": bible}, tier=2)
            for fid, role in joined:
                world.join_faction(game, nid, fid, role, t)
        for p in w["people"]:                       # (after every outfit and place is filed: where they are)
            if p["where"] and not (o and p["ref"] in o["present"]):
                world.move(game, made[p["ref"]], p["where"], eid(w["keys"].get(p["place"].lower(), p["place"]))
                           if p["place"] else None)
        for x in w["ties"]:
            S.ensure_entity(L.get(x["id"]), t)
            if x["role"]:
                S.add_note([x["id"]], f"{tag}: {x['role']}", t)
            for r, role in x["joins"] if x["kind"] == "npc" else []:   # (resolved in review: never a new outfit)
                fid = eid(r)
                if fid and (L.get(fid) or {}).get("kind") == "faction":
                    world.join_faction(game, x["id"], fid, role, t)
                    ent = L.get(x["id"])
                    bible = world.persona(ent)
                    if bible is not None and L.get(fid)["name"] not in [a.get("name") for a in
                                                                        bible.get("affiliations") or []]:
                        L.update_entity(x["id"], props={**ent["props"], "persona": {    # (added to, never rewritten)
                            **bible, "affiliations": list(bible.get("affiliations") or [])
                            + [{"name": L.get(fid)["name"], "role": role}]}})
            if x["where"] and x["kind"] == "npc" and (L.scene_of(x["id"]) != (L.current_scene() or {}).get("id")):
                world.move(game, x["id"], x["where"], eid(w["keys"].get(x["place"].lower(), x["place"]))
                           if x["place"] else None)
        sid = None
        if o:
            sid = game.new_scene(o["title"], eid(o["place"]), [], t)
            if o["present"]:
                game.enter_scene(ids(o["present"]), t, sid)
        # (no opening: the seed's turn is in no scene - an empty narration filed in the scene being played would stand
        # in for the GM's real last one in the next turn's packet and the frame: Ledger.last_turn counts 'seed' turns)
        tid = L.begin_turn(sid, [["seed", w["title"]]], status="seed")
        if tid != t:
            raise LedgerError(f"The turn count moved under the seed (T{tid}, expected T{t}) - try again.")
        # the seed itself, on the world spine: offscreen, so the doubts it raises are never asked of the table
        marker = S.write_offscreen(t, f"(The story seed '{w['title']}' was read into the world here - GM-only. "
                                      f"{w['intent']})", [], None, story_time=start)
        for e in w["events"]:
            members = [(eid(r), role) for r, role in e["who"] if eid(r)]
            wid = S.write_offscreen(t, e["text"], members, None, story_time=max(0, start - e["days"] * clock.DAY))
            for h, src in e["known_by"]:
                if eid(h) not in dict(members):
                    S.add_knows(eid(h), wid, "told" if src else "rumor", eid(src), t)
        public_facts = []
        for f in w["facts"]:
            fid = S.add_fact(f["text"], ids(f["about"]), t, by="seed")
            public_facts.append(fid)
            for h, src in f["known_by"]:
                S.add_knows(eid(h), fid, "told" if src else "rumor", eid(src), t)
        for f in w["notes"]:                         # GM-only: a note rides who it's about and who knows it
            S.add_note(list(dict.fromkeys(ids(f["about"]) + [eid(h) for h, _ in f["known_by"]])) or [marker],
                       f"{tag}: {f['text']}", t)
        for f in w["feelings"]:
            h, a = eid(f["holder"]), eid(f["about"])
            bid = S.add_belief(h, a, f["belief"], t, story_time=start)
            L.set_stat(h, f"attitude:{a}", f["attitude"])
            L.log(t, "belief", h, {"about": a, "attitude": f["attitude"], "belief": bid, "by": "seed"})
            if (L.get(h) or {}).get("tier", 1) < 2:
                L.update_entity(h, tier=2)                # (a view of their own: a mind)
        for a in w["agendas"]:                      # ("" is right away; a due the clock can't read waits - review says)
            due = _due(a["due"], start)
            world.add_agenda(game, eid(a["who"]), a["goal"], ids(a["targets"]), t, by="seed",
                             due_in=max(0, due - game.clock()) if due is not None else UNREAD_WAIT if a["due"] else 0)
        for h in w["hooks"]:
            world.add_hook(game, eid(h["source"]), None, h["text"], ids(h["about"]), t)
        for q in w["tensions"]:
            qid = tensions.open_tension(game, q["question"], ids(q["about"]), t, q["stakes"], q["next"] or None,
                                        q["public"] or None, _due(q["due"], start), by="seed")
            if q["note"]:
                S.add_note([qid], f"{tag}: {q['note']}", t)
        raised = []
        for d in w["doubts"]:
            r = doubts.raise_(game, d["text"], ids(d["ids"]) + [marker], t, by="seed")
            raised.append(r["id"])
        for nid, bits in pictures.items():            # last: a picture folds every note on them written so far
            notes = [n["text"] for n in S.notes_for(nid, 12)][::-1]
            text = " ".join(bits + notes)
            if text:
                S.clarify(nid, text, t, by="seed")
        if o:
            notes = [x for x in (f"{tag} - the GM's first move: {o['gm_first']}" if o["gm_first"] else "",
                                 f"{tag} - what it's for: {w['intent']}" if w["intent"] else "",
                                 f"{tag} - the arc: {w['arc']}" if w["arc"] else "") if x]
            for n in notes:
                S.add_note([f"S{sid}"], n, t)
            L.set_meta(META_OPENING, json.dumps({        # (who dies in the opening dies when it plays: open_scene)
                "seed": slug, "title": w["title"], "scene": sid, "turn": t, "place": eid(o["place"]),
                "narration": o["narration"], "summary": o["summary"], "cast": o["cast"],
                "moment": [[eid(r), role] for r, role in o["moment"] if eid(r)], "deaths": ids(o["deaths"]),
                "facts": public_facts, "terms": w["terms"],
                "job": ({**{k: w["job"][k] for k in ("title", "objective", "pay", "deadline")},
                         "client": eid(w["job"]["client"]) or "", "progress": "Offered in the opening."}
                        if w["job"] else None)}))
        shut = [e for e in w["people"] + w["outfits"] + w["places"] if e["sealed"]]
        here = sid or (L.current_scene() or {}).get("id")
        if shut and here:                             # (the packet prints the scene's notes: the GM sees what's sealed)
            S.add_note([f"S{here}"], f"{tag} - SEALED, who and what the crew doesn't know yet: " + "; ".join(
                (f"{e['true_name']} (on file as '{L.get(made[e['ref']])['name']}' [{made[e['ref']]}])"
                 if e["true_name"] else f"{L.get(made[e['ref']])['name']} [{made[e['ref']]}]") for e in shut)
                + ". Keep them out of what the players hear until the story reveals them (then `name <id>: ...`).", t)
        for p in w["people"]:                         # dead before the opening: dead now
            if p["dead"] and not (o and p["ref"] in o["deaths"]):
                _kill(game, made[p["ref"]], t)
        # the names only the GM's half has, for the spoiler guard (dm/spoilers.py: never at the table until revealed)
        for e in w["people"] + w["outfits"] + w["places"] + w["ties"]:
            ent = L.get(made[e["ref"]] if e.get("ref") else e["id"])
            gm = list(dict.fromkeys(list(ent["props"].get("gm_names") or []) + list(e.get("gm_names") or [])))
            true = e.get("true_name") or ""
            if true or gm:
                L.update_entity(ent["id"], props={**ent["props"], **({"true_name": true} if true else {}),
                                                  **({"gm_names": gm} if gm else {})})
        kept = json.loads(L.meta(META_TERMS) or "{}")          # (every seed's, so a second never drops the first's)
        kept = kept if isinstance(kept, dict) else {}
        L.set_meta(META_TERMS, json.dumps({k: sorted(set(kept.get(k) or []) | set(w.get(k) or []),
                                                     key=lambda x: (x.lower(), x))
                                           for k in ("terms", "secret_words", "cased")}))
        sealed = set(json.loads(L.meta(META_SEALED) or "[]")) | set(ids(w["sealed"]))
        L.set_meta(META_SEALED, json.dumps(sorted(sealed)))
        for x in ids(w["sealed"]):                  # (an entity's node is public by birth; a sealed name isn't)
            S.set_visibility(x, "gm")
        L.set_meta(META_APPLIED, json.dumps(applied(game) + [{
            "seed": slug, "title": w["title"], "turn": t, "scene": sid, "at": time.time(), "intent": w["intent"],
            "arc": w["arc"], "files": [n for n, _ in w["files"]], "backup": str(backup), "story_time": start,
            # who it made or tied in - the graph log's minds tell its changes from a reset's just before it
            "ids": sorted(set(made.values()) | {x["id"] for x in w["ties"]} | set(ids(o["present"] if o else []))
                          | set(ids([f["holder"] for f in w["feelings"]])))}]))
        # they've just made their move (the seed): only what comes due from here wakes them offscreen
        seq = conn.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]
        actors = {made[e["ref"]] for e in w["people"] + w["outfits"]} | {x["id"] for x in w["ties"]
                                                                        if x["kind"] in ("npc", "faction")}
        for a in actors:
            conn.execute("INSERT OR REPLACE INTO world_actors(npc_id, last_turn, last_time, last_seq) VALUES(?,?,?,?)",
                         (a, t, game.clock(), seq))
        c = counts(w)
        L.log(t, "seed", None, {"seed": slug, "title": w["title"], "counts": c, "doubts": raised, "by": "seed"})
        L.finish_turn(t, "", 0.0, status="seed")
        S.touch([x for x in list(made.values()) + [marker] + ([f"S{sid}"] if sid else []) if S.exists(x)], t,
                game.settings.knobs.retrieval_quantum)
        S.observe(t)
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        (game.undo_dir / f"before_{t:06d}.db").unlink(missing_ok=True)
        raise
    from . import graphlog
    graphlog.after_turn(game)                      # (a seed is a turn of its own: its graph and minds on file)
    lines += [f"[SEED] {w['title']} T{t}: " + ", ".join(f"{k} {v}" for k, v in c.items() if v)]
    lines += [f"[SEED] couldn't place: {p}" for p in w["problems"]]
    lines += [f"[SEED] kept GM-only ({what}): {text}" for what, text in w["guarded"]]
    return {"title": w["title"], "turn": t, "scene": sid, "backup": str(backup), "counts": c, "doubts": raised,
            "opening": bool(o), "lines": lines}


def result_text(res: dict) -> str:
    """What the table hears once it's filed - spoiler-free."""
    c = res["counts"]
    out = (f"🌱 **{res['title']}** is in the world (T{res['turn']}): "
           + ", ".join(x for x in (_n(c["people"], "person", "people"), _n(c["outfits"], "outfit"),
                                   _n(c["places"], "place"), _n(c["public_facts"], "public fact"),
                                   _n(c["tensions"], "open question")) if x)
           + f" · {_n(c['identities'], 'secret identity', 'secret identities')} and "
             f"{_n(c['gm_facts'] + c['events'] + c['agendas'] + c['hooks'], 'GM-only thread')} sealed")
    if res["doubts"]:
        out += f" · {_n(len(res['doubts']), 'doubt')} for the GM (`!doubts`, by DM - spoilers)"
    out += f".\n-# Backup: `{Path(res['backup']).name}` · `!undo` takes the seed back like a turn"
    if res["opening"]:
        out += "\n🎬 The story opens when the crew is here: make or bring your runners, then `!begin`."
    return out


# ── the opening: the crew's first scene ─────────────────────────────────

NO_CREW = ("Nobody has a runner yet for the story - it opens for runners brought for it (made or checked out since it "
           "was read, or `!join`ed into its scene), not a seat from before it: `!newchar`, `!pregen`, "
           "`!characterledger checkout <name>` or `!join <name>`, then `!begin`.")


class NoCrew(LedgerError):
    """The opening is waiting and nobody here is in it yet (prepare)."""


def pending(game) -> dict | None:
    """The opening waiting for its crew, or None."""
    try:
        p = json.loads(game.ledger.meta(META_OPENING) or "null")
    except ValueError:
        return None
    return p if isinstance(p, dict) and p.get("scene") else None


def crew(game, sid: int) -> list[dict]:
    """Who the opening is for: the runners brought for it - each seated PC (in the order they sat down) who is in the
    seed's scene or was made after the seed - then any other PC in that scene. Never an AFK seat, nor a PC from before
    the seed still seated somewhere else: on a world that hasn't had `!rp newparty`, the old crew's seats would
    otherwise take the story's parts (live: a player's AFK runner as the story's partner)."""
    L, out = game.ledger, []
    roster, since = set(L.roster(sid)), int((pending(game) or {}).get("turn") or 0)
    away = set()
    for r in game.conn.execute("SELECT handle, afk FROM players ORDER BY rowid"):
        ent = game.character_for(r["handle"])
        if not ent or ent["kind"] != "pc" or ent["status"] != "active":
            continue
        if r["afk"]:
            away.add(ent["id"])
        elif (ent["id"] in roster or ent["created_turn"] >= since) and ent["id"] not in [e["id"] for e in out]:
            # (>=: a runner made after the seed is stamped with the seed's own turn number - turn_no() - final check)
            out.append(ent)
    for x in sorted(roster):
        ent = L.get(x)
        if ent and ent["kind"] == "pc" and ent["status"] == "active" and x not in away \
                and x not in [e["id"] for e in out]:
            out.append(ent)
    return out


def cast_for(cast: list[dict], pcs: list[dict]) -> tuple[dict, list[dict]]:
    """Slot -> the PC who takes it: a slot the story names ('Marco') goes to the PC of that name; the rest, in order,
    to whoever else is there - 'his partner' is the second PC. Returns (slots, the PCs left over)."""
    left, got = list(pcs), {}
    for c in cast:
        n = c["story_name"].lower()
        hit = next((p for p in left if n and n[:1].isalpha() and c["story_name"][:1].isupper()
                    and n in (p["name"].lower(), p["name"].lower().split()[0])), None)
        if hit:
            got[c["slot"]] = hit
            left.remove(hit)
    for c in cast:
        if c["slot"] not in got and left:
            got[c["slot"]] = left.pop(0)
    return got, left


def prepare(game) -> dict:
    """Who's here and who takes which slot (game thread, quick). Raises LedgerError when there's nothing to open."""
    p = pending(game)
    if not p:
        raise LedgerError("No story is waiting to open.")
    if not game.ledger.scene(p["scene"]):
        raise LedgerError("The story's scene is gone - `!seed status`.")
    pcs = crew(game, p["scene"])
    if not pcs:
        raise NoCrew(NO_CREW)
    got, extra = cast_for(p["cast"], pcs)
    renamed = any(c["story_name"][:1].isupper() and c["slot"] in got
                  and got[c["slot"]]["name"].lower().split()[0] != c["story_name"].lower().split()[0] for c in p["cast"])
    return {"pending": p, "pcs": [e["id"] for e in pcs], "names": {s: e["name"] for s, e in got.items()},
            "who": {s: e["id"] for s, e in got.items()}, "extra": [e["id"] for e in extra],
            "adapt": bool(p["cast"]) and (len(got) < len(p["cast"]) or bool(extra) or renamed)}


def parts_line(game, prep: dict) -> str:
    """Who takes which of the story's parts, for the table: "**Marco** as *Marco*, **Nyx** as *his partner*" ("" when
    the story has none)."""
    L, p = game.ledger, prep["pending"]
    if not p["cast"]:
        return ""
    out = [f"**{prep['names'][c['slot']]}** as *{c['story_name'] or c['slot']}*" for c in p["cast"]
           if c["slot"] in prep["names"]]
    out += [f"**{(L.get(x) or {}).get('name', x)}** (no part of their own)" for x in prep["extra"]]
    out += [f"*{c['story_name'] or c['slot']}* nobody yet" for c in p["cast"] if c["slot"] not in prep["names"]]
    return ", ".join(out)


def adapt_schema() -> dict:
    s = {"type": "string"}
    return _obj(narration=s, summary=s)


ADAPT_SYSTEM = """You adapt the opening narration of a scene in a Shadowrun tabletop campaign to the player characters \
actually at the table. Keep the author's prose, voice and order - change only what the crew changes: each slot token \
({PC1}, {PC2}...) becomes the character who takes it; fix pronouns and details that no longer fit who they are (their \
look, metatype, what they'd carry). A slot nobody takes: write the passage without that character. More player \
characters than slots: put the others in the scene with a light touch (at the same booth, at the counter) - no words or \
choices for them. Never decide anything for a player character beyond what the story already has them doing. Add no \
names, places or facts. summary: one sentence of what happened, for the record."""


def adapt(game, prep: dict) -> dict:
    """The opening fitted to whoever is there when the slots don't fit them (off the game thread). Its input is only
    the player-safe narration and the crew's sheets - nothing from the GM's half can be in it."""
    L, p = game.ledger, prep["pending"]
    crew_lines = []
    for x in prep["pcs"]:
        e = L.get(x)
        slot = next((s for s, i in prep["who"].items() if i == x), "no slot")
        crew_lines.append(f"- {slot}: {e['name']} ({' '.join(v for v in (e['props'].get('pronouns'), e['props'].get('metatype'), (e['props'].get('archetype') or '').replace('_', ' ')) if v)}) - {_s(e['description'], 240)}")
    user = (f"{ADAPT_HEAD}\nTHE SLOTS (as the story names them): "
            + "; ".join(f"{c['slot']} = {c['story_name']}" for c in p["cast"])
            + "\nTHE PLAYER CHARACTERS AT THE TABLE:\n" + "\n".join(crew_lines)
            + f"\n\nTHE OPENING:\n{p['narration']}\n\nIts one-line summary: {p.get('summary') or '(none)'}")
    m = game.settings.models
    return game.llm.structured(m.dm, ADAPT_SYSTEM, user, adapt_schema(), max_tokens=8000, effort="low",
                               fallback=m.commit, purpose="seed")


def fill(text: str, names: dict, cast: list[dict]) -> str:
    """Slot tokens -> the PCs' names (a slot nobody took keeps the story's own words: 'his partner')."""
    story = {c["slot"]: c["story_name"] for c in cast}
    return SLOT.sub(lambda m: names.get(m.group(1)) or story.get(m.group(1)) or "someone", text or "")


def open_scene(game, prep: dict, adapted: dict | None = None):
    """The crew's first turn: placed in the seed's scene, the opening on the record as a turn they all witnessed
    (its public facts with it), the job on the board. Returns the TurnResult the table posts as story cards."""
    from . import jobs
    from .dm.turn import TurnResult
    L, S, conn = game.ledger, game.sub, game.conn
    p = prep["pending"]
    if pending(game) != p:
        raise LedgerError("The story's opening changed under it - `!begin` again.")
    narration = fill(p["narration"], prep["names"], p["cast"])
    crew_names = [L.get(x)["name"] for x in prep["pcs"]]
    summary = fill(p.get("summary") or "", prep["names"], p["cast"])
    if adapted:
        a_n, a_s = (adapted.get("narration") or "").strip(), _s(adapted.get("summary"), 400)
        if a_n and not leaks(a_n, p["terms"]) and not SLOT.search(a_n):
            narration = a_n
        if a_s and not leaks(a_s, p["terms"]):
            summary = a_s
    if not summary:
        place = (L.get(p.get("place") or "") or {}).get("name")
        summary = f"{', '.join(crew_names)} saw the story '{p['title']}' open" + (f" at {place}." if place else ".")
    sid = p["scene"]
    t = game.turn_no() + 1
    game.snapshot(t)
    conn.execute("BEGIN")
    try:
        if (L.current_scene() or {}).get("id") != sid:
            L.activate_scene(sid)
        tid = L.begin_turn(sid, [["scene", f"(the story seed's opening: {p['title']})"]])
        game.enter_scene(prep["pcs"], tid, sid)
        for d in p["deaths"]:
            if L.get(d):
                _kill(game, d, tid)
        members = ([(p["place"], "location")] if p.get("place") else []) + [
            (x, role) for x, role in p["moment"] if L.get(x)] + [(x, "present") for x in prep["pcs"]]
        slice_id = S.write_slice(tid, sid, summary, members, p["facts"], story_time=game.clock())
        S.touch([slice_id], tid)
        if p.get("job"):
            jobs.apply(game, tid, [{**p["job"], "change": "new", "id": ""}], by="seed")
        L.finish_turn(tid, narration, 0.0)
        L.set_meta(META_OPENING, "")
        L.log(tid, "seed_opening", None, {"seed": p["seed"], "crew": prep["pcs"], "slots": prep["who"]})
        S.observe(tid)
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        (game.undo_dir / f"before_{t:06d}.db").unlink(missing_ok=True)
        raise
    from . import graphlog
    graphlog.after_turn(game)                      # (the new story's first turn: on file from the start)
    if game.art.active:                            # (as a turn's memory pass does: pictures for who's new here)
        queued = 0
        for x in [p.get("place")] + [m for m, _ in p["moment"]]:
            ent = L.get(x) if x else None
            if queued < game.settings.knobs.art_per_turn and ent and ent["tier"] >= 1 \
                    and not game.art.has_art(conn, ent["id"]) and game.request_art(ent["id"]) == "queued":
                queued += 1
    return TurnResult(tid, narration, [], 0.0, slice_id, "", {"introduced": [], "speakers": {}, "auto_cut": True,
                                                             "seed": p["seed"]})


# ── at the table (session.py's hooks call these) ────────────────────────

_READS: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()    # table -> the read waiting for !seed confirm
_BUSY: "weakref.WeakSet" = weakref.WeakSet()                        # tables reading a story right now

USAGE = ("`!seed <name>` reads seeds/<name>*.md (`!seed list`) - or attach .md / .txt files to `!seed`, or paste the "
         "story after it (a file named GM / SECRET, or a section headed *for the GM only*, is the GM's) · "
         "`!seed preview` again · `!seed preview full` the whole plan by DM (spoilers) · `!seed confirm` / "
         "`!seed cancel` · `!seed status`")


async def command(table, uid: str, uname: str, rest: str, admin: bool) -> None:
    """`!seed ...` - the owner's (it rewrites the world; its preview spoils nothing)."""
    g, ch = table.game, table.ch
    if not admin:
        await ch.send("That one's for the campaign owner.")
        return
    words = rest.split()
    verb = words[0].lower() if words and not rest.lstrip().startswith("<<<") else ""
    if not rest or verb in ("help", "?"):
        await ch.send(USAGE)
    elif verb == "list" and len(words) == 1:
        have = available()
        await ch.send("🌱 Seeds in `seeds/`: " + (", ".join(f"`{n}`" for n in have) if have else "none yet")
                      + " - `!seed <name>` reads one.")
    elif verb == "status" and len(words) == 1:
        await ch.send(await table.run(_status, g, table))
    elif verb in ("cancel", "no") and len(words) == 1:
        r = _READS.pop(table, None)
        await ch.send(f"👍 Dropped the read of **{r['work']['title']}** - nothing was written." if r
                      else "Nothing waiting to confirm.")
    elif verb in ("confirm", "yes") and len(words) == 1:
        await confirm(table, uid)
    elif verb in ("preview", "full") and len(words) <= 2:
        r = _READS.get(table)
        if not r:
            await ch.send("Nothing read yet - `!seed <name>` reads a story first.")
            return
        r["expires"] = time.time() + TTL
        await _show(table, uid, r, full=verb == "full" or (len(words) == 2 and words[1].lower() == "full"))
    elif table in _BUSY:
        await ch.send("🌱 Still reading the last one - give it a minute.")
    else:
        full = len(words) == 2 and words[1].lower() == "full"
        try:
            docs, skipped = ((from_seeds(words[0]), []) if len(words) == 1 or full else parse(rest))
        except LedgerError as exc:
            await ch.send(f"⚠️ {exc}")
            return
        await read(table, uid, docs, skipped, full, seed=words[0] if (len(words) == 1 or full) else "")


async def read(table, uid: str, docs: list[Doc], skipped: list[str], full: bool = False, seed: str = "") -> None:
    g, ch = table.game, table.ch
    if not docs:
        await ch.send("Nothing to read - " + (f"skipped {', '.join(skipped)} (only .md / .txt). " if skipped else "")
                      + USAGE)
        return
    if await table.run(pending, g):                   # (before the paid read: apply would refuse it at confirm)
        await ch.send(f"⚠️ {WAITING} - then read the next one.")
        return
    _BUSY.add(table)
    try:
        await ch.send(f"🌱 Reading **{_label(docs)}** into the world"
                      + (f" (skipped {', '.join(skipped)}: only .md / .txt)" if skipped else "")
                      + " - a few minutes: the GM's model reads it whole, against everything on file.")
        async with ch.typing():
            gathered = await table.run(gather, g, docs)
            plan = await table.loop.run_in_executor(None, think, g, gathered)
            work = await table.run(review, g, docs, plan)
    except Exception as exc:                          # (a refusal, a timeout: nothing was written)
        await ch.send(f"⚠️ Couldn't read it ({type(exc).__name__}: {str(exc)[:200]}) - nothing was written.")
        return
    finally:
        _BUSY.discard(table)
    r = {"docs": docs, "plan": plan, "work": work, "uid": uid, "seed": seed, "expires": time.time() + TTL, "key": None}
    _READS[table] = r
    await _show(table, uid, r, full)


async def _show(table, uid: str, r: dict, full: bool) -> None:
    """The spoiler-free preview to the channel (the whole plan by DM when asked), then the confirm buttons."""
    g, ch = table.game, table.ch
    await ch.send_cards(await table.run(preview, g, r["work"], False))
    if full:
        try:
            await ch.dm_cards(uid, await table.run(preview, g, r["work"], True))
            await ch.send("📬 Sent you the whole plan by DM - secrets and all.")
        except Exception as exc:                      # (DMs closed: the channel never gets the secrets instead)
            await ch.send(f"⚠️ Couldn't DM you the whole plan ({type(exc).__name__}) - open your DMs and "
                          "`!seed preview full` again.")
    card = {"title": f"🌱 Read **{r['work']['title']}** into the world?", "color": SEED_COLOR,
            "description": f"<@{uid}>: ✅ to file it (`!seed confirm`) or ✖️ to drop it (`!seed cancel`) - within "
                           f"{TTL // 60} minutes. `!seed preview full` sends you everything by DM first (spoilers)."}
    r["key"] = await ch.ask(f"<@{uid}>", card, ["✅", "❌"], holder=uid) if hasattr(ch, "ask") else None
    if r["key"] is None:
        await ch.send_cards([card])


async def confirm(table, uid: str) -> None:
    g, ch = table.game, table.ch
    r = _READS.get(table)
    if not r or r["expires"] < time.time():
        await ch.send("Nothing waiting to confirm" + (" - the two minutes ran out; `!seed preview` shows it again"
                                                     if r else " - `!seed <name>` reads a story first") + ".")
        return
    if r["uid"] != uid:
        await ch.send(f"Only <@{r['uid']}>, who read it, can file it.")
        return
    try:                                              # (the read is kept until it's filed: a refusal costs no re-read)
        async with ch.typing():
            res = await table.run(apply, g, r["docs"], r["plan"], r["seed"])
    except LedgerError as exc:
        await ch.send(f"⚠️ {exc} The read is kept - `!seed confirm` again once it's sorted.")
        return
    except Exception as exc:                          # (apply rolled back: nothing was written)
        print(f"[{g.path.stem}] seed apply failed: {type(exc).__name__}: {exc}", flush=True)
        await ch.send(f"⚠️ Couldn't file it ({type(exc).__name__}: {str(exc)[:200]}) - nothing was written; the "
                      "read is kept.")
        return
    if _READS.get(table) is r:
        _READS.pop(table, None)
    for line in res["lines"]:
        print(f"[{g.path.stem}] {line}", flush=True)
    await table.refresh()
    await ch.send(result_text(res))
    if not res["opening"]:                            # (a story with an opening is read back once it plays: play)
        table.kick_canon(force=True)                  # the canon outranks older memories: it reads the seed in now
        table.kick_frame(force=True)                  # (it waits for the canon)


async def reaction(table, message_id: str, uid: str, emoji: str) -> bool:
    """✅ / ❌ on the confirm card. True when it was this card."""
    r = _READS.get(table)
    if not r or not message_id or r.get("key") != message_id or emoji not in ("✅", "❌") or uid != r["uid"]:
        return False
    if emoji == "✅":
        await confirm(table, uid)
    else:
        _READS.pop(table, None)
        await table.ch.send(f"👍 Dropped the read of **{r['work']['title']}** - nothing was written.")
    return True


def _status(game, table=None) -> str:
    out = []
    r = _READS.get(table) if table is not None else None
    if r:
        left = int(r["expires"] - time.time())
        out.append(f"🌱 Read and waiting: **{r['work']['title']}** - " + (f"`!seed confirm` within {left}s" if left > 0
                                                                          else "`!seed preview` to look again"))
    p = pending(game)
    if p:
        sc = game.ledger.scene(p["scene"])
        out.append(f"🎬 Waiting for its crew: **{p['title']}** - \"{sc['title'] if sc else '?'}\" opens on `!begin`.")
        try:                                          # (who'd take each part, before anyone says !begin)
            prep = prepare(game)
            out.append("If it opened now: " + (parts_line(game, prep) or ", ".join(
                f"**{game.ledger.get(x)['name']}**" for x in prep["pcs"])) + ".")
        except LedgerError as exc:
            out.append(str(exc))
    done = applied(game)
    if done:
        out.append("In this world: " + ", ".join(f"**{s['title']}** (T{s['turn']})" for s in done[-6:]))
    return "\n".join(out) or "No seeds in this world yet - `!seed <name>`."


async def play(table, pitch: str = "") -> str | None:
    """The opening, at the table: place the crew, post it as the scene's first turn. 'opened', 'waiting' (nobody's
    runner is in it yet - said so), 'failed' (said why), or None when no opening is waiting."""
    g, ch = table.game, table.ch
    if not await table.run(pending, g):
        return None
    try:
        prep = await table.run(prepare, g)
    except NoCrew as exc:
        await ch.send(f"🎬 {exc}")
        return "waiting"
    except LedgerError as exc:
        await ch.send(f"⚠️ {exc}")
        return "failed"
    adapted = None
    if prep["adapt"]:
        try:
            async with ch.typing():
                adapted = await table.loop.run_in_executor(None, adapt, g, prep)
        except Exception as exc:                      # (the slots' own words stand in)
            print(f"[{g.path.stem}] seed opening: couldn't fit it to the crew ({exc})", flush=True)
    try:
        res = await table.run(open_scene, g, prep, adapted)
    except LedgerError as exc:
        await ch.send(f"⚠️ {exc}")
        return "failed"
    if pitch.strip():
        from .dm import aside
        await table.run(aside.add_direction, g, pitch)
    names = await table.run(lambda: [g.ledger.get(x)["name"] for x in prep["pcs"]])
    parts = await table.run(parts_line, g, prep)
    await ch.send(f"🎬 Here we go: **{', '.join(names)}**" + (f" - {parts}" if parts else "") + ".")
    await table._post_story(await table.run(table._story_cards, res, True))
    await table._post_divider()
    await table.refresh()
    # the canon outranks older memories in every packet: read the story back now, not CANON_EVERY turns on (the old
    # world's "COMING UP" would steer the first turns). The world's frame waits for it (session._frame_pass).
    table.kick_canon(force=True)
    table.kick_world()
    return "opened"


async def begin(table, pitch: str) -> bool:
    """session.begin's hook: a seeded story opens its own scene. False when none is waiting (the usual !begin)."""
    return await play(table, pitch) is not None


async def before_turn(table, inputs) -> bool:
    """session._resolve's hook: the crew posted before the story opened - open it first, and their posts go into the
    turn after it (nothing they wrote is lost). While nobody's runner is in it yet (an old seat posting), nothing
    plays: the story's scene is current, and a GM turn there would come before its own opening. False when there was
    nothing to open, or it couldn't open (the turn goes on as it would have)."""
    done = await play(table)
    if done == "waiting":
        return True
    if done != "opened":
        return False
    seated = set(table.handles.values())
    for handle, text in inputs:
        if handle in seated:
            table.director.add(handle, text)
    return True


# ── for the other parts of the engine ───────────────────────────────────

def sealed_ids(conn) -> set[str]:
    """Who and what only the GM's half of a story seed knows, that the crew hasn't met yet - a public moment with them
    in it or a public fact about them unseals them; only play can (a fact a seed filed on its own turn never does - its
    review keeps them off those anyway). Being in a moment as recalled or mentioned isn't meeting them (NOT_MET): the
    memory pass's 'mentioned' alone never unseals anyone. The dashboard keeps them off its people list. A bare
    connection is enough (the dashboard reads read-only)."""
    try:
        row = conn.execute("SELECT value FROM meta WHERE key=?", (META_SEALED,)).fetchone()
        ids = set(json.loads(row[0] or "[]")) if row else set()
    except (ValueError, sqlite3.Error):
        return set()
    if not ids:
        return set()
    marks, args = ",".join("?" * len(ids)), sorted(ids)
    met = {r[0] for r in conn.execute(
        f"SELECT DISTINCT m.node_id FROM members m JOIN nodes n ON n.id=m.slice_id WHERE n.kind='slice' AND "
        f"n.visibility='public' AND m.role NOT IN ({','.join('?' * len(NOT_MET))}) AND m.node_id IN ({marks})",
        (*NOT_MET, *args))}
    met |= {r[0] for r in conn.execute(
        f"SELECT CASE WHEN l.a IN ({marks}) THEN l.a ELSE l.b END FROM links l JOIN nodes f ON f.id = CASE WHEN "
        f"l.a IN ({marks}) THEN l.b ELSE l.a END WHERE l.kind='about' AND f.kind='fact' AND f.visibility='public' AND "
        f"(l.a IN ({marks}) OR l.b IN ({marks})) AND f.created_turn NOT IN (SELECT id FROM turns WHERE "
        f"status='seed')", args * 4)}
    return ids - met


def canon_text(game) -> str:
    """canon.gather's hook: the stories the owner seeded, so the read-back keeps their threads and their secrets
    out of the facts."""
    seeds = applied(game)
    if not seeds:
        return ""
    return ("\n\nSTORY SEEDS (stories the owner read into the world - GM-only: their threads are planned, keep them "
            "open; never write their secrets into a fact - facts are what the players know):\n"
            + "\n".join(f"- '{s['title']}' (T{s['turn']}" + (f", S{s['scene']}" if s.get("scene") else "")
                        + f"): {_s(s.get('intent'), 500)}" + (f" Arc: {_s(s.get('arc'), 700)}" if s.get("arc") else "")
                        for s in seeds[-3:]))


# ── the console: python -m roleplay.seed <campaign> <files...> ──────────

def main(argv=None, llm=None, art=None, out=print, ask=input) -> int:
    ap = argparse.ArgumentParser(prog="python -m roleplay.seed", description="Read a story into a campaign's world "
                                 "(DESIGN.md §12l). Spoiler-free unless --full.")
    ap.add_argument("campaign", help="a campaign name (campaigns/<name>.db) or a .db path")
    ap.add_argument("files", nargs="*", help="the story's .md / .txt files - a name with GM or SECRET in it is GM-only")
    ap.add_argument("--seed", help="a seed from seeds/ by name (night-ferry)")
    ap.add_argument("--full", action="store_true", help="show the whole plan, secrets and all")
    ap.add_argument("--yes", action="store_true", help="file it without asking")
    ap.add_argument("--dry-run", action="store_true", help="read and preview only - nothing is written")
    ap.add_argument("--plan", help="file a plan saved earlier (JSON) instead of reading the story again")
    ap.add_argument("--save-plan", help="save the read's plan as JSON (it holds the secrets)")
    args = ap.parse_args(argv)
    from .config import CAMPAIGN_DIR
    from .game import Game
    path = Path(args.campaign) if args.campaign.endswith(".db") else CAMPAIGN_DIR / f"{args.campaign}.db"
    if not path.exists():
        out(f"No campaign at {path}.")
        return 2
    try:
        docs = (from_seeds(args.seed) if args.seed else []) + from_files(args.files)
    except (LedgerError, OSError) as exc:
        out(str(exc))
        return 2
    if not docs:
        out("Nothing to read - give the story's files, or --seed <name>.")
        return 2
    game = Game(path, llm=llm, art=art, out=lambda s: None)
    try:
        if game.ledger.current_scene() is None:
            out("That world has no scene yet - start it at the table first (`!rp start`).")
            return 2
        if args.plan:
            plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
        else:
            out(f"Reading {_label(docs)} into {path.stem} with {game.settings.models.dm} - a few minutes...")
            plan = think(game, gather(game, docs))
            if args.save_plan:
                Path(args.save_plan).write_text(json.dumps(plan, indent=2), encoding="utf-8")
        w = review(game, docs, plan)
        out(preview_text(game, w, full=args.full))
        if args.dry_run:
            return 0
        if not args.yes and ask("Read it into the world? [y/N] ").strip().lower() not in ("y", "yes"):
            out("Cancelled - nothing written.")
            return 1
        try:
            res = apply(game, docs, plan, args.seed or "")
        except LedgerError as exc:
            out(str(exc))
            return 1
        out(result_text(res).replace("**", ""))
        for line in res["lines"] if args.full else []:
            out(line)
        return 0
    finally:
        game.close()


if __name__ == "__main__":
    raise SystemExit(main())
