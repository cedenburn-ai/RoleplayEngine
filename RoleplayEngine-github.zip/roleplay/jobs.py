"""The crew's jobs (DESIGN.md §12f): the runs they're offered, take, finish or walk away from.

A Shadowrun story hangs on the job - who hired the crew, for what, for how much, by when - and nothing else in the
engine holds that as one thing (it's spread across facts, notes and tensions). So the memory pass (commit.py) reads
each turn for changes to a job and this module files them in the ledger: `jobs` (J1, J2...) with a title, the
client, the objective, the pay and deadline as the story put them, a one-line progress note, and a status -
offered, active, done, failed or dropped.

The GM's packet shows the open jobs so pay and deadlines stay straight. The dashboard shows the current run and the
crew's record. A campaign played before the tracker existed can be read once for its jobs (`backfill`).
"""
from __future__ import annotations

import re

from .dm.prompts import FICTION_NOTE

OPEN = ("offered", "active")
CLOSED = ("done", "failed", "dropped")
CHANGES = ("new", "active", "update", "done", "failed", "dropped")
FIELDS = ("title", "objective", "pay", "deadline", "progress")
PER_TURN = 2                     # job changes the memory pass can file in one turn

EXTRACT_SYSTEM = FICTION_NOTE + """ You keep the job board for a Shadowrun tabletop campaign: the crew's runs - paid \
work or a mission they took on (a fixer's job, a favor owed, a heist they're planning). The memory pass says this turn \
moved one. Report each change, checking JOBS ON FILE (usually one entry, at most two):
- change: new (someone offered or pitched them a job; id ""), active (they took it, or it got underway), update (new \
details - pay, deadline, target - or a real step forward), done (finished: delivered or paid), failed (it went wrong \
for good) or dropped (they walked away).
- id: the J# of a job on file, else "". title: 3-8 words. client: the id of whoever hired them, from KNOWN ENTITIES, or \
"". objective: one line. pay and deadline: as the story states them, or "" (on an update, "" keeps what's on file). \
progress: one line on where it stands now.
Only what the narration establishes - never invent a price, a deadline or a name. An empty list if nothing really \
moved."""

BACKFILL_SYSTEM = FICTION_NOTE + """ You read the record of a Shadowrun tabletop campaign and list the crew's jobs: \
paid work or missions the player characters were offered or took on (a fixer's run, a favor owed, a heist they \
planned). Only what the record shows - never invent a job, a price or a name. For each job:
- title: 3-8 words. client: the id of whoever hired them, from KNOWN PEOPLE (or ""). objective: one line.
- pay and deadline: as the record states them, or "".
- status: offered (pitched, never taken), active (taken and not finished when the record ends), done, failed or \
dropped (they walked away).
- progress: one line on how it ended, or where it stands at the end of the record.
- first_turn / last_turn: the turn numbers (T#) where it first came up and where it last moved.
An empty list if the crew never had a job."""


def _has_table(conn) -> bool:
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='jobs'").fetchone() is not None


def all_jobs(conn) -> list[dict]:
    """Every job, oldest first. Takes a connection so the dashboard can read a file without a Game."""
    if not _has_table(conn):
        return []
    return [dict(r) for r in conn.execute("SELECT * FROM jobs ORDER BY created_turn, CAST(SUBSTR(id, 2) AS INTEGER)")]


def get(game, jid: str) -> dict | None:
    row = game.conn.execute("SELECT * FROM jobs WHERE id=?", ((jid or "").strip().upper(),)).fetchone()
    return dict(row) if row else None


def open_jobs(game) -> list[dict]:
    return [j for j in all_jobs(game.conn) if j["status"] in OPEN]


def current(conn) -> dict | None:
    """The run in play: the active job that moved last; else the newest offer on the table."""
    jobs = all_jobs(conn)
    for status in OPEN[::-1]:
        live = [j for j in jobs if j["status"] == status]
        if live:
            return max(live, key=lambda j: (j["updated_turn"], j["created_turn"]))
    return None


def _norm(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (title or "").lower()).strip()


def _next_id(game) -> str:
    n = int(game.ledger.meta("seq_J", "0")) + 1
    game.ledger.set_meta("seq_J", str(n))
    return f"J{n}"


def _create(game, turn: int, fields: dict, status: str, client: str | None, by: str) -> str:
    jid = _next_id(game)
    game.conn.execute("INSERT INTO jobs(id, title, client_id, objective, pay, deadline, status, progress, created_turn, "
                      "updated_turn, closed_turn, by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (jid, fields["title"][:120], client, fields["objective"][:300], fields["pay"][:120],
                       fields["deadline"][:120], status, fields["progress"][:300], turn, turn,
                       turn if status in CLOSED else None, by))
    return jid


def apply(game, turn: int, entries: list[dict] | None, by: str = "commit") -> list[str]:
    """File the memory pass's job changes. Returns a line per change (for the turn's events)."""
    from . import seed
    from .dm import spoilers
    L = game.ledger
    lines = []
    sealed = seed.sealed_ids(game.conn)
    for e in entries or []:
        if len(lines) >= PER_TURN:
            break
        change = (e.get("change") or "").strip().lower()
        if change not in CHANGES:
            continue
        # the board is public: its words in the names the crew knows, and never a client the crew hasn't met (the
        # seed's review keeps its own job to that - review 2026-10-28: the memory pass's job named a sealed NPC)
        fields, slip = {}, []
        for k in FIELDS:
            fields[k], h = spoilers.scrub(game, str(e.get(k) or "").strip())
            slip += [x for x in h if x not in slip]
        if slip:
            spoilers.flag(game, "spoiler", f"T{turn}'s job board", slip, turn, "scrubbed to the names the crew knows")
        ent = L.find(e["client"]) if (e.get("client") or "").strip() else None
        client = ent["id"] if ent and ent["id"] not in sealed else None
        job = get(game, e.get("id") or "")
        if job is None and fields["title"]:              # the same job told twice is still one job
            job = next((j for j in open_jobs(game) if _norm(j["title"]) == _norm(fields["title"])), None)
        if job is None:
            if change not in ("new", "active") or not fields["title"]:
                continue                                  # an update to a job we never heard of: nothing to file
            status = "active" if change == "active" else "offered"
            jid = _create(game, turn, fields, status, client, by)
            L.log(turn, "job", client, {"job": jid, "change": change, "title": fields["title"]})
            lines.append(f"JOB {jid} {status}: {fields['title']}")
            continue
        status = {"active": "active", "done": "done", "failed": "failed", "dropped": "dropped"}.get(change,
                                                                                                   job["status"])
        sets = {k: v for k, v in fields.items() if v and k != "title"}
        if client and not job["client_id"]:
            sets["client_id"] = client
        sets.update(status=status, updated_turn=turn)
        if status in CLOSED and job["status"] not in CLOSED:
            sets["closed_turn"] = turn
        game.conn.execute(f"UPDATE jobs SET {', '.join(f'{k}=?' for k in sets)} WHERE id=?",
                          (*sets.values(), job["id"]))
        L.log(turn, "job", job["client_id"] or client, {"job": job["id"], "change": change, **sets})
        lines.append(f"JOB {job['id']} {status}: {job['title']}" + (f" - {fields['progress']}" if fields["progress"]
                                                                   else ""))
    return lines


def lift_deadline(game, jid: str) -> str | None:
    """Take an open job's deadline away and keep the job - the GM's `fix J#: due off`, the canon's read-back. Review
    2026-10-27 (flag #42): a job's deadline was a deadline the engine held that nothing could lift - an update's ""
    keeps what's on file, and no lever or read-back reached the jobs table - so a time the table ruled out kept
    pressing in THE JOB, which tells the GM to keep deadlines consistent with it. (Not a move of the job: updated_turn
    stays.) Returns the deadline it had, or None when it had none (nothing changed)."""
    j = get(game, jid)
    if not j or j["status"] not in OPEN or not (j["deadline"] or "").strip():
        return None
    game.conn.execute("UPDATE jobs SET deadline='' WHERE id=?", (j["id"],))
    return j["deadline"]


def extract_schema() -> dict:
    s = {"type": "string"}
    change = {"type": "string", "enum": list(CHANGES)}
    job = {"type": "object", "additionalProperties": False,
           "required": ["id", "change", "title", "client", "objective", "pay", "deadline", "progress"],
           "properties": {"id": s, "change": change, "title": s, "client": s, "objective": s, "pay": s,
                          "deadline": s, "progress": s}}
    return {"type": "object", "additionalProperties": False, "required": ["jobs"],
            "properties": {"jobs": {"type": "array", "items": job}}}


def extract(game, turn: int, user: str) -> list[str]:
    """The memory pass flagged a job change: a second, small call reads it from the same turn and files it.
    (The memory pass's own schema is near the API's grammar limit, so the details live in their own call.)"""
    data = game.llm.structured(game.settings.models.commit, EXTRACT_SYSTEM, user, extract_schema(),
                               max_tokens=2000, effort="low", purpose="jobs")
    return apply(game, turn, data.get("jobs") or [])


def _line(game, j: dict) -> str:
    client = game.ledger.get(j["client_id"]) if j["client_id"] else None
    bits = [f"for {client['name']} [{client['id']}]" if client else "",
            f"objective: {j['objective']}" if j["objective"] else "",
            f"pay: {j['pay']}" if j["pay"] else "", f"deadline: {j['deadline']}" if j["deadline"] else "",
            f"lately: {j['progress']}" if j["progress"] else ""]
    return f"[{j['id']}] {j['status']} - {j['title']}" + "".join(f"; {b}" for b in bits if b)


def commit_lines(game) -> str:
    """For the memory pass: the jobs it can update by id."""
    jobs = open_jobs(game)
    return "JOBS ON FILE:\n" + ("\n".join(_line(game, j) for j in jobs) if jobs else "(none)")


def packet_lines(game) -> list[str]:
    jobs = open_jobs(game)
    if not jobs:
        return []
    return ["\n=== THE JOB (tracked from the story after each turn - keep pay, deadlines and clients consistent with "
            "it) ==="] + [_line(game, j) for j in jobs]


def backfill_schema() -> dict:
    s = {"type": "string"}
    job = {"type": "object", "additionalProperties": False,
           "required": ["title", "client", "objective", "pay", "deadline", "status", "progress", "first_turn",
                        "last_turn"],
           "properties": {"title": s, "client": s, "objective": s, "pay": s, "deadline": s,
                          "status": {"type": "string", "enum": list(OPEN + CLOSED)}, "progress": s,
                          "first_turn": {"type": "integer"}, "last_turn": {"type": "integer"}}}
    return {"type": "object", "additionalProperties": False, "required": ["jobs"],
            "properties": {"jobs": {"type": "array", "items": job}}}


def backfill(game) -> list[str]:
    """Read a campaign from before the tracker for its jobs (only if it has none on file). Returns the new ids."""
    if all_jobs(game.conn):
        return []
    slices = game.conn.execute("SELECT id, text FROM nodes WHERE kind='slice' AND visibility='public' "
                               "ORDER BY created_turn, id").fetchall()
    if not slices:
        return []
    people = [e for e in game.ledger.entities() if e["kind"] in ("npc", "faction")]
    record = "\n".join(f"[{r['id']}] {r['text'][:400]}" for r in slices)[-60000:]
    user = ("KNOWN PEOPLE (id: name):\n" + "\n".join(f"{e['id']}: {e['name']}" for e in people[:200])
            + f"\n\nTHE RECORD (oldest first):\n{record}")
    data = game.llm.structured(game.settings.models.commit, BACKFILL_SYSTEM, user, backfill_schema(),
                               max_tokens=4000, effort="low", purpose="jobs")
    made = []
    for j in data.get("jobs", [])[:12]:
        fields = {k: str(j.get(k) or "").strip() for k in FIELDS}
        if not fields["title"]:
            continue
        ent = game.ledger.find(j["client"]) if (j.get("client") or "").strip() else None
        first, last = int(j.get("first_turn") or 0), int(j.get("last_turn") or 0)
        jid = _create(game, first, fields, j.get("status") if j.get("status") in OPEN + CLOSED else "active",
                      ent["id"] if ent else None, "backfill")
        game.conn.execute("UPDATE jobs SET updated_turn=?, closed_turn=CASE WHEN status IN ('done','failed','dropped') "
                          "THEN ? END WHERE id=?", (max(first, last), max(first, last), jid))
        made.append(jid)
    return made
