import argparse

from ..config import CAMPAIGN_DIR
from .server import live_campaign, serve

ap = argparse.ArgumentParser(prog="python -m roleplay.browser", description="Graph browser for a campaign")
ap.add_argument("campaign", nargs="?", default="live",
                help="campaign name or path to a .db file (default: the one live in Discord)")
ap.add_argument("--port", type=int, default=8765)
args = ap.parse_args()
if args.campaign == "live":
    args.campaign = live_campaign(CAMPAIGN_DIR)
path = CAMPAIGN_DIR / f"{args.campaign}.db" if not args.campaign.endswith(".db") else __import__("pathlib").Path(args.campaign)
if not path.exists():
    raise SystemExit(f"No campaign at {path}")
serve(path, args.port)
