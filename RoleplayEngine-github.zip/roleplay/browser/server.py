"""Graph browser: a local, read-only web view of a campaign's memory substrate.

    python -m roleplay.browser                 -> http://127.0.0.1:8765  (the campaign live in Discord)
    python -m roleplay.browser demo            -> the same, opening on demo
    (or `!graph` inside the console - it runs alongside play and auto-refreshes)

Any campaign in the folder can be browsed from the same server: the page's campaign picker adds
`?c=<name>` to every request.

Standard library only. Every request opens its own SQLite connection, so it is safe to
browse while a game is being played in the same file (the DB runs in WAL mode).
"""
from __future__ import annotations

import json
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .. import spend
from ..engine import geo
from ..engine.ledger import Ledger
from ..engine.rules import sr_lite

STATIC = Path(__file__).resolve().parent / "static"


def _connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def _has_table(c: sqlite3.Connection, name: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def _label(row: dict, ent: dict | None) -> str:
    if ent:
        return ent["name"]
    return row["id"]


def campaigns(directory: Path) -> list[dict]:
    """Every campaign file in the folder, most recently played first; 'live' = bound to a Discord channel."""
    live = set()
    try:
        live = {b["campaign"] for b in json.loads((directory / "discord_bindings.json").read_text()).values()}
    except (OSError, ValueError, KeyError, TypeError):
        pass
    files = sorted((p for p in directory.glob("*.db") if p.name not in spend.NOT_WORLDS),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"name": p.stem, "live": p.stem in live} for p in files]


def live_campaign(directory: Path, fallback: str = "demo") -> str:
    return next((c["name"] for c in campaigns(directory) if c["live"]), fallback)


class Api:
    def __init__(self, path: Path):
        self.path = path

    # ── whole graph ─────────────────────────────────────────────────────
    def graph(self) -> dict:
        c = _connect(self.path)
        try:
            mean = c.execute("SELECT AVG(energy) FROM energy").fetchone()[0] or 1.0
            ents = {r["id"]: dict(r) for r in c.execute("SELECT * FROM entities")}
            energy = {r["node_id"]: dict(r) for r in c.execute("SELECT * FROM energy")}
            nodes = []
            for r in c.execute("SELECT * FROM nodes"):
                r = dict(r)
                ent = ents.get(r["id"])
                e = energy.get(r["id"], {})
                nodes.append({
                    "id": r["id"], "kind": r["kind"], "sub": ent["kind"] if ent else r["kind"],
                    "label": _label(r, ent), "text": r["text"][:400],
                    "ratio": (e.get("energy", 0) / mean) if e else 0.0,
                    "touches": e.get("touch_count", 0), "turn": r["created_turn"], "scene": r["scene_id"],
                    "tier": ent["tier"] if ent else None, "status": ent["status"] if ent else None,
                })
            roles = {(r["slice_id"], r["node_id"]): r["role"] for r in c.execute("SELECT * FROM members")}
            born = {n["id"]: n["turn"] for n in nodes}
            arrows = {(r["old_id"], r["new_id"]) for r in c.execute("SELECT old_id, new_id FROM supersedes")}
            superseded = {o for o, _ in arrows}
            art = {r["entity_id"]: r["version"] for r in c.execute(
                "SELECT entity_id, MAX(version) AS version FROM art WHERE status='ready' GROUP BY entity_id")} \
                if _has_table(c, "art") else {}
            scene_loc = {r["id"]: r["location_id"] for r in c.execute("SELECT id, location_id FROM scenes")}
            where = {r["entity_id"]: scene_loc.get(r["scene_id"]) for r in c.execute("SELECT * FROM scene_roster")}
            settled = {r[0] for r in c.execute("SELECT id FROM doubts WHERE status<>'open'")} \
                if _has_table(c, "doubts") else set()
            for n in nodes:
                n["superseded"] = n["id"] in superseded
                if n["kind"] == "doubt":                  # a settled doubt is history: drawn dim
                    n["settled"] = n["id"] in settled
                if n["id"] in art:
                    n["art"] = f"/api/art?id={n['id']}&v={art[n['id']]}"
                ent = ents.get(n["id"])
                if ent:                                   # the map: places have positions, people are somewhere
                    props = json.loads(ent["props"] or "{}")
                    if ent["kind"] == "location" and props.get("geo"):
                        n["geo"] = props["geo"]
                    elif ent["kind"] in ("pc", "npc"):
                        w = props.get("whereabouts") or {}
                        at = w.get("place") or where.get(n["id"])
                        if at:
                            n["at"] = at if at in ents else f"district:{at}"
            edges = []
            for r in c.execute("SELECT * FROM links"):
                role = roles.get((r["a"], r["b"])) or roles.get((r["b"], r["a"]))
                src, dst = r["a"], r["b"]
                ta, tb = born.get(src, 0), born.get(dst, 0)
                if r["kind"] == "recall" and ta < tb:      # newer slice -> the memory it recalled
                    src, dst = dst, src
                if r["kind"] == "spine" and ta > tb:       # older -> newer
                    src, dst = dst, src
                if r["kind"] == "diode" and (dst, src) in arrows:   # superseded -> replacement
                    src, dst = dst, src
                edges.append({"id": f"l{r['id']}", "source": src, "target": dst, "kind": r["kind"],
                              "strength": r["strength"], "together": r["together"], "role": role})
            for r in c.execute("SELECT * FROM annotates"):
                edges.append({"id": f"a{r['note_id']}-{r['target_id']}", "source": r["note_id"],
                              "target": r["target_id"], "kind": "annotates", "strength": 1, "together": 0,
                              "role": None})
            scenes = [dict(r) for r in c.execute("SELECT * FROM scenes ORDER BY id")]
            turn = c.execute("SELECT COALESCE(MAX(id),0) FROM turns").fetchone()[0]
            campaign = c.execute("SELECT value FROM meta WHERE key='campaign'").fetchone()
            districts = [{"name": k, "lat": v[0], "lon": v[1], "radius": v[2]} for k, v in geo.GAZETTEER.items()]
            return {"nodes": nodes, "edges": edges, "scenes": scenes, "turn": turn, "mean": mean,
                    "campaign": campaign[0] if campaign else self.path.stem, "districts": districts}
        finally:
            c.close()

    # ── one node ────────────────────────────────────────────────────────
    def node(self, nid: str) -> dict:
        c = _connect(self.path)
        try:
            row = c.execute("SELECT * FROM nodes WHERE id=?", (nid,)).fetchone()
            ent = c.execute("SELECT * FROM entities WHERE id=?", (nid,)).fetchone()
            if row is None and ent is None:
                return {"error": f"no node {nid}"}
            out: dict = {"id": nid, "node": dict(row) if row else None, "entity": None}
            mean = c.execute("SELECT AVG(energy) FROM energy").fetchone()[0] or 1.0
            e = c.execute("SELECT * FROM energy WHERE node_id=?", (nid,)).fetchone()
            out["energy"] = dict(e) | {"ratio": e["energy"] / mean} if e else None
            labels = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM entities")}
            texts = {r["id"]: (r["kind"], r["text"]) for r in c.execute("SELECT id, kind, text FROM nodes")}

            def lab(i):
                return labels.get(i) or i

            if ent:
                ledger = Ledger(c)
                out["entity"] = dict(ent)
                try:
                    out["sheet"] = sr_lite.sheet(ledger, nid, full=True)
                except Exception as exc:  # never let a sheet bug break browsing
                    out["sheet"] = f"(sheet error: {exc})"
                out["slices"] = [{"id": r["slice_id"], "role": r["role"], "text": texts.get(r["slice_id"], ("", ""))[1],
                                  "turn": int(r["slice_id"][1:]) if r["slice_id"][1:].isdigit() else 0}
                                 for r in c.execute("SELECT * FROM members WHERE node_id=? ORDER BY slice_id", (nid,))]
                out["slices"].sort(key=lambda d: d["turn"])
                out["holdings"] = [dict(r) for r in c.execute("SELECT * FROM holdings WHERE owner_id=?", (nid,))]
                out["held_by"] = [r["owner_id"] for r in c.execute("SELECT owner_id FROM holdings WHERE item_id=?", (nid,))]
                out["scenes"] = [dict(r) for r in c.execute(
                    "SELECT p.scene_id, s.title, p.first_turn FROM scene_presence p JOIN scenes s ON s.id=p.scene_id "
                    "WHERE p.entity_id=? ORDER BY p.scene_id", (nid,))]
            if row and row["kind"] == "slice":
                out["members"] = [{"id": r["node_id"], "role": r["role"], "label": lab(r["node_id"]),
                                   "text": texts.get(r["node_id"], ("", ""))[1][:200]}
                                  for r in c.execute("SELECT * FROM members WHERE slice_id=?", (nid,))]
                tid = int(nid[1:])
                t = c.execute("SELECT * FROM turns WHERE id=?", (tid,)).fetchone()
                out["turn"] = dict(t) if t else None
                out["tests"] = [dict(r) for r in c.execute("SELECT * FROM tests WHERE turn_id=?", (tid,))]
                out["events"] = [dict(r) for r in c.execute("SELECT * FROM events WHERE turn_id=? ORDER BY seq", (tid,))]
                m = c.execute("SELECT * FROM turn_metrics WHERE turn=?", (tid,)).fetchone()
                out["metrics"] = dict(m) if m else None
                out["recalled_by"] = [r["slice_id"] for r in c.execute(
                    "SELECT slice_id FROM members WHERE node_id=? AND role='recalled'", (nid,))]
            out["links"] = []
            for r in c.execute("SELECT * FROM links WHERE a=? OR b=? ORDER BY strength DESC", (nid, nid)):
                other = r["b"] if r["a"] == nid else r["a"]
                kind, text = texts.get(other, ("?", ""))
                out["links"].append({"other": other, "label": lab(other), "other_kind": kind, "kind": r["kind"],
                                     "strength": r["strength"], "together": r["together"], "text": text[:160]})
            out["notes"] = [dict(r) for r in c.execute(
                "SELECT n.* FROM nodes n JOIN annotates a ON a.note_id=n.id WHERE a.target_id=? "
                "ORDER BY n.created_turn DESC, n.id DESC", (nid,))]
            if row and row["kind"] == "tension" and _has_table(c, "tensions"):
                t = c.execute("SELECT * FROM tensions WHERE id=?", (nid,)).fetchone()
                out["tension"] = dict(t) if t else None
            if row and row["kind"] == "doubt" and _has_table(c, "doubts"):      # (dm/doubts.py: both sides are links)
                d = c.execute("SELECT * FROM doubts WHERE id=?", (nid,)).fetchone()
                out["doubt"] = dict(d) | {"about": [{"id": x["other"], "label": lab(x["other"])}
                                                    for x in out["links"] if x["kind"] == "about"]} if d else None
            if row and row["kind"] in ("note", "clarification", "tension"):
                out["targets"] = [{"id": r["target_id"], "label": lab(r["target_id"])}
                                  for r in c.execute("SELECT target_id FROM annotates WHERE note_id=?", (nid,))]
            out["history"] = [[r["turn"], r["ratio"]] for r in c.execute(
                "SELECT turn, ratio FROM energy_history WHERE node_id=? ORDER BY turn", (nid,))]
            out["art"] = [dict(r) for r in c.execute(
                "SELECT entity_id, version, status, caption, prompt, error, created_turn FROM art WHERE entity_id=? "
                "ORDER BY version DESC", (nid,))] if _has_table(c, "art") else []
            out["supersedes"] = [dict(r) for r in c.execute(
                "SELECT * FROM supersedes WHERE new_id=? OR old_id=?", (nid, nid))]
            out["knows"] = [dict(r) | {"text": texts.get(r["node_id"], ("", ""))[1][:200]} for r in c.execute(
                "SELECT * FROM knows WHERE holder=? ORDER BY turn DESC", (nid,))]
            out["known_by"] = [dict(r) | {"label": lab(r["holder"])} for r in c.execute(
                "SELECT * FROM knows WHERE node_id=?", (nid,))]
            if ent and ent["kind"] == "npc":
                out["beliefs"] = [dict(r) for r in c.execute(
                    "SELECT n.*, (n.id IN (SELECT old_id FROM supersedes)) AS superseded FROM nodes n WHERE n.kind='belief' "
                    "AND n.id IN (SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='holds') "
                    "ORDER BY n.created_turn DESC", (nid,) * 3)]
                out["attitudes"] = {r["key"].split(":", 1)[1]: r["value"] for r in c.execute(
                    "SELECT key, value FROM stats WHERE entity_id=? AND key LIKE 'attitude:%'", (nid,))}
            return out
        finally:
            c.close()

    # ── time ────────────────────────────────────────────────────────────
    def metrics(self) -> dict:
        c = _connect(self.path)
        try:
            return {"metrics": [dict(r) for r in c.execute("SELECT * FROM turn_metrics ORDER BY turn")],
                    "turns": [{"id": r["id"], "scene_id": r["scene_id"], "status": r["status"], "cost": r["cost"]}
                              for r in c.execute("SELECT id, scene_id, status, cost FROM turns ORDER BY id")],
                    "heat_turns": [r[0] for r in c.execute("SELECT DISTINCT turn FROM energy_history ORDER BY turn")]}
        finally:
            c.close()

    def heat(self, turn: int) -> dict:
        c = _connect(self.path)
        try:
            return {r["node_id"]: r["ratio"] for r in
                    c.execute("SELECT node_id, ratio FROM energy_history WHERE turn=?", (turn,))}
        finally:
            c.close()

    def art_file(self, eid: str, version: int | None) -> Path | None:
        c = _connect(self.path)
        try:
            if not _has_table(c, "art"):
                return None
            sql = "SELECT path FROM art WHERE entity_id=? AND status='ready'"
            args: list = [eid]
            if version:
                sql += " AND version=?"
                args.append(version)
            row = c.execute(sql + " ORDER BY version DESC LIMIT 1", args).fetchone()
            p = Path(row["path"]) if row else None
            return p if p and p.exists() else None
        finally:
            c.close()

    def search(self, q: str) -> list:
        c = _connect(self.path)
        try:
            like = f"%{q.lower()}%"
            return [dict(r) for r in c.execute(
                "SELECT n.id, n.kind, n.text FROM nodes n LEFT JOIN entities e ON e.id=n.id "
                "WHERE lower(n.text) LIKE ? OR lower(n.id) LIKE ? OR lower(COALESCE(e.name,'')) LIKE ? LIMIT 40",
                (like, like, like))]
        finally:
            c.close()


JSON = "application/json"
ROUTES = ("/graph3d", "/api/campaigns", "/api/graph", "/api/node", "/api/metrics", "/api/heat", "/api/search", "/api/art")


def _dumps(obj) -> bytes:
    return json.dumps(obj, default=str).encode()


def route(base: Api, path: str, q: dict[str, str]) -> tuple[int, bytes, str]:
    """One GET of the browser - its page or its API - as (status, body, content type). The graph browser's own
    server and the dashboard (which mounts the page at /graph) both answer through this."""
    if path == "/api/campaigns":
        return 200, _dumps({"current": base.path.stem, "campaigns": campaigns(base.path.parent)}), JSON
    api = base
    name = q.get("c", "")
    if name and name != base.path.stem:            # another campaign in the same folder
        p = base.path.parent / f"{name}.db"
        if not name.replace("_", "").replace("-", "").isalnum() or not p.exists():
            return 404, _dumps({"error": f"no campaign '{name}'"}), JSON
        api = Api(p)
    try:
        if path in ("/", "/index.html", "/graph"):
            return 200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8"
        if path == "/graph3d":                     # the same graph to fly through (static/graph3d.html)
            return 200, (STATIC / "graph3d.html").read_bytes(), "text/html; charset=utf-8"
        if path == "/api/graph":
            return 200, _dumps(api.graph()), JSON
        if path == "/api/node":
            return 200, _dumps(api.node(q.get("id", ""))), JSON
        if path == "/api/metrics":
            return 200, _dumps(api.metrics()), JSON
        if path == "/api/heat":
            return 200, _dumps(api.heat(int(q.get("turn", 0)))), JSON
        if path == "/api/search":
            return 200, _dumps(api.search(q.get("q", ""))), JSON
        if path == "/api/art":
            f = api.art_file(q.get("id", ""), int(q["v"]) if q.get("v", "").isdigit() else None)
            return (200, f.read_bytes(), "image/png") if f else (404, b"no art", "text/plain")
        return 404, b"not found", "text/plain"
    except Exception as exc:
        return 500, _dumps({"error": str(exc)}), JSON


def make_handler(base: Api):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):   # keep the console quiet
            pass

        def do_GET(self):  # noqa: N802
            url = urlparse(self.path)
            code, body, ctype = route(base, url.path, {k: v[0] for k, v in parse_qs(url.query).items()})
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return Handler


def serve(db_path: Path, port: int = 8765, background: bool = False):
    server = ThreadingHTTPServer(("127.0.0.1", port), make_handler(Api(Path(db_path))))
    if background:
        threading.Thread(target=server.serve_forever, daemon=True, name="graph-browser").start()
        return server
    print(f"Graph browser for {db_path.name}: http://127.0.0.1:{port}  (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return server
