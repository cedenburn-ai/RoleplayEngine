"""Story time, kept narrative (DESIGN.md §12): a day and a part of it - "Day 2, afternoon".

Underneath it's minutes since Day 1, 00:00, so memories, schedules and deadlines still compare and sort. But
nothing counts minutes any more: time doesn't tick each turn, travel doesn't add up, and the GM moves the clock only
when the story does ("time: evening", "time: next morning", sleep, a scene that runs into the night). The table
saw what minute-counting did - a GM "hyper focused on times", deadlines pinging, a timeline lock in the house rules -
so the clock now says what a person would: this afternoon, last night, three days ago.
"""
from __future__ import annotations

import re

DAY = 24 * 60
DEFAULT_START = 22 * 60          # a new campaign starts on Day 1, night - shadowruns happen at night
# Game.advance_clock's cap (nothing calls it any more). The GM's time: lines aren't capped: a player asked for
# "6 months later" (live T160) and the story took it.
MAX_STEP = 3 * DAY
# meta: {turn, text, clock} of a GM `time:` line nobody could read (dmblock writes it, the table's next packet says
# so). Game.set_clock clears it: once anyone sets the clock, "set it again" would skip the time twice.
MISS = "clock_miss"

# part of day: (first hour, the hour the clock lands on when the story moves to it)
PARTS = {"late night": (0, 1), "dawn": (5, 6), "morning": (8, 9), "midday": (12, 12), "afternoon": (14, 15),
         "evening": (18, 19), "night": (21, 22)}
ORDER = ["late night", "dawn", "morning", "midday", "afternoon", "evening", "night"]
# what the GM actually writes (live T156-T162 and the narrations: "late morning", "by noon", "by dusk", "that night")
WORDS = {"noon": "midday", "lunchtime": "midday", "lunch": "midday", "mid-day": "midday", "high noon": "midday",
         "dusk": "evening", "sunset": "evening", "sundown": "evening", "nightfall": "evening", "twilight": "evening",
         "early evening": "evening",
         "sunrise": "dawn", "daybreak": "dawn", "first light": "dawn", "early morning": "dawn", "morning light": "dawn",
         "late morning": "morning", "mid-morning": "morning", "midmorning": "morning", "mid morning": "morning",
         "early afternoon": "afternoon", "mid-afternoon": "afternoon", "midafternoon": "afternoon",
         "mid afternoon": "afternoon", "late afternoon": "afternoon",
         "midnight": "late night", "small hours": "late night", "after midnight": "late night",
         "before dawn": "late night", "pre-dawn": "late night", "predawn": "late night", "dead of night": "late night",
         "late at night": "late night",
         "late evening": "night", "tonight": "night", "dark": "night", "after dark": "night"}

# A jump: "3 days later", "three quiet days go by", "a week after", "six months later", "an hour later".
NUMS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
        "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "a dozen": 12, "dozen": 12, "a couple of": 2,
        "a couple": 2, "couple of": 2, "couple": 2, "a few": 3, "few": 3, "several": 4, "half an": 0.5, "half a": 0.5}
UNITS = {"minute": 1, "min": 1, "hour": 60, "hr": 60, "day": DAY, "night": DAY, "week": 7 * DAY,
         "fortnight": 14 * DAY, "month": 30 * DAY, "year": 365 * DAY}
_N = "|".join(sorted((re.escape(k) for k in NUMS), key=len, reverse=True)) + r"|\d+"
_U = r"minutes?|mins?|hours?|hrs?|days?|nights?|weeks?|fortnights?|months?|years?"
_PASSING = r"pass(?:es|ed)?|go(?:es)? by|went by|ha(?:ve|s|d) passed|roll(?:s|ed)? by|elapsed?"
_TAIL = rf"later(?: on)?|on|after|from now|{_PASSING}"
JUMP_N = re.compile(rf"\b({_N})\s+(?:([a-z]+)\s+)?({_U})\b(?:\s+({_TAIL})\b)?")   # a number, then a unit
JUMP_T = re.compile(rf"(?:\b([a-z]+)\s+)?\b({_U})\s+({_TAIL})\b")               # no number: "days later"
NUMBERISH = re.compile(r"(?:teen|ty|hundred|thousand|half)$")     # "twenty minutes later": a number we can't read
LEAD = re.compile(r"^(?:the|at|in the|on the|in|on|by the|by|around|about|until|till|into the|into|toward|towards|"
                  r"just|for|after|it'?s|it is|some time|sometime)\s+")
LATER = {"later", "later on", "a bit later", "a little later", "a little while later", "a while later", "a while",
         "next", "later today", "later that day", "later in the day", "hours later", "some hours later",
         "shortly after", "soon after", "afterwards", "shortly afterwards", "a while after"}
TOMORROW = {"tomorrow", "next day", "following day", "day after", "overnight", "morning after", "next morning",
            "following morning"}
TOMORROW_PRE = re.compile(r"^(?:tomorrow|next day|following day|day after|next|following)\s+(.+)$")
TOMORROW_POST = re.compile(r"^(.+?)\s+(?:tomorrow|next day|following day|day after|after)$")
TODAY = re.compile(r"^(?:later\s+)?(?:that|this)\s+(?:same\s+)?(.+)$")   # "that evening", "later this afternoon"
DAY_N = re.compile(r"\bday\s*(\d+)\b")
HINT = ("try 'evening', 'later', 'tomorrow morning', 'day 9 evening', '3 days later, evening' or '6 months later' - "
        "digits work too: '18 months later'")


def part_of_day(m: int) -> str:
    h = (m % DAY) // 60
    return next(p for p in reversed(ORDER) if h >= PARTS[p][0])


def day_of(m: int) -> int:
    return m // DAY + 1


def fmt(m: int) -> str:
    """Day 2, afternoon"""
    return f"Day {day_of(m)}, {part_of_day(m)}"


def short(m: int) -> str:
    """Day 2 afternoon - for card footers"""
    return f"Day {day_of(m)} {part_of_day(m)}"


def _at(day0: int, part: str) -> int:
    return day0 * DAY + PARTS[part][1] * 60


def since(then: int | None, now: int) -> str:
    """When something happened, the way a person says it: 'this afternoon', 'last night', 'yesterday morning'."""
    if then is None:
        return ""
    if then > now:
        return "just now"
    p_then = part_of_day(then)
    if p_then in ("night", "late night"):                 # a night runs 21:00 through the small hours
        tonight = _night(now) if part_of_day(now) in ("night", "late night") else now // DAY
        nights = tonight - _night(then)
        if nights >= 7:
            return _days_ago(nights)
        return ("tonight", "last night", "the night before last")[nights] if nights < 3 else f"{nights} nights ago"
    days = now // DAY - then // DAY
    word = {"dawn": "at dawn", "midday": "around midday"}.get(p_then, f"this {p_then}")
    if days == 0:
        return word
    if days == 1:
        return "yesterday " + word.replace("this ", "")
    return _days_ago(days)


def _days_ago(days: int) -> str:
    """'6 days ago', '3 weeks ago', '6 months ago', 'a year ago' - a six-month skip (live T160) shouldn't read as
    '26 weeks ago'."""
    if days < 7:
        return f"{days} days ago"
    if days < 60:
        weeks = days // 7
        return "a week ago" if weeks == 1 else f"{weeks} weeks ago"
    if days < 365:
        return f"{days // 30} months ago"
    years = days // 365
    return "a year ago" if years == 1 else f"{years} years ago"


def snap(m: int) -> int:
    """The first time the story would say at or after m - the next part of day's landing hour (a courier due at 02:30
    comes at dawn). Deliveries land on these, so nothing waits on a minute (the narrative clock, §12)."""
    day0 = m // DAY
    for d in (day0, day0 + 1):
        for part in ORDER:
            t = _at(d, part)
            if t >= m:
                return t
    return _at(day0 + 1, "late night")


def ahead(then: int, now: int) -> str:
    """When something will happen, the way a person says it - coarse, never a countdown: 'tonight', 'tomorrow
    morning', 'in two days', 'in a few days', 'in about a week'. (since() looks back; this looks forward.)"""
    if then <= now:
        return "now"
    days = _base_day(then) - _base_day(now)
    part = part_of_day(then)
    if days == 0:
        if part in ("night", "late night"):
            return "tonight"
        return {"dawn": "at dawn", "midday": "around midday"}.get(part, f"this {part}")
    if days == 1:
        return "tomorrow " + {"late night": "night", "midday": "around midday", "dawn": "at dawn"}.get(part, part)
    if days == 2:
        return "in two days"
    if days < 7:
        return "in a few days"
    if days < 14:
        return "in about a week"
    if days < 28:
        return "in a couple of weeks"
    if days < 60:
        return "in about a month"
    return f"in {days // 30} months"


def _night(m: int) -> int:
    """Which night a night-time minute belongs to: the day it began (the small hours count as the night before)."""
    return m // DAY - (1 if part_of_day(m) == "late night" else 0)


def ago(delta: int) -> str:
    """Coarse 'how long ago' when only the gap is known (prefer since(), which knows the time of day)."""
    if delta < 60:
        return "just now"
    if delta < 6 * 60:
        return "a little while ago"
    if delta < 20 * 60:
        return "earlier today"
    days = round(delta / DAY)
    return "yesterday" if days <= 1 else _days_ago(days)


def _next(now: int, part: str, day0: int | None = None) -> int:
    """The next time it's `part` (now, if it already is) - or that part of day `day0`."""
    if day0 is not None:
        return _at(day0, part)
    if part_of_day(now) == part:
        return now
    if part == "night" and part_of_day(now) == "late night":
        return now                                   # "tonight" at 1 a.m. is this night, not 21 hours on
    today = _at(now // DAY, part)
    return today if today > now else _at(now // DAY + 1, part)


def _base_day(now: int) -> int:
    """The story's 'today' (0-based): the small hours still belong to the night before, as 'tomorrow' always has."""
    return now // DAY - (1 if part_of_day(now) == "late night" else 0)


def _clean(text: str) -> str:
    """Lowercase, punctuation and dashes out ("Day 9 - evening", "evening (3 days later)", "Evening!"), leading
    filler off ("by noon", "until dawn", "in the morning") - HH:MM and 02.10 keep their colon and dot."""
    s = text.strip().lower()
    s = re.sub(r"[,;()\[\]*_!?\"“”]|:(?=\s|$)|\.(?=\s|$)|\s[-–—]+\s|[–—]", " ", s)
    return _strip_lead(" ".join(s.split()))


def _strip_lead(s: str) -> str:
    while True:
        t = LEAD.sub("", s, count=1)
        if t == s:
            return s
        s = t


def _part(s: str) -> str | None:
    """A bare part of day ('evening', 'late morning', 'at dusk', 'in the afternoon'), or None."""
    s = re.sub(r"\s+(?:of|on)$", "", _strip_lead(s.strip()))
    s = WORDS.get(s, s)
    return s if s in PARTS else None


def _jump(s: str, text: str, now: int) -> int | None:
    """'3 days later', 'evening, 3 days later', 'two days later at dusk', 'six months later', 'an hour later' -
    a jump, with a part of day on either side or none. None when the line has no jump in it."""
    m = JUMP_N.search(s)
    if m:
        word, adj, unit, tail = m.groups()
        start = m.start()
    else:
        m = JUMP_T.search(s)
        if not m:
            return None
        (adj, unit, tail), word = m.groups(), None
        start = m.start()
        if adj and _part(adj):
            # "evening, days later": the word before is the part of day, not an adjective - it stays in what's
            # left, or the line lands on the morning (and "evening, hours later" would read with no error)
            adj, start = None, m.start(2)
    if adj and (NUMBERISH.search(adj) or adj in NUMS):
        raise ValueError(f"can't read a time from '{text}' ({HINT})")     # "twenty minutes": say it in digits
    n = NUMS.get(word, 0) or int(word) if word else (1 if not unit.endswith("s") else 3)   # "days later": a few
    minutes = int(n * UNITS[unit.rstrip("s")])
    rest = (s[:start] + " " + s[m.end():]).strip()
    part = _part(rest) if rest else None
    if rest and part is None or part and minutes < DAY:
        raise ValueError(f"can't read a time from '{text}' ({HINT})")     # "3 days later, teatime"
    if part is None and unit.startswith("night"):    # "two nights later": that night; "a night passes": the morning
        part = "morning" if tail and re.match(_PASSING, tail) else "night"
    if part is None:
        return now + minutes
    # "3 days later, evening" is that part of day N days on; "late night" is the small hours after its evening
    return max(now, _at(_base_day(now) + minutes // DAY + (1 if part == "late night" else 0), part))


def parse(text: str, now: int) -> int:
    """Where the story's clock goes. Narrative: a part of day ('evening', 'late morning', 'by dusk', 'tonight'),
    'later' (the next part of the day), today's part ('this afternoon', 'that night', 'later that evening' - never a
    day on: if it's passed, the clock stays), tomorrow's ('tomorrow morning', 'the following evening', 'noon
    tomorrow', 'overnight'), 'the day after tomorrow', a day ('day 9 evening', 'Day 9 - evening', 'day 9'), and a jump
    alone or with a part of day ('3 days later', 'three quiet days go by', '3 days later, evening', 'evening, 3 days
    later', 'two days later at dusk', 'a week later, morning', 'six months later', 'an hour later', 'next week'). The
    exact forms still work: '+45m', '+2h', '+183d', '02:10', 'day 3 08:00'. Raises ValueError on anything else - the
    GM is told (dmblock's clock_miss), so a line nobody can read never moves the clock silently wrong.

    Live T160/T162: '6 months later' and '3 days later, evening' were both thrown out, and the clock sat six months
    and three days behind the story."""
    s = _clean(text)
    m = re.fullmatch(r"\+\s*(\d+)\s*(m|min|mins|minutes?|h|hrs?|hours?|d|days?)", s)
    if m:
        n, unit = int(m.group(1)), m.group(2)[0]
        return now + n * {"m": 1, "h": 60, "d": DAY}[unit]
    m = re.fullmatch(r"(?:day\s*(\d+)\s*)?(\d{1,2})[:.h](\d{2})", s)
    if m:
        hh, mm = int(m.group(2)), int(m.group(3))
        if hh > 23 or mm > 59:
            raise ValueError(f"no such time: {text}")
        if m.group(1):
            return (int(m.group(1)) - 1) * DAY + hh * 60 + mm
        target = (now // DAY) * DAY + hh * 60 + mm
        return target if target >= now else target + DAY        # the next time the clock reads that
    if s in LATER:
        i = ORDER.index(part_of_day(now))
        nxt = ORDER[(i + 1) % len(ORDER)]
        return _at(now // DAY + (1 if nxt == "late night" else 0), nxt)
    if s in TOMORROW:
        s = "tomorrow morning"
    s = re.sub(r"\b(?:next|following)\s+(week|fortnight|month|year)\b", r"a \1 later", s)
    s = {"late that night": "that late night", "late tonight": "that late night", "later tonight": "tonight"}.get(s, s)
    m = re.fullmatch(r"day after tomorrow\s*(.*)", s)
    if m:
        part = _part(m.group(1)) if m.group(1) else "morning"
        if part:
            return max(now, _at(_base_day(now) + 2 + (1 if part == "late night" else 0), part))
    m = DAY_N.search(s)                                # an absolute day (the owner's fixes, a GM resetting it)
    if m:
        rest = (s[:m.start()] + " " + s[m.end():]).strip()
        part = _part(rest) if rest else "morning"
        if part:
            return _at(int(m.group(1)) - 1, part)
        raise ValueError(f"can't read a time from '{text}' ({HINT})")
    t = _jump(s, text, now)
    if t is not None:
        return t
    m = TOMORROW_PRE.fullmatch(s) or TOMORROW_POST.fullmatch(s)
    part = _part(m.group(1)) if m else None
    if part:
        # (at 2 a.m., "tomorrow morning" is a few hours away - the same calendar day)
        return max(now, _at(_base_day(now) + 1 + (1 if part == "late night" else 0), part))
    m = TODAY.fullmatch(s)
    part = _part(m.group(1)) if m else None
    if part:
        # today's: never a day on - "that evening" at 22:00 means it's still that evening, not tomorrow's. In the
        # small hours only the night is still the night before's: "later that morning" at 03:00 is the coming one,
        # on the calendar day the GM sees ("Day 7, late night") - not yesterday's, which froze the clock silently
        night = part in ("night", "late night")
        day0 = _base_day(now) if night else now // DAY
        return max(now, _at(day0 + (1 if part == "late night" else 0), part))
    part = _part(s)
    if part:
        return _next(now, part)
    raise ValueError(f"can't read a time from '{text}' ({HINT})")
