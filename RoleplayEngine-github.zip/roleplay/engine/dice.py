"""Server-side dice. Players never roll; the engine does (DESIGN.md §6)."""
from __future__ import annotations

import random


class Dice:
    def __init__(self, seed: int | None = None):
        self.rng = random.Random(seed)

    def roll(self, n: int) -> list[int]:
        return [self.rng.randint(1, 6) for _ in range(max(0, n))]


class ScriptedDice(Dice):
    """Deterministic dice for tests: hands out the given faces in order, then 3s."""

    def __init__(self, faces: list[int]):
        super().__init__(0)
        self.faces = list(faces)

    def roll(self, n: int) -> list[int]:
        out = []
        for _ in range(max(0, n)):
            out.append(self.faces.pop(0) if self.faces else 3)
        return out
