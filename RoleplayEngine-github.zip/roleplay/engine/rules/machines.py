"""Drones and vehicles (DESIGN.md §7a): machines with their own stats, run three ways.

  autonomous  the machine's own Pilot + the autosoft for the job (Targeting, Clearsight, Maneuvering,
              Evasion, Stealth) - no autosoft means Pilot - 1
  remote      a controller's skill + Logic (a commlink link); -2 for each other live machine they're also running
              where they are
  jumped      a controller's skill + Reaction + their control rig (riding the machine's senses) - one machine at a
              time; the rigger's body is limp, half the machine's damage comes back as Stun biofeedback, and
              losing it under them is 6 dumpshock. A hacker has to beat the rigger, not the drone (SR5 p. 266-269)

Machines don't take stun, use their own Armor, and are destroyed instead of dying. Who may drive one:
  - its owner;
  - a crewmate the owner lent the keys to (props.delegates) - SR5's Invite Mark and the owner's permission to jump in
    (p. 240-241), kept simple: the keys stand until the owner takes the controls back. Only a runner's machine is lent
    this way; an NPC's changes hands by a hack;
  - a decker who steals it: win an opposed Hacking test against it (it defends with its Pilot as a device rating,
    doubled), and only then does control_drone accept them.
A machine someone runs goes where they go (followers). Crashes and rams (crash: SR5 p. 201-203) do the vehicle's Body
to everyone aboard, and the ram table's multiple of it to whatever is hit. The pool math lives in sr_lite (build_pool
routes machines to machine_pool) so every existing tool works with a drone as actor or target.

What it carries is what's in its holdings (2026-10-24): a bought machine is the book's bare frame; it has its Body / 3
weapon mounts (p. 461) - a standard mount holds an assault rifle or smaller, a heavy one takes two and holds anything
- and runs half its Pilot in autosofts, rounded up (p. 269). check_load / mount_weapon put guns, mounts, autosofts
and grenades aboard (no mount for grenades: the table's drop rig). Anything else handed to it rides as cargo (stow,
2026-10-25): a medkit in the van, a datachip on a courier drone, a rifle in the trunk - held with state.cargo, never
on a mount, never fired from it.
"""
from __future__ import annotations

import re
from math import ceil

from ..ledger import Ledger, LedgerError, RulesRefusal
from . import magic, sr_lite

# model -> what it is: the book's numbers (SR5 p. 462-466; the drone table there is printed a row out of line - these
# are matched against the rigger archetype's stat blocks, p. 123) at this table's scale. Handling, Speed, Accel, Pilot
# and Sensor are the book's ratings. Armor is a third of the book's, like a person's (an armored jacket's 12 is our
# 4): our damage is about 0.6 of the book's, and full book armor on a drone made the Steel Lynx all but immune. A
# drone's Body is the book's; a vehicle's stays on the damage scale, since a crash does its Body (p. 201).
# slots: weapon mounts it can take - the book's unaugmented Body / 3, rounded down (p. 461; the Roto-drone counts as
# Body 7, p. 466) - a heavy mount takes two. mounts: what it comes with. Sold, it's that frame and nothing else; an NPC's
# introduced drone comes fitted (build_machine(equipped)): its usual weapon (loadout) and autosofts up to its slots.
MODELS = {
    "fly-spy": {"kind": "drone", "name": "Fly-Spy", "desc": "insect-sized aerial spy drone, hard to spot",
                "stats": dict(handling=4, speed=3, accel=2, body=1, armor=0, pilot=3, sensor=3),
                "slots": 0, "mounts": (), "autosofts": dict(clearsight=3, stealth=3, evasion=3)},
    "roto-drone": {"kind": "drone", "name": "Roto-drone", "desc": "modular quad-rotor medium drone, built to be armed",
                   "stats": dict(handling=4, speed=4, accel=2, body=4, armor=1, pilot=3, sensor=3),
                   "slots": 2, "mounts": (), "autosofts": dict(targeting=3, evasion=3, clearsight=3, maneuvering=3),
                   "loadout": ("drone SMG", dict(dv=5, ap=0, skill="firearms", damage_type="physical", ammo_capacity=30,
                                                 size="standard"))},
    "doberman": {"kind": "drone", "name": "Doberman", "desc": "tracked perimeter-patrol drone with a standard weapon mount",
                 "stats": dict(handling=5, speed=3, accel=1, body=4, armor=1, pilot=3, sensor=3),
                 "slots": 1, "mounts": ("standard",), "autosofts": dict(targeting=3, evasion=3, clearsight=3),
                 "loadout": ("turret SMG", dict(dv=5, ap=0, skill="firearms", damage_type="physical", ammo_capacity=30,
                                                size="standard"))},
    "steel lynx": {"kind": "drone", "name": "Steel Lynx",
                   "desc": "hardened combat drone on four wheeled legs, with a heavy weapon mount",
                   "stats": dict(handling=5, speed=4, accel=2, body=6, armor=4, pilot=3, sensor=3),
                   "slots": 2, "mounts": ("heavy",), "autosofts": dict(targeting=4, evasion=3, maneuvering=3, clearsight=3),
                   "loadout": ("drone LMG", dict(dv=7, ap=-2, skill="firearms", damage_type="physical", ammo_capacity=50,
                                                 size="heavy"))},
    "crawler": {"kind": "drone", "name": "Crawler", "desc": "small walker drone that climbs stairs and walls",
                "stats": dict(handling=4, speed=3, accel=1, body=3, armor=1, pilot=4, sensor=3),     # Pilot "a step above"
                "slots": 1, "mounts": (), "autosofts": dict(maneuvering=3, clearsight=2)},
    "americar": {"kind": "vehicle", "name": "Ford Americar", "desc": "the most stolen sedan in the UCAS",
                 "stats": dict(handling=4, speed=3, accel=2, body=8, armor=2, pilot=1, sensor=2),
                 "slots": 3, "mounts": (), "autosofts": dict(maneuvering=1)},
    "scorpion": {"kind": "vehicle", "name": "Harley-Davidson Scorpion", "desc": "a growling, armored chrome road hog",
                 "stats": dict(handling=4, speed=4, accel=2, body=5, armor=3, pilot=1, sensor=2),
                 "slots": 2, "mounts": (), "autosofts": {}},
    "bulldog": {"kind": "vehicle", "name": "GMC Bulldog", "desc": "armored step-van, the shadowrunner's minivan",
                "stats": dict(handling=3, speed=3, accel=1, body=12, armor=4, pilot=1, sensor=2),
                "slots": 5, "mounts": (), "autosofts": dict(maneuvering=1)},
}
MODES = ("remote", "jumped")
MOUNT_SLOTS = {"standard": 1, "heavy": 2}    # a heavy mount counts as two (p. 461)
CARGO = "cargo"                              # holding state: stowed aboard, not fitted (stow)
# Machine guns, cannons and launchers need a heavy mount; a standard one holds "any assault rifle or smaller" (p. 461).
HEAVY = re.compile(r"\b(?:lmg|mmg|hmg|machine\s*gun|minigun|cannon|launcher|sniper|valiant|stoner|rpk|m202)\b", re.I)
# What a machine does, for the pools the cards compare (driver against its own Pilot): the skill each job rolls.
DOES = (("shoots", "firearms"), ("spots", "perception"), ("drives", "piloting"), ("dodges", "evasion"))


def model(name: str | None) -> str | None:
    """'Roto-drone', 'roto drone', 'MCT Fly-Spy' -> the catalog key."""
    low = (name or "").lower().replace("_", " ")
    squash = low.replace("-", "").replace(" ", "")
    for key, m in MODELS.items():
        k = key.replace("-", "").replace(" ", "")
        if k in squash or m["name"].lower().replace("-", "").replace(" ", "") in squash:
            return key
    return None


def soft_slots(pilot: int) -> int:
    """Autosofts a drone runs: half its Device Rating, rounded up - and its Device Rating is its Pilot (p. 269)."""
    return max(1, ceil(int(pilot) / 2))


def build_machine(ledger: Ledger, name: str, model_key: str | None, owner: str | None, turn: int = 0,
                  description: str = "", aliases=(), equipped: bool = True) -> str:
    """A drone or vehicle from the model catalog. equipped (an NPC's drone the GM introduces, an archetype's): fitted
    the way it'd be met on the street - its usual weapon on a mount, and autosofts up to its slots (ceil(Pilot / 2):
    the old bundles ran 3-4 on Pilot 3). Not equipped (bought - shops, character creation): the book's frame alone,
    with only the mounts it comes with (the Doberman's standard, the Steel Lynx's heavy) - mounts, autosofts and guns
    are bought on their own (live T184-T187: three drones came with a free gun, mount and 3-4 autosofts each)."""
    key = model_key if model_key in MODELS else (model(model_key) or model(name))
    if key is None:
        raise LedgerError(f"Unknown drone/vehicle model for '{name}'. Models: {', '.join(MODELS)}.")
    m = MODELS[key]
    softs = dict(list(m["autosofts"].items())[:soft_slots(m["stats"]["pilot"])]) if equipped else {}
    mounts = list(m.get("mounts") or ())
    gun = m.get("loadout") if equipped else None
    if gun and gun[1].get("size", "standard") not in mounts:
        mounts.append(gun[1].get("size", "standard"))           # (its gun came on a mount of its own)
    props = {"model": key, "autosofts": softs, "mounts": mounts, "owner": owner, "controller": None, "control": None}
    desc = description or (m["desc"] + (f", fitted with a {gun[0]}" if gun else ""))
    eid = ledger.create_entity(m["kind"], name, desc, aliases=aliases, props=props, turn=turn)
    for k, v in m["stats"].items():
        ledger.set_stat(eid, k, v)
    if gun:
        mname, mprops = gun
        iid = ledger.create_entity("item", f"{name}'s {mname}", description=mname, tier=0, props=dict(mprops), turn=turn)
        ledger.give(eid, iid, 1, {"loaded": mprops["ammo_capacity"]} if "ammo_capacity" in mprops else {})
    return eid


# ── What it carries: weapon mounts (SR5 p. 461), autosofts (p. 269), and what rides aboard ──
def weapon_size(item: dict) -> str | None:
    """'standard' or 'heavy' for a gun a mount can hold; None for what no mount takes (a blade, a thrown knife)."""
    p = item.get("props") or {}
    if p.get("size") in MOUNT_SLOTS:
        return p["size"]
    if "dv" not in p or p.get("explosive") or p.get("skill", "firearms") != "firearms":
        return None
    return "heavy" if HEAVY.search(item.get("name", "")) else "standard"


def _weapons(ledger: Ledger, m: dict, here_only: bool = False) -> list[dict]:
    """The guns on its mounts - not grenades aboard, not a rifle or a katana stowed as cargo."""
    held = sr_lite.in_hand(ledger, m["id"]) if here_only else ledger.holdings(m["id"])
    return [i for i in held if "dv" in i["props"] and not i["props"].get("explosive") and not i["state"].get(CARGO)]


def mounts(ledger: Ledger, m: dict) -> list[str]:
    """The weapon mounts on a machine: the ones it came with or was built with (props.mounts) and mount items fitted
    since. A machine from before mounts were counted (no props.mounts) has one mount for each gun it carries - its
    old bundled weapon came with its own."""
    return _base_mounts(ledger, m) + [i["props"]["mount"] for i in ledger.holdings(m["id"])
                                      if i["props"].get("mount") in MOUNT_SLOTS]


def _base_mounts(ledger: Ledger, m: dict) -> list[str]:
    p = m["props"]
    return list(p["mounts"]) if "mounts" in p else [weapon_size(w) or "standard" for w in _weapons(ledger, m)]


def settle_mounts(ledger: Ledger, m: dict, turn: int | None = None) -> dict:
    """Before anything moves on or off a machine from before mounts were counted: its inferred mounts (one a gun) become
    mount items it holds, so they stay when the gun comes off - and can come off themselves (live: Filament's
    Roto-drone has its old SMG's mount in one of its two slots; a machine gun needs both, for a heavy one).
    Returns the machine as it is now."""
    if "mounts" in m["props"]:
        return m
    for size in _base_mounts(ledger, m):
        iid = ledger.create_entity("item", f"{m['name']}'s weapon mount ({size})", f"weapon mount ({size})", tier=0,
                                   props={"mount": size}, turn=turn or 0)
        ledger.give(m["id"], iid, 1)
    ledger.update_entity(m["id"], props={**m["props"], "mounts": []})
    return ledger.require(m["id"])


def slots(ledger: Ledger, m: dict) -> int:
    """How many weapon mounts it has room for: its model's (p. 461), else its Body / 3."""
    key = m["props"].get("model")
    if key in MODELS:
        return int(MODELS[key]["slots"])
    return int(ledger.stat(m["id"], "body", 0)) // 3


def _fits(mts: list[str], guns: list[str]) -> bool:
    """Every gun on a mount: a heavy one on a heavy mount, the rest anywhere."""
    heavy = sum(1 for g in guns if g == "heavy")
    return heavy <= sum(1 for x in mts if x == "heavy") and len(guns) <= len(mts)


def _soft_names(ledger: Ledger, m: dict) -> set[str]:
    return set((m["props"].get("autosofts") or {})) | {i["props"]["autosoft"] for i in ledger.holdings(m["id"])
                                                        if i["props"].get("autosoft")}


def check_load(ledger: Ledger, m: dict, item: dict) -> str:
    """Can this go onto machine m? Raises RulesRefusal if not, else says how it rides: a gun needs a free mount of its
    size, a mount a free slot, an autosoft a free autosoft slot. Explosives need none: a drone carrying grenades drops
    or throws them (explode with the drone as holder - its own Pilot + Targeting) - the table's drop rig; core SR5
    delivers drone grenades through a mounted launcher."""
    if m["kind"] not in sr_lite.MACHINES:
        raise LedgerError(f"{m['name']} isn't a drone or vehicle.")
    p = item.get("props") or {}
    if p.get("explosive"):
        return "rides aboard (no mount needed: it drops or throws it)"
    if p.get("mount") in MOUNT_SLOTS:
        used = sum(MOUNT_SLOTS[x] for x in mounts(ledger, m))
        need, room = MOUNT_SLOTS[p["mount"]], slots(ledger, m)
        if used + need > room:
            raise RulesRefusal(f"{m['name']} has room for {room} weapon mount{'s' * (room != 1)} (its Body / 3, SR5 "
                               f"p. 461 - a heavy mount takes two) and {used} {'is' if used == 1 else 'are'} taken - "
                               f"no room for a {p['mount']} mount.")
        return f"a {p['mount']} weapon mount ({used + need} of {room} slots)"
    if p.get("autosoft"):
        names = _soft_names(ledger, m)
        room = soft_slots(int(ledger.stat(m["id"], "pilot", 1)))
        if p["autosoft"] not in names and len(names) >= room:
            raise RulesRefusal(f"{m['name']} runs {room} autosoft{'s' * (room != 1)} at most (half its Pilot, rounded "
                               f"up - SR5 p. 269) and has {', '.join(sorted(names))}.")
        return f"loaded ({len(names | {p['autosoft']})} of {room} autosoft slots)"
    size = weapon_size(item)
    if size is None:
        raise RulesRefusal(f"{item['name']} doesn't go on a weapon mount - mounts hold guns (SR5 p. 461); a drone "
                           "carries grenades aboard, guns, mounts and autosofts are fitted with mount_weapon, and "
                           "anything else rides as cargo: transfer_item it aboard.")
    mts, guns = mounts(ledger, m), [weapon_size(w) or "standard" for w in _weapons(ledger, m)]
    if _fits(mts, guns + [size]):
        return f"on a {'heavy' if size == 'heavy' else 'weapon'} mount ({len(guns) + 1} of {len(mts)} mounts in use)"
    if not mts:
        why = "no weapon mount - buy one onto it first (weapon-mount, or heavy-mount for a machine gun)"
    elif size == "heavy" and "heavy" not in mts:
        why = ("no heavy mount - a machine gun needs one (heavy-mount: it takes two slots"
               + (f", and {m['name']} has {slots(ledger, m)})" if slots(ledger, m) < 2 else ")"))
    else:
        why = f"every mount is in use ({', '.join(w['name'] for w in _weapons(ledger, m))}) - take one off first"
    raise RulesRefusal(f"{item['name']} won't go on {m['name']}: {why} (SR5 p. 461).")


def stow(ledger: Ledger, m: dict, item: dict) -> tuple[str, bool]:
    """How something handed to machine m rides (transfer_item): (how, as cargo). Grenades, mounts and autosofts are
    fitted (check_load), and so is a gun handed to a drone - a mount is the only way a drone carries one, so nothing
    hangs a sniper rifle on a Fly-Spy. Anything else is cargo, and a gun in a vehicle is stowed, not mounted
    (mount_weapon fits it). Review E2: check_load on every item refused a medkit into the Bulldog, a paydata chip onto
    a courier drone and a spare rifle into the van's trunk - while the prompt tells the GM never to invent a reason a
    drone can't carry something."""
    p = item.get("props") or {}
    fitted = p.get("explosive") or p.get("mount") in MOUNT_SLOTS or p.get("autosoft")
    if fitted or (m["kind"] == "drone" and weapon_size(item)):
        return check_load(ledger, m, item), False
    if m["kind"] not in sr_lite.MACHINES:
        raise LedgerError(f"{m['name']} isn't a drone or vehicle.")
    return "stowed aboard as cargo" + (" - not on a mount (mount_weapon fits it)" if weapon_size(item) else ""), True


def check_unload(ledger: Ledger, m: dict, item: dict) -> None:
    """Can this come off machine m? A mount with a gun on it stays until the gun comes off - mount_weapon's rule, and
    transfer_item's (review E2: it took a Roto-drone's only mount from under its HK-227, leaving a gun on 0 mounts)."""
    if item["props"].get("mount") not in MOUNT_SLOTS or not ledger.holds(m["id"], item["id"]):
        return
    left = mounts(ledger, m)
    left.remove(item["props"]["mount"])
    if not _fits(left, [weapon_size(w) or "standard" for w in _weapons(ledger, m)]):
        raise RulesRefusal(f"A gun is on that mount - take it off {m['name']} first.")


def cargo_line(ledger: Ledger, m: dict) -> str:
    """What it carries stowed (cargo): handed back out with transfer_item."""
    held = [i for i in ledger.holdings(m["id"]) if i["state"].get(CARGO)]
    if not held:
        return ""
    return "Cargo: " + "; ".join((f"{i['qty']}x " if i["qty"] > 1 else "") + f"{i['name']} [{i['id']}]" for i in held)


def commands(ledger: Ledger, m: dict, eid: str) -> bool:
    """Who may load a machine: its owner, whoever is driving it, or a crewmate holding the owner's keys."""
    p = m["props"]
    return eid in (p.get("owner"), p.get("controller")) or eid in (p.get("delegates") or [])


def mount_weapon(ledger: Ledger, turn: int | None, machine_id: str, item_id: str, by: str, unmount: bool = False,
                 qty: int | None = None) -> str:
    """Put a gun on a drone's mount - or a mount, an autosoft, grenades aboard (check_load) - from by's hands, or take
    it back off (unmount: back to by). by is the owner, the driver or a keyholder. Live T184: the GM had a dealer say a
    Roto-drone 'can't lift' a machine gun (by the book it takes a heavy mount, p. 466), and narrated a drop rig the
    ledger never had - the grenades stayed in Filament's pockets."""
    m, c = ledger.require(machine_id), ledger.require(by)
    if m["kind"] not in sr_lite.MACHINES:
        raise LedgerError(f"{m['name']} isn't a drone or vehicle.")
    if not commands(ledger, m, c["id"]):
        owner = ledger.get(m["props"].get("owner") or "")
        raise RulesRefusal(f"{c['name']} has no say over {m['name']}" + (f" - it's {owner['name']}'s" if owner else "")
                           + ": its owner, its driver or a crewmate with the keys loads it.")
    item = ledger.find(item_id)
    src, dst = (m, c) if unmount else (c, m)
    if item is None or not ledger.holds(src["id"], item["id"]):
        raise LedgerError(f"{src['name']} isn't holding '{item_id}'.")
    for what in (m, item):
        if sr_lite.arriving(what):
            raise LedgerError(f"{what['name']} is {sr_lite.transit_note(ledger, what)} - it can't be fitted yet.")
    have = next((i["qty"] for i in ledger.holdings(src["id"]) if i["id"] == item["id"]), 1)
    n = max(1, min(have, int(qty or (have if item["props"].get("explosive") else 1))))
    m = settle_mounts(ledger, m, turn)                    # (an old bundle's mount stays when its gun comes off)
    if unmount:
        check_unload(ledger, m, item)                     # (a mount with a gun on it stays until the gun comes off)
        how = "taken off"
    else:
        how = check_load(ledger, m, item)
    state = ledger.take(src["id"], item["id"], n)
    state.pop(CARGO, None)                                # (fitted, or back in someone's hands: not cargo now)
    ledger.give(dst["id"], item["id"], n, state)
    ledger.log(turn, "mount", m["id"], {"item": item["id"], "qty": n, "by": c["id"], "off": unmount})
    what = item["name"].split("'s ", 1)[-1] + (f" x{n}" if n > 1 else "")
    return (f"[GEAR] {c['name']} takes the {what} off {m['name']}" if unmount
            else f"[GEAR] {c['name']} fits {m['name']} with the {what} - {how}")


def mount_line(ledger: Ledger, m: dict) -> str:
    """The sheet's line: its mounts, what's on them, the slots left."""
    mts, guns = mounts(ledger, m), _weapons(ledger, m)
    room = slots(ledger, m)
    if not mts and not guns and not room:
        return ""
    def gun(i):
        p = i["props"]
        bits = [f"DV{p['dv']}" + (f" AP{p['ap']}" if p.get("ap") else "")]
        if "ammo_capacity" in p:
            bits.append(f"{i['state'].get('loaded', p['ammo_capacity'])}/{p['ammo_capacity']}")
        if sr_lite.arriving(i):
            bits.append(sr_lite.transit_note(ledger, i))
        return f"{i['name']} [{i['id']}] ({'; '.join(bits)})"
    used = sum(MOUNT_SLOTS[x] for x in mts)
    head = (f"Mounts {used} of {room} slot{'s' * (room != 1)}: " + (", ".join(mts) if mts else "none fitted"))
    return head + (" - " + "; ".join(gun(i) for i in guns) if guns else (" - empty" if mts else ""))


def aboard_line(ledger: Ledger, m: dict) -> str:
    """Grenades it carries (explode with it as the holder drops or throws one)."""
    boom = [i for i in ledger.holdings(m["id"]) if i["props"].get("explosive")]
    if not boom:
        return ""
    return "Aboard: " + "; ".join(f"{i['qty']}x {i['name']} [{i['id']}]" if i["qty"] > 1 else f"{i['name']} [{i['id']}]"
                                  for i in boom) + " - it drops or throws them (explode, holder: the drone)"


def _machines(ledger: Ledger) -> list[dict]:
    return [e for kind in sr_lite.MACHINES for e in ledger.entities(kind=kind)]


def owned_by(ledger: Ledger, eid: str) -> list[dict]:
    return [e for e in _machines(ledger) if e["props"].get("owner") == eid]


def driven_by(ledger: Ledger, eid: str) -> list[dict]:
    """Machines eid has the controls of that aren't theirs - a crewmate's lent drone, a stolen one."""
    return [e for e in _machines(ledger) if e["props"].get("controller") == eid and e["props"].get("owner") != eid]


def keys_held(ledger: Ledger, eid: str) -> list[dict]:
    """Machines whose owner lent eid the keys."""
    return [e for e in _machines(ledger) if eid in (e["props"].get("delegates") or [])]


def _names(ledger: Ledger, ids) -> str:
    return ", ".join((ledger.get(i) or {}).get("name", i) for i in ids)


# ── Who drives ──────────────────────────────────────────────────────────
def _no_control(m: dict, c: dict, owner: dict | None) -> str:
    """The refusal for someone with no claim on a machine. Live T188 (flags #67, #68): it only ever said to hack it -
    a crewmate's drone too - so it names the owner's handover when a runner owns it."""
    return (f"{c['name']} has no control of {m['name']}" + (f" - it answers to {owner['name']}" if owner else "")
            + ". Win an opposed Hacking test against it this turn first"
            + (f", or - if {owner['name']} is handing it over - call control_drone again with owner_hands_over: true"
               if owner and owner["kind"] == "pc" else "") + ".")


def _hijacker(ledger: Ledger, m: dict, c: dict) -> dict | None:
    """Whoever holds the machine now with no right to it - not the owner, no keys, not c themselves."""
    p = m["props"]
    cur = ledger.get(p.get("controller") or "")
    if not cur or cur["id"] in (p.get("owner"), c["id"]) or cur["id"] in (p.get("delegates") or []):
        return None
    return cur


def _lendable(ledger: Ledger, m: dict, owner: dict | None, c: dict) -> None:
    """Can the owner lend c the keys? Only a runner's machine is lent: an NPC's 'consent' would be the GM's word alone,
    and a stranger's drone changes hands by a hack (live review: Kaz's Doberman went to Ghost on a handover, no roll).
    Never by an owner who's out, nor while a hijacker holds it."""
    if not owner:
        raise RulesRefusal(f"{m['name']} has no owner on file to hand it over - an ownerless machine is taken by "
                           "winning an opposed Hacking test against it.")
    if owner["kind"] != "pc":
        raise RulesRefusal(f"{owner['name']} isn't one of the crew - an NPC's drone only changes hands by a won opposed "
                           "Hacking test (or introduce it with owner_id the runner, if it was a gift).")
    cond = sr_lite.condition(ledger, owner["id"])
    if cond in sr_lite.OUT:
        raise RulesRefusal(f"{owner['name']} is {cond} and can't hand anything over.")
    thief = _hijacker(ledger, m, c)
    if thief:
        raise RulesRefusal(f"{thief['name']} has hijacked {m['name']} - {owner['name']} has to win it back first (an "
                           "opposed Hacking test).")


def lend(ledger: Ledger, turn: int | None, machine_id: str, to: str) -> str:
    """The owner gives `to` the keys and the controls stay where they are - for a crewmate whose player isn't here to
    take them this turn: next turn they can, on their own word. (SR5 p. 240 Invite Mark: the owner's offer, no test.)"""
    m = ledger.require(machine_id)
    c = ledger.require(to)
    if m["kind"] not in sr_lite.MACHINES or c["kind"] not in ("pc", "npc"):
        raise LedgerError("Keys go from a drone or vehicle's owner to a person.")
    owner = ledger.get(m["props"].get("owner") or "")
    keys = list(m["props"].get("delegates") or [])
    if owner and c["id"] == owner["id"]:
        return f"[GEAR] {m['name']}: it's {c['name']}'s own"
    if c["id"] in keys:
        return f"[GEAR] {m['name']}: {c['name']} already holds the keys"
    _lendable(ledger, m, owner, c)
    ledger.update_entity(m["id"], props={**m["props"], "delegates": keys + [c["id"]]})
    ledger.log(turn, "grant", m["id"], {"owner": owner["id"], "to": c["id"], "controls": False})
    return (f"[GEAR] {m['name']}: {owner['name']} lends {c['name']} the keys (they stand until {owner['name']} takes "
            "the controls back)")


def set_control(ledger: Ledger, turn: int | None, machine_id: str, controller: str | None, mode: str = "remote",
                hacked: set | None = None, handed_over: bool = False) -> str:
    """Hand a machine to a driver, or back to its own Pilot ('autonomous' - the keys stay lent). Who may take it:
    the owner (taking the controls back takes the keys back too); someone holding the owner's keys; whoever is already
    driving it (a change of mode - live: a hijacker who'd seized it in a host couldn't switch to jumped next turn); or
    someone who won an opposed hack against it this turn (hacked: (actor, machine) pairs). handed_over: the owner lends
    the keys now (_lendable) and the controller takes them - unless the controller has a claim already (the keys, a won
    hack, the controls), which the flag doesn't put through the lending checks. Nobody takes it from under a rigger
    jumped into it, short of a won hack (SR5 p. 241: not until they vacate; R&G p. 265: the jumped-in rigger overrides
    remote control)."""
    m = ledger.require(machine_id)
    if m["kind"] not in sr_lite.MACHINES:
        raise LedgerError(f"{m['name']} isn't a drone or vehicle.")
    if sr_lite.arriving(m):                               # bought, still with the courier (shops.py)
        raise LedgerError(f"{m['name']} is {sr_lite.transit_note(ledger, m)} - nobody can run it yet.")
    props = dict(m["props"])
    if not controller or controller.lower() in ("autonomous", "none", "auto"):
        props.update(controller=None, control=None)
        ledger.update_entity(m["id"], props=props)
        ledger.log(turn, "control", m["id"], {"controller": None})
        return f"[GEAR] {m['name']}: running on its own Pilot now"
    c = ledger.require(controller)
    if c["kind"] not in ("pc", "npc"):
        raise LedgerError("Only a person can drive a drone or vehicle.")
    if sr_lite.condition(ledger, c["id"]) in sr_lite.OUT:
        raise LedgerError(f"{c['name']} is {sr_lite.condition(ledger, c['id'])} and can't drive anything.")
    mode = mode if mode in MODES else "remote"
    if mode == "jumped" and not control_rig(ledger, c["id"]):
        raise LedgerError(f"{c['name']} has no control rig to jump in with - use remote control instead.")
    owner = ledger.get(props.get("owner") or "")
    keys = list(props.get("delegates") or [])
    cur = ledger.get(props.get("controller") or "")
    won = (c["id"], m["id"]) in (hacked or set())
    if (cur and cur["id"] != c["id"] and props.get("control") == "jumped" and not won
            and sr_lite.condition(ledger, cur["id"]) not in sr_lite.OUT):
        raise RulesRefusal(f"{cur['name']} is jumped into {m['name']} - nobody else takes the controls until they jump "
                           "out (SR5 p. 241), short of beating them with an opposed Hacking test.")
    note, grant, revoked = "", False, []
    driving = bool(cur and cur["id"] == c["id"])
    if owner and c["id"] == owner["id"]:
        revoked, keys = keys, []                          # the owner takes the controls back: the keys come back too
    elif handed_over and c["id"] not in keys and not won and not driving:
        # (a won hack or the controls already in hand is a claim of its own - the flag on top of it is redundant, not
        # a lend to check: review, Ghost out-hacked Kaz's Doberman and the flag got "only by a won Hacking test")
        _lendable(ledger, m, owner, c)
        keys.append(c["id"])
        grant = True
    elif not (c["id"] in keys or driving or won):
        raise RulesRefusal(_no_control(m, c, owner))
    elif c["id"] in keys and not won:                     # (the keys don't beat a hijacker - winning it back does)
        thief = _hijacker(ledger, m, c)
        if thief:
            raise RulesRefusal(f"{thief['name']} has hijacked {m['name']} - win it back with an opposed Hacking test "
                               "first.")
    if mode == "jumped":                                  # a rigger rides one machine at a time (SR5 p. 266)
        for other in _machines(ledger):
            op = other["props"]
            if other["id"] != m["id"] and op.get("controller") == c["id"] and op.get("control") == "jumped":
                ledger.update_entity(other["id"], props={**op, "control": "remote"})
                note += f" ({other['name']} drops back to remote control)"
    props.update(controller=c["id"], control=mode, delegates=keys)
    ledger.update_entity(m["id"], props=props)
    ledger.log(turn, "control", m["id"], {"controller": c["id"], "mode": mode})
    if grant:
        ledger.log(turn, "grant", m["id"], {"owner": owner["id"], "to": c["id"], "controls": True})
        note = f" ({owner['name']} hands over the keys)" + note
    if revoked:
        ledger.log(turn, "revoke", m["id"], {"owner": owner["id"], "from": revoked})
        note = f" (the keys come back from {_names(ledger, revoked)})" + note
    how = "jumped in - their body goes limp, and they feel its hits" if mode == "jumped" else "remote control"
    return f"[GEAR] {m['name']}: {c['name']} takes the controls ({how}){note}\n{compare(ledger, m['id'])}"


def control_rig(ledger: Ledger, eid: str) -> int:
    return max([int(i["props"].get("control_rig", 0)) for i in sr_lite.in_hand(ledger, eid)] or [0])


# ── What it rolls: a driver against its own Pilot ───────────────────────
def does(ledger: Ledger, m: dict) -> list[tuple[str, str]]:
    """The jobs a machine's cards show: shooting only with a gun aboard (and here, not still with the courier)."""
    armed = bool(_weapons(ledger, m, here_only=True))
    return [(verb, skill) for verb, skill in DOES if armed or skill != "firearms"]


def pools(ledger: Ledger, m: dict, driver: str | None = None, mode: str = "remote") -> list[tuple[str, int]]:
    """[(job, dice)] - on its own Pilot (driver None), or with driver at the controls in mode: sr_lite.machine_pool
    itself, so the cards say what a roll would (the -2 for each other machine they run, its damage)."""
    ent = {**m, "props": {**m["props"], "controller": driver, "control": mode if driver else None}}
    return [(verb, sr_lite.machine_pool(ledger, ent, skill)[0]) for verb, skill in does(ledger, m)]


def compare(ledger: Ledger, machine_id: str) -> str:
    """The control card's second line: the driver's dice against the machine's own Pilot, job by job. Live T132: the
    Fly-Spy went to Filament's remote control (untrained, 6 dice) just before a stealth test its autopilot rolled 7 for;
    by T188 his Roto-drone drove and dodged worse under him than on its own, and nothing ever said so."""
    m = ledger.require(machine_id)
    drv = ledger.get(m["props"].get("controller") or "")
    if not drv:
        return ""
    mode = m["props"].get("control") or "remote"
    theirs, own = pools(ledger, m, drv["id"], mode), dict(pools(ledger, m))
    line = (f"  Pools  {drv['name']} ({'jumped in' if mode == 'jumped' else 'remote'}) vs its own Pilot: "
            + " · ".join(f"{verb} {n} vs {own[verb]}" for verb, n in theirs))
    worse = [verb for verb, n in theirs if own[verb] > n]
    if worse:
        line += f" - on its own Pilot it {' and '.join(worse)} better"
    return line


# ── Where it is: with whoever runs it ───────────────────────────────────
def beside(ledger: Ledger, machine_id: str, driver_id: str, driver_at: int | None = None) -> bool:
    """Is the machine where its driver is - in their scene (driver_at: the scene they're in or leaving), or never
    placed anywhere (a drone just bought rides along)? Not one the GM took out of a scene with scene_presence leave:
    leave drops the roster row, and reading 'no row' as 'never placed' sent a Fly-Spy the story left on overwatch
    after its rigger at the next cut, still costing him -2 on every other drone (review, the T188 bug again)."""
    at = ledger.scene_of(machine_id)
    if at is None:
        return not ledger.ever_placed(machine_id)
    return at == (ledger.scene_of(driver_id) if driver_at is None else driver_at)


def followers(ledger: Ledger, ids, scene_id: int | None) -> list[str]:
    """Machines that go where their driver goes: remote-run or jumped into by someone in ids, not destroyed, and with
    them (beside) - in the scene they're leaving, or never placed anywhere. Live: Filament's Fly-Spy sat in S12's
    roster from T132 on, under his remote control, while the story carried it with him to S13, S14 and S19 - and the -2
    for running it hung on every drone he drove after. (A drone left behind on purpose - in another scene, or sent out
    of this one with scene_presence leave - stays where it is.)"""
    movers = {i: ledger.scene_of(i) for i in ids}
    out = []
    for m in _machines(ledger):
        p = m["props"]
        if m["id"] in movers or p.get("controller") not in movers or p.get("control") not in MODES:
            continue
        if sr_lite.condition(ledger, m["id"]) in sr_lite.OUT:
            continue
        if ((scene_id is None or ledger.scene_of(m["id"]) != scene_id)
                and beside(ledger, m["id"], p["controller"], movers[p["controller"]])):
            out.append(m["id"])
    return out


# ── Crashes and rams (SR5 p. 201-203) ───────────────────────────────────
# Live T164/T165/T171/T174: riders hit Magic's barrier and the GM picked the damage - 10P, 8P and 9P where the book's
# crash does the bike's Body (5: about 4 boxes on a ganger), 3S on Garvey, nothing at all for five bikes 'at speed'.
TURN_SECONDS = 3                     # a Combat Turn is 3 seconds (p. 160): the ram table's speeds are meters a turn
RAM_TABLE = ((10, 0.5, "Body / 2"), (50, 1, "Body"), (200, 2, "Body x 2"), (300, 3, "Body x 3"), (500, 5, "Body x 5"),
             (None, 10, "Body x 10"))                 # p. 203: (top of the speed band in m a Combat Turn, x Body)
CRASH_AP = -6                        # people resist a crash or a ram with Body + Armor at -6 AP (p. 201, 203)
KEEP_CONTROL = (2, 3)                # after a ram, Piloting + Reaction to keep control: the rammer (2), the rammed (3)


def meters_a_turn(kph: int) -> int:
    return max(1, round(int(kph) * 1000 / 3600 * TURN_SECONDS))


def ram_dv(body: int, kph: int) -> tuple[int, str, int]:
    """(DV, the table's line, m a Combat Turn) for a ram at kph: 64 km/h is 53 m a turn - Body x 2."""
    mpt = meters_a_turn(kph)
    for top, mult, label in RAM_TABLE:
        if top is None or mpt <= top:
            return max(1, ceil(body * mult)), label, mpt
    raise AssertionError("unreachable")


RAMMED = ("pc", "npc", "spirit") + sr_lite.MACHINES   # what a ram's into_id is: someone, or a drone or vehicle (p. 203)
NOT_RAMMED = ("a wall, a pole, a dumpster or anything else that's no one is a crash: leave out into_id (barrier_of for "
              "a magician's Physical Barrier)")


def _person(ledger: Ledger, ref: str, what: str) -> dict:
    ent = ledger.find(ref)
    if ent is None:
        raise LedgerError(f"No one on file as '{ref}' - introduce {what} first (unnamed riders too; a group of riders "
                          "may be one entity, 'Crows riders').")
    return ent


def ram_roller(ledger: Ledger, v: dict | None, driver: str | None) -> dict | None:
    """Whose dice a ram rolls, and whose Edge rides it: the driver named, else whoever runs the machine remotely or is
    jumped into it (machine_pool rolls their skill) - None for one on its own Pilot, which has no Edge. Review: a
    Roto-drone's ram rolled Ghost's Piloting + Logic and spent his action, and the roll guard never counted it his."""
    if driver:
        return ledger.require(driver)
    p = (v or {}).get("props") or {}
    cur = ledger.get(p.get("controller") or "") if p.get("control") in MODES else None
    return cur if cur and sr_lite.condition(ledger, cur["id"]) not in sr_lite.OUT else None


def _ram_pool(ledger: Ledger, v: dict | None, actor: dict, driver: str | None) -> tuple[list, str]:
    """(parts, how) for a ram's roll (p. 203: Vehicle skill + Reaction): a driver at the wheel rolls their Piloting +
    Reaction; a machine rolls its own pool - through whoever runs it (machine_pool: their skill + Logic remote, +
    Reaction + rig jumped in, -2 for each other machine), else Pilot + Maneuvering. A driver_id who is the one running
    the drone rolls through it, not as if they sat aboard."""
    p = (v or {}).get("props") or {}
    if driver and not (v and p.get("controller") == driver and p.get("control") in MODES):
        return sr_lite.build_pool(ledger, actor["id"], "piloting")[1], "Piloting + Reaction"
    return sr_lite.machine_pool(ledger, v, "piloting")[1], ("its driver's Piloting" if p.get("controller")
                                                           else "Pilot + Maneuvering")


def check_crash(ledger: Ledger, vehicle: str | None = None, model_key: str | None = None, riders=(), kph: int = 0,
                into: str | None = None, barrier_of: str | None = None, driver: str | None = None,
                which: str | None = None, edge=None, defense_edge=None, soak_edge=None) -> dict:
    """Everything a crash needs settled before anything happens (a fight opening, an Action Phase, Edge): raises
    LedgerError on what can't be. which: the wall, when barrier_of holds more than one (magic.barrier asks which).
    edge: the ram roll's (the driver's player); defense_edge / soak_edge: the rammed one's player's, on the dodge and
    the soak. A ram rolls on into, or on barrier_of with a driver - ramming the wall on purpose (p. 197).
    Returns {v, name, body, aboard [(ent, edge)], target, caster, actor, wall, ram, roller}."""
    if vehicle:
        v = ledger.require(vehicle)
        if v["kind"] not in sr_lite.MACHINES:
            raise LedgerError(f"{v['name']} isn't a drone or vehicle.")
        if sr_lite.arriving(v):                       # bought, still with the courier - like set_control (§7f)
            raise LedgerError(f"{v['name']} is {sr_lite.transit_note(ledger, v)} - nobody can run it yet.")
        body, name = int(ledger.stat(v["id"], "body", 1)), v["name"]
    else:
        key = model_key if model_key in MODELS else model(model_key)
        if not key:
            raise LedgerError(f"What crashed? vehicle_id (a drone or vehicle on file), or model for one that isn't "
                              f"({', '.join(MODELS)}).")
        v, body, name = None, int(MODELS[key]["stats"]["body"]), MODELS[key]["name"]
    aboard = []
    for r in riders or []:
        rid, soak = (r.get("id"), r.get("edge")) if isinstance(r, dict) else (r, None)
        ent = _person(ledger, str(rid or ""), "the rider")
        if ent["kind"] not in ("pc", "npc"):
            raise LedgerError(f"{ent['name']} isn't a person - riders are the people aboard.")
        aboard.append((ent, soak))
    if not v and aboard:                              # (a bike not on file: whose it is, by its first rider)
        name = f"{aboard[0][0]['name']}'s {name}"
    if into and barrier_of:
        raise LedgerError("One thing is hit: into_id (a person, drone or vehicle) or barrier_of, not both.")
    target = ledger.find(into) if into else None
    if into and target is None:
        raise LedgerError(f"No one on file as '{into}' - introduce whoever is rammed first (a person, drone or "
                          f"vehicle); {NOT_RAMMED}.")
    # (review: the Lucky Shot, a dumpster and a host were 'rammed' - they took the boxes, and the bar stood as a foe)
    if target and target["kind"] not in RAMMED:
        raise LedgerError(f"{target['name']} isn't a person, drone or vehicle - {NOT_RAMMED}.")
    if target and sr_lite.arriving(target):
        raise LedgerError(f"{target['name']} is {sr_lite.transit_note(ledger, target)} - it isn't here to be hit.")
    if target and (v and target["id"] == v["id"] or any(target["id"] == e["id"] for e, _ in aboard)):
        raise LedgerError(f"{target['name']} is aboard - a ram hits something else.")
    caster = ledger.require(barrier_of) if barrier_of else None
    wall = magic.barrier(ledger, caster["id"], which) if caster else None
    if caster and not wall:
        raise LedgerError(f"{caster['name']} isn't holding up a Physical Barrier.")
    if (target or caster) and int(kph or 0) <= 0:
        raise LedgerError("How fast was it going? speed_kph sets a ram's damage (SR5 p. 203).")
    if (target or caster) and v and sr_lite.condition(ledger, v["id"]) == "destroyed":
        raise LedgerError(f"{v['name']} is destroyed - it can't ram anything.")
    actor = ledger.require(driver) if driver else v
    if target and not actor:
        raise LedgerError("Who's driving? driver_id - a ram is the driver's Piloting + Reaction (SR5 p. 203).")
    ram = bool(target or (caster and driver))           # (into a wall on purpose: an unopposed attack, p. 197)
    if ram and sr_lite.condition(ledger, actor["id"]) in sr_lite.OUT:
        raise LedgerError(f"{actor['name']} is {sr_lite.condition(ledger, actor['id'])} - nobody's driving.")
    roller = ram_roller(ledger, v, actor["id"] if driver else None) if ram else None
    _check_crash_edge(ledger, name, aboard, target, ram, roller, edge, defense_edge, soak_edge)
    return {"v": v, "name": name, "body": body, "aboard": aboard, "target": target, "caster": caster, "actor": actor,
            "wall": wall, "ram": ram, "roller": roller}


def _check_crash_edge(ledger: Ledger, name: str, aboard: list, target: dict | None, ram: bool, roller: dict | None,
                      edge, defense_edge, soak_edge) -> None:
    """Every Edge field on a crash names a roll that happens - before any dice. Review: the driver's 'pushing my Edge
    on the ram' was steered into a rider's soak field that a ram never rolls (riders aren't hit), and a rammed PC's
    dodge Edge had nowhere to go; both went out unspent with the card silent."""
    for e in [edge, defense_edge, soak_edge] + [e for _, e in aboard]:
        sr_lite.edge_use(e)                           # (a mode it doesn't know raises here, not mid-crash)
    if sr_lite.edge_use(edge):
        if not ram:
            raise LedgerError("edge is the ram's roll (into_id, or ramming a barrier on purpose with driver_id) - a "
                              "rider's Edge on their soak goes in riders.")
        if not roller:
            raise LedgerError(f"{name} runs on its own Pilot - a machine has no Edge to spend on its ram.")
        sr_lite.check_push(ledger, roller["id"], edge)
    if (sr_lite.edge_use(defense_edge) or sr_lite.edge_use(soak_edge)) and not target:
        raise LedgerError("defense_edge and soak_edge are the rammed one's (into_id), on their dodge and their soak.")
    if target and any(sr_lite.edge_use(e) for _, e in aboard):
        raise LedgerError("In a ram the riders aren't hit - a rider's soak Edge rides nothing. The driver's Edge on "
                          "the ram roll is edge; the rammed one's is defense_edge / soak_edge.")


def _soak(ledger: Ledger, dice, turn: int | None, ent: dict, dv: int, ap: int, edge, head: str,
          lines: list, results: list) -> None:
    """One person or machine resists crash or ram damage, with its card lines. A crash's Stun rule is the book's: Stun
    when the vehicle's Body is under the character's armor (p. 202) - armor at this table's scale, times
    sr_lite.ARMOR_STUN, the same yardstick as any light hit."""
    dtype, why = "physical", ""
    if ent["kind"] not in sr_lite.MACHINES:
        armor, label = sr_lite.best_armor(ledger, ent["id"])
        if armor and dv < armor * sr_lite.ARMOR_STUN:
            what = (label or "armor").split("'s ", 1)[-1]
            dtype, why = "stun", f" - under what their {what} ({armor}) stops: Stun"
    lines.append(f"  {ent['name']}: {head.format(t=dtype[0].upper())}{why}")
    boxes, soak = sr_lite.resist_damage(ledger, dice, turn, ent["id"], dv, dtype, ap, edge=edge)
    lines += ["  " + s for s in soak]
    results.append({"id": ent["id"], "boxes": boxes, "status": sr_lite.condition(ledger, ent["id"])})


def crash(ledger: Ledger, dice, turn: int | None, vehicle: str | None = None, model_key: str | None = None,
          riders=(), kph: int = 0, into: str | None = None, barrier_of: str | None = None, driver: str | None = None,
          reason: str = "", defend=None, which: str | None = None, edge=None, defense_edge=None,
          soak_edge=None) -> dict:
    """A drone or vehicle crashes or rams (SR5 p. 201-203), the GM saying only what hit what, how fast, who was aboard:
      crash    (nothing hit on file: a wall, a pole, the road) the vehicle and everyone aboard resist its Body at -6 AP -
               Stun for whoever's armor is over the Body (p. 201-202)
      into     a ram on a person, drone or vehicle: the driver's Piloting + Reaction (or the machine's own pool) against
               the target's defense, Reaction + Intuition; on a hit the target resists the ram table's multiple of the
               Body (by speed) + the net hits - a person at -6 AP - and the rammer half the table's damage, rounded up
               (p. 203). Its riders aren't hit; keeping control after is the drivers' Piloting test (2 / 3)
      barrier_of  the magician whose Physical Barrier it hits: a wall can't dodge (p. 197), so it resists the ram's
               damage with Armor + Structure - nothing gets through if the damage doesn't beat its Armor - and the boxes
               come off its Structure: at 0 it collapses and the spell ends (p. 294, magic.damage_barrier). With a
               driver it's rammed on purpose - their roll, unopposed, adds its hits to the damage, and only a critical
               glitch misses the wall (p. 197); riders who couldn't stop roll nothing. The rammer takes half; if the
               wall held, the vehicle stopped dead - a crash for everyone aboard. which: the wall, when the magician
               holds more than one - its number or who it's on (magic.barrier); the others are untouched.
    vehicle: a machine on file (it takes its own damage), or model_key for one that isn't (a ganger's bike). riders:
    [{id, edge}] or ids, everyone aboard, on file. defend(target, melee) -> (parts, notes): what the fight adds to the
    rammed one's defense. edge: the ram roll's (ram_roller's player); defense_edge / soak_edge: the rammed one's.
    Damage is capped at sr_lite.MAX_DV like every hit. Returns {card, results [{id, boxes, status}], hit (the ram's,
    else None), broken (the barrier's, else None), dv}."""
    c = check_crash(ledger, vehicle, model_key, riders, kph, into, barrier_of, driver, which, edge, defense_edge,
                    soak_edge)
    v, name, body, aboard, target, caster = c["v"], c["name"], c["body"], c["aboard"], c["target"], c["caster"]
    actor, roller, use = c["actor"], c["roller"], sr_lite.edge_use(edge)
    results, hit, broken = [], None, None
    crash_dv = min(sr_lite.MAX_DV, body)
    why = [f"  Why    {reason}"] if reason else []

    def everyone_crashes(lines: list) -> None:          # (the soak lines show the AP at this table's armor scale)
        if v and sr_lite.condition(ledger, v["id"]) != "destroyed" and not target and not caster:
            _soak(ledger, dice, turn, v, crash_dv, CRASH_AP, None, f"crash {crash_dv}{{t}}", lines, results)
        for ent, soak in aboard:
            _soak(ledger, dice, turn, ent, crash_dv, CRASH_AP, soak, f"crash {crash_dv}{{t}}", lines, results)

    if not target and not caster:                     # a crash: Body to the vehicle and everyone aboard (p. 201)
        lines = [f"[DAMAGE] {name} crashes - its Body ({body}) to it and everyone aboard, at -6 AP (SR5 p. 201)"] + why
        everyone_crashes(lines)
        dv = crash_dv
    elif caster:                                      # into a Physical Barrier: it can't dodge (p. 197)
        b = c["wall"]                                  # (the one wall it hit: live review, every ram took the first)
        dv0, label, mpt = ram_dv(body, kph)
        dv = min(sr_lite.MAX_DV, dv0)
        lines = [f"[DAMAGE] {name} hits {caster['name']}'s {magic.barrier_name(ledger, caster['id'], b)} at {kph} "
                 f"km/h ({mpt} m a Combat Turn) - {label} = {dv} (SR5 p. 203)"] + why
        if c["ram"]:                                  # on purpose: the attack test only adds hits (p. 197)
            hits = _wall_ram(ledger, dice, turn, c, b, dv0, use, kph, reason, lines)
            if hits is None:                          # a critical glitch: the one way to miss a wall
                lines.append(f"  It misses the wall altogether - keeping control is the driver's Piloting + Reaction "
                             f"({KEEP_CONTROL[0]}) (p. 203)")
                return _logged(ledger, turn, c, kph, dv0, results, lines, None, None)
            dv = min(sr_lite.MAX_DV, dv0 + hits)
            if hits:
                lines.append(f"  Damage {label} {dv0}+{hits} = {dv}")
        if dv <= b["armor"]:
            broken = False
            lines.append(f"  Barrier {dv} doesn't beat its Armor {b['armor']} - not a scratch on it (p. 197)")
        else:
            r = sr_lite.roll(dice, b["armor"] + b["hits"])
            boxes = max(0, dv - r.hits)
            lines.append(f"  Barrier Armor {b['armor']} + Structure {b['hits']} = {r.pool}d6 -> {r.faces()} -> "
                         f"{r.hits} hits")
            res = magic.damage_barrier(ledger, turn, caster["id"], boxes, f"{name} rammed it", str(b["n"]))
            broken = res["broken"]
            lines.append(res["line"])
        half = ceil(dv0 / 2)
        if v and sr_lite.condition(ledger, v["id"]) != "destroyed":
            _soak(ledger, dice, turn, v, min(sr_lite.MAX_DV, half), 0, None,
                  f"rams it - half the ram's damage, {min(sr_lite.MAX_DV, half)}{{t}} (p. 203)", lines, results)
        if broken:
            lines.append(f"  {name} tears through - keeping control is the driver's Piloting + Reaction "
                         f"({KEEP_CONTROL[0]}) (p. 203)")
        else:
            lines.append(f"  The wall holds: {name} stops dead - a crash for everyone aboard: its Body ({body}), "
                         "AP -6 (p. 201)")
            everyone_crashes(lines)
    else:                                             # a ram on someone: an opposed test, like a melee attack (p. 203)
        parts, how = _ram_pool(ledger, v, actor, actor["id"] if driver else None)
        extra = sr_lite._opposition(ledger, target["id"], actor["id"])      # an NPC driver at a PC
        if extra:
            parts = parts + [(f"Table ({sr_lite.table_difficulty(ledger)['level']})", extra)]
        explode = sr_lite.push_edge(ledger, turn, roller["id"], parts, use, on="ram")[0] if roller else False
        n = max(0, sum(x for _, x in parts))
        dv0, label, mpt = ram_dv(body, kph)
        lines = [f"[ROLL] {name} rams {target['name']} at {kph} km/h ({mpt} m a Combat Turn) - {label}"
                 + (f", {actor['name']} driving" if driver else "") + f" ({how})"] + why
        ra0 = sr_lite.roll(dice, n, explode)
        level = sr_lite.table_difficulty(ledger)["level"]
        d_use = sr_lite.edge_use(defense_edge)
        d_parts, rd0, d_note, d_notes = sr_lite._defense(ledger, dice, turn, actor, target,
                                                         {"defend": defend, "melee": True, "d_use": d_use}, level)
        # Second chances as attack's: the rammer's while it would miss, the dodge's while the ram still lands
        ra, a_line = (sr_lite.second_chance(ledger, dice, turn, roller["id"], ra0, use, ra0.hits <= rd0.hits, on="ram")
                      if roller else (ra0, None))
        hit_now = ra.hits > rd0.hits
        rd, d_line = sr_lite.second_chance(ledger, dice, turn, target["id"], rd0, d_use, hit_now, useful=hit_now,
                                           on="dodge")
        lines.append(f"  Ram    {sr_lite.fmt_parts(parts)} = {n}d6 -> {ra0.faces()} -> {ra0.verdict()}")
        lines += [a_line] if a_line else []
        lines.append(f"  Defend {sr_lite.fmt_parts(d_parts)} = {rd0.pool}d6 -> {rd0.faces()} -> {rd0.hits} "
                     f"hit{'s' * (rd0.hits != 1)}")
        lines += [x for x in [d_note, d_line] if x] + ([f"  [{'; '.join(d_notes)}]"] if d_notes else [])
        hit, net = ra.hits > rd.hits, ra.hits - rd.hits
        dv = min(sr_lite.MAX_DV, dv0 + max(0, net))
        if hit:
            person = target["kind"] not in sr_lite.MACHINES
            lines.append(f"  HIT (net {net}). Damage {label} {dv0}+{net} = {dv}P" + (", AP -6" if person else ""))
            boxes, soak = sr_lite.resist_damage(ledger, dice, turn, target["id"], dv, "physical",
                                                CRASH_AP if person else 0, edge=soak_edge)
            lines += soak
            results.append({"id": target["id"], "boxes": boxes, "status": sr_lite.condition(ledger, target["id"])})
            half = min(sr_lite.MAX_DV, ceil(dv0 / 2))
            if v:
                _soak(ledger, dice, turn, v, half, 0, None, f"half the ram's damage, {half}{{t}} (p. 203)", lines,
                      results)
            lines.append(f"  Keeping control: Piloting + Reaction ({KEEP_CONTROL[0]}) for the rammer, "
                         f"({KEEP_CONTROL[1]}) for a rammed driver - request_test if it matters (p. 203)")
        else:
            lines.append("  MISS" + (" (no hits - with no defense it's a Success Test, SR5 p. 189)" if not rd.dice
                                     else " (ties go to the defender)" if net == 0 else ""))
        sr_lite._record(ledger, turn, actor["id"], {"kind": "ram", "target": target["id"], "vehicle": v and v["id"],
                                                    "kph": kph, "reason": reason}, ra, hit, net)
        ledger.log(turn, "attack", actor["id"], {"target": target["id"], "hit": hit, "ram": True,
                                                 "boxes": next((r["boxes"] for r in results
                                                                if r["id"] == target["id"]), 0),
                                                 "target_status": sr_lite.condition(ledger, target["id"])})
    return _logged(ledger, turn, c, kph, dv, results, lines, hit, broken)


def _wall_ram(ledger: Ledger, dice, turn: int | None, c: dict, b: dict, dv0: int, use: str | None, kph: int,
              reason: str, lines: list) -> int | None:
    """A barrier rammed on purpose (p. 197, Destroying Barriers: 'resolve the attack normally'): the driver's ram roll
    (_ram_pool) unopposed - a wall can't dodge - its hits added to the damage; a critical glitch is the only miss
    (None). Review: the van floored into a 12-hit wall rolled nothing and did its bare Body x band - not a scratch,
    where 12 and a hit beats Armor 12. The ram's Edge goes on it like any attack's: pushed before, a second chance
    while the hit would still fall at the Armor (if_short) or add damage (reroll)."""
    actor, roller, v = c["actor"], c["roller"], c["v"]
    parts, how = _ram_pool(ledger, v, actor, actor["id"])
    explode = sr_lite.push_edge(ledger, turn, roller["id"], parts, use, on="ram")[0] if roller else False
    n = max(0, sum(x for _, x in parts))
    r0 = sr_lite.roll(dice, n, explode)
    r, e_line = (sr_lite.second_chance(ledger, dice, turn, roller["id"], r0, use, dv0 + r0.hits <= b["armor"],
                                       useful=dv0 + r0.hits < sr_lite.MAX_DV, on="ram") if roller else (r0, None))
    lines.append(f"  Ram    {sr_lite.fmt_parts(parts)} = {n}d6 -> {r0.faces()} -> {r0.verdict()} ({actor['name']}'s "
                 f"{how}, on purpose: unopposed, each hit adds to the damage - p. 197)")
    lines += [e_line] if e_line else []
    missed = r.crit_glitch
    sr_lite._record(ledger, turn, actor["id"], {"kind": "ram", "barrier_of": c["caster"]["id"], "wall": b["n"],
                                                "vehicle": v and v["id"], "kph": kph, "reason": reason},
                    r, not missed, 0 if missed else r.hits)
    return None if missed else r.hits


def _logged(ledger: Ledger, turn: int | None, c: dict, kph: int, dv: int, results: list, lines: list, hit,
            broken) -> dict:
    """The crash event on the ledger, and crash()'s result."""
    v, target, caster = c["v"], c["target"], c["caster"]
    ledger.log(turn, "crash", v["id"] if v else None, {
        "vehicle": c["name"], "kph": kph, "into": target and target["id"], "barrier_of": caster and caster["id"],
        "riders": [e["id"] for e, _ in c["aboard"]], "dv": dv, "results": results}
        | ({"broken": broken} if broken is not None else {})
        | ({"wall": c["wall"]["n"], "wall_on": c["wall"]["target"]} if c["wall"] else {}))
    return {"card": "\n".join(lines), "results": results, "hit": hit, "broken": broken, "dv": dv}
