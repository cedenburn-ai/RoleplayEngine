"""Host maps (DESIGN.md §7h): a host is a small network of nodes you move through, like the old Genesis Shadowrun.

The engine draws every map - the GM never does - from the host's rating, the same way every time (seeded by the
host's id): an Entry, hubs that route on, datastores (files), the building's systems (cameras, door locks, alarms,
elevators), Comms (calls out of the building) and the Core (the host itself). A host is tied to the building it
runs (props.site, the location the decker jacked in from), so its device nodes ARE that building's cameras and
locks: looping them shows up for the GM as the building's state, in the Matrix or out of it.

Every node has a security color - it's both how hard it is to crack and the login level that opens it:
    blue    open: no security at all - anyone in the host walks in
    green   light security (host rating - 2) - a user login opens it
    orange  guarded (the host's rating) - a user login opens it
    red     secure (host rating + 2) - only an admin login opens it
A decker without a login cracks nodes one at a time; moving through what's open to them is free. The decker sees the
nodes they've been to and the ones next to them; a search shows more. IC lives in nodes (Killer in the records, Black
IC at the core): it sleeps until something wakes it, then hunts.

Map state lives on the host (props.nodes, each IC's node/home); what a decker knows on the decker
(props.matrix: node, cleared, creds, seen, scanned - per host).
"""
from __future__ import annotations

import random
from collections import deque

from ..ledger import Ledger
from . import sr_lite

COLORS = ("blue", "green", "orange", "red")
NEED = {"blue": None, "green": "user", "orange": "user", "red": "admin"}
OFFSET = {"blue": 0, "green": -2, "orange": 0, "red": 2}
COLOR_TEXT = {"blue": "open", "green": "light security", "orange": "guarded", "red": "secure, admin only"}
LEVELS = ("outsider", "user", "admin")
SYSTEMS = (("cameras", "Cameras", ("camera", "cctv", "feed", "surveillance", "monitor")),
           ("locks", "Door locks", ("lock", "door", "maglock", "gate", "shutter", "keypad", "vault")),
           ("alarms", "Alarms", ("alarm", "siren", "sensor", "motion", "sprinkler", "fire")),
           ("elevators", "Elevators", ("elevator", "lift")))
KIND_TEXT = {"entry": "where you come in", "hub": "a junction that routes on", "datastore": "files",
             "devices": "the building's {system}", "comms": "the building's calls and messages",
             "core": "the host itself - take it and you're admin over everything"}


# ── the map ─────────────────────────────────────────────────────────────
def generate(seed: str, rating: int) -> list[dict]:
    """A host's nodes by its rating: 6 for a corner store, 10 for a hospital ward's host."""
    rnd = random.Random(f"{seed}:{rating}")
    nodes: list[dict] = []

    def add(kind, name, color, *near):
        n = {"id": f"n{len(nodes) + 1}", "kind": kind, "name": name, "color": color, "near": [], "things": [],
             "state": None}
        nodes.append(n)
        for o in near:
            n["near"].append(o["id"])
            o["near"].append(n["id"])
        return n

    low, high = rating <= 3, rating >= 7
    prev = add("entry", "Entry", "blue")                     # (where you log in: always open)
    hubs = []
    for i in range(1 if low else 2 if rating <= 7 else 3):
        prev = add("hub", f"Hub {'ABC'[i]}", "green" if low or (i == 0 and not high) else "orange", prev)
        hubs.append(prev)
    for key, name, _ in SYSTEMS[:2 if rating <= 4 else 3 if rating <= 7 else 4]:
        color = ("blue" if low and key == "cameras" and rnd.random() < 0.5 else "green" if rating <= 4 else "orange")
        add("devices", name, color, rnd.choice(hubs))["system"] = key
    for i in range(1 if rating <= 4 else 2):
        add("datastore", "Records" if i == 0 else "Archive", "green" if low else "red" if high and i else "orange",
            hubs[len(hubs) // 2] if i == 0 else hubs[-1])
    if rating >= 3:
        add("comms", "Comms", "green" if rating <= 5 else "orange", hubs[0])
    add("core", "Core", "orange" if rating <= 2 else "red", hubs[-1])
    return nodes


def ic_home(kind: str, nodes: list[dict]) -> str:
    by = lambda k: [n for n in nodes if n["kind"] == k]          # noqa: E731
    hubs, ds, comms, core = by("hub"), by("datastore"), by("comms"), by("core")
    if kind == "patrol":
        return hubs[0]["id"]
    if kind == "track":
        return (comms or core)[0]["id"]
    if kind == "killer":
        return (ds or hubs)[0]["id"]
    if kind == "tar baby":
        return (hubs[-1] if len(hubs) > 1 else ds[-1] if len(ds) > 1 else core[0])["id"]
    return core[0]["id"]                                         # Black IC and anything else guards the core


def ensure(ledger: Ledger, hid: str, site: str | None = None) -> dict:
    """The host's props with a map: drawn on first use (old hosts get one the next time anyone touches them), IC
    given homes, and the host's files filed into its datastores."""
    from .matrix import ic_suite
    h = ledger.require(hid)
    hp = dict(h["props"])
    hr = int(hp.get("rating", 4))
    changed = False
    if not hp.get("nodes"):
        hp["nodes"] = generate(hid, hr)
        changed = True
    if "ic" not in hp:
        hp["ic"] = [{"type": t, "rating": hr, "damage": 0, "active": False} for t in ic_suite(hr)]
        hp.setdefault("alert", 0)
        changed = True
    for ic in hp["ic"]:
        if not ic.get("home") or not node(hp, ic["home"]):
            ic["home"] = ic_home(ic["type"], hp["nodes"])
            changed = True
        if not ic.get("node") or not node(hp, ic["node"]):
            ic["node"] = ic["home"]
            changed = True
    placed = {t for n in hp["nodes"] for t in n["things"]}
    for f in ledger.holdings(hid):                               # files the GM gave the host
        if f["id"] not in placed:
            _file_away(hp, ledger.get(f["id"]) or f)
            changed = True
    if site and not hp.get("site"):
        hp["site"] = site
        changed = True
    if changed:
        ledger.update_entity(hid, props=hp)
    return hp


def node(hp: dict, ref: str | None) -> dict | None:
    """A node by id ('n3'), name ('Records', 'hub b') or kind ('core', 'datastore')."""
    if not ref:
        return None
    want = str(ref).strip().lower()
    nodes = hp.get("nodes") or []
    for test in (lambda n: n["id"] == want, lambda n: n["name"].lower() == want, lambda n: n["kind"] == want,
                 lambda n: n.get("system") == want, lambda n: want in n["name"].lower() or n["name"].lower() in want):
        hit = next((n for n in nodes if test(n)), None)
        if hit:
            return hit
    return None


def entry(hp: dict) -> dict:
    return next(n for n in hp["nodes"] if n["kind"] == "entry")


def near(hp: dict, nid: str) -> list[dict]:
    n = node(hp, nid)
    return [node(hp, x) for x in (n["near"] if n else [])]


def path(hp: dict, a: str, b: str) -> list[str]:
    """The shortest route a -> b (node ids, both ends included)."""
    prev, q = {a: None}, deque([a])
    while q:
        cur = q.popleft()
        if cur == b:
            break
        for x in node(hp, cur)["near"]:
            if x not in prev:
                prev[x] = cur
                q.append(x)
    if b not in prev:
        return [a]
    out = [b]
    while prev[out[-1]]:
        out.append(prev[out[-1]])
    return out[::-1]


def rating(host_rating: int, color: str) -> int:
    return max(1, min(12, host_rating + OFFSET[color]))


# ── what the decker can get into ────────────────────────────────────────
def _per(st: dict, key: str, hid: str) -> list:
    return st.setdefault(key, {}).setdefault(hid, [])


def open_to(st: dict, hid: str, n: dict) -> str | None:
    """How a node is open to this decker: 'open' (blue), 'login' (their credentials reach it), 'cracked'; None if
    they'd have to crack it."""
    need = NEED[n["color"]]
    if need is None:
        return "open"
    if n["id"] in (st.get("cleared") or {}).get(hid, []):
        return "cracked"
    creds = (st.get("creds") or {}).get(hid)
    if creds and LEVELS.index(creds) >= LEVELS.index(need):
        return "login"
    return None


def clear(st: dict, hid: str, nid: str) -> None:
    got = _per(st, "cleared", hid)
    if nid not in got:
        got.append(nid)


def see(st: dict, hid: str, hp: dict, nids, scan: bool = False) -> None:
    """Mark nodes as seen (and their neighbors, for the ones they stood in); scan=True: their contents too."""
    seen, scanned = _per(st, "seen", hid), _per(st, "scanned", hid)
    for nid in nids:
        for x in [nid] + (node(hp, nid)["near"] if not scan else []):
            if x not in seen:
                seen.append(x)
        if scan and nid not in scanned:
            scanned.append(nid)


def walk(hp: dict, st: dict, hid: str, here: str, dest: str) -> tuple[list[str], dict | None]:
    """Move toward dest along the shortest route, through nodes open to them. Returns (the nodes walked, the node that
    stopped them - None if they got there)."""
    route = path(hp, here, dest)
    walked = [here]
    for nid in route[1:]:
        n = node(hp, nid)
        if not open_to(st, hid, n):
            return walked, n
        walked.append(nid)
    return walked, None


def within(hp: dict, nid: str, hops: int) -> list[str]:
    seen, frontier = {nid}, [nid]
    for _ in range(hops):
        frontier = [x for f in frontier for x in node(hp, f)["near"] if x not in seen]
        seen.update(frontier)
    return sorted(seen)


# ── things in nodes: files, and the building's devices ─────────────────
def where(hp: dict, eid: str) -> dict | None:
    return next((n for n in hp.get("nodes") or [] if eid in n["things"]), None)


def _file_away(hp: dict, ent: dict) -> dict:
    nodes = hp["nodes"]
    if ent.get("kind") in sr_lite.MACHINES or not (ent.get("props", {}).get("file") or ent.get("kind") == "item"):
        kind = "devices"
    else:
        name = (ent.get("name", "") + " " + ent.get("description", "")).lower()
        kind = "devices" if any(k in name for _, _, keys in SYSTEMS for k in keys) else "datastore"
    pool = [n for n in nodes if n["kind"] == kind] or [n for n in nodes if n["kind"] == "datastore"] or nodes
    if kind == "devices":
        name = (ent.get("name", "") + " " + ent.get("description", "")).lower()
        match = [n for n in pool if any(k in name for s, _, keys in SYSTEMS if s == n.get("system") for k in keys)]
        pool = match or pool
    spot = min(pool, key=lambda n: (len(n["things"]), n["id"]))
    spot["things"].append(ent["id"])
    return spot


def place(ledger: Ledger, hid: str, eid: str) -> dict:
    """Where a file or device sits in the host - filed somewhere sensible the first time anyone reaches for it."""
    hp = ensure(ledger, hid)
    spot = where(hp, eid)
    if spot:
        return spot
    spot = _file_away(hp, ledger.require(eid))
    ledger.update_entity(hid, props=hp)
    return spot


def site_lines(ledger: Ledger, location_id: str | None) -> list[str]:
    """The building's systems as the Matrix left them - for the GM, in the room or out of it."""
    if not location_id:
        return []
    out = []
    for h in ledger.entities(kind="host"):
        if h["props"].get("site") != location_id:
            continue
        for n in h["props"].get("nodes") or []:
            s = n.get("state")
            if s:
                who = (ledger.get(s.get("by") or "") or {}).get("name", "someone")
                out.append(f"{h['name']} - {n['name']}: {s.get('effect')} (by {who} in the Matrix, T{s.get('turn')})")
    return out


def describe(hp: dict, st: dict, hid: str, n: dict) -> str:
    how = open_to(st, hid, n)
    tag = {"open": "open", "login": "your login opens it", "cracked": "cracked", None: "locked"}[how]
    return f"{n['name']} ({n['color']}, {tag})"
