"""SR-lite: house rules on Shadowrun's shared d6-pool core (DESIGN.md §7).

The DM model chooses *what* to test and *why*; everything numeric happens here.
Every function validates against the ledger and raises LedgerError on a violation,
which the tool layer hands back to the model as an error result.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from math import ceil

from ..dice import Dice
from ..ledger import Ledger, LedgerError, RulesRefusal

ATTRIBUTES = ("body", "agility", "reaction", "strength", "willpower",
              "logic", "intuition", "charisma", "edge", "magic", "resonance")
ABBR = {"body": "BOD", "agility": "AGI", "reaction": "REA", "strength": "STR", "willpower": "WIL",
        "logic": "LOG", "intuition": "INT", "charisma": "CHA", "edge": "EDG", "magic": "MAG", "resonance": "RES"}
SPECIAL = ("magic", "resonance")          # can't be bought from zero: you're Awakened / Emerged or you aren't

# drones and vehicles (rules in machines.py; pools here so every tool works with them)
MACHINES = ("drone", "vehicle")
MACHINE_STATS = ("body", "armor", "pilot", "sensor", "handling", "speed", "accel")     # (what a sheet shows)
AUTOSOFT_FOR = {"firearms": "targeting", "throwing": "targeting", "close_combat": "targeting",
                "perception": "clearsight", "piloting": "maneuvering", "athletics": "maneuvering",
                "stealth": "stealth", "evasion": "evasion"}
DRIVER_SKILL = {"firearms": "firearms", "throwing": "firearms", "close_combat": "firearms",
                "perception": "perception", "stealth": "piloting"}          # everything else: piloting
MATRIX_SKILLS = ("hacking", "cybercombat", "electronics")
OUT = ("unconscious", "dying", "dead", "destroyed")                       # can't act

# skill -> default linked attribute
SKILLS = {
    "firearms": "agility", "close_combat": "agility", "throwing": "agility", "athletics": "agility",
    "stealth": "agility", "perception": "intuition", "hacking": "logic", "cybercombat": "logic",
    "electronics": "logic", "engineering": "logic", "first_aid": "logic", "con": "charisma",
    "negotiation": "charisma", "intimidation": "charisma", "etiquette": "charisma",
    "streetwise": "charisma", "sorcery": "magic", "conjuring": "magic", "piloting": "reaction",
    "software": "resonance", "compiling": "resonance",
    "survival": "willpower",
}

MOD_EACH = 4      # each situational modifier within +/-4
MOD_TOTAL = 6     # all modifiers together within +/-6
MAX_DV = 15
RESISTS = ("body_armor", "drain", "none")
THRESHOLD_MAX = 10          # SR5: easy 1, average 2, hard 4, very hard 6, extreme 8-10 (p. 45)
# Armor is about a third of SR5's here (an armored jacket is 4, not 12) and damage about 0.6, so the SR5 rule "Physical
# damage whose DV is under the armor becomes Stun" (p. 168) compares the DV with the armor times this.
ARMOR_STUN = 2.5
# Skills that are a whole SR5 skill group here (Firearms is Automatics + Longarms + Pistols) cost x3 a rating to raise -
# between a single skill's x2 and a group's x5, since you can't buy just the part you use (SR5 p. 107).
GROUP_SKILLS = ("firearms", "close_combat", "athletics", "engineering", "conjuring")
SMARTGUNS = ("predator", "hk-227", "alpha", "light fire")      # built-in smartgun systems (SR5 p. 425-428)


def nice(skill: str) -> str:
    return skill.replace("_", " ").title()


def scaled_ap(ap: int) -> int:
    """Weapons carry the book's AP; our armor is about a third of the book's, so AP counts at 0.4 (at least 1) -
    an Ares Alpha's -2 takes 1 off an armored jacket's 4, as the book's -2 takes a sixth of 12. Positive AP (frag)
    adds to the armor."""
    ap = int(ap or 0)
    if not ap:
        return 0
    return (1 if ap > 0 else -1) * max(1, round(abs(ap) * 0.4))


# ── Rolling ─────────────────────────────────────────────────────────────

@dataclass
class Roll:
    pool: int
    dice: list[int] = field(default_factory=list)
    extra: list[int] = field(default_factory=list)       # what exploding sixes rolled (Edge: push the limit)
    kept_glitch: bool = False                            # the first roll's glitch, kept through a Second Chance -
    kept_crit: bool = False                              # rerolling the 1s can't undo it (SR5 p. 56)

    @property
    def hits(self) -> int:
        return sum(1 for d in self.dice + self.extra if d >= 5)

    @property
    def ones(self) -> int:
        return sum(1 for d in self.dice if d == 1)

    @property
    def glitch(self) -> bool:
        return self.kept_glitch or (self.pool > 0 and self.ones > self.pool / 2)

    @property
    def crit_glitch(self) -> bool:
        return self.kept_crit or (self.glitch and self.hits == 0)

    def faces(self) -> str:
        if not self.dice:
            return "(no dice)"
        out = " ".join(str(d) for d in sorted(self.dice, reverse=True))
        if self.extra:
            out += " + " + " ".join(str(d) for d in self.extra) + " (sixes exploded)"
        return out

    def verdict(self) -> str:
        tag = f"{self.hits} hit{'s' if self.hits != 1 else ''}"
        if self.crit_glitch:
            tag += " - CRITICAL GLITCH"
        elif self.glitch:
            tag += " - GLITCH"
        return tag


def roll(dice: Dice, pool: int, explode: bool = False) -> Roll:
    """`pool` d6. explode: every 6 rolls again (and again) and its hits count - the Rule of Six, for pushed Edge."""
    pool = max(0, pool)
    r = Roll(pool, dice.roll(pool))
    sixes = sum(1 for d in r.dice if d == 6) if explode else 0
    for _ in range(30):
        if not sixes:
            break
        more = dice.roll(sixes)
        r.extra += more
        sixes = sum(1 for d in more if d == 6)
    return r


# ── Condition ───────────────────────────────────────────────────────────

def _is_machine(ledger: Ledger, eid: str) -> bool:
    ent = ledger.get(eid)
    return bool(ent) and ent["kind"] in MACHINES


REFLEX_WARE = ("wired reflexes", "synaptic booster")       # +1 initiative die a rating (SR5 p. 455, 461)
INIT_DICE_MAX = 5                                           # "the maximum Initiative Dice anyone can have is +5D6" (p. 288)


def _ware_dice(item: dict) -> int:
    """An implant's initiative dice: its initiative_dice prop, else its rating prop, else the rating at the end of its
    name ('Wired reflexes 2', 'Wired reflexes (3)'), else 1. Live: Quiet Lou's 'Wired reflexes' carries no prop at all,
    so rated-2 or -3 ware read by name alone would have counted one die."""
    p = item["props"]
    if p.get("initiative_dice"):
        return int(p["initiative_dice"])
    name = item["name"].lower()
    if not any(w in name for w in REFLEX_WARE):
        return 0
    if p.get("rating"):
        return int(p["rating"])
    m = re.search(r"(\d)\W*$", name)
    return int(m.group(1)) if m else 1


def initiative_dice(ledger: Ledger, eid: str) -> tuple[int, list[str]]:
    """Extra initiative dice (SR5 p. 159) beyond the 1D6 everyone rolls: reflex ware, Increase Reflexes - and where
    they come from. An initiative die raises the Initiative Score (Action Phases come from the score: initiative_rating),
    it isn't an action of its own. At most +4 (5D6 in all)."""
    n, why = 0, []
    for item in in_hand(ledger, eid):                 # (chrome still with the courier isn't installed yet)
        d = _ware_dice(item)
        if d:
            n += d
            label = item["name"].split("'s ", 1)[-1]
            why.append(label if re.search(r"\d\W*$", label) else f"{label} {d}")
    spell = int(ledger.stat(eid, "spell_init_dice", 0))
    if spell:
        n += spell
        why.append("Increase Reflexes")
    return min(INIT_DICE_MAX - 1, n), why


def _data_processing(ledger: Ledger, eid: str) -> tuple[int, str]:
    """A deck's Data Processing for VR Initiative - its rating here; Logic with no deck (a technomancer's living
    persona has Logic as its Data Processing too, SR5 p. 251)."""
    from .matrix import LIVING, deck                  # (matrix builds on this module - import late)
    rating, name = deck(ledger, eid)
    if rating and name != LIVING:
        return rating, f"Data Processing {rating}"
    return int(ledger.stat(eid, "logic", 0)), "Logic"


def initiative_rating(ledger: Ledger, eid: str) -> tuple[int, int, list[str]]:
    """(Initiative attribute, initiative dice, [the attribute's label, then where the dice come from]) - SR5's
    Initiative for what someone is doing right now (p. 159). In the flesh: Reaction + Intuition (+1 a hit of Increase
    Reflexes) and 1D6 plus reflex dice. Projecting: Intuition x 2 + 2D6. In hot-sim VR: Intuition + Data Processing
    + 4D6 (p. 229). A spirit: Reaction + Intuition + 2D6. A drone on its own Pilot: Pilot x 2 + 4D6 (riggers: Drone
    Initiative); jumped into, it takes its rigger's VR Initiative, cold-sim - Intuition + Data Processing + 3D6, since
    the engine's biofeedback is Stun (p. 266) - and the rigger's limp body gets none; remote-controlled, none of its
    own: it acts on its rigger's Action Phases (Control Device, p. 238). Never more than 5D6."""
    ent = ledger.require(eid)
    s = ledger.stats(eid)
    if ent["kind"] in MACHINES:
        p = ent["props"]
        drv = ledger.get(p.get("controller") or "")
        if drv and p.get("control") == "jumped":
            dp, label = _data_processing(ledger, drv["id"])
            return int(ledger.stat(drv["id"], "intuition", 0)) + dp, 3, [
                f"{drv['name']} jumped in: Intuition + {label}", "cold-sim VR"]
        if drv:
            return 0, 0, [f"remote: on {drv['name']}'s actions"]
        return int(s.get("pilot", 1)) * 2, 4, ["Pilot x 2", "autonomous"]
    rea, intu = int(s.get("reaction", 0)), int(s.get("intuition", 0))
    if ent["kind"] == "spirit":
        return rea + intu, 2, ["Reaction + Intuition", "spirit"]
    rig = jumped_into(ledger, eid)
    if rig:
        return 0, 0, [f"jumped into {rig['name']} - it acts for them"]
    if ent["props"].get("astral") == "projecting":
        return intu * 2, 2, ["Intuition x 2", "astral"]
    mx = ent["props"].get("matrix") or {}
    if mx.get("host") and mx.get("mode") == "vr" and _jacked_in(ledger, eid):
        dp, label = _data_processing(ledger, eid)
        return intu + dp, 4, [f"Intuition + {label}", "hot-sim VR"]
    n, why = initiative_dice(ledger, eid)
    bonus = int(s.get("spell_init_bonus", 0))                       # Increase Reflexes: +1 a hit (p. 288)
    return rea + intu + bonus, min(INIT_DICE_MAX, 1 + n), [
        "Reaction + Intuition" + (f" + {bonus} (Increase Reflexes)" if bonus else "")] + why


def initiative_text(ledger: Ledger, eid: str) -> str:
    """'Initiative 10 + 2D6 (Reaction + Intuition; Wired reflexes 1) - each 10 is an Action Phase' for the sheets."""
    attr, n, why = initiative_rating(ledger, eid)
    if not n:
        return f"Initiative: none of their own ({why[0]})"
    return (f"Initiative {attr} + {n}D6 ({'; '.join([why[0]] + [', '.join(why[1:])] if why[1:] else why[:1])})"
            " - each 10 is an Action Phase")


def jumped_into(ledger: Ledger, eid: str) -> dict | None:
    """The machine a rigger is jumped into (their body lies limp meanwhile), if any."""
    for kind in MACHINES:
        for m in ledger.entities(kind=kind):
            if m["props"].get("controller") == eid and m["props"].get("control") == "jumped":
                return m
    return None


def _jacked_in(ledger: Ledger, eid: str) -> bool:
    """Still in their Matrix run (matrix.live) - a run the story left behind doesn't leave the body limp. Live (flag
    #11): for forty turns after the T46 KD-4 dive the packet had Filament's body LIMP in hot-sim VR."""
    from .matrix import live                          # (matrix builds on this module - import late)
    return bool(live(ledger, eid))


def limp(ledger: Ledger, ent: dict) -> str | None:
    """Why a conscious body can't defend itself, if it can't: its mind is elsewhere - hot-sim VR, astral projection,
    jumped into a drone. None if they're in it."""
    mx = ent["props"].get("matrix") or {}
    if mx.get("host") and mx.get("mode") == "vr" and _jacked_in(ledger, ent["id"]):
        return "In hot-sim VR"
    if ent["props"].get("astral") == "projecting":
        return "Projecting astrally"
    rig = ent["kind"] not in MACHINES and jumped_into(ledger, ent["id"])
    return f"Jumped into {rig['name']}" if rig else None


def helpless(ledger: Ledger, eid: str) -> bool:
    """Can't fight back at all: out (unconscious, dying) or a limp body - a coup de grace's target (finish)."""
    ent = ledger.require(eid)
    return ent["kind"] not in MACHINES and (condition(ledger, eid) in OUT or bool(limp(ledger, ent)))


def monitor_max(ledger: Ledger, eid: str) -> tuple[int, int]:
    s = ledger.stats(eid)
    if _is_machine(ledger, eid):
        return 8 + ceil(s.get("body", 2) / 2), 0                         # no stun track: machines don't get dazed
    return 8 + ceil(s.get("body", 2) / 2), 8 + ceil(s.get("willpower", 2) / 2)


def wound_penalty(ledger: Ledger, eid: str) -> int:
    return int(ledger.stat(eid, "physical_damage") // 3 + ledger.stat(eid, "stun_damage") // 3)


def condition(ledger: Ledger, eid: str) -> str:
    pmax, smax = monitor_max(ledger, eid)
    if _is_machine(ledger, eid):
        phys = ledger.stat(eid, "physical_damage")
        return "destroyed" if phys >= pmax else "damaged" if phys else "ok"
    phys, stun = ledger.stat(eid, "physical_damage"), ledger.stat(eid, "stun_damage")
    body = ledger.stat(eid, "body", 2)
    if phys > pmax + body:
        return "dead"
    if phys > pmax:
        return "dying"
    if phys >= pmax or stun >= smax:
        return "unconscious"
    if phys or stun:
        return "wounded"
    return "ok"


def condition_line(ledger: Ledger, eid: str) -> str:
    pmax, smax = monitor_max(ledger, eid)
    if _is_machine(ledger, eid):
        pen = wound_penalty(ledger, eid)
        return (f"Structure {int(ledger.stat(eid, 'physical_damage'))}/{pmax} ({condition(ledger, eid)}"
                + (f", -{pen} to pools" if pen else "") + ")")
    phys, stun = int(ledger.stat(eid, "physical_damage")), int(ledger.stat(eid, "stun_damage"))
    pen = wound_penalty(ledger, eid)
    status = condition(ledger, eid)
    if status == "dying" and ledger.stat(eid, "stabilized", 0):
        status += ", stabilized"                                         # (no longer bleeding: bleed)
    tail = f", -{pen} to pools" if pen else ""
    return f"Physical {phys}/{pmax}, Stun {stun}/{smax} ({status}{tail})"


# ── Bought, not here yet (shops.py: a dealer's delivery) ────────────────
# Live N353: the GM tracked a courier "around T209" by hand, while the ledger already had Filament holding the gun.
# An item or machine bought for delivery carries props.in_transit {until, from} until the story clock passes it
# (shops.arrivals flips it in commit); until then it's held but can't be used.

def arriving(ent: dict | None) -> dict | None:
    """The delivery an item or machine is still waiting on ({until, from}), or None if it's here."""
    return ((ent or {}).get("props") or {}).get("in_transit") or None


def transit_note(ledger: Ledger, ent: dict) -> str:
    """'on its way from BarrensBolt - arrives tomorrow morning' (coarse, never a countdown)."""
    from .. import clock
    t = arriving(ent) or {}
    now = int(ledger.meta("clock", str(clock.DEFAULT_START)))
    return (f"on its way" + (f" from {t['from']}" if t.get("from") else "")
            + f" - arrives {clock.ahead(int(t.get('until') or now), now)}")


def in_hand(ledger: Ledger, eid: str) -> list[dict]:
    """What someone holds that's actually here - their holdings less what's still with the courier, and chrome that
    came but was never put in (props.install still on it: shops.arrivals found them at the Essence floor)."""
    return [i for i in ledger.holdings(eid) if not arriving(i) and not i["props"].get("install")]


def autosofts(ledger: Ledger, ent: dict) -> dict[str, int]:
    """A machine's autosofts: the ones it came with (props.autosofts) and the ones loaded onto it since - autosoft
    items in its holdings (shops: buy onto a drone; machines.mount_weapon), the best rating of each."""
    out = {k: int(v) for k, v in ((ent.get("props") or {}).get("autosofts") or {}).items()}
    for i in in_hand(ledger, ent["id"]):
        soft = i["props"].get("autosoft")
        if soft:
            out[soft] = max(out.get(soft, 0), int(i["props"].get("rating", 1)))
    return out


# ── Pools ───────────────────────────────────────────────────────────────

def gear_bonus(ledger: Ledger, eid: str, skill: str) -> tuple[int, str]:
    """Best single gear bonus for a skill (bonuses don't stack - anti-cheese). A bricked deck gives none until it's
    repaired (matrix.bricked - flag #24: Filament's Deck 14/10 still added +2 to his Hacking)."""
    best, label = 0, ""
    for item in in_hand(ledger, eid):
        b = int(item["props"].get("bonus", {}).get(skill, 0))
        if b > best and not _bricked(ledger, eid, item):
            best, label = b, item["name"]
    return best, label


def _bricked(ledger: Ledger, eid: str, item: dict) -> bool:
    if not (item["props"].get("deck") or "deck" in item["name"].lower()):
        return False
    from .matrix import bricked                       # (matrix builds on this module - import late)
    return bricked(ledger, eid) == item["id"]


def machine_pool(ledger: Ledger, ent: dict, skill: str) -> tuple[int, list[tuple[str, int]]]:
    """A drone or vehicle's pool: its device rating against hackers; a driver's skill when someone has the
    controls (Logic remote, Reaction + control rig jumped in); otherwise Pilot + the right autosoft."""
    s, props = ledger.stats(ent["id"]), ent["props"]
    pilot = int(s.get("pilot", 1))
    skill = skill.lower().replace(" ", "_")
    driver = ledger.get(props.get("controller") or "")
    if skill in MATRIX_SKILLS:
        if driver and props.get("control") == "jumped" and condition(ledger, driver["id"]) not in OUT:
            from .machines import control_rig                       # (SR5 p. 269: hack the rigger, not the drone)
            mind = (int(ledger.stat(driver["id"], "logic", 0)) + int(ledger.stat(driver["id"], "willpower", 0))
                    + control_rig(ledger, driver["id"]))
            if mind > pilot * 2:
                return mind, [(f"{driver['name']} jumped in (Logic + Willpower + rig)", mind)]
        return pilot * 2, [(f"Device (Pilot {pilot} doubled)", pilot * 2)]
    if driver and condition(ledger, driver["id"]) not in OUT:
        mode = props.get("control") or "remote"
        dskill = DRIVER_SKILL.get(skill, "piloting")
        rating = int(ledger.stat(driver["id"], dskill, 0))
        attr = "reaction" if mode == "jumped" else "logic"
        parts = [(f"{driver['name']}'s {nice(dskill)}" if rating else f"{driver['name']}, untrained", rating or -1),
                 (f"{driver['name']}'s {attr.title()}", int(ledger.stat(driver["id"], attr, 0)))]
        if mode == "jumped":
            from .machines import control_rig
            rig = control_rig(ledger, driver["id"])
            if rig:
                parts.append(("Control rig", rig))
        # One mind, several drones: the others they run that are still running and with them - where they are, or
        # never placed. Live T188: Filament's Fly-Spy, parked in S12's roster under his remote control since T132,
        # took 2 dice off every roll of the Roto-drone he drove at S22 (destroyed machines counted too). One the GM
        # sent out of the scene (scene_presence leave) was placed - it's left behind, not with them (machines.beside).
        from .machines import beside
        others = sum(1 for k in MACHINES for m in ledger.entities(kind=k)
                     if m["props"].get("controller") == driver["id"] and m["id"] != ent["id"]
                     and condition(ledger, m["id"]) not in OUT and beside(ledger, m["id"], driver["id"]))
        if others:
            parts.append((f"Also running {others} other machine{'s' if others > 1 else ''}", -2 * others))
    else:
        soft = AUTOSOFT_FOR.get(skill)
        rating = autosofts(ledger, ent).get(soft, 0) if soft else 0
        parts = [("Pilot", pilot), (f"{soft.title()} autosoft" if rating else "No autosoft", rating or -1)]
    pen = wound_penalty(ledger, ent["id"])
    if pen:
        parts.append(("Damage", -pen))
    return max(0, sum(v for _, v in parts)), parts


def build_pool(ledger: Ledger, eid: str, skill: str, attribute: str | None = None,
               use_gear: bool = True) -> tuple[int, list[tuple[str, int]]]:
    ent = ledger.require(eid)
    if ent["kind"] in MACHINES:
        return machine_pool(ledger, ent, skill)
    if ent["kind"] == "host":
        rating = int(ent["props"].get("rating", ledger.stat(eid, "rating", 3)))
        return rating * 2, [(f"Host (rating {rating} doubled)", rating * 2)]
    skill = skill.lower().replace(" ", "_")
    if skill not in SKILLS:
        raise LedgerError(f"Unknown skill '{skill}'. Skills: {', '.join(sorted(SKILLS))}.")
    attribute = (attribute or SKILLS[skill]).lower()
    if attribute not in ATTRIBUTES:
        raise LedgerError(f"Unknown attribute '{attribute}'. Attributes: {', '.join(ATTRIBUTES)}.")
    stats = ledger.stats(eid)
    parts = [(attribute.title(), int(stats.get(attribute, 0)))]
    rating = int(stats.get(skill, 0))
    if rating:
        parts.append((nice(skill), rating))
    elif skill in ("sorcery", "conjuring", "hacking", "cybercombat", "software", "compiling"):
        raise LedgerError(f"{ent['name']} has no {nice(skill)} skill and it can't be used untrained.")
    else:
        parts.append(("Untrained", -1))
    if use_gear:
        bonus, label = gear_bonus(ledger, eid, skill)
        if bonus:
            parts.append((label, bonus))
    parts += _conditions(ledger, ent, skill)
    return max(0, sum(v for _, v in parts)), parts


def _conditions(ledger: Ledger, ent: dict, skill: str | None) -> list[tuple[str, int]]:
    """What a living character's state takes off any pool: wounds, held spells and forms, Confusion, and astral
    perception (-2 to mundane tests: all but Sorcery, Conjuring and Perception)."""
    eid, parts = ent["id"], []
    pen = wound_penalty(ledger, eid)
    if pen:
        parts.append(("Wounds", -pen))
    held = int(ledger.stat(eid, "sustaining", 0))
    if held:
        parts.append((f"Sustaining {held} spell{'s' if held > 1 else ''}", -2 * held))
    forms = int(ledger.stat(eid, "sustaining_forms", 0))
    if forms:
        parts.append((f"Sustaining {forms} form{'s' if forms > 1 else ''}", -2 * forms))
    fog = int(ledger.stat(eid, "spell_penalty", 0))
    if fog:
        parts.append(("Confused", -fog))
    if ent["props"].get("astral") == "perceiving" and skill not in ("sorcery", "conjuring", "perception"):
        parts.append(("Perceiving astrally", -2))
    return parts


def attribute_pool(ledger: Ledger, eid: str, attributes) -> tuple[int, list[tuple[str, int]], list[str]]:
    """An attribute-only test's pool (SR5 p. 152: 'pair two attributes together ... where no skill suffices', or one
    alone): Composure is Charisma + Willpower, Memory Logic + Willpower, and seeing through a mana illusion like
    Invisibility Logic + Willpower (p. 290). No skill, so no untrained -1 and no gear; wounds, held spells and
    Confusion still count. Returns (dice, parts, the attributes). Live review: Invisibility's card asked for Logic +
    Willpower and request_test could only roll a skill."""
    ent = ledger.require(eid)
    if ent["kind"] in MACHINES or ent["kind"] == "host":
        raise LedgerError(f"{ent['name']} isn't a living mind - an attribute-only test is a person's (a machine rolls "
                          "its own pool: name a skill).")
    attrs = [str(a).strip().lower() for a in attributes or [] if str(a).strip()]
    bad = [a for a in attrs if a not in ATTRIBUTES]
    if bad:
        raise LedgerError(f"Unknown attribute '{bad[0]}'. Attributes: {', '.join(ATTRIBUTES)}.")
    if not 1 <= len(attrs) <= 2 or len(set(attrs)) < len(attrs):
        raise LedgerError("An attribute-only test pairs two different attributes, or takes one alone (SR5 p. 152).")
    stats = ledger.stats(eid)
    parts = [(a.title(), int(stats.get(a, 0))) for a in attrs] + _conditions(ledger, ent, None)
    return max(0, sum(v for _, v in parts)), parts, attrs


def clamp_mods(modifiers) -> tuple[list[tuple[str, int]], list[str]]:
    out, notes = [], []
    for m in modifiers or []:
        label = str(m.get("label", "situational"))
        value = int(m.get("value", 0))
        clamped = max(-MOD_EACH, min(MOD_EACH, value))
        if clamped != value:
            notes.append(f"'{label}' clamped {value:+d} -> {clamped:+d}")
        if clamped:
            out.append((label, clamped))
    total = sum(v for _, v in out)
    if abs(total) > MOD_TOTAL:
        notes.append(f"total modifiers clamped {total:+d} -> {MOD_TOTAL if total > 0 else -MOD_TOTAL:+d}")
        excess = total - (MOD_TOTAL if total > 0 else -MOD_TOTAL)
        out.append(("cap", -excess))
    return out, notes


def fmt_parts(parts) -> str:
    s = ""
    for i, (label, v) in enumerate(parts):
        if i == 0:
            s = f"{label} {v}"
        else:
            s += f" {'+' if v >= 0 else '-'} {label} {abs(v)}"
    return s


def table_difficulty(ledger: Ledger) -> dict:
    """The !difficulty dial (threshold shift for PCs, extra dice for their opposition)."""
    raw = ledger.meta("difficulty")
    d = json.loads(raw) if raw else {}
    return {"level": d.get("level", "normal"), "threshold": int(d.get("threshold", 0)),
            "opposition": int(d.get("opposition", 0))}


def _opposition(ledger: Ledger, pc_side: str, other_side: str) -> int:
    """Extra dice the table difficulty gives a non-PC acting against a PC."""
    a, b = ledger.get(pc_side), ledger.get(other_side)
    if a and b and a["kind"] == "pc" and b["kind"] in ("npc", "host"):
        return table_difficulty(ledger)["opposition"]
    return 0


def _record(ledger: Ledger, turn: int | None, actor: str, spec: dict, r: Roll, success: bool, net: int):
    ledger.conn.execute(
        "INSERT INTO tests(turn_id, actor_id, spec, dice, hits, glitch, crit_glitch, success, net)"
        " VALUES(?,?,?,?,?,?,?,?,?)",
        (turn, actor, json.dumps(spec), json.dumps(r.dice), r.hits, int(r.glitch), int(r.crit_glitch),
         int(success), net))


# ── Tests ───────────────────────────────────────────────────────────────

# ── Edge ────────────────────────────────────────────────────────────────
# Luck, a few points a session: a PC has as many Edge points as their Edge rating, refilled when a new session starts.
# Only the player spends it - they say so in their post, for any roll of theirs - and the GM passes it on (§6b):
#   push     - Push the Limit, before the roll: + Edge-rating dice, every 6 explodes (counts, then rolls again), and
#              the roll ignores its limit - the only way past a spell's Force ("push it", "reroll 6s", "exploding 6s")
#   reroll   - Second Chance, the player's binding call ("reroll my misses"): the misses are rerolled whenever more
#              hits can still change something - never past the limit, which a Second Chance doesn't raise (p. 56)
#   if_short - Second Chance as insurance ("Edge if I miss"): the misses are rerolled only if the roll falls short,
#              and the point is spent only then
# Live flag #64 (T164): "uses edge to reroll fails" on a Force 8 barrier was held in reserve - 'reroll' was insurance
# only, and 4 hits on 13 dice didn't count as short though 4 more could still have counted.
# Burning Edge - the rating itself, for good - keeps a dying character alive: not dead yet.
EDGE_USES = ("push", "reroll", "if_short")
EDGE_ALIASES = {"push_the_limit": "push", "pushed": "push", "push_it": "push", "reroll_6s": "push",
                "re_roll_6s": "push", "reroll_sixes": "push", "exploding_6s": "push", "exploding_sixes": "push",
                "explode": "push", "rule_of_six": "push", "rule_of_6": "push",
                "second_chance": "reroll", "re_roll": "reroll", "reroll_misses": "reroll", "reroll_fails": "reroll",
                "insurance": "if_short", "if_needed": "if_short", "if_miss": "if_short", "if_fail": "if_short",
                "if_i_miss": "if_short", "if_i_fail": "if_short", "just_in_case": "if_short", "in_case": "if_short"}


def edge_use(use) -> str | None:
    """None, push, reroll or if_short, from the mode or the player's words for it ('second chance', 'if I miss',
    'reroll 6s'). True means push - the old use_edge flag; 'none' (any case) means no Edge on this roll."""
    if use in (None, False, ""):
        return None
    if use is True:
        return "push"
    u = str(use).strip().lower().replace("'", "").replace("’", "").replace("-", "_").replace(" ", "_")
    if u == "none":
        return None
    u = EDGE_ALIASES.get(u, u)
    if u not in EDGE_USES:
        raise LedgerError(f"Edge is spent as one of: {', '.join(EDGE_USES)} (or 'none').")
    return u


def spend_edge(ledger: Ledger, turn: int | None, eid: str, how: str = "push", on: str = "") -> int:
    """Spend one Edge point; returns how many are left. Raises if there are none. on: the roll it went on (cast,
    drain, attack, dodge, soak, test, matrix) - live T165's point could have been the casting's or the drain's."""
    have = int(ledger.stat(eid, "edge_points"))
    if have <= 0:
        raise LedgerError(f"{ledger.require(eid)['name']} has no Edge points left this session.")
    ledger.set_stat(eid, "edge_points", have - 1)
    ledger.log(turn, "edge", eid, {"use": how, "left": have - 1} | ({"on": on} if on else {}))
    return have - 1


def push_edge(ledger: Ledger, turn: int | None, eid: str, parts: list, use: str | None,
              required: bool = True, on: str = "") -> tuple[bool, str | None]:
    """Before the roll: with `use` push, spend the point and add the Edge dice to `parts` (in place). Returns
    (explode?, a note when it couldn't). required=False - a dodge, a soak, drain - just goes without when they're out."""
    if use != "push":
        return False, None
    try:
        left = spend_edge(ledger, turn, eid, "push", on)
    except LedgerError as exc:
        if required:
            raise
        return False, f"  Edge   {exc}"
    parts.append((f"Edge, pushed - 6s explode ({left} left)", int(ledger.stat(eid, "edge", 1))))
    return True, None


def second_chance(ledger: Ledger, dice: Dice, turn: int | None, eid: str, r: Roll, use: str | None,
                  short: bool, useful: bool = True, limit: int | None = None,
                  on: str = "", free: bool = False) -> tuple[Roll, str | None]:
    """After the roll: a Second Chance rerolls the misses. use reroll (the player's binding call) spends it whenever
    `useful` - more hits can still change something; if_short (insurance) only when the roll fell `short`. Either is
    held with no misses, or at `limit` (a spell's Force: a Second Chance never raises it, SR5 p. 56). The rerolled
    roll keeps the first roll's glitch - a Second Chance can't undo one. free: the point was already spent on an
    earlier share of the same split pool - one Edge rerolls them all (Multiple Attacks, p. 196)."""
    if use not in ("reroll", "if_short") or not r.dice:
        return r, None
    misses = [d for d in r.dice if d < 5]
    if not misses:
        return r, "  Edge   held in reserve - no misses to reroll"
    if limit is not None and r.hits >= limit:
        return r, f"  Edge   held in reserve - already at the limit (Force {limit}); only a push goes past it"
    if use == "reroll" and not useful:
        return r, "  Edge   held in reserve - more hits couldn't change this roll"
    if use == "if_short" and not short:
        return r, "  Edge   held in reserve - the roll didn't need a second chance"
    if free:
        left = None
    else:
        try:
            left = spend_edge(ledger, turn, eid, use, on)
        except LedgerError as exc:
            return r, f"  Edge   {exc}"
    new = dice.roll(len(misses))
    r2 = Roll(r.pool, [d for d in r.dice if d >= 5] + new, list(r.extra), kept_glitch=r.glitch, kept_crit=r.crit_glitch)
    return r2, (f"  Edge   second chance: {len(misses)} misses rerolled -> "
                f"{' '.join(str(d) for d in sorted(new, reverse=True)) or '-'} -> {r2.verdict()} "
                + ("(the same point - one Edge covers the split pool)" if free else f"({left} left)")
                + (" - the glitch stands" if r.glitch else ""))


def below_average(r: Roll) -> bool:
    """With nothing to beat, a roll falls short under one hit per three dice."""
    return r.hits < max(1, r.pool // 3)


def burn_edge(ledger: Ledger, turn: int | None, eid: str, reason: str = "") -> dict:
    """Not dead yet: a dying (or just-killed) character burns a point of Edge rating for good and lives - out cold but
    stable, at the edge of their monitor."""
    ent = ledger.require(eid)
    rating = int(ledger.stat(eid, "edge", 0))
    if rating <= 0:
        raise LedgerError(f"{ent['name']} has no Edge left to burn.")
    status = condition(ledger, eid)
    if status not in ("dying", "dead"):
        raise LedgerError(f"Burning Edge is for cheating death, and {ent['name']} is {status}. (To push a roll, pass "
                          "edge='push' on it.)")
    pmax, _ = monitor_max(ledger, eid)
    ledger.set_stat(eid, "physical_damage", pmax)
    ledger.set_stat(eid, "edge", rating - 1)
    ledger.set_stat(eid, "edge_points", min(int(ledger.stat(eid, "edge_points")), rating - 1))
    ledger.log(turn, "edge_burn", eid, {"edge": rating - 1, "was": status, "reason": reason})
    return {"card": f"[EDGE] {ent['name']} burns Edge - not dead yet. Edge {rating} -> {rating - 1}, for good. "
                    f"{condition_line(ledger, eid)}"}


def regain_edge(ledger: Ledger, turn: int | None, eid: str, reason: str = "") -> dict:
    """The GM hands back a point of Edge for a great moment (never past the rating)."""
    ent = ledger.require(eid)
    rating, have = int(ledger.stat(eid, "edge", 0)), int(ledger.stat(eid, "edge_points"))
    if have >= rating:
        raise LedgerError(f"{ent['name']} already has all {rating} Edge points.")
    ledger.set_stat(eid, "edge_points", have + 1)
    ledger.log(turn, "edge_regain", eid, {"points": have + 1, "reason": reason})
    return {"card": f"[EDGE] {ent['name']} gets a point of Edge back ({have + 1}/{rating})"
                    + (f" - {reason}" if reason else "")}


def refresh_edge(ledger: Ledger, turn: int | None, eid: str, reason: str = "") -> dict:
    """Edge points back to full - when a table ruling says so (after a fight, a finished run) or the GM grants it.
    ('all' refreshes every PC.) A new session does this by itself (Ledger.new_session)."""
    who = [p for p in ledger.entities(kind="pc") if int(ledger.stat(p["id"], "edge", 0))] if eid == "all" \
        else [ledger.require(eid)]
    if not who:
        raise LedgerError("No one here has an Edge rating.")
    done = []
    for ent in who:
        rating, have = int(ledger.stat(ent["id"], "edge", 0)), int(ledger.stat(ent["id"], "edge_points"))
        if not rating:
            raise LedgerError(f"{ent['name']} has no Edge rating.")
        if have < rating:
            ledger.set_stat(ent["id"], "edge_points", rating)
            ledger.log(turn, "edge_refresh", ent["id"], {"points": rating, "was": have, "reason": reason})
        done.append(f"{ent['name']} {rating}/{rating}" + ("" if have < rating else " (already full)"))
    return {"card": "[EDGE] Edge back to full: " + ", ".join(done) + (f" - {reason}" if reason else "")}


# ── Advancement (karma) ─────────────────────────────────────────────────
# SR5 costs: an attribute to rating N costs N x 5 karma, a skill to N costs N x 2 (learning one = 2).
# Every stat has a fixed reference number so "!advance 13" means the same thing on every sheet.
ATTR_MAX, SKILL_MAX = 6, 12


# Reference numbers never move: new stats are appended after the original 30.
_LATER = ("resonance", "software", "compiling")


def advancement_refs() -> dict[int, str]:
    order = ([a for a in ATTRIBUTES if a not in _LATER] + sorted(s for s in SKILLS if s not in _LATER)
             + list(_LATER))
    return {i + 1: k for i, k in enumerate(order)}


def resolve_stat(ref: str) -> str:
    """'13', 'firearms', 'close combat', 'AGI' -> the stat key."""
    r = ref.strip().lower().replace(" ", "_")
    if r.isdigit():
        key = advancement_refs().get(int(r))
        if key:
            return key
    abbr = {v.lower(): k for k, v in ABBR.items()}
    if r in ATTRIBUTES or r in SKILLS:
        return r
    if r in abbr:
        return abbr[r]
    raise LedgerError(f"No stat '{ref}'. Use the number from your !charactersheet, or a name like firearms or AGI.")


def attr_cap(ledger: Ledger, eid: str, key: str) -> int:
    """The natural maximum: 6, shifted by the metatype (an ork's Body goes to 9) for characters built with one."""
    meta = ((ledger.get(eid) or {}).get("props") or {}).get("metatype")
    if not meta:
        return ATTR_MAX
    from ...chargen import METATYPES                  # (chargen builds on these rules - import late)
    return METATYPES.get(meta, {}).get("max", {}).get(key, ATTR_MAX)


def augmentation(ledger: Ledger, eid: str, key: str) -> int:
    """How much of an attribute is chrome (muscle replacement, wired reflexes...) rather than the runner's own: the
    installed cyberware's catalog bonuses. Karma raises - and is priced on - the natural part (SR5 p. 106)."""
    from ...chargen import CATALOG                    # (chargen builds on these rules - import late)
    chrome = [(c["name"].lower(), c["attrs"]) for c in CATALOG.values() if c.get("attrs")]
    total = 0
    for i in in_hand(ledger, eid):                    # ("Quiet Lou's Muscle replacement" is muscle replacement)
        attrs = next((a for n, a in chrome if n in i["name"].lower()), None)
        if attrs:
            total += int(attrs.get(key, 0)) * max(1, int(i.get("qty", 1) or 1))
    return total


def advance_cost(ledger: Ledger, eid: str, key: str) -> tuple[int, int, str | None]:
    """(new rating, karma cost, why not) for raising one stat by a point."""
    now = int(ledger.stat(eid, key, 0))
    if key in ATTRIBUTES:
        if key == "magic" and now <= 0:
            return now, 0, "You aren't Awakened - Magic can't be bought."
        if key == "resonance" and now <= 0:
            return now, 0, "You haven't Emerged - Resonance can't be bought."
        top = attr_cap(ledger, eid, key)
        if key in SPECIAL:                            # every Essence point lost to chrome is a point of Magic gone for good
            lost = ceil(6.0 - float(ledger.stat(eid, "essence", 6.0)) - 1e-9)
            if lost > 0:
                top = max(0, top - lost)
                if now >= top:
                    return now, 0, f"{ABBR[key]} can't go past {top} - the chrome took the rest (Essence lost)."
        aug = augmentation(ledger, eid, key)
        natural = now - aug
        if natural >= top:
            return now, 0, (f"{ABBR[key]} is at its natural maximum ({top})"
                            + (f" - {natural} natural + {aug} chrome." if aug else "."))
        return now + 1, (natural + 1) * 5, None
    if key in ("sorcery", "conjuring") and ledger.stat(eid, "magic", 0) <= 0:
        return now, 0, f"{nice(key)} needs Magic - you aren't Awakened."
    if key in ("software", "compiling") and ledger.stat(eid, "resonance", 0) <= 0:
        return now, 0, f"{nice(key)} needs Resonance - you haven't Emerged."
    if now >= SKILL_MAX:
        return now, 0, f"{nice(key)} is at the maximum ({SKILL_MAX})."
    return now + 1, (now + 1) * (3 if key in GROUP_SKILLS else 2), None


def advance(ledger: Ledger, turn: int | None, eid: str, ref: str) -> dict:
    ent = ledger.require(eid)
    if ent["kind"] != "pc":
        raise LedgerError("Only player characters spend karma.")
    # (No list on file means every spell or form - as cast, thread and the sheets read it - so there's nothing to learn:
    # live review, learning one on an empty list charged the karma and cut the caster down to that one.)
    if ref.strip().lower().startswith("form"):
        from .resonance import FORMS, LEARN_COST as FCOST, form, learnable as can_learn
        key = form(ref.strip()[4:])
        if int(ledger.stat(eid, "resonance", 0)) <= 0:
            raise LedgerError(f"{ent['name']} hasn't Emerged - complex forms need Resonance.")
        known = list(ent["props"].get("forms") or [])
        if key not in can_learn(ledger, eid):
            raise LedgerError(f"{ent['name']} already knows {FORMS[key]['name']}"
                              + ("" if known else " - with no list on file, they know every complex form") + ".")
        have = int(ledger.stat(eid, "karma"))
        if have < FCOST:
            raise LedgerError(f"Learning {FORMS[key]['name']} costs {FCOST} karma; {ent['name']} has {have}.")
        ledger.set_stat(eid, "karma", have - FCOST)
        ledger.update_entity(eid, props={**ent["props"], "forms": known + [key]})
        ledger.log(turn, "advance", eid, {"form": key, "cost": FCOST})
        return {"card": f"[KARMA] {ent['name']} learns {FORMS[key]['name']} ({FCOST} karma, {have - FCOST} left)",
                "stat": key, "rating": 1, "cost": FCOST, "left": have - FCOST}
    if ref.strip().lower().startswith("spell"):
        from .magic import LEARN_COST, SPELLS, learnable, spell
        key = spell(ref.strip()[5:])
        if int(ledger.stat(eid, "magic", 0)) <= 0:
            raise LedgerError(f"{ent['name']} isn't Awakened - spells need Magic.")
        known = list(ent["props"].get("spells") or [])
        if key not in learnable(ledger, eid):
            raise LedgerError(f"{ent['name']} already knows {SPELLS[key]['name']}"
                              + ("" if known else " - with no list on file, they know every spell") + ".")
        have = int(ledger.stat(eid, "karma"))
        if have < LEARN_COST:
            raise LedgerError(f"Learning {SPELLS[key]['name']} costs {LEARN_COST} karma; {ent['name']} has {have}.")
        ledger.set_stat(eid, "karma", have - LEARN_COST)
        ledger.update_entity(eid, props={**ent["props"], "spells": known + [key]})
        ledger.log(turn, "advance", eid, {"spell": key, "cost": LEARN_COST})
        return {"card": f"[KARMA] {ent['name']} learns {SPELLS[key]['name']} ({LEARN_COST} karma, {have - LEARN_COST} left)",
                "stat": key, "rating": 1, "cost": LEARN_COST, "left": have - LEARN_COST}
    key = resolve_stat(ref)
    new, cost, why = advance_cost(ledger, eid, key)
    if why:
        raise LedgerError(why)
    have = int(ledger.stat(eid, "karma"))
    if have < cost:
        raise LedgerError(f"{nice(key) if key in SKILLS else ABBR[key]} {new - 1} -> {new} costs {cost} karma; "
                          f"{ent['name']} has {have}.")
    ledger.set_stat(eid, "karma", have - cost)
    ledger.set_stat(eid, key, new)
    if key == "edge":                                   # a higher Edge rating comes with the extra point
        ledger.add_stat(eid, "edge_points", 1)
    ledger.log(turn, "advance", eid, {"stat": key, "to": new, "cost": cost})
    label = nice(key) if key in SKILLS else ABBR[key]
    return {"card": f"[KARMA] {ent['name']} raises {label} to {new} ({cost} karma, {have - cost} left)",
            "stat": key, "rating": new, "cost": cost, "left": have - cost}


def award_karma(ledger: Ledger, turn: int | None, eid: str, amount: int, reason: str = "") -> str:
    ent = ledger.require(eid)
    if ent["kind"] != "pc":
        raise LedgerError("Karma goes to player characters.")
    amount = max(-20, min(20, int(amount)))
    total = int(ledger.add_stat(eid, "karma", amount))
    ledger.log(turn, "karma", eid, {"amount": amount, "reason": reason})
    return f"[KARMA] {ent['name']} {amount:+d} karma" + (f" - {reason}" if reason else "") + f" (now {total})"


def teamwork(ledger: Ledger, dice: Dice, leader: str, skill: str, helpers: list[dict] | None) -> dict:
    """Teamwork (SR5): each helper rolls their own pool - the same skill unless named - and every hit adds a die to the
    leader's, up to the leader's rating in the skill (at least 1). That cap is the book's, and the table's since
    2026-10-27 (the owner, flags #38/#52): it replaces R8's 'max +4'. A helper's glitch is their own complication. Someone
    who can't act, or can't use the skill untrained, doesn't help. Returns {bonus, who, lines, helped, hits, cap} -
    helped: one {id, skill, dice, hits} a helper (or {id, why} for one who couldn't), for the tests row."""
    cap = max(1, int(ledger.stat(leader, skill.lower(), 0)))
    hits, who, rows, seen, helped = 0, [], [], {leader}, []
    for h in helpers or []:
        ent = ledger.find(str(h.get("id") or ""))
        if not ent or ent["id"] in seen:
            continue
        seen.add(ent["id"])
        if condition(ledger, ent["id"]) in OUT:
            rows.append(f"{ent['name']} can't help ({condition(ledger, ent['id'])})")
            helped.append({"id": ent["id"], "why": condition(ledger, ent["id"])})
            continue
        h_skill = (h.get("skill") or skill).lower()
        try:
            n, _ = build_pool(ledger, ent["id"], h_skill)
        except LedgerError as exc:
            rows.append(f"{ent['name']} can't help ({exc})")
            helped.append({"id": ent["id"], "why": str(exc)})
            continue
        r = roll(dice, max(0, n))
        hits += r.hits
        who.append(ent["name"])
        helped.append({"id": ent["id"], "skill": h_skill, "dice": n, "hits": r.hits}
                      | ({"glitch": "critical" if r.crit_glitch else True} if r.glitch else {}))
        rows.append(f"{ent['name']} {nice(h_skill)} {n}d6 -> {r.faces()} -> {r.hits} hit{'s' * (r.hits != 1)}"
                    + (" - CRITICAL GLITCH: their own mess" if r.crit_glitch else
                       " - glitch: their own complication" if r.glitch else ""))
    bonus = min(cap, hits)
    lines = ([f"  Team   " + " · ".join(rows)]
             + ([f"         +{bonus} {'die' if bonus == 1 else 'dice'} to {ledger.get(leader)['name']}"
                 + (f" (capped at their {nice(skill)} {cap})" if hits > cap else "")] if who else [])) if rows else []
    return {"bonus": bonus, "who": who, "lines": lines, "helped": helped, "hits": hits, "cap": cap}


def request_test(ledger: Ledger, dice: Dice, turn: int | None, actor: str, skill: str,
                 attribute: str | None = None, threshold: int | None = None,
                 opposed: dict | None = None, modifiers=None, reason: str = "", use_edge: bool = False,
                 edge: str | None = None, helpers: list[dict] | None = None, attributes=None,
                 by: str | None = None) -> dict:
    """A skill test - or, with attributes and no skill, an attribute-only test (attribute_pool, SR5 p. 152) - against
    a threshold or opposed (opposed may name attributes too). The tests row keeps the teamwork: who helped, each one's
    dice and hits, the bonus and the cap (flag #38: T128's 8d6 against Magic's base 7 couldn't say whether anyone had
    helped). by: who made the roll when it wasn't the GM - 'engine' for a called roll the engine rolled itself
    (dm/calls.py)."""
    ent = ledger.require(actor)
    if condition(ledger, ent["id"]) in OUT:
        raise LedgerError(f"{ent['name']} is {condition(ledger, ent['id'])} and can't act.")
    use = edge_use(edge or use_edge)
    attrs = None
    if attributes:
        if skill or attribute:
            raise LedgerError("A skill test or an attribute-only test, not both: name the skill (and its attribute) "
                              "or two attributes.")
        if helpers:
            raise LedgerError("Teamwork adds dice up to the leader's skill - an attribute-only test has no skill to "
                              "help with.")
        base, parts, attrs = attribute_pool(ledger, ent["id"], attributes)
        what = " + ".join(a.title() for a in attrs)
    elif not skill:
        raise LedgerError("Which skill? Or attributes (two, no skill) for an attribute-only test (SR5 p. 152).")
    else:
        base, parts = build_pool(ledger, ent["id"], skill, attribute)
        what = f"{nice(skill)} + {(attribute or SKILLS.get(skill.lower(), '')).title()}"
    mods, notes = clamp_mods(modifiers)
    parts = parts + mods
    team = teamwork(ledger, dice, ent["id"], skill, helpers) if skill else {"bonus": 0, "who": [], "lines": []}
    if team["bonus"]:
        parts.append((f"Teamwork ({', '.join(team['who'])})", team["bonus"]))
    explode, _ = push_edge(ledger, turn, ent["id"], parts, use, on="test")
    pool = max(0, sum(v for _, v in parts))
    r0 = roll(dice, pool, explode)
    lines = []
    diff = table_difficulty(ledger)
    shown = {"attributes": attrs} if attrs else {}     # (on the record: a tests row with no skill says what it rolled)
    if team.get("helped"):                             # (read_turn shows who helped, and how much it added)
        shown |= {"helpers": team["helped"], "teamwork": team["bonus"]} | (
            {"cap": team["cap"]} if team["hits"] > team["cap"] else {})
    if by:
        shown["by"] = by
    if opposed and opposed.get("entity_id"):
        opp = ledger.require(opposed["entity_id"])
        o_skill = opposed.get("skill") or "perception"
        if opp["kind"] in MACHINES and (skill or "").lower() in MATRIX_SKILLS:
            o_skill = "hacking"                       # a drone fights a hacker with its own device rating
        if opposed.get("attributes") and not opposed.get("skill"):
            o_pool, o_parts, _ = attribute_pool(ledger, opp["id"], opposed["attributes"])
        else:
            o_pool, o_parts = build_pool(ledger, opp["id"], o_skill, opposed.get("attribute"))
        extra = _opposition(ledger, ent["id"], opp["id"])
        if extra:
            o_parts.append((f"Table ({diff['level']})", extra))
            o_pool = max(0, o_pool + extra)
        o = roll(dice, o_pool)
        r, edge_line = second_chance(ledger, dice, turn, ent["id"], r0, use, r0.hits <= o.hits, on="test")
        success = r.hits > o.hits
        net = r.hits - o.hits
        head = f"[ROLL] {ent['name']}: {what} vs {opp['name']} (opposed)"
        lines += [head,
                  f"  Pool   {fmt_parts(parts)} = {pool}d6",
                  f"  Roll   {r0.faces()} -> {r0.verdict()}"] + ([edge_line] if edge_line else []) + [
                  f"  vs     {fmt_parts(o_parts)} = {o_pool}d6 -> {o.faces()} -> {o.verdict()}"]
        spec = {"skill": skill, "attribute": attribute, "opposed": opposed, "mods": mods, "reason": reason} | shown
    else:
        threshold = max(1, min(THRESHOLD_MAX, int(threshold or 2)))
        shift = diff["threshold"] if ent["kind"] == "pc" else 0
        if shift:
            notes.append(f"table {diff['level']}: threshold {threshold} {shift:+d}")
            threshold = max(1, min(THRESHOLD_MAX + 2, threshold + shift))
        r, edge_line = second_chance(ledger, dice, turn, ent["id"], r0, use, r0.hits < threshold, on="test")
        success = r.hits >= threshold
        net = r.hits - threshold
        head = f"[ROLL] {ent['name']}: {what} (threshold {threshold})"
        lines += [head,
                  f"  Pool   {fmt_parts(parts)} = {pool}d6",
                  f"  Roll   {r0.faces()} -> {r0.verdict()}"] + ([edge_line] if edge_line else [])
        spec = {"skill": skill, "attribute": attribute, "threshold": threshold, "mods": mods, "reason": reason} | shown
    outcome = "SUCCESS" if success else "FAILURE"
    lines.append(f"  {outcome} (net {net:+d})" + (f"   [{'; '.join(notes)}]" if notes else ""))
    lines[1:1] = team["lines"]                            # (who helped, under the head)
    if reason:
        lines.insert(1, f"  Why    {reason}")
    # The Edge on the record, as a Matrix row keeps it (flag #25): a plain row had only the 'edge' event, so read_turn
    # couldn't say which roll the point went on (review 2026-10-28)
    pushed = next((label for label, _ in parts if label.startswith("Edge, pushed")), None)
    if edge_line or pushed:
        spec["edge"] = edge_line.strip().removeprefix("Edge").strip() if edge_line else pushed.removeprefix("Edge, ")
    _record(ledger, turn, ent["id"], spec, r, success, net)
    ledger.log(turn, "test", ent["id"], {"skill": skill, "success": success, "net": net,
                                         "glitch": r.glitch, "crit_glitch": r.crit_glitch} | shown)
    return {"card": "\n".join(lines), "success": success, "hits": r.hits, "net": net,
            "glitch": r.glitch, "critical_glitch": r.crit_glitch}


# ── Combat & damage ─────────────────────────────────────────────────────

UNARMED = {"name": "bare hands", "props": {"dv": None, "skill": "close_combat", "damage_type": "stun"}}


def best_armor(ledger: Ledger, eid: str) -> tuple[int, str]:
    ent = ledger.get(eid) or {}
    if ent.get("kind") in MACHINES or ent.get("kind") == "spirit":
        return int(ledger.stat(eid, "armor", 0)), "Armor" if ent.get("kind") != "spirit" else "Spirit hide"
    best, label = 0, ""
    for item in in_hand(ledger, eid):
        a = int(item["props"].get("armor", 0))
        if a > best:
            best, label = a, item["name"]
    spell = int(ledger.stat(eid, "spell_armor", 0))
    if spell:
        return best + spell, (f"{label} + " if label else "") + f"Armor spell {spell}"
    return best, label


def _apply_boxes(ledger: Ledger, eid: str, boxes: int, dtype: str) -> None:
    if boxes <= 0:
        return
    pmax, smax = monitor_max(ledger, eid)
    if dtype == "stun":
        stun = ledger.stat(eid, "stun_damage") + boxes
        overflow = max(0, stun - smax)
        ledger.set_stat(eid, "stun_damage", min(stun, smax))
        if overflow // 2:
            ledger.add_stat(eid, "physical_damage", overflow // 2)   # every 2 boxes past the track: 1 Physical (p. 170)
    else:
        ledger.add_stat(eid, "physical_damage", boxes)
    # a new set of wounds: first aid and magic can be tried again, a stabilized patient is bleeding again (p. 209), and
    # the rest put in toward healing starts over - "must rest for the entire hour / day" (p. 207; recover)
    for k in ("first_aided", "magic_healed", "stabilized", "stabilize_tries", "rest_minutes"):
        if ledger.stat(eid, k, 0):
            ledger.set_stat(eid, k, 0)


def resist_damage(ledger: Ledger, dice: Dice, turn: int | None, target: str, dv: int, dtype: str,
                  ap: int = 0, resist: str = "body_armor", edge: str | None = None) -> tuple[int, list[str]]:
    """Soak and apply. Returns (boxes taken, card lines). edge: the target's player spends Edge on the soak or the
    drain (a second chance only while damage would still get through - past that, more hits change nothing)."""
    use = edge_use(edge)
    on = "drain" if resist == "drain" else "soak"
    lines = []
    if dtype == "stun" and _is_machine(ledger, target):
        name = ledger.require(target)["name"]
        lines.append(f"  {name} is a machine - stun damage does nothing")
        return 0, lines
    if resist == "none":
        boxes = dv
        lines.append(f"  Damage {dv}{dtype[0].upper()} (unresisted)")
    else:
        if resist == "drain":
            parts = [("Willpower", int(ledger.stat(target, "willpower"))),
                     ("Logic", int(ledger.stat(target, "logic")))]
        else:
            armor, label = best_armor(ledger, target)
            sap = scaled_ap(ap)
            eff = max(0, armor + sap)
            parts = [("Body", int(ledger.stat(target, "body")))]
            if eff:
                parts.append((f"{label} {armor}{f' AP{sap:+d}' if sap else ''}", eff))
            if dtype == "physical" and eff and not _is_machine(ledger, target) and dv < eff * ARMOR_STUN:
                dtype = "stun"                                 # the armor stops it; the impact still hurts
                lines.append(f"  The armor holds: {dv} DV against armor {eff} - it lands as Stun")
        explode, note = push_edge(ledger, turn, target, parts, use, required=False, on=on)
        pool = sum(v for _, v in parts)
        r0 = roll(dice, pool, explode)
        hurts = dv - r0.hits > 0
        r, edge_line = second_chance(ledger, dice, turn, target, r0, use, hurts, useful=hurts, on=on)
        boxes = max(0, dv - r.hits)
        lines.append(f"  Soak   {fmt_parts(parts)} = {pool}d6 -> {r0.faces()} -> {r0.hits} hits")
        lines += [x for x in (note, edge_line) if x]
    _apply_boxes(ledger, target, boxes, dtype)
    name = ledger.require(target)["name"]
    lines.append(f"  {name} takes {boxes} {dtype} -> {condition_line(ledger, target)}")
    ledger.log(turn, "damage", target, {"boxes": boxes, "type": dtype, "status": condition(ledger, target)}
               | ({"resist": "drain"} if resist == "drain" else {}))     # (a caster's own drain: no foe's doing)
    if boxes and _is_machine(ledger, target):
        lines += rigger_feedback(ledger, dice, turn, target, boxes)
    return boxes, lines


def rigger_feedback(ledger: Ledger, dice: Dice, turn: int | None, machine: str, boxes: int) -> list[str]:
    """A rigger jumped into a machine feels its hits: half the boxes (rounded up) as Stun biofeedback, resisted with
    Willpower - and 6 dumpshock if it's destroyed under them (SR5 p. 266, 269)."""
    m = ledger.require(machine)
    rig = ledger.get(m["props"].get("controller") or "")
    if not rig or m["props"].get("control") != "jumped" or condition(ledger, rig["id"]) in OUT:
        return []
    bf = ceil(boxes / 2)
    soak = roll(dice, int(ledger.stat(rig["id"], "willpower", 0)))
    took = max(0, bf - soak.hits)
    _apply_boxes(ledger, rig["id"], took, "stun")
    lines = [f"  Biofeedback: {rig['name']} is jumped in - {bf}S, Willpower {soak.pool}d6 -> {soak.hits}: takes {took} "
             f"-> {condition_line(ledger, rig['id'])}"]
    if condition(ledger, machine) == "destroyed":
        lines.append(f"  DUMPSHOCK: {m['name']} dies with {rig['name']} still inside")
        _, ds = resist_damage(ledger, dice, turn, rig["id"], 6, "stun", resist="drain")
        lines += ["  " + s for s in ds]
        ledger.update_entity(machine, props={**m["props"], "controller": None, "control": None})
    return lines


def smartlink(ledger: Ledger, eid: str, weapon: dict) -> tuple[int, str]:
    """A smartlink with a smartgun: +2 implanted, +1 as gear (SR5 p. 433). Only on guns with a smartgun system."""
    props = weapon.get("props") or {}
    if props.get("skill", "firearms") != "firearms":
        return 0, ""
    if not (props.get("smartgun") or any(k in weapon["name"].lower() for k in SMARTGUNS)):
        return 0, ""
    best = 0
    for item in in_hand(ledger, eid):
        if "smartlink" in item["name"].lower() or item["props"].get("smartlink"):
            best = max(best, 2 if (item["props"].get("augmentation") or item["props"].get("essence")) else 1)
    return best, ("Smartlink" if best else "")


def check_attack(ledger: Ledger, attacker: str, weapon_id: str | None) -> dict | None:
    """Can this attack happen at all? Raises LedgerError if not; returns the weapon (None: unarmed or ramming)."""
    a = ledger.require(attacker)
    if condition(ledger, a["id"]) in OUT:
        raise LedgerError(f"{a['name']} is {condition(ledger, a['id'])} and can't attack.")
    if arriving(a):                                   # a drone still with the courier
        raise LedgerError(f"{a['name']} is {transit_note(ledger, a)} - it can't act yet.")
    if not weapon_id:
        return None
    weapon = ledger.find(weapon_id)
    if weapon is None or not ledger.holds(a["id"], weapon["id"]):
        held = ", ".join(f"{i['name']} [{i['id']}]" for i in in_hand(ledger, a["id"]) if "dv" in i["props"])
        raise LedgerError(f"{a['name']} isn't carrying '{weapon_id}'. Weapons held: {held or 'none'}.")
    if arriving(weapon):
        raise LedgerError(f"{weapon['name']} is {transit_note(ledger, weapon)} - it can't be used yet.")
    if ledger.item_state(a["id"], weapon["id"]).get("cargo"):      # (machines.stow: in the trunk, not on a mount)
        raise LedgerError(f"{weapon['name']} is stowed in {a['name']} as cargo, not on a mount - it can't fire it "
                          "(mount_weapon fits a gun).")
    if "dv" not in weapon["props"]:
        raise LedgerError(f"'{weapon['name']}' is not a weapon.")
    if weapon["props"].get("explosive"):
        raise LedgerError(f"{weapon['name']} is an explosive - use the explode tool (who's how close, what space).")
    return weapon


# What one attack action is (SR5 p. 165-167) - shown on the card, so the table can see why a phase is gone.
ATTACK_ACTION = {"firearms": "Simple: Fire Weapon", "throwing": "Simple: Throw Weapon",
                 "close_combat": "Complex: Melee Attack", "piloting": "Complex: Ram"}
MELEE = ("close_combat",)
OFF_HAND = -2                     # attacking with the off hand: the whole pool for two guns (p. 178), the off hand's
                                  # strikes for two blades (p. 187)


def max_strikes(ledger: Ledger, eid: str, skill: str) -> tuple[int, int]:
    """(How many attacks one Action Phase holds with Multiple Attacks, the skill rating that sets it): half the Combat
    skill, rounded up (SR5 p. 196; the book rounds up unless it says otherwise, p. 48) - Close Combat 5 makes 3,
    Firearms 2 makes 1 - never under 1. A machine fires once."""
    if _is_machine(ledger, eid):
        return 1, 0
    rating = int(ledger.stat(eid, skill, 0))
    return max(1, ceil(rating / 2)), rating


def split_pool(n: int, k: int) -> list[int]:
    """A pool split as evenly as possible, the larger shares first: 13 three ways is 5 / 4 / 4 (p. 196)."""
    return [n // k + (1 if i < n % k else 0) for i in range(k)]


def check_push(ledger: Ledger, eid: str, use: str | None) -> None:
    """A pushed roll needs a point to spend: raises (as spend_edge would) before anything else is spent on it."""
    if edge_use(use) == "push" and int(ledger.stat(eid, "edge_points")) <= 0:
        raise LedgerError(f"{ledger.require(eid)['name']} has no Edge points left this session.")


def plan_strikes(ledger: Ledger, attacker: str, strikes: list[dict], thrown: bool = False,
                 edge: str | None = None) -> dict:
    """Everything one attack action needs settled before anything is spent (a round, Edge, a step toward the target):
    raises LedgerError on what can't happen. strikes: [{target, weapon_id, defense_edge, soak_edge}], the first with
    the main hand's weapon. Multiple Attacks (SR5 p. 196): one skill for every strike and at most half of it in
    strikes; a gun fires once a phase, so a second shot needs a gun in each hand (p. 165) - two hands, two weapons; a
    throw needs that many in hand (p. 166); a machine fires once. thrown (or a throwing weapon): Throwing + Agility at
    range, never a gun. edge: the attacker's - a push needs a point left. Every strike's Edge is a mode edge_use
    knows. Review: a bad soak_edge on the second strike raised after the first had landed (damage on the ledger, no
    card, no action spent - a retry hit twice), and a push with no Edge left took a round from both guns first.
    Returns {skill, weapons, thrown, off_hand ('pool' | 'strike' | None), cap, rating}."""
    a = ledger.require(attacker)
    check_push(ledger, a["id"], edge)
    for s in strikes:                                 # (edge_use raises on a mode it doesn't know)
        for field_ in ("defense_edge", "soak_edge"):
            edge_use(s.get(field_))
    weapons, skills = [], []
    for s in strikes:
        w = check_attack(ledger, attacker, s.get("weapon_id"))
        if w is None:                                 # no weapon: bare hands - or, for a machine, it rams
            w = ({"name": "ramming", "props": {"dv": None, "skill": "piloting", "damage_type": "physical"}}
                 if a["kind"] in MACHINES else UNARMED)
        skill = w["props"].get("skill", "firearms")
        if thrown or skill == "throwing":
            if not w.get("id"):
                raise LedgerError("Nothing to throw - give the weapon_id of what's thrown.")
            if skill == "firearms" or "ammo_capacity" in w["props"]:
                raise LedgerError(f"{w['name']} is a gun - it's fired, not thrown (thrown is for knives, shuriken, "
                                  "a hatchet...).")
            skill = "throwing"
        weapons.append(w)
        skills.append(skill)
    skill, n = skills[0], len(strikes)
    if any(x != skill for x in skills):
        raise LedgerError("Several strikes in one Action Phase use one skill (Multiple Attacks, SR5 p. 196) - this "
                          f"call mixes {' and '.join(sorted({nice(x) for x in skills}))}. Make them separate attack calls.")
    cap, rating = max_strikes(ledger, attacker, skill)
    if n > cap:
        why = ("a machine fires once a phase" if a["kind"] in MACHINES
               else f"half {nice(skill)} {rating}, rounded up - SR5 p. 196")
        raise LedgerError(f"{a['name']} can make at most {cap} attack{'s' * (cap != 1)} in one Action Phase ({why}); "
                          f"this call has {n}. The rest is another attack call - another Action Phase.")
    ids = [w.get("id") for w in weapons]
    distinct = list(dict.fromkeys(ids))
    if len(distinct) > 2:
        raise LedgerError("Two hands, two weapons at most in one Action Phase.")
    for wid in distinct:
        w, k = weapons[ids.index(wid)], ids.count(wid)
        if skill == "firearms" and k > 1:
            raise LedgerError(f"{w['name']} is named for {k} strikes - a gun fires once a phase (single shot or "
                              "semi-auto, SR5 p. 165). A second shot needs a gun in each hand (a weapon_id per strike "
                              "in more) or the next Action Phase.")
        if skill == "throwing":
            held = next((i["qty"] for i in ledger.holdings(attacker) if i["id"] == wid), 0)
            if k > held:
                raise LedgerError(f"{a['name']} has {held} {w['name']} to throw - {k} throws named.")
        if skill == "firearms" and wid and "ammo_capacity" in w["props"]:
            loaded = int(ledger.item_state(attacker, wid).get("loaded", w["props"]["ammo_capacity"]))
            if loaded <= 0:
                raise LedgerError(f"{w['name']} is empty. {a['name']} needs to reload (use the reload tool).")
    off = ("strike" if skill in MELEE else "pool") if len(distinct) == 2 else None
    return {"skill": skill, "weapons": weapons, "thrown": skill == "throwing", "off_hand": off, "cap": cap,
            "rating": rating}


def _defense(ledger: Ledger, dice: Dice, turn: int | None, a: dict, t: dict, s: dict,
             level: str) -> tuple[list, Roll, str | None, list[str]]:
    """One strike's defense test: (parts, roll, an Edge line, notes). The helpless roll nothing and the unaware only
    their cover (p. 189); a machine dodges with Pilot + Evasion (or its driver), anyone else with Reaction + Intuition -
    wounds + cover. s['defend'] adds what the fight does to it - the -1 for each defense since they last acted, an
    interrupt they pay Initiative for (encounters.defense_parts); then the target's own Edge."""
    t_status, away = condition(ledger, t["id"]), limp(ledger, t)
    if t_status in OUT or away:
        return [(away + ", body limp" if away and t_status not in OUT else "Helpless", 0)], Roll(0, []), None, []
    if s.get("unaware"):                              # never saw it coming: only cover stands between them
        d_parts = [("Unaware - no dodge", 0)] + list(s.get("cover") or [])
        return d_parts, roll(dice, max(0, sum(v for _, v in d_parts))), None, []
    if t["kind"] in MACHINES:                         # a drone dodges with Pilot + Evasion (or its driver)
        _, d_parts = machine_pool(ledger, t, "evasion")
    else:
        d_parts = [("Reaction", int(ledger.stat(t["id"], "reaction"))),
                   ("Intuition", int(ledger.stat(t["id"], "intuition")))]
        pen = wound_penalty(ledger, t["id"])
        if pen:
            d_parts.append(("Wounds", -pen))
    d_parts += list(s.get("cover") or [])
    extra_def = _opposition(ledger, a["id"], t["id"])           # an NPC dodging a PC
    if extra_def:
        d_parts.append((f"Table ({level})", extra_def))
    notes = []
    if s.get("defend"):
        more, notes = s["defend"](t["id"], s.get("melee", False))
        d_parts += more
    d_explode, d_note = push_edge(ledger, turn, t["id"], d_parts, s.get("d_use"), required=False, on="dodge")
    return d_parts, roll(dice, max(0, sum(v for _, v in d_parts)), d_explode), d_note, notes


def _thrown_lands(ledger: Ledger, a: dict, weapons: list[dict], drop_at: str | None) -> list[str]:
    """A thrown weapon leaves the hand: it lies where the fight is - the scene's place - until someone picks it up
    (transfer_item). With no place on file it stays on the sheet, and the card says so, so nothing silently vanishes.
    Live T172/T174: Lou 'threw' his combat knife twice and never let go of it."""
    out = []
    for wid, k in {w["id"]: sum(1 for x in weapons if x["id"] == w["id"]) for w in weapons}.items():
        name = ledger.require(wid)["name"].split("'s ", 1)[-1] + (f" x{k}" if k > 1 else "")
        if not drop_at:
            out.append(f"  Thrown {name}: no place on file for it to land - it stays on {a['name']}'s sheet "
                       "(transfer_item moves it when the story says where)")
            continue
        state = ledger.take(a["id"], wid, k)
        ledger.give(drop_at, wid, k, state)
        out.append(f"  Thrown {name} now {'lie' if k > 1 else 'lies'} at {ledger.require(drop_at)['name']} - "
                   "picked back up with transfer_item")
    return out


def attack(ledger: Ledger, dice: Dice, turn: int | None, attacker: str, target: str,
           weapon_id: str | None = None, modifiers=None, reason: str = "", use_edge: bool = False,
           situation=None, cover=None, edge: str | None = None, defense_edge: str | None = None,
           soak_edge: str | None = None, unaware: bool = False, defend=None, thrown: bool = False,
           drop_at: str | None = None, more: list[dict] | None = None) -> dict:
    """One attack action. situation / cover: engine-computed parts from the battlefield (range on the attack, cover on
    the defense) - not the GM's modifiers, so they don't count against the modifier caps. edge: the attacker's player
    spends Edge; defense_edge / soak_edge: the target's player does, on the dodge / the soak. unaware: the target doesn't
    see it coming (ambushed and caught flat-footed, a sniper they never spotted) - no dodge, only cover (SR5 p. 189).
    defend(target, melee) -> (parts, notes): what the fight adds to a real defense test. thrown: Throwing + Agility, and
    the weapon lands at drop_at (the scene's place). more: further strikes in the same Action Phase - Multiple Attacks
    (p. 196), each {target, weapon_id, situation, cover, unaware, defense_edge, soak_edge, defend}: the pool is built
    once with every modifier and pushed Edge, split as evenly as it goes (13 -> 5 / 4 / 4), each strike adds its own
    range after the split (the book has the range in before it - this counts it once, per target) and is defended and
    resolved on its own; one Second Chance covers every share. Live T171/T175: Quiet Lou swung three full 13-dice
    pools in one round, each at a fresh defense."""
    use = edge_use(edge or use_edge)
    a = ledger.require(attacker)
    strikes = [{"target": target, "weapon_id": weapon_id, "situation": situation, "cover": cover, "unaware": unaware,
                "defense_edge": defense_edge, "soak_edge": soak_edge, "defend": defend}]
    strikes += [dict(s, weapon_id=s.get("weapon_id") or weapon_id) for s in more or []]
    for s in strikes:
        s["t"], s["d_use"] = ledger.require(s["target"]), edge_use(s.get("defense_edge"))
    plan = plan_strikes(ledger, a["id"], strikes, thrown, use)     # (everything checked before anything's spent)
    skill, n, w0 = plan["skill"], len(strikes), plan["weapons"][0]
    for s, w in zip(strikes, plan["weapons"]):
        s["weapon"], s["melee"] = w, skill in MELEE
        s["off"] = plan["off_hand"] == "strike" and w.get("id") != w0.get("id")
        if skill == "firearms" and "ammo_capacity" in w["props"]:              # a round from each gun
            state = ledger.item_state(a["id"], w["id"])
            state["loaded"] = int(state.get("loaded", w["props"]["ammo_capacity"])) - 1
            ledger.set_item_state(a["id"], w["id"], state)

    base, parts = build_pool(ledger, a["id"], skill, "agility", use_gear=False)   # (a drone: Pilot + Targeting)
    if w0["props"].get("accuracy"):
        parts.append((f"{w0['name']} accuracy", int(w0["props"]["accuracy"])))
    if a["kind"] not in MACHINES:
        link, label = smartlink(ledger, a["id"], w0)
        if link:
            parts.append((label, link))
    mods, notes = clamp_mods(modifiers)
    parts += mods
    if plan["off_hand"] == "pool":
        parts.append(("Off-hand weapon", OFF_HAND))
    if n == 1:
        parts += list(situation or [])
    explode, _ = push_edge(ledger, turn, a["id"], parts, use, on="attack")       # (Edge goes in before a split)
    level = table_difficulty(ledger)["level"]
    total = max(0, sum(v for _, v in parts))
    shares = split_pool(total, n)

    if a["kind"] in MACHINES:                         # say who's really rolling
        drv = ledger.get(a["props"].get("controller") or "")
        how = (f"driven by {drv['name']}: {nice(DRIVER_SKILL.get(skill, 'piloting'))} + "
               f"{'Reaction' if a['props'].get('control') == 'jumped' else 'Logic'}") if drv else "Pilot + autosoft"
    else:
        how = f"{nice(skill)} + Agility"
    if n == 1:
        lines = [f"[ROLL] {a['name']} attacks {strikes[0]['t']['name']} with {w0['name']} ({how})"]
    else:
        names = " and ".join(dict.fromkeys(w["name"] for w in plan["weapons"]))
        lines = [f"[ROLL] {a['name']} attacks {n} times with {names} ({how}) - Multiple Attacks"]
    if reason:
        lines.append(f"  Why    {reason}")
    if n > 1:
        lines.append(f"  Pool   {fmt_parts(parts)} = {total}d6, split {' / '.join(map(str, shares))} "
                     f"(at most {plan['cap']}: half {nice(skill)} {plan['rating']})")
    out, paid = [], False
    for i, s in enumerate(strikes):
        t = s["t"]
        if n == 1:
            s_parts = parts
        else:
            s_parts = [("Split share", shares[i])] + list(s.get("situation") or [])
            if s["off"]:
                s_parts.append(("Off-hand weapon", OFF_HAND))
            lines.append(f"  Strike #{i + 1} vs {t['name']}" + (f" with {s['weapon']['name']}" if plan["off_hand"]
                                                                  else ""))
        extra_atk = _opposition(ledger, t["id"], a["id"])          # an NPC shooting at a PC
        if extra_atk:
            s_parts.append((f"Table ({level})", extra_atk))
        pool = max(0, sum(v for _, v in s_parts))
        ra0 = roll(dice, pool, explode)
        d_parts, rd0, d_note, d_notes = _defense(ledger, dice, turn, a, t, s, level)
        ra, a_line = second_chance(ledger, dice, turn, a["id"], ra0, use, ra0.hits <= rd0.hits, on="attack",
                                   free=paid)                     # (a miss)
        paid = paid or ra is not ra0
        hit_now = ra.hits > rd0.hits                  # a dodge's hits only count against a shot that lands
        rd, d_line = second_chance(ledger, dice, turn, t["id"], rd0, s["d_use"], hit_now, useful=hit_now, on="dodge")
        lines += [f"  Attack {fmt_parts(s_parts)} = {pool}d6 -> {ra0.faces()} -> {ra0.verdict()}"]
        lines += [a_line] if a_line else []
        lines += [f"  Defend {fmt_parts(d_parts)} = {rd0.pool}d6 -> {rd0.faces()} -> {rd0.hits} hit{'s' * (rd0.hits != 1)}"]
        lines += [x for x in (d_note, d_line) if x]
        if d_notes:
            lines.append(f"  [{'; '.join(d_notes)}]")
        props = s["weapon"]["props"]
        dtype = props.get("damage_type", "physical")
        dv_base = props["dv"] if props.get("dv") is not None else ceil(
            ledger.stat(a["id"], "body" if a["kind"] in MACHINES else "strength", 2) / 2)
        ap = int(props.get("ap", 0))
        hit, net, boxes = ra.hits > rd.hits, ra.hits - rd.hits, 0
        if hit:
            dv = min(MAX_DV, int(dv_base) + net)
            lines.append(f"  HIT (net {net}). Damage {dv_base}+{net} = {dv}{dtype[0].upper()}"
                         + (f", AP {scaled_ap(ap):+d}" if scaled_ap(ap) else ""))
            boxes, soak_lines = resist_damage(ledger, dice, turn, t["id"], dv, dtype, ap, edge=s.get("soak_edge"))
            lines += soak_lines
        else:                   # (live T170, flag #65: a 0-hit stab on an unconscious man read as a 0-0 tie)
            lines.append("  MISS" + (" (no hits - with no defense it's a Success Test, SR5 p. 189)" if not rd0.dice
                                     else " (ties go to the defender)" if net == 0 else ""))
        spec = ({"kind": "attack", "target": t["id"], "weapon": s["weapon"].get("id"), "mods": mods, "reason": reason}
                | ({"strike": i + 1, "of": n} if n > 1 else {}) | ({"thrown": True} if plan["thrown"] else {}))
        _record(ledger, turn, a["id"], spec, ra, hit, net)
        status = condition(ledger, t["id"])
        ledger.log(turn, "attack", a["id"], {"target": t["id"], "hit": hit, "boxes": boxes, "target_status": status}
                   | ({"thrown": True} if plan["thrown"] else {}))
        out.append({"target": t["id"], "hit": hit, "net": net, "boxes": boxes, "target_status": status,
                    "glitch": ra.glitch, "critical_glitch": ra.crit_glitch})
    guns = list(dict.fromkeys(w["id"] for w in plan["weapons"] if skill == "firearms" and "ammo_capacity" in w["props"]))
    if guns:
        ammo = [(ledger.require(g)["name"].split("'s ", 1)[-1],
                 f"{ledger.item_state(a['id'], g).get('loaded')}/{ledger.require(g)['props']['ammo_capacity']}")
                for g in guns]
        lines.append("  Ammo   " + (ammo[0][1] if len(ammo) == 1 else " · ".join(f"{nm} {v}" for nm, v in ammo)))
    if plan["thrown"]:
        lines += _thrown_lands(ledger, a, plan["weapons"], drop_at)
    if notes:
        lines.append(f"  [{'; '.join(notes)}]")
    first = out[0]
    return {"card": "\n".join(lines), "hit": first["hit"], "net": first["net"], "boxes": first["boxes"],
            "target_status": first["target_status"], "glitch": first["glitch"],
            "critical_glitch": first["critical_glitch"], "strikes": out, "skill": skill}


def apply_damage(ledger: Ledger, dice: Dice, turn: int | None, target: str, dv: int, dtype: str,
                 resist: str = "body_armor", ap: int = 0, reason: str = "", edge: str | None = None) -> dict:
    t = ledger.require(target)
    if dtype not in ("physical", "stun"):
        raise LedgerError("damage_type must be 'physical' or 'stun'.")
    if resist not in RESISTS:
        raise LedgerError(f"resist must be one of {RESISTS}.")
    dv = max(1, min(MAX_DV, int(dv)))
    lines = [f"[DAMAGE] {t['name']}: {dv}{dtype[0].upper()}" + (f" - {reason}" if reason else "")]
    boxes, soak = resist_damage(ledger, dice, turn, t["id"], dv, dtype, ap, resist, edge)
    lines += soak
    return {"card": "\n".join(lines), "boxes": boxes, "status": condition(ledger, t["id"])}


def heal(ledger: Ledger, turn: int | None, target: str, dtype: str, boxes: int, reason: str = "",
         how: str = "care") -> dict:
    """Take boxes off. how: 'magic' (the Heal spell: Physical only, once per set of wounds - SR5 p. 206) or 'care'
    (anything else the story provides: a street doc, a hospital bed, a stim patch; the GM says what)."""
    t = ledger.require(target)
    key = "physical_damage" if dtype == "physical" else "stun_damage"
    if how == "magic":
        if dtype != "physical":
            raise LedgerError("Magic heals Physical damage only - Stun needs rest, first aid or stims.")
        if ledger.stat(t["id"], "magic_healed", 0):
            raise LedgerError(f"{t['name']}'s wounds have already been healed by magic - only new wounds take another Heal.")
        ledger.set_stat(t["id"], "magic_healed", 1)
    boxes = max(0, min(12, int(boxes)))
    cur = ledger.stat(t["id"], key)
    healed = min(cur, boxes)
    ledger.set_stat(t["id"], key, cur - healed)
    ledger.log(turn, "heal", t["id"], {"boxes": healed, "type": dtype, "reason": reason, "how": how})
    tail = f" ({reason})" if reason and how == "care" else ""
    return {"card": f"[HEAL] {t['name']} recovers {int(healed)} {dtype}{tail} -> {condition_line(ledger, t['id'])}",
            "healed": healed}


def first_aid(ledger: Ledger, dice: Dice, turn: int | None, healer: str, target: str, dtype: str,
              reason: str = "") -> dict:
    """First Aid + Logic (2): each net hit heals a box, up to the healer's First Aid rating; once per set of wounds,
    and not on wounds magic has healed (SR5 p. 205-206). A medkit is assumed; without one it's -2. On someone dying
    and still bleeding it's the stabilization test instead (stabilize)."""
    h, t = ledger.require(healer), ledger.require(target)
    _can_treat(ledger, h, t)
    if condition(ledger, t["id"]) == "dying" and not ledger.stat(t["id"], "stabilized", 0):
        return stabilize(ledger, dice, turn, h["id"], t["id"], reason)
    if dtype not in ("physical", "stun"):
        raise LedgerError("damage_type must be 'physical' or 'stun'.")
    if ledger.stat(t["id"], "first_aided", 0):
        raise LedgerError(f"{t['name']} has had first aid for these wounds - now it's rest, a doctor or magic.")
    if ledger.stat(t["id"], "magic_healed", 0):
        raise LedgerError(f"{t['name']}'s wounds were healed by magic - first aid can't add to that.")
    n, parts = build_pool(ledger, h["id"], "first_aid")
    if not gear_bonus(ledger, h["id"], "first_aid")[0]:
        parts.append(("No medkit", -2))
        n = max(0, sum(v for _, v in parts))
    r = roll(dice, n)
    cap = int(ledger.stat(h["id"], "first_aid", 0))
    net = max(0, r.hits - 2)
    lines = [f"[HEAL] {h['name']} gives {t['name']} first aid ({dtype}; First Aid + Logic, threshold 2)"
             + (f" - {reason}" if reason else ""),
             f"  Pool   {fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()}"]
    if r.crit_glitch:
        worse = ceil(dice.roll(1)[0] / 2)
        _apply_boxes(ledger, t["id"], worse, dtype)
        lines.append(f"  CRITICAL GLITCH: it makes things worse - {worse} more {dtype} -> {condition_line(ledger, t['id'])}")
    else:
        key = "physical_damage" if dtype == "physical" else "stun_damage"
        cur = ledger.stat(t["id"], key)
        healed = int(min(cur, net, cap))
        ledger.set_stat(t["id"], key, cur - healed)
        why = ("untrained - First Aid 0 can only diagnose" if not cap else
               f"{net} net hit{'s' * (net != 1)}" + (f", capped at First Aid {cap}" if net > cap else ""))
        lines.append(f"  {t['name']} recovers {healed} {dtype} ({why}) -> {condition_line(ledger, t['id'])}")
    ledger.set_stat(t["id"], "first_aided", 1)
    ledger.log(turn, "heal", t["id"], {"how": "first_aid", "by": h["id"], "type": dtype})
    return {"card": "\n".join(lines)}


STABILIZE = 3                    # First Aid + Logic (3) stops a dying character's bleeding (SR5 p. 209)


def _can_treat(ledger: Ledger, h: dict, t: dict) -> None:
    """A medic has to be able to act (OUT can't, as for a test or an attack): never the dying patient themselves, and
    never someone unconscious. Turned away before any roll - so an impossible try doesn't count toward the next
    medic's -2 (review: heal first_aid with no healer_id had dying Joey try to stabilize himself, and the failure put
    Kaz's real try at -2)."""
    if h["id"] == t["id"] and condition(ledger, t["id"]) in OUT:
        raise RulesRefusal(f"{t['name']} is {condition(ledger, t['id'])} and can't treat themselves - name who does "
                           "(healer_id), someone awake beside them.")
    if condition(ledger, h["id"]) in OUT:
        raise RulesRefusal(f"{h['name']} is {condition(ledger, h['id'])} and can't give first aid - name someone "
                           "awake (healer_id).")


def stabilize(ledger: Ledger, dice: Dice, turn: int | None, healer: str, target: str, reason: str = "") -> dict:
    """Someone dying and bleeding: First Aid + Logic (3) - success stops the bleeding (no more boxes every Body
    minutes: bleed), and first aid proper can follow (SR5 p. 209). Every try after the first is at a cumulative -2;
    -2 without a medkit. It isn't first aid's once-per-wounds test, so a failed try can be tried again. Live T170:
    'will bleed out within minutes' said the narration, and nothing in the engine could stop it - or make it so. The
    medic must be able to act (_can_treat)."""
    h, t = ledger.require(healer), ledger.require(target)
    _can_treat(ledger, h, t)
    n, parts = build_pool(ledger, h["id"], "first_aid")
    if not gear_bonus(ledger, h["id"], "first_aid")[0]:
        parts.append(("No medkit", -2))
    tries = int(ledger.stat(t["id"], "stabilize_tries", 0))
    if tries:
        parts.append(("Tried before", -2 * tries))
    n = max(0, sum(v for _, v in parts))
    r = roll(dice, n)
    ok = r.hits >= STABILIZE and not r.crit_glitch
    lines = [f"[HEAL] {h['name']} tries to stabilize {t['name']} (dying; First Aid + Logic, threshold {STABILIZE})"
             + (f" - {reason}" if reason else ""),
             f"  Pool   {fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()}"]
    if ok:
        for k, v in (("stabilized", 1), ("stabilize_tries", 0), ("bleed_minutes", 0)):
            ledger.set_stat(t["id"], k, v)
        lines.append(f"  STABILIZED: the bleeding stops -> {condition_line(ledger, t['id'])}")
    else:
        ledger.set_stat(t["id"], "stabilize_tries", tries + 1)
        lines.append(f"  NOT STABILIZED: still losing a box every {max(1, int(ledger.stat(t['id'], 'body', 2)))} "
                     f"minutes - the next try is at -{2 * (tries + 1)}")
    ledger.log(turn, "heal", t["id"], {"how": "stabilize", "by": h["id"], "ok": ok})
    return {"card": "\n".join(lines), "stabilized": ok}


def bleed(ledger: Ledger, turn: int | None, eid: str, minutes: int) -> str | None:
    """Dying and not stabilized: a box of Physical every (Body) minutes of story time - blood loss, shock - until
    someone stabilizes them or they die (SR5 p. 170, 209). Minutes short of a box carry over to the next time the clock
    moves. Returns the card, or None if nothing happened. Live: Hollow Joe lay dying at exactly monitor + Body from T171
    to T188, eleven story hours, and the world paid a clinic for his care."""
    ent = ledger.require(eid)
    if ent["kind"] in MACHINES:
        return None
    if condition(ledger, eid) != "dying" or ledger.stat(eid, "stabilized", 0):
        if ledger.stat(eid, "bleed_minutes", 0):
            ledger.set_stat(eid, "bleed_minutes", 0)
        return None
    body = max(1, int(ledger.stat(eid, "body", 2)))
    boxes, left = divmod(int(ledger.stat(eid, "bleed_minutes", 0)) + max(0, int(minutes)), body)
    pmax, _ = monitor_max(ledger, eid)
    boxes = min(boxes, pmax + body + 1 - int(ledger.stat(eid, "physical_damage")))   # (no further than dead)
    ledger.set_stat(eid, "bleed_minutes", left)
    if boxes <= 0:
        return None
    ledger.add_stat(eid, "physical_damage", boxes)          # (not _apply_boxes: bleeding isn't a new set of wounds)
    now = condition(ledger, eid)
    ledger.log(turn, "damage", eid, {"boxes": boxes, "type": "physical", "status": now, "how": "bleeding",
                                     "minutes": int(minutes)})
    line = (f"[DAMAGE] {ent['name']} {'bleeds to death' if now == 'dead' else 'is bleeding out'}: {boxes} "
            f"box{'es' * (boxes != 1)} in {int(minutes)} minutes (a box every Body {body} minutes until someone "
            f"stabilizes them, SR5 p. 170) -> {condition_line(ledger, eid)}")
    if now == "dead" and ent["kind"] == "pc":
        line += f"\n  Not dead yet? {ent['name']}'s player can burn Edge to live (the edge tool, burn)."
    return line


def rest(ledger: Ledger, dice: Dice, turn: int | None, target: str, dtype: str, periods: int,
         reason: str = "", most: int | None = None) -> dict:
    """Natural recovery (SR5 p. 207): Stun heals by the hour (Body + Willpower), Physical by the day (Body x 2) - and
    only once the Stun is gone. It's an Extended Test: one die fewer each roll after the first (p. 48). When the dice
    run out with time still to rest, a fresh test starts at the full pool - healing doesn't stop because one test did
    (review: a single test running dry dropped the rest of a two-week skip, and a quarter of the hurt came out of it
    still stunned, their Physical untouched, while thirty days healed everyone). most: the periods one call may take
    (the heal tool's 24 hours / 30 days). Returns the card, the periods it took and the boxes healed."""
    t = ledger.require(target)
    key = "physical_damage" if dtype == "physical" else "stun_damage"
    if condition(ledger, t["id"]) == "dying" and not ledger.stat(t["id"], "stabilized", 0):
        raise LedgerError(f"{t['name']} is dying - stabilize them first (heal first_aid: First Aid + Logic "
                          f"({STABILIZE})).")
    if dtype == "physical" and ledger.stat(t["id"], "stun_damage", 0):
        raise LedgerError(f"{t['name']} still has Stun damage - it heals first (rest by the hour).")
    unit, top = ("day", 30) if dtype == "physical" else ("hour", 24)
    periods = max(1, min(most or top, int(periods or 1)))
    body = int(ledger.stat(t["id"], "body", 2))
    pool = max(1, body * 2 if dtype == "physical" else body + int(ledger.stat(t["id"], "willpower", 2)))
    cur, total, spent, tests, n = ledger.stat(t["id"], key), 0, 0, 1, pool
    while spent < periods and total < cur:
        if n <= 0:                                   # (out of dice, time left: a fresh test)
            tests, n = tests + 1, pool
        total += roll(dice, n).hits
        spent, n = spent + 1, n - 1
    healed = int(min(cur, total))
    ledger.set_stat(t["id"], key, cur - healed)
    ledger.log(turn, "heal", t["id"], {"how": "rest", "type": dtype, "periods": spent, "tests": tests})
    dice_line = (f"{pool}d6 {'an' if unit == 'hour' else 'a'} {unit}" if spent <= 1
                 else f"{pool}d6 the first {unit}, a die fewer each after"
                 + (", afresh each time the dice ran out" if tests > 1 else ""))
    return {"card": f"[HEAL] {t['name']} rests {spent} {unit}{'s' * (spent != 1)} ({dice_line}"
                    + (f"; {reason}" if reason else "") + f"): recovers {healed} {dtype} -> {condition_line(ledger, t['id'])}",
            "spent": spent, "healed": healed}


MEND_ALL = 30 * 24 * 60          # a month or more of story time off: everyone's whole again, no dice to roll
                                 # (an Extended Test runs out of dice long before that, p. 48)


def recover(ledger: Ledger, dice: Dice, turn: int | None, eid: str, minutes: int, why: str = "") -> list[str]:
    """Natural recovery over story time that passed (SR5 p. 207): the Stun by the hour, then - once it's gone - the
    Physical by the day, out of the hours left. The time adds up across turns, the way bleeding does: what a skip
    leaves short of an hour (Stun) or a day (Physical) waits in `rest_minutes` for the next one, and new wounds start
    it over (_apply_boxes). A month or more simply heals everything. The dying who aren't stabilized don't mend (they
    bleed). Returns the [HEAL] cards. Live T175-T178: eleven story hours went by and Magic still carried 7 boxes of
    drain, -2 to every pool, because only a `heal rest` call could heal it. Review: a story week told a morning and an
    evening at a time - no skip a whole day - never healed a box of Physical."""
    ent = ledger.require(eid)
    if ent["kind"] not in ("pc", "npc"):
        return []
    status = condition(ledger, eid)
    if status == "dead" or (status == "dying" and not ledger.stat(eid, "stabilized", 0)):
        return []
    carried = int(ledger.stat(eid, "rest_minutes", 0))
    if not (ledger.stat(eid, "stun_damage") or ledger.stat(eid, "physical_damage")):
        if carried:
            ledger.set_stat(eid, "rest_minutes", 0)
        return []
    if minutes >= MEND_ALL:
        for k in ("stun_damage", "physical_damage", "rest_minutes"):
            ledger.set_stat(eid, k, 0)
        ledger.log(turn, "heal", eid, {"how": "rest", "full": True, "minutes": int(minutes)})
        return [f"[HEAL] {ent['name']} has weeks to mend" + (f" ({why})" if why else "")
                + f": fully healed -> {condition_line(ledger, eid)}"]
    total = carried + max(0, int(minutes))
    if carried and why:
        h = total // 60
        why += f" - {'an hour' if h == 1 else f'{h} hours' if h < 48 else f'{h // 24} days'} of rest in all"
    out, hours = [], total // 60
    if ledger.stat(eid, "stun_damage") and hours:
        res = rest(ledger, dice, turn, eid, "stun", hours, why, most=hours)
        hours -= res["spent"]
        out.append(res["card"])
    if ledger.stat(eid, "physical_damage") and not ledger.stat(eid, "stun_damage") and hours >= 24:
        res = rest(ledger, dice, turn, eid, "physical", hours // 24, why, most=hours // 24)
        hours -= 24 * res["spent"]
        out.append(res["card"])
    whole = not (ledger.stat(eid, "stun_damage") or ledger.stat(eid, "physical_damage"))
    left = 0 if whole else hours * 60 + total % 60
    if left != carried:
        ledger.set_stat(eid, "rest_minutes", left)
    return out


def check_finish(ledger: Ledger, attacker: str, target: str, against=()) -> str:
    """Can attacker give target a coup de grace? Their condition as it stands ('unconscious', 'dying'...), or a
    RulesRefusal saying why not: not living, already dead, can still fight back, or someone still stands against the
    attacker (`against`)."""
    a, t = ledger.require(attacker), ledger.require(target)
    status = condition(ledger, t["id"])
    if t["kind"] not in ("pc", "npc", "spirit"):
        raise RulesRefusal(f"{t['name']} is " + ("a machine" if t["kind"] in MACHINES else f"a {t['kind']}")
                           + " - a coup de grace is for the living. Attack it instead.")
    if status == "dead":
        raise RulesRefusal(f"{t['name']} is already dead.")
    if not helpless(ledger, t["id"]):
        raise RulesRefusal(f"{t['name']} can still fight back ({status}) - finish is only for someone helpless "
                           "(unconscious, dying, or a body left limp by VR, astral projection or a jumped-in rig). "
                           "Attack them instead.")
    standing = [ledger.require(x)["name"] for x in against if x not in (a["id"], t["id"])]
    if standing:
        raise RulesRefusal(f"Not while {', '.join(standing)} still stand{'s' * (len(standing) == 1)} against "
                           f"{a['name']} - a coup de grace waits until nobody does. Attack, or deal with them first.")
    return status


def finish(ledger: Ledger, turn: int | None, attacker: str, target: str, weapon_id: str | None = None,
           reason: str = "", against=(), more=()) -> dict:
    """A coup de grace: a deliberate killing blow on a helpless, living target (unconscious, dying, or a body left limp
    by VR, astral projection or a jumped-in rig), once nobody stands against the attacker (`against`: who still does,
    from the fight) - it's certain, so no roll (SR5 p. 44), and the target dies outright. The table's ruling
    (2026-10-24). Live T170/T171 (flag #65): 'kill the survivors' went to Magic's 1-die knife, which missed twice
    against men who couldn't move, and Lou's two cuts then left Hollow Joe dying at exactly monitor + Body. Refusals
    are RulesRefusals - the table's rule, for the GM to work with, not an engine fault. more: the other helpless the
    same call finishes - every one is checked (and a gun's rounds counted) before anyone dies; review: 'kill the
    survivors' with `more` killed the first and silently left the second unconscious."""
    a = ledger.require(attacker)
    weapon = check_attack(ledger, a["id"], weapon_id)
    ids = list(dict.fromkeys([ledger.require(target)["id"]] + [ledger.require(m)["id"] for m in more or ()]))
    was = {tid: check_finish(ledger, a["id"], tid, against) for tid in ids}
    if weapon and "ammo_capacity" in weapon["props"]:
        state = ledger.item_state(a["id"], weapon["id"])
        loaded = int(state.get("loaded", weapon["props"]["ammo_capacity"]))
        if loaded < len(ids):
            raise LedgerError(f"{weapon['name']} is empty. {a['name']} needs to reload (use the reload tool)."
                              if loaded <= 0 else f"{weapon['name']} has {loaded} round{'s' * (loaded != 1)} loaded - "
                              f"{len(ids)} coups de grace take {len(ids)}. Reload, or finish fewer.")
        ledger.set_item_state(a["id"], weapon["id"], {**state, "loaded": loaded - len(ids)})
    names = [ledger.require(x)["name"] for x in ids]
    lines = [f"[ROLL] {a['name']} finishes {names[0]} - a coup de grace on a helpless target" if len(ids) == 1 else
             f"[ROLL] {a['name']} finishes {', '.join(names[:-1])} and {names[-1]} - a coup de grace on each, "
             "helpless all"]
    if reason:
        lines.append(f"  Why    {reason}")
    for tid in ids:
        t, status = ledger.require(tid), was[tid]
        pmax, _ = monitor_max(ledger, tid)
        killing = pmax + int(ledger.stat(tid, "body", 2)) + 1 - int(ledger.stat(tid, "physical_damage"))
        ledger.add_stat(tid, "physical_damage", killing)                # past monitor + Body: dead (p. 170)
        ledger.log(turn, "damage", tid, {"boxes": killing, "type": "physical", "status": "dead", "how": "finish"})
        ledger.log(turn, "finish", a["id"], {"target": tid, "weapon": (weapon or {}).get("id"), "was": status,
                                             "reason": reason})
        away = limp(ledger, t) if status not in OUT else None
        state = f"{away[0].lower()}{away[1:]} (body limp)" if away else status
        lines.append(f"  {('With ' + weapon['name']) if weapon else 'Bare-handed'}, no roll: {t['name']} was {state} "
                     f"and nobody stands against {a['name']} - it's certain")
        lines.append(f"  {t['name']} is dead -> {condition_line(ledger, tid)}")
        if t["kind"] == "pc":
            lines.append(f"  Not dead yet? {t['name']}'s player can burn Edge to live (the edge tool, burn).")
    return {"card": "\n".join(lines), "target_status": condition(ledger, ids[0]),
            "strikes": [{"target": x, "target_status": condition(ledger, x)} for x in ids]}


def reload(ledger: Ledger, turn: int | None, owner: str, weapon_id: str) -> dict:
    o = ledger.require(owner)
    w = ledger.find(weapon_id)
    if w is None or not ledger.holds(o["id"], w["id"]):
        raise LedgerError(f"{o['name']} isn't carrying '{weapon_id}'.")
    cap = w["props"].get("ammo_capacity")
    if not cap:
        raise LedgerError(f"{w['name']} doesn't take ammo.")
    state = ledger.item_state(o["id"], w["id"])
    state["loaded"] = cap
    ledger.set_item_state(o["id"], w["id"], state)
    ledger.log(turn, "reload", o["id"], {"weapon": w["id"]})
    return {"card": f"[GEAR] {o['name']} reloads {w['name']} ({cap}/{cap})"}


# ── Characters ──────────────────────────────────────────────────────────

def _grenade(kind: str, qty: int = 1):
    from .explosives import catalog
    name, props = catalog(kind)
    return (name, props, qty)


def _weapon(name, dv, skill="firearms", ap=0, ammo=None, dtype="physical", accuracy=0):
    p = {"dv": dv, "ap": ap, "skill": skill, "damage_type": dtype}
    if ammo:
        p["ammo_capacity"] = ammo
    if accuracy:
        p["accuracy"] = accuracy
    return (name, p)


ARCHETYPES = {
    "street_samurai": {
        "blurb": "street samurai",
        "attrs": dict(body=5, agility=6, reaction=5, strength=5, willpower=3, logic=2, intuition=4, charisma=2, edge=3),
        "essence": 2.6,
        "skills": dict(firearms=6, close_combat=5, athletics=4, perception=4, stealth=3, intimidation=3),
        "gear": [_weapon("Ares Predator V", 5, ap=-1, ammo=15, accuracy=2), _weapon("Katana", 6, "close_combat", ap=-2),
                 ("Armored jacket", {"armor": 4}), _grenade("HE grenade", 2)],
        "nuyen": 3000,
    },
    "decker": {
        "blurb": "decker",
        "attrs": dict(body=3, agility=3, reaction=4, strength=2, willpower=4, logic=6, intuition=5, charisma=3, edge=3),
        "essence": 5.6,
        "skills": dict(hacking=6, cybercombat=5, electronics=5, firearms=2, perception=3, stealth=2),
        "gear": [("Cyberdeck", {"deck": 4, "bonus": {"hacking": 2, "cybercombat": 2, "electronics": 1}}),
                 _weapon("Colt America L36", 4, ammo=11), ("Lined coat", {"armor": 3})],
        "drones": ["fly-spy"],
        "nuyen": 2000,
    },
    "rigger": {
        "blurb": "rigger",
        "attrs": dict(body=3, agility=3, reaction=5, strength=2, willpower=4, logic=5, intuition=5, charisma=2, edge=3),
        "essence": 3.8,
        "skills": dict(piloting=6, firearms=4, electronics=4, engineering=4, perception=4, stealth=2),
        "gear": [("Control rig", {"control_rig": 2}), _weapon("Ares Light Fire 75", 4, ammo=16, accuracy=1),
                 ("Armor jacket", {"armor": 4})],
        "drones": ["roto-drone", "fly-spy", "bulldog"],
        "nuyen": 2500,
    },
    "technomancer": {
        "blurb": "technomancer",
        "attrs": dict(body=3, agility=3, reaction=4, strength=2, willpower=5, logic=5, intuition=5, charisma=4, edge=3,
                      resonance=6),
        "essence": 6.0,
        "skills": dict(software=6, compiling=5, hacking=5, electronics=4, cybercombat=3, perception=3),
        "gear": [_weapon("Ruger Super Warhawk", 5, ammo=6), ("Armored hoodie", {"armor": 3})],
        "forms": ["resonance spike", "puppeteer", "cleaner", "static veil"],
        "nuyen": 1500,
    },
    "mage": {
        "blurb": "hermetic mage",
        "attrs": dict(body=3, agility=3, reaction=3, strength=2, willpower=6, logic=4, intuition=5, charisma=4, edge=3, magic=6),
        "essence": 6.0,
        "skills": dict(sorcery=6, conjuring=4, perception=4, etiquette=2, firearms=1),
        "gear": [("Power focus", {"bonus": {"sorcery": 2}}), _weapon("Fichetti pistol", 4, ammo=10),
                 ("Lined coat", {"armor": 3})],
        "spells": ["manabolt", "stunbolt", "fireball", "heal", "armor", "invisibility", "detect life", "levitate"],
        "nuyen": 1500,
    },
    "face": {
        "blurb": "face",
        "attrs": dict(body=3, agility=4, reaction=4, strength=3, willpower=4, logic=4, intuition=5, charisma=6, edge=5),
        "essence": 5.5,
        "skills": dict(con=6, negotiation=6, etiquette=5, intimidation=3, perception=4, firearms=3, streetwise=4),
        "gear": [("Tailored pheromones", {"bonus": {"con": 1, "negotiation": 1, "etiquette": 1}}),
                 _weapon("Hold-out pistol", 3, ammo=6), ("Armored suit", {"armor": 3})],
        "nuyen": 5000,
    },
}

NPC_TEMPLATES = {
    "civilian": {"attrs": dict(body=2, agility=2, reaction=2, strength=2, willpower=2, logic=2, intuition=3, charisma=3),
                 "skills": dict(perception=2, etiquette=2), "gear": [], "nuyen": 100},
    "contact": {"attrs": dict(body=3, agility=3, reaction=3, strength=3, willpower=4, logic=4, intuition=4, charisma=4),
                "skills": dict(negotiation=4, etiquette=4, streetwise=5, perception=4, con=3),
                "gear": [_weapon("hold-out pistol", 3, ammo=6)], "nuyen": 2000},
    # (piloting: a biker gang rides - live T164, Biker Two's Piloting test rolled no dice at all)
    "ganger": {"attrs": dict(body=4, agility=4, reaction=3, strength=4, willpower=3, logic=2, intuition=3, charisma=2),
               "skills": dict(firearms=3, close_combat=4, intimidation=3, perception=2, athletics=3, piloting=2),
               "gear": [_weapon("knife", 3, "close_combat"), _weapon("cheap pistol", 4, ammo=10),
                        ("synthleather jacket", {"armor": 2})], "nuyen": 150},
    "security": {"attrs": dict(body=4, agility=4, reaction=4, strength=4, willpower=4, logic=3, intuition=4, charisma=3),
                 "skills": dict(firearms=4, close_combat=3, perception=4, athletics=3),
                 "gear": [_weapon("security pistol", 5, ap=-1, ammo=15), _weapon("stun baton", 5, "close_combat", ap=-5, dtype="stun"),
                          ("armor vest", {"armor": 4}), _grenade("flash-bang")], "nuyen": 300},
    "expert": {"attrs": dict(body=2, agility=2, reaction=3, strength=2, willpower=4, logic=6, intuition=5, charisma=3),
               "skills": dict(first_aid=4, electronics=3, negotiation=3, etiquette=3, perception=3),
               "gear": [], "nuyen": 3000},
    "operative": {"attrs": dict(body=5, agility=6, reaction=6, strength=4, willpower=5, logic=4, intuition=5, charisma=3),
                     "skills": dict(firearms=6, close_combat=5, perception=5, stealth=4, athletics=4),
                     "gear": [_weapon("assault rifle", 7, ap=-2, ammo=30), ("full body armor", {"armor": 6}),
                              _grenade("frag grenade")],
                     "nuyen": 1000},
}


TEMPLATE_TEXT = {"civilian": "an ordinary person - a clerk, a parent, a bystander",
                 "contact": "a street-smart fixer, informant or broker - talks, deals, carries a hold-out",
                 "expert": "a doctor, scientist, lawyer, engineer or corporate specialist - sharp, connected, unarmed",
                 "ganger": "street muscle with a knife and a cheap pistol (rides a bike)",
                 "security": "a guard or cop - pistol, stun baton, armor vest",
                 "operative": "an elite combat professional - merc, special forces, corp black ops: assault rifle, "
                              "full body armor, grenades"}
# What a template word asked for means today. "professional" was the operative block's old name, and the word read as a
# professional PERSON: it armed a virologist three times (Dr. Vandermeer; flags #33/#47 - Dr. Engstrom at T113 and the
# corporate liaison D. Adeyemi-Ross at T131, each issued the operative block's rifle, grenade and heavy armor). Asked
# for now, it's an expert. A word that's no template at all is a civilian (build_npc): an unread word never arms anyone.
TEMPLATE_ALIASES = {"professional": "expert"}
# The block an OLD record's template name gave it - what retemplate takes back off. Never read for a new NPC.
LEGACY_BLOCKS = {"professional": "operative"}


def npc_template(name: str | None) -> str | None:
    """A template word -> the template it means today, or None (build_npc's civilian)."""
    key = (name or "").strip().lower()
    key = TEMPLATE_ALIASES.get(key, key)
    return key if key in NPC_TEMPLATES else None


def _give_gear(ledger: Ledger, eid: str, gear, turn: int, owner_name: str, tag_items: bool, mark: bool = False) -> None:
    """mark: an NPC's block gear carries who it was made for (props.made_for), so retemplate takes back only theirs."""
    for name, props, *qty in gear:
        if mark:
            props = {**props, "made_for": eid}
        label = f"{owner_name}'s {name}" if tag_items else name
        iid = ledger.create_entity("item", label, description=name, tier=0 if tag_items else 1,
                                   props=props, turn=turn)
        state = {"loaded": props["ammo_capacity"]} if "ammo_capacity" in props else {}
        ledger.give(eid, iid, qty[0] if qty else 1, state)


def _apply_block(ledger: Ledger, eid: str, block: dict, turn: int, owner_name: str, tag_items: bool,
                 mark: bool = False) -> None:
    for k, v in block["attrs"].items():
        ledger.set_stat(eid, k, v)
    for k, v in block["skills"].items():
        ledger.set_stat(eid, k, v)
    if "essence" in block:
        ledger.set_stat(eid, "essence", block["essence"])
    ledger.set_stat(eid, "nuyen", block.get("nuyen", 0))
    ledger.set_stat(eid, "edge_points", block["attrs"].get("edge", 1))
    _give_gear(ledger, eid, block["gear"], turn, owner_name, tag_items, mark)
    if block.get("drones"):
        from .machines import MODELS, build_machine
        for key in block["drones"]:
            build_machine(ledger, f"{owner_name}'s {MODELS[key]['name']}", key, eid, turn)


def build_character(ledger: Ledger, name: str, archetype: str, player: str | None,
                    description: str = "", turn: int = 0) -> str:
    arch = ARCHETYPES.get(archetype)
    if arch is None:
        raise LedgerError(f"Unknown archetype '{archetype}'. Options: {', '.join(ARCHETYPES)}.")
    props = {"archetype": archetype}
    if arch.get("spells"):
        props["spells"] = list(arch["spells"])
    if arch.get("forms"):
        props["forms"] = list(arch["forms"])
    eid = ledger.create_entity("pc", name, description or f"A {arch['blurb']}.", tier=2,
                               player=player or name.lower(), props=props, turn=turn)
    _apply_block(ledger, eid, arch, turn, name, tag_items=True)
    ledger.set_stat(eid, "karma", 0)
    return eid


def build_npc(ledger: Ledger, name: str, template: str, description: str = "", aliases=(),
              tier: int = 1, turn: int = 0, nuyen: int | None = None) -> str:
    template = npc_template(template) or "civilian"
    tpl = NPC_TEMPLATES[template]
    eid = ledger.create_entity("npc", name, description, aliases=aliases, tier=tier,
                               props={"template": template if template in NPC_TEMPLATES else "civilian"}, turn=turn)
    _apply_block(ledger, eid, tpl, turn, name, tag_items=True, mark=True)
    if nuyen is not None:
        ledger.set_stat(eid, "nuyen", max(0, min(250_000, int(nuyen))))
    return eid


def template_of(ent: dict) -> str | None:
    """The block an NPC's record actually carries: its template, an old name read as what it gave them then
    ("professional" was the operative block), or None for a record with no template it knows."""
    raw = (ent.get("props", {}).get("template") or "").strip().lower()
    return LEGACY_BLOCKS.get(raw) or (raw if raw in NPC_TEMPLATES else None)


def block_gear(ledger: Ledger, ent: dict) -> list[dict]:
    """The items an NPC holds that their own block made for them - what retemplate takes back off. Block gear made
    since 2026-10-27 carries who it was made for (props.made_for); an older item goes by its name, "<their name, or one
    they had before>'s <gear>". Review 2026-10-27: the test was any "<someone>'s <gear>", so a pickup off another NPC's
    body went too - and the live Sprocket holds Pastor Garvey's armor vest and nine Crows' cheap pistols."""
    old = template_of(ent)
    made = {g[0].lower() for g in NPC_TEMPLATES[old]["gear"]} if old else set()
    names = {n.strip().lower() for n in [ent["name"], *(ent.get("aliases") or [])] if n and n.strip()}
    out = []
    for item in ledger.holdings(ent["id"]):
        what = (item["description"] or "").strip().lower()
        if what not in made:
            continue
        owner = (item["props"] or {}).get("made_for")
        mine = (owner == ent["id"]) if owner else item["name"].strip().lower() in {f"{n}'s {what}" for n in names}
        if mine:
            out.append(item)
    return out


def carry_wounds(phys: float, stun: float, was: tuple, now: tuple) -> tuple[int, int]:
    """(Physical, Stun) boxes moved from one condition monitor to another in the same condition - was and now are
    (Body, Willpower). Review 2026-10-27: retemplate kept the boxes as they were while the monitor followed the new
    Body, so a wounded operative-block virologist (10 of 11) became dying (10 of 9), bleeding out, from a paperwork fix -
    and 12 boxes made a dying one dead. Each track keeps its zone: unhurt, hurt (capped below the new track), full,
    past it (the same boxes over, as far as the new Body allows - dying stays dying), dead."""
    (body, will), (nbody, nwill) = was, now
    pmax, smax = 8 + ceil(body / 2), 8 + ceil(will / 2)
    npmax, nsmax = 8 + ceil(nbody / 2), 8 + ceil(nwill / 2)
    phys, stun = int(phys), int(stun)
    if phys <= 0:
        p = phys
    elif phys < pmax:
        p = min(phys, npmax - 1)
    elif phys == pmax:
        p = npmax
    elif phys <= pmax + body:
        p = npmax + min(phys - pmax, int(nbody))
    else:
        p = max(phys, npmax + int(nbody) + 1)
    s = stun if stun <= 0 else min(stun, nsmax - 1) if stun < smax else nsmax
    return p, s


def retemplate(ledger: Ledger, eid: str, template: str, turn: int = 0) -> dict:
    """Give an NPC another template's block, when the engine handed out the wrong one (flags #33/#47: a virologist and
    a corporate liaison came out of the old "professional" block kitted like soldiers - rifle, grenade, heavy
    armor). The old block's own gear - the items it made for them (block_gear) - comes off and leaves play; the new
    block's gear comes on; the attributes and skills become the new block's, and a skill only the old block gave goes
    to 0. Their money and anything they picked up in the story stay theirs, and so does how hurt they are: the wounds
    move onto the new block's monitor in the same condition (carry_wounds) - a paperwork fix never kills or heals.
    Returns {"from": old template or None, "to": new, "took": [item names], "gave": [item names],
    "condition": their condition, "wounds": ((Physical, Stun) before, after) when the boxes moved, else None}."""
    ent = ledger.require(eid)
    if ent["kind"] != "npc":
        raise LedgerError(f"{ent['name']} isn't an NPC - only an NPC has a template.")
    new = npc_template(template)
    if not new:
        raise LedgerError(f"No NPC template '{template}'. Options: {', '.join(NPC_TEMPLATES)}.")
    old = template_of(ent)
    took = []
    for item in block_gear(ledger, ent):
        ledger.take(ent["id"], item["id"], item["qty"])
        ledger.update_entity(item["id"], status="departed")
        took.append(item["name"])
    was = (ledger.stat(ent["id"], "body", 2), ledger.stat(ent["id"], "willpower", 2))
    hurt = (int(ledger.stat(ent["id"], "physical_damage")), int(ledger.stat(ent["id"], "stun_damage")))
    block = NPC_TEMPLATES[new]
    for k in (NPC_TEMPLATES[old]["skills"] if old else {}):
        if k not in block["skills"]:
            ledger.set_stat(ent["id"], k, 0)
    for k, v in {**block["attrs"], **block["skills"]}.items():
        ledger.set_stat(ent["id"], k, v)
    kept = carry_wounds(*hurt, was, (ledger.stat(ent["id"], "body", 2), ledger.stat(ent["id"], "willpower", 2)))
    if kept != hurt:
        ledger.set_stat(ent["id"], "physical_damage", kept[0])
        ledger.set_stat(ent["id"], "stun_damage", kept[1])
    held = {(i["description"] or "").strip().lower() for i in ledger.holdings(ent["id"])}
    gear = [g for g in block["gear"] if g[0].lower() not in held]
    _give_gear(ledger, ent["id"], gear, turn, ent["name"], tag_items=True, mark=True)
    ledger.update_entity(ent["id"], props={**ent["props"], "template": new})
    return {"from": old, "to": new, "took": took, "gave": [f"{ent['name']}'s {g[0]}" for g in gear],
            "condition": condition(ledger, ent["id"]), "wounds": (hurt, kept) if kept != hurt else None}


# ── Sheets ──────────────────────────────────────────────────────────────

def _gift_lines(ent: dict, s: dict, full: bool) -> list[str]:
    """A caster's spells with their drain codes (a technomancer's forms with their fading codes), the cost at full
    Magic in brackets and the resist pool - so `!sheet text`, !askdm and the GM's packet know what they know and
    what it costs, with the arithmetic done. Live, flag #62: only the picture sheet listed spells at all. An NPC's
    short sheet (full=False) gets just the codes. No list means they know them all, as the sheets read it."""
    out = []
    if s.get("magic"):
        from .magic import SPELLS, spell_at, spell_label           # (magic imports this module)
        m = int(s["magic"])
        known = [k for k in (ent["props"].get("spells") or []) if k in SPELLS]
        if full:
            out.append(f"  Spells (drain: F = the Force cast at, never under 2; at Force {m} in brackets): "
                       + ", ".join(spell_at(k, m) for k in known or SPELLS)
                       + f" | drain resist {int(s.get('willpower', 0)) + int(s.get('logic', 0))} dice "
                         "(Willpower + Logic)")
        else:
            out.append("  Spells: " + (", ".join(spell_label(k) for k in known) or "any on the list"))
    if s.get("resonance"):
        from .resonance import FORMS, form_at, form_label
        r = int(s["resonance"])
        known = [k for k in (ent["props"].get("forms") or []) if k in FORMS]
        if full:
            out.append(f"  Complex forms (fading: L = the Level, never under 2; at Level {r} in brackets): "
                       + ", ".join(form_at(k, r) for k in known or FORMS)
                       + f" | fading resist {int(s.get('willpower', 0)) + r} dice (Willpower + Resonance)")
        else:
            out.append("  Complex forms: " + (", ".join(form_label(k) for k in known) or "any on the list"))
    return out


def sheet(ledger: Ledger, eid: str, full: bool = True) -> str:
    ent = ledger.require(eid)
    s = ledger.stats(ent["id"])
    if ent["kind"] == "host":
        return f"{ent['name']} [{ent['id']}] host rating {ent['props'].get('rating', '?')}"
    if ent["kind"] in MACHINES:
        p = ent["props"]
        owner = ledger.get(p.get("owner") or "")
        driver = ledger.get(p.get("controller") or "")
        run = (f"{'jumped in' if p.get('control') == 'jumped' else 'remote'} by {driver['name']}" if driver
               else "autonomous")
        if p.get("delegates"):                        # (who the owner lent it to - the GM can see they need no handover)
            run += "; keys: " + ", ".join((ledger.get(d) or {}).get("name", d) for d in p["delegates"])
        stats = " ".join(f"{k.title()} {int(s[k])}" for k in MACHINE_STATS if k in s)
        softs = ", ".join(f"{k.title()} {v}" for k, v in autosofts(ledger, ent).items())
        from .machines import aboard_line, cargo_line, mount_line
        out = [f"{ent['name']} [{ent['id']}] - {ent['kind'].upper()} ({(owner or {}).get('name', 'no owner')}'s; {run})",
               f"  {stats}" + (f" | Autosofts: {softs}" if softs else ""),
               f"  {initiative_text(ledger, ent['id'])}",
               f"  Condition: {condition_line(ledger, ent['id'])}"]
        out += [f"  {x}" for x in (mount_line(ledger, ent), aboard_line(ledger, ent), cargo_line(ledger, ent)) if x]
        if arriving(ent):
            out.insert(1, f"  NOT HERE YET: {transit_note(ledger, ent)}")
        if full and ent["description"]:
            out.insert(1, f"  {ent['description']}")
        return "\n".join(out)
    if ent["kind"] == "sprite":
        p = ent["props"]
        owner = ledger.get(p.get("owner") or "")
        return (f"{ent['name']} [{ent['id']}] - SPRITE ({p.get('type')}, Level {p.get('level')}; "
                f"{(owner or {}).get('name', 'free')}'s, {p.get('tasks', 0)} task(s) left) - lives in the Matrix\n"
                f"  Can: {'; '.join(p.get('powers') or [])}")
    if ent["kind"] == "spirit":
        p = ent["props"]
        owner = ledger.get(p.get("owner") or "")
        return (f"{ent['name']} [{ent['id']}] - SPIRIT ({p.get('type')}, Force {p.get('force')}; "
                f"{(owner or {}).get('name', 'free')}'s, {p.get('services', 0)} service(s) left)\n"
                f"  Powers: {', '.join(p.get('powers') or [])} | armor {int(s.get('armor', 0))} vs mundane harm\n"
                f"  {initiative_text(ledger, ent['id'])}\n"
                f"  Condition: {condition_line(ledger, ent['id'])}")
    if ent["kind"] == "faction":
        return (f"{ent['name']} [{ent['id']}] - FACTION (reach {int(s.get('reach', 2))}: tests roll reach x2; "
                f"funds {int(s.get('nuyen', 0)):,} nuyen)" + (f"\n  {ent['description']}" if full and ent["description"] else ""))
    if ent["kind"] in ("location", "item"):
        extra = ""
        shown = {k: v for k, v in ent["props"].items() if k != "made_for"}      # (bookkeeping: block_gear's)
        if ent["kind"] == "item" and shown:
            extra = " " + json.dumps(shown)
        return f"{ent['name']} [{ent['id']}] ({ent['kind']}) {ent['description']}{extra}"
    attrs = " ".join(f"{ABBR[a]} {int(s[a])}" for a in ATTRIBUTES if a in s)
    skills = ", ".join(f"{nice(k)} {int(v)}" for k, v in sorted(s.items()) if k in SKILLS and v)
    gear = []
    for item in ledger.holdings(ent["id"]):
        p, bits = item["props"], []
        if _bricked(ledger, ent["id"], item):         # (flag #24: the sheet said nothing of it)
            from .matrix import brick_note
            bits.append(brick_note(ledger, ent["id"], item))
        if "dv" in p:
            bits.append(f"DV{p['dv']}{'S' if p.get('damage_type') == 'stun' else 'P'}" + (f" AP{p['ap']}" if p.get("ap") else ""))
        if "ammo_capacity" in p:
            bits.append(f"{item['state'].get('loaded', p['ammo_capacity'])}/{p['ammo_capacity']} loaded")
        if "armor" in p:
            bits.append(f"armor {p['armor']}")
        if "bonus" in p:
            bits.append("+" + ", +".join(f"{v} {nice(k)}" for k, v in p["bonus"].items()))
        if p.get("augmentation"):
            bits.append("cyberware" + (f", {p['effect']}" if p.get("effect") else "") + f", ESS {p.get('essence', 0)}")
        if arriving(item):
            bits.append(transit_note(ledger, item) + (" (installed then)" if p.get("augmentation") else ""))
        elif p.get("install"):
            bits.append("NOT INSTALLED - it came, but not into them")
        qty = f"{item['qty']}x " if item["qty"] > 1 else ""
        gear.append(f"{qty}{item['name']} [{item['id']}]" + (f" ({'; '.join(bits)})" if bits else ""))
    head = f"{ent['name']} [{ent['id']}] - {ent['kind'].upper()}"
    if ent["kind"] == "pc":
        p = ent["props"]
        who = " ".join(x for x in (p.get("metatype"), p.get("archetype", "?").replace("_", " ")) if x)
        head += f" ({who}{', ' + p['pronouns'] if p.get('pronouns') else ''}, player: {ent['player']})"
    lines = [head]
    if full and ent["description"]:
        lines.append(f"  {ent['description']}")
    lines.append(f"  {attrs}" + (f" | ESS {s['essence']}" if "essence" in s else ""))
    if full:
        lines.append(f"  {initiative_text(ledger, ent['id'])}")
    if skills:
        lines.append(f"  Skills: {skills}")
    lines += _gift_lines(ent, s, full)
    lines.append(f"  Condition: {condition_line(ledger, ent['id'])}")
    if full:
        lines.append(f"  Nuyen {int(s.get('nuyen', 0)):,} | Edge points {int(s.get('edge_points', 0))}"
                     + (f" | Karma {int(s.get('karma', 0))}" if ent["kind"] == "pc" else ""))
    if gear:
        lines.append("  Gear: " + "; ".join(gear))
    fleet = [m for kind in MACHINES for m in ledger.entities(kind=kind)]
    rides = [m for m in fleet if m["props"].get("owner") == ent["id"]]
    if rides:
        lines.append("  Drones & vehicles: " + "; ".join(
            f"{m['name']} [{m['id']}] ({transit_note(ledger, m) if arriving(m) else condition(ledger, m['id'])})"
            for m in rides))
    # What they run that isn't theirs, and the keys they hold (a crewmate's lent drone, a stolen one) - the sheets
    # listed owned machines only, so a delegate's never said what they drive.
    driving = [f"{m['name']} [{m['id']}] ({'jumped in' if m['props'].get('control') == 'jumped' else 'remote'})"
               for m in fleet if m["props"].get("controller") == ent["id"] and m["props"].get("owner") != ent["id"]]
    keys = [f"{m['name']} [{m['id']}]" for m in fleet if ent["id"] in (m["props"].get("delegates") or [])
            and m["props"].get("controller") != ent["id"]]
    if driving or keys:
        lines.append("  " + " | ".join(x for x in (("Driving: " + "; ".join(driving)) if driving else "",
                                                  ("Keys to: " + "; ".join(keys)) if keys else "") if x))
    return "\n".join(lines)
