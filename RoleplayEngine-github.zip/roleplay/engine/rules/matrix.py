"""The Matrix (DESIGN.md §7b, §7h): a heist inside the heist. One roll per beat; the host answers every action.

A decker jacks into a host (AR: aware of their body; hot-sim VR: +2 dice, body limp and helpless, and Black IC can
hurt them for real) at its Entry node, and moves through the host's map (hostmap.py) node by node, like the old
Genesis Shadowrun: hubs, datastores (files), the building's systems (cameras, locks, alarms, elevators), Comms and
the Core. Moving through nodes open to them is free; cracking one (hack, or a loud brute force against the node's
rating x 2) is the illegal part. Only illegal moves leave heat on the OVERWATCH meter - the defender's hits, more when
it's loud or it goes wrong - and the host answers in the same card:
    15  noticed      Patrol IC launches (it watches illegal moves: +2 Overwatch each while it's up)
    25  alert        the host wakes its IC one a turn - each where it lives - and they hunt the decker
    40  convergence  dumped, dumpshocked, physical location known - the host's owners send someone
IC: Track (finds your meat body once the host has marks on you), Killer (deck damage), Tar Baby (no jacking out
until you cut free), Black IC (biofeedback - the decker, never the deck; one emergency jack-out roll in VR before it
can kill you). The host launches at most one IC a GM turn, however many beats it holds. Matrix damage is the table's model (2026-10-27): the deck
soaks it with Device Rating + Firewall and takes it up to its full monitor, and what's past that is the decker's Stun;
Black IC skips the deck - Willpower + Firewall. In a node open to them a decker reads and copies files, and runs the
building's devices - legal, no Overwatch; a real login does it without a roll. Taking the Core makes them admin:
stand the IC down, cancel the alert, pull the whole map.
State lives on the decker (props.matrix) and the host (props.nodes, props.alert, props.ic). A run is live until the
decker jacks out or the story leaves it behind (over(): every reader goes by it, and the engine closes such a run
quietly). A scene cut that takes the decker along takes the run with them (carry()), and a turn whose narration has
them in the host keeps it going (keep()). The table's !difficulty dial reaches in here as in the room (dial()), and
every roll is a tests row with the host's dice beside the decker's (_record_roll).
"""
from __future__ import annotations

import re
from math import ceil

from ..ledger import Ledger, LedgerError, RulesRefusal
from . import hostmap, sr_lite

LEVELS = ("outsider", "user", "admin")
NOTICED, ALERT, CONVERGENCE = 15, 25, 40
STALE = 3            # turns with no sign of life: the packet starts counting a run down, and a jack_out is the GM
#                      tidying up after the story - quiet, no dumpshock (flag #11)
PICK_UP = 1          # turns: a jack-in into the same host this soon after the run's last Matrix move picks it up;
#                      later, it's a new run (Overwatch 0, no marks, no trace)
IDLE = 10            # turns: a run with no Matrix move - nor a turn of the story in the host (keep()) - this long is
#                      over, even in the same scene (over()); the packet counts it down from STALE (summary_lines)
CONVERGENCE_DAMAGE = 6   # the grid's own hit at convergence: Matrix damage, soaked like an IC's (flag #29)
ACTIONS =("jack_in", "move", "hack", "brute_force", "search", "data", "control", "admin", "fight", "hide", "jack_out",
           "repair")
ILLEGAL = ("hack", "brute_force", "fight", "hide")    # Attack and Sleaze actions: the only ones that feed Overwatch
TRACE_MARKS = 2      # Track IC finds your body only once the host has this many marks on you (SR5 p. 249)
ADMIN = ("stand_down", "cancel_alert", "reveal")
IC_TEXT = {"patrol": "watches - +2 Overwatch every illegal move while it's up",
           "track": "traces the decker's meat body",
           "killer": "damages the deck - past a full deck, the decker's Stun",
           "tar baby": "locks the decker in - no jacking out until it's beaten",
           "black ic": "biofeedback - hurts the decker, never the deck (Physical in hot-sim VR, Stun in AR)"}
HELP = [
    "Say what your decker does in plain words - the GM turns it into the move. `!net` shows the host's map: its "
    "nodes, their colors, where you are and what's guarding them.",
    "**Look around:** `!net` (the map) · \"I search the node\" - files here, the nodes around, what IC sleeps where",
    "**Move:** \"I head for the records\" - free through nodes open to you; you stop at the first locked one",
    "**Crack a node:** \"I hack into Hub B\" (sneaky) or \"I brute-force it\" (loud) - the illegal part: it feeds "
    "Overwatch, and a failure leaves the host a mark on you",
    "**Files** (in a datastore): \"I copy / edit / wipe the patient file\"",
    "**The building** (in a devices node): \"I loop the cameras\", \"pop the maglocks on 3\", \"kill the alarm\", "
    "\"stop the elevator\" - the GM plays it out in the room",
    "**The Core:** take it and you're admin - \"shut the IC down\", \"cancel the alert\", \"pull the whole map\"",
    "**Fight IC:** \"I go after the Killer IC\" · **Cover your tracks:** \"I hide\" (cools Overwatch) · "
    "**Leave:** \"I jack out\" (Tar Baby has to be beaten first) · **Fix your deck:** \"I repair it\" (once out)",
    "**Colors:** blue open · green light · orange guarded · red secure (admin only). A real login - stolen "
    "credentials, a hijacked session - opens every node at its level, no roll, no Overwatch.",
    "**Overwatch:** only illegal moves feed it. 15 noticed (Patrol IC watches), 25 alert (the host wakes its IC one "
    "at a time and they come for you), 40 convergence (dumped and traced). Jacking out resets it - and a run the "
    "story leaves behind (ten turns with no Matrix move and nothing of it in the story) is over: the next jack-in "
    "starts clean. A scene cut that takes you along takes the run with you.",
    "**Damage:** your deck soaks IC hits with Device Rating + Firewall; past a full deck it's your Stun, and a "
    "bricked deck gives no bonuses until it's repaired. Black IC skips the deck: Willpower + Firewall.",
    "**Hot-sim VR:** +2 dice, but your body is limp in the room and Black IC's biofeedback is Physical.",
    "**Table difficulty:** the `!difficulty` dial counts in here too - the host and its IC get its extra dice, a "
    "search its threshold shift, the same as in the room.",
]


def ic_name(kind: str) -> str:
    return "Black IC" if kind == "black ic" else f"{kind.title()} IC"


def ic_suite(rating: int) -> list[str]:
    suite = ["patrol"]
    if rating >= 2:
        suite.append("track")
    if rating >= 3:
        suite.append("killer")
    if rating >= 4:
        suite.append("tar baby")
    if rating >= 5:
        suite.append("black ic")
    return suite


def _deck_rating(item: dict) -> int:
    return int(item["props"].get("deck", 0)) or (3 if "deck" in item["name"].lower() else 0)


def _deck_item(ledger: Ledger, eid: str) -> dict | None:
    """The deck they'd jack in with: the best one in hand (a deck still with the courier can't be jacked into)."""
    best, item = 0, None
    for i in sr_lite.in_hand(ledger, eid):
        r = _deck_rating(i)
        if r > best:
            best, item = r, i
    return item


def deck(ledger: Ledger, eid: str) -> tuple[int, str]:
    """The decker's deck rating - or a technomancer's living persona (their Resonance)."""
    item = _deck_item(ledger, eid)
    if not item and ledger.stat(eid, "resonance", 0) > 0:
        return int(ledger.stat(eid, "resonance")), LIVING
    return (_deck_rating(item), item["name"]) if item else (0, "")


LIVING = "Living persona"


def living(ledger: Ledger, eid: str) -> bool:
    return deck(ledger, eid)[1] == LIVING


def deck_monitor(rating: int) -> int:
    return 8 + ceil(rating / 2)


def firewall(ledger: Ledger, eid: str) -> int:
    """The engine's Firewall: the deck's rating (a living persona's, its Resonance) plus what's raised it - Infusion
    of Firewall's hits (firewall_bonus). The IC defense, the deck's soak and Black IC's soak all read it (flags #29,
    #30: the soaks left firewall_bonus out, and the deck's left the Firewall out altogether)."""
    return deck(ledger, eid)[0] + int(ledger.stat(eid, "firewall_bonus", 0))


def bricked(ledger: Ledger, eid: str) -> str | None:
    """The id of the decker's deck while its condition monitor is full - it gives no bonuses and won't jack in until
    it's repaired. Live, flag #24 (T105): Filament's Cyber-5 sat at Deck 14/10, bricked, and still added its +2
    Hacking to every test he rolled. None for a living persona, or a deck that works."""
    item = _deck_item(ledger, eid)
    if not item or not ledger.get(eid):
        return None
    return item["id"] if int(state(ledger, eid).get("deck_damage", 0)) >= deck_monitor(_deck_rating(item)) else None


def brick_note(ledger: Ledger, eid: str, item: dict) -> str | None:
    """'BRICKED (Deck 14/10) - no bonuses until repaired' for that item, when it's their bricked deck."""
    if not _deck_rating(item) or bricked(ledger, eid) != item["id"]:
        return None
    return (f"BRICKED (Deck {int(state(ledger, eid).get('deck_damage', 0))}/{deck_monitor(_deck_rating(item))}) - "
            "no bonuses until repaired")


def state(ledger: Ledger, eid: str) -> dict:
    return dict(ledger.require(eid)["props"].get("matrix") or {})


def _save(ledger: Ledger, eid: str, st: dict) -> None:
    ent = ledger.require(eid)
    ledger.update_entity(eid, props={**ent["props"], "matrix": st})


# ── is the run still live? (one answer for every reader) ────────────────
# Live, flags #11 / #17 / #26: Filament never jacked out of the T45/46 KD-4 dive. For forty turns the packet told the GM
# he was still in it - "hot-sim VR: their body is LIMP", Overwatch 33/40, TRACED, the host ON ALERT - and every beat but
# a jack-in played from there; only jack_in looked at how old the run was. Later his T105 trace showed as TRACED on
# every host he went into, eighty turns on. Now over() is the one test: the packet, the map, the sheets, a limp body,
# edge_rides and act all read a run that's over as over, and the engine closes it quietly (end_stale) when it meets it
# - in act, and at every turn's end (end_stale_runs).
# Review 2026-10-27, the other way round: the story keeps runs going that no tool call touches. At T126 Filament
# jacked into the Bellevue Arcade host and looped its cameras, and the same turn cut to S12 with him along - T127-T130
# narrate the loop holding; reading any scene change as the end would have closed that run at T126's end. And from T180
# he sat in Lim's garage host watching the gate camera, narrated every turn to T188 with no Matrix move. So a cut that
# takes the decker along takes the run with them (carry), a turn whose memory pass has them in the host keeps it going
# (keep), the packet counts the idle turns down where the GM can see them (summary_lines), and the GM's jack_out on a
# run the engine already closed gets the quiet card, not an error (act: st.ended).

def _now(ledger: Ledger) -> int | None:
    """The turn the table is on: the newest turn row (mid-turn, the open one)."""
    row = ledger.conn.execute("SELECT MAX(id) AS n FROM turns").fetchone()
    return row["n"] if row else None


def _run_scene(ledger: Ledger, st: dict) -> int | None:
    """The scene the run's last Matrix move was made in - kept on the state since 2026-10-27 (_touch); for a run from
    before, the scene of the turn it was made on (a played one: no run was made in a world's seeded history)."""
    if "scene" in st:
        return st["scene"]
    if st.get("last_turn") is None:
        return None
    row = ledger.conn.execute("SELECT scene_id FROM turns WHERE id=? AND status != 'seed'",
                              (int(st["last_turn"]),)).fetchone()
    return row["scene_id"] if row else None


def _touch(ledger: Ledger, eid: str, st: dict, turn: int | None) -> None:
    """A Matrix move: when and where the run last did something - what over() goes by."""
    st["last_turn"] = turn
    st["scene"] = ledger.scene_of(eid)


def _alive(st: dict) -> int | None:
    """The run's last sign of life: its last Matrix move (last_turn), or a later turn whose narration had the decker in
    the host (kept - keep())."""
    seen = [int(x) for x in (st.get("last_turn"), st.get("kept")) if x is not None]
    return max(seen) if seen else None


def _over(ledger: Ledger, eid: str, st: dict, now: int | None) -> str | None:
    """over() on a given state (fix_live_world_3 judges the record it would write)."""
    if not st.get("host"):
        return None
    alive, last = _alive(st), st.get("last_turn")
    now = _now(ledger) if now is None else now
    if alive is not None and now is not None and now - alive > IDLE:
        return (f"no Matrix move since T{int(last)}" if last is not None else "no Matrix move") + (
            f", and nothing of it in the story since T{alive}" if last is None or alive > int(last) else "")
    was, here = _run_scene(ledger, st), ledger.scene_of(eid)
    if was is not None and here is not None and was != here:
        return f"the story left S{was} behind"
    return None


def over(ledger: Ledger, eid: str, now: int | None = None) -> str | None:
    """Why a decker's run is over though props.matrix still has them in a host - None while it's live (or they're out).
    Over once IDLE turns pass with no Matrix move and no turn of the story in the host (keep) - not STALE's 3: live
    T101-T105, four turns of talk inside a KD-4 dive that was still going, and a decker does sit in a host while the
    room plays. Or once the decker is in another scene than the run's: a cut that takes them along takes the run too
    (carry), so that's a run from before 2026-10-27 the story moved on from (the T45 dive was S5, the T88 jack-in S6).
    now: the turn to judge from (default: the newest turn)."""
    return _over(ledger, eid, state(ledger, eid), now)


def live(ledger: Ledger, eid: str, now: int | None = None) -> str | None:
    """The host of the decker's run while it's live (over()) - else None."""
    st = state(ledger, eid) if ledger.get(eid) else {}
    return st.get("host") if st.get("host") and not over(ledger, eid, now) else None


def carry(ledger: Ledger, eid: str) -> None:
    """A decker the story takes to another scene takes their run along: its scene is where they are now (over()'s
    scene test). game.enter_scene calls it - after the move - for whoever had a live run before it. Not a Matrix move:
    the idle turns count on. Live T126: Filament's camera loop rode along from S11 into S12."""
    st = state(ledger, eid)
    if st.get("host"):
        st["scene"] = ledger.scene_of(eid)
        _save(ledger, eid, st)


def riding_note(ledger: Ledger, ids) -> str:
    """For a cut or a scene_presence result: who of these went along still jacked in, so the GM knows the run went
    with them - and how to end it if the story logged them off. '' when nobody did."""
    rides = []
    for eid in dict.fromkeys(ids):
        hid = live(ledger, eid) if ledger.get(eid) else None
        if hid:
            st = state(ledger, eid)
            rides.append(f"{ledger.require(eid)['name']} in {(ledger.get(hid) or {}).get('name', hid)} "
                         f"({str(st.get('mode') or 'ar').upper()}, last Matrix move T{st.get('last_turn')})")
    if not rides:
        return ""
    # (review 2026-10-28 of flag #11: inside those turns a jack_out plays the run - the Tar Baby, the host's answer - so
    # a dive the table took back is `correct` what=jack_out, never a jack_out that replays it)
    return (" (still jacked in - the run goes with them: " + "; ".join(rides) + ". If the story logged them off, "
            f"call matrix jack_out - {STALE} turns on from the run's last sign of life it closes quietly, no "
            "dumpshock; if the table took the dive back, call correct what=jack_out instead - no roll)")


# The narration logging a decker off, or taking the dive back: live T47, the GM out of character playing it as if
# Filament had never jacked in - no dive, no trace - with no jack_out or correct called (review of flag #11: the memory pass had
# Filament an actor and the host mentioned, so keep() held the retconned run live ten turns more, the packet calling his
# body LIMP in the nap room, and a cut carried it into the next scene). Read in a sentence that names the decker, never
# a might-be ("he could pull the plug if it goes wrong").
LOGGED_OFF = re.compile(
    r"\b(?:never\s+(?:jack(?:s|ed)?|plug(?:s|ged)?|went|goes|go)\s+in|jack(?:s|ed|ing)?\s+out|unplug(?:s|ged)?|"
    r"log(?:s|ged)?\s+(?:off|out)|pull(?:s|ed)?\s+(?:the|his|her|their)\s+(?:plug|cable|jack)|"
    r"(?:doesn['’]t|didn['’]t|does\s+not|did\s+not|never)\s+(?:plug|jack)|"
    r"clos(?:es|ed)\s+(?:the|his|her|their)\s+deck|(?:no|never\s+(?:a|any))\s+(?:[\w'’-]+\s+){0,2}(?:dive|run)\b)",
    re.I)
_MIGHT = re.compile(r"\b(?:could|would|might|may|can|unless|should|ready\s+to|about\s+to|wants?\s+to|"
                    r"thinks?\s+about|before)\b|(?<!\bas\s)\bif\b", re.I)    # ("as if he never jacked in" is the retcon)


def _logs_off(ledger: Ledger, eid: str, narration: str) -> str | None:
    """The sentence of the narration that has the decker leave the Matrix (LOGGED_OFF), or None."""
    e = ledger.get(eid) or {}
    names = {w.lower() for n in [e.get("name") or "", *(e.get("aliases") or [])] for w in re.findall(r"[A-Za-z]{3,}", n)}
    for s in re.split(r"(?<=[.!?])\s+|\n+", narration or ""):
        m = LOGGED_OFF.search(s)
        if m and any(re.search(rf"\b{re.escape(w)}\b", s, re.I) for w in names) and not _MIGHT.search(s[:m.start()]):
            return " ".join(s.split())[:160]
    return None


def story_out(ledger: Ledger, turn: int | None, narration: str) -> list[str]:
    """At a turn's end, before keep(): a live run the narration logs off (or takes back) with no Matrix move this turn
    is closed the way the story has it - quietly, no dumpshock, nothing for the GM to call (st.ended, as end_stale);
    the host stands down and goes quiet: what the story took back never happened to it. A line per run closed."""
    out = []
    for kind in ("pc", "npc"):
        for e in ledger.entities(kind=kind):
            st = dict(e["props"].get("matrix") or {})
            hid = st.get("host")
            if not hid or st.get("last_turn") == turn or not live(ledger, e["id"], turn):
                continue
            said = _logs_off(ledger, e["id"], narration)
            if not said:
                continue
            why = f"the story logged them off at T{turn} (\"{said}\")"
            st["ended"] = {"turn": turn, "why": why}
            _close(ledger, turn, e["id"], st, seen=False)
            hp = _host_props(ledger, hid)                  # (and the host forgets the alarm a taken-back dive raised)
            hp["alert"] = 0
            for ic in hp.get("ic", []):
                ic.update(active=False, damage=0, node=ic.get("home") or ic.get("node"))
            _save_host(ledger, hid, hp)
            ledger.log(turn, "matrix", e["id"], {"action": "jack_out", "host": hid, "stale": why})
            out.append(f"{e['name']}'s Matrix run on {(ledger.get(hid) or {}).get('name', 'a host')} is over - {why} - "
                       "closed quietly, no dumpshock")
    return out


def keep(ledger: Ledger, turn: int | None, members: dict, narration: str = "") -> list[str]:
    """The memory pass's word on a run, at a turn's end (before end_stale_runs): a turn whose members have the decker
    in it - anything but only talked about - and the run's host, in any role, keeps the run going as a Matrix move
    would for over()'s idle count (st.kept; a jack-in's pick-up goes by it too). Live T188: a line of narration back in
    the garage host, its sculpted camera feed still watching the gate - Filament an actor, Lim's host mentioned, eight
    turns after his last Matrix move. Never a turn whose narration logs the decker off (_logs_off - live T47's
    retcon: story_out closes that run). Only a run still live this turn: the story's word doesn't reopen one that's
    over. Returns who was kept."""
    out = []
    for kind in ("pc", "npc"):
        for e in ledger.entities(kind=kind):
            st = dict(e["props"].get("matrix") or {})
            hid = st.get("host")
            if not hid or hid not in members or members.get(e["id"]) in (None, "mentioned") \
                    or over(ledger, e["id"], turn) or _logs_off(ledger, e["id"], narration):
                continue
            st["kept"] = turn
            _save(ledger, e["id"], st)
            out.append(e["id"])
    return out


def idle_line(ledger: Ledger, eid: str, now: int | None = None) -> str | None:
    """The packet's countdown on a live run that's gone STALE turns with no sign of life: when the engine will close it,
    what keeps it going, and the jack_out if the story's done with it. None while it's busy. Review: nothing showed
    the GM the last move's turn, so the T191 close of Filament's Lim watch would have come unannounced."""
    st = state(ledger, eid)
    alive, last = _alive(st), st.get("last_turn")
    now = _now(ledger) if now is None else now
    if not live(ledger, eid, now) or alive is None or now is None or now - alive < STALE:
        return None
    name = ledger.require(eid)["name"]
    return ("  No Matrix move" + (f" since T{last}" if last is not None else "")
            + (f" (the story last had {name} in the host at T{alive})" if last is None or alive > int(last) else "")
            + f" - the run ends quietly after T{alive + IDLE} unless a matrix beat keeps it going, or the narration "
              f"keeps {name} in the host (name it). If the story logged them off, call matrix jack_out - it closes "
              "quietly now, no dumpshock")


def closed_note(st: dict, turn: int | None) -> str:
    """Why a decker who isn't in a host is out, when the engine closed their run (st.ended, end_stale): for a beat
    turned away - '' when it didn't. Review: a run closed at one turn's end, then the next turn's beat got a bare
    "start with action 'jack_in'" with no reason."""
    ended = st.get("ended") if not st.get("host") else None
    if not ended:
        return ""
    when = "" if ended.get("turn") == turn else f" at the end of T{ended.get('turn')}"
    return (f" (Their last run was over - {ended.get('why')} - so the engine closed it quietly{when}, no dumpshock; a "
            "new jack-in starts clean.)")


def _log_off(st: dict) -> dict:
    """What leaving a host does to the decker's side, in place: the Overwatch Score, the marks and the trace die with
    the session, and so does what they cracked - log back in and you start outside (p. 236); a login is only good for
    the session it was used in. (TRACED belongs to the run: the meat-world consequence is the READY hook the matrix
    tool files - flags #17, #26.)"""
    host = st.get("host")
    st.pop("kept", None)                             # (the story's word on that run - keep())
    st.update(host=None, node=None, mode=None, tarred=False, overwatch=0, marks=0, traced=False,
              last_host=host or st.get("last_host"))
    if host:
        for k in ("access", "cleared", "creds"):
            (st.get(k) or {}).pop(host, None)
    return st


def current(ledger: Ledger, eid: str, now: int | None = None) -> dict:
    """The decker's Matrix state as it reads now: a run that's over (over()) reads as the jack-out the engine makes
    of it - out, Overwatch 0, no marks, no trace. Read-only (end_stale writes it)."""
    st = state(ledger, eid)
    return _log_off(st) if st.get("host") and over(ledger, eid, now) else st


def traced_in(st: dict) -> bool:
    """TRACED, on this run: the host they're in is the one that traced them (Track IC sets the host's id). A trace
    from an earlier run - or the plain True older records carry - never shows."""
    return bool(st.get("host")) and st.get("traced") == st.get("host")


def _close(ledger: Ledger, turn: int | None, decker: str, st: dict, seen: bool = True) -> None:
    """End a run, both sides: the decker's (_log_off), and the host's - it stands its IC down and a full alert eases
    to "noticed". seen: the host saw them go (a jack-out, a dump). A run the engine finds over (end_stale) wasn't seen
    leaving: the host's last sight of them stays at their last move, so it cools from there."""
    host = st.get("host")
    _log_off(st)
    if host and ledger.get(host):
        hp = _host_props(ledger, host)
        for ic in hp.get("ic", []):
            if ic["type"] != "patrol":
                ic.update(active=False, damage=0, node=ic.get("home") or ic.get("node"))
        hp["alert"] = min(1, int(hp.get("alert", 0)))
        hp.pop("ic_launched_turn", None)                 # (the IC stood down: the next run's turn launches anew)
        if seen:
            hp["last_seen"] = turn
        _save_host(ledger, host, hp)
    _save(ledger, decker, st)


def end_stale(ledger: Ledger, turn: int | None, eid: str) -> str | None:
    """Close a run that's over (over()) the way the story already did: quietly - no dumpshock, no card - and on the
    record (a jack_out event saying why, and st.ended: the GM's own jack_out after it gets the quiet card, and any
    other beat the reason - act, closed_note). Returns why, or None when there was nothing to close."""
    why = over(ledger, eid, turn)
    if not why:
        return None
    st = state(ledger, eid)
    host = st["host"]
    st["ended"] = {"turn": turn, "why": why}
    _close(ledger, turn, eid, st, seen=False)
    ledger.log(turn, "matrix", eid, {"action": "jack_out", "host": host, "stale": why})
    return why


def end_stale_runs(ledger: Ledger, turn: int | None) -> list[str]:
    """At a turn's end: close every run that's over (end_stale). A line per run closed, for the turn's events."""
    out = []
    for kind in ("pc", "npc"):
        for e in ledger.entities(kind=kind):
            hid = (e["props"].get("matrix") or {}).get("host")
            why = end_stale(ledger, turn, e["id"]) if hid else None
            if why:
                out.append(f"{e['name']}'s Matrix run on {(ledger.get(hid) or {}).get('name', 'a host')} is over "
                           f"({why}) - closed quietly, no dumpshock")
    return out


def _host_props(ledger: Ledger, hid: str) -> dict:
    return dict(ledger.require(hid)["props"])


def _save_host(ledger: Ledger, hid: str, props: dict) -> None:
    ledger.update_entity(hid, props=props)


def rating(ledger: Ledger, hid: str) -> int:
    return int(ledger.require(hid)["props"].get("rating", 4))


def bar(n: int, size: int = CONVERGENCE, width: int = 20) -> str:
    filled = max(0, min(width, round(n / size * width)))
    return "▰" * filled + "▱" * (width - filled)


def overwatch_line(ow: int) -> str:
    stage = "convergence" if ow >= CONVERGENCE else "alert" if ow >= ALERT else "noticed" if ow >= NOTICED else "quiet"
    return f"Overwatch {bar(ow)} {ow}/{CONVERGENCE} ({stage})"


def in_vr(ledger: Ledger, eid: str) -> bool:
    st = current(ledger, eid) if ledger.get(eid) else {}
    return bool(st.get("host")) and st.get("mode") == "vr"


# ── the table's !difficulty dial, in the Matrix ─────────────────────────
# Live, flags #27/#28 (T106, a player: the Matrix played far harder than the meat world - seven hits, and it still
# failed): the dial shifted every PC threshold and gave every NPC who opposed a PC its dice, but no host
# defense, IC attack or Matrix threshold ever saw it - the Matrix played at "normal" whatever the table set. The
# owner, 2026-10-27: "The difficulty dial reaches the Matrix" - one dial sets both, and the card shows its part the
# way a roll card does ("+ Table (hard) 1").

def dial(ledger: Ledger, decker: str) -> dict:
    """The !difficulty dial as it reaches this decker's Matrix rolls: {opposition (extra dice for the host and its IC),
    threshold (the shift on a Matrix threshold), level}. A PC's only, as in the room (sr_lite._opposition, the
    request_test threshold shift): an NPC decker's host plays it straight."""
    d = sr_lite.table_difficulty(ledger)
    pc = (ledger.get(decker) or {}).get("kind") == "pc"
    return {"opposition": d["opposition"] if pc else 0, "threshold": d["threshold"] if pc else 0, "level": d["level"]}


def against(ledger: Ledger, decker: str, label: str, dice: int) -> tuple[list, int]:
    """The host's side of a roll - a node's defense, an IC's attack, the host itself - with the dial's dice on it.
    Returns (parts, pool)."""
    parts = [(label, dice)]
    dl = dial(ledger, decker)
    if dl["opposition"]:
        parts.append((f"Table ({dl['level']})", dl["opposition"]))
    return parts, max(0, sum(v for _, v in parts))


def vs_text(parts: list, n: int) -> str:
    """'Hub B (orange, rating 6) doubled = 12d6' - or, with the dial's dice, '... doubled 12 + Table (hard) 1 = 13d6'."""
    return f"{parts[0][0]} = {n}d6" if len(parts) == 1 else f"{sr_lite.fmt_parts(parts)} = {n}d6"


def threshold(ledger: Ledger, decker: str, base: int) -> tuple[int, str]:
    """A Matrix threshold - a search's, an emergency jack-out's - with the dial's shift: (threshold, the note for the
    card: 'table hard +1', or '')."""
    dl = dial(ledger, decker)
    if not dl["threshold"]:
        return base, ""
    return max(1, base + dl["threshold"]), f"table {dl['level']} {dl['threshold']:+d}"


# ── Matrix rolls on the record ──────────────────────────────────────────
# Live, flag #25 (T106): Magic's player asked to see the KD-4 host's roll against Filament's T105 crack (7 hits, Edge
# spent) - and nothing on file had it. The card showed it once; no Matrix roll was ever a tests row, so read_turn, the
# aside and the browser had nothing to show or check. Every Matrix roll is one now, like any test's.

def _record_roll(ledger: Ledger, turn: int | None, decker: str, rec: dict | None, parts: list, r, success: bool,
                 net: int, edge_line: str | None = None, vs: tuple | None = None, need: int | None = None) -> None:
    """A Matrix roll's tests row (sr_lite._record): the decker's pool and dice, and against them the host's or the
    IC's label, dice and hits (vs: (parts, roll)) or the threshold (need); the Edge line; the dial when it's set.
    rec: the beat - {action, host, node, skill, ic, form, reason}."""
    rec = rec or {}
    n = max(0, sum(v for _, v in parts))
    spec = {"kind": "matrix", "action": rec.get("action"), "host": rec.get("host"),
            "pool": f"{sr_lite.fmt_parts(parts)} = {n}d6"}
    spec.update({k: rec[k] for k in ("node", "skill", "ic", "form", "reason") if rec.get(k)})
    if vs:
        v_parts, v = vs
        spec.update(vs=sr_lite.fmt_parts(v_parts), vs_pool=v.pool, vs_dice=list(v.dice), vs_hits=v.hits)
    if need is not None:
        spec["threshold"] = need
    if edge_line:
        spec["edge"] = edge_line.strip().removeprefix("Edge").strip()
    dl = dial(ledger, decker)
    if dl["opposition"] or dl["threshold"]:
        spec["table"] = dl["level"]
    sr_lite._record(ledger, turn, decker, spec, r, success, net)


def _pool(ledger: Ledger, eid: str, skill: str, attribute: str | None, vr: bool) -> tuple[int, list]:
    n, parts = sr_lite.build_pool(ledger, eid, skill, attribute)
    if vr:
        parts = parts + [("Hot-sim VR", 2)]
        n += 2
    assist = int(ledger.stat(eid, "sprite_assist", 0))
    if assist:                                         # a crack sprite's help: one action's worth
        parts = parts + [("Crack sprite", assist)]
        n += assist
        ledger.set_stat(eid, "sprite_assist", 0)
    return n, parts


def _contest(ledger, dice, eid, skill, attribute, vr, defense, defense_label, edge: dict | None = None,
             rec: dict | None = None):
    """edge: the beat's {"use", "turn"} - the first roll of the beat takes the decker's Edge. The host's side gets the
    table's dial (against: flags #27/#28), and the roll goes on the record (rec: the beat - _record_roll, flag #25)."""
    n, parts = _pool(ledger, eid, skill, attribute, vr)
    use = edge.pop("use", None) if edge else None
    turn = edge.get("turn") if edge else None
    explode, _ = sr_lite.push_edge(ledger, turn, eid, parts, use, on="matrix")
    n = max(0, sum(v for _, v in parts))
    r0 = sr_lite.roll(dice, n, explode)
    d_parts, d_n = against(ledger, eid, defense_label, defense)
    d = sr_lite.roll(dice, d_n)
    # (the margin counts - damage to IC, Overwatch cooled by hiding - so a called reroll goes even on a winning roll)
    r, edge_line = sr_lite.second_chance(ledger, dice, turn, eid, r0, use, r0.hits <= d.hits, useful=True,
                                         on="matrix")
    lines = [f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r0.faces()} -> {r0.verdict()}"]
    lines += ([edge_line] if edge_line else []) + [f"  vs     {vs_text(d_parts, d_n)} -> {d.faces()} -> {d.hits} hits"]
    _record_roll(ledger, turn, eid, {**(rec or {}), "skill": skill}, parts, r, r.hits > d.hits, r.hits - d.hits,
                 edge_line, vs=(d_parts, d))
    return r, d, lines


def _alone(ledger, dice, eid, parts: list, edge: dict | None, need: int, cap: int | None = None):
    """An unopposed roll - a search, a deck repair - with the beat's Edge on it like any other roll: a push before, a
    second chance after (a called reroll whenever more hits still count - up to `cap` - insurance only under `need`).
    Before, the Edge passed on a search or a repair was dropped without a word. Returns (pool, first roll, final
    roll, the Edge line or None)."""
    use = edge.pop("use", None) if edge else None
    turn = edge.get("turn") if edge else None
    explode, _ = sr_lite.push_edge(ledger, turn, eid, parts, use, on="matrix")
    n = max(0, sum(v for _, v in parts))
    r0 = sr_lite.roll(dice, n, explode)
    r, edge_line = sr_lite.second_chance(ledger, dice, turn, eid, r0, use, r0.hits < need,
                                         useful=cap is None or r0.hits < cap, on="matrix")
    return n, r0, r, edge_line


def _here(ledger: Ledger, hid: str, hp: dict, st: dict) -> dict:
    n = hostmap.node(hp, st.get("node"))
    if not n:                                          # (jacked in before hosts had maps: they're at the Entry)
        n = hostmap.entry(hp)
        st["node"] = n["id"]
        hostmap.see(st, hid, hp, [n["id"]])
    return n


def _route(hp, walked: list[str]) -> str:
    return " -> ".join(hostmap.node(hp, x)["name"] for x in walked)


def _reach(ledger, hid, hp, st, here, spot, what) -> tuple[dict, list[str]]:
    """Walk to where something is, if the way is open (one beat does both)."""
    if spot["id"] == here["id"]:
        return here, []
    walked, blocked = hostmap.walk(hp, st, hid, here["id"], spot["id"])
    if blocked:
        raise LedgerError(f"{what} is in {spot['name']} ({spot['color']}) - the way there stops at {blocked['name']} "
                          f"({blocked['color']}, locked): crack it first (hack).")
    st["node"] = spot["id"]
    hostmap.see(st, hid, hp, walked)
    return spot, [f"  Moves {_route(hp, walked)}"]


def edge_rides(ledger: Ledger, decker: str, action: str, target: str | None = None, node: str | None = None,
               forced: bool = False) -> bool:
    """Whether this beat rolls the decker's dice - the roll a called Edge rides on. Read-only, before the dice.
    jack_in, move and admin roll nothing; jack_out only against an active Tar Baby; control and data nothing on a node
    their login opens or that has no security (R16). Review: a jack_in took the one Edge reminder, and the hack it was
    called for went out without it (the T164 failure, in the Matrix)."""
    if action in ("jack_in", "move", "admin") or action not in ACTIONS or not ledger.get(decker):
        return False
    st = current(ledger, decker)                           # (a run that's over: act closes it and turns the beat away)
    hid = st.get("host")
    if action == "repair":
        return not hid
    h = ledger.get(hid) if hid else None
    if not h:
        return False                                       # (not jacked in: the call itself is turned away)
    hp = h["props"]
    if action == "jack_out":
        return bool(st.get("tarred") and not forced and any(ic["type"] == "tar baby" and ic["active"]
                                                            for ic in hp.get("ic", [])))
    if action in ("control", "data") and target:
        spot = hostmap.where(hp, target)                   # (not filed in the host yet: it lands behind security)
        return spot is None or hostmap.open_to(st, hid, spot) not in ("login", "open")
    if action == "control":                                # the building's system itself
        here = hostmap.node(hp, st.get("node"))
        spot = hostmap.node(hp, node) if node else (here if here and here["kind"] == "devices" else None)
        return bool(spot) and hostmap.open_to(st, hid, spot) not in ("login", "open")
    return action != "data"                                # (data with no file: the call itself is turned away)


def act(ledger: Ledger, dice, turn: int | None, decker: str, action: str, host: str | None = None,
        target: str | None = None, mode: str = "ar", effect: str = "", reason: str = "",
        forced: bool = False, edge: str | None = None, access: str | None = None, node: str | None = None) -> dict:
    """One Matrix beat: the decker's action, then the host's answer. Returns {card, traced, out}.
    edge: the decker's player spends Edge on the action roll. access (jack_in only): a real login the decker holds -
    a hijacked session, stolen credentials - opening every node at its level. node: where to move, or which node to
    crack or control (a name like 'Records' or 'Hub B')."""
    spend = {"use": sr_lite.edge_use(edge), "turn": turn}
    d_ent = ledger.require(decker)
    if action not in ACTIONS:
        raise LedgerError(f"action must be one of {', '.join(ACTIONS)}.")
    if sr_lite.condition(ledger, decker) in sr_lite.OUT:
        raise LedgerError(f"{d_ent['name']} is {sr_lite.condition(ledger, decker)} and can't do anything in the Matrix.")
    # A run that's over though nobody jacked out (over()) is closed first, quietly, so no beat plays from it. Live
    # (flag #11): at T88 a search, a hack or a jack-out would have played from the T46 dive's Overwatch 33, its alert
    # and its awake IC - only a jack-in started clean.
    ended = end_stale(ledger, turn, decker)
    st = state(ledger, decker)
    drating, dname = deck(ledger, decker)
    result = {"traced": False, "out": False, "host": host or st.get("host")}

    if action == "repair":                                # SR5 p. 228: a toolkit, an hour, a box per hit
        if st.get("host"):
            raise LedgerError(f"{d_ent['name']} has to jack out before working on the deck.")
        dmg = int(st.get("deck_damage", 0))
        if living(ledger, decker) or drating <= 0 or not dmg:
            raise LedgerError(f"{d_ent['name']}'s deck has nothing to repair.")
        _, parts = sr_lite.build_pool(ledger, decker, "electronics", "logic")
        n, r0, r, edge_line = _alone(ledger, dice, decker, parts, spend, need=dmg, cap=dmg)   # (short: boxes left)
        fixed = min(dmg, r.hits)
        st["deck_damage"] = dmg - fixed
        _save(ledger, decker, st)
        _record_roll(ledger, turn, decker, {"action": "repair", "skill": "electronics", "reason": reason}, parts, r,
                     fixed > 0, fixed, edge_line)
        ledger.log(turn, "matrix", decker, {"action": "repair", "fixed": fixed})
        return {"card": f"[MATRIX] {d_ent['name']} repairs {dname} (about an hour)\n"
                        f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r0.faces()} -> {r0.verdict()}\n"
                        + (edge_line + "\n" if edge_line else "")
                        + f"  {fixed} box{'es' * (fixed != 1)} fixed -> Deck {st['deck_damage']}/{deck_monitor(drating)}",
                **result}

    if action == "jack_in":
        if drating <= 0:
            raise LedgerError(f"{d_ent['name']} has no cyberdeck - hacking takes one (or Resonance).")
        if not living(ledger, decker) and int(st.get("deck_damage", 0)) >= deck_monitor(drating):
            raise LedgerError(f"{d_ent['name']}'s deck is bricked - it needs repair (matrix action repair) first.")
        h = ledger.require(host or "")
        if h["kind"] != "host":
            raise LedgerError(f"'{h['name']}' isn't a host. Introduce it with kind 'host' and a rating first.")
        scene = ledger.current_scene()
        hp = hostmap.ensure(ledger, h["id"], site=(scene or {}).get("location_id"))
        hid = h["id"]
        mode = "vr" if mode == "vr" else "ar"
        creds = access if access in LEVELS[1:] else None
        if st.get("host") and st["host"] != hid:          # into another host: they leave the one they were in, and
            _close(ledger, turn, decker, st)               # its IC stands down (live: Horizon sat at alert 2, every IC
        #                                                    awake, from T18 on - Filament went to KD-4 from inside it)
        # The Overwatch Score belongs to one run: it's back to 0 when the decker logs off. A jack-in that isn't
        # picking up a run still going on this host starts clean - the score of a dive that was jacked out of, or
        # that the table took back in the story without `!undo`, doesn't carry into the next one.
        # Picking up the same run means its last Matrix move was this turn or the one before (review of flag #11: a
        # re-dive three turns after a dive the table took back carried its Overwatch 33, the trace and the alert with
        # every IC awake - and the turn that took it back had "kept" it, the host being named in it). A run that sat
        # a story turn out is closed first - its IC stand down - and this one is new.
        last = st.get("last_turn")
        going = st.get("host") == hid and turn is not None and last is not None and turn - int(last) <= PICK_UP
        if st.get("host") == hid and not going:
            _close(ledger, turn, decker, st, seen=False)
            hp = hostmap.ensure(ledger, hid, site=(scene or {}).get("location_id"))
        if not going:                                      # a new run: no marks on them; a host that's had time cools
            if turn is not None and turn - int(hp.get("last_seen") or -STALE - 1) > STALE:
                hp["alert"] = 0
                hp.pop("ic_launched_turn", None)
                for ic in hp.get("ic", []):
                    ic.update(active=False, damage=0, node=ic.get("home"))
            hp["last_seen"] = turn
            _save_host(ledger, hid, hp)
            st.setdefault("cleared", {})[hid] = []
            st["traced"] = False                           # a trace is the run's (flags #17, #26), never the next one's
            st.pop("kept", None)                           # (and so is the story's word on it - keep())
        st.pop("ended", None)                              # (a new run: the engine's close of the last one is history)
        if creds:
            st.setdefault("creds", {})[hid] = creds
        start = hostmap.node(hp, st.get("node")) if going and st.get("node") else hostmap.entry(hp)
        st.update(host=hid, node=start["id"], mode=mode, overwatch=int(st.get("overwatch", 0)) if going else 0,
                  marks=int(st.get("marks", 0)) if going else 0,
                  deck_damage=int(st.get("deck_damage", 0)), tarred=False)
        _touch(ledger, decker, st, turn)
        hostmap.see(st, hid, hp, [start["id"]])
        _save(ledger, decker, st)
        how = "hot-sim VR (+2 dice; the body goes limp)" if mode == "vr" else "AR (eyes open, body aware)"
        login = (st.get("creds") or {}).get(hid)
        nxt = ", ".join(hostmap.describe(hp, st, hid, n) for n in hostmap.near(hp, start["id"]))
        lines = [f"[MATRIX] {d_ent['name']} jacks into {h['name']} (rating {rating(ledger, hid)}) - {how}",
                 f"  At {hostmap.describe(hp, st, hid, start)} · next: {nxt}",
                 f"  {'Login: ' + login + ' (opens every node at that level) · ' if login else ''}"
                 f"{overwatch_line(st['overwatch'])}"
                 + (f" · host {['quiet', 'noticed', 'on alert'][min(2, int(hp.get('alert', 0)))]}" if hp.get("alert") else ""),
                 "  New to this? !matrixhelp says what you can do in here · !net shows the map"]
        if reason:
            lines.insert(1, f"  Why    {reason}")
        ledger.log(turn, "matrix", decker, {"action": action, "host": hid, "mode": mode})
        return {"card": "\n".join(lines), **result}

    # A jack_out on a run with no sign of life for STALE turns is the GM tidying up after the story - it already logged
    # them off, or took the dive back - so it closes the way end_stale does: no Tar Baby contest, no host answer, no
    # dumpshock (review of flag #11: the cut result's "If the story logged them off, call matrix jack_out" played the
    # retconned T45 dive's Tar Baby on its stale Overwatch 33 - convergence, 6 Stun of dumpshock, TRACED - forced or not).
    alive = _alive(st)
    if action == "jack_out" and st.get("host") and turn is not None and alive is not None and turn - alive >= STALE:
        gone = st["host"]
        st["ended"] = {"turn": turn, "why": f"no Matrix move since T{st.get('last_turn')} - the story had moved on"}
        _close(ledger, turn, decker, st, seen=False)
        ledger.log(turn, "matrix", decker, {"action": "jack_out", "host": gone, "stale": st["ended"]["why"]})
        st = state(ledger, decker)
    # The engine's close - this beat's, or at an earlier turn's end (end_stale_runs) - answers the GM's own jack_out
    # once, quietly: review 2026-10-27, a run closed at T(n)'s end and the story logging the decker off at T(n+1) got
    # "isn't jacked in - start with action 'jack_in'" and an engine tool-error flag. Any other beat hears why.
    closed = st.get("ended") if not st.get("host") else None
    if action == "jack_out" and closed:                   # what the GM asked for is done - quietly, no dumpshock
        gone = ledger.get(st.get("last_host") or "")
        st.pop("ended")
        _save(ledger, decker, st)
        when = "" if closed.get("turn") == turn else f" at the end of T{closed.get('turn')}"
        return {"card": f"[MATRIX] {d_ent['name']} is out of the Matrix - the run on "
                        f"{(gone or {}).get('name', 'the host')} was already over ({closed.get('why') or ended}), so "
                        f"{'the engine closed it' if when else 'it closed'} quietly{when}: no dumpshock",
                **result, "out": True}
    if not st.get("host"):                                # (the GM's to fix - a jack-in first - not an engine fault)
        raise RulesRefusal(f"{d_ent['name']} isn't jacked in - start with action 'jack_in' and a host."
                           + closed_note(st, turn))
    hid = st["host"]
    h = ledger.require(hid)
    hr = rating(ledger, hid)
    hp = hostmap.ensure(ledger, hid)
    here = _here(ledger, hid, hp, st)
    vr = st.get("mode") == "vr"
    ow0 = int(st.get("overwatch", 0))
    heat = 0
    woke: list[str] = []                                   # IC the action itself woke this beat (a failed hack's guard)
    rec = {"action": action, "host": hid, "node": here["name"], "reason": reason}     # (the beat, for its rolls' rows)
    lines = [f"[MATRIX] {d_ent['name']} - {action.replace('_', ' ')} · {h['name']} (rating {hr}) · {here['name']}"
             + (" · hot-sim VR" if vr else " · AR")]
    if reason:
        lines.append(f"  Why    {reason}")

    if action == "jack_out":
        tar = next((ic for ic in hp.get("ic", []) if ic["type"] == "tar baby" and ic["active"]), None)
        if st.get("tarred") and tar and not forced:
            r, dres, rl = _contest(ledger, dice, decker, "hacking", None, vr, tar["rating"] * 2,
                                   f"Tar Baby IC ({tar['rating']}) doubled", edge=spend, rec={**rec, "ic": "tar baby"})
            lines += rl
            if r.hits <= dres.hits:
                lines.append("  STUCK: the Tar Baby holds - still jacked in")
                heat += dres.hits
                st["overwatch"] = ow0 + heat
                _touch(ledger, decker, st, turn)
                _save(ledger, decker, st)
                lines += _respond(ledger, dice, turn, decker, st, hid, result, illegal=False)
                return {"card": "\n".join(lines), **result}
            lines.append("  Cuts free of the Tar Baby")
        lines += _disconnect(ledger, dice, turn, decker, st, forced=forced)
        result["out"] = True
        return {"card": "\n".join(lines), **result}

    if action == "move":
        dest = hostmap.node(hp, node or target)
        if not dest:
            raise LedgerError("move where? Nodes: " + ", ".join(n["name"] for n in hp["nodes"]
                                                               if n["id"] in (st.get("seen") or {}).get(hid, [])))
        walked, blocked = hostmap.walk(hp, st, hid, here["id"], dest["id"])
        st["node"] = walked[-1]
        hostmap.see(st, hid, hp, walked)
        lines.append(f"  Moves {_route(hp, walked)}" if len(walked) > 1 else f"  Stays in {here['name']}")
        if blocked:
            lines.append(f"  STOPS: {blocked['name']} ({blocked['color']}, {hostmap.COLOR_TEXT[blocked['color']]}) is "
                         f"locked to {d_ent['name']} - crack it (hack) to go on")
        else:
            lines.append(f"  In {hostmap.describe(hp, st, hid, dest)}" + (f" - {hostmap.KIND_TEXT[dest['kind']].format(system=dest.get('system', ''))}"))
    elif action in ("hack", "brute_force"):
        tgt = hostmap.node(hp, node or target) if (node or target) else next(
            (n for n in hostmap.near(hp, here["id"]) if not hostmap.open_to(st, hid, n)), None)
        if not tgt:
            raise LedgerError(f"Nothing next to {here['name']} is locked to {d_ent['name']} - say which node to crack.")
        if hostmap.open_to(st, hid, tgt):
            raise LedgerError(f"{tgt['name']} is already open to {d_ent['name']} ({hostmap.open_to(st, hid, tgt)}) - "
                              "just move there.")
        if tgt["id"] not in here["near"]:
            walked, blocked = hostmap.walk(hp, st, hid, here["id"], tgt["id"])
            if blocked and blocked["id"] != tgt["id"]:
                raise LedgerError(f"{tgt['name']} is past {blocked['name']} ({blocked['color']}, locked) - crack that first.")
            st["node"] = walked[-1]
            hostmap.see(st, hid, hp, walked)
            here = hostmap.node(hp, st["node"])
            if len(walked) > 1:
                lines.append(f"  Moves {_route(hp, walked)}")
        nr = hostmap.rating(hr, tgt["color"])
        skill = "hacking" if action == "hack" else "cybercombat"
        r, dres, rl = _contest(ledger, dice, decker, skill, None, vr, nr * 2,
                               f"{tgt['name']} ({tgt['color']}, rating {nr}) doubled", edge=spend,
                               rec={**rec, "node": tgt["name"]})
        lines += rl
        heat += dres.hits + (4 if action == "brute_force" else 0)
        if r.hits > dres.hits:
            hostmap.clear(st, hid, tgt["id"])
            st["node"] = tgt["id"]
            hostmap.see(st, hid, hp, [tgt["id"]])
            lines.append(f"  SUCCESS: cracks {tgt['name']} and slips in"
                         + (" (loud: everyone in the host felt that)" if action == "brute_force" else "")
                         + f" - {hostmap.KIND_TEXT[tgt['kind']].format(system=tgt.get('system', ''))}")
        else:
            heat += 3
            st["marks"] = int(st.get("marks", 0)) + 1      # a failed intrusion leaves the host a mark on you (p. 231)
            lines.append(f"  FAILED: {tgt['name']} holds - and the host marks {d_ent['name']} ({st['marks']}/{TRACE_MARKS})")
            for ic in hp.get("ic", []):                    # the node's own guard wakes (Patrol only wakes on alert) -
                if not _may_launch(hp, turn):              # one, and that's the turn's one IC (flag #31: _respond)
                    break
                if ic.get("node") == tgt["id"] and not ic["active"] and ic["type"] != "patrol":
                    ic["active"] = True
                    ic["woke"] = turn
                    hp["ic_launched_turn"] = turn
                    woke.append(ic["type"])
                    lines.append(f"  {ic_name(ic['type'])} in {tgt['name']} wakes")
                    break
        if r.glitch:
            heat += 5
            lines.append("  GLITCH: a sloppy trace left behind")
    elif action == "search":
        _, parts = _pool(ledger, decker, "electronics", "intuition", vr)
        need, shift = threshold(ledger, decker, max(1, hr // 2))   # (more hits than that search further: a reroll
        n, r0, r, edge_line = _alone(ledger, dice, decker, parts, spend, need)   # counts; the dial shifts it, #27)
        lines.append(f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r0.faces()} -> {r0.verdict()} (needs {need}"
                     + (f" - {shift}" if shift else "") + ")")
        lines += [edge_line] if edge_line else []
        _record_roll(ledger, turn, decker, {**rec, "skill": "electronics"}, parts, r, r.hits >= need, r.hits - need,
                     edge_line, need=need)
        if r.hits >= need:                                 # (a search is legal: no Overwatch - SR5 p. 244)
            around = hostmap.within(hp, here["id"], 1 + (r.hits - need >= 2))
            hostmap.see(st, hid, hp, around, scan=True)
            st.setdefault("found", {})[hid] = True
            files = [ledger.get(t)["name"] + f" [{t}]" for t in here["things"] if ledger.get(t)]
            ics = [f"{ic_name(ic['type'])} in {hostmap.node(hp, ic['node'])['name']}" + (" (ACTIVE)" if ic["active"] else "")
                   for ic in hp.get("ic", []) if ic.get("node") in around]
            lines.append("  FOUND: " + (f"here: {', '.join(files)} · " if files else "")
                         + "nodes: " + ", ".join(hostmap.describe(hp, st, hid, hostmap.node(hp, x)) for x in around if x != here["id"])
                         + " · IC: " + (", ".join(ics) or "none nearby"))
        else:
            lines.append("  Nothing yet - the host keeps its secrets")
    elif action in ("control", "data"):
        if action == "control" and not target:             # the building's system itself: "loop the cameras"
            spot = hostmap.node(hp, node) if node else (here if here["kind"] == "devices" else None)
            if not spot or spot["kind"] != "devices":
                raise LedgerError("control what? Name a device, or a devices node: "
                                  + ", ".join(n["name"] for n in hp["nodes"] if n["kind"] == "devices"))
            what, tgt = spot["name"], None
        else:
            tgt = ledger.require(target or "")
            spot, what = hostmap.place(ledger, hid, tgt["id"]), tgt["name"]
            hp = hostmap.ensure(ledger, hid)               # (placing it saved the map: work on the fresh copy)
            spot, here = hostmap.node(hp, spot["id"]), hostmap.node(hp, here["id"])
        here, moved = _reach(ledger, hid, hp, st, here, spot, what)
        lines += moved
        how = hostmap.open_to(st, hid, here)
        if how in ("login", "open"):                       # a real login, or no security at all: it just opens (R16)
            ok = True
            lines.append(f"  {what}: " + ("a real login - it just opens, no roll" if how == "login"
                                          else "no security on this node - no roll"))
        else:
            nr = hostmap.rating(hr, here["color"])
            r, dres, rl = _contest(ledger, dice, decker, "electronics", None, vr, nr * 2, f"{here['name']} {nr} doubled",
                                   edge=spend, rec={**rec, "node": f"{here['name']} ({what})"})
            lines += rl                                    # inside their access it's legal: no Overwatch (p. 232, 244)
            ok = r.hits > dres.hits
        if not ok:
            lines.append(f"  FAILED: {what} doesn't respond")
        elif tgt is None:
            here["state"] = {"effect": effect or "under their control", "by": decker, "turn": turn}
            lines.append(f"  SUCCESS: {what} - {here['state']['effect']} (the building's {here.get('system', 'systems')})")
        elif action == "control" and tgt["kind"] in sr_lite.MACHINES:
            ledger.update_entity(tgt["id"], props={**tgt["props"], "controller": decker, "control": "remote"})
            lines.append(f"  SUCCESS: {tgt['name']} answers to {d_ent['name']} now")
        elif action == "data" and (effect or "copy").lower().startswith("copy"):
            cid = ledger.create_entity("item", f"Copy of {tgt['name']}", tgt["description"], tier=1,
                                       props={**tgt["props"], "file": True, "copied_from": tgt["id"]}, turn=turn or 0)
            ledger.give(decker, cid, 1)
            lines.append(f"  SUCCESS: copied {tgt['name']} -> {d_ent['name']} holds [{cid}]")
        else:
            ledger.update_entity(tgt["id"], props={**tgt["props"], "state": effect or ("controlled" if action == "control" else "edited")})
            if here["kind"] == "devices":
                here["state"] = {"effect": f"{tgt['name']}: {effect or 'controlled'}", "by": decker, "turn": turn}
            lines.append(f"  SUCCESS: {tgt['name']} - {effect or ('controlled' if action == 'control' else 'edited')}")
    elif action == "admin":
        if here["kind"] != "core":
            core = next(n for n in hp["nodes"] if n["kind"] == "core")
            raise LedgerError(f"Admin happens in the Core - {d_ent['name']} is in {here['name']}. Get to "
                              f"{core['name']} ({core['color']}) first.")
        want = (effect or "").lower()
        picks = set()
        if re.search(r"ic|agent|stand|shut|down|off|kill the ic", want):
            picks.add("stand_down")
        if re.search(r"alert|alarm|cancel|quiet|calm", want):
            picks.add("cancel_alert")
        if re.search(r"reveal|map|everything|nodes", want):
            picks.add("reveal")
        if not picks or re.search(r"all|everything", want):
            picks = set(ADMIN)
        if "stand_down" in picks:
            for ic in hp.get("ic", []):
                ic.update(active=False, damage=0, node=ic.get("home"))
            hp.pop("ic_launched_turn", None)
            st["tarred"] = False
            lines.append("  ADMIN: every IC in the host stands down")
        if "cancel_alert" in picks or "stand_down" in picks:
            hp["alert"] = 0
            lines.append("  ADMIN: the alert is cancelled - the host goes quiet")
        if "reveal" in picks:
            hostmap.see(st, hid, hp, [n["id"] for n in hp["nodes"]], scan=True)
            lines.append("  ADMIN: the whole map - every node, file and device")
    elif action == "fight":
        ic = _find_ic(hp, target, here["id"])
        r, dres, rl = _contest(ledger, dice, decker, "cybercombat", None, vr, ic["rating"] * 2,
                               f"{ic_name(ic['type'])} ({ic['rating']}) doubled", edge=spend, rec={**rec, "ic": ic["type"]})
        lines += rl
        heat += 2
        if r.hits > dres.hits:
            dmg = drating + (r.hits - dres.hits)
            ic["damage"] = int(ic.get("damage", 0)) + dmg
            mon = deck_monitor(ic["rating"])
            if ic["damage"] >= mon:
                ic.update(active=False, damage=0, node=ic.get("home"))
                if ic["type"] == "tar baby":
                    st["tarred"] = False
                lines.append(f"  CRASHED: {ic_name(ic['type'])} derezzes ({dmg} damage)")
            else:
                lines.append(f"  HIT: {dmg} damage -> {ic_name(ic['type'])} {ic['damage']}/{mon}")
        else:
            lines.append("  The IC slips the attack")
    elif action == "hide":
        r, dres, rl = _contest(ledger, dice, decker, "hacking", None, vr, hr * 2, f"Host {hr} doubled", edge=spend,
                               rec=rec)
        lines += rl
        if r.hits > dres.hits:
            cool = 2 * (r.hits - dres.hits)
            heat -= cool
            lines.append(f"  SUCCESS: spoofed the logs - Overwatch -{cool}")
        else:
            heat += dres.hits
            st["marks"] = int(st.get("marks", 0)) + 1
            lines.append(f"  FAILED: the host noticed the cleanup - and marks {d_ent['name']} ({st['marks']}/{TRACE_MARKS})")

    st["overwatch"] = max(0, ow0 + heat)
    _touch(ledger, decker, st, turn)
    _save(ledger, decker, st)
    _save_host(ledger, hid, hp)
    lines.append(f"  {overwatch_line(st['overwatch'])} ({heat:+d})" + ("" if action in ILLEGAL else " - legal, inside their access"))
    lines += _respond(ledger, dice, turn, decker, st, hid, result, illegal=action in ILLEGAL, woke=tuple(woke))
    ledger.log(turn, "matrix", decker, {"action": action, "host": hid, "node": state(ledger, decker).get("node"),
                                        "overwatch": state(ledger, decker).get("overwatch")})
    return {"card": "\n".join(lines), **result}


def _find_ic(hp: dict, target: str | None, at: str | None = None) -> dict:
    """An active IC by type - the one in the decker's node first (`at`), else anywhere in the host."""
    want = (target or "").lower().replace("ic", "").replace("_", " ").strip()
    live = [ic for ic in hp.get("ic", []) if ic["active"] and (not want or want in ic["type"])]
    if at:
        here = [ic for ic in live if ic.get("node") in (None, at)]
        if here:
            return here[0]
        if live:
            where = hostmap.node(hp, live[0].get("node")) or {}
            raise LedgerError(f"{ic_name(live[0]['type'])} isn't here - it's in {where.get('name', 'another node')}.")
    if live:
        return live[0]
    raise LedgerError("No active IC like that here. Active: "
                      + (", ".join(ic["type"] for ic in hp.get("ic", []) if ic["active"]) or "none"))


def _may_launch(hp: dict, turn: int | None) -> bool:
    """Whether the host may launch an IC this GM turn - one a turn, all told (flag #31: _respond)."""
    return turn is None or hp.get("ic_launched_turn") != turn


def _respond(ledger, dice, turn, decker, st, hid, result, illegal: bool = True, woke: tuple = ()) -> list[str]:
    """The host's answer: alert stages, IC launching, IC hunting and acting. Patrol IC only catches illegal moves -
    anyone working inside their access looks legitimate (SR5 p. 248). Once alerted, the host wakes one IC a turn, in
    its suite's order, where it lives (p. 247); awake IC comes for the decker a node a beat, and attacks when it
    shares their node - from the beat after it woke. At most one IC launches a GM turn, all told (flag #31, a player:
    one IC a turn from a host, no more - one GM turn is one SR5 Combat Turn, DESIGN §6a): an alert that jumped two
    stages at once launched Patrol and the suite's next together, a failed hack's node guard came with the alert's,
    and - review of the build - a turn of six beats woke the whole suite, one a beat (hp.ic_launched_turn holds the
    turn's launch; a failed hack's guard wake is that turn's one too). woke: the IC types the decker's own action woke
    this beat. An IC that woke on a turn's first beat still moves and hunts on its second (fresh is this call's)."""
    hp = _host_props(ledger, hid)
    if hp.get("nodes"):
        hostmap.ensure(ledger, hid)
        hp = _host_props(ledger, hid)
    name = ledger.require(decker)["name"]
    lines = []
    hp["last_seen"] = turn
    veiled = any(h["form"] == "static veil" for h in (ledger.require(decker)["props"].get("forms_sustained") or []))
    if illegal and any(ic["type"] == "patrol" and ic["active"] for ic in hp.get("ic", [])) and not veiled:
        st["overwatch"] += 2
        _save(ledger, decker, st)
        lines.append(f"  Patrol IC is watching: +2 -> {overwatch_line(st['overwatch'])}")
    ow = st["overwatch"]
    if ow >= CONVERGENCE:
        lines.append(f"  CONVERGENCE: the grid's watchdogs lock onto {name}")
        hp["alert"] = 2
        _save_host(ledger, hid, hp)
        hit, _ = _matrix_damage(ledger, dice, turn, decker, CONVERGENCE_DAMAGE, "convergence")
        lines += [f"  The grid's own hit: {hit[0]}"] + hit[1:]
        lines += _disconnect(ledger, dice, turn, decker, state(ledger, decker), forced=True)
        result.update(out=True, traced=True)               # (the trace is the hook the matrix tool files)
        lines.append(f"  TRACED: {ledger.require(hid)['name']} knows where {name}'s body is")
        return lines
    stage = 2 if ow >= ALERT else 1 if ow >= NOTICED else 0
    if stage > int(hp.get("alert", 0)):
        hp["alert"] = stage
    launched = []
    alert, ics = int(hp.get("alert", 0)), hp.get("ic", [])
    if alert >= 1 and not woke and _may_launch(hp, turn):  # one IC a turn: the dormant Patrol first, then the suite
        pick = next((ic for ic in ics if ic["type"] == "patrol" and not ic["active"]), None)
        if not pick and alert >= 2:
            pick = next((ic for ic in ics if ic["type"] != "patrol" and not ic["active"]), None)
        if pick:
            pick.update(active=True, woke=turn)
            hp["ic_launched_turn"] = turn
            launched.append(pick)
    fresh = set(woke) | {ic["type"] for ic in launched}   # (woke this beat: it moves from the next one)
    if launched:
        left = sum(1 for ic in hp.get("ic", []) if not ic["active"])
        lines.append(f"  HOST {'ALERT' if hp['alert'] >= 2 else 'NOTICED'}: launches "
                     + ", ".join(ic_name(ic["type"]) + (f" in {hostmap.node(hp, ic['node'])['name']}" if hp.get("nodes") and ic.get("node") else "")
                                 for ic in launched)
                     + (f" ({left} more IC still dormant)" if left and hp["alert"] >= 2 else ""))
    at = state(ledger, decker).get("node")
    for ic in hp.get("ic", []):
        if not ic["active"] or ic["type"] == "patrol" or ic["type"] in fresh or not state(ledger, decker).get("host"):
            continue
        if hp.get("nodes") and at and ic.get("node") and ic["node"] != at:
            route = hostmap.path(hp, ic["node"], at)
            ic["node"] = route[1] if len(route) > 1 else ic["node"]
            gap = len(hostmap.path(hp, ic["node"], at)) - 1
            lines.append(f"  {ic_name(ic['type'])} moves to {hostmap.node(hp, ic['node'])['name']}"
                         + (f" - {gap} node{'s' * (gap != 1)} from {name}" if gap else f" - it's on {name} now"))
            continue
        lines += _ic_attack(ledger, dice, turn, decker, ic, result)
        if not state(ledger, decker).get("host"):         # it threw them out: the jack-out stood the host's IC down -
            return lines                                   # this beat's copy mustn't write over that (live: KD-4 sat at
            #                                                alert 2 with every IC awake long after Filament was gone)
    _save_host(ledger, hid, hp)
    return lines


def _ic_attack(ledger, dice, turn, decker, ic, result) -> list[str]:
    st = state(ledger, decker)
    name = ledger.require(decker)["name"]
    fw = firewall(ledger, decker)
    a_parts, a_n = against(ledger, decker, f"{ic_name(ic['type'])} ({ic['rating']}) attack", ic["rating"] * 2)
    a = sr_lite.roll(dice, a_n)                        # (the dial's dice ride the IC's attack too: flags #27/#28)
    d_parts = [("Intuition", int(ledger.stat(decker, "intuition"))), ("Firewall", fw)]
    d_pool = sum(v for _, v in d_parts)
    dd = sr_lite.roll(dice, d_pool)
    net = a.hits - dd.hits
    atk = f"{a_n}d6" if len(a_parts) == 1 else f"{ic['rating'] * 2} + {sr_lite.fmt_parts(a_parts[1:])} = {a_n}d6"
    head = (f"  {ic_name(ic['type'])} ({ic['rating']}) attacks: {atk} -> {a.hits} hits vs "
            f"Intuition + Firewall {d_pool}d6 -> {dd.hits}")
    h = ledger.get(st.get("host") or "")
    spot = hostmap.node(h["props"], ic.get("node")) if h else None
    _record_roll(ledger, turn, decker, {"action": "defend", "host": st.get("host"), "ic": ic["type"],
                                        "node": (spot or {}).get("name")}, d_parts, dd, net <= 0, -net, vs=(a_parts, a))
    if net <= 0:
        return [head + " - misses"]
    if ic["type"] == "track":
        marks = int(st.get("marks", 0))
        if marks < TRACE_MARKS:
            return [head + f" - it has {name}'s signal but not enough marks to follow it home ({marks}/{TRACE_MARKS})"]
        st["traced"] = st.get("host")                     # this host, this run (traced_in) - flags #17, #26
        _save(ledger, decker, st)
        result["traced"] = True
        return [head + f" - TRACED: they know where {name}'s body is"]
    if ic["type"] == "tar baby":
        if st.get("tarred"):
            st["marks"] = int(st.get("marks", 0)) + 1      # stuck and hit again: the host marks them (p. 249)
        st["tarred"] = True
        _save(ledger, decker, st)
        return [head + f" - STUCK: {name} can't jack out until the Tar Baby is beaten"]
    dv = ic["rating"] + net
    if ic["type"] == "black ic":                       # the decker, never the deck (the owner, 2026-10-27; flags #30, #32)
        return _black_ic(ledger, dice, turn, decker, st, ic, dv, fw, head, result)
    hit, dead = _matrix_damage(ledger, dice, turn, decker, dv, ic["type"])
    out = [head + " - " + hit[0]] + hit[1:]
    if dead:
        out.append("  BRICKED: the deck dies")
        out += _disconnect(ledger, dice, turn, decker, state(ledger, decker), forced=True)
        result["out"] = True
    return out


def _matrix_damage(ledger, dice, turn, decker, dv: int, source: str) -> tuple[list[str], bool]:
    """Matrix damage - an IC's hit, convergence's - the table's model (the owner, 2026-10-27, a player's model; flags #29,
    #32): the deck soaks it with Device Rating + Firewall (the engine's Firewall: the rating plus firewall_bonus, as
    in the IC defense), takes it up to its full condition monitor, and what's past that lands on the decker as Stun,
    logged - enough of it knocks them out. A living persona has no deck to fry: it's all Stun, soaked by its own
    Device Rating (Resonance) + Firewall. Live, flag #29 (a player, T110: why the decker kept getting one-shot):
    the deck soaked with its rating alone - 4 dice - and damage piled up past the monitor, to Deck 14/10.
    Returns (card lines - the first goes after the attack's head - and whether the deck is bricked now)."""
    name = ledger.require(decker)["name"]
    drating, _ = deck(ledger, decker)
    fw = firewall(ledger, decker)
    parts = [("Device Rating", drating), ("Firewall", fw)]
    n = drating + fw
    soak = sr_lite.roll(dice, n)
    boxes = max(0, dv - soak.hits)
    how = f"{dv} Matrix damage, soaks {sr_lite.fmt_parts(parts)} = {n}d6 -> {soak.hits} hits"
    if living(ledger, decker):                        # no deck to fry: it hits the technomancer's mind
        sr_lite._apply_boxes(ledger, decker, boxes, "stun")
        ledger.log(turn, "damage", decker, {"boxes": boxes, "type": "stun", "status": sr_lite.condition(ledger, decker),
                                            "source": source})
        return [f"{how}: living persona takes {boxes}S -> {sr_lite.condition_line(ledger, decker)}"], False
    st = state(ledger, decker)
    mon = deck_monitor(drating)
    had = int(st.get("deck_damage", 0))
    onto = min(boxes, max(0, mon - had))               # the deck holds what its monitor has room for...
    past = boxes - onto
    st["deck_damage"] = min(mon, had + onto)           # (never past it: an older record's 14/10 reads 10/10)
    _save(ledger, decker, st)
    lines = [f"{how}: deck takes {onto} -> Deck {st['deck_damage']}/{mon}"]
    if past:                                           # ...and the rest is the decker's Stun
        sr_lite._apply_boxes(ledger, decker, past, "stun")
        ledger.log(turn, "damage", decker, {"boxes": past, "type": "stun", "status": sr_lite.condition(ledger, decker),
                                            "source": source, "overflow": "deck"})
        lines.append(f"  {past} past the full deck: {name} takes {past}S -> {sr_lite.condition_line(ledger, decker)}")
    return lines, st["deck_damage"] >= mon


def _black_ic(ledger, dice, turn, decker, st, ic, dv, fw, head, result) -> list[str]:
    """Black IC's hit: biofeedback straight to the decker - never the deck - soaked with Willpower + Firewall
    (flag #30, a player; the owner's call 2026-10-27). Physical in hot-sim VR, where it can kill, with one emergency
    jack-out roll (Willpower + Logic) first; Stun in AR. Before, an AR decker's deck took it like a Killer's, and the
    VR soak left the Firewall's firewall_bonus out."""
    name = ledger.require(decker)["name"]
    vr = st.get("mode") == "vr"
    dtype = "physical" if vr else "stun"
    parts = [("Willpower", int(ledger.stat(decker, "willpower"))), ("Firewall", fw)]
    n = sum(v for _, v in parts)
    soak = sr_lite.roll(dice, n)
    boxes = max(0, dv - soak.hits)
    how = (f"BIOFEEDBACK {dv}{dtype[0].upper()} (the deck's untouched), soaks {sr_lite.fmt_parts(parts)} = {n}d6 -> "
           f"{soak.hits} hits")
    pmax, _ = sr_lite.monitor_max(ledger, decker)
    tried = ""
    if vr and ledger.stat(decker, "physical_damage") + boxes > pmax:      # this would put them down: one way out
        e_parts = [("Willpower", int(ledger.stat(decker, "willpower"))), ("Logic", int(ledger.stat(decker, "logic")))]
        esc = sr_lite.roll(dice, sum(v for _, v in e_parts))
        need, shift = threshold(ledger, decker, ic["rating"] // 2 + 1)    # (the dial's shift: flags #27/#28)
        _record_roll(ledger, turn, decker, {"action": "emergency_jack_out", "host": st.get("host"), "ic": "black ic"},
                     e_parts, esc, esc.hits >= need, esc.hits - need, need=need)
        if esc.hits >= need:
            out = [head + f" - {how}: {boxes} would drop {name} - emergency jack-out "
                          f"{esc.pool}d6 -> {esc.hits} hits, made it (needs {need}" + (f" - {shift}" if shift else "")
                   + ")"]
            out += _disconnect(ledger, dice, turn, decker, st, forced=True)
            result["out"] = True
            return out
        tried = (f" - the emergency jack-out fails ({esc.pool}d6 -> {esc.hits} hits, needs {need}"
                 + (f" - {shift}" if shift else "") + ")")
    sr_lite._apply_boxes(ledger, decker, boxes, dtype)
    ledger.log(turn, "damage", decker, {"boxes": boxes, "type": dtype, "status": sr_lite.condition(ledger, decker),
                                        "source": "black ic"})
    return [head + f" - {how}{tried}: {name} takes {boxes} -> {sr_lite.condition_line(ledger, decker)}"]


def _disconnect(ledger, dice, turn, decker, st, forced: bool) -> list[str]:
    """Out of the Matrix - forced (dumped, bricked, yanked) or a clean logout - and the run closes (_close). A forced
    exit from hot-sim VR dumpshocks: 6S, resisted with Willpower + Logic. (When a brick's overflow has just landed,
    both do: the hit's Stun first, then the dumpshock.)"""
    name = ledger.require(decker)["name"]
    lines = []
    if forced and st.get("mode") == "vr":                  # dumpshock: the brain doesn't like being yanked
        boxes, soak = sr_lite.resist_damage(ledger, dice, turn, decker, 6, "stun", resist="drain")
        lines.append(f"  DUMPSHOCK: {name} is thrown out of VR")
        lines += ["  " + s for s in soak]
    _close(ledger, turn, decker, st)
    lines.append(f"  {name} is out of the Matrix" + ("" if forced else " (clean logout)"))
    return lines


def summary_lines(ledger: Ledger, eid: str, now: int | None = None) -> list[str]:
    """For the GM's packet: where a decker is, what's around them, how hot it's getting - and the whole map. A run
    that's over (over()) isn't here at all: they're out (flag #11 - forty turns of a LIMP Filament in KD-4)."""
    st = current(ledger, eid, now)
    if not st.get("host"):
        return []
    h = ledger.get(st["host"])
    if not h:
        return []
    hid = h["id"]
    hp = hostmap.ensure(ledger, hid)
    here = hostmap.node(hp, st.get("node")) or hostmap.entry(hp)
    drating, _ = deck(ledger, eid)
    fw = firewall(ledger, eid)
    name = ledger.require(eid)["name"]
    login = (st.get("creds") or {}).get(hid)
    lines = [f"{name} is in {h['name']} [{hid}] (rating {hp.get('rating', '?')}) at {here['name']} - "
             + ("hot-sim VR: their body is LIMP and helpless" if st.get("mode") == "vr" else "AR: aware of their body"),
             f"  {overwatch_line(int(st.get('overwatch', 0)))}"
             + (f" · login {login}" if login else "")
             + (f" · host marks on them {int(st.get('marks', 0))}/{TRACE_MARKS}" if st.get("marks") else "")
             + (" · living persona (Matrix damage is stun)" if living(ledger, eid)
                else f" · Deck {int(st.get('deck_damage', 0))}/{deck_monitor(drating)}")
             + f" · soaks: Matrix damage {drating + fw}, Black IC {int(ledger.stat(eid, 'willpower')) + fw}"
             + (" · STUCK (Tar Baby)" if st.get("tarred") else "") + (" · TRACED" if traced_in(st) else "")
             + f" · host {['quiet', 'noticed', 'ON ALERT'][min(2, int(hp.get('alert', 0)))]}",
             "  Next to them: " + ", ".join(hostmap.describe(hp, st, hid, n) for n in hostmap.near(hp, here["id"]))]
    seen = (st.get("seen") or {}).get(hid, [])
    rows = []
    for n in hp["nodes"]:
        things = [ledger.get(t)["name"] for t in n["things"] if ledger.get(t)]
        ics = [ic_name(ic["type"]) + ("!" if ic["active"] else "") for ic in hp.get("ic", []) if ic.get("node") == n["id"]]
        rows.append(f"{n['name']}({n['color'][0]}{'' if n['id'] in seen else ', unseen'})"
                    + (f"[{'; '.join(things)}]" if things else "") + (f"{{{', '.join(ics)}}}" if ics else "")
                    + (f"<{n['state']['effect']}>" if n.get("state") else "")
                    + " - " + "/".join(hostmap.node(hp, x)["name"] for x in n["near"]))
    lines.append("  Map (yours to narrate; they only know what they've seen - b/g/o/r = blue open, green, orange, red "
                 "admin-only; [files/devices] {IC, ! = awake} <building state>): " + " | ".join(rows))
    lines[1:1] = dress_lines(ledger, hid)
    idle = idle_line(ledger, eid, now)                     # (a quiet run's countdown - right under where they are)
    if idle:
        lines.insert(1, idle)
    return lines


def dress_lines(ledger: Ledger, hid: str) -> list[str]:
    """The host's look and its IC's (ic_dressing) - THE MATRIX section's, and a jack_in's result for the GM: at this
    table a dive is jack_in, every beat and the narration in one turn (live T121, T126, T131), and on that turn there
    is no THE MATRIX section yet (review of flag #35)."""
    h = ledger.require(hid)
    if not h["description"]:
        return []
    dress = [f"  The host looks like: {h['description']} (dress its nodes in that sculpting)"]
    looks = ic_dressing(h["description"], [ic["type"] for ic in (h["props"] or {}).get("ic", [])])
    if looks:
        dress.append("  Its IC (call it IC, and play it as the host sculpts it - what it looks like says who built it): "
                     + looks)
    return dress


# Live, flag #35 (T116, a player): a dive was narrated like the meat world - 'slips past the guard' - with nothing of
# the net in it and none of the flavor a sculpted host gives its IC (a guard who looks like a cop from an old
# black-and-white show, say). The host's description had the IC's look all along ("IC dressed as night porters with
# brass keys"); the packet's map gave its IC as bare types.
IC_WORD = re.compile(r"\bICE?\b")                                  # (capitals: 'ice' in a sentence is just ice)
IC_TYPE_WORDS = {"patrol": "patrol", "track": "track", "killer": "killer", "tar baby": r"tar[- ]?baby", "black ic": "black"}


def ic_looks(description: str) -> dict[str, str]:
    """How a host's description sculpts its IC: {an IC type, or '' for IC in general: the words}. 'a sleepy bellhop
    patrol IC pushing a luggage cart' is the Patrol's; 'IC paces the halls as ushers with torches' every IC's."""
    out: dict[str, str] = {}
    for sentence in re.split(r"[.;:!?]+\s*", description or ""):
        for piece in re.split(r",\s+", sentence):
            if not IC_WORD.search(piece):
                continue
            piece = re.sub(r"^(?:and|but|while|with|where|its|their)\s+", "", piece.strip(), flags=re.I)
            kind = next((k for k, w in IC_TYPE_WORDS.items() if re.search(rf"\b{w}\s+ICE?\b", piece, re.I)), "")
            out[kind] = f"{out[kind]}; {piece}" if kind in out else piece
    return out


def ic_dressing(description: str, types: list[str]) -> str:
    """The packet's line of IC looks for these IC types (ic_looks): each type its own look, else the host's look for
    IC in general, else a nudge to give it one in the host's sculpting."""
    looks, types = ic_looks(description), list(dict.fromkeys(types))
    if not types:
        return ""
    bits = [f"{ic_name(t)} - {looks[t]}" for t in types if looks.get(t)]
    rest = [ic_name(t) for t in types if not looks.get(t)]
    if rest:
        bits.append(", ".join(rest) + (f" - {looks['']}" if looks.get("") else
                                       ": no look on file - give it one in the host's sculpting (and note it)"))
    return " · ".join(bits)


# ── the hosts on file, for the GM to tell apart ─────────────────────────
# Live, flag #36 (T120): the post named the rating-3 camera system as Filament's target - and the GM dove the
# rating-5 Larkspur host, the only host it had on file, until !undo. Nothing showed the GM which hosts there were, how
# hard each was, or what each ran, so "the cameras" went to the building's main host. HOSTS_SHOWN is the packet's cap.
HOSTS_SHOWN = 6
HOST_RECENT = 10     # turns: a host in a turn's memory this recently is "in play lately"
HOST_LOOK_CUT = 200  # characters of a host's look on its HOSTS ON FILE line (its IC's look rides after the cut)


def host_line(ledger: Ledger, hid: str, location_id: str | None = None) -> str:
    """One host for the packet's HOSTS ON FILE: its rating and the IC it runs, what it runs (the building's systems
    on its map - or the map its first jack-in will draw - and the files and devices it holds), its site, its alert,
    and its look. Read-only: it draws no map."""
    h = ledger.require(hid)
    hp = h["props"]
    r = int(hp.get("rating", 4))
    nodes = hp.get("nodes") or hostmap.generate(hid, r)          # (hostmap.generate: the same map, every time)
    runs = [n["name"] for n in nodes if n["kind"] in ("devices", "comms")]
    held = [i["name"] for i in ledger.holdings(hid)]
    ics = [ic["type"] for ic in hp["ic"]] if hp.get("ic") else ic_suite(r)
    bits = [f"{h['name']} [{hid}] - rating {r} ({r * 2}d6 against a decker; IC: {', '.join(ic_name(t) for t in ics)})",
            "runs " + (", ".join(runs) or "nothing of the building's") + (f"; holds {', '.join(held)}" if held else "")]
    site = ledger.get(hp.get("site") or "")         # (hostmap.ensure: where its first jack-in came from - the
    if site:                                         # building, on site; a remote dive's booth, not the building)
        bits.append("site: here" if site["id"] == location_id else f"site: {site['name']}")
    alert = int(hp.get("alert", 0))
    if alert:
        bits.append("NOTICED" if alert == 1 else "ON ALERT")
    if h["description"]:
        d = h["description"]
        shown = d if len(d) <= HOST_LOOK_CUT + 20 else d[:HOST_LOOK_CUT].rsplit(" ", 1)[0] + "..."
        bits.append(shown)
        # The cut kept the IC's look off the line: live, 6 of the 7 hosts' (Bellevue's janitor-bot Patrol IC, Horizon's
        # paper cranes) - and a jack-in turn has no THE MATRIX section to give it (review of flag #35).
        lost = [p for look in ic_looks(d).values() for p in look.split("; ") if p not in shown]
        if lost:
            bits.append("its IC: " + "; ".join(lost))
    return " · ".join(bits)


_GENERIC = {"the", "a", "an", "old", "new", "main", "private", "public", "local", "corporate", "building", "city"}


def host_mentions(ledger: Ledger, text: str) -> list[tuple[str, int, int, str]]:
    """Each place a post names a host, in order: (host id, start, end, how) - how is 'name' (its name, an alias, or
    the name without the 'host': 'the Bellevue Arcade Building Services'), 'short' (its first word and 'host': 'the
    Larkspur host', 'Larkspur's host') or 'holds' (a file or device it holds: the camera archive is Bellevue's host's).
    Where, so a reader can tell going after a host from ruling it out or just remembering it (turn.matrix_asks)."""
    low = (text or "").lower()

    def spans(phrase: str) -> list[tuple[int, int]]:
        if len(phrase) < 3:
            return []
        return [m.span() for m in re.finditer(rf"(?<![a-z0-9]){re.escape(phrase)}(?![a-z0-9])", low)]
    out = []
    for h in ledger.entities(kind="host"):
        name = h["name"].lower()
        base = re.sub(r"[\s-]+host$", "", name).strip()
        first = next((w for w in re.findall(r"[a-z0-9][a-z0-9'-]*", base) if w not in _GENERIC), "")
        first = first.removesuffix("'s")
        other = ledger.find(base)                            # ('the Larkspur Room' is the place, when one's on file)
        forms = ([(f, "name") for f in [name, *(a.lower() for a in h["aliases"] if a)]]
                 + ([(base, "name")] if not other or other["id"] == h["id"] else [])
                 + ([(f"{first} host", "short"), (f"{first}'s host", "short")] if first else []))
        taken: list[tuple[int, int]] = []
        for form, how in forms:                              # (the longest form at a place: the name over 'X host')
            for a, b in spans(form):
                if not any(a < y and x < b for x, y in taken):
                    taken.append((a, b))
                    out.append((h["id"], a, b, how))
    for name, eid in ledger.name_index():                   # a file or device the post names: whose host holds it
        for a, b in spans(name):
            out += [(o, a, b, "holds") for o in ledger.holders(eid) if (ledger.get(o) or {}).get("kind") == "host"]
    return sorted(out, key=lambda m: (m[1], -m[2]))


def named_hosts(ledger: Ledger, text: str) -> list[str]:
    """The hosts a post names (host_mentions): by name or alias, the way people shorten one - without the 'host' ('the
    Larkspur Room'), or its first word and 'host' ('the Larkspur host', 'Larkspur's host') - or through a file or device
    it holds that the post names (the camera archive is Bellevue's host's). For the packet's HOSTS ON FILE: a host
    merely mentioned is listed - whether the post goes after it is turn.matrix_asks's to read."""
    return list(dict.fromkeys(m[0] for m in host_mentions(ledger, text)))
