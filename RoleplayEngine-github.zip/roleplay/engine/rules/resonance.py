"""Technomancers (DESIGN.md §7b): the Matrix without a deck.

A technomancer has Resonance and a living persona - their mind is the deck (device rating = Resonance),
so they jack into hosts like a decker, and Matrix damage hits them as stun instead of frying hardware.
Complex forms are the Matrix's spells: Software + Resonance [Level] - the Level is the limit on hits (SR5
p. 250) - at a Level from 1 to Resonance x 2, and fading (the form's code, L-1 is the Level minus 1, min 2)
resisted with Willpower + Resonance - physical when the threading hits beat their Resonance (p. 251-252).
Sprites are compiled with Compiling + Resonance against the sprite's Level; net hits are tasks owed, fading
is twice the sprite's hits, physical when the Level is over their Resonance (p. 252). Each sprite type does
something real: Crack (+Level dice on your next hack), Fault (strikes IC), Data (finds files), Machine
(takes a device), Courier (narrative: carries data, hides your trail in the fiction).
"""
from __future__ import annotations

import re

from ..ledger import Ledger, LedgerError, RulesRefusal
from . import matrix, sr_lite

FORMS = {
    "resonance spike": dict(name="Resonance Spike", fading=-1, kind="spike",
                            text="a spike of pure Resonance - damages active IC, or a drone's electronics"),
    "puppeteer": dict(name="Puppeteer", fading=2, kind="control",
                      text="seizes a device without any access - loud (+4 Overwatch)"),
    "cleaner": dict(name="Cleaner", fading=0, kind="cleaner", text="scrubs the trail: Overwatch -hits"),
    "static veil": dict(name="Static Veil", fading=-1, kind="sustained",
                        text="Patrol IC can't see you: no watching heat while it's held"),
    "editor": dict(name="Editor", fading=-1, kind="data", text="copies or rewrites a file without access"),
    "infusion of firewall": dict(name="Infusion of Firewall", fading=-2, kind="sustained",
                                 text="+hits Firewall against IC while held"),
}
SPRITES = {
    "courier": ["carry data across the Matrix", "hash: hide a file", "cookie: tag a persona"],
    "crack": ["assist a hack: +Level dice on your next Matrix action", "suppression: delay IC"],
    "data": ["search: finds files and IC in the host", "decryption"],
    "fault": ["electron storm: strikes active IC", "accident"],
    "machine": ["gremlins: takes or breaks a device in the host", "diagnostics"],
}
LEARN_COST = 4                                    # a complex form, like SR5 (p. 107)
FADING_MIN = 2                                    # "can never be less than 2 DV" (SR5 p. 252)
# A code typed after a form's name ('!advance form Puppeteer L+2') is the sheets' label, not the name.
_CODE = re.compile(r"(?:\s+|\s*\()(?:fading\s+)?L\s*(?:[-+−–]\s*\d+)?\s*\)?\s*$", re.I)


def form(name: str) -> str:
    key = _CODE.sub("", (name or "").strip()).strip().lower().replace("_", " ").replace("-", " ")
    if key not in FORMS:
        raise LedgerError(f"No complex form '{name}'. Forms: {', '.join(f['name'] for f in FORMS.values())}.")
    return key


def fading_code(mod: int) -> str:
    """A fading modifier as the book prints a form's FV, compactly: 'L-1', 'L+2' - and 'L+0', where a spell's
    zero is a bare F (SR5 p. 252-253)."""
    return f"L{mod:+d}"


def fading_value(level: int, mod: int) -> int:
    return max(FADING_MIN, level + mod)


def form_label(key: str) -> str:
    """'Puppeteer L+2' - the name with its fading code, the way every list shows a form."""
    return f"{FORMS[key]['name']} {fading_code(FORMS[key]['fading'])}"


def form_at(key: str, level: int) -> str:
    """'Puppeteer L+2 (8)' - the label with the fading it costs at that Level."""
    return f"{form_label(key)} ({fading_value(level, FORMS[key]['fading'])})"


def learnable(ledger: Ledger, eid: str) -> list[str]:
    """The forms a technomancer could still learn. None for an empty list: no list on file means they know every form
    (thread enforces only a list it has), so learning one mustn't cut them down to it (magic.learnable, live review)."""
    have = list(ledger.require(eid)["props"].get("forms") or [])
    return [k for k in FORMS if have and k not in have]


def _emerged(ledger: Ledger, eid: str) -> int:
    r = int(ledger.stat(eid, "resonance", 0))
    if r <= 0:
        raise LedgerError(f"{ledger.require(eid)['name']} hasn't Emerged - no Resonance to work with.")
    return r


def _fade(ledger, dice, turn, techno: str, dv: int, physical: bool, over: str = "hits over Resonance",
          how: str = "") -> list[str]:
    """Resist and take fading. over: why it's physical - a thread's hits beat Resonance, a sprite's Level did.
    how: where the number came from ('Editor L-1 at Level 6')."""
    dv = max(FADING_MIN, dv)
    parts = [("Willpower", int(ledger.stat(techno, "willpower"))), ("Resonance", int(ledger.stat(techno, "resonance")))]
    n = sum(v for _, v in parts)
    r = sr_lite.roll(dice, n)
    boxes = max(0, dv - r.hits)
    dtype = "physical" if physical else "stun"
    sr_lite._apply_boxes(ledger, techno, boxes, dtype)
    ledger.log(turn, "damage", techno, {"boxes": boxes, "type": dtype, "status": sr_lite.condition(ledger, techno),
                                        "source": "fading"})
    name = ledger.require(techno)["name"]
    return [f"  Fading {dv}{f'P ({over})' if physical else 'S'}" + (f" · {how}" if how else ""),
            f"    Resist {sr_lite.fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.hits} hits",
            f"    {name} takes {boxes} {dtype} -> {sr_lite.condition_line(ledger, techno)}"]


def _in_host(ledger: Ledger, techno: str, turn: int | None = None) -> tuple[str, dict]:
    """The host they're threading in. A run the story left behind (matrix.over) is closed first, quietly, as act
    does - nothing plays from it - and the refusal says so, whichever turn closed it (matrix.closed_note)."""
    matrix.end_stale(ledger, turn, techno)
    st = matrix.state(ledger, techno)
    if not st.get("host"):                     # (the GM's to fix - a jack-in first - not an engine fault)
        raise RulesRefusal(f"{ledger.require(techno)['name']} isn't in a host - jack in first (matrix jack_in)."
                           + matrix.closed_note(st, turn))
    return st["host"], st


def thread(ledger: Ledger, dice, turn: int | None, techno: str, form_name: str, level: int,
           target: str | None = None, effect: str = "", reason: str = "") -> dict:
    t = ledger.require(techno)
    res = _emerged(ledger, techno)
    if sr_lite.condition(ledger, techno) in sr_lite.OUT:
        raise LedgerError(f"{t['name']} is {sr_lite.condition(ledger, techno)} and can't thread anything.")
    key = form(form_name)
    f = FORMS[key]
    known = list(t["props"].get("forms") or [])
    if known and key not in known:
        raise LedgerError(f"{t['name']} doesn't know {f['name']} (learning one: {LEARN_COST} karma).")
    level = max(1, min(res * 2, int(level or res)))
    hid, st = _in_host(ledger, techno, turn)
    hr = matrix.rating(ledger, hid)
    vr = st.get("mode") == "vr"
    n, parts = matrix._pool(ledger, techno, "software", None, vr)
    r = sr_lite.roll(dice, n)
    hits = min(r.hits, level)                     # Software + Resonance [Level]: the Level is the limit (SR5 p. 250)
    lines = [f"[MATRIX] {t['name']} threads {f['name']} at Level {level}" + (" (over Resonance)" if level > res else ""),
             f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()}"
             + (f" (limit: Level {level} -> {hits})" if hits < r.hits else "")]
    if reason:
        lines.insert(1, f"  Why    {reason}")
    heat = 0
    hp = dict(ledger.require(hid)["props"])
    rec = {"action": "thread", "host": hid, "form": f["name"], "skill": "software", "reason": reason}
    vs, ok, net = None, hits > 0, hits                    # (the record's: what it was against, and how it went)
    if f["kind"] == "spike":
        tgt = ledger.find(target or "") if target else None
        if tgt and tgt["kind"] in sr_lite.MACHINES:
            d_parts = [(f"{tgt['name']} (Pilot doubled)", int(ledger.stat(tgt["id"], "pilot", 1)) * 2)]
            d = sr_lite.roll(dice, d_parts[0][1])
            net = hits - d.hits
            vs, ok = (d_parts, d), net > 0
            heat += d.hits
            if net > 0:
                dv = level + net
                sr_lite._apply_boxes(ledger, tgt["id"], dv, "physical")
                lines.append(f"  {tgt['name']}'s electronics burn: {dv} -> {sr_lite.condition_line(ledger, tgt['id'])}")
            else:
                lines.append(f"  {tgt['name']} shrugs it off")
        else:
            ic = matrix._find_ic(hp, target)
            d_parts, d_n = matrix.against(ledger, techno, f"{matrix.ic_name(ic['type'])} ({ic['rating']}) doubled",
                                          ic["rating"] * 2)          # (the table's dial: flags #27/#28)
            d = sr_lite.roll(dice, d_n)
            net = hits - d.hits
            vs, ok = (d_parts, d), net > 0
            rec["ic"] = ic["type"]
            lines.append(f"  vs     {matrix.vs_text(d_parts, d_n)} -> {d.faces()} -> {d.hits} hits")
            heat += 2
            if net > 0:
                ic["damage"] = int(ic.get("damage", 0)) + level + net
                mon = matrix.deck_monitor(ic["rating"])
                if ic["damage"] >= mon:
                    ic.update(active=False, damage=0)
                    if ic["type"] == "tar baby":
                        st["tarred"] = False
                    lines.append(f"  CRASHED: {matrix.ic_name(ic['type'])} derezzes")
                else:
                    lines.append(f"  HIT: {level + net} -> {matrix.ic_name(ic['type'])} {ic['damage']}/{mon}")
            else:
                lines.append(f"  {matrix.ic_name(ic['type'])} slips it")
    elif f["kind"] in ("control", "data"):
        tgt = ledger.require(target or "")
        d_parts, d_n = matrix.against(ledger, techno, f"Host {hr} doubled", hr * 2)
        d = sr_lite.roll(dice, d_n)
        vs, ok, net = (d_parts, d), hits > d.hits, hits - d.hits
        heat += d.hits + (4 if f["kind"] == "control" else 0)
        lines.append(f"  vs     {matrix.vs_text(d_parts, d_n)} -> {d.faces()} -> {d.hits} hits")
        if hits > d.hits:
            if f["kind"] == "control" and tgt["kind"] in sr_lite.MACHINES:
                ledger.update_entity(tgt["id"], props={**tgt["props"], "controller": techno, "control": "remote"})
                lines.append(f"  SUCCESS: {tgt['name']} answers to {t['name']} now - no access needed")
            elif f["kind"] == "data" and (effect or "copy").lower().startswith("copy"):
                cid = ledger.create_entity("item", f"Copy of {tgt['name']}", tgt["description"], tier=1,
                                           props={**tgt["props"], "file": True, "copied_from": tgt["id"]}, turn=turn or 0)
                ledger.give(techno, cid, 1)
                lines.append(f"  SUCCESS: copied {tgt['name']} -> [{cid}]")
            else:
                ledger.update_entity(tgt["id"], props={**tgt["props"], "state": effect or "rewritten"})
                lines.append(f"  SUCCESS: {tgt['name']} - {effect or 'rewritten'}")
        else:
            heat += 2
            lines.append(f"  FAILED: {tgt['name']} doesn't answer")
    elif f["kind"] == "cleaner":
        cool = hits
        heat -= cool
        lines.append(f"  The trail thins: Overwatch -{cool}")
    elif f["kind"] == "sustained":
        if hits <= 0:
            lines.append("  It doesn't take")
        else:
            held = list(t["props"].get("forms_sustained") or [])
            held.append({"form": key, "level": level, "hits": hits})
            ledger.update_entity(techno, props={**ledger.require(techno)["props"], "forms_sustained": held})
            ledger.set_stat(techno, "sustaining_forms", len(held))
            if key == "infusion of firewall":
                ledger.add_stat(techno, "firewall_bonus", hits)
            lines.append(f"  Holds with {hits} hits - {f['text']} (-2 dice while held)")
    ledger.update_entity(hid, props=hp)
    # (on the record like every Matrix roll - flag #25; the Level's limit is on the hits, the dice are the roll's)
    matrix._record_roll(ledger, turn, techno, rec, parts, r, ok, net, vs=vs)
    st = matrix.state(ledger, techno) | {"tarred": st.get("tarred", False)}
    st["overwatch"] = max(0, int(st.get("overwatch", 0)) + heat)
    matrix._touch(ledger, techno, st, turn)       # (a Matrix move: the run's alive - matrix.over)
    matrix._save(ledger, techno, st)
    lines.append(f"  {matrix.overwatch_line(st['overwatch'])} ({heat:+d})")
    # Physical when the threading HITS beat Resonance, like a spell's hits against Magic (SR5 p. 251-252) - it was
    # Level > Resonance here, the original build's rule that §7g took out of the spells. With the Level as the
    # limit, it still takes a Level over Resonance to get there.
    lines += _fade(ledger, dice, turn, techno, fading_value(level, f["fading"]), hits > res,
                   how=f"{form_label(key)} at Level {level}"
                   + (", min 2" if level + f["fading"] < FADING_MIN else ""))
    out = {"traced": False, "out": False, "host": hid}
    if matrix.state(ledger, techno).get("host"):
        lines += matrix._respond(ledger, dice, turn, techno, matrix.state(ledger, techno), hid, out)
    ledger.log(turn, "thread", techno, {"form": key, "level": level, "hits": hits})
    return {"card": "\n".join(lines), **out}


def release(ledger: Ledger, techno: str, form_name: str | None = None) -> str:
    t = ledger.require(techno)
    held = list(t["props"].get("forms_sustained") or [])
    key = form(form_name) if form_name else None
    drop = [h for h in held if key is None or h["form"] == key]
    if not drop:
        raise LedgerError(f"{t['name']} isn't holding {FORMS[key]['name'] if key else 'any form'}.")
    for h in drop:
        if h["form"] == "infusion of firewall":
            ledger.add_stat(techno, "firewall_bonus", -h["hits"])
    keep = [h for h in held if h not in drop]
    ledger.update_entity(techno, props={**t["props"], "forms_sustained": keep})
    ledger.set_stat(techno, "sustaining_forms", len(keep))
    return f"[MATRIX] {t['name']} lets go of " + ", ".join(FORMS[h["form"]]["name"] for h in drop)


def veiled(ledger: Ledger, eid: str) -> bool:
    return any(h["form"] == "static veil" for h in (ledger.require(eid)["props"].get("forms_sustained") or []))


# ── sprites ─────────────────────────────────────────────────────────────

def compile_sprite(ledger: Ledger, dice, turn: int | None, techno: str, kind: str, level: int, reason: str = "") -> dict:
    t = ledger.require(techno)
    res = _emerged(ledger, techno)
    if not ledger.stat(techno, "compiling", 0):
        raise LedgerError(f"{t['name']} has no Compiling skill.")
    kind = (kind or "").lower().replace(" sprite", "").strip()
    if kind not in SPRITES:
        raise LedgerError(f"Sprite types: {', '.join(SPRITES)}.")
    level = max(1, min(res * 2, int(level or res)))
    n, parts = sr_lite.build_pool(ledger, techno, "compiling")
    r = sr_lite.roll(dice, n)
    s = sr_lite.roll(dice, level)
    net = r.hits - s.hits
    lines = [f"[MATRIX] {t['name']} compiles a {kind} sprite at Level {level}" + (" (over Resonance)" if level > res else ""),
             f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()}",
             f"  vs     Sprite Level {level} = {level}d6 -> {s.faces()} -> {s.hits} hits"]
    if reason:
        lines.insert(1, f"  Why    {reason}")
    sid = None
    if net <= 0:
        lines.append("  The code won't cohere - no sprite")
    else:
        name = f"{t['name']}'s {kind} sprite"
        sid = ledger.create_entity("sprite", name, f"a Level {level} {kind} sprite", tier=1,
                                   props={"type": kind, "level": level, "tasks": net, "owner": t["id"],
                                          "powers": SPRITES[kind]}, turn=turn or 0)
        ledger.set_stat(sid, "level", level)
        lines.append(f"  COMPILED: {name} [{sid}] owes {net} task(s) - {'; '.join(SPRITES[kind])}")
    # Compiling stays Level over Resonance - that one is the book's (p. 252).
    lines += _fade(ledger, dice, turn, techno, s.hits * 2, level > res, over="Level over Resonance",
                   how=f"2 x {s.hits} sprite hit{'' if s.hits == 1 else 's'}"
                   + (", min 2" if s.hits * 2 < FADING_MIN else ""))
    ledger.log(turn, "compile", techno, {"sprite": sid, "kind": kind, "level": level, "tasks": max(0, net)})
    return {"card": "\n".join(lines), "sprite": sid}


def sprite_task(ledger: Ledger, dice, turn: int | None, sprite: str, task: str = "", target: str | None = None) -> dict:
    sp = ledger.require(sprite)
    if sp["kind"] != "sprite" or sp["status"] != "active":
        raise LedgerError(f"{sp['name']} isn't an active sprite.")
    owner = sp["props"].get("owner")
    lvl = int(sp["props"].get("level", 1))
    kind = sp["props"].get("type")
    lines = [f"[MATRIX] {sp['name']}: {task or SPRITES[kind][0]}"]
    out = {"traced": False, "out": False, "host": matrix.live(ledger, owner) if owner else None}
    if kind == "crack":
        ledger.set_stat(owner, "sprite_assist", lvl)
        lines.append(f"  {ledger.require(owner)['name']}'s next Matrix action gets +{lvl} dice")
    elif kind == "fault" and out["host"]:
        hp = dict(ledger.require(out["host"])["props"])
        ic = matrix._find_ic(hp, target)
        a, d = sr_lite.roll(dice, lvl * 2), sr_lite.roll(dice, ic["rating"] * 2)
        net = a.hits - d.hits
        if net > 0:
            ic["damage"] = int(ic.get("damage", 0)) + lvl + net
            if ic["damage"] >= matrix.deck_monitor(ic["rating"]):
                ic.update(active=False, damage=0)
                lines.append(f"  Electron storm: {matrix.ic_name(ic['type'])} derezzes")
            else:
                lines.append(f"  Electron storm: {lvl + net} to {matrix.ic_name(ic['type'])}")
        else:
            lines.append(f"  Electron storm: {matrix.ic_name(ic['type'])} weathers it")
        ledger.update_entity(out["host"], props=hp)
    elif kind == "data" and out["host"]:
        st = matrix.state(ledger, owner)
        st.setdefault("found", {})[out["host"]] = True
        from . import hostmap                           # the sprite maps the host: every node, and what's in it
        hp = hostmap.ensure(ledger, out["host"])
        hostmap.see(st, out["host"], hp, [n["id"] for n in hp["nodes"]], scan=True)
        matrix._save(ledger, owner, st)
        files = [i["name"] for i in ledger.holdings(out["host"])]
        hp = ledger.require(out["host"])["props"]
        lines.append("  Found: files: " + (", ".join(files) or "nothing worth taking") + " · security: "
                     + (", ".join(matrix.ic_name(ic["type"]) for ic in hp.get("ic", [])) or "none"))
    elif kind == "machine" and target:
        tgt = ledger.require(target)
        hr = matrix.rating(ledger, out["host"]) if out["host"] else 3
        a, d = sr_lite.roll(dice, lvl * 2), sr_lite.roll(dice, hr * 2)
        if a.hits > d.hits:
            if tgt["kind"] in sr_lite.MACHINES:
                ledger.update_entity(tgt["id"], props={**tgt["props"], "controller": owner, "control": "remote"})
                lines.append(f"  Gremlins: {tgt['name']} answers to {ledger.require(owner)['name']}")
            else:
                ledger.update_entity(tgt["id"], props={**tgt["props"], "state": task or "glitched"})
                lines.append(f"  Gremlins: {tgt['name']} - {task or 'glitched'}")
        else:
            lines.append(f"  Gremlins: {tgt['name']} holds")
    left = int(sp["props"].get("tasks", 0)) - 1
    ledger.update_entity(sp["id"], props={**ledger.require(sp["id"])["props"], "tasks": max(0, left)})
    if left <= 0:
        ledger.update_entity(sp["id"], status="departed")
        lines.append("  Last task done - the sprite decompiles")
    else:
        lines.append(f"  {left} task(s) left")
    return {"card": "\n".join(lines), **out}


def decompile(ledger: Ledger, dice, turn: int | None, techno: str, sprite: str) -> str:
    t, sp = ledger.require(techno), ledger.require(sprite)
    _emerged(ledger, techno)
    n, _ = sr_lite.build_pool(ledger, techno, "compiling")
    r = sr_lite.roll(dice, n)
    lvl = int(sp["props"].get("level", 1))
    d = sr_lite.roll(dice, lvl)
    net = r.hits - d.hits
    lines = [f"[MATRIX] {t['name']} decompiles {sp['name']}: {n}d6 -> {r.hits} vs Level {lvl}d6 -> {d.hits}"]
    if net > 0:
        left = int(sp["props"].get("tasks", 0)) - net
        ledger.update_entity(sp["id"], props={**sp["props"], "tasks": max(0, left)})
        if left <= 0:
            ledger.update_entity(sp["id"], status="departed")
            lines.append("  DECOMPILED: it unravels into noise")
        else:
            lines.append(f"  Frayed: {left} task(s) left")
    else:
        lines.append("  It holds together")
    return "\n".join(lines)


def summary_lines(ledger: Ledger, eid: str) -> list[str]:
    ent = ledger.get(eid)
    if not ent or not ledger.stat(eid, "resonance", 0):
        return []
    out = []
    held = ent["props"].get("forms_sustained") or []
    if held:
        out.append(f"{ent['name']} holds: " + ", ".join(f"{FORMS[h['form']]['name']} ({h['hits']} hits)" for h in held)
                   + f" (-{2 * len(held)} dice)")
    for sp in ledger.entities(kind="sprite"):
        if sp["props"].get("owner") == eid:
            out.append(f"{sp['name']} [{sp['id']}] Level {sp['props'].get('level')} - {sp['props'].get('tasks')} "
                       f"task(s) left; can: {'; '.join(sp['props'].get('powers') or [])}")
    return out
