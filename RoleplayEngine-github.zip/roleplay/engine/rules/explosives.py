"""Explosives (DESIGN.md §7a): the GM picks the grenade, how close each person is, and the space -
the engine does the math. No meters, no arithmetic for the model.

  bands    point_blank (at their feet), close (a few meters), near (across the room), far (down the street)
  space    open, room (+2: the blast bounces), tight (+4: hallways, vans - the chunky salsa effect).
           The bounce is strongest up close: full bonus at point blank and close, half at near, none far.
  cover    a wall, a door frame, a corner between them and the blast: -6
  aware    whoever saw it coming dives: Reaction + Intuition, every 2 hits is one band further away
  thrown   Throwing + Agility vs 2 - a miss bounces it a band further from everyone; a glitch lands it
           near the thrower; a critical glitch drops it at their feet

Then everyone soaks as usual (Body + armor, the grenade's AP applies).

Clouds, not blasts (SR5 p. 434-435): a smoke grenade fills a 10 m cloud for about 4 Combat Turns - in a fight the
engine marks the zone and takes the visibility modifier off every attack into, out of or inside it (heavy smoke -6,
p. 175; thermographic eyes see ordinary smoke as moderate, -3, but not thermal smoke). A gas grenade (CS/tear gas,
p. 409) does no blast: everyone breathing it resists its Power with Body + Willpower and takes the rest as Stun.
"""
from __future__ import annotations

import re

from ..ledger import Ledger, LedgerError

GRENADES = {   # SR-lite scale (about 0.6x SR5, like the guns)
    "HE grenade": dict(dv=10, ap=-2, damage_type="physical"),
    "frag grenade": dict(dv=11, ap=5, damage_type="physical"),     # flechettes: armor counts for more (book AP +5)
    "flash-bang": dict(dv=6, ap=-4, damage_type="stun"),
    "smoke grenade": dict(smoke="smoke"),                          # no DV: a cloud (p. 435)
    "thermal smoke grenade": dict(smoke="thermal"),                # hot particles: blinds thermographic eyes too
    "CS gas grenade": dict(gas=5, damage_type="stun"),             # CS/tear gas Power 8 (p. 409), at our 0.6 scale
}
CLOUD_ROUNDS = 4                   # "approximately 4 Combat Turns" (p. 435) - a fight round is one of our turns
TOXIN_RESISTANCE = 2               # a dwarf's "+2 dice for pathogen and toxin resistance" (p. 66) - CS is a toxin
SMOKE = {"smoke": -6, "thermal": -6}                               # heavy smoke, p. 175
THERMO_SMOKE = -3                  # thermographic vision shifts visibility one row up - not against thermal smoke

# Live T184: 'smoke grenade' came back a 10P HE grenade, and 'flashlight' a flash-bang - plain substring tests.
# What only sounds like a grenade: launchers and their rounds, detectors, lights, fragments, pods and rigs.
NOT_A_GRENADE = re.compile(
    r"\b(?:launchers?|rounds?|ammo|ammunition|bullets?|shells?|cartridges?|detectors?|scanners?|sniffers?|"
    r"flashlights?|fragments?|pods?|rigs?|belts?|bandoliers?|pouch(?:es)?|cases?|crates?|boxes|box|pins?|holsters?)\b"
    r"|\bflash[- ]?(?:drives?|lights?|paks?|packs?|cards?|memory|photography)\b|\b(?:camera|muzzle)\s+flash\b")
SMOKE_RE = re.compile(r"\bsmoke\s*(?:grenades?|bombs?|canisters?|charges?|screens?)\b|^\s*(?:an?\s+)?(?:thermal\s+)?"
                      r"smoke\s*$")
GAS_RE = re.compile(r"\b(?:tear\s*gas|cs\s*gas|cs|gas)\s*(?:grenades?|bombs?|canisters?)\b")
FLASH_RE = re.compile(r"\bflash[- ]?bangs?\b|\b(?:flash|stun|concussion)\s+grenades?\b")
FRAG_RE = re.compile(r"\bfrag(?:s|mentation)?\b")
# a minigrenade is a grenade too (p. 434: "the same cost and effects"); a charge of plastic explosive stands in as an
# HE blast - the engine has no demolitions rules
HE_RE = re.compile(r"grenades?\b|\bexplosives?\b|\bc-?4\b|\b(?:demolition|satchel|breaching)\s+charges?\b|"
                   r"\bhigh[- ]explosive\b|^\s*(?:an?\s+)?h\.?e\.?\s*$")
BANDS = ("point_blank", "close", "near", "far")
FALLOFF = {"open": (0, -2, -5, -10), "room": (0, -2, -4, -8), "tight": (0, -1, -3, -6)}
SPACE_BONUS = {"open": 0, "room": 2, "tight": 4}
BONUS_SHARE = (1.0, 1.0, 0.5, 0.0)           # how much of the space bonus reaches each band
COVER = 6
SPACE_LABEL = {"open": "open ground", "room": "a room (+2, the blast bounces)",
               "tight": "a tight space (+4, chunky salsa)"}


def catalog(name: str | None) -> tuple[str, dict] | None:
    """'grenade', 'a frag', 'flashbang', 'smoke bomb', 'tear gas grenade' -> (canonical name, item props); None for
    whatever only sounds like one ('Grenade launcher', 'flashlight', 'fragment of the ledger', 'frag rounds')."""
    low = (name or "").lower()
    if not low.strip() or NOT_A_GRENADE.search(low):
        return None
    if SMOKE_RE.search(low):
        key = "thermal smoke grenade" if re.search(r"\btherm(?:al|o)", low) else "smoke grenade"
    elif GAS_RE.search(low):
        key = "CS gas grenade"
    elif FLASH_RE.search(low):
        key = "flash-bang"
    elif FRAG_RE.search(low):
        key = "frag grenade"
    elif HE_RE.search(low):
        key = "HE grenade"
    else:
        return None
    return key, {**GRENADES[key], "explosive": True, "skill": "throwing"}


def cloud(props: dict) -> str | None:
    """'smoke', 'thermal' or 'gas' for a grenade that makes a cloud instead of a blast."""
    return props.get("smoke") or ("gas" if props.get("gas") else None)


def explode(ledger: Ledger, dice, turn: int | None, item_id: str, holder_id: str, targets: list[dict],
            space: str = "open", thrown: bool = False, reason: str = "") -> dict:
    from . import sr_lite                     # (sr_lite's starting gear uses catalog() - import late)
    holder = ledger.require(holder_id)
    item = ledger.find(item_id)
    if item is None or not ledger.holds(holder["id"], item["id"]):
        boom = [f"{i['name']} [{i['id']}]" for i in ledger.holdings(holder["id"]) if i["props"].get("explosive")]
        raise LedgerError(f"{holder['name']} isn't carrying '{item_id}'. Explosives held: {', '.join(boom) or 'none'}.")
    p = item["props"]
    if not p.get("explosive"):
        raise LedgerError(f"'{item['name']}' isn't an explosive.")
    for what in (holder, item):                   # bought, and still with the courier (shops.py)
        if sr_lite.arriving(what):
            raise LedgerError(f"{what['name']} is {sr_lite.transit_note(ledger, what)} - it can't be used yet.")
    if cloud(p) in SMOKE:
        return _smoke(ledger, turn, item, holder, p["smoke"], reason)
    space = space if space in SPACE_BONUS else "open"
    if not targets:
        raise LedgerError("Who is in the " + ("cloud" if cloud(p) else "blast") + "? List each person with their "
                          "range band.")
    if cloud(p) == "gas":
        return _gas(ledger, dice, turn, item, holder, targets, int(p["gas"]), reason)
    band_of: dict[str, int] = {}
    aware: dict[str, bool] = {}
    covered: set[str] = set()
    edges: dict[str, str] = {}                # a target's player spending Edge on their soak
    for t in targets:
        ent = ledger.require(t["id"])
        if t.get("range") not in BANDS:
            raise LedgerError(f"range must be one of {', '.join(BANDS)}.")
        band_of[ent["id"]] = BANDS.index(t["range"])
        aware[ent["id"]] = bool(t.get("aware", True))
        if t.get("cover"):
            covered.add(ent["id"])
        if t.get("edge"):
            edges[ent["id"]] = t["edge"]
    ledger.take(holder["id"], item["id"], 1)                      # it's gone either way
    lines = [f"[ROLL] {item['name'].split(chr(39) + 's ', 1)[-1]} goes off - {SPACE_LABEL[space]}"]
    if reason:
        lines.append(f"  Why    {reason}")

    if thrown:
        n, parts = sr_lite.build_pool(ledger, holder["id"], "throwing")
        r = sr_lite.roll(dice, n)
        lines.append(f"  Throw  {sr_lite.fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()} (needs 2)")
        if r.crit_glitch:
            band_of[holder["id"]], aware[holder["id"]] = 0, False
            lines.append("  CRITICAL GLITCH: it slips - right at the thrower's feet")
        elif r.glitch:
            band_of = {k: min(3, v + 1) for k, v in band_of.items()}
            band_of[holder["id"]] = min(band_of.get(holder["id"], 3), 1)
            lines.append("  GLITCH: it bounces back toward the thrower")
        elif r.hits < 2:
            band_of = {k: min(3, v + 1) for k, v in band_of.items()}
            lines.append("  Off target: it lands wide - everyone is one band further away")

    base = int(p["dv"])
    dtype, ap = p.get("damage_type", "physical"), int(p.get("ap", 0))
    lines.append(f"  Blast  {p['dv']}{dtype[0].upper()}" + (f" +{SPACE_BONUS[space]} ({space})" if SPACE_BONUS[space] else "")
                 + (f", AP {ap:+d}" if ap else ""))
    results = []
    for eid, band in band_of.items():
        ent = ledger.require(eid)
        dodge = ""
        if aware.get(eid, True) and sr_lite.condition(ledger, eid) not in sr_lite.OUT and band < 3:
            if ent["kind"] in sr_lite.MACHINES:
                n, parts = sr_lite.machine_pool(ledger, ent, "evasion")
            else:
                parts = [("Reaction", int(ledger.stat(eid, "reaction"))), ("Intuition", int(ledger.stat(eid, "intuition")))]
                n = max(0, sum(v for _, v in parts) - sr_lite.wound_penalty(ledger, eid))
            r = sr_lite.roll(dice, n)
            moved = min(3 - band, r.hits // 2)
            dodge = f" · dives {n}d6 -> {r.hits} hits" + (f", {moved} band(s) clear" if moved else "")
            band += moved
        dv = base + int(SPACE_BONUS[space] * BONUS_SHARE[band]) + FALLOFF[space][band] - (COVER if eid in covered else 0)
        head = f"  {ent['name']}: {BANDS[band].replace('_', ' ')}{', behind cover' if eid in covered else ''}{dodge}"
        if dv <= 0:
            lines.append(head + " - out of the blast")
            results.append({"id": eid, "band": BANDS[band], "dv": 0, "boxes": 0})
            continue
        lines.append(head + f" - {dv}{dtype[0].upper()}")
        boxes, soak = sr_lite.resist_damage(ledger, dice, turn, eid, dv, dtype, ap, edge=edges.get(eid))
        lines += ["  " + s for s in soak]
        results.append({"id": eid, "band": BANDS[band], "dv": dv, "boxes": boxes,
                        "status": sr_lite.condition(ledger, eid)})
    ledger.log(turn, "explode", holder["id"], {"item": item["id"], "space": space, "results": results})
    return {"card": "\n".join(lines), "results": results}


def _label(item: dict) -> str:
    return item["name"].split(chr(39) + "s ", 1)[-1]


def _smoke(ledger: Ledger, turn: int | None, item: dict, holder: dict, kind: str, reason: str) -> dict:
    """A smoke cloud: nobody is hurt, the grenade is used up, and the visibility modifier is the engine's to apply -
    the GM's modifiers stop at -4 (sr_lite.MOD_EACH), and heavy smoke is -6 (p. 175). Which zone it fills is the
    fight's business (encounters.smoke); the card says what it does."""
    ledger.take(holder["id"], item["id"], 1)
    thermal = kind == "thermal"
    lines = [f"[ROLL] {_label(item)} goes off - a 10 m cloud of {'thermal ' if thermal else ''}smoke for about "
             f"{CLOUD_ROUNDS} rounds (SR5 p. 435)"]
    if reason:
        lines.append(f"  Why    {reason}")
    lines.append(f"  Smoke  heavy: {SMOKE[kind]} to attacks and sight into, out of or through it (p. 175)"
                 + ("; thermal smoke blinds thermographic eyes too" if thermal
                    else f"; thermographic eyes see through it at {THERMO_SMOKE}"))
    ledger.log(turn, "explode", holder["id"], {"item": item["id"], "smoke": kind, "results": []})
    return {"card": "\n".join(lines), "results": [], "smoke": kind}


def _toxin_resistant(ent: dict) -> bool:
    """A metatype whose traits resist toxins (chargen.METATYPES: the dwarf's)."""
    from ...chargen import METATYPES          # (chargen builds on these rules - import late)
    meta = ((ent.get("props") or {}).get("metatype") or "").lower()
    return "toxin resistance" in METATYPES.get(meta, {}).get("traits", "")


def _gas(ledger: Ledger, dice, turn: int | None, item: dict, holder: dict, targets: list[dict], power: int,
         reason: str) -> dict:
    """CS/tear gas (p. 409): no blast and no dive - everyone in the cloud (the targets: whoever breathes it; not a
    machine, not a spirit) resists its Power with Body + Willpower - a dwarf +2 (p. 66; review E2: the trait was on
    the metatype and nothing read it) - and what's left is Stun; the disorientation is the GM's to narrate (-2 for
    about ten minutes). A target's `edge` rides their resistance roll, as on a blast's soak (before, it was dropped:
    the gas soak rolled bare). The +2 is dice, so it isn't scaled like the Power."""
    from . import sr_lite
    breathing = [ledger.require(t["id"]) for t in targets]          # (everyone checked before the can is used up)
    edges = {ent["id"]: sr_lite.edge_use(t.get("edge")) for ent, t in zip(breathing, targets)}
    ledger.take(holder["id"], item["id"], 1)
    lines = [f"[ROLL] {_label(item)} goes off - a 10 m cloud of CS gas for about {CLOUD_ROUNDS} rounds (SR5 p. 409)"]
    if reason:
        lines.append(f"  Why    {reason}")
    lines.append(f"  Gas    Power {power} Stun - resisted with Body + Willpower, no armor; whoever's hit is "
                 "disoriented (-2) for about ten minutes")
    results = []
    for ent in breathing:
        if ent["kind"] not in ("pc", "npc"):
            lines.append(f"  {ent['name']}: doesn't breathe - untouched")
            results.append({"id": ent["id"], "band": "cloud", "dv": 0, "boxes": 0})
            continue
        parts = [("Body", int(ledger.stat(ent["id"], "body"))), ("Willpower", int(ledger.stat(ent["id"], "willpower")))]
        if _toxin_resistant(ent):
            parts.append(("Toxin resistance (dwarf)", TOXIN_RESISTANCE))
        use = edges.get(ent["id"])
        explode, note = sr_lite.push_edge(ledger, turn, ent["id"], parts, use, required=False, on="soak")
        r0 = sr_lite.roll(dice, sum(v for _, v in parts), explode)
        hurts = power - r0.hits > 0                       # (more hits count only while the gas still gets through)
        r, edge_line = sr_lite.second_chance(ledger, dice, turn, ent["id"], r0, use, hurts, useful=hurts, on="soak")
        boxes = max(0, power - r.hits)
        sr_lite._apply_boxes(ledger, ent["id"], boxes, "stun")
        ledger.log(turn, "damage", ent["id"], {"boxes": boxes, "type": "stun", "how": "gas",
                                               "status": sr_lite.condition(ledger, ent["id"])})
        took = f"takes {boxes} stun -> {sr_lite.condition_line(ledger, ent['id'])}"
        said = [x for x in (note, edge_line) if x]
        lines.append(f"  {ent['name']}: {sr_lite.fmt_parts(parts)} = {r0.pool}d6 -> {r0.faces()} -> {r0.hits} hits"
                     + ("" if said else f" - {took}"))
        lines += ["  " + x for x in said] + ([f"    {took}"] if said else [])
        results.append({"id": ent["id"], "band": "cloud", "dv": power, "boxes": boxes,
                        "status": sr_lite.condition(ledger, ent["id"])})
    ledger.log(turn, "explode", holder["id"], {"item": item["id"], "gas": power, "results": results})
    return {"card": "\n".join(lines), "results": results, "gas": power}
