"""Magic (DESIGN.md §7b): spells, spirits and the astral - the GM picks, the engine does the math.

Spells   a curated list. The caster picks the Force (1 to Magic x 2). Sorcery + Magic is rolled - the Force is
         the limit on hits, unless Edge was pushed (SR5 p. 281) - then: direct combat (Manabolt, Stunbolt,
         Powerbolt) is resisted by Willpower or Body and does its net hits with no armor (p. 283); indirect
         (Lightning Bolt, Fireball) is dodged, then soaked at AP -Force - Fireball uses the grenade blast bands.
         Mana spells only touch the living and the astral: machines shrug them off (p. 282). Heal mends hits
         (max Force), once per set of wounds. Sustained spells (Armor, Invisibility, Confusion, Increase
         Reflexes...) last until dropped and cost the caster -2 dice each. Confusion, Control Actions and Mind
         Probe are resisted with Logic + Willpower (p. 285, 290, 292). Drain: the spell's code, written the
         book's way - F-3 is the Force minus 3 - never under 2, resisted with Willpower + Logic; physical if
         the hits were over the caster's Magic (p. 281-283).
Spirits  Conjuring + Magic vs the spirit's Force, hits capped at the Force: net hits are services owed, drain
         is twice the spirit's hits. The spirit is a character (kind 'spirit') the GM runs with the usual tools;
         ordering it to do something big uses a service; at zero it goes home. Banishing is opposed, and drains
         the same way (p. 300-301): physical, for both, when the spirit's Force is over the caster's Magic.
Astral   perceive (see auras, spirits, magic - Perception while perceiving) or project (the body is
         limp and helpless, like hot-sim VR).
Mages know specific spells (props.spells); learning one costs LEARN_COST karma.
"""
from __future__ import annotations

import re

from ..ledger import Ledger, LedgerError
from . import sr_lite

# Every spell's type (M mana / P physical), range (LOS, LOS (A) for an area, T touch), duration (I instant,
# S sustained, P permanent) and drain modifier are the book's stat blocks, SR5 pp. 284-294 - and
# test_spell_table_is_the_book pins them. Live, flag #63: Powerbolt carried the original build's F-2; the book
# prints F-3 like every bolt. Heal is P in the book but resolves at once here (sustaining it for Force turns would
# be bookkeeping with nothing at stake); only S spells are held.
SPELLS = {
    "manabolt": dict(name="Manabolt", target="direct", resist=("willpower",), damage="physical", drain=-3,
                     type="mana", range="LOS", duration="I",
                     text="a lance of raw mana - ignores armor; does nothing to machines or the non-living"),
    "stunbolt": dict(name="Stunbolt", target="direct", resist=("willpower",), damage="stun", drain=-3,
                     type="mana", range="LOS", duration="I",
                     text="a mana jolt that knocks people out without killing them"),
    "powerbolt": dict(name="Powerbolt", target="direct", resist=("body",), damage="physical", drain=-3,
                      type="physical", range="LOS", duration="I",
                      text="raw force - ignores armor, and works on drones and objects too"),
    "lightning bolt": dict(name="Lightning Bolt", target="indirect", damage="physical", drain=-3,
                           type="physical", range="LOS", duration="I",
                           text="a crackling bolt: the target dodges, then soaks"),
    "fireball": dict(name="Fireball", target="area", damage="physical", drain=-1,
                     type="physical", range="LOS (A)", duration="I",
                     text="an exploding sphere of fire - everyone in the blast dives and soaks"),
    "heal": dict(name="Heal", target="heal", drain=-4, type="mana", range="T", duration="P",
                 text="mends physical damage: each hit heals a box (max Force), once per set of wounds"),
    "armor": dict(name="Armor", target="buff", drain=-2, type="physical", range="LOS", duration="S",
                  text="a shimmering field: +hits armor while sustained"),
    "invisibility": dict(name="Invisibility", target="buff", drain=-2, type="mana", range="LOS", duration="S",
                         text="unseen by living eyes, not cameras: to see through, Logic + Willpower must "
                              "match its hits"),
    "levitate": dict(name="Levitate", target="buff", drain=-2, type="physical", range="LOS", duration="S",
                     text="lifts a person or object; hits = how fine the control"),
    "physical barrier": dict(name="Physical Barrier", target="buff", drain=-1, type="physical", range="LOS (A)",
                             duration="S",
                             # (visible: "translucent but shimmers, the equivalent of Light Fog", p. 294 - live
                             # T171-T176 the GM had riders hit 'a wall nobody can see', so every crash was automatic)
                             text="a visible, shimmering wall of force: Armor and Structure 1 per hit; it stops "
                                  "movement and bullets"),
    "detect life": dict(name="Detect Life", target="buff", drain=-3, type="mana", range="T", duration="S",
                        text="senses the living nearby: how many, where, roughly what"),
    "clairvoyance": dict(name="Clairvoyance", target="buff", drain=-3, type="mana", range="T", duration="S",
                         text="sees a distant place the caster knows"),
    "confusion": dict(name="Confusion", target="resisted", resist=("logic", "willpower"), drain=-3, type="mana",
                      range="LOS", duration="S",
                      text="a fog of the mind (Logic + Willpower resists): -net hits dice to every test while held"),
    "control actions": dict(name="Control Actions", target="resisted", resist=("logic", "willpower"), drain=-1,
                            type="mana", range="LOS", duration="S",
                            text="puppets a body (Logic + Willpower resists): the target acts as the caster wills"),
    "mind probe": dict(name="Mind Probe", target="resisted", resist=("logic", "willpower"), drain=0, type="mana",
                       range="T", duration="S",
                       text="reads thoughts: 1 net hit surface thoughts, 3+ secrets"),
    "increase reflexes": dict(name="Increase Reflexes", target="buff", drain=0, type="physical", range="T",
                              duration="S",
                              text="faster than thought: +1 Initiative a hit and an initiative die every 2 hits "
                                   "(SR5 p. 288)"),
}
DRAIN_MIN = 2                                     # "can never be below 2" (SR5 p. 283)
# Seeing through Invisibility: the cast's hits are the threshold "for anyone that resists at a later point" (p. 291),
# who resists a mana illusion with Logic + Willpower (p. 290) - an attribute-only test (p. 152). Live review: the card
# asked for a roll no tool could make (request_test needed a skill), so the card names the call.
INVISIBLE_SEE = "anyone who might see them: request_test with attributes logic + willpower, threshold {n}"
# A code typed after a spell's name - '!advance spell Stunbolt F-3', 'Heal (F-4)' - is the label the sheets show,
# not part of the name. (No spell's name ends in a lone F.)
_CODE = re.compile(r"(?:\s+|\s*\()(?:drain\s+)?F\s*(?:[-+−–]\s*\d+)?\s*\)?\s*$", re.I)
SPIRITS = {
    "fire": dict(mods=dict(body=1, agility=2, reaction=3, strength=-2), attack=("flame lash", "physical"),
                 powers=["engulf (fire)", "elemental attack", "confusion", "accident"]),
    "air": dict(mods=dict(body=-2, agility=3, reaction=4, strength=-3), attack=("lightning lash", "stun"),
                powers=["engulf (suffocation)", "movement", "concealment", "elemental attack"]),
    "earth": dict(mods=dict(body=4, agility=-2, reaction=-1, strength=4), attack=("stone fist", "physical"),
                  powers=["binding", "engulf (crushing)", "guard", "search"]),
    "water": dict(mods=dict(body=2, agility=1, reaction=0, strength=0), attack=("crushing wave", "stun"),
                  powers=["engulf (drowning)", "concealment", "movement", "elemental attack"]),
    "man": dict(mods=dict(body=1, agility=0, reaction=2, strength=-2), attack=("spirit strike", "stun"),
                powers=["concealment", "confusion", "guard", "search", "accident", "influence"]),
    "beast": dict(mods=dict(body=2, agility=1, reaction=0, strength=2), attack=("claws", "physical"),
                  powers=["fear", "movement", "animal control", "natural weapons"]),
}
LEARN_COST = 5                                    # a spell, like SR5 (p. 107)
ASTRAL = ("perceive", "project", "return")


def spell(name: str) -> str:
    key = _CODE.sub("", (name or "").strip()).strip().lower().replace("_", " ").replace("-", " ")
    if key not in SPELLS:
        raise LedgerError(f"No spell '{name}'. Spells: {', '.join(s['name'] for s in SPELLS.values())}.")
    return key


def drain_code(mod: int) -> str:
    """A drain modifier as the book prints it, compactly: 'F-3', 'F+1', or a bare 'F' (SR5 p. 283). Live, flag #62:
    the sheets showed one number at Force = Magic, and the player read 'Stunbolt 3' as the modifier."""
    return f"F{mod:+d}" if mod else "F"


def drain_value(force: int, mod: int) -> int:
    """The Drain Value: the Force plus the spell's modifier, never under 2."""
    return max(DRAIN_MIN, force + mod)


def spell_label(key: str) -> str:
    """'Stunbolt F-3' - the name with its drain code, the way every list shows a spell."""
    return f"{SPELLS[key]['name']} {drain_code(SPELLS[key]['drain'])}"


def spell_at(key: str, force: int) -> str:
    """'Stunbolt F-3 (3)' - the label with the drain it costs at that Force (the sheets use the caster's Magic)."""
    return f"{spell_label(key)} ({drain_value(force, SPELLS[key]['drain'])})"


def sustained(key: str) -> bool:
    """Held until dropped (-2 dice each): the book's S duration."""
    return SPELLS[key]["duration"] == "S"


def known(ledger: Ledger, eid: str) -> list[str]:
    ent = ledger.require(eid)
    return list(ent["props"].get("spells") or [])


def _awakened(ledger: Ledger, eid: str) -> int:
    m = int(ledger.stat(eid, "magic", 0))
    if m <= 0:
        raise LedgerError(f"{ledger.require(eid)['name']} isn't Awakened - no magic to work with.")
    return m


def _drain(ledger, dice, turn, caster, dv: int, physical: bool, edge: str | None = None,
           over: str = "hits over Magic", how: str = "") -> list[str]:
    """Resist and take the drain. over: why it's physical - a cast's hits beat Magic, a spirit's Force did (summon,
    banish). how: where the number came from ('Stunbolt F-3 at Force 6'), so the card can be checked against the
    sheet. Live: a summon card said 'hits over Magic' for a Force 8 spirit that rolled one hit."""
    dv = max(DRAIN_MIN, dv)
    boxes, soak = sr_lite.resist_damage(ledger, dice, turn, caster, dv, "physical" if physical else "stun",
                                        resist="drain", edge=edge)
    return (["  Drain  " + f"{dv}{f'P ({over})' if physical else 'S'}" + (f" · {how}" if how else "")]
            + ["  " + s for s in soak])


def _spirit_drain(hits: int) -> tuple[int, str]:
    """Summoning and banishing drain: twice the spirit's hits, never under 2 (SR5 p. 300-301)."""
    return hits * 2, f"2 x {hits} spirit hit{'' if hits == 1 else 's'}" + (", min 2" if hits * 2 < DRAIN_MIN else "")


def _resist(ledger: Ledger, ent: dict, sp: dict) -> tuple[int, str]:
    """A target's dice against a spell, and their label: the spell's resist attributes summed ('Logic + Willpower');
    a machine adds its armor (Powerbolt on a drone)."""
    n = sum(int(ledger.stat(ent["id"], a, 0)) for a in sp["resist"])
    if ent["kind"] in sr_lite.MACHINES:
        n += int(ledger.stat(ent["id"], "armor", 0))
    return n, " + ".join(a.title() for a in sp["resist"])


def _sustain(ledger: Ledger, caster: str, entry: dict) -> None:
    ent = ledger.require(caster)
    held = list(ent["props"].get("sustained") or [])
    held.append(entry)
    ledger.update_entity(caster, props={**ent["props"], "sustained": held})
    ledger.set_stat(caster, "sustaining", len(held))


HARMFUL = ("direct", "indirect", "area")         # combat spells: cast at someone, they're an attack (a fight opens)
SPLIT = ("direct", "indirect")                   # one-target bolts that can go at several at once (p. 281)


def check_cast(ledger: Ledger, caster: str, spell_name: str, targets: list | None = None,
               edge: str | None = None) -> str:
    """Can this cast happen at all? Raises LedgerError if not (so a cast that can't happen opens no fight); returns
    the spell's key. targets: a bolt at several targets is Casting Multiple Spells - at most Magic of them, and at
    least a die each (SR5 p. 281); a held or one-target spell (Confusion, Heal, a buff) goes at one, and says so
    instead of quietly dropping the rest (each held spell is its own -2 dice). Fireball takes everyone in the blast.
    edge: the caster's - a push needs a point left. (Review: the split's dice were counted in cast, after the tool had
    opened the fight - a refused bolt left a fight and its [FIGHT] card behind.)"""
    c = ledger.require(caster)
    magic = _awakened(ledger, caster)
    if sr_lite.condition(ledger, caster) in sr_lite.OUT:
        raise LedgerError(f"{c['name']} is {sr_lite.condition(ledger, caster)} and can't cast.")
    key = spell(spell_name)
    if known(ledger, caster) and key not in known(ledger, caster):
        raise LedgerError(f"{c['name']} doesn't know {SPELLS[key]['name']}. Known: "
                          + ", ".join(SPELLS[k]["name"] for k in known(ledger, caster)) + f" (learning one: {LEARN_COST} karma).")
    n, kind = len(targets or []), SPELLS[key]["target"]
    if n > 1 and kind in SPLIT and n > magic:
        raise LedgerError(f"{c['name']} can cast at most {magic} spells at once (Magic {magic}, SR5 p. 281) - {n} "
                          "targets named.")
    if n > 1 and kind not in SPLIT and kind != "area":
        raise LedgerError(f"{SPELLS[key]['name']} goes at one target a cast - {n} named. Cast it again for the next "
                          "(each its own action" + (", and each held spell -2 dice)." if sustained(key) else ")."))
    if n > 1 and kind in SPLIT:
        pool, _ = sr_lite.build_pool(ledger, caster, "sorcery")
        if pool < n:
            raise LedgerError(f"{pool} dice can't split {n} ways - at least a die a spell (SR5 p. 281).")
    sr_lite.check_push(ledger, caster, edge)
    return key


CRIT_HELD = "  Edge   held in reserve - a critical glitch stands (SR5 p. 56): more hits couldn't change this cast"


def _roll_cast(ledger, dice, turn, caster, n: int, explode: bool, use, force: int, free: bool = False):
    """One casting roll and its Second Chance: (first roll, final roll, hits after the Force, the Edge line, the
    limit note). Live T164/T165 (flag #64): the second chance judged a casting by the pool alone - held on 4 hits of 13
    dice at Force 8, and free to spend on 3 hits at Force 3, where it can't add one. Now the Force decides. A critical
    glitch stands whatever a Second Chance rolls (p. 56) and the spell goes wild on any hits, so no point goes on one:
    rerolled hits there only made the drain Physical (review: Finch, 14 rerolled hits, 7P)."""
    r0 = sr_lite.roll(dice, n, explode)
    if r0.crit_glitch and use in ("reroll", "if_short"):
        return r0, r0, r0.hits, CRIT_HELD, ""
    under = r0.hits < force
    r, edge_line = sr_lite.second_chance(ledger, dice, turn, caster, r0, use, sr_lite.below_average(r0) and under,
                                         useful=under, limit=None if explode else force, on="cast", free=free)
    hits = r.hits if explode else min(r.hits, force)          # the Force is the limit - pushing Edge breaks it
    capped = f" (limit: Force {force} -> {hits})" if hits < r.hits else ""     # (on the roll the hits came from)
    return r0, r, hits, edge_line, capped


def cast(ledger: Ledger, dice, turn: int | None, caster: str, spell_name: str, force: int, targets: list[dict],
         reason: str = "", edge: str | None = None, drain_edge: str | None = None, defend=None) -> dict:
    """edge: the caster's player spends Edge on the casting - push breaks the Force limit; a second chance (reroll,
    or if_short for a below-average casting) rerolls the misses but never past the Force (SR5 p. 56), so it's held
    once the hits reach it. drain_edge: on resisting the drain (a second chance only while the drain would hurt).
    defend(target, melee) -> (parts, notes): what the fight adds to a dodge against an indirect spell (the -1 for
    each earlier defense, Full Defense). A bolt at several targets is Casting Multiple Spells (SR5 p. 281): the
    Sorcery + Magic pool, pushed Edge in, splits as evenly as it goes (at least a die each, at most Magic spells), and
    each spell rolls, is limited by the Force, resisted and drained on its own - one action in a fight. Live T65: 'I
    split my pool evenly between them' put one unsplit roll on both targets."""
    use = sr_lite.edge_use(edge)
    c = ledger.require(caster)
    magic = _awakened(ledger, caster)
    key = check_cast(ledger, caster, spell_name, targets, use)    # (the split's dice, the push's point: checked)
    sp = SPELLS[key]
    force = max(1, min(magic * 2, int(force or magic)))
    n, parts = sr_lite.build_pool(ledger, caster, "sorcery")
    if len(targets) > 1 and sp["target"] in SPLIT:
        return _cast_split(ledger, dice, turn, c, key, force, magic, parts, targets, reason, use, drain_edge, defend)
    explode, _ = sr_lite.push_edge(ledger, turn, caster, parts, use, on="cast")
    n = max(0, sum(v for _, v in parts))
    r0, r, hits, edge_line, capped = _roll_cast(ledger, dice, turn, caster, n, explode, use, force)
    lines = [f"[ROLL] {c['name']} casts {sp['name']} at Force {force}" + (" (overcast)" if force > magic else ""),
             f"  Cast   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r0.faces()} -> {r0.verdict()}"
             + ("" if r is not r0 else capped)]
    if edge_line:
        lines.append(edge_line + (capped if r is not r0 else ""))
    if reason:
        lines.insert(1, f"  Why    {reason}")
    effects, results, boost = _effects(ledger, dice, turn, c, key, force, hits, r.crit_glitch, targets, defend)
    lines += effects
    if sustained(key):
        lines.append(f"  (sustained: {c['name']} is at -2 dice per spell held until it's dropped)")
    lines += _settle(ledger, dice, turn, c, key, force, magic, hits, r, targets, reason, _edge_said(edge_line, parts),
                     drain_edge)
    return {"card": "\n".join(lines), "results": results, "boost": boost}


def _cast_split(ledger, dice, turn, c, key, force, magic, parts, targets, reason, use, drain_edge, defend) -> dict:
    """Casting Multiple Spells (p. 281): one pool split between the spells, then each is its own roll, Force limit,
    resistance and drain. One Second Chance covers every share (as for Multiple Attacks, p. 196); drain_edge rides the
    first drain - one roll, one called Edge."""
    sp = SPELLS[key]
    explode, _ = sr_lite.push_edge(ledger, turn, c["id"], parts, use, on="cast")       # (Edge goes in before the split)
    n = max(0, sum(v for _, v in parts))
    shares = sr_lite.split_pool(n, len(targets))
    lines = [f"[ROLL] {c['name']} casts {sp['name']} at Force {force}" + (" (overcast)" if force > magic else "")
             + f" at {len(targets)} targets - {n}d6 split {' / '.join(map(str, shares))}, each its own drain"]
    if reason:
        lines.append(f"  Why    {reason}")
    lines.append(f"  Pool   {sr_lite.fmt_parts(parts)} = {n}d6, split {' / '.join(map(str, shares))} "
                 f"(at most {magic} spells at once: Magic {magic})")
    results, paid = [], False
    for i, t in enumerate(targets):
        lines.append(f"  Spell #{i + 1} at {ledger.require(t['id'])['name']}")
        r0, r, hits, edge_line, capped = _roll_cast(ledger, dice, turn, c["id"], shares[i], explode, use, force, paid)
        paid = paid or r is not r0
        lines.append(f"  Cast   Split share {shares[i]} = {shares[i]}d6 -> {r0.faces()} -> {r0.verdict()}"
                     + ("" if r is not r0 else capped))
        if edge_line:
            lines.append(edge_line + (capped if r is not r0 else ""))
        effects, res, _ = _effects(ledger, dice, turn, c, key, force, hits, r.crit_glitch, [t], defend)
        lines += effects
        results += res
        lines += _settle(ledger, dice, turn, c, key, force, magic, hits, r, [t], reason, _edge_said(edge_line, parts),
                         drain_edge if i == 0 else None, split=(i + 1, len(targets)))
    return {"card": "\n".join(lines), "results": results, "boost": None}


def _edge_said(edge_line: str | None, parts) -> str | None:
    """The Edge on a cast's row, as a test's row keeps it (sr_lite.request_test): what it did - pushed, a second chance,
    held in reserve - never the mode asked for. Review 2026-10-28: read_turn printed "Edge: reroll" beside a casting
    whose card held the point in reserve at the Force, flag #64's very dispute."""
    if edge_line:
        return edge_line.strip().removeprefix("Edge").strip()
    pushed = next((label for label, _ in parts if label.startswith("Edge, pushed")), None)
    return pushed.removeprefix("Edge, ") if pushed else None


def _settle(ledger, dice, turn, c, key, force, magic, hits, r, targets, reason, edge, drain_edge,
            split: tuple | None = None) -> list[str]:
    """A spell's drain, its row in tests and its cast event (edge: what the casting's Edge did - _edge_said). Live,
    T164-T175's drain had to be rebuilt from the formula - the card lived only in Discord."""
    sp = SPELLS[key]
    dv, physical = drain_value(force, sp["drain"]), hits > magic                       # (SR5 p. 281)
    lines = _drain(ledger, dice, turn, c["id"], dv, physical, drain_edge,
                   how=f"{spell_label(key)} at Force {force}" + (", min 2" if force + sp["drain"] < DRAIN_MIN else ""))
    sr_lite._record(ledger, turn, c["id"], {"kind": "cast", "spell": key, "force": force,
                                            "targets": [t["id"] for t in targets], "edge": edge, "reason": reason}
                    | ({"split": list(split)} if split else {}), r, hits > 0 and not r.crit_glitch, hits)
    ledger.log(turn, "cast", c["id"], {"spell": key, "force": force, "hits": hits, "drain": dv,
                                       "drain_type": "physical" if physical else "stun"}
               | ({"split": list(split)} if split else {}))
    return lines


def _effects(ledger, dice, turn, c: dict, key: str, force: int, hits: int, crit: bool, targets: list[dict],
             defend=None) -> tuple[list[str], list[dict], dict | None]:
    """What the spell's hits do to its targets: (card lines, [{id, boxes}], Increase Reflexes' boost or None)."""
    sp = SPELLS[key]
    lines, results, boost = [], [], None
    kind = sp["target"]
    if crit:
        lines.append("  CRITICAL GLITCH: the spell goes wild - the GM decides how")
    elif kind == "direct":
        for t in targets:
            ent = ledger.require(t["id"])
            if sp.get("type") == "mana" and ent["kind"] in sr_lite.MACHINES:
                lines.append(f"  {ent['name']}: no mind, no aura - {sp['name']} passes through")
                continue
            rp, rlabel = _resist(ledger, ent, sp)
            rr = sr_lite.roll(dice, rp)
            net = hits - rr.hits
            if net <= 0:
                lines.append(f"  {ent['name']} resists ({rlabel} {rp}d6 -> {rr.hits}) - no effect")
                continue
            dv = net                                          # direct spells: the net hits, no soak (SR5 p. 283)
            sr_lite._apply_boxes(ledger, ent["id"], dv, sp["damage"])
            ledger.log(turn, "damage", ent["id"], {"boxes": dv, "type": sp["damage"], "status": sr_lite.condition(ledger, ent["id"])})
            lines.append(f"  {ent['name']}: resists {rp}d6 -> {rr.hits}, takes {dv}{sp['damage'][0].upper()} (no armor) -> "
                         f"{sr_lite.condition_line(ledger, ent['id'])}")
            results.append({"id": ent["id"], "boxes": dv})
    elif kind in ("indirect", "area"):
        for t in targets:
            ent = ledger.require(t["id"])
            band = t.get("range", "point_blank") if kind == "area" else "point_blank"
            from .explosives import BANDS, FALLOFF
            bi = BANDS.index(band) if band in BANDS else 0
            if ent["kind"] in sr_lite.MACHINES:
                dn, dparts = sr_lite.machine_pool(ledger, ent, "evasion")
            else:
                dn = max(0, int(ledger.stat(ent["id"], "reaction")) + int(ledger.stat(ent["id"], "intuition"))
                         - sr_lite.wound_penalty(ledger, ent["id"]))
            notes = []
            if kind == "indirect" and defend and t.get("aware", True):     # a bolt is a ranged attack: the fight's
                more, notes = defend(ent["id"], False)                     # -1 a defense and Full Defense count
                dn = max(0, dn + sum(v for _, v in more))
                notes = [f"{label} {v:+d}" for label, v in more] + notes
            dr = sr_lite.roll(dice, dn) if t.get("aware", True) else sr_lite.roll(dice, 0)
            net = hits - dr.hits
            dv = force + max(0, net) + FALLOFF["open"][bi]
            tail = f" [{'; '.join(notes)}]" if notes else ""
            if net <= 0 and kind == "indirect":
                lines.append(f"  {ent['name']} dodges ({dn}d6 -> {dr.hits}){tail}")
                continue
            if dv <= 0:
                lines.append(f"  {ent['name']}: {band.replace('_', ' ')} - out of the blast")
                continue
            lines.append(f"  {ent['name']}: {band.replace('_', ' ')} · dodges {dn}d6 -> {dr.hits} - {dv}P, "
                         f"AP {sr_lite.scaled_ap(-force):+d}{tail}")
            boxes, soak = sr_lite.resist_damage(ledger, dice, turn, ent["id"], dv, "physical", -force)
            lines += ["  " + s for s in soak]
            results.append({"id": ent["id"], "boxes": boxes})
    elif kind == "heal":
        for t in targets[:1]:                             # (check_cast turns away a second target)
            ent = ledger.require(t["id"])
            if ent["kind"] in sr_lite.MACHINES:
                lines.append(f"  {ent['name']}: a machine - mana can't mend it")
                continue
            try:
                res = sr_lite.heal(ledger, turn, ent["id"], "physical", hits, f"Heal (Force {force})", how="magic")
            except LedgerError as exc:
                lines.append(f"  {ent['name']}: {exc}")
                continue
            lines.append(f"  {ent['name']} heals {int(res['healed'])} -> {sr_lite.condition_line(ledger, ent['id'])}")
    elif kind == "buff":
        tgt = ledger.require(targets[0]["id"]) if targets else c
        if hits <= 0:
            lines.append("  It fizzles")
        elif sp.get("type") == "mana" and tgt["kind"] in sr_lite.MACHINES:
            lines.append(f"  {tgt['name']}: a machine - {sp['name']} can't take hold on it")
        elif key == "increase reflexes" and any(h["spell"] == key and h["target"] == tgt["id"]
                                                for e in ledger.entities(kind="pc") + ledger.entities(kind="npc")
                                                for h in (e["props"].get("sustained") or [])):
            lines.append(f"  {tgt['name']} already has Increase Reflexes on them - only one at a time")
        else:
            if key == "armor":
                ledger.add_stat(tgt["id"], "spell_armor", hits)
            if key == "increase reflexes":               # +1 Initiative a hit, +1 die every 2 (SR5 p. 288)
                ledger.set_stat(tgt["id"], "spell_init_dice", min(4, hits // 2))
                ledger.set_stat(tgt["id"], "spell_init_bonus", hits)
                boost = {"target": tgt["id"], "bonus": hits, "dice": min(4, hits // 2)}
            held = {"spell": key, "target": tgt["id"], "force": force, "hits": hits}
            if key == "physical barrier":                 # a real wall: 1 Armor and 1 Structure per hit (SR5 p. 294)
                held |= {"armor": hits, "structure": hits}
            _sustain(ledger, c["id"], held)
            walls = len(barriers(ledger, c["id"])) if key == "physical barrier" else 0
            lines.append(f"  {tgt['name']}: {sp['name']} holds with {hits} hits - {sp['text']}"
                         + (f" (Armor {hits} / Structure {hits})" if walls else "")
                         + (f" - wall #{walls} of the {walls} {c['name']} holds" if walls > 1 else "")
                         + (f" (Initiative +{hits}, +{min(4, hits // 2)}D6)" if key == "increase reflexes" else "")
                         + (f" ({INVISIBLE_SEE.format(n=hits)})" if key == "invisibility" else ""))
    elif kind == "resisted":
        for t in targets[:1]:                             # (check_cast turns away a second target)
            ent = ledger.require(t["id"])
            if sp.get("type") == "mana" and ent["kind"] in sr_lite.MACHINES:
                lines.append(f"  {ent['name']}: no mind to touch - {sp['name']} slides off")
                continue
            rp, rlabel = _resist(ledger, ent, sp)         # Logic + Willpower, all three (SR5 p. 285, 290, 292)
            rr = sr_lite.roll(dice, rp)
            net = hits - rr.hits
            if net <= 0:
                lines.append(f"  {ent['name']} shrugs it off ({rlabel} {rp}d6 -> {rr.hits})")
                continue
            if key == "confusion":
                ledger.add_stat(ent["id"], "spell_penalty", net)
            _sustain(ledger, c["id"], {"spell": key, "target": ent["id"], "force": force, "hits": net})
            lines.append(f"  {ent['name']}: resists {rlabel} {rp}d6 -> {rr.hits}, {net} net hits - {sp['text']}")
    return lines, results, boost


def learnable(ledger: Ledger, eid: str) -> list[str]:
    """The spells a caster could still learn. None for an empty list: no list on file means they know every spell (cast
    enforces only a list it has, and the sheets read it the same way) - live review: '!advance spell Powerbolt' on an
    empty list charged 5 karma and cut the caster from every spell down to Powerbolt alone."""
    have = known(ledger, eid)
    return [k for k in SPELLS if have and k not in have]


def _castings(ledger: Ledger, caster: str, key: str) -> list[tuple[int, dict]]:
    """Each held casting of one spell, with its place in props.sustained, in the order cast."""
    held = (ledger.get(caster) or {}).get("props", {}).get("sustained") or []
    return [(at, h) for at, h in enumerate(held) if h["spell"] == key]


def _pick(ledger: Ledger, caster: str, key: str, which) -> int:
    """The place in props.sustained of the one casting `which` names: its number among that spell's castings ('2',
    '#2' - the packet numbers a caster's Physical Barriers) or who it's on. Raises LedgerError naming the choices when
    it matches none, or more than one."""
    name, held = ledger.require(caster)["name"], _castings(ledger, caster, key)
    choices = "; ".join(f"#{n} on {(ledger.get(h['target']) or {}).get('name', h['target'])}"
                        for n, (_, h) in enumerate(held, 1))
    ref = str(which).strip().lstrip("#").strip()
    if ref.isdigit():
        hits = [held[int(ref) - 1][0]] if 1 <= int(ref) <= len(held) else []
    else:
        ent = ledger.find(ref)
        hits = [at for at, h in held if ent and h["target"] == ent["id"]]
    if len(hits) != 1:
        raise LedgerError(f"Which {SPELLS[key]['name']}? {name} holds {len(held)}: {choices}"
                          + (" - name it by number." if len(hits) > 1 else "."))
    return hits[0]


def _release(ledger: Ledger, caster: str, drop_at: list[int], turn: int | None, why: str = "") -> list[dict]:
    """Let go of the held spells at those places in props.sustained: their effects come off, the -2 dice go, and it's
    logged as 'spell_end' (so the record shows when a spell stopped, not just when it began). By place, not by spell:
    one of two Physical Barriers collapsing must leave the other standing (live review: one collapse ended both)."""
    ent = ledger.require(caster)
    held = list(ent["props"].get("sustained") or [])
    drop = [held[i] for i in drop_at]
    for h in drop:
        if h["spell"] == "armor":
            ledger.add_stat(h["target"], "spell_armor", -h["hits"])
        if h["spell"] == "confusion":
            ledger.add_stat(h["target"], "spell_penalty", -h["hits"])
        if h["spell"] == "increase reflexes":
            ledger.set_stat(h["target"], "spell_init_dice", 0)
            ledger.set_stat(h["target"], "spell_init_bonus", 0)
    keep = [h for i, h in enumerate(held) if i not in drop_at]
    ledger.update_entity(caster, props={**ent["props"], "sustained": keep})
    ledger.set_stat(caster, "sustaining", len(keep))
    ledger.log(turn, "spell_end", caster, {"spells": [h["spell"] for h in drop],
                                           "targets": [h["target"] for h in drop]} | ({"why": why} if why else {}))
    return drop


def end_spell(ledger: Ledger, caster: str, spell_name: str | None = None, turn: int | None = None,
              why: str = "", which=None) -> str:
    """Drop a sustained spell (or all of them). which: just one casting of it, when it's held more than once - its
    number or who it's on (_pick) - so dropping one of two walls, or the Armor on one of two runners, leaves the other."""
    ent = ledger.require(caster)
    held = list(ent["props"].get("sustained") or [])
    key = spell(spell_name) if spell_name else None
    if which not in (None, "") and not key:
        raise LedgerError("Which spell? `which` picks one casting of a spell - name the spell too.")
    if which not in (None, "") and _castings(ledger, caster, key):
        drop_at = [_pick(ledger, caster, key, which)]
    else:
        drop_at = [i for i, h in enumerate(held) if key is None or h["spell"] == key]
    if not drop_at:
        raise LedgerError(f"{ent['name']} isn't sustaining {SPELLS[key]['name'] if key else 'anything'}.")
    drop = _release(ledger, caster, drop_at, turn, why)
    return f"[ROLL] {ent['name']} lets go of " + ", ".join(SPELLS[h["spell"]]["name"] for h in drop)


# ── Physical Barrier: a wall with numbers ───────────────────────────────
# Live T164/T165/T174: the GM had riders crash into Magic's barrier for 10P, 8P, 9P - the barrier was a
# narrative 'buff' with a hits value and nothing to break. Now it carries the book's Armor and Structure (1 each
# per hit, p. 294); what hits it rolls Structure + Armor to resist and the Structure takes the rest (p. 197), and
# at Structure 0 it collapses and the spell ends. While sustained it regrows its Structure every Combat Turn
# (regrow_barriers, at each turn's end), and what rams it is machines.crash. Each cast is its own wall (a wall per
# doorway): a caster may hold several, numbered #1, #2 in the order cast, and each takes its own hits and falls alone.

def barriers(ledger: Ledger, caster: str) -> list[dict]:
    """Every Physical Barrier the caster holds, in the order cast: {armor, structure, hits, force, target, n (its
    number), at (its place in props.sustained)}. An entry from before the barrier had numbers reads its hits for both."""
    return [{**h, "armor": int(h.get("armor", h["hits"])), "structure": int(h.get("structure", h["hits"])), "n": n,
             "at": at} for n, (at, h) in enumerate(_castings(ledger, caster, "physical barrier"), 1)]


def barrier(ledger: Ledger, caster: str, which=None) -> dict | None:
    """The caster's held Physical Barrier (barriers' shape), or None when they hold none. Holding several, which picks
    one - its number or who it's on - and without it this asks which (LedgerError naming them): live review, every
    crash hit the first wall and damage_barrier wrote its numbers onto the others."""
    walls = barriers(ledger, caster)
    if not walls:
        return None
    if which in (None, "") and len(walls) == 1:
        return walls[0]
    at = _pick(ledger, caster, "physical barrier", "" if which is None else which)
    return next(b for b in walls if b["at"] == at)


def barrier_name(ledger: Ledger, caster: str, b: dict) -> str:
    """'Physical Barrier', or 'Physical Barrier #2 (on Razor)' when the caster holds more than one."""
    if len(barriers(ledger, caster)) < 2:
        return "Physical Barrier"
    return f"Physical Barrier #{b['n']} (on {(ledger.get(b['target']) or {}).get('name', b['target'])})"


def damage_barrier(ledger: Ledger, turn: int | None, caster: str, boxes: int, why: str = "", which=None) -> dict:
    """Take boxes off one barrier's Structure (after its Structure + Armor resist) - that wall's alone. At 0 it
    collapses and that spell ends; any other wall the caster holds stands. Returns {'structure': left, 'broken': bool,
    'line': card line}."""
    b = barrier(ledger, caster, which)
    if not b:
        raise LedgerError(f"{ledger.require(caster)['name']} isn't holding a Physical Barrier.")
    name = barrier_name(ledger, caster, b)
    left = max(0, b["structure"] - max(0, int(boxes)))
    if left <= 0:
        _release(ledger, caster, [b["at"]], turn, why or "the barrier broke")
        return {"structure": 0, "broken": True,
                "line": f"  The {name} takes {boxes} - Structure 0: it collapses and the spell ends"}
    ent = ledger.require(caster)
    held = list(ent["props"].get("sustained") or [])
    held[b["at"]] = dict(held[b["at"]], armor=b["armor"], structure=left)
    ledger.update_entity(caster, props={**ent["props"], "sustained": held})
    ledger.log(turn, "barrier", caster, {"boxes": int(boxes), "structure": left, "target": b["target"]}
               | ({"why": why} if why else {}))
    return {"structure": left, "broken": False,
            "line": f"  The {name} takes {boxes} - Structure {left}/{b['hits']} (Armor {b['armor']})"}


def regrow_barriers(ledger: Ledger, turn: int | None) -> list[str]:
    """A sustained Physical Barrier 'will regenerate all of its Structure Rating at the beginning of each Combat Turn'
    (SR5 p. 294). A GM turn is a Combat Turn in a fight and longer outside one, so commit calls this at the end of
    every turn: what hit the wall this turn adds up (crash), and the next turn finds it whole. Each wall regrows to
    its own hits. Returns the casters."""
    out = []
    for kind in ("pc", "npc", "spirit"):
        for e in ledger.entities(kind=kind):
            hurt = [b for b in barriers(ledger, e["id"]) if b["structure"] < int(b["hits"])]
            if not hurt:
                continue
            held = list(e["props"].get("sustained") or [])
            for b in hurt:
                held[b["at"]] = dict(held[b["at"]], structure=int(b["hits"]))
                ledger.log(turn, "barrier", e["id"], {"structure": int(b["hits"]), "target": b["target"],
                                                      "regrew": True})
            ledger.update_entity(e["id"], props={**e["props"], "sustained": held})
            out.append(e["id"])
    return out


def summon(ledger: Ledger, dice, turn: int | None, caster: str, kind: str, force: int, reason: str = "") -> dict:
    c = ledger.require(caster)
    magic = _awakened(ledger, caster)
    if not ledger.stat(caster, "conjuring", 0):
        raise LedgerError(f"{c['name']} has no Conjuring skill.")
    kind = (kind or "").lower().replace(" spirit", "").strip()
    if kind not in SPIRITS:
        raise LedgerError(f"Spirit types: {', '.join(SPIRITS)}.")
    force = max(1, min(magic * 2, int(force or magic)))
    n, parts = sr_lite.build_pool(ledger, caster, "conjuring")
    r = sr_lite.roll(dice, n)
    sr_ = sr_lite.roll(dice, force)
    hits = min(r.hits, force)                                 # the spirit's Force is the limit (SR5 p. 300)
    net = hits - sr_.hits
    lines = [f"[ROLL] {c['name']} summons {'an' if kind[0] in 'aeiou' else 'a'} {kind} spirit at Force {force}" + (" (overcast)" if force > magic else ""),
             f"  Call   {sr_lite.fmt_parts(parts)} = {n}d6 -> {r.faces()} -> {r.verdict()}"
             + (f" (limit: Force {force} -> {hits})" if hits < r.hits else ""),
             f"  vs     Spirit Force {force} = {force}d6 -> {sr_.faces()} -> {sr_.hits} hits"]
    if reason:
        lines.insert(1, f"  Why    {reason}")
    sid = None
    if net <= 0:
        lines.append("  The spirit refuses the call")
    else:
        spec = SPIRITS[kind]
        name = f"{c['name']}'s {kind} spirit"
        sid = ledger.create_entity("spirit", name, f"a Force {force} {kind} spirit", tier=1,
                                   props={"type": kind, "force": force, "services": net, "owner": c["id"],
                                          "powers": spec["powers"]}, turn=turn or 0)
        for a in ("body", "agility", "reaction", "strength", "willpower", "logic", "intuition", "charisma"):
            ledger.set_stat(sid, a, max(1, force + spec["mods"].get(a, 0)))
        for s in ("close_combat", "perception", "stealth", "athletics"):
            ledger.set_stat(sid, s, force)
        ledger.set_stat(sid, "armor", force)                       # spirits shrug off mundane hits
        aname, adtype = spec["attack"]
        iid = ledger.create_entity("item", f"{name}'s {aname}", aname, tier=0,
                                   props={"dv": force, "ap": -(force // 2), "skill": "close_combat", "damage_type": adtype},
                                   turn=turn or 0)
        ledger.give(sid, iid, 1)
        lines.append(f"  ANSWERS: {name} [{sid}] owes {net} service(s) - powers: {', '.join(spec['powers'])}")
    dv, how = _spirit_drain(sr_.hits)
    lines += _drain(ledger, dice, turn, caster, dv, force > magic, over="Force over Magic", how=how)   # (p. 300)
    ledger.log(turn, "summon", caster, {"spirit": sid, "kind": kind, "force": force, "services": max(0, net)})
    return {"card": "\n".join(lines), "spirit": sid}


def order(ledger: Ledger, spirit: str, task: str = "") -> str:
    s = ledger.require(spirit)
    left = int(s["props"].get("services", 0)) - 1
    ledger.update_entity(s["id"], props={**s["props"], "services": max(0, left)})
    if left <= 0:
        ledger.update_entity(s["id"], status="departed")
        return f"[ROLL] {s['name']} does it" + (f" ({task})" if task else "") + " - its last service; it goes home"
    return f"[ROLL] {s['name']} does it" + (f" ({task})" if task else "") + f" - {left} service(s) left"


def banish(ledger: Ledger, dice, turn: int | None, caster: str, spirit: str) -> str:
    """Opposed: Conjuring + Magic vs the spirit's Force; net hits strip services. It drains like summoning - twice
    the spirit's hits, physical if its Force is over the caster's Magic (SR5 p. 301) - whether it works or not."""
    c, s = ledger.require(caster), ledger.require(spirit)
    magic = _awakened(ledger, caster)
    n, parts = sr_lite.build_pool(ledger, caster, "conjuring")
    r = sr_lite.roll(dice, n)
    force = int(s["props"].get("force", 1))
    d = sr_lite.roll(dice, force)
    net = r.hits - d.hits
    lines = [f"[ROLL] {c['name']} banishes {s['name']}: {n}d6 -> {r.hits} vs Force {force}d6 -> {d.hits}"]
    if net > 0:
        left = int(s["props"].get("services", 0)) - net
        ledger.update_entity(s["id"], props={**s["props"], "services": max(0, left)})
        if left <= 0:
            ledger.update_entity(s["id"], status="departed")
            lines.append("  BANISHED: it unravels and is gone")
        else:
            lines.append(f"  Weakened: {left} service(s) left")
    else:
        lines.append("  It holds on")
    dv, how = _spirit_drain(d.hits)
    lines += _drain(ledger, dice, turn, caster, dv, force > magic, over="Force over Magic", how=how)
    ledger.log(turn, "banish", caster, {"spirit": s["id"], "force": force, "net": net})
    return "\n".join(lines)


def astral(ledger: Ledger, turn: int | None, eid: str, mode: str) -> str:
    ent = ledger.require(eid)
    _awakened(ledger, eid)
    if mode not in ASTRAL:
        raise LedgerError(f"mode: {', '.join(ASTRAL)}")
    new = None if mode == "return" else ("perceiving" if mode == "perceive" else "projecting")
    ledger.update_entity(eid, props={**ent["props"], "astral": new})
    ledger.log(turn, "astral", eid, {"mode": new})
    return {None: f"[ROLL] {ent['name']} is back in their own skin",
            "perceiving": f"[ROLL] {ent['name']} shifts their sight to the astral - auras, spirits, magic all visible "
                          "(-2 dice to mundane tests while perceiving)",
            "projecting": f"[ROLL] {ent['name']} leaves their body and projects - the body is limp and helpless"}[new]


def summary_lines(ledger: Ledger, eid: str) -> list[str]:
    """For the packet: what a magician is holding up, and their spirits."""
    ent = ledger.get(eid)
    if not ent or not ledger.stat(eid, "magic", 0):
        return []
    out = []
    held = ent["props"].get("sustained") or []
    if held:
        out.append(f"{ent['name']} sustains: " + ", ".join(f"{SPELLS[h['spell']]['name']} on "
                                                            f"{(ledger.get(h['target']) or {}).get('name', h['target'])} "
                                                            f"({h['hits']} hits)" for h in held)
                   + f" (-{2 * len(held)} dice)")
    for b in barriers(ledger, eid):               # what a crash or a burst has to get through - each wall its own
        out.append(f"{ent['name']}'s {barrier_name(ledger, eid, b)}: Armor {b['armor']} / Structure {b['structure']}"
                   + (f" (of {b['hits']})" if b["structure"] < b["hits"] else ""))
    if ent["props"].get("astral"):
        out.append(f"{ent['name']} is {ent['props']['astral']} astrally"
                   + (" - the body is LIMP and helpless" if ent["props"]["astral"] == "projecting" else ""))
    for s in ledger.entities(kind="spirit"):
        if s["props"].get("owner") == eid:
            out.append(f"{s['name']} [{s['id']}] Force {s['props'].get('force')} - {s['props'].get('services')} "
                       f"service(s) left; powers: {', '.join(s['props'].get('powers') or [])}")
    return out
