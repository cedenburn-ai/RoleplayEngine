"""The ledger: authoritative hard state. Only the engine writes here (DESIGN.md §1).

Anything with a number lives here - stats, damage, nuyen, ammo, who is where.
The memory substrate never decides any of it.
"""
from __future__ import annotations

import json
import re
import sqlite3
from typing import Iterable

RESERVED_ID = re.compile(r"^[tsfnbwahcq]\d+$", re.IGNORECASE)  # T12 slice, S3 scene, F4 fact, N5 note, B2 belief,
#                                                       W6 offscreen event, A1 agenda, H2 hook, C3 clarification, Q4 tension


class LedgerError(Exception):
    """A rule or state violation. Tool calls turn these into is_error results."""


class RulesRefusal(LedgerError):
    """The table's rules turning a call away before anything happens - a player's called Edge left off their roll, an
    action past a fighter's phases. The GM gets it back as an is_error result to correct course, but it isn't an engine
    fault: run_tool files no 'tool error' flag and doesn't count it as one (otherwise every reminder would land in the
    bug queue the owner triages)."""


def slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "entity"
    if RESERVED_ID.match(slug):
        slug += "-x"
    return slug


def _entity(row: sqlite3.Row | None) -> dict | None:
    if row is None:
        return None
    d = dict(row)
    d["aliases"] = json.loads(d["aliases"] or "[]")
    d["props"] = json.loads(d["props"] or "{}")
    return d


class Ledger:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    # ── meta ────────────────────────────────────────────────────────────
    def meta(self, key: str, default: str | None = None) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?,?)", (key, value))

    # ── entities ────────────────────────────────────────────────────────
    def create_entity(self, kind: str, name: str, description: str = "", aliases: Iterable[str] = (),
                      tier: int = 1, player: str | None = None, props: dict | None = None,
                      turn: int = 0, entity_id: str | None = None) -> str:
        base = entity_id or slugify(name)
        eid, n = base, 2
        while self.get(eid) is not None:
            eid = f"{base}-{n}"
            n += 1
        self.conn.execute(
            "INSERT INTO entities(id, kind, name, aliases, description, tier, player, props, created_turn)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (eid, kind, name, json.dumps(list(aliases)), description, tier, player,
             json.dumps(props or {}), turn))
        return eid

    def update_entity(self, eid: str, **fields) -> None:
        for key, value in fields.items():
            if key in ("aliases", "props"):
                value = json.dumps(value)
            self.conn.execute(f"UPDATE entities SET {key}=? WHERE id=?", (value, eid))

    def get(self, eid: str) -> dict | None:
        return _entity(self.conn.execute("SELECT * FROM entities WHERE id=?", (eid,)).fetchone())

    def require(self, eid: str) -> dict:
        ent = self.find(eid)
        if ent is None:
            raise LedgerError(f"Unknown entity '{eid}'.")
        return ent

    def find(self, ref: str | None) -> dict | None:
        """Resolve an id, a name, or an alias (case-insensitive)."""
        if not ref:
            return None
        ref = ref.strip()
        ent = self.get(ref)
        if ent:
            return ent
        low = ref.lower()
        row = self.conn.execute(
            "SELECT * FROM entities WHERE lower(id)=? OR lower(name)=? ORDER BY tier DESC LIMIT 1",
            (low, low)).fetchone()
        if row:
            return _entity(row)
        for ent in self.entities(status=None):
            if low in (a.lower() for a in ent["aliases"]):
                return ent
        return None

    def entities(self, kind: str | None = None, status: str | None = "active") -> list[dict]:
        sql, args = "SELECT * FROM entities WHERE 1=1", []
        if kind:
            sql += " AND kind=?"
            args.append(kind)
        if status:
            sql += " AND status=?"
            args.append(status)
        return [_entity(r) for r in self.conn.execute(sql + " ORDER BY id", args)]

    def name_index(self) -> list[tuple[str, str]]:
        """(lowercase name or alias, entity id), longest first - for mention matching."""
        pairs = []
        for ent in self.entities(status=None):
            if ent["tier"] < 1:
                continue
            pairs.append((ent["name"].lower(), ent["id"]))
            pairs.extend((a.lower(), ent["id"]) for a in ent["aliases"] if a)
        return sorted(pairs, key=lambda p: -len(p[0]))

    def pc_for_player(self, handle: str) -> dict | None:
        low = handle.strip().lower()
        for ent in self.entities(kind="pc", status=None):
            if (ent["player"] or "").lower() == low or ent["name"].lower() == low or ent["id"] == low:
                return ent
        return None

    # ── stats ───────────────────────────────────────────────────────────
    def stats(self, eid: str) -> dict[str, float]:
        return {r["key"]: r["value"] for r in
                self.conn.execute("SELECT key, value FROM stats WHERE entity_id=?", (eid,))}

    def stat(self, eid: str, key: str, default: float = 0) -> float:
        row = self.conn.execute("SELECT value FROM stats WHERE entity_id=? AND key=?", (eid, key)).fetchone()
        return row["value"] if row else default

    def set_stat(self, eid: str, key: str, value: float) -> None:
        self.conn.execute("INSERT OR REPLACE INTO stats(entity_id, key, value) VALUES(?,?,?)", (eid, key, value))

    def add_stat(self, eid: str, key: str, delta: float) -> float:
        value = self.stat(eid, key) + delta
        self.set_stat(eid, key, value)
        return value

    # ── holdings ────────────────────────────────────────────────────────
    def holdings(self, owner: str) -> list[dict]:
        out = []
        for r in self.conn.execute("SELECT * FROM holdings WHERE owner_id=? ORDER BY item_id", (owner,)):
            item = self.get(r["item_id"])
            if item:
                item["qty"] = r["qty"]
                item["state"] = json.loads(r["state"] or "{}")
                out.append(item)
        return out

    def holds(self, owner: str, item: str) -> bool:
        return self.conn.execute("SELECT 1 FROM holdings WHERE owner_id=? AND item_id=?",
                                 (owner, item)).fetchone() is not None

    def give(self, owner: str, item: str, qty: int = 1, state: dict | None = None) -> None:
        row = self.conn.execute("SELECT qty, state FROM holdings WHERE owner_id=? AND item_id=?",
                                (owner, item)).fetchone()
        if row:
            self.conn.execute("UPDATE holdings SET qty=? WHERE owner_id=? AND item_id=?",
                              (row["qty"] + qty, owner, item))
        else:
            self.conn.execute("INSERT INTO holdings(owner_id, item_id, qty, state) VALUES(?,?,?,?)",
                              (owner, item, qty, json.dumps(state or {})))

    def take(self, owner: str, item: str, qty: int = 1) -> dict:
        row = self.conn.execute("SELECT qty, state FROM holdings WHERE owner_id=? AND item_id=?",
                                (owner, item)).fetchone()
        if row is None or row["qty"] < qty:
            raise LedgerError(f"'{owner}' does not hold {qty}x '{item}'.")
        if row["qty"] == qty:
            self.conn.execute("DELETE FROM holdings WHERE owner_id=? AND item_id=?", (owner, item))
        else:
            self.conn.execute("UPDATE holdings SET qty=? WHERE owner_id=? AND item_id=?",
                              (row["qty"] - qty, owner, item))
        return json.loads(row["state"] or "{}")

    def item_state(self, owner: str, item: str) -> dict:
        row = self.conn.execute("SELECT state FROM holdings WHERE owner_id=? AND item_id=?",
                                (owner, item)).fetchone()
        return json.loads(row["state"]) if row else {}

    def set_item_state(self, owner: str, item: str, state: dict) -> None:
        self.conn.execute("UPDATE holdings SET state=? WHERE owner_id=? AND item_id=?",
                          (json.dumps(state), owner, item))

    def holders(self, item: str) -> list[str]:
        return [r["owner_id"] for r in self.conn.execute("SELECT owner_id FROM holdings WHERE item_id=?", (item,))]

    # ── scenes ──────────────────────────────────────────────────────────
    def current_scene(self) -> dict | None:
        row = self.conn.execute("SELECT * FROM scenes WHERE status='active' ORDER BY id DESC LIMIT 1").fetchone()
        return dict(row) if row else None

    def scene(self, sid: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM scenes WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None

    def scenes(self) -> list[dict]:
        return [dict(r) for r in self.conn.execute("SELECT * FROM scenes ORDER BY id")]

    def create_scene(self, title: str, location_id: str | None, turn: int) -> int:
        self.conn.execute("UPDATE scenes SET status='parked' WHERE status='active'")
        cur = self.conn.execute("INSERT INTO scenes(title, location_id, status, created_turn) VALUES(?,?,?,?)",
                                (title, location_id, "active", turn))
        return cur.lastrowid

    def activate_scene(self, sid: int) -> None:
        self.conn.execute("UPDATE scenes SET status='parked' WHERE status='active'")
        self.conn.execute("UPDATE scenes SET status='active' WHERE id=?", (sid,))

    def roster(self, sid: int) -> list[str]:
        return [r["entity_id"] for r in
                self.conn.execute("SELECT entity_id FROM scene_roster WHERE scene_id=? ORDER BY entity_id", (sid,))]

    def enter(self, sid: int, ids: Iterable[str], turn: int) -> tuple[list[str], list[str]]:
        """Put entities in the scene. Returns (newly present this scene, previously present)."""
        prior = [r["entity_id"] for r in
                 self.conn.execute("SELECT entity_id FROM scene_presence WHERE scene_id=?", (sid,))]
        new = []
        for eid in ids:
            self.conn.execute("INSERT OR IGNORE INTO scene_roster(scene_id, entity_id) VALUES(?,?)", (sid, eid))
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO scene_presence(scene_id, entity_id, first_turn) VALUES(?,?,?)",
                (sid, eid, turn))
            if cur.rowcount:
                new.append(eid)
        return new, prior

    def leave(self, sid: int, ids: Iterable[str]) -> None:
        for eid in ids:
            self.conn.execute("DELETE FROM scene_roster WHERE scene_id=? AND entity_id=?", (sid, eid))

    def scene_of(self, eid: str) -> int | None:
        row = self.conn.execute(
            "SELECT r.scene_id FROM scene_roster r JOIN scenes s ON s.id=r.scene_id"
            " WHERE r.entity_id=? ORDER BY (s.status='active') DESC, s.id DESC LIMIT 1", (eid,)).fetchone()
        return row["scene_id"] if row else None

    def ever_placed(self, eid: str) -> bool:
        """Has eid ever been in a scene? scene_of is None both for what was never placed and for what left (leave drops
        the roster row; scene_presence keeps the history) - and a drone the GM sent out of the scene isn't one that's
        never been anywhere (review: a Fly-Spy left behind with scene_presence leave followed its rigger again)."""
        return self.conn.execute("SELECT 1 FROM scene_presence WHERE entity_id=? LIMIT 1", (eid,)).fetchone() is not None

    def presence_counts(self) -> tuple[dict[str, int], int]:
        counts = {r["entity_id"]: r["n"] for r in self.conn.execute(
            "SELECT entity_id, COUNT(*) AS n FROM scene_presence GROUP BY entity_id")}
        total = self.conn.execute("SELECT COUNT(DISTINCT scene_id) AS n FROM scene_presence").fetchone()["n"]
        return counts, total

    # ── turns & events ──────────────────────────────────────────────────
    # ── sessions (story time for memory: "last session" beats "11 turns ago") ──
    def session(self) -> int:
        return int(self.meta("session", "1"))

    def new_session(self) -> int:
        """The next session - and every PC's Edge points are back to their Edge rating."""
        n = self.session() + 1
        self.set_meta("session", str(n))
        for pc in self.entities(kind="pc"):
            rating = self.stat(pc["id"], "edge", 0)
            if rating:
                self.set_stat(pc["id"], "edge_points", rating)
        return n

    def session_of(self, turn_id: int) -> int | None:
        row = self.conn.execute("SELECT session FROM turns WHERE id=?", (turn_id,)).fetchone()
        return row["session"] if row else None

    def begin_turn(self, scene_id: int | None, inputs: list, status: str = "open") -> int:
        cur = self.conn.execute("INSERT INTO turns(scene_id, inputs, status, session) VALUES(?,?,?,?)",
                                (scene_id, json.dumps(inputs), status, self.session()))
        return cur.lastrowid

    def finish_turn(self, tid: int, narration: str, cost: float, status: str = "committed") -> None:
        self.conn.execute("UPDATE turns SET narration=?, cost=?, status=? WHERE id=?",
                          (narration, cost, status, tid))

    def last_turn(self, scene_id: int | None = None, before: int | None = None,
                  public: bool = False) -> dict | None:
        sql, args = "SELECT * FROM turns WHERE status IN ('committed','seed')", []
        if public:
            sql += " AND private IS NULL"
        if scene_id is not None:
            sql += " AND scene_id=?"
            args.append(scene_id)
        if before is not None:
            sql += " AND id<?"
            args.append(before)
        row = self.conn.execute(sql + " ORDER BY id DESC LIMIT 1", args).fetchone()
        return dict(row) if row else None

    def total_cost(self) -> float:
        return self.conn.execute("SELECT COALESCE(SUM(cost),0) AS c FROM turns").fetchone()["c"]

    def log(self, turn_id: int | None, kind: str, actor: str | None, payload: dict) -> None:
        self.conn.execute("INSERT INTO events(turn_id, kind, actor, payload) VALUES(?,?,?,?)",
                          (turn_id, kind, actor, json.dumps(payload)))

    def events(self, turn_id: int) -> list[dict]:
        return [dict(r) | {"payload": json.loads(r["payload"])} for r in
                self.conn.execute("SELECT * FROM events WHERE turn_id=? ORDER BY seq", (turn_id,))]
