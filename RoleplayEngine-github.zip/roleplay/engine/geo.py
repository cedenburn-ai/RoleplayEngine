"""Geography: where locations are, and how far apart (DESIGN.md §12a).

Every location gets a position (lat/lon) in Sixth World Seattle. The models never do the math:
the engine places a new location from hints ("in Tacoma", "near the Lucky Shot, six blocks east"),
and hands the DM precomputed distances, bearings and travel times. Travel also moves the story
clock, so a run across the metroplex is a story beat, not a jump cut.

Positions are stored on the location's ledger props: props.geo = {lat, lon, district, how}.
"""
from __future__ import annotations

import hashlib
import math
import re

from . import coast

# The metroplex: districts and landmarks at real-world coordinates (Sixth World names).
# (lat, lon, radius in meters for placing things "somewhere in" it, aliases)
GAZETTEER: dict[str, tuple[float, float, int, tuple[str, ...]]] = {
    "Downtown": (47.6062, -122.3321, 1500, ("downtown seattle", "the core")),
    "Ork Underground": (47.6015, -122.3343, 400, ("the underground", "pioneer square")),
    "Pike Place": (47.6097, -122.3422, 300, ("pike place market", "the market")),
    "Touristville": (47.6080, -122.3400, 500, ()),
    "Seattle Center": (47.6205, -122.3493, 500, ("space needle", "the needle")),
    "Renraku Arcology": (47.6125, -122.3440, 300, ("the arcology", "arcology", "the arc")),
    "Elliott Bay Docks": (47.6027, -122.3385, 700, ("the docks", "docks", "the waterfront", "waterfront")),
    "Harbor Island": (47.5770, -122.3500, 800, ("the port", "port of seattle")),
    "Bellevue": (47.6101, -122.2015, 2500, ()),
    "Council Island": (47.5707, -122.2221, 1500, ("mercer island",)),
    "Redmond": (47.6740, -122.1215, 3000, ()),
    "Redmond Barrens": (47.6620, -122.1350, 2500, ("the barrens", "barrens", "redmond barrens")),
    "Glow City": (47.6900, -122.1000, 1200, ("the glow",)),
    "Kirkland": (47.6815, -122.2087, 1500, ()),
    "520 Bridge": (47.6400, -122.2600, 1500, ("520", "the 520", "sr-520", "evergreen point bridge")),
    "I-90 Bridge": (47.5900, -122.2650, 1200, ("i-90",)),
    "Renton": (47.4829, -122.2171, 2500, ()),
    "Sea-Tac": (47.4502, -122.3088, 1500, ("seatac", "sea-tac airport", "the airport")),
    "Auburn": (47.3073, -122.2285, 2500, ()),
    "Tacoma": (47.2529, -122.4443, 4000, ()),
    "Puyallup": (47.1854, -122.2929, 3000, ()),
    "Puyallup Barrens": (47.1950, -122.3100, 3000, ()),
    "Tarislar": (47.2000, -122.3300, 800, ()),
    "Hell's Kitchen": (47.1300, -122.2500, 1500, ("hells kitchen",)),
    "Everett": (47.9790, -122.2021, 4000, ()),
    "Snohomish": (47.9129, -122.0982, 3000, ()),
    "Fort Lewis": (47.0854, -122.5806, 4000, ("joint base lewis",)),
    "Salish-Shidhe Border": (47.7000, -121.9000, 5000, ("the border", "salish-shidhe", "salish shidhe")),
}
DEFAULT_DISTRICT = "Redmond Barrens"
BEARINGS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
ROAD = 1.3                 # streets don't run straight
WALK_M_PER_MIN = 75        # ~4.5 km/h
CITY_KMH, HIGHWAY_KMH, HIGHWAY_OVERHEAD = 25.0, 60.0, 6
EARTH = 6_371_000.0


# ── math ────────────────────────────────────────────────────────────────

def distance_m(a: dict, b: dict) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * EARTH * math.asin(math.sqrt(h))


def bearing(a: dict, b: dict) -> str:
    lat1, lon1, lat2, lon2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    y = math.sin(lon2 - lon1) * math.cos(lat2)
    x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(lon2 - lon1)
    deg = (math.degrees(math.atan2(y, x)) + 360) % 360
    return BEARINGS[int((deg + 22.5) // 45) % 8]


def offset(lat: float, lon: float, compass: str, meters: float) -> tuple[float, float]:
    deg = BEARINGS.index(compass) * 45 if compass in BEARINGS else 0
    d, th = meters / EARTH, math.radians(deg)
    la1, lo1 = math.radians(lat), math.radians(lon)
    la2 = math.asin(math.sin(la1) * math.cos(d) + math.cos(la1) * math.sin(d) * math.cos(th))
    lo2 = lo1 + math.atan2(math.sin(th) * math.sin(d) * math.cos(la1), math.cos(d) - math.sin(la1) * math.sin(la2))
    return math.degrees(la2), math.degrees(lo2)


def travel_minutes(meters: float) -> dict:
    """On foot and by car, along streets."""
    road = meters * ROAD
    walk = road / WALK_M_PER_MIN
    km = road / 1000
    car = km / CITY_KMH * 60 if km < 5 else HIGHWAY_OVERHEAD + km / HIGHWAY_KMH * 60
    return {"walk": max(1, round(walk)), "car": max(1, round(car))}


def _fmt_min(m: int) -> str:
    return f"{m} min" if m < 90 else f"{m / 60:.1f} h".replace(".0 h", " h")


def how_far(meters: float) -> str:
    """Distance the way the story says it - travel takes as long as the story needs, nobody counts minutes."""
    return ("right here" if meters < 60 else "a short walk" if meters < 400 else "a walk, or a quick drive"
            if meters < 1500 else "a short drive" if meters < 6000 else "across town" if meters < 20000
            else "the far side of the metroplex")


def describe(a: dict, b: dict) -> str:
    """'0.6 km E · a walk, or a quick drive' (from a to b)."""
    d = distance_m(a, b)
    if d < 60:
        return "right here"
    dist = f"{round(d)} m" if d < 1000 else f"{d / 1000:.1f} km"
    return f"{dist} {bearing(a, b)} · {how_far(d)}"


def best_trip(a: dict, b: dict) -> tuple[str, int]:
    """How a party would plausibly go: on foot for short hops, by car otherwise."""
    t = travel_minutes(distance_m(a, b))
    return ("walk", t["walk"]) if t["walk"] <= 20 else ("car", t["car"])


# ── places ──────────────────────────────────────────────────────────────

def district(name: str | None) -> str | None:
    """A gazetteer name from a name or alias, if it is one."""
    if not name:
        return None
    low = name.strip().lower()
    for key, (_, _, _, aliases) in GAZETTEER.items():
        if low == key.lower() or low in aliases:
            return key
    return None


def districts_in(text: str) -> list[str]:
    """Gazetteer places named in free text, longest names first (so 'Redmond Barrens' beats 'Redmond')."""
    low, found = (text or "").lower(), []
    names = sorted(((n.lower(), key) for key, v in GAZETTEER.items() for n in (key, *v[3])), key=lambda x: -len(x[0]))
    taken: list[tuple[int, int]] = []
    for name, key in names:
        for m in re.finditer(rf"(?<![a-z0-9]){re.escape(name)}(?![a-z0-9])", low):
            if key not in found and not any(s <= m.start() < e for s, e in taken):
                found.append(key)
                taken.append((m.start(), m.end()))
    return found


def district_geo(name: str) -> dict:
    lat, lon, _, _ = GAZETTEER[name]
    return {"lat": lat, "lon": lon, "district": name}


def _jitter(key: str, radius: int) -> tuple[str, float]:
    """A stable 'somewhere in there' for a place with no better hint."""
    h = int(hashlib.md5(key.encode()).hexdigest()[:8], 16)
    return BEARINGS[h % 8], radius * (0.25 + 0.6 * ((h >> 3) % 1000) / 1000)


def geo_of(game, eid: str | None) -> dict | None:
    """A location's position; a person's comes from where they are (scene, or offscreen whereabouts)."""
    if not eid:
        return None
    L = game.ledger
    ent = L.get(eid)
    if not ent:
        return district_geo(district(eid)) if district(eid) else None
    if ent["kind"] == "location":
        return ent["props"].get("geo")
    w = ent["props"].get("whereabouts") or {}
    if w.get("place"):
        return geo_of(game, w["place"]) if L.get(w["place"]) else (
            district_geo(w["place"]) if w["place"] in GAZETTEER else None)
    sid = L.scene_of(eid)
    if sid:
        sc = L.scene(sid)
        return geo_of(game, sc["location_id"]) if sc and sc["location_id"] else None
    return None


def place(game, loc_id: str, district_name: str | None = None, near: str | None = None,
          compass: str | None = None, meters: float | None = None, origin: str | None = None) -> dict:
    """Give a location a position. Precedence: near a known place (+ bearing and distance), then a named
    district, then a district named in its name/description, then near the origin (the scene it was
    reached from), then the default district."""
    L = game.ledger
    ent = L.require(loc_id)
    if ent["props"].get("geo"):
        return ent["props"]["geo"]
    compass = (compass or "").upper() if (compass or "").upper() in BEARINGS else None
    anchor, how = None, ""
    near_ent = L.find(near) if near else None
    if near_ent and near_ent["id"] != ent["id"] and geo_of(game, near_ent["id"]):
        anchor, how = geo_of(game, near_ent["id"]), f"near {near_ent['id']}"
        meters = meters if meters and meters > 0 else 400
    elif district(district_name):
        anchor, how = district_geo(district(district_name)), f"in {district(district_name)}"
    elif districts_in(f"{ent['name']} {ent['description']}"):
        d = districts_in(f"{ent['name']} {ent['description']}")[0]
        anchor, how = district_geo(d), f"in {d} (from its description)"
    elif origin and geo_of(game, origin):
        anchor, how = geo_of(game, origin), f"near {origin} (where the party came from)"
        meters = meters if meters and meters > 0 else 500
    else:
        anchor, how = district_geo(DEFAULT_DISTRICT), f"in {DEFAULT_DISTRICT} (default)"
    if not meters:                                   # somewhere in the district
        radius = GAZETTEER.get(anchor.get("district") or "", (0, 0, 800, ()))[2]
        jc, meters = _jitter(ent["id"], radius)
        compass = compass or jc
    elif not compass:
        compass = _jitter(ent["id"], 1)[0]
    lat, lon = offset(anchor["lat"], anchor["lon"], compass, min(meters, 200_000))
    shore = None
    if not on_a_bridge(anchor.get("district")):           # (somewhere in Downtown shouldn't mean in Elliott Bay)
        s = coast.shore_check(lat, lon)
        lat, lon, shore = s["lat"], s["lon"], s["by"]
        if s["moved"]:
            how += f"; moved ashore {int(s['moved'])} m"
    near_d = nearest_district(lat, lon)
    geo = {"lat": round(lat, 6), "lon": round(lon, 6), "district": near_d, "how": how}
    if shore == "map":
        geo["shore"] = coast.SHORE                        # (checked against the real map: not again)
    L.update_entity(ent["id"], props={**ent["props"], "geo": geo})
    return geo


def nearest_district(lat: float, lon: float) -> str:
    """The district a point is in: the nearest center, weighted by how big the district is."""
    p = {"lat": lat, "lon": lon}
    return min(GAZETTEER, key=lambda k: distance_m(p, district_geo(k)) / max(GAZETTEER[k][2], 300))


def on_a_bridge(district_name: str | None) -> bool:
    return "bridge" in (district_name or "").lower()


def ensure_all(game, origin: str | None = None) -> list[str]:
    """Place every location that has no position yet (cheap, deterministic) - and bring ashore any placed in the
    water before the engine knew where the shore was."""
    placed = []
    for loc in game.ledger.entities(kind="location", status=None):
        g = loc["props"].get("geo")
        if not g:
            place(game, loc["id"], origin=origin)
            placed.append(loc["id"])
        elif not on_a_bridge(g.get("district")) and g.get("shore") != coast.SHORE:
            s = coast.shore_check(g["lat"], g["lon"])     # (until the real map has confirmed it, look again)
            if s["moved"] or s["by"] == "map":
                g = {**g, "lat": s["lat"], "lon": s["lon"], "district": nearest_district(s["lat"], s["lon"])}
                if s["moved"]:
                    g["how"] = f"{g.get('how', '')}; moved ashore {int(s['moved'])} m".lstrip("; ")
                if s["by"] == "map":
                    g["shore"] = coast.SHORE
                game.ledger.update_entity(loc["id"], props={**loc["props"], "geo": g})
                if s["moved"]:
                    placed.append(loc["id"])
    return placed


def where_lines(game, here: dict, candidates: list[str], limit: int = 8) -> list[str]:
    """'Name [id] (District) - 0.6 km E · 8 min on foot, 2 min by car' for each known place, nearest first."""
    L, seen, rows = game.ledger, set(), []
    for c in candidates:
        if c in seen:
            continue
        seen.add(c)
        g = geo_of(game, c)
        if not g:
            continue
        ent = L.get(c)
        label = f"{ent['name']} [{ent['id']}] ({g.get('district', '?')})" if ent else f"{c} (district)"
        rows.append((distance_m(here, g), f"{label} - {describe(here, g)}"))
    rows.sort(key=lambda r: r[0])
    return [r for _, r in rows[:limit]]
