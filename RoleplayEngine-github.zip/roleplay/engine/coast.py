"""The metroplex's water and land (DESIGN.md §12a): Puget Sound, the lakes, the islands, the highways.

The traced shapes are schematic - good to a few hundred meters, so Seattle's piers sit "inland" of the trace. maps.py
draws them. To keep places out of the water the engine asks the real map first: OpenStreetMap paints water one exact
blue, so `shore_check` samples the tile under a point (cached on disk in campaigns/.cache/osm) and walks out to the
nearest real shore. Offline - or in tests (ROLEPLAY_TILES=off) - it falls back to the traced shapes.
"""
from __future__ import annotations

import io
import math
import os
import time
import urllib.request

from ..config import CAMPAIGN_DIR

# Coastlines (lat, lon), hand-traced and simplified - schematic, not survey grade.
SOUND = [  # Puget Sound's main basin: the east shore north->south, then the Kitsap shore back north
    (48.03, -122.22), (47.98, -122.23), (47.95, -122.29), (47.90, -122.33), (47.85, -122.36), (47.81, -122.39),
    (47.76, -122.38), (47.70, -122.40), (47.67, -122.41), (47.66, -122.435), (47.645, -122.41), (47.63, -122.40),
    (47.625, -122.38), (47.615, -122.36), (47.61, -122.35), (47.60, -122.34), (47.59, -122.343), (47.575, -122.355),
    (47.58, -122.37), (47.585, -122.39), (47.578, -122.418), (47.56, -122.405), (47.53, -122.395), (47.50, -122.37),
    (47.45, -122.35), (47.40, -122.33), (47.35, -122.34), (47.32, -122.39), (47.30, -122.42), (47.28, -122.41),
    (47.265, -122.42), (47.255, -122.435), (47.27, -122.45), (47.29, -122.48), (47.31, -122.515), (47.29, -122.535),
    (47.27, -122.55), (47.24, -122.56), (47.20, -122.58), (47.17, -122.60), (47.13, -122.65), (47.10, -122.68),
    (47.08, -122.72), (47.04, -122.75), (47.03, -122.80),
    (47.10, -122.80), (47.17, -122.66), (47.22, -122.59), (47.26, -122.565), (47.30, -122.56), (47.35, -122.55),
    (47.40, -122.53), (47.46, -122.53), (47.51, -122.50), (47.55, -122.53), (47.59, -122.56), (47.62, -122.57),
    (47.70, -122.60), (47.75, -122.56), (47.80, -122.50), (47.86, -122.53), (47.92, -122.58), (47.96, -122.60),
    (48.03, -122.62),
]
LAKES = {
    "Lake Washington": [
        (47.765, -122.275), (47.74, -122.28), (47.70, -122.275), (47.68, -122.255), (47.66, -122.275),
        (47.645, -122.29), (47.63, -122.28), (47.61, -122.285), (47.59, -122.275), (47.565, -122.265),
        (47.54, -122.26), (47.51, -122.255), (47.50, -122.215), (47.505, -122.20), (47.53, -122.20),
        (47.56, -122.195), (47.59, -122.205), (47.61, -122.21), (47.63, -122.22), (47.66, -122.21),
        (47.68, -122.21), (47.71, -122.23), (47.74, -122.25), (47.76, -122.265)],
    "Lake Sammamish": [
        (47.655, -122.105), (47.64, -122.11), (47.61, -122.105), (47.58, -122.09), (47.555, -122.07),
        (47.555, -122.05), (47.58, -122.06), (47.61, -122.075), (47.64, -122.09)],
    "Lake Union": [(47.648, -122.335), (47.645, -122.32), (47.63, -122.33), (47.625, -122.34), (47.635, -122.345)],
}
ISLANDS = {
    "Vashon": [(47.51, -122.47), (47.50, -122.44), (47.45, -122.43), (47.40, -122.43), (47.36, -122.43),
               (47.33, -122.46), (47.33, -122.50), (47.38, -122.52), (47.44, -122.52), (47.50, -122.51)],
    "Bainbridge": [(47.72, -122.53), (47.68, -122.49), (47.63, -122.49), (47.60, -122.52), (47.59, -122.55),
                   (47.62, -122.58), (47.67, -122.57), (47.71, -122.56)],
    "Whidbey": [(48.03, -122.35), (47.98, -122.37), (47.92, -122.38), (47.90, -122.40), (47.93, -122.45),
                (47.98, -122.50), (48.03, -122.55)],
    "Council Island": [(47.595, -122.23), (47.59, -122.215), (47.56, -122.215), (47.53, -122.22),
                       (47.535, -122.235), (47.56, -122.245), (47.585, -122.245)],
}
ROADS = {
    "I-5": [(48.03, -122.19), (47.98, -122.19), (47.90, -122.25), (47.82, -122.30), (47.75, -122.32),
            (47.68, -122.32), (47.64, -122.325), (47.61, -122.33), (47.58, -122.32), (47.54, -122.30),
            (47.48, -122.27), (47.40, -122.29), (47.33, -122.31), (47.28, -122.35), (47.24, -122.43),
            (47.20, -122.48), (47.15, -122.53), (47.10, -122.62), (47.05, -122.70)],
    "I-405": [(47.83, -122.26), (47.79, -122.21), (47.73, -122.18), (47.68, -122.185), (47.62, -122.185),
              (47.58, -122.18), (47.53, -122.19), (47.49, -122.21), (47.465, -122.26)],
    "SR-520": [(47.645, -122.32), (47.64, -122.29), (47.64, -122.22), (47.635, -122.19), (47.65, -122.14),
               (47.67, -122.11)],
    "I-90": [(47.59, -122.32), (47.59, -122.27), (47.585, -122.21), (47.57, -122.16), (47.55, -122.05),
             (47.53, -121.95), (47.50, -121.83)],
    "SR-167": [(47.47, -122.21), (47.38, -122.24), (47.30, -122.24), (47.20, -122.28)],
}


EARTH = 6_371_000.0


def _inside(lat: float, lon: float, poly: list[tuple[float, float]]) -> bool:
    """Ray casting in lat/lon (fine at this scale)."""
    hit = False
    j = len(poly) - 1
    for i in range(len(poly)):
        (ya, xa), (yb, xb) = poly[i], poly[j]
        if (ya > lat) != (yb > lat) and lon < (xb - xa) * (lat - ya) / (yb - ya) + xa:
            hit = not hit
        j = i
    return hit


def in_water(lat: float, lon: float) -> bool:
    if any(_inside(lat, lon, p) for p in ISLANDS.values()):
        return False
    return _inside(lat, lon, SOUND) or any(_inside(lat, lon, p) for p in LAKES.values())


def _step(lat: float, lon: float, degrees: float, meters: float) -> tuple[float, float]:
    rad = math.radians(degrees)
    return (lat + math.degrees(meters * math.cos(rad) / EARTH),
            lon + math.degrees(meters * math.sin(rad) / (EARTH * math.cos(math.radians(lat)))))


def ashore(lat: float, lon: float, inland: float = 120.0) -> tuple[float, float, float]:
    """By the traced shapes only (offline): the nearest dry spot to a point in the water - a little inland, so the
    rough trace matters less - as (lat, lon, meters moved). A point already on land comes back as it is."""
    if not in_water(lat, lon):
        return lat, lon, 0.0
    for r in range(60, 20_001, 60):
        for k in range(36):
            deg = k * 10
            la, lo = _step(lat, lon, deg, r)
            if not in_water(la, lo):
                la2, lo2 = _step(lat, lon, deg, r + inland)
                if not in_water(la2, lo2):
                    la, lo = la2, lo2
                return round(la, 6), round(lo, 6), float(r)
    return lat, lon, 0.0


# ── the real map: OpenStreetMap's tiles ─────────────────────────────────
TILE_Z = 16                      # ~2.4 m a pixel this far north
WATER = (170, 211, 223)          # OpenStreetMap's water (#aad3df) - the sea, lakes and rivers alike
CACHE = CAMPAIGN_DIR / ".cache" / "osm"
AGENT = "RoleplayEngine/1.0 (a personal tabletop game; keeps its places out of the water)"
_tiles: dict[tuple[int, int, int], object] = {}
_offline_until = 0.0


def tiles_on() -> bool:
    return os.environ.get("ROLEPLAY_TILES", "on").lower() != "off"


def _tile(x: int, y: int, z: int = TILE_Z):
    """One map tile as an RGB image - from memory, the disk cache, or OpenStreetMap - or None."""
    global _offline_until
    if not tiles_on():                                  # (off means off - not even the disk cache: tests stay exact)
        return None
    key = (z, x, y)
    if key in _tiles:
        return _tiles[key]
    from PIL import Image                               # (imported late: the engine doesn't need it otherwise)
    f = CACHE / str(z) / str(x) / f"{y}.png"
    img = None
    if f.exists():
        try:
            img = Image.open(f).convert("RGB")
        except OSError:
            img = None
    if img is None:
        if not tiles_on() or time.time() < _offline_until:
            return None
        try:
            req = urllib.request.Request(f"https://tile.openstreetmap.org/{z}/{x}/{y}.png", headers={"User-Agent": AGENT})
            with urllib.request.urlopen(req, timeout=8) as r:
                data = r.read()
            img = Image.open(io.BytesIO(data)).convert("RGB")
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_bytes(data)
        except Exception:
            _offline_until = time.time() + 300           # (offline: try again in five minutes, use the trace till then)
            return None
    if len(_tiles) > 96:
        _tiles.clear()
    _tiles[key] = img
    return img


SHORE = "map:2"                  # the version of the check a place passed (geo.ensure_all re-checks older ones)


def water_share(lat: float, lon: float, step: int = 6, n: int = 7) -> float | None:
    """How much of the ~60 m square around a point OpenStreetMap paints as water (0..1), or None when the map can't
    be had. A square, not a point: ferry-slip pilings and dolphins out in the bay are drawn as tiny bits of land."""
    z = 2 ** TILE_Z
    fx = (lon + 180) / 360 * z * 256
    fy = (1 - math.log(math.tan(math.radians(lat)) + 1 / math.cos(math.radians(lat))) / math.pi) / 2 * z * 256
    half = (n - 1) // 2
    wet = total = 0
    for i in range(-half, half + 1):
        for j in range(-half, half + 1):
            px, py = fx + i * step, fy + j * step
            img = _tile(int(px // 256), int(py // 256))
            if img is None:
                return None
            c = img.getpixel((int(px % 256), int(py % 256)))
            wet += all(abs(int(v) - w) <= 8 for v, w in zip(c, WATER))
            total += 1
    return wet / total


def water_at(lat: float, lon: float) -> bool | None:
    """Is a point in the water by OpenStreetMap - more than a quarter of the square around it - or None offline."""
    share = water_share(lat, lon)
    return None if share is None else share > 0.25


def shore_check(lat: float, lon: float, inland: float = 30.0, reach: int = 2000) -> dict:
    """Is a point on land? By the real map when it can be had, else by the traced shapes - and if not, the nearest
    solid ground (hardly any water around it) a little inland. Returns {lat, lon, moved (meters), by: 'map' | 'trace'}."""
    share = water_share(lat, lon)
    if share is None:
        la, lo, moved = ashore(lat, lon)
        return {"lat": la, "lon": lo, "moved": moved, "by": "trace"}
    if share <= 0.25:
        return {"lat": lat, "lon": lon, "moved": 0.0, "by": "map"}
    for r in range(25, reach + 1, 25):
        for k in range(24):
            la, lo = _step(lat, lon, k * 15, r)
            w = water_share(la, lo)
            if w is None:                                 # (lost the map halfway: the trace it is)
                la, lo, moved = ashore(lat, lon)
                return {"lat": la, "lon": lo, "moved": moved, "by": "trace"}
            if w <= 0.08:                                 # solid ground, not a piling or the end of a slip
                la2, lo2 = _step(lat, lon, k * 15, r + inland)
                w2 = water_share(la2, lo2)
                if w2 is not None and w2 <= 0.08:
                    la, lo = la2, lo2
                return {"lat": round(la, 6), "lon": round(lo, 6), "moved": float(r), "by": "map"}
    la, lo, moved = ashore(lat, lon)                      # far out in the Sound: the trace gets it near the shore
    return {"lat": la, "lon": lo, "moved": moved, "by": "trace"}
