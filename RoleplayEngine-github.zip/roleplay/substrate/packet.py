"""The memory packet: what the DM sees each turn (DESIGN.md §8; the DOUBTS section, §12k).

Deterministic and cheap. The query is the scene itself - who and what is in the room -
plus whatever the players named. Everything carries an id the DM can recall().

Layout rules learned from long autoplay runs:
- every memory, fact and note is printed in full ONCE; later mentions are bare ids;
- NPC "Remembers" lines skip the scene's recent turns (already in RECENTLY) so they surface
  the *older* first-hand memories - which is the whole point of memory;
- associations only show once two things have shared more than one scene.
"""
from __future__ import annotations

import json

from ..engine import clock, geo
from ..engine.rules import sr_lite

RECENT_N = 6


def _clock_miss(game, turn_id: int) -> list[str]:
    """The table's next turn after a time: line the clock couldn't read, the GM hears it. Live T162: 'time: 3 days
    later, evening' went to the bot log alone, and the GM narrated on ('Day 7, evening') from a clock three days behind.
    Only while the clock still stands where that line left it - once the owner's `!time` (or anything) sets it,
    "set it again" would skip the time twice - and never in a whisper, which would spend it where the scene doesn't
    move on: the table's own next turn hears it."""
    try:
        miss = json.loads(game.ledger.meta(clock.MISS) or "null")
    except ValueError:
        return []
    if not isinstance(miss, dict) or miss.get("clock") != game.clock():
        return []
    rows = game.conn.execute("SELECT id, status, private FROM turns WHERE id > ? AND id <= ?",
                             (int(miss.get("turn") or 0), turn_id)).fetchall()
    if any(r["private"] for r in rows if r["id"] == turn_id):
        return []                                                           # (a whisper)
    if any(r["status"] == "committed" and not r["private"] for r in rows if r["id"] < turn_id):
        return []                                                           # (the table's turn after has had it)
    return [f"(your last `time: {miss.get('text', '')}` wasn't read, so that line didn't move the clock; if time "
            f"passed, set it again, e.g. `time: day {clock.day_of(game.clock()) + 1} evening` or "
            f"`time: 3 days later, evening`)"]


def _heat(game, energy: float | None) -> str:
    mean = game.sub.system_mean() or 1.0
    return f"heat {((energy or 0) / mean):.1f}x"


def _ago(game, row: dict, turn_id: int) -> str:
    """Story time: in-fiction time when the slice carries it (+ "last session" across sessions);
    older slices fall back to sessions and turns."""
    st = row.get("story_time")
    if st is None and row.get("kind") == "slice" and "story_time" not in row:
        node = game.sub.node(row["id"])
        st = node["story_time"] if node else None
    if st is not None:
        text = clock.since(st, game.clock())
        then = game.ledger.session_of(row["created_turn"]) if str(row["id"]).startswith("T") else None
        k = game.ledger.session() - then if then is not None else 0
        return text + ("" if k <= 0 else ", last session" if k == 1 else f", {k} sessions ago")
    now = game.ledger.session()
    then = game.ledger.session_of(row["created_turn"]) if row.get("kind") == "slice" else None
    if then is not None and then < now:
        k = now - then
        return "last session" if k == 1 else f"{k} sessions ago"
    n = turn_id - row["created_turn"]
    return "just now" if n <= 0 else f"{n} turn{'s' if n != 1 else ''} ago this session"


def whisper_knowers(game, row: dict) -> list[str]:
    """Who knows a whisper's memory (its slice, or a fact out of it): who sent it - the sender of the whisper turn it
    names (`about`), else of the turn it was set down in - and whoever has heard of it since (knows). Never just who is
    in it: the memory pass lists whoever it was done to, who may never have noticed (witness.Scope holds a whisper the
    same way: its sender's, and the told)."""
    conn, nid = game.conn, row["id"]
    named = [int(x["other"][1:]) for x in game.sub.links_of(nid)
             if x["kind"] == "about" and x["other"][:1] == "T" and x["other"][1:].isdigit()]
    turn = row.get("created_turn")
    if turn is None:
        node = game.sub.node(nid)
        turn = node["created_turn"] if node else None
    who = []
    for t in (named if nid[:1] != "T" and named else [turn]):
        r = conn.execute("SELECT private FROM turns WHERE id=?", (t,)).fetchone() if t is not None else None
        if r and r[0]:
            who.append(r[0])
    who += [r[0] for r in conn.execute("SELECT holder FROM knows WHERE node_id=? ORDER BY turn", (nid,))]
    return list(dict.fromkeys(who))


def _whisper(game, row: dict) -> str:
    """A whisper's slice says who knows - everyone else must not. Review (2026-10-26): it named every witness-role
    member as knowing, so Ghost's tracker slipped into Razor's coat ('He never notices') read "only Ghost, Razor
    know" - and when Razor's player asked the aside about his coat, the record told it Razor knew. Who sent it (and
    who heard of it since) knows; anyone else in it, only if they noticed."""
    vis = row.get("visibility")
    if vis is None:
        node = game.sub.node(row["id"])
        vis = node["visibility"] if node else "public"
    if vis not in ("private", "offscreen"):
        return ""
    L, roles = game.ledger, game.settings.knobs.witness_roles
    inside = [m for m, r in game.sub.members_of(row["id"]) if r in roles]

    def named(ids) -> list[str]:
        return [e["name"] for e in map(L.get, dict.fromkeys(ids)) if e and e["kind"] in ("pc", "npc", "faction")]
    if vis == "offscreen":
        names = named(inside)
        return f"OFFSCREEN, no PC saw it - only {', '.join(names) or 'the GM'} know{'s' if len(names) <= 1 else ''}: "
    knowers = whisper_knowers(game, row)
    names, others = named(knowers), named(m for m in inside if m not in knowers)
    return (f"WHISPER, private - only {', '.join(names) or 'the GM'} know{'s' if len(names) <= 1 else ''}"
            + (f" ({', '.join(others)} too, only if they noticed it)" if others else "") + ": ")


def slice_line(game, row: dict, turn_id: int) -> str:
    energy = row.get("energy", game.sub.energy_of(row["id"]))
    scene = f"S{row['scene_id']}, " if row.get("scene_id") else ""
    return (f"[{row['id']}] ({scene}{_ago(game, row, turn_id)}, {_heat(game, energy)}) "
            f"{_whisper(game, row)}{row['text']}")


class _Printed:
    """Print each memory once; afterwards refer to it by id."""

    def __init__(self, game, turn_id: int, shown: set[str]):
        self.game, self.turn_id, self.shown, self.full = game, turn_id, shown, set()

    def slice(self, row: dict, suffix: str = "") -> str:
        self.shown.add(row["id"])
        if row["id"] in self.full:
            return f"[{row['id']}] (see above){suffix}"
        self.full.add(row["id"])
        return slice_line(self.game, row, self.turn_id) + suffix


def _assoc_line(game, eid: str, presence, total) -> str | None:
    bits = []
    for a in game.sub.associations(eid, presence, total, 6):
        if a["together"] < 2:
            continue
        other = game.ledger.get(a["id"])
        if other:
            bits.append(f"{other['name']} [{a['id']}] ({a['together']} scenes, lift {a['lift']:.1f})")
    return ("Often with: " + ", ".join(bits[:3])) if bits else None


def _picture(game, eid: str, indent: str) -> list[str]:
    """The GM's current picture of a node (C#): its notes up to then, folded into one page."""
    pic = game.sub.clarification(eid)
    return [f"{indent}Current picture (GM-only) [{pic['id']}, T{pic['created_turn']}]: {pic['text']}"] if pic else []


def _hosts_on_file(game, scene: dict, roster: list[str], text_in: str, turn_id: int) -> list[str]:
    """The hosts the GM has to tell apart this turn (flag #36 - T120's "rating 3 system cameras" went to the rating-5
    Larkspur host, the only one the GM had to hand): this place's own, any in the scene, the ones its deckers are in
    or were last in, any the players name now (matrix.named_hosts), and any in play lately - in a turn's memory in the
    last HOST_RECENT turns, or put on file then. This place's first; at most HOSTS_SHOWN."""
    from ..engine.rules import matrix
    L = game.ledger
    hosts = {h["id"]: h for h in L.entities(kind="host")}
    if not hosts:
        return []
    loc = scene["location_id"]
    out = [hid for hid, h in hosts.items() if loc and h["props"].get("site") == loc]
    out += [e for e in roster if e in hosts]
    for e in roster:
        st = ((L.get(e) or {}).get("props") or {}).get("matrix") or {}
        out += [x for x in (st.get("host"), st.get("last_host")) if x in hosts]
    out += [h for h in matrix.named_hosts(L, text_in) if h in hosts]
    since = turn_id - matrix.HOST_RECENT
    out += [r[0] for r in game.conn.execute(
        "SELECT m.node_id FROM members m JOIN nodes n ON n.id = m.slice_id WHERE n.kind = 'slice' "
        "AND n.visibility != 'offscreen' AND n.created_turn >= ? ORDER BY n.created_turn DESC", (since,))
        if r[0] in hosts]
    out += [hid for hid, h in sorted(hosts.items(), key=lambda kv: -kv[1]["created_turn"]) if h["created_turn"] >= since]
    return list(dict.fromkeys(out))[:matrix.HOSTS_SHOWN]


def build_packet(game, scene_id: int, inputs: list[tuple[str, str]], turn_id: int) -> tuple[str, set[str]]:
    from ..dm import world                 # (world renders slices with slice_line - import here, not at the top)
    L, S = game.ledger, game.sub
    shown: set[str] = set()
    P = _Printed(game, turn_id, shown)
    scene = L.scene(scene_id)
    roster = L.roster(scene_id)
    presence, total = L.presence_counts()
    ents = [e for e in (L.get(x) for x in roster) if e]
    text_in = " ".join(t for _, t in inputs)
    mentioned = [m for m in game.resolve_mentions(text_in) if m not in roster]
    recent = S.recent_slices(scene_id, RECENT_N)
    recent_ids = {r["id"] for r in recent}

    out = [f"=== SCENE S{scene_id}: {scene['title']} ===", f"Story time: {game.clock_line()}"]
    out += _clock_miss(game, turn_id)
    # the names the table hasn't learned, first - on every turn while any are left (DESIGN.md §12l: the seed's note on
    # its scene reached only that scene's packets, and only while it was among the ten newest notes)
    from ..dm import spoilers
    out += spoilers.packet_lines(game)
    from .. import rulings
    out += rulings.packet_lines(game)
    from .. import narrative
    out += narrative.packet_lines(game)                 # where the table wants the story to go (out of character)
    from ..dm import canon, doubts
    out += canon.packet_lines(game, scene_id)          # the story's reconciled record (the sleep cycle)
    # where the record doesn't add up - before the people it's about, so it's read before anyone speaks (§12k)
    out += doubts.packet_lines(game, turn_id, set(roster) | ({scene["location_id"]} if scene["location_id"] else set()))
    loc = L.get(scene["location_id"]) if scene["location_id"] else None
    if loc:
        g = loc["props"].get("geo") or {}
        out.append(f"Location: {loc['name']} [{loc['id']}]" + (f" ({g['district']})" if g.get("district") else "")
                   + f" - {loc['description']}")
        out += _picture(game, loc["id"], "  ")
        shown.add(loc["id"])
    pcs = [e for e in ents if e["kind"] == "pc"]
    npcs = [e for e in ents if e["kind"] == "npc"]
    other = [e for e in ents if e["kind"] in ("item", "host", "drone", "vehicle", "spirit", "sprite")]

    # ── people: the frame first (who everyone is now, toward each other), then their files ──
    from ..dm import frame
    out += frame.packet_lines(game, scene_id)
    framed_turn, framed = frame.framed_at(game, scene_id)
    out.append("\n=== PRESENT ===")
    for pc in pcs:
        out.append(sr_lite.sheet(L, pc["id"], full=True))
        out += _picture(game, pc["id"], "  ")
        line = _assoc_line(game, pc["id"], presence, total)
        if line:
            out.append("  " + line)
        shown.add(pc["id"])
    for npc in npcs:
        tier = {0: "background", 1: "named", 2: "major"}.get(npc["tier"], "named")
        out.append(f"{npc['name']} [{npc['id']}] - NPC ({tier}, {npc['props'].get('template', 'civilian')})"
                   f" - {npc['description']}")
        out.append("  " + sr_lite.sheet(L, npc["id"], full=False).split("\n", 1)[-1].strip())
        bible = world.persona_line(npc)
        if bible:
            out.append(f"  Persona (GM-only, play them true to it): {bible}")
        out += _picture(game, npc["id"], "  ")
        for row in world.lately(game, npc["id"]):          # what they've been up to while nobody watched
            out.append("  Lately, offscreen: " + P.slice(row))
        line = _assoc_line(game, npc["id"], presence, total)
        if line:
            out.append("  " + line)
        covered = []                       # (the frame has where they stand - an older belief is just its number)
        for who in pcs:                    # feelings toward the PCs in the room (NPC-NPC views: the scene frame)
            belief = S.current_belief(npc["id"], who["id"])
            if belief and npc["id"] in framed and belief["created_turn"] <= framed_turn:
                att = int(L.stat(npc["id"], "attitude:" + who["id"], 0))
                covered.append(f"{who['name']} {att:+d}")
                shown.add(belief["id"])
                continue
            if belief:
                att = int(L.stat(npc["id"], f"attitude:{who['id']}", 0))
                from ..dm.minds import view_attitude
                was = view_attitude(game, belief["id"])
                cooled = f"; time has cooled it from {was:+d}" if was is not None and abs(att) < abs(was) else ""
                out.append(f"  Feels about {who['name']} (attitude {att:+d}{cooled}, [{belief['id']}] since "
                           f"T{belief['created_turn']}): {belief['text']}")
                shown.add(belief["id"])
        if covered:
            out.append(f"  Attitudes (where they stand is in the SCENE FRAME): {', '.join(covered)}")
        older, heard = [], []
        for pc in pcs:
            older += [m for m in S.shared_slices(npc["id"], pc["id"], 6) if m["id"] not in recent_ids]
            heard += [h for h in S.heard_slices(npc["id"], pc["id"], 3) if h["id"] not in recent_ids]
        seen: set[str] = set()
        older = [m for m in sorted(older, key=lambda r: -r["energy"]) if not (m["id"] in seen or seen.add(m["id"]))][:3]
        heard = [h for h in sorted(heard, key=lambda r: -r["energy"]) if not (h["id"] in seen or seen.add(h["id"]))][:2]
        if older or heard:
            out.append(f"  Remembers (earlier, involving the PCs here):")
            for row in older:
                out.append("    " + P.slice(row))
            for row in heard:
                src = L.get(row["source"])["name"] if row.get("source") and L.get(row["source"]) else "someone"
                how = (f"  (not witnessed - rumor that reached them via {src}'s circles; may be garbled)"
                       if row.get("how") == "rumor" else
                       "  (not witnessed - on the line: they heard what was said, saw none of it)"
                       if row.get("how") == "on the line" else f"  (not witnessed - heard it from {src})")
                out.append("    " + P.slice(row, how))
        shown.add(npc["id"])
    for o in other:
        out.append(sr_lite.sheet(L, o["id"], full=o["kind"] in sr_lite.MACHINES or o["kind"] in ("spirit", "sprite")))
        shown.add(o["id"])

    # ── canon and notes about what is here: each printed once ──
    subjects = [e["id"] for e in ents] + ([loc["id"] if loc else None] or [])
    subjects = [s for s in subjects if s]
    carried = [i["id"] for e in pcs + npcs for i in L.holdings(e["id"]) if i["tier"] >= 1]
    facts: dict[str, dict] = {}
    for s in subjects + carried:
        for f in S.facts_for(s, 6):
            facts.setdefault(f["id"], f)
    if facts:
        out.append("\n=== FACTS IN PLAY (canon about who/what is here, hottest first) ===")
        for f in sorted(facts.values(), key=lambda r: -r["energy"])[:10]:
            about = [r["other"] for r in S.links_of(f["id"]) if r["kind"] == "about" and L.get(r["other"])]
            names = ", ".join(L.get(a)["name"] for a in about[:4])
            out.append(f"[{f['id']}] {f['text']}" + (f"  (about {names})" if names else ""))
            shown.add(f["id"])
    notes: dict[str, dict] = {}
    for s in subjects + carried + [f"S{scene_id}"]:
        for n in S.notes_for(s, 6, unfolded=True):
            notes.setdefault(n["id"], n)
    if notes:
        out.append("\n=== YOUR DM NOTES (private; newest first - notes already folded into a Current picture "
                   "aren't repeated) ===")
        for n in sorted(notes.values(), key=lambda r: (-r["created_turn"], r["id"]))[:10]:
            targets = [r["target_id"] for r in game.conn.execute("SELECT target_id FROM annotates WHERE note_id=?",
                                                                 (n["id"],))]
            names = ", ".join((L.get(t) or {}).get("name", t) for t in targets[:4])
            text = n["text"] if len(n["text"]) <= 320 else n["text"][:300].rsplit(" ", 1)[0] + f"... (recall {n['id']})"
            out.append(f"[{n['id']}] (T{n['created_turn']}, on {names}) {text}")

    # ── the Matrix layer: who's jacked in, how deep, how hot ──
    from ..engine.rules import matrix
    from ..engine.rules import resonance
    jacked = [line for e in pcs + npcs                 # (a run the story left behind isn't here: matrix.over)
              for line in matrix.summary_lines(L, e["id"], turn_id) + resonance.summary_lines(L, e["id"])]
    if jacked:
        out.append("\n=== THE MATRIX (cut between this and the room; resolve with the matrix tool) ===")
        out += jacked
    from ..engine.rules import hostmap
    systems = hostmap.site_lines(L, scene["location_id"])
    if systems:
        out.append("\n=== THIS BUILDING'S SYSTEMS (set from the Matrix - play them out in the room) ===")
        out += systems
    hosts = _hosts_on_file(game, scene, roster, text_in, turn_id) if any(
        matrix.deck(L, e["id"])[0] > 0 for e in pcs + npcs) else []
    if hosts:
        out.append("\n=== HOSTS ON FILE (here, or in play lately - the host or device a player names is the one "
                   "their decker goes after; never a harder one they didn't pick) ===")
        out += [matrix.host_line(L, hid, scene["location_id"]) for hid in hosts]

    # ── magic: what's being held up, who's in the astral, whose spirits are here ──
    from ..engine.rules import magic
    arcane = [line for e in pcs + npcs for line in magic.summary_lines(L, e["id"])]
    if arcane:
        out.append("\n=== MAGIC (sustained spells, the astral, bound spirits) ===")
        out += arcane

    # ── the story's open questions, most neglected first ──
    from .. import jobs
    from ..dm import tensions
    out += jobs.packet_lines(game)
    out += tensions.packet_lines(game)
    from .. import shops
    out += shops.packet_lines(game, loc["id"] if loc else None, scene_id)   # (and remote dealers listed here)
    from .. import encounters
    fight = encounters.active(game, scene_id)
    if fight:
        out += encounters.packet_lines(game, fight)

    # ── the offscreen world touching who/what is here ──
    out += world.section(game, set(subjects + carried), turn_id, shown)

    # ── geography: the engine does the math ──
    here = geo.geo_of(game, loc["id"]) if loc else None
    if here:
        places = [m for m in mentioned if (L.get(m) or {}).get("kind") == "location"] + geo.districts_in(text_in)
        places += [s["location_id"] for s in reversed(L.scenes()) if s["location_id"] and s["location_id"] != loc["id"]]
        places += [r["id"] for r in game.conn.execute(
            "SELECT e.id FROM entities e JOIN energy en ON en.node_id=e.id WHERE e.kind='location' AND e.id<>? "
            "ORDER BY en.energy DESC LIMIT 6", (loc["id"],))]
        lines = geo.where_lines(game, here, places, 8)
        if lines:
            out.append("\n=== WHERE THINGS ARE (from here, measured by the engine - how far, not how long) ===")
            out += lines

    # ── named but elsewhere ──
    if mentioned:
        out.append("\n=== MENTIONED BUT NOT HERE ===")
        for eid in mentioned:
            e = L.get(eid)
            if not e:
                continue
            where = L.scene_of(eid)
            out.append(f"{e['name']} [{eid}] ({e['kind']}) - {e['description']}"
                       + (f" Last seen in S{where}." if where else ""))
            for f in S.facts_for(eid, 2):
                if f["id"] not in facts:
                    out.append(f"  Fact [{f['id']}]: {f['text']}")
                    shown.add(f["id"])
            out += _picture(game, eid, "  ")
            for n in S.notes_for(eid, 2, unfolded=True):
                if n["id"] not in notes:
                    out.append(f"  DM note [{n['id']}] (T{n['created_turn']}): {n['text']}")
            for pc in pcs:
                for row in S.shared_slices(pc["id"], eid, 2):
                    if row["id"] not in recent_ids and row["id"] not in P.full:
                        out.append(f"  With {pc['name']}: " + P.slice(row))
            shown.add(eid)

    # ── the spine ──
    out.append("\n=== RECENTLY (this scene, oldest first) ===")
    if len(recent) < 3:
        prev = game.conn.execute("SELECT prev_id FROM spine WHERE next_id=? AND kind='scene'",
                                 (f"S{scene_id}",)).fetchone()
        if prev:
            pnode = S.node(prev["prev_id"])
            if pnode:
                out.append(f"Previous scene [{pnode['id']}]: {pnode['text']}")
                shown.add(pnode["id"])
                for row in S.recent_slices(int(pnode["id"][1:]), 3 - len(recent)):
                    out.append(P.slice(row))
    for row in recent:
        out.append(P.slice(row))
    if not recent:
        out.append("(nothing yet in this scene)")
    last = L.last_turn(scene_id, before=turn_id, public=True)      # whispers aren't the table's story
    if last and last["narration"]:
        out.append(f"\nYour last narration, verbatim (for continuity of voice):\n{last['narration'][:2500]}")

    seeds = roster + mentioned
    hot = S.hot_neighbors(seeds, exclude=shown | set(seeds), limit=6)
    if hot:
        out.append("\n=== ASSOCIATED MEMORIES (linked to who/what is here, hottest first) ===")
        for row in hot:
            if row["kind"] == "slice":
                out.append(P.slice(row))
            else:
                out.append(f"[{row['id']}] ({row['kind']}, {_heat(game, row['energy'])}) {row['text']}")
                shown.add(row["id"])
    return "\n".join(out), shown
