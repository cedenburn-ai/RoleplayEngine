"""Energy propagation - a port of the Orchard's SubstratePhysics.kt (lakes and rivers).

  1. DEPOSIT      a touch deposits touch_quantum x mean into the origin; every node reached
                  by propagation deposits 100% of what arrives.
  2. PROPAGATION  after depositing, a node forwards propagation_share (1/2) of what it
                  received, divided among its links proportional to strength (normalized
                  at the source).
  3. TERMINATION  a packet stops after depositing when it is < negligibility_fraction x the
                  receiver's pre-deposit energy; shares below the floor (x mean) never form.
  4. CYCLES       no forward clip - halving bounds every cascade at <= 2x the deposit.
  5. STRENGTH     (game change) traversal does NOT carve strength unless knobs.traversal_carves.
                  In the game, strength is carved by shared scenes and recall (DESIGN.md §8).
  6. DIODE        a superseded node passes its FULL arrival forward to its replacement and keeps
                  half for itself (Orchard ruling [29]: the old starves gracefully, every touch of
                  the past reinforces what replaced it). One hop per arrow per propagation.

Arrivals aggregate per node per wave (Orchard I-16). Works on an in-memory graph so a
whole turn's touches cost a handful of dict operations; the store writes results back.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass
class PropagationStats:
    origins: int = 0
    nodes_deposited: int = 0
    energy_minted: float = 0.0
    links_traversed: int = 0
    waves: int = 0
    deposit: float = 0.0        # the origins' quanta summed - each at the mean it met (I-5), what the 2x rule measures


class EnergyGraph:
    def __init__(self, energy: dict[str, float], links: list[tuple[int, str, str, float]],
                 arrows: dict[str, str] | None = None):
        self.arrows = dict(arrows or {})                       # superseded -> replacement (diode)
        self.diode_hops = 0
        self.energy = dict(energy)
        self.total = sum(self.energy.values())
        self.count = len(self.energy)
        self.adj: dict[str, list[list]] = defaultdict(list)    # node -> [[link_id, other, strength]]
        self._entries: dict[int, list[list]] = defaultdict(list)
        for lid, a, b, s in links:
            ea, eb = [lid, b, s], [lid, a, s]
            self.adj[a].append(ea)
            self.adj[b].append(eb)
            self._entries[lid] += [ea, eb]
        self.touched: dict[str, int] = defaultdict(int)
        self.carved: dict[int, float] = defaultdict(float)
        self.deposited: dict[str, float] = defaultdict(float)

    def mean(self) -> float | None:
        return self.total / self.count if self.count else None

    def deposit(self, node: str, amount: float, counts_as_touch: bool) -> None:
        self.energy[node] += amount
        self.total += amount
        self.deposited[node] += amount
        if counts_as_touch:
            self.touched[node] += 1

    def carve(self, link_id: int) -> None:
        for entry in self._entries.get(link_id, ()):
            entry[2] += 1.0
        self.carved[link_id] += 1.0


def touch_all(graph: EnergyGraph, knobs, origins, quantum_ratio: float = 1.0,
              counts_as_touch: bool = True) -> PropagationStats:
    """Touch each origin with quantum = mean x touch_quantum x quantum_ratio.
    The mean is re-read per origin (Orchard I-5): deposits shift it mid-batch."""
    stats = PropagationStats()
    for origin in dict.fromkeys(origins):          # dedupe, keep order
        if origin not in graph.energy:
            continue
        mean = graph.mean()
        if not mean:
            continue
        quantum = mean * knobs.touch_quantum * quantum_ratio
        if quantum <= 0:
            continue
        stats.origins += 1
        stats.deposit += quantum
        _propagate(graph, knobs, origin, quantum, mean * knobs.propagation_floor_ratio, stats, counts_as_touch)
    return stats


def _propagate(graph: EnergyGraph, knobs, origin: str, quantum: float, floor: float,
               stats: PropagationStats, counts_as_touch: bool) -> None:
    frontier: dict[str, float] = {origin: quantum}
    first_wave = True
    wave = 0
    arrows_taken: set[str] = set()
    while frontier and wave < knobs.wave_cap:
        nxt: dict[str, float] = defaultdict(float)
        deposits: list[tuple[str, float]] = []
        flows: dict[int, float] = defaultdict(float)
        for node, amount in frontier.items():
            snap = graph.energy.get(node)
            if snap is None:
                continue
            target = graph.arrows.get(node)                       # Rule 6: the diode
            if target and target in graph.energy and node not in arrows_taken:
                arrows_taken.add(node)
                nxt[target] += amount                             # full arrival rides forward
                amount *= 0.5                                     # the old keeps half
                graph.diode_hops += 1
            deposits.append((node, amount))                       # Rule 1
            stats.nodes_deposited += 1
            stats.energy_minted += amount
            if amount < knobs.negligibility_fraction * snap:      # Rule 3
                continue
            links = graph.adj.get(node, ())
            total = sum(e[2] for e in links)
            if total <= 0:
                continue
            forward = amount * knobs.propagation_share            # Rule 2
            for lid, other, strength in links:
                share = forward * (strength / total)
                if share <= 0 or share < floor or other not in graph.energy:
                    continue
                nxt[other] += share
                flows[lid] += share
        for node, amount in deposits:                             # the wave commits together
            graph.deposit(node, amount, first_wave and counts_as_touch)
        stats.links_traversed += len(flows)
        if knobs.traversal_carves:                                # Rule 5 (optional in the game)
            for lid in flows:
                graph.carve(lid)
        frontier = nxt
        first_wave = False
        wave += 1
    stats.waves = max(stats.waves, wave)
