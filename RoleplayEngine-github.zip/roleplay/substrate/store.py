"""The memory substrate: nodes, energy, links, the time-slice spine, facts and DM notes.

Ids carry their kind: entity slugs (lowercase), T<turn> slices, S<scene> scenes,
F<n> canon facts, N<n> DM notes, C<n> clarifications (the GM's current picture of a node, folding
the notes before it), Q<n> tensions, X<n> doubts (where the record doesn't add up - dm/doubts.py).
"""
from __future__ import annotations

import re
import sqlite3
from typing import Iterable

from ..config import Knobs
from .physics import EnergyGraph, PropagationStats, touch_all

SLICE_RE = re.compile(r"^[tsfnbwahcqx]\d+$", re.IGNORECASE)


def norm_id(ref: str) -> str:
    """Models sometimes lowercase T12 -> t12; reserved ids are uppercase."""
    ref = ref.strip().strip("[]")
    return ref.upper() if SLICE_RE.match(ref) else ref


# ── search words (DESIGN.md §8d) ────────────────────────────────────────
# Live: Bo, the boy the whole Low Wharf storyline turns on, was unsearchable - words under three letters were
# dropped - and a bare substring match would find him in "about" and "body". A two-letter word is kept when the query
# capitalises it (a name) or it is an id (F4, Q3), and short words match whole words only.
_TERM = re.compile(r"\d{1,3}(?:,\d{3})+|[A-Za-z0-9]+(?:['’][A-Za-z]+)?")   # (a sum stays one word: "2,410")
_STOP = frozenset("the and for with was were are who what when where why how did does has had have that this they "
                  "them their his her she him from about into onto not but any its our your you can".split())
_STOP2 = frozenset("is it if in on at to of we my no so or an as by do go me up us he be am oh ok".split())
SEARCH_WORDS = 8


def search_terms(query: str) -> list[str]:
    """The words a search looks for, lowercased: three letters and up (not the commonest), a capitalised two-letter
    word (a name: 'Bo'), or an id ('F45'). A possessive is its name ("Juno's" -> juno); hyphens split ('KD-4')."""
    out: list[str] = []
    for raw in _TERM.findall(query or ""):
        w = re.sub(r"['’]s$", "", raw)
        low = w.lower()
        keep = (len(low) >= 3 and low not in _STOP) or bool(SLICE_RE.match(w)) or (
            len(w) == 2 and w[0].isupper() and low not in _STOP2)
        if keep and low not in out:
            out.append(low)
    return out[:SEARCH_WORDS]


def term_re(term: str) -> re.Pattern:
    """Where a search word matches: an id as a whole word ('f4' not in 'f45'), a short word as a whole word or its
    plural ('bo' not in 'about' or 'boring'; 'ork' finds 'orks', 'cop' 'cops' - review 2026-10-26: the whole-word rule
    had cost every three-letter word its plural, which the old substring search found), a longer one at the start of a
    word ('negotiat' finds 'negotiation'; 'ash' isn't in 'flash')."""
    if SLICE_RE.match(term):
        tail = r"(?![a-z0-9])"
    elif len(term) <= 3:
        tail = r"(?:e?s)?(?![a-z0-9])"
    else:
        tail = ""
    return re.compile(rf"(?<![a-z0-9]){re.escape(term)}{tail}", re.IGNORECASE)


# What search_memory's kinds filter names (the GM's words), as SQL over nodes n.
SEARCH_KINDS = {
    "turn": "(n.kind='slice' AND n.visibility<>'offscreen')", "offscreen": "(n.kind='slice' AND n.visibility='offscreen')",
    "scene": "n.kind='scene'", "fact": "n.kind='fact'", "note": "n.kind='note'", "picture": "n.kind='clarification'",
    "belief": "n.kind='belief'", "agenda": "n.kind='agenda'", "hook": "n.kind='hook'", "tension": "n.kind='tension'",
    "doubt": "n.kind='doubt'", "entity": "n.kind='entity'"}


class Substrate:
    recorder = None     # the per-turn graph log's (graphlog.Recorder): Game attaches it; None costs nothing

    def __init__(self, conn: sqlite3.Connection, knobs: Knobs):
        self.conn = conn
        self.knobs = knobs

    # ── energy ──────────────────────────────────────────────────────────
    def system_mean(self) -> float | None:
        row = self.conn.execute("SELECT AVG(energy) AS m FROM energy").fetchone()
        return row["m"]

    def born_energy(self) -> float:
        m = self.system_mean()
        return m if m else self.knobs.bootstrap_energy     # born at the mean (Orchard D7)

    def energy_of(self, nid: str) -> float:
        row = self.conn.execute("SELECT energy FROM energy WHERE node_id=?", (nid,)).fetchone()
        return row["energy"] if row else 0.0

    def ratio(self, nid: str) -> float:
        m = self.system_mean() or 1.0
        return self.energy_of(nid) / m

    # ── nodes ───────────────────────────────────────────────────────────
    def node(self, nid: str) -> dict | None:
        row = self.conn.execute("SELECT * FROM nodes WHERE id=?", (norm_id(nid),)).fetchone()
        return dict(row) if row else None

    def exists(self, nid: str) -> bool:
        return self.node(nid) is not None

    def create_node(self, nid: str, kind: str, text: str, turn: int, scene_id: int | None = None,
                    visibility: str = "public", citizen: bool = True) -> str:
        if self.exists(nid):
            return nid
        energy = self.born_energy()
        self.conn.execute("INSERT INTO nodes(id, kind, text, created_turn, scene_id, visibility) VALUES(?,?,?,?,?,?)",
                          (nid, kind, text, turn, scene_id, visibility))
        if citizen:
            self.conn.execute("INSERT INTO energy(node_id, energy, touch_count, last_touched_turn) VALUES(?,?,0,?)",
                              (nid, energy, turn))
        return nid

    def set_text(self, nid: str, text: str) -> None:
        self.conn.execute("UPDATE nodes SET text=? WHERE id=?", (text, nid))

    def ensure_entity(self, ent: dict, turn: int) -> str:
        text = f"{ent['name']} ({ent['kind']})" + (f": {ent['description']}" if ent.get("description") else "")
        if self.exists(ent["id"]):
            self.set_text(ent["id"], text)
        else:
            self.create_node(ent["id"], "entity", text, turn)
        return ent["id"]

    def _next(self, prefix: str) -> str:
        key = f"seq_{prefix}"
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        n = int(row["value"]) + 1 if row else 1
        self.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?,?)", (key, str(n)))
        return f"{prefix}{n}"

    # ── links ───────────────────────────────────────────────────────────
    def link(self, a: str, b: str, kind: str, strength: float, turn: int, together: int = 0) -> None:
        if a == b:
            return
        a, b = sorted((a, b))
        row = self.conn.execute("SELECT id FROM links WHERE a=? AND b=?", (a, b)).fetchone()
        if row:
            self.conn.execute("UPDATE links SET strength=strength+?, together=together+?, last_turn=? WHERE id=?",
                              (strength, together, turn, row["id"]))
        else:
            self.conn.execute("INSERT INTO links(a, b, kind, strength, together, last_turn) VALUES(?,?,?,?,?,?)",
                              (a, b, kind, strength, together, turn))

    def links_of(self, nid: str) -> list[dict]:
        out = []
        for r in self.conn.execute("SELECT * FROM links WHERE a=? OR b=?", (nid, nid)):
            d = dict(r)
            d["other"] = r["b"] if r["a"] == nid else r["a"]
            out.append(d)
        return out

    def mark_copresence(self, new_ids: Iterable[str], prior_ids: Iterable[str], turn: int) -> int:
        """Your rule: two entities sharing a scene get +1 (once per scene)."""
        new_ids, prior = list(new_ids), list(prior_ids)
        pairs = 0
        for i, a in enumerate(new_ids):
            for b in prior + new_ids[i + 1:]:
                if a != b:
                    self.link(a, b, "assoc", 1.0, turn, together=1)
                    pairs += 1
        return pairs

    # ── touches ─────────────────────────────────────────────────────────
    def touch(self, origins: Iterable[str], turn: int, quantum_ratio: float = 1.0,
              counts_as_touch: bool = True) -> PropagationStats:
        origins = [norm_id(o) for o in origins]
        energy = {r["node_id"]: r["energy"] for r in self.conn.execute("SELECT node_id, energy FROM energy")}
        links = [(r["id"], r["a"], r["b"], r["strength"]) for r in
                 self.conn.execute("SELECT id, a, b, strength FROM links")]
        arrows = {r["old_id"]: r["new_id"] for r in self.conn.execute(
            "SELECT old_id, new_id FROM supersedes ORDER BY confidence ASC")}   # highest confidence wins
        graph = EnergyGraph(energy, links, arrows)
        stats = touch_all(graph, self.knobs, origins, quantum_ratio, counts_as_touch)
        for nid, added in graph.deposited.items():
            self.conn.execute("UPDATE energy SET energy=energy+? WHERE node_id=?", (added, nid))
        for nid, n in graph.touched.items():
            self.conn.execute("UPDATE energy SET touch_count=touch_count+?, last_touched_turn=? WHERE node_id=?",
                              (n, turn, nid))
        for lid, add in graph.carved.items():
            self.conn.execute("UPDATE links SET strength=strength+? WHERE id=?", (add, lid))
        if self.recorder is not None:                # the graph log: every deposit, and who touched (graphlog/)
            self.recorder.touched(origins, turn, quantum_ratio, counts_as_touch, graph, stats)
        return stats

    def renormalize(self) -> None:
        """Divide every energy by the mean: ratios preserved, mean -> 1 (V5 spec sleep renorm)."""
        m = self.system_mean()
        if m and m > 0:
            self.conn.execute("UPDATE energy SET energy = energy / ?", (m,))
            if self.recorder is not None:
                self.recorder.renormalized(m)

    def log_mean(self, turn: int) -> None:
        r = self.conn.execute("SELECT AVG(energy) AS m, SUM(energy) AS t, COUNT(*) AS n FROM energy").fetchone()
        links = self.conn.execute("SELECT COUNT(*) AS n FROM links").fetchone()["n"]
        self.conn.execute("INSERT INTO mean_log(turn, mean, total, nodes, links) VALUES(?,?,?,?,?)",
                          (turn, r["m"], r["t"], r["n"], links))

    def observe(self, turn: int) -> dict:
        """Record every citizen's heat for this turn and summarize the distribution - the
        warm-set instrumentation from the V5 spec §7: stable population, empty, or one lump?"""
        rows = self.conn.execute("SELECT node_id, energy FROM energy").fetchall()
        if not rows:
            return {"nodes": 0, "links": 0, "mean": 0, "warm": 0, "hot": 0, "gini": 0, "top5_share": 0}
        energies = sorted((r["energy"] for r in rows), reverse=True)
        total = sum(energies)
        mean = total / len(energies)
        self.conn.execute("DELETE FROM energy_history WHERE turn=?", (turn,))
        self.conn.executemany("INSERT INTO energy_history(turn, node_id, ratio) VALUES(?,?,?)",
                              [(turn, r["node_id"], r["energy"] / mean) for r in rows])
        asc = energies[::-1]
        n = len(asc)
        gini = (2 * sum((i + 1) * e for i, e in enumerate(asc)) / (n * total) - (n + 1) / n) if total else 0.0
        links = self.conn.execute("SELECT COUNT(*) AS n FROM links").fetchone()["n"]
        self.log_mean(turn)
        return {"nodes": n, "links": links, "mean": mean,
                "warm": sum(1 for e in energies if e >= mean),
                "hot": sum(1 for e in energies if e >= 2 * mean),
                "gini": gini, "top5_share": sum(energies[:5]) / total if total else 0.0}

    # ── scenes and slices ───────────────────────────────────────────────
    def ensure_scene(self, scene_id: int, title: str, turn: int, prev_scene_id: int | None = None) -> str:
        sid = f"S{scene_id}"
        if not self.exists(sid):
            self.create_node(sid, "scene", f"Scene: {title}", turn, scene_id=scene_id)
            if prev_scene_id and self.exists(f"S{prev_scene_id}"):
                self.conn.execute("INSERT OR IGNORE INTO spine(prev_id, next_id, kind) VALUES(?,?,'scene')",
                                  (f"S{prev_scene_id}", sid))
                self.link(f"S{prev_scene_id}", sid, "spine", self.knobs.spine_strength, turn)
        return sid

    def last_slice(self, scene_id: int, before_turn: int | None = None) -> str | None:
        sql = "SELECT id FROM nodes WHERE kind='slice' AND scene_id=?"
        args: list = [scene_id]
        if before_turn is not None:
            sql += " AND created_turn<?"
            args.append(before_turn)
        row = self.conn.execute(sql + " ORDER BY created_turn DESC LIMIT 1", args).fetchone()
        return row["id"] if row else None

    def write_slice(self, turn_id: int, scene_id: int, summary: str, members: list[tuple[str, str]],
                    recalled: Iterable[str], story_time: int | None = None) -> str:
        """The turn's time-slice node: linked to everyone in it, chained to the previous slice."""
        tid = f"T{turn_id}"
        prev = self.last_slice(scene_id, before_turn=turn_id)
        self.create_node(tid, "slice", summary, turn_id, scene_id=scene_id)
        if story_time is not None:
            self.conn.execute("UPDATE nodes SET story_time=? WHERE id=?", (story_time, tid))
        for nid, role in members:
            if not self.exists(nid):
                continue
            self.conn.execute("INSERT OR IGNORE INTO members(slice_id, node_id, role) VALUES(?,?,?)", (tid, nid, role))
            self.link(tid, nid, "member", self.knobs.role_strength.get(role, 1.0), turn_id)
        if prev:
            self.conn.execute("INSERT OR IGNORE INTO spine(prev_id, next_id, kind) VALUES(?,?,'slice')", (prev, tid))
            self.link(prev, tid, "spine", self.knobs.spine_strength, turn_id)
        scene_node = f"S{scene_id}"
        if self.exists(scene_node):
            self.link(scene_node, tid, "contains", self.knobs.spine_strength, turn_id)
        for rid in recalled:
            rid = norm_id(rid)
            if rid != tid and self.exists(rid):
                self.conn.execute("INSERT OR IGNORE INTO members(slice_id, node_id, role) VALUES(?,?,'recalled')",
                                  (tid, rid))
                self.link(tid, rid, "recall", self.knobs.recall_strength, turn_id)
        return tid

    def write_offscreen(self, turn_id: int, text: str, members: list[tuple[str, str]],
                        agenda_id: str | None = None, story_time: int | None = None) -> str:
        """An offscreen event (W#): a time slice on the world spine, witnessed only by its members -
        no PC saw it. It hangs off the agenda it advanced, so the chain of what an NPC did stays whole."""
        prev = self.conn.execute("SELECT id FROM nodes WHERE kind='slice' AND visibility='offscreen' "
                                 "ORDER BY created_turn DESC, rowid DESC LIMIT 1").fetchone()
        wid = self._next("W")
        self.create_node(wid, "slice", text, turn_id, visibility="offscreen")
        if story_time is not None:
            self.conn.execute("UPDATE nodes SET story_time=? WHERE id=?", (story_time, wid))
        for nid, role in members:
            if not self.exists(nid):
                continue
            self.conn.execute("INSERT OR IGNORE INTO members(slice_id, node_id, role) VALUES(?,?,?)", (wid, nid, role))
            self.link(wid, nid, "member", self.knobs.role_strength.get(role, 1.0), turn_id)
        if prev:
            self.conn.execute("INSERT OR IGNORE INTO spine(prev_id, next_id, kind) VALUES(?,?,'world')", (prev["id"], wid))
            self.link(prev["id"], wid, "spine", self.knobs.spine_strength, turn_id)
        if agenda_id and self.exists(agenda_id):
            self.link(wid, agenda_id, "step", 1.0, turn_id)
        return wid

    def set_visibility(self, nid: str, visibility: str) -> None:
        self.conn.execute("UPDATE nodes SET visibility=? WHERE id=?", (visibility, norm_id(nid)))

    def members_of(self, slice_id: str) -> list[tuple[str, str]]:
        return [(r["node_id"], r["role"]) for r in
                self.conn.execute("SELECT node_id, role FROM members WHERE slice_id=?", (norm_id(slice_id),))]

    def recent_slices(self, scene_id: int, limit: int = 5) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE kind='slice' AND scene_id=? ORDER BY created_turn DESC LIMIT ?",
            (scene_id, limit)).fetchall()
        return [dict(r) for r in reversed(rows)]

    def shared_slices(self, witness: str, other: str, limit: int = 3) -> list[dict]:
        """Slices `witness` saw first-hand that also involve `other`, hottest first."""
        roles = self.knobs.witness_roles
        q = (f"SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id "
             f"WHERE n.kind='slice' AND n.id IN (SELECT slice_id FROM members WHERE node_id=? AND role IN "
             f"({','.join('?' * len(roles))})) AND n.id IN (SELECT slice_id FROM members WHERE node_id=?) "
             f"ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (witness, *roles, other, limit))]

    def witnessed_slices(self, eid: str, limit: int = 50) -> list[dict]:
        roles = self.knobs.witness_roles
        q = (f"SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.kind='slice' AND n.id IN "
             f"(SELECT slice_id FROM members WHERE node_id=? AND role IN ({','.join('?' * len(roles))})) "
             f"ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (eid, *roles, limit))]

    # ── associations ────────────────────────────────────────────────────
    def associations(self, eid: str, presence: dict[str, int], total_scenes: int, limit: int = 4) -> list[dict]:
        """Entities that share scenes with `eid`, ranked by lift (how much more often than chance)
        so the PCs and the bar - which are in everything - don't drown out the telling links."""
        out = []
        for link in self.links_of(eid):
            if link["kind"] != "assoc" or link["together"] <= 0:
                continue
            o = link["other"]
            pa, pb = presence.get(eid, 0), presence.get(o, 0)
            lift = (link["together"] * total_scenes / (pa * pb)) if pa and pb and total_scenes else 0.0
            out.append({"id": o, "together": link["together"], "lift": lift})
        out.sort(key=lambda d: (d["lift"], d["together"]), reverse=True)
        return out[:limit]

    def hot_neighbors(self, seeds: Iterable[str], exclude: set[str], kinds=("slice", "fact"),
                      limit: int = 5) -> list[dict]:
        """Energy-ranked nodes one hop from the seeds (the Band-B 'still on everyone's mind')."""
        cand: set[str] = set()
        for s in seeds:
            for link in self.links_of(s):
                if link["other"] not in exclude:
                    cand.add(link["other"])
        if not cand:
            return []
        q = (f"SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.id IN "
             f"({','.join('?' * len(cand))}) AND n.kind IN ({','.join('?' * len(kinds))}) "
             f"ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (*cand, *kinds, limit))]

    # ── the diode (supersession) ────────────────────────────────────────
    def superseded_by(self, nid: str) -> str | None:
        row = self.conn.execute("SELECT new_id FROM supersedes WHERE old_id=? ORDER BY confidence DESC LIMIT 1",
                                (nid,)).fetchone()
        return row["new_id"] if row else None

    def newest(self, nid: str) -> str | None:
        """The end of nid's supersession chain - the current version - or None when nothing replaced it."""
        cur, seen = nid, {nid}
        while True:
            nxt = self.superseded_by(cur)
            if not nxt or nxt in seen:
                return cur if cur != nid else None
            seen.add(nxt)
            cur = nxt

    def replaced(self, nid: str) -> list[str]:
        """What nid superseded (the diode's old ends), oldest first."""
        return [r["old_id"] for r in self.conn.execute("SELECT old_id FROM supersedes WHERE new_id=? ORDER BY turn",
                                                       (norm_id(nid),))]

    def supersede(self, old: str, new: str, confidence: float, by: str, turn: int) -> str:
        """Port of the Orchard DiodeInstaller gates. Inference nominates; this adjudicates.
        >= high: install the arrow.  mid..high: both stay live, fit decides.  floor..mid: too
        weak, logged.  < floor (or a cycle): no arrow - the contest becomes a DM note."""
        old, new = norm_id(old), norm_id(new)
        if old == new or not self.exists(old) or not self.exists(new):
            return "invalid"
        k = self.knobs
        if self.conn.execute("SELECT 1 FROM supersedes WHERE old_id=? AND new_id=?", (old, new)).fetchone():
            return "duplicate"
        if confidence < k.diode_c_floor or self._reaches(new, old):
            self.add_note([old, new], f"Contested: [{new}] was nominated to replace [{old}] "
                                      f"(confidence {confidence:.2f}{', would form a cycle' if self._reaches(new, old) else ''}). "
                                      "Both stand until play settles it.", turn)
            return "contested"
        if confidence < k.diode_c_mid:
            return "too_weak"
        if confidence < k.diode_c_high:
            return "both_live"
        self.conn.execute("INSERT INTO supersedes(old_id, new_id, confidence, installed_by, turn) VALUES(?,?,?,?,?)",
                          (old, new, confidence, by, turn))
        self.link(old, new, "diode", 1.0, turn)
        return "installed"

    def _reaches(self, start: str, goal: str) -> bool:
        seen, frontier = set(), [start]
        while frontier:
            nxt = []
            for n in frontier:
                for r in self.conn.execute("SELECT new_id FROM supersedes WHERE old_id=?", (n,)):
                    if r["new_id"] == goal:
                        return True
                    if r["new_id"] not in seen:
                        seen.add(r["new_id"])
                        nxt.append(r["new_id"])
            frontier = nxt
        return False

    # ── facts (canon) ───────────────────────────────────────────────────
    def add_fact(self, text: str, about: Iterable[str], turn: int, slice_id: str | None = None,
                 replaces: str | None = None, confidence: float = 0.9, by: str = "commit") -> str:
        fid = self._next("F")
        self.create_node(fid, "fact", text, turn)
        for eid in about:
            if self.exists(eid):
                self.link(fid, eid, "about", 1.0, turn)
        if slice_id and self.exists(slice_id):
            self.link(fid, slice_id, "about", 1.0, turn)
        if replaces and self.exists(norm_id(replaces)) and norm_id(replaces).startswith("F"):
            self.supersede(replaces, fid, confidence, by, turn)
        return fid

    def facts_for(self, eid: str, limit: int = 5, include_superseded: bool = False) -> list[dict]:
        live = "" if include_superseded else " AND n.id NOT IN (SELECT old_id FROM supersedes)"
        q = ("SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.kind='fact' AND n.id IN "
             "(SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='about')"
             f"{live} ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (eid, eid, eid, limit))]

    # ── hearsay ─────────────────────────────────────────────────────────
    def add_knows(self, holder: str, node: str, how: str, source: str | None, turn: int) -> bool:
        node = norm_id(node)
        if not (self.exists(holder) and self.exists(node)):
            return False
        cur = self.conn.execute("INSERT OR IGNORE INTO knows(holder, node_id, how, source, turn) VALUES(?,?,?,?,?)",
                                (holder, node, how, source, turn))
        if cur.rowcount:
            self.link(holder, node, "knows", 0.5, turn)
        return bool(cur.rowcount)

    def heard_slices(self, holder: str, other: str, limit: int = 2) -> list[dict]:
        """Slices `holder` was told about (not witnessed) that involve `other`."""
        q = ("SELECT n.*, e.energy, k.how, k.source FROM knows k JOIN nodes n ON n.id=k.node_id "
             "JOIN energy e ON e.node_id=n.id WHERE k.holder=? AND n.kind='slice' AND n.id IN "
             "(SELECT slice_id FROM members WHERE node_id=?) ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (holder, other, limit))]

    def heard(self, holder: str, limit: int = 4) -> list[dict]:
        q = ("SELECT n.*, COALESCE(e.energy,0) AS energy, k.how, k.source, k.turn AS heard_turn FROM knows k "
             "JOIN nodes n ON n.id=k.node_id LEFT JOIN energy e ON e.node_id=n.id WHERE k.holder=? "
             "ORDER BY k.turn DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (holder, limit))]

    # ── NPC beliefs (minds) ─────────────────────────────────────────────
    def current_belief(self, holder: str, about: str) -> dict | None:
        q = ("SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.kind='belief' "
             "AND n.id IN (SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='holds') "
             "AND n.id IN (SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='about') "
             "AND n.id NOT IN (SELECT old_id FROM supersedes) ORDER BY n.created_turn DESC LIMIT 1")
        row = self.conn.execute(q, (holder,) * 3 + (about,) * 3).fetchone()
        return dict(row) if row else None

    def beliefs_of(self, holder: str) -> list[dict]:
        q = ("SELECT n.*, e.energy FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.kind='belief' "
             "AND n.id IN (SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND kind='holds') "
             "AND n.id NOT IN (SELECT old_id FROM supersedes) ORDER BY n.created_turn DESC")
        return [dict(r) for r in self.conn.execute(q, (holder,) * 3)]

    def add_belief(self, holder: str, about: str, text: str, turn: int, scene_id: int | None = None,
                   story_time: int | None = None) -> str:
        """A new belief supersedes the holder's previous belief about the same subject (a diode),
        so the history of how an NPC's view changed stays in the chain."""
        prev = self.current_belief(holder, about)
        bid = self._next("B")
        self.create_node(bid, "belief", text, turn, scene_id=scene_id, visibility="gm")
        if story_time is not None:                      # (when the view was formed: time apart cools it - minds.cool)
            self.conn.execute("UPDATE nodes SET story_time=? WHERE id=?", (story_time, bid))
        self.link(bid, holder, "holds", 1.0, turn)
        self.link(bid, about, "about", 1.0, turn)
        if prev:
            self.supersede(prev["id"], bid, 0.9, "reflection", turn)
        return bid

    # ── DM notes (clarification nodes) ──────────────────────────────────
    def add_note(self, targets: Iterable[str], text: str, turn: int) -> str:
        """Notes ride their targets: no energy of their own, never adjudicated, GM-only."""
        nid = self._next("N")
        self.create_node(nid, "note", text, turn, visibility="gm", citizen=False)
        for t in targets:
            self.conn.execute("INSERT OR IGNORE INTO annotates(note_id, target_id) VALUES(?,?)", (nid, norm_id(t)))
        return nid

    def notes_for(self, target: str, limit: int = 5, unfolded: bool = False) -> list[dict]:
        """Newest first. unfolded=True: only notes newer than the target's current clarification."""
        target = norm_id(target)
        upto = (self.clarification(target) or {}).get("upto_note", 0) if unfolded else 0
        q = ("SELECT n.* FROM nodes n JOIN annotates a ON a.note_id=n.id WHERE a.target_id=? AND n.kind='note' "
             "AND CAST(substr(n.id, 2) AS INTEGER) > ? ORDER BY n.created_turn DESC, n.id DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (target, upto, limit))]

    # ── clarifications: the GM's current picture of a node ──────────────
    def clarification(self, target: str) -> dict | None:
        row = self.conn.execute(
            "SELECT c.*, n.text FROM clarifications c JOIN nodes n ON n.id=c.id WHERE c.target_id=? "
            "AND c.status='current' ORDER BY c.created_turn DESC, c.id DESC LIMIT 1", (norm_id(target),)).fetchone()
        return dict(row) if row else None

    def clarify(self, target: str, text: str, turn: int, by: str = "dm") -> str:
        """Write the current picture of a node. It folds every note on the target written so far and
        supersedes the previous picture (the diode keeps the history: old -> new)."""
        target = norm_id(target)
        old = self.clarification(target)
        upto = int((self.conn.execute("SELECT value FROM meta WHERE key='seq_N'").fetchone() or {"value": 0})["value"])
        cid = self._next("C")
        self.create_node(cid, "clarification", text, turn, visibility="gm", citizen=False)
        self.conn.execute("INSERT INTO clarifications(id, target_id, upto_note, created_turn, by) VALUES(?,?,?,?,?)",
                          (cid, target, upto, turn, by))
        self.conn.execute("INSERT OR IGNORE INTO annotates(note_id, target_id) VALUES(?,?)", (cid, target))
        if old:
            self.conn.execute("UPDATE clarifications SET status='superseded' WHERE id=?", (old["id"],))
            self.conn.execute("INSERT OR IGNORE INTO supersedes(old_id, new_id, confidence, installed_by, turn) "
                              "VALUES(?,?,?,?,?)", (old["id"], cid, 1.0, by, turn))
        return cid

    # ── search ──────────────────────────────────────────────────────────
    def search(self, query: str, limit: int | None = 8, include_gm: bool = True, kinds=None, about=None,
               from_turn: int | None = None, to_turn: int | None = None) -> list[dict]:
        """Nodes matching the query's words (search_terms), every word matched first, then the most words, the
        current version before a superseded one, then heat - the first `limit` of them (None: all, for a caller that
        filters them first). Each row carries `terms` (the words it matched) and
        `superseded_by` (the current version, when something replaced it). kinds: SEARCH_KINDS names; about: node
        ids - only nodes linked to or involving all of them (neighborhood); from_turn / to_turn: when made. With no
        words, `about` alone lists that neighborhood, newest first."""
        terms = search_terms(query)
        conds, args = [], []
        if terms:
            conds.append("(" + " OR ".join("lower(n.text) LIKE ?" for _ in terms) + ")")
            args += [f"%{t}%" for t in terms]
        elif not about:
            return []
        if not include_gm:
            conds.append("n.visibility='public'")
        picked = [SEARCH_KINDS[k] for k in kinds or () if k in SEARCH_KINDS]
        if picked:
            conds.append("(" + " OR ".join(picked) + ")")
        if from_turn is not None:
            conds.append("n.created_turn>=?")
            args.append(int(from_turn))
        if to_turn is not None:
            conds.append("n.created_turn<=?")
            args.append(int(to_turn))
        near = self.involving(about) if about else None
        if near is not None and not near:
            return []
        q = (f"SELECT n.*, COALESCE(e.energy, 0) AS energy FROM nodes n LEFT JOIN energy e ON e.node_id=n.id "
             f"WHERE {' AND '.join(conds) or '1'}")
        pats = [(t, term_re(t)) for t in terms]
        rows = []
        for r in self.conn.execute(q, args):
            if near is not None and r["id"] not in near:   # (in Python: a hub like a PC has a thousand neighbours)
                continue
            d = dict(r)
            d["terms"] = [t for t, p in pats if p.search(d["text"] or "")]
            if terms and not d["terms"]:
                continue                                 # (a LIKE hit inside another word: 'bo' in 'about')
            rows.append(d)
        old = {r["old_id"] for r in self.conn.execute("SELECT DISTINCT old_id FROM supersedes")} if rows else set()
        for d in rows:
            d["superseded_by"] = self.newest(d["id"]) if d["id"] in old else None
        if terms:
            rows.sort(key=lambda d: (len(d["terms"]) == len(terms), len(d["terms"]), d["superseded_by"] is None,
                                     d["energy"], d["created_turn"]), reverse=True)
        else:
            rows.sort(key=lambda d: (d["superseded_by"] is None, d["created_turn"], d["energy"]), reverse=True)
        return rows[:limit]

    def neighborhood(self, nid: str) -> set[str]:
        """Every node linked to or involving nid: its links, the slices it is a member of (or a slice's members), the
        notes and pictures on it (or a note's targets), and hearsay either way."""
        nid = norm_id(nid)
        out = {r["other"] for r in self.links_of(nid)}
        for sql in ("SELECT slice_id FROM members WHERE node_id=?", "SELECT node_id FROM members WHERE slice_id=?",
                    "SELECT note_id FROM annotates WHERE target_id=?", "SELECT target_id FROM annotates WHERE note_id=?",
                    "SELECT node_id FROM knows WHERE holder=?", "SELECT holder FROM knows WHERE node_id=?"):
            out |= {r[0] for r in self.conn.execute(sql, (nid,))}
        out.discard(nid)
        return out

    def involving(self, ids: Iterable[str]) -> set[str]:
        """The nodes in every one of ids' neighborhoods - what involves them all."""
        sets = [self.neighborhood(i) for i in ids]
        return set.intersection(*sets) if sets else set()

    def top_energy(self, limit: int = 15) -> list[dict]:
        q = ("SELECT n.id, n.kind, n.text, e.energy, e.touch_count FROM energy e JOIN nodes n ON n.id=e.node_id "
             "ORDER BY e.energy DESC LIMIT ?")
        return [dict(r) for r in self.conn.execute(q, (limit,))]
