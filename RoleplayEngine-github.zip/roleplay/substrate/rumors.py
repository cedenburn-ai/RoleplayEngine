"""Rumors: when a scene closes, its most notable moments travel along the association graph.

Deterministic and free. For the hottest few slices of the closed scene, the NPCs who saw it tell their own people -
NPCs who share history (assoc links) with them but weren't there - who now know it as a rumor. The DM sees
"(rumor - via Buzzcut's circles)" and can garble it in the telling.

Word travels through witnesses, never through a player character: a PC's deeds aren't spread by the PC (what they
say is their player's call), and spreading "via" them handed each scene's most alarming moment to their own contacts,
stripped of why - an earlier world's Berit heard "a runner tailed the Hush Man and troll girl Tamsin" about her
own daughter.
The dead neither tell nor hear. `tidy` takes back what the old way spread (once per world, when it opens).
This is the first, cheapest step toward the offscreen world (DESIGN.md §12).
"""
from __future__ import annotations

TIDY = "rumors_v2"                 # meta key: this world's old rumors have been tidied


def _alive_npc(L, eid: str, tier: int = 0) -> bool:
    from ..engine.rules.sr_lite import condition
    ent = L.get(eid)
    return bool(ent and ent["kind"] == "npc" and ent["tier"] >= tier and ent["status"] == "active"
                and condition(L, eid) != "dead")


def spread_rumors(game, scene_id: int, turn: int, max_slices: int = 3, max_listeners: int = 3) -> int:
    S, L, k = game.sub, game.ledger, game.settings.knobs
    rows = game.conn.execute(
        "SELECT n.id FROM nodes n JOIN energy e ON e.node_id=n.id WHERE n.kind='slice' AND n.scene_id=? "
        "AND n.visibility='public' "                       # whispers don't become gossip
        "ORDER BY e.energy DESC LIMIT ?", (scene_id, max_slices)).fetchall()
    spread = 0
    for row in rows:
        sid = row["id"]
        members = S.members_of(sid)
        witnesses = {m for m, r in members if r in k.witness_roles}
        tellers = [m for m in witnesses if _alive_npc(L, m)]     # the NPCs who saw it, and lived to tell it
        candidates: dict[str, tuple[int, str]] = {}
        for teller in tellers:
            for link in S.links_of(teller):
                other = link["other"]
                if link["kind"] != "assoc" or other in witnesses or not _alive_npc(L, other, tier=1):
                    continue
                if link["together"] > candidates.get(other, (0, ""))[0]:
                    candidates[other] = (link["together"], teller)
        best = sorted(candidates.items(), key=lambda kv: -kv[1][0])[:max_listeners]
        for npc, (_, via) in best:
            if S.add_knows(npc, sid, "rumor", via, turn):
                spread += 1
    if spread:
        game.out(f"[RUMOR] {spread} rumor(s) spread from scene S{scene_id}")
    return spread


def tidy(game) -> int:
    """Once per world: drop the rumors the old spreading made - told "via" a player character, or to someone dead.
    (Beliefs already formed stay: what an NPC concluded is part of the story now.)"""
    L = game.ledger
    if L.meta(TIDY):
        return 0
    pcs = {e["id"] for e in L.entities(kind="pc")}
    gone = [(r["holder"], r["node_id"]) for r in game.conn.execute("SELECT holder, node_id, source FROM knows "
                                                                   "WHERE how='rumor'")
            if r["source"] in pcs or not _alive_npc(L, r["holder"])]
    for holder, node in gone:
        game.conn.execute("DELETE FROM knows WHERE holder=? AND node_id=? AND how='rumor'", (holder, node))
        game.conn.execute("DELETE FROM links WHERE kind='knows' AND ((a=? AND b=?) OR (a=? AND b=?))",
                          (holder, node, node, holder))
    L.set_meta(TIDY, "1")
    if gone:
        game.out(f"[RUMOR] took back {len(gone)} rumor(s) the old spreading told via a PC or to the dead")
    return len(gone)
