"""Dynamics report for a campaign: is the memory substrate behaving?

    python -m roleplay.analyze autoplay            (markdown to stdout)
    python -m roleplay.analyze autoplay --out report.md

Answers the V5 spec §7 question first - does the warm set hold a stable population, drain
toward empty (subcritical), or collapse into one hot lump (supercritical)? - then recall depth,
NPC memory, tool use, duplicates, cost.
"""
from __future__ import annotations

import argparse
import difflib
import json
import sqlite3
import statistics
import sys
from collections import Counter
from pathlib import Path

from .config import CAMPAIGN_DIR


def _q(c, sql, args=()):
    return [dict(r) for r in c.execute(sql, args)]


def _has(c, table: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def trend(values: list[float]) -> float:
    """Least-squares slope per turn."""
    n = len(values)
    if n < 2:
        return 0.0
    xs = range(n)
    mx, my = (n - 1) / 2, sum(values) / n
    den = sum((x - mx) ** 2 for x in xs)
    return sum((x - mx) * (y - my) for x, y in zip(xs, values)) / den if den else 0.0


def report(path: Path) -> str:
    c = sqlite3.connect(str(path))
    c.row_factory = sqlite3.Row
    out: list[str] = []
    w = out.append
    turns = _q(c, "SELECT * FROM turns ORDER BY id")
    played = [t for t in turns if t["status"] == "committed"]
    metrics = _q(c, "SELECT * FROM turn_metrics ORDER BY turn")
    w(f"# Substrate report: {path.stem}\n")
    kinds = Counter(r["kind"] for r in _q(c, "SELECT kind FROM nodes"))
    ekinds = Counter(r["kind"] for r in _q(c, "SELECT kind FROM entities WHERE tier>=1"))
    lkinds = Counter(r["kind"] for r in _q(c, "SELECT kind FROM links"))
    w(f"- Turns: {len(played)} played + {len(turns) - len(played)} seeded; scenes: {len(_q(c, 'SELECT id FROM scenes'))}")
    w(f"- Nodes: {dict(kinds)}")
    w(f"- Tracked entities: {dict(ekinds)}")
    w(f"- Links: {dict(lkinds)}")
    if metrics:
        secs = [m["seconds"] for m in metrics]
        costs = [m["cost"] for m in metrics]
        packets = [m["packet_chars"] for m in metrics]
        w(f"- Cost: ${sum(costs):.3f} total, ${statistics.mean(costs):.3f}/turn (max ${max(costs):.3f})")
        w(f"- Latency: mean {statistics.mean(secs):.1f}s, p90 {sorted(secs)[int(0.9 * (len(secs) - 1))]:.1f}s, "
          f"max {max(secs):.1f}s")
        w(f"- Packet: {packets[0]} -> {packets[-1]} chars (mean {statistics.mean(packets):.0f}, max {max(packets)})")

    # ── warm set ──
    w("\n## Warm-set dynamics (V5 §7)\n")
    if metrics:
        frac = [m["warm"] / m["nodes"] for m in metrics if m["nodes"]]
        top5 = [m["top5_share"] for m in metrics]
        gini = [m["gini"] for m in metrics]
        w("| turn | nodes | warm (>=mean) | hot (>=2x) | warm % | gini | top-5 share |")
        w("|---|---|---|---|---|---|---|")
        for m in metrics:
            w(f"| {m['turn']} | {m['nodes']} | {m['warm']} | {m['hot']} | {100 * m['warm'] / max(1, m['nodes']):.0f}% "
              f"| {m['gini']:.2f} | {m['top5_share']:.2f} |")
        s_frac, s_top5 = trend(frac), trend(top5)
        verdict = "stable"
        if s_top5 > 0.01 and frac[-1] < 0.2:
            verdict = "LUMPING (supercritical): energy concentrating in a few nodes"
        elif frac[-1] < 0.1:
            verdict = "DRAINING (subcritical): almost nothing above the mean"
        w(f"\nWarm fraction {frac[0]:.2f} -> {frac[-1]:.2f} (slope {s_frac:+.4f}/turn); top-5 share "
          f"{top5[0]:.2f} -> {top5[-1]:.2f} (slope {s_top5:+.4f}/turn); gini {gini[0]:.2f} -> {gini[-1]:.2f}. "
          f"Verdict: **{verdict}**.")
        # warm-set turnover: how much of the warm set changes between turns
        hist = {}
        for r in _q(c, "SELECT turn, node_id, ratio FROM energy_history"):
            hist.setdefault(r["turn"], {})[r["node_id"]] = r["ratio"]
        ts = sorted(hist)
        churn = []
        for a, b in zip(ts, ts[1:]):
            wa = {k for k, v in hist[a].items() if v >= 1}
            wb = {k for k, v in hist[b].items() if v >= 1}
            if wa | wb:
                churn.append(1 - len(wa & wb) / len(wa | wb))
        if churn:
            w(f"Warm-set turnover per turn (1 - Jaccard): mean {statistics.mean(churn):.2f} "
              f"(0 = frozen, 1 = completely replaced each turn).")

    # ── hottest ──
    w("\n## Hottest nodes now\n")
    mean = c.execute("SELECT AVG(energy) FROM energy").fetchone()[0] or 1
    names = {r["id"]: r["name"] for r in _q(c, "SELECT id, name FROM entities")}
    for r in _q(c, "SELECT n.id, n.kind, n.text, e.energy, e.touch_count FROM energy e JOIN nodes n ON n.id=e.node_id "
                   "ORDER BY e.energy DESC LIMIT 15"):
        w(f"- {r['energy'] / mean:5.2f}x `{r['id']}` ({r['kind']}, {r['touch_count']} touches) "
          f"{names.get(r['id']) or r['text'][:90]}")
    w("\nHottest *turns* (the episodic memories most present right now):")
    for r in _q(c, "SELECT n.id, n.text, e.energy FROM energy e JOIN nodes n ON n.id=e.node_id WHERE n.kind='slice' "
                   "ORDER BY e.energy DESC LIMIT 6"):
        w(f"- {r['energy'] / mean:5.2f}x `{r['id']}` {r['text'][:140]}")

    # ── recall ──
    w("\n## Recall (attention-head links)\n")
    rec = _q(c, "SELECT m.slice_id, m.node_id, a.created_turn AS t_new, b.created_turn AS t_old, b.kind AS okind "
                "FROM members m JOIN nodes a ON a.id=m.slice_id JOIN nodes b ON b.id=m.node_id WHERE m.role='recalled'")
    played_ids = {f"T{t['id']}" for t in played}
    with_recall = {r["slice_id"] for r in rec}
    if played:
        w(f"- {len(rec)} recall links; {len(with_recall & played_ids)}/{len(played)} played turns recalled something")
    if rec:
        dist = [r["t_new"] - r["t_old"] for r in rec]
        w(f"- Distance back: median {statistics.median(dist)} turns, max {max(dist)}; "
          f"by kind {dict(Counter(r['okind'] for r in rec))}")
        scene_of = {r["id"]: r["scene_id"] for r in _q(c, "SELECT id, scene_id FROM nodes WHERE kind='slice'")}
        long_range = [r for r in rec if r["okind"] != "slice" or scene_of.get(r["node_id"]) != scene_of.get(r["slice_id"])
                      or r["t_new"] - r["t_old"] > 6]
        w(f"- Long-range recall (facts, other scenes, or >6 turns back): {len(long_range)} of {len(rec)}")
        top = Counter(r["node_id"] for r in rec).most_common(6)
        texts = {r["id"]: r["text"] for r in _q(c, "SELECT id, text FROM nodes")}
        w("- Most recalled:")
        for nid, n in top:
            w(f"  - `{nid}` x{n}: {texts.get(nid, '')[:120]}")

    # ── NPC memory ──
    w("\n## NPC memory\n")
    w("| NPC | heat | witnessed turns | facts | DM notes | scenes |")
    w("|---|---|---|---|---|---|")
    for e in _q(c, "SELECT * FROM entities WHERE kind='npc' AND tier>=1 ORDER BY id"):
        en = c.execute("SELECT energy FROM energy WHERE node_id=?", (e["id"],)).fetchone()
        wit = c.execute("SELECT COUNT(*) FROM members WHERE node_id=? AND role IN ('actor','target','present')",
                        (e["id"],)).fetchone()[0]
        facts = c.execute("SELECT COUNT(*) FROM links l JOIN nodes n ON n.id = CASE WHEN l.a=? THEN l.b ELSE l.a END "
                          "WHERE (l.a=? OR l.b=?) AND n.kind='fact'", (e["id"],) * 3).fetchone()[0]
        notes = c.execute("SELECT COUNT(*) FROM annotates WHERE target_id=?", (e["id"],)).fetchone()[0]
        scenes = c.execute("SELECT COUNT(*) FROM scene_presence WHERE entity_id=?", (e["id"],)).fetchone()[0]
        w(f"| {e['name']} | {(en[0] / mean) if en else 0:.2f}x | {wit} | {facts} | {notes} | {scenes} |")

    # ── tools ──
    if metrics:
        w("\n## DM behaviour\n")
        tools = Counter(t for m in metrics for t in json.loads(m["tools"] or "[]"))
        w(f"- Tool calls: {dict(tools.most_common())}")
        w(f"- Tool errors: {sum(m['tool_errors'] for m in metrics)}; DM calls/turn: "
          f"{statistics.mean(m['dm_steps'] for m in metrics):.1f}")
        tests = _q(c, "SELECT * FROM tests")
        if tests:
            w(f"- Rolls: {len(tests)}, {100 * sum(t['success'] for t in tests) / len(tests):.0f}% succeeded, "
              f"{sum(t['glitch'] for t in tests)} glitches, {sum(t['crit_glitch'] for t in tests)} critical")
            by_actor = Counter((t["actor_id"], bool(t["success"])) for t in tests)
            actors = sorted({a for a, _ in by_actor})
            w("- Success by actor: " + ", ".join(
                f"{a} {by_actor[(a, True)]}/{by_actor[(a, True)] + by_actor[(a, False)]}" for a in actors))
        cuts = len(_q(c, "SELECT DISTINCT scene_id FROM turns WHERE status='committed'"))
        hosts = c.execute("SELECT COUNT(*) FROM entities WHERE kind='host'").fetchone()[0]
        beliefs = c.execute("SELECT COUNT(*) FROM nodes WHERE kind='belief'").fetchone()[0]
        hearsay = c.execute("SELECT COUNT(*) FROM knows").fetchone()[0] if _has(c, "knows") else 0
        diodes = c.execute("SELECT COUNT(*) FROM supersedes").fetchone()[0] if _has(c, "supersedes") else 0
        w(f"- Scenes played in: {cuts}; hosts introduced: {hosts}; beliefs formed: {beliefs}; "
          f"hearsay edges: {hearsay}; diodes: {diodes}")
        w(f"- New per turn: facts {statistics.mean(m['facts_new'] for m in metrics):.2f}, notes "
          f"{statistics.mean(m['notes_new'] for m in metrics):.2f}, entities {statistics.mean(m['entities_new'] for m in metrics):.2f}")

    # ── duplicates ──
    w("\n## Possible duplicate entities\n")
    ents = _q(c, "SELECT id, name, kind FROM entities WHERE tier>=1")
    dups = []
    for i, a in enumerate(ents):
        for b in ents[i + 1:]:
            if a["kind"] == b["kind"]:
                r = difflib.SequenceMatcher(None, a["name"].lower(), b["name"].lower()).ratio()
                if r >= 0.6:
                    dups.append((r, a, b))
    for r, a, b in sorted(dups, key=lambda x: -x[0])[:12]:
        w(f"- {r:.2f} {a['name']} [{a['id']}] ~ {b['name']} [{b['id']}]")
    if not dups:
        w("- none found")

    w("\n## Facts\n")
    for r in _q(c, "SELECT id, created_turn, text FROM nodes WHERE kind='fact' ORDER BY created_turn"):
        w(f"- `{r['id']}` (T{r['created_turn']}) {r['text']}")
    w("\n## DM notes\n")
    for r in _q(c, "SELECT n.id, n.created_turn, n.text, group_concat(a.target_id) AS t FROM nodes n "
                   "JOIN annotates a ON a.note_id=n.id GROUP BY n.id ORDER BY n.created_turn"):
        w(f"- `{r['id']}` (T{r['created_turn']}, on {r['t']}) {r['text']}")
    c.close()
    return "\n".join(out)


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m roleplay.analyze")
    ap.add_argument("campaign", nargs="?", default="autoplay")
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    path = CAMPAIGN_DIR / f"{args.campaign}.db" if not args.campaign.endswith(".db") else Path(args.campaign)
    text = report(path)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(text)


if __name__ == "__main__":
    main()
