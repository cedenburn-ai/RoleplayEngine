"""Models, substrate knobs, prices and paths. Everything tunable lives here."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CAMPAIGN_DIR = ROOT / "campaigns"


@dataclass
class Models:
    dm: str = "claude-opus-5-5"          # the game master (tool loop)
    commit: str = "claude-haiku-5-5"     # post-turn extraction into the substrate
    askdm: str = "claude-haiku-5-5"      # out-of-fiction questions
    dm_effort: str = "medium"            # Opus 5.5 can't disable thinking; effort is the knob
    commit_effort: str = "low"
    world: str = "claude-haiku-5-5"      # offscreen NPC minds: personas and agendas (background)
    world_effort: str = "medium"
    dm_max_tokens: int = 32000
    dm_max_steps: int = 8                # tool round trips per turn before we force narration
    # Research is free up to here (DESIGN.md §8d): a step whose calls are all lookups (recall, read_turn, search_memory,
    # timeline) doesn't spend dm_max_steps. Live, 188 turns had recall in 6 and search in 14 - looking cost the turn's
    # rolls, so the GM narrated from the summaries instead.
    dm_research_steps: int = 6           # free lookup round trips per turn
    dm_research_calls: int = 16          # lookups per turn in all, free or not
    # Out of the story, a few lookups before the answer (DESIGN.md §8e): "Hey DM, didn't we agree at T33..." used to be
    # answered from the packet's summaries, and !askdm from the eight memories its keywords ranked highest.
    aside_research_steps: int = 4        # the GM aside: lookup round trips before it must answer
    askdm_research_steps: int = 4        # !askdm: the same, over what the asking character witnessed
    askdm_research_calls: int = 8        # !askdm: lookups per question in all


@dataclass
class Knobs:
    """Port of the Orchard SubstrateKnobs (game subset). See DESIGN.md §8."""

    bootstrap_energy: float = 1.0        # energy of the very first node (scale is irrelevant)
    touch_quantum: float = 1.0           # x mean, deposited on touch
    propagation_share: float = 0.5       # forward half -> bounded cascades (the honest mint)
    negligibility_fraction: float = 1e-4 # receiver-relative termination
    propagation_floor_ratio: float = 4e-8  # x mean: packet shares below this die
    wave_cap: int = 16                   # operational backstop
    # Orchard Rule 5 (+1 strength per traversal). Off for the game: the party is touched
    # every turn, so flow-carving would make strength mean "distance from the PCs".
    traversal_carves: bool = False
    # Link strength born per slice-member role (count units: "events of togetherness").
    role_strength: dict = field(default_factory=lambda: {
        "actor": 2.0, "target": 2.0, "present": 1.0, "location": 1.0,
        "mentioned": 0.5, "created": 1.0,
    })
    witness_roles: tuple = ("actor", "target", "present", "location")
    recall_strength: float = 1.0         # slice -> recalled memory (the attention-head link)
    spine_strength: float = 1.0
    retrieval_quantum: float = 0.5       # recalled / DM-expanded / player-named nodes (the slice gets 1.0)
    lookup_quantum: float = 0.5          # !askdm / recall lookups by players
    # Diode gates (Orchard SubstrateKnobs): relational confidence that new replaces old
    diode_c_high: float = 0.8
    diode_c_mid: float = 0.5
    diode_c_floor: float = 0.3
    # NPC minds: reflect at scene close, and every N turns inside a long scene
    reflect_every: int = 6
    reflect_min_witnessed: int = 2       # an NPC needs this many first-hand turns in the scene to reflect
    art_per_turn: int = 3                # new images queued per turn at most (each ~50 s, in the background)
    # The offscreen world (DESIGN.md §12): background Haiku calls after each turn
    world_agents_per_pass: int = 3       # NPCs/factions that take an offscreen step per pass (oldest move first)
    world_personas_per_pass: int = 2     # NPCs that get a character bible written per pass
    world_max_wait: int = 30             # turns an agenda can sleep before its next step


# USD per million tokens: (input, output, cache_read, cache_write_5m). Estimates for the
# console's running cost display - verify against the live pricing page before trusting.
PRICES = {
    "claude-fable-5-1": (10.00, 50.00, 0.25, 12.50),
    "claude-opus-5-5": (4.00, 20.00, 0.20, 5.00),
    "claude-sonnet-5-5": (2.00, 10.00, 0.20, 2.50),
    "claude-haiku-5-5": (0.10, 0.50, 0.01, 0.125),
}

# USD per generated image (OpenAI Images at the default medium quality). Rough estimates for the dashboard's spend
# view - the Images API bills on its own account, so check the OpenAI usage page for the real number.
IMAGE_PRICES = {
    "gpt-image-2.5-flare": 0.04,
    "gpt-image-2.5-sunburst": 0.06,
    "default": 0.05,
}

# !gmmodel names -> model ids. Server-side refusal fallbacks exist for all but Haiku.
MODEL_ALIASES = {"opus": "claude-opus-5-5", "sonnet": "claude-sonnet-5-5", "haiku": "claude-haiku-5-5",
                 "fable": "claude-fable-5-1"}
FALLBACK_MODELS = {"claude-opus-5-5", "claude-sonnet-5-5", "claude-fable-5-1"}
EFFORTS = ("low", "medium", "high", "xhigh", "max")

# !difficulty: a table dial, applied mechanically and shown on every roll card - in the Matrix too (matrix.dial,
# the owner, 2026-10-27, flags #27/#28: hosts had played at "normal" whatever the dial said).
#   threshold  - added to static thresholds the DM sets for PCs, and to a Matrix threshold (a search, an emergency
#                jack-out)
#   opposition - extra dice for NPCs/hosts opposing PCs (and for NPCs attacking PCs): a host's node defense, an IC's
#                attack, a host resisting a complex form
DIFFICULTY = {
    "story":  {"threshold": -1, "opposition": -2,
               "stance": "Story mode: the table wants momentum and spectacle. Lean generous, fail forward."},
    "easy":   {"threshold": -1, "opposition": -1,
               "stance": "Easy: competent runners in a forgiving world. Setbacks sting but rarely stop them."},
    "normal": {"threshold": 0, "opposition": 0,
               "stance": "Normal: fair and gritty. Plans matter, luck matters, consequences stick."},
    "hard":   {"threshold": 1, "opposition": 1,
               "stance": "Hard: the Sixth World pushes back. Opposition is smart, prepared and persistent."},
    "brutal": {"threshold": 1, "opposition": 2,
               "stance": "Brutal: corps and gangs play for keeps. Mistakes get people hurt; nothing is free."},
}


@dataclass
class Settings:
    models: Models = field(default_factory=Models)
    knobs: Knobs = field(default_factory=Knobs)
    art_style: str = "gritty cyberpunk concept art, neon and rain, painterly"
    undo_depth: int = 10
    graph_log: bool = True        # the per-turn graph log (graphlog/, DESIGN.md §8f); one campaign: graphlog off <name>
