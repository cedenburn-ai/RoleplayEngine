"""python -m roleplay.graphlog backfill|analyze|mind|on|off|status [campaign] - see roleplay/graphlog/__init__.py."""
from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

from ..config import CAMPAIGN_DIR
from ..spend import NOT_WORLDS                       # (campaigns/ holds the spend log, the ledger, the flags too)
from . import fmt


def campaign_path(arg: str | None) -> Path:
    """A campaign by name (campaigns/<name>.db) or path; none given: the world played most recently."""
    if arg:
        p = Path(arg)
        if p.suffix == ".db" and p.exists():
            return p
        p = CAMPAIGN_DIR / f"{arg.removesuffix('.db')}.db"
        if p.exists():
            return p
        raise SystemExit(f"No campaign '{arg}' (looked for {p}).")
    worlds = [p for p in CAMPAIGN_DIR.glob("*.db") if p.name not in NOT_WORLDS]
    if not worlds:
        raise SystemExit(f"No campaigns in {CAMPAIGN_DIR}.")
    return max(worlds, key=lambda p: max(p.stat().st_mtime, (p.with_name(p.name + "-wal").stat().st_mtime
                                                             if p.with_name(p.name + "-wal").exists() else 0)))


def _switch(db: Path, on: bool) -> str:
    """The campaign's own switch: one meta row (the running game reads it at its next turn)."""
    c = sqlite3.connect(str(db), timeout=10)
    try:
        c.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('graphlog', ?)", ("on" if on else "off",))
        c.commit()
    finally:
        c.close()
    return f"graph log {'on' if on else 'off'} for {db.stem} (from its next turn)"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m roleplay.graphlog", description=__doc__)
    ap.add_argument("command", choices=("backfill", "analyze", "mind", "on", "off", "status"))
    ap.add_argument("campaign", nargs="?", help="campaign name or .db path (default: the one played last)")
    ap.add_argument("who", nargs="?", help="mind: the character, by id or name")
    ap.add_argument("--turn", type=int, help="mind: as of this turn (default: the newest file)")
    ap.add_argument("--out", help="backfill: where the turn files go; analyze: where measures.csv and report.html go")
    ap.add_argument("--log", help="analyze, mind: the graph log folder (default: campaigns/<campaign>_graph)")
    ap.add_argument("--force", action="store_true", help="backfill: replace forward (exact) files too")
    a = ap.parse_args(argv)
    if a.command == "mind" and a.who is None:      # (`mind <who> --log DIR`: no campaign named)
        if not a.log or not a.campaign:
            raise SystemExit("mind needs a character: python -m roleplay.graphlog mind <campaign> <who>")
        a.campaign, a.who = None, a.campaign
    db = campaign_path(a.campaign) if not (a.command in ("analyze", "mind") and a.log and not a.campaign) else None
    if a.command == "backfill":
        from .backfill import backfill
        backfill(db, a.out, a.force)
    elif a.command == "analyze":
        from .analyze import analyze
        d = Path(a.log) if a.log else fmt.log_dir(db)
        res = analyze(d, a.out)
        print(f"{res['turns']} turn(s) analysed -> {res['csv']} and {res['html']}")
    elif a.command == "mind":                     # (GM-side: a character's whole mind - the owner's console only)
        from .perspectives import text
        try:
            print(text(Path(a.log) if a.log else fmt.log_dir(db), a.who, a.turn))
        except KeyError as exc:
            raise SystemExit(str(exc).strip("'\""))
    elif a.command in ("on", "off"):
        print(_switch(db, a.command == "on"))
    else:
        d = fmt.log_dir(db)
        turns = fmt.turns_on_file(d)
        size = sum(fmt.turn_file(d, t).stat().st_size for t in turns)
        c = sqlite3.connect(f"file:{db.resolve().as_posix()}?mode=ro", uri=True)
        try:
            row = c.execute("SELECT value FROM meta WHERE key='graphlog'").fetchone()
        finally:
            c.close()
        print(f"{db.stem}: graph log {'off' if row and row[0] == 'off' else 'on'}; {len(turns)} turn file(s)"
              + (f" T{turns[0]}..T{turns[-1]}, {size / 1e6:.1f} MB in {d}" if turns else f" in {d}"))
        from .minds import minds_file, minds_on_file     # (who felt and knew what: a sidecar beside each turn file)
        have = minds_on_file(d)
        line = f"  minds: {len(have)} file(s)" + (f" T{have[0]}..T{have[-1]}, "
                                                  f"{sum(minds_file(d, t).stat().st_size for t in have) / 1e6:.1f} MB"
                                                  if have else "")
        bare = sorted(set(turns) - set(have))
        if bare:
            line += (f"; no minds file beside {len(bare)} turn file(s): " + ", ".join(f"T{t}" for t in bare[-12:])
                     + (" ..." if len(bare) > 12 else ""))
            if len([t for t in bare if not have or t > have[-1]]) >= 2:
                line += " - the newest have stopped (the flags say why)"
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
