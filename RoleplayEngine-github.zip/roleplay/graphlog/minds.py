"""Minds per turn (DESIGN.md §8f, 'Minds per turn'): who everyone is and what's on their mind after each turn - beside
each turn file, T<turn>.minds.json.gz (fmt.FORMAT).

The owner: "we should see the connected stories of characters from their perspectives over time, where we can build a
relational model of them and see how the story played out from their perspective." The graph file has the memory;
this has the people: every PC, NPC and outfit (condition, scene, outfits, picture, persona), the whole attitude
matrix, the views they hold, what they were told, their goals, who witnessed each moment and the canon each would know
(witness.py's own rules), who was together, what changed since the last file and why, and what's on the mind of each
character in play - the hottest of what they know, as the substrate sees it.

Every table is the whole state (a keyframe a turn: 9 KB on average on the live world), so any turn's minds are one
file.
What changed comes from durable sources, never a buffer: the state diffed against the last minds file on disk, the
event log after the last file's `events_seq` (belief, attitude_cooled, new_party, damage, attack, retired...) for the
why, and marks.jsonl for a new party in between. A restart between turns loses nothing (all are on disk), an undo takes
its file and the record back together, and a turn the log missed (off, a write that failed) leaves the next file's
events covering both.
"""
from __future__ import annotations

import gzip
import json
import os
import re
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from . import fmt

SCHEMA = 1                                 # the minds file's own (the turn file's stays fmt.SCHEMA)
KINDS = ("pc", "npc", "faction")           # who has a mind on file
TOP = 12                                   # what's on a mind: the hottest this many of what they know
_MINDS_FILE = re.compile(r"^T(\d{6})\.minds\.json\.gz$")
CHAR_COLUMNS = ["id", "kind", "name", "condition", "tier", "player", "control", "former_pc", "scene", "place",
                "whereabouts", "moved_at", "factions", "picture", "persona", "sealed", "created_turn", "status"]
ATTITUDE_COLUMNS = ["holder", "about", "value"]
BELIEF_COLUMNS = ["id", "holder", "about", "created_turn", "attitude", "why", "replaces"]
KNOWS_COLUMNS = ["holder", "node", "how", "source", "turn"]
AGENDA_COLUMNS = ["id", "actor", "status", "targets", "steps", "created_turn", "updated_turn", "next_time", "by"]
HOOK_COLUMNS = ["id", "actor", "agenda", "status", "about", "created_turn", "landed_turn"]
HOLDING_COLUMNS = ["holder", "item", "name", "qty"]
# why a view was formed, by the belief event's `by` (none: minds.reflect_scene - an NPC thinking a scene over)
WHY_BY = {None: "belief", "world": "world", "newparty": "new-party", "seed": "seed", "dm": "gm"}


# ── the files ──────────────────────────────────────────────────────────
def minds_file(d: Path, turn: int) -> Path:
    return d / f"T{int(turn):06d}.minds.json.gz"


def minds_on_file(d: Path) -> list[int]:
    if not d.exists():
        return []
    return sorted(int(m.group(1)) for p in d.iterdir() if (m := _MINDS_FILE.match(p.name)))


def write_minds(d: Path, doc: dict) -> int:
    """Atomically, as fmt.write_turn. Returns its size in bytes."""
    d.mkdir(parents=True, exist_ok=True)
    data = gzip.compress(json.dumps(doc, separators=(",", ":"), ensure_ascii=False).encode("utf-8"), compresslevel=6)
    path = minds_file(d, doc["meta"]["turn"])
    tmp = path.with_name(path.name + ".part")
    tmp.write_bytes(data)
    os.replace(tmp, path)
    return len(data)


def read_minds(d: Path, turn: int) -> dict:
    return json.loads(gzip.decompress(minds_file(d, turn).read_bytes()).decode("utf-8"))


def digest(value) -> str | None:
    """A persona's (or whereabouts') short hash: the text goes once per version into the catalog under it."""
    if not value:
        return None
    return fmt.text_hash(value if isinstance(value, str) else json.dumps(value, sort_keys=True, ensure_ascii=False))


def _num(v):
    """A stat as the ledger holds it (REAL), an integer when it is one."""
    return int(v) if isinstance(v, float) and v.is_integer() else v


# ── the world's minds as they stand (one read of the record) ───────────
def snapshot(game) -> dict:
    """Everything a minds file holds, read from the campaign now - bulk queries, never a witness.Scope per character
    (4 ms each: 118 ms for the live world's 68; this whole file takes ~25 ms there). A runner gone home to the
    character ledger stays on file, departed: their views and numbers still stand in the record."""
    from ..engine.rules import sr_lite
    c, L = game.conn, game.ledger
    roles = tuple(game.settings.knobs.witness_roles)
    ents = [dict(r) | {"props": json.loads(r["props"] or "{}")} for r in c.execute(
        f"SELECT * FROM entities WHERE kind IN ({','.join('?' * len(KINDS))}) AND status IN ('active','departed') "
        "ORDER BY rowid", KINDS)]
    ids = {e["id"] for e in ents}
    scenes = {r["id"]: dict(r) for r in c.execute("SELECT id, status, location_id FROM scenes")}
    where_now = scenes_now(c)
    rosters: dict[int, list[str]] = defaultdict(list)
    for r in c.execute("SELECT r.scene_id, r.entity_id FROM scene_roster r JOIN scenes s ON s.id=r.scene_id WHERE "
                       "s.status IN ('active','parked') ORDER BY r.scene_id, r.entity_id"):
        if r[1] in ids:
            rosters[r[0]].append(r[1])
    kind_of = {e["id"]: e["kind"] for e in ents}
    members_of: dict[str, list[list]] = defaultdict(list)          # npc -> [[faction, role]] (world.factions_of)
    for r in c.execute("SELECT a, b FROM links WHERE kind='member_of' ORDER BY id"):
        npc, fac = (r[0], r[1]) if kind_of.get(r[1]) == "faction" else (r[1], r[0])
        if kind_of.get(fac) == "faction":
            roster = next((e["props"].get("members") or {} for e in ents if e["id"] == fac), {})
            members_of[npc].append([fac, roster.get(npc, "member")])
    pictures: dict[str, str] = {}
    for r in c.execute("SELECT id, target_id FROM clarifications WHERE status='current' "
                       "ORDER BY created_turn DESC, id DESC"):
        pictures.setdefault(r[1], r[0])
    try:
        from ..seed import sealed_ids
        sealed = sealed_ids(c)
    except Exception:
        sealed = set()
    chars, texts = [], {}
    for e in ents:
        p = e["props"]
        persona, w = p.get("persona"), p.get("whereabouts") or {}
        sid = where_now.get(e["id"])
        place = w.get("place") or (scenes.get(sid) or {}).get("location_id")
        if persona:
            texts[f"persona:{e['id']}"] = ("persona", json.dumps(persona, sort_keys=True, ensure_ascii=False))
        if w.get("where"):
            texts[f"where:{e['id']}"] = ("whereabouts", w["where"])
        chars.append([e["id"], e["kind"], e["name"],
                      None if e["kind"] == "faction" else sr_lite.condition(L, e["id"]), e["tier"], e["player"],
                      None if e["kind"] == "faction" else game.control_of(e["id"]),
                      (p.get("former_pc") or {}).get("turn"), sid, place, digest(w.get("where")),
                      w.get("time") if w.get("where") else None, members_of.get(e["id"], []), pictures.get(e["id"]),
                      digest(persona), e["id"] in sealed, e["created_turn"], e["status"]])
    attitudes = [[r[0], r[1].split(":", 1)[1], _num(r[2])] for r in c.execute(
        "SELECT entity_id, key, value FROM stats WHERE key LIKE 'attitude:%' ORDER BY entity_id, key")]
    # the views on file: holder and subject by their links, the number and the why by the event that formed them
    formed = {}
    for r in c.execute("SELECT actor, payload FROM events WHERE kind='belief' ORDER BY seq"):
        try:
            pl = json.loads(r[1] or "{}")
        except ValueError:
            continue
        formed[pl.get("belief")] = (r[0], pl)
    old = {r[0] for r in c.execute("SELECT old_id FROM supersedes")}
    replaces = {r[1]: r[0] for r in c.execute("SELECT old_id, new_id FROM supersedes WHERE old_id LIKE 'B%' "
                                              "ORDER BY turn, rowid")}
    current = [dict(r) for r in c.execute("SELECT id, created_turn FROM nodes WHERE kind='belief' ORDER BY rowid")
               if r[0] not in old]
    ends = _ends(c, {b["id"] for b in current}, ("holds", "about"))
    beliefs = []
    for b in current:
        actor, pl = formed.get(b["id"], (None, {}))
        holder = (ends.get((b["id"], "holds")) or [actor])[0]
        about = (ends.get((b["id"], "about")) or [pl.get("about")])[0]
        beliefs.append([b["id"], holder, about, b["created_turn"], pl.get("attitude"),
                        WHY_BY.get(pl.get("by"), pl.get("by")) if b["id"] in formed else None, replaces.get(b["id"])])
    knows = [list(r) for r in c.execute("SELECT holder, node_id, how, source, turn FROM knows ORDER BY turn, rowid")]
    agenda_rows = [dict(r) for r in c.execute("SELECT * FROM agendas ORDER BY rowid")]
    hook_rows = [dict(r) for r in c.execute("SELECT * FROM hooks ORDER BY rowid")]
    about = _ends(c, {a["id"] for a in agenda_rows} | {h["id"] for h in hook_rows}, ("about",))
    agendas = [[a["id"], a["npc_id"], a["status"], about.get((a["id"], "about"), []), a["steps"], a["created_turn"],
                a["updated_turn"], a["next_time"], a["by"]] for a in agenda_rows]
    hooks = [[h["id"], h["npc_id"], h["agenda_id"], h["status"], about.get((h["id"], "about"), []), h["created_turn"],
              h["landed_turn"]] for h in hook_rows]
    holdings = [[r[0], r[1], r[2], _num(r[3])] for r in c.execute(      # (what they carry: Scope.known has it too)
        "SELECT h.owner_id, h.item_id, e.name, h.qty FROM holdings h JOIN entities e ON e.id=h.item_id "
        "ORDER BY h.owner_id, h.item_id") if r[0] in ids]
    witnesses, members = witnesses_all(c, roles)
    return {"characters": chars, "attitudes": attitudes, "beliefs": beliefs, "knows": knows, "agendas": agendas,
            "hooks": hooks, "holdings": holdings, "witnesses": witnesses, "members": members,
            "facts": facts_known(c, ids, witnesses, game.turn_no() + 1),
            "co_presence": [[sid, scenes[sid]["status"], who] for sid, who in sorted(rosters.items()) if who],
            "texts": texts}


def scenes_now(c) -> dict[str, int]:
    """Ledger.scene_of, for everyone at once: the active scene first, then the newest."""
    out: dict[str, int] = {}
    for r in c.execute("SELECT r.entity_id, r.scene_id FROM scene_roster r JOIN scenes s ON s.id=r.scene_id "
                       "ORDER BY (s.status='active') DESC, s.id DESC"):
        out.setdefault(r[0], r[1])
    return out


def _ends(c, ids: set[str], kinds: tuple[str, ...]) -> dict[tuple[str, str], list[str]]:
    """{(node, link kind): the other ends} for the nodes in ids - one pass over those links."""
    out: dict[tuple[str, str], list[str]] = defaultdict(list)
    if not ids:
        return out
    for r in c.execute(f"SELECT a, b, kind FROM links WHERE kind IN ({','.join('?' * len(kinds))}) ORDER BY id", kinds):
        if r[0] in ids:
            out[(r[0], r[2])].append(r[1])
        if r[1] in ids:
            out[(r[1], r[2])].append(r[0])
    return out


def witnesses_all(c, roles) -> tuple[dict[str, list[list]], dict[str, list[tuple[str, str]]]]:
    """({slice: [[id, role]]} - who witnessed each T#/W# by witness.Scope's own rule: a member in a witness role, and a
    whisper only its sender (its slice lists its target too, who may never have noticed) - and {slice: every
    (member, role)}) for every slice at once."""
    sender = {f"T{r[0]}": r[1] for r in c.execute("SELECT id, private FROM turns WHERE private IS NOT NULL AND "
                                                  "status IN ('committed','seed')")}
    vis = {r[0]: r[1] for r in c.execute("SELECT id, visibility FROM nodes WHERE kind='slice'")}
    out: dict[str, list[list]] = {s: [] for s in vis}
    members: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for r in c.execute("SELECT slice_id, node_id, role FROM members ORDER BY rowid"):
        if r[0] not in vis:
            continue
        members[r[0]].append((r[1], r[2]))
        if r[2] in roles and (vis[r[0]] != "private" or sender.get(r[0]) == r[1]):
            out[r[0]].append([r[1], r[2]])
    return out, members


def facts_known(c, ids, witnesses: dict[str, list], now: int) -> dict[str, list[str]]:
    """{id: the canon they'd know} - witness.Scope._facts for everyone at once (its inputs, read once)."""
    from ..dm.dmblock import between_turns
    vis = {r[0]: (r[1], r[2]) for r in c.execute("SELECT id, visibility, created_turn FROM nodes WHERE kind='fact' "
                                                  "AND visibility IN ('public','private')")}
    source: dict[str, set[str]] = defaultdict(set)
    drawn: dict[str, set[str]] = defaultdict(set)
    for r in c.execute("SELECT l.kind, x.id, x.kind, y.id FROM links l JOIN nodes x ON x.id=l.a JOIN nodes y ON "
                       "y.id=l.b WHERE l.kind IN ('about','recall') AND ((x.kind='fact' AND y.kind='slice') OR "
                       "(x.kind='slice' AND y.kind='fact'))"):
        f, s = (r[1], r[3]) if r[2] == "fact" else (r[3], r[1])
        (source if r[0] == "about" else drawn)[f].add(s)
    heard: dict[str, set[str]] = defaultdict(set)
    for r in c.execute("SELECT k.holder, k.node_id FROM knows k JOIN nodes n ON n.id=k.node_id WHERE n.kind IN "
                       "('slice','fact') AND n.visibility<>'gm'"):
        heard[r[0]].add(r[1])
    own: dict[str, set[int]] = defaultdict(set)
    for r in c.execute("SELECT id, private FROM turns WHERE private IS NOT NULL AND status IN ('committed','seed')"):
        own[r[1]].add(r[0])
    rounds: dict[str, set[int]] = defaultdict(set)              # (Scope._rounds: a fight's rounds write no slice)
    for e in c.execute("SELECT scene_id, started_turn, ended_turn, members, positions FROM encounters").fetchall():
        try:
            inside = set(json.loads(e[3] or "{}")) | set(json.loads(e[4] or "{}"))
        except (ValueError, TypeError):
            continue
        if e[1] is None or not inside:
            continue
        turns = {r[0] for r in c.execute("SELECT id FROM turns WHERE scene_id=? AND id BETWEEN ? AND ? AND private IS "
                                         "NULL AND status='committed'", (e[0], e[1], e[2] or now))}
        for x in inside:
            rounds[x] |= turns
    wit: dict[str, set[str]] = defaultdict(set)
    for s, ws in witnesses.items():
        for w, _ in ws:
            wit[w].add(s)
    turns_of = {eid: {int(s[1:]) for s in wit.get(eid, ()) if s[:1] == "T" and s[1:].isdigit()} | own.get(eid, set())
                | rounds.get(eid, set()) for eid in ids}
    return canon(ids, vis, source, drawn, between_turns(c), {r[0] for r in c.execute("SELECT id FROM turns")}, wit,
                 {eid: heard.get(eid, set()) - wit.get(eid, set()) for eid in ids}, turns_of)


def canon(ids, vis: dict[str, tuple], source: dict, drawn: dict, between: set[str], on_file: set[int],
          wit: dict[str, set[str]], heard: dict[str, set[str]], turns_of: dict[str, set[int]]) -> dict[str, list[str]]:
    """Scope._facts' rule over prepared inputs (the forward log's and the backfill's): a fact that came out of a moment
    they hold (linked `about` it); else - unless the canon or an aside set it down between turns - a public fact set
    down in a turn they were in, or outside play; a public fact a moment they witnessed drew on; any fact they were
    told."""
    out = {}
    for eid in ids:
        seen, turns = wit.get(eid, set()) | heard.get(eid, set()), turns_of.get(eid, set())
        got = {f for f in heard.get(eid, ()) if f[:1] == "F"}
        for f, (v, born) in vis.items():
            moments = source.get(f)
            if moments:
                ok = bool(moments & seen)
            elif f in between:
                ok = False
            else:
                ok = v == "public" and (born in turns or born not in on_file)
            if ok or (v == "public" and drawn.get(f, set()) & wit.get(eid, set())):
                got.add(f)
        if got:
            out[eid] = sorted(got, key=lambda x: (len(x), x))
    return out


# ── what a character knows, and what's on their mind ───────────────────
def known(eid: str, witnessed: set[str], told: set[str], facts: set[str], members: dict[str, list],
          own: dict[str, str], carried=()) -> tuple[dict[str, str], set[str]]:
    """({memory: how they hold it}, {who and what they've met}) - what's on a mind can only be what's in it. Memories:
    witness.Scope's - the moments they witnessed, what they were told, the canon they'd know - and their own views
    and goals (`own`: {B#/A#: belief | agenda}). Met: the people, places and things in the moments they hold, and
    what they carry. Themselves left out (a PC's own node is the hottest thing on file)."""
    out = dict(own)
    for s in witnessed:
        out.setdefault(s, "witnessed")
    for n in told:
        out.setdefault(n, "told")
    for f in facts:
        out.setdefault(f, "fact")
    met = {m for s in witnessed | told for m, role in members.get(s, ()) if role != "recalled"} | set(carried)
    out.pop(eid, None)
    met.discard(eid)
    return out, met


def salience(held, ratios: dict[str, float], top: int = TOP) -> list[list]:
    """The hottest `top` of what they hold - [[node, ratio, how]] ({node: how}), or [[node, ratio]] (a set) - by the
    snapshot's energy ratio (notes and pictures aren't citizens: never on a mind by heat)."""
    pairs = held.items() if isinstance(held, dict) else ((n, None) for n in held)
    rows = [(ratios[n], n, how) for n, how in pairs if ratios.get(n) is not None]
    rows.sort(key=lambda r: (-r[0], r[1]))
    return [[n, fmt.rnd(r), how] if how else [n, fmt.rnd(r)] for r, n, how in rows[:top]]


def perspective_sets(doc: dict) -> tuple[dict[str, set[str]], dict[str, set[str]], dict[str, dict[str, str]],
                                         dict[str, set[str]]]:
    """From a minds file alone: ({id: the slices they witnessed}, {id: what they were told}, {id: their own B#/A#},
    {id: the canon they'd know}) - every one a defaultdict."""
    wit: dict[str, set[str]] = defaultdict(set)
    for s, ws in (doc.get("witnesses") or {}).items():
        for eid, _ in ws:
            wit[eid].add(s)
    told: dict[str, set[str]] = defaultdict(set)
    for k in fmt.rows_of(doc.get("knows")):
        told[k["holder"]].add(k["node"])
    own: dict[str, dict[str, str]] = defaultdict(dict)
    for b in fmt.rows_of(doc.get("beliefs")):
        own[b["holder"]][b["id"]] = "belief"
    for a in fmt.rows_of(doc.get("agendas")):
        if a["status"] == "active":
            own[a["actor"]][a["id"]] = "agenda"
    facts: dict[str, set[str]] = defaultdict(set, {eid: set(fs) for eid, fs in (doc.get("facts") or {}).items()})
    return wit, told, own, facts


# ── the diff: what changed since the last minds file, and why ──────────
def state_of(doc: dict) -> dict:
    """What a minds file's successor diffs against (also rebuilt from the file itself after a restart)."""
    return {"turn": doc["meta"]["turn"], "events_seq": doc["meta"].get("events_seq") or 0,
            "reconstructed": bool(doc.get("reconstructed")), "exactness": doc.get("exactness") or {},
            "story_time": doc["meta"].get("story_time"),
            "characters": {r["id"]: r for r in fmt.rows_of(doc.get("characters"))},
            "attitudes": {(r["holder"], r["about"]): r["value"] for r in fmt.rows_of(doc.get("attitudes"))},
            "beliefs": {r["id"]: r for r in fmt.rows_of(doc.get("beliefs"))},
            "knows": {(r["holder"], r["node"]): r for r in fmt.rows_of(doc.get("knows"))},
            "agendas": {r["id"]: r for r in fmt.rows_of(doc.get("agendas"))},
            "hooks": {r["id"]: r for r in fmt.rows_of(doc.get("hooks"))},
            "witnesses": {s: [tuple(w) for w in ws] for s, ws in (doc.get("witnesses") or {}).items()}}


def _phase(at, turn: int) -> str | None:
    return None if at is None else "turn" if int(at) >= turn else "between"


LOGGED = ("belief", "attitude_cooled", "new_party", "damage", "heal", "attack", "repair", "retired", "correct",
          "introduce", "renamed", "departed", "returned", "merge", "transfer_item", "persona")
CONDITIONS = ("ok", "wounded", "unconscious", "dying", "dead")    # (sr_lite.condition's, worst last)
# the characters fields a backfill rebuilds from history (minds_backfill.py) - a change against a reconstructed file in
# one of these may be the rebuild's, not the world's. The rest (persona, player) it takes as they stand when it runs -
# today's - so a change in them came since.
REBUILT = ("condition", "scene", "place", "whereabouts", "moved_at", "factions", "picture", "sealed", "control",
           "status", "tier", "name")


def log_since(c, seq: int) -> list[dict]:
    """The event log's lines a mind event can come from, after `seq` (the last minds file's events_seq)."""
    out = []
    for r in c.execute(f"SELECT seq, turn_id, kind, actor, payload FROM events WHERE seq>? AND kind IN "
                       f"({','.join('?' * len(LOGGED))}) ORDER BY seq", (seq, *LOGGED)):
        try:
            pl = json.loads(r[4] or "{}")
        except ValueError:
            pl = {}
        out.append({"seq": r[0], "turn": r[1], "kind": r[2], "actor": r[3], "p": pl})
    return out


WATERMARKED = ("nodes", "entities", "knows")       # the tables a new party's mark keeps a high-water mark of


def watermark(c) -> dict[str, int]:
    """{table: its newest rowid} - newparty.run's, when the reset begins (the mark's rows_after, beside events_after):
    what its catch-up passes add lands above it."""
    return {t: c.execute(f"SELECT COALESCE(MAX(rowid), 0) FROM {t}").fetchone()[0] for t in WATERMARKED}


def rows(c) -> dict:
    """Where each node, character and hearsay row sits in its table (rowid), for a mark's rows_after (_during)."""
    return {"nodes": {r[0]: r[1] for r in c.execute("SELECT id, rowid FROM nodes")},
            "entities": {r[0]: r[1] for r in c.execute("SELECT id, rowid FROM entities")},
            "knows": {(r[0], r[1]): r[2] for r in c.execute("SELECT holder, node_id, rowid FROM knows")}}


def lookups(c, fresh: list[str]) -> dict:
    """What events() needs to know beyond the two states, read from the campaign: the seed turns and who each one
    filed, which view replaced which, the goals the new moments hang off, who wrote each picture, and where each row
    sits in its table (a new party's watermark)."""
    new = set(fresh)
    steps: dict[str, list[str]] = defaultdict(list)
    if new:
        for r in c.execute("SELECT a, b FROM links WHERE kind='step' ORDER BY id"):
            w, a = (r[0], r[1]) if r[0] in new else (r[1], r[0])
            if w in new and a[:1] == "A":
                steps[a].append(w)
    return {"seeds": {r[0] for r in c.execute("SELECT id FROM turns WHERE status='seed'")},
            "seed_cast": seed_cast(c),
            "replaces": {r[1]: r[0] for r in c.execute("SELECT old_id, new_id FROM supersedes WHERE new_id LIKE 'B%' "
                                                       "ORDER BY turn, rowid")},
            "steps": steps,
            "pictures": {r[0]: (r[1], r[2]) for r in c.execute("SELECT id, by, created_turn FROM clarifications")},
            "rows": rows(c)}


def seed_cast(c) -> dict[int, tuple[set[str], int | None]]:
    """{seed turn: (who it made or tied in, the story clock it was filed at)} - seed.apply's record (seed:applied).
    A seed filed before the record said: whoever was made in its turn."""
    try:
        from ..seed import META_APPLIED
        row = c.execute("SELECT value FROM meta WHERE key=?", (META_APPLIED,)).fetchone()
        recs = json.loads(row[0] or "[]") if row else []
    except Exception:
        return {}
    out = {}
    for r in recs:
        if not isinstance(r, dict) or r.get("turn") is None:
            continue
        ids = r.get("ids")
        if ids is None:
            ids = [x[0] for x in c.execute("SELECT id FROM entities WHERE created_turn=?", (int(r["turn"]),))]
        out[int(r["turn"])] = (set(ids), r.get("story_time"))
    return out


def events(turn: int, now: dict, prev: dict | None, log: list[dict], marks: list[dict], ctx: dict,
           dated_only: bool = False) -> list[dict]:
    """The mind events since `prev` (the last minds file's state; None: none on file) - the states diffed, the event log
    since then replayed for the why - each with a phase (turn: this turn's; between: before it - the offscreen world, a
    new party, a read-back; null: nothing dates it). The forward log and the backfill both come here (ctx: lookups()).
    dated_only: a first minds file on a world with history keeps only what this turn's own numbers date."""
    seeds = ctx.get("seeds") or set()
    seeded = lambda at: at in seeds and _phase(at, turn) == "turn"     # noqa: E731 (a seed's own turn: its file)
    since = prev["turn"] if prev else None
    seed_here = sorted(t for t in seeds if t is not None and (since is None or t > since) and t <= turn)
    parties = [m for m in marks if m.get("kind") == "new-party"]
    former = {x for m in parties for x in m.get("former_pcs") or []}
    out: list[dict] = []

    def add(ev: dict, at=None, line: dict | None = None, during: bool = False) -> None:
        """One event, dated by `at` (a turn) and, when the log says it, by its line (`during`: what dated it says
        it was a new party's)."""
        ev.setdefault("phase", _phase(at, turn))
        ev.setdefault("turn", at)
        if ev["phase"] == "between" and (during or any(_during(m, ev, line, former, ctx.get("rows"))
                                                      for m in parties)):
            ev["during"] = "new-party"                       # (the reset's own: its scene close, its minds, its skip)
        out.append(ev)

    # ── the views and the numbers: the event log replayed over the last file's matrix ──
    att = dict(prev["attitudes"]) if prev else {}
    for e in log:
        if e["kind"] == "belief":
            p = e["p"]
            why = WHY_BY.get(p.get("by"), p.get("by"))
            key, to = (e["actor"], p.get("about")), p.get("attitude")
            ev = {"kind": "belief", "who": e["actor"], "about": p.get("about"), "id": p.get("belief"),
                  "attitude": to, "why": why}
            if (ctx.get("replaces") or {}).get(p.get("belief")):
                ev["replaces"] = ctx["replaces"][p["belief"]]
            add(ev, e["turn"], e)
            if to is not None and att.get(key) != to:
                add({"kind": "attitude", "who": e["actor"], "about": p.get("about"), "from": att.get(key), "to": to,
                     "why": why}, e["turn"], e)
                att[key] = to
        elif e["kind"] == "attitude_cooled":
            key = (e["actor"], e["p"].get("about"))
            add({"kind": "attitude", "who": e["actor"], "about": key[1], "from": att.get(key, e["p"].get("from")),
                 "to": e["p"].get("to"), "why": "cool"}, e["turn"], e)
            att[key] = e["p"].get("to")
    cur = {(h, a): v for h, a, v in now["attitudes"]}
    for key in sorted(set(cur) | set(att)):                  # what no line of the log says: a hand edit, a script
        if cur.get(key) != att.get(key) and not (dated_only and key not in att):
            add({"kind": "attitude", "who": key[0], "about": key[1], "from": att.get(key), "to": cur.get(key),
                 "why": "unlogged"})
    if not dated_only:                                       # (a view gone with no new one replacing it)
        gone = set(prev["beliefs"] if prev else ()) - {b[0] for b in now["beliefs"]}
        explained = {e.get("replaces") for e in out if e["kind"] == "belief"}
        for bid in sorted(gone - explained):
            b = prev["beliefs"][bid]
            add({"kind": "belief", "who": b["holder"], "about": b["about"], "id": None, "replaces": bid,
                 "why": "unlogged"})

    # ── who went for whom: every attack the rules rolled (sr_lite.attack, a ram) - what it left them is below ──
    for e in log:
        if e["kind"] == "attack":
            p = e["p"]
            add({"kind": "attacked", "who": e["actor"], "about": p.get("target"), "hit": p.get("hit"),
                 "boxes": p.get("boxes"), "target_status": p.get("target_status"),
                 "why": "ram" if p.get("ram") else "attack"}, e["turn"], e)

    # ── things changing hands (transfer_item: the GM's, or an offscreen move's) - what a thing carries goes with it ──
    for e in log:
        if e["kind"] == "transfer_item":
            p = e["p"]
            add({"kind": "handed", "who": e["actor"], "about": p.get("to"), "item": p.get("item"),
                 "qty": p.get("qty"), "why": "world" if p.get("by") == "world" else "gm"}, e["turn"], e)

    # ── hearsay ──
    had = prev["knows"] if prev else {}
    late = now.get("knows_late") or set()                    # (the backfill's: told after its turn's snapshot)
    for h, node, how, src, t in now["knows"]:
        if (h, node) in had or (dated_only and t != turn):
            continue
        between = _phase(t, turn) == "between" or (h, node) in late
        why = ("seed" if seeded(t) and not between else {"on the line": "on-the-line", "rumor": "rumor",
                                                          "discovered": "world"}.get(how)
               or ("world" if between else "told"))
        add({"kind": "learned", "who": h, "node": node, "how": how, "from": src, "why": why}, t)

    # ── goals and hooks ──
    retired = {e["p"].get("id"): e for e in log if e["kind"] == "retired"}
    dropped = {e["actor"]: e for e in log if e["kind"] == "correct" and e["p"].get("what") == "hook"}   # (a GM's fix)
    pa = prev["agendas"] if prev else {}
    for a in (dict(zip(AGENDA_COLUMNS, r)) for r in now["agendas"]):
        old = pa.get(a["id"])
        if old is None:
            if dated_only and a["created_turn"] != turn:
                continue
            add({"kind": "agenda", "who": a["actor"], "id": a["id"], "change": "new", "targets": a["targets"],
                 "why": {"newparty": "new-party", "dm": "gm"}.get(a["by"], a["by"])}, a["created_turn"])
        if old is not None and (a["steps"] or 0) > (old["steps"] or 0):
            add({"kind": "agenda", "who": a["actor"], "id": a["id"], "change": "advanced", "targets": a["targets"],
                 "steps": a["steps"] - (old["steps"] or 0), "moments": (ctx.get("steps") or {}).get(a["id"], []),
                 "why": "world" if _phase(a["updated_turn"], turn) == "between" else "turn"}, a["updated_turn"])
        if (old or {}).get("status", "active") != a["status"] and a["status"] != "active":
            r = retired.get(a["id"])
            ev = {"kind": "agenda", "who": a["actor"], "id": a["id"], "change": a["status"], "targets": a["targets"],
                  "why": "retired" if r else "world" if _phase(a["updated_turn"], turn) == "between" else "turn"}
            if r:
                ev["reason"] = r["p"].get("why")
            add(ev, r["turn"] if r else a["updated_turn"], r)
    ph = prev["hooks"] if prev else {}
    for h in (dict(zip(HOOK_COLUMNS, r)) for r in now["hooks"]):
        old = ph.get(h["id"])
        if old is None:
            if dated_only and h["created_turn"] != turn:
                continue
            add({"kind": "hook", "who": h["actor"], "id": h["id"], "change": "new", "about": h["about"],
                 "why": "seed" if seeded(h["created_turn"]) else "world"
                 if _phase(h["created_turn"], turn) == "between" else "turn"}, h["created_turn"])
        if (old or {}).get("status", "ready") != h["status"] and h["status"] != "ready":
            r = retired.get(h["id"])
            x = dropped.get(h["id"]) if h["status"] == "stale" and not r else None
            ev = {"kind": "hook", "who": h["actor"], "id": h["id"], "change": h["status"], "about": h["about"],
                  "why": "landed" if h["status"] == "landed" else "retired" if r else "gm" if x else "superseded"}
            if r or x:
                ev["reason"] = r["p"].get("why") if r else x["p"].get("reason")
            add(ev, h["landed_turn"] if h["status"] == "landed" else (r or x)["turn"] if r or x else None, r or x)

    # ── the people themselves ──
    if not dated_only:
        _people(turn, now, prev, log, ctx, seeded, seed_here, parties, add)
    return out


def _row(ev: dict, rows: dict) -> tuple[str, int] | None:
    """(table, rowid) of the row a between-turns event made, when it made one: a new goal or hook, a goal's new steps,
    a hearsay row, a newcomer."""
    k = ev["kind"]
    if k in ("agenda", "hook") and ev.get("change") == "new":
        at = rows["nodes"].get(ev.get("id"))
        return ("nodes", at) if at is not None else None
    if k == "agenda" and ev.get("change") == "advanced":
        at = [rows["nodes"][w] for w in ev.get("moments") or [] if w in rows["nodes"]]
        return ("nodes", max(at)) if at else None
    if k == "learned":
        at = rows["knows"].get((ev.get("who"), ev.get("node")))
        return ("knows", at) if at is not None else None
    if k == "appeared":
        at = rows["entities"].get(ev.get("who"))
        return ("entities", at) if at is not None else None
    return None


def _during(mark: dict, ev: dict, line: dict | None, former: set[str], rows: dict | None = None) -> bool:
    """Is this between-turns event a new party's own? Its line in the log comes after the reset began (the mark's
    events_after). With no line to say: the row it made sits above the mark's rows_after (the tables' high-water mark
    when the reset began - review 2026-10-28: the catch-up passes' goals, steps, hooks, hearsay and newcomers write no
    line, and read as the world's moves before the reset); else the old crew's own changes are, and rumors at its turn
    (word only spreads at a scene close, and between turns only a reset closes one). A mark from before events_after:
    its turn says."""
    if mark.get("turn") != ev.get("turn"):
        return False
    if mark.get("events_after") is None:
        return True
    if line is not None and line.get("seq") is not None:
        return line["seq"] > mark["events_after"]
    row = _row(ev, rows) if rows and mark.get("rows_after") else None
    if row is not None:
        return row[1] > int(mark["rows_after"].get(row[0]) or 0)
    return ev.get("who") in former or (ev["kind"] == "learned" and ev.get("why") == "rumor")


def _shaky(prev: dict | None) -> set[str]:
    """The rebuilt fields (REBUILT) a reconstructed file couldn't recover exactly, by its exactness map."""
    if not prev or not prev.get("reconstructed"):
        return set()
    ex = prev.get("exactness") or {}
    return {f for f in REBUILT if not str(ex.get(f"characters.{f}", ex.get("*", ""))).startswith("exact")}


def _people(turn: int, now: dict, prev: dict | None, log: list[dict], ctx: dict, seeded, seed_here: list[int],
            parties: list[dict], add) -> None:
    """Characters appearing, dying, changing hands or names, joining outfits, moving, going home - the diff of the
    characters table, each dated and explained by the event log where it says (introduce, damage, heal, attack, repair,
    new_party, renamed, departed, merge, persona). Where it doesn't: a new party's old crew changed in the reset; whoever a
    seed in the window made or tied in (seed.apply's record), in the seed; an offscreen move by the story clock it was
    made at (whereabouts.time) - inside a new party's gap, its catch-up passes'. An exact file against a reconstructed
    one: a change in one of the fields the rebuild took from history says basis: reconstructed, and why reconstruction
    where nothing above explains it (the rebuild may simply have had it wrong)."""
    pc = prev["characters"] if prev else {}
    since = prev["turn"] if prev else None
    by_actor: dict[tuple[str, str], dict] = {}
    hit_by: dict[str, dict] = {}                           # target -> the newest attack that landed on them
    for e in log:                                          # the newest of each kind for each actor
        if e["actor"]:
            by_actor[(e["kind"], e["actor"])] = e
        if e["kind"] == "merge":
            by_actor[("merge", e["p"].get("dropped"))] = e
        if e["kind"] == "attack" and e["p"].get("hit"):
            hit_by[e["p"].get("target")] = e
    rows = {r[0]: dict(zip(CHAR_COLUMNS, r)) for r in now["characters"]}
    cast: dict[str, tuple[int, int | None]] = {}          # id -> (the seed's turn, its clock)
    for t in seed_here:
        ids, clock = (ctx.get("seed_cast") or {}).get(t, ((), None))
        cast.update({x: (t, clock) for x in ids})
    reset_of = {x: m.get("turn") for m in parties for x in m.get("former_pcs") or []}
    shaky = set() if now.get("reconstructed") else _shaky(prev)    # (the seam: an exact file after a rebuilt one)
    clock0 = (prev or {}).get("story_time")                # (the last file's story clock)
    after = since if since is not None and since == turn - 1 else None   # (a between-turns change: after that turn)

    def cause(eid: str, default: str | None, moved_at=None) -> tuple[str | None, int | None, bool, bool]:
        """(why, turn, a new party's?, only the default?) for a change no line dates."""
        if eid in reset_of:
            return "new-party", reset_of[eid], True, False
        s = cast.get(eid)
        if s and (moved_at is None or s[1] is None or moved_at >= s[1]):
            return "seed", s[0], False, False
        if moved_at is not None:
            for m in parties:
                lo, hi = m.get("story_time_from"), m.get("story_time_to")
                # (strictly after its start: a move stamped at the reset's first minute is the world's before it -
                # review 2026-10-28)
                if lo is not None and hi is not None and lo < moved_at <= hi:
                    return "world", m.get("turn"), True, False       # (the reset's catch-up passes)
            if clock0 is not None and moved_at > clock0:
                return "world", after, False, False                 # (after the last file's clock: the world's)
        return default, after if default == "world" else None, False, True

    def put(ev: dict, field: str, why, at=None, during: bool = False, guessed: bool = False, line=None) -> None:
        if field in shaky:
            ev["basis"] = "reconstructed"
            if guessed:
                why, at, during, line = "reconstruction", None, False, None
        ev["why"] = why
        add(ev, at, line, during)

    for eid, r in rows.items():
        o = pc.get(eid)
        if o is None:
            e = by_actor.get(("introduce", eid))
            at = e["turn"] if e else r["created_turn"]
            add({"kind": "appeared", "who": eid, "as": r["kind"],
                 "why": "seed" if seeded(at) else "setup" if not at else "player" if r["kind"] == "pc" and not e
                 else "world" if _phase(at, turn) == "between" else "turn"}, at, e)
            continue
        if o["condition"] != r["condition"]:
            worse = (CONDITIONS.index(r["condition"]) if r["condition"] in CONDITIONS else 0) > \
                (CONDITIONS.index(o["condition"]) if o["condition"] in CONDITIONS else 0)
            line = (by_actor.get(("damage", eid)) if worse else by_actor.get(("heal", eid))) \
                or by_actor.get(("repair", eid))
            kind = (line or {}).get("kind")
            why = ("seed" if kind == "damage" and line["p"].get("by") == "seed" else "damage" if kind == "damage"
                   else "heal" if kind == "heal" else "repair" if kind == "repair" else "time")
            ev = {"kind": "condition", "who": eid, "from": o["condition"], "to": r["condition"]}
            if kind == "damage" and line["p"].get("how"):
                ev["how"] = line["p"]["how"]
            if worse and kind == "damage" and eid in hit_by:
                ev["by"] = hit_by[eid]["actor"]                # (who hurt them: the attack that landed)
            if kind == "heal":
                ev.update({k: v for k, v in (("by", line["p"].get("by")), ("reason", line["p"].get("reason"))) if v})
            if kind == "repair" and line["p"].get("why"):
                ev["reason"] = line["p"]["why"]
            put(ev, "condition", why, (line or {}).get("turn"), guessed=line is None, line=line)
        if o["kind"] != r["kind"]:
            e = by_actor.get(("new_party", eid))
            add({"kind": "kind", "who": eid, "from": o["kind"], "to": r["kind"],
                 "why": "new-party" if e else "unlogged"}, e["turn"] if e else None, e)
        if o["name"] != r["name"]:                         # (the story revealed a name: speakers.rename)
            e = by_actor.get(("renamed", eid))
            put({"kind": "renamed", "who": eid, "from": o["name"], "to": r["name"]}, "name",
                "gm" if e else "unlogged", e["turn"] if e else None, guessed=e is None, line=e)
        if (o.get("status") or "active") != (r["status"] or "active"):
            home = r["status"] == "departed"
            e = by_actor.get(("departed" if home else "returned", eid))
            put({"kind": "departed" if home else "returned", "who": eid}, "status", "ledger" if e else "unlogged",
                e["turn"] if e else None, guessed=e is None, line=e)
        persona = o["persona"] != r["persona"] and r["persona"]
        written = by_actor.get(("persona", eid)) if persona else None    # (world.apply's line: when it was written)
        moved_off = o["whereabouts"] != r["whereabouts"] and r["whereabouts"]
        when = r["moved_at"] if moved_off else None
        old_f, new_f = {f for f, _ in o["factions"] or []}, dict(r["factions"] or [])
        for f in sorted(set(new_f) - old_f):             # (a persona's affiliations join its outfits: world.apply)
            why, at, during, guessed = cause(eid, "world" if persona else None)
            put({"kind": "joined", "who": eid, "faction": f, "role": new_f[f]}, "factions", why, at, during,
                guessed and not persona, written)
        for f in sorted(old_f - set(new_f)):
            why, at, during, guessed = cause(eid, None)
            put({"kind": "left", "who": eid, "faction": f}, "factions", why, at, during, guessed)
        if o["scene"] != r["scene"]:                     # (world.move takes an offscreen NPC out of the scene left)
            why, at, during, guessed = cause(eid, "world" if moved_off else "turn", when)
            put({"kind": "moved", "who": eid, "from": o["scene"], "to": r["scene"]}, "scene", why, at, during, guessed)
        if moved_off:
            why, at, during, guessed = cause(eid, "world", when)
            put({"kind": "whereabouts", "who": eid, "place": r["place"], "text": f"where:{eid}",
                 "story_time": when}, "whereabouts", why, at, during, guessed)
        if persona:
            why, at, during, _ = cause(eid, "world")
            add({"kind": "persona", "who": eid, "text": f"persona:{eid}", "why": why}, at, written, during)
        if o["picture"] != r["picture"] and r["picture"]:
            by, at = (ctx.get("pictures") or {}).get(r["picture"], (None, None))
            put({"kind": "picture", "who": eid, "id": r["picture"], "replaces": o["picture"]}, "picture",
                {"newparty": "new-party", "dm": "gm"}.get(by, by), at)
        if o["tier"] != r["tier"]:                       # (a mind earned: minds.reflect_scene after a first view)
            b = by_actor.get(("belief", eid))
            ev = {"kind": "tier", "who": eid, "from": o["tier"], "to": r["tier"]}
            if b:                                        # (the view that earned it says why, and when)
                put(ev, "tier", WHY_BY.get(b["p"].get("by"), b["p"].get("by") or "belief"), b["turn"], line=b)
            else:
                put(ev, "tier", *cause(eid, None))
        if bool(o["sealed"]) != bool(r["sealed"]):
            s = cast.get(eid) if r["sealed"] else None
            put({"kind": "sealed" if r["sealed"] else "unsealed", "who": eid}, "sealed",
                "seed" if r["sealed"] else "play", s[0] if s else None, guessed=not r["sealed"])
    for eid in sorted(set(pc) - set(rows)):
        e = by_actor.get(("merge", eid))
        add({"kind": "gone", "who": eid, "why": "merged" if e else "unlogged", **({"into": e["actor"]} if e else {})},
            e["turn"] if e else None, e)


def in_play(now: dict, fresh: list[str], evs: list[dict]) -> set[str]:
    """Who's in play this turn: the PCs, whoever is in the scene or the new moments (offscreen actors who moved too),
    and anyone whose mind changed - never one gone home to the character ledger."""
    kinds = {r[0]: r[1] for r in now["characters"]}
    home = {r[0] for r in now["characters"] if r[CHAR_COLUMNS.index("status")] == "departed"}
    play = {i for i, k in kinds.items() if k == "pc" and i not in home}
    play |= {i for _, status, who in now["co_presence"] if status == "active" for i in who}
    play |= {w for s in fresh for w, _ in now["witnesses"].get(s, ()) if w in kinds}
    play |= {e["who"] for e in evs if e.get("who") in kinds}
    return play - home


def minds_of(now: dict, play: set[str], ratios: dict[str, float]) -> tuple[dict, dict]:
    """({id: what's on their mind}, {id: who's on it}) for everyone in play (salience over known())."""
    wit, told, own, facts = perspective_sets({"witnesses": now["witnesses"], "facts": now["facts"],
                                              "knows": fmt.table(KNOWS_COLUMNS, now["knows"]),
                                              "beliefs": fmt.table(BELIEF_COLUMNS, now["beliefs"]),
                                              "agendas": fmt.table(AGENDA_COLUMNS, now["agendas"])})
    carried: dict[str, set[str]] = defaultdict(set)
    for holder, item, *_ in now.get("holdings") or []:
        carried[holder].add(item)
    sal, people = {}, {}
    for eid in sorted(play):
        held, met = known(eid, wit[eid], told[eid], facts[eid], now["members"], own[eid], carried[eid])
        sal[eid], people[eid] = salience(held, ratios), salience(met, ratios)
    return sal, people


def document(campaign: str, turn: int, now: dict, fresh: list[str], evs: list[dict], sal: dict, people: dict,
             meta: dict, exactness: dict, reconstructed: bool = False) -> dict:
    """A minds file from its parts (the forward log's and the backfill's alike)."""
    return {"schema": SCHEMA, "kind": "minds", "reconstructed": reconstructed, "exactness": exactness,
            "meta": {"campaign": campaign, "turn": turn, **meta, "characters": len(now["characters"]),
                     "in_play": len(sal)},
            "characters": fmt.table(CHAR_COLUMNS, now["characters"]),
            "attitudes": fmt.table(ATTITUDE_COLUMNS, now["attitudes"]),
            "beliefs": fmt.table(BELIEF_COLUMNS, now["beliefs"]),
            "knows": fmt.table(KNOWS_COLUMNS, now["knows"]),
            "agendas": fmt.table(AGENDA_COLUMNS, now["agendas"]),
            "hooks": fmt.table(HOOK_COLUMNS, now["hooks"]),
            "holdings": fmt.table(HOLDING_COLUMNS, now.get("holdings") or []),
            "witnesses": now["witnesses"], "witnessing": fresh, "facts": now["facts"],
            "co_presence": now["co_presence"],
            "salience": sal, "salience_people": people, "events": evs}


# ── the file ───────────────────────────────────────────────────────────
def seeded_events(turn: int, now: dict, prev: dict, log: list[dict], marks: list[dict], ctx: dict,
                  before: dict) -> list[dict]:
    """A seed's own file, in two: what came before its first change (the last file to the seed's start - a new party
    just before it, the offscreen world) and what the seed did (its start to its snapshot: every change in it is the
    seed's). `before`: before_seed's minds, the moment it began."""
    mid = state_of(document("", turn - 1, before["now"], [], [], {}, {}, {"events_seq": before["seq"],
                                                                         "story_time": before["story_time"]}, {}))
    pre = events(turn, before["now"], prev, [e for e in log if e["seq"] <= before["seq"]], marks,
                 dict(ctx, seeds=set(ctx.get("seeds") or ()) - {turn}))
    everyone = {r[0] for r in now["characters"]} | {r[0] for r in before["now"]["characters"]}
    post = events(turn, now, mid, [e for e in log if e["seq"] > before["seq"]], [],
                  dict(ctx, seed_cast={**(ctx.get("seed_cast") or {}), turn: (everyone, before["story_time"])}))
    return pre + post


def before_seed(rec, game) -> None:
    """seed.apply, before its first change: the minds as they stand, for its own file (seeded_events). Never
    raises - without it the file still tells the seed's people by its record (seed_cast)."""
    try:
        rec.minds_before = {"turn": game.turn_no() + 1, "now": snapshot(game), "story_time": game.clock(),
                            "seq": game.conn.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]}
    except Exception:
        rec.minds_before = None


def build(game, turn: int, ratios: dict[str, float], prev: dict | None, campaign: str, marks: list[dict] | None = None,
          scene_id=None, story_time=None, before: dict | None = None) -> tuple[dict, dict]:
    """One turn's minds file, and the texts (persona:, where:) the catalog needs. `before`: the minds as a seed found
    them (before_seed) - in the seed's own turn, its file tells the seed's changes from what came before it."""
    t0 = time.perf_counter()
    c = game.conn
    now = snapshot(game)
    seq = c.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]
    dated_only = prev is None and c.execute("SELECT 1 FROM turns WHERE id<? LIMIT 1", (turn,)).fetchone() is not None
    if prev is not None and prev["events_seq"] > seq:     # (the record was put back under the file: its seq is stale)
        prev = dict(prev, events_seq=0)
    log = log_since(c, prev["events_seq"] if prev else 0)
    if dated_only:
        log = [e for e in log if e["turn"] == turn]
    pw = prev["witnesses"] if prev else {}
    born = {r[0] for r in c.execute("SELECT id FROM nodes WHERE kind='slice' AND created_turn=?", (turn,))} \
        if dated_only else None
    fresh = [s for s, ws in now["witnesses"].items() if (s not in pw or [tuple(w) for w in ws] != pw[s])
             and (born is None or s in born)]
    ctx = lookups(c, fresh)
    if before is not None and prev is not None and not dated_only and before["turn"] == turn and \
            before["seq"] >= prev["events_seq"] and (c.execute("SELECT status FROM turns WHERE id=?", (turn,))
                                                     .fetchone() or [None])[0] == "seed":
        evs = seeded_events(turn, now, prev, log, marks or [], ctx, before)
    else:
        evs = events(turn, now, prev, log, marks or [], ctx, dated_only)
    sal, people = minds_of(now, in_play(now, fresh, evs), ratios)
    exactness = {"*": "exact"}
    if dated_only:
        exactness["events"] = ("partial: the first minds file of a world with history - only what this turn's own "
                               "numbers date (python -m roleplay.graphlog backfill rebuilds the turns before)")
    elif prev is not None and prev.get("reconstructed"):
        exactness["events"] = ("approximate: against a reconstructed file - a change in a field it rebuilt from "
                               f"history ({', '.join(sorted(_shaky(prev))) or 'none'}) carries basis: reconstructed, "
                               "and why reconstruction where nothing on file explains it (the rebuild's, not the "
                               "world's); views, numbers, hearsay, goals and hooks exact")
    doc = document(campaign, turn, now, fresh, evs, sal, people,
                   {"diff_since": prev["turn"] if prev else None, "events_seq": seq, "scene_id": scene_id,
                    "story_time": story_time, "written_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                   exactness)
    doc["meta"]["ms"] = round((time.perf_counter() - t0) * 1000, 1)
    return doc, now["texts"]


def catalog_texts(have: dict[str, str], texts: dict[str, tuple[str, str]], turn: int) -> list[dict]:
    """Catalog lines for a persona or whereabouts new to the catalog, or changed (`have`: id -> hash on file)."""
    out = []
    for key, (kind, text) in sorted(texts.items()):
        h = fmt.text_hash(text)
        if have.get(key) != h:
            out.append({"id": key, "kind": kind, "ekind": None, "created_turn": None, "scene_id": None,
                        "since": turn, "hash": h, "text": text})
    return out


def prev_state(rec, turn: int) -> dict | None:
    """The newest minds file before `turn` - the recorder's cache while it is still the newest on disk, else read off
    disk (a restart, an undo, or another process on this world that wrote one since: the console's seed)."""
    older = [t for t in minds_on_file(rec.dir) if t < turn]
    if not older:
        return None
    cached = getattr(rec, "minds_prev", None)
    if cached is not None and cached["turn"] == older[-1]:
        return cached
    try:
        return state_of(read_minds(rec.dir, older[-1]))
    except Exception:
        return None


def marks_since(d: Path, marks: list[dict], since: int | None, turn: int) -> list[dict]:
    """The turn file's marks (the recorder's buffer), plus any marks.jsonl has from this file's window - a reset at
    or after the last minds file's turn - that the buffer lost: a minds or graph file that failed, the log off, a
    restart that dropped the buffer. marks.jsonl has each one the moment it happened, less those taken back."""
    from .analyze import standing_marks
    have = {(m.get("kind"), m.get("turn")) for m in marks}
    lo = since if since is not None else turn - 1
    return list(marks) + [m for m in standing_marks(d) if (m.get("kind"), m.get("turn")) not in have
                          and m.get("turn") is not None and lo <= int(m["turn"]) < turn]


def after_file(rec, game, doc: dict, marks: list[dict]) -> int | None:
    """Recorder.write, right after the turn's own file: its minds beside it. Never raises - the graph file is written
    whatever happens here, and a minds file that's missing heals itself: the next one's events cover both turns (and a
    second turn running without one is a flag)."""
    turn = doc["meta"]["turn"]
    try:
        ratios = {r[0]: r[6] for r in doc["nodes"]["rows"]}
        prev = prev_state(rec, turn)
        before, rec.minds_before = getattr(rec, "minds_before", None), None
        mdoc, texts = build(game, turn, ratios, prev, rec.campaign,
                            marks_since(rec.dir, marks, prev["turn"] if prev else None, turn),
                            doc["meta"].get("scene_id"), doc["meta"].get("story_time"), before)
        fresh = catalog_texts(rec.catalog or {}, texts, turn)
        fmt.append_catalog(rec.dir, fresh)
        if rec.catalog is not None:
            for e in fresh:
                rec.catalog[e["id"]] = e["hash"]
        size = write_minds(rec.dir, mdoc)
        rec.minds_prev = state_of(mdoc)
        return size
    except Exception as exc:
        rec.minds_prev = None
        try:
            game.out(f"  (graph log: T{turn}'s minds not written - {type(exc).__name__}: {exc})")
        except Exception:
            pass
        stopped(rec.dir, game, turn, exc)
        return None


def stopped(d: Path, game, turn: int, exc: Exception) -> None:
    """A second turn file running with no minds file beside it: a flag, once while it's open (the dashboard shows it).
    The console line alone is easy to miss - a whisper turn sends only its cards - and the perspective record would
    stop with every other sign saying the log is fine."""
    try:
        have = minds_on_file(d)
        last = have[-1] if have else None
        if len([t for t in fmt.turns_on_file(d) if (last is None or t > last) and t <= turn]) < 2:
            return
        from .. import flags
        flags.record(game, "engine", "graph log", f"The graph log's minds files stopped after T{last} "
                     f"(the turn files go on): {type(exc).__name__}: {exc} - who felt and knew what isn't being "
                     "recorded until it's fixed (python -m roleplay.graphlog status)")
    except Exception:
        pass
