"""The per-turn graph log (DESIGN.md §8f): the memory graph after every turn, written to a file - the raw material for
testing the Orchard's claims (V5 spec §7 criticality, §8.9 echo chamber, the lakes-and-rivers physics) on a real run.

    forward    on by default: after each committed turn, campaigns/<campaign>_graph/T<turn>.json.gz (fmt.FORMAT),
               and beside it T<turn>.minds.json.gz - every character's mind (minds.py)
    python -m roleplay.graphlog backfill [campaign] [--out DIR]   rebuild T1..Tn from history, read-only on the db
    python -m roleplay.graphlog analyze [campaign] [--out DIR]    measures.csv + report.html from the log
    python -m roleplay.graphlog mind <campaign> <who> [--turn N]  one character's mind at a turn (perspectives.py)
    python -m roleplay.graphlog off|on [campaign]                 this campaign's switch (settings.graph_log: all)
"""
from __future__ import annotations

from .fmt import FORMAT, SCHEMA, log_dir, read_turn, rows_of, turns_on_file  # noqa: F401
from .record import Recorder, after_turn, attach, before_seed, enabled, undone  # noqa: F401
