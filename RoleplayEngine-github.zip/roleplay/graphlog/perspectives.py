"""Perspectives from the graph log alone (DESIGN.md §8f, 'Minds per turn'): one character's mind at any turn, and their
story turn by turn - from the minds files, the turn files and the catalog, never the campaign file.

    mind_at(log_dir, who, turn)   what they feel, believe, were told, want, have witnessed so far, where they are, who
                                  with, and what's on their mind - as of the newest minds file at or before `turn`
    timeline(log_dir, who)        their mind events, turn by turn: views formed, numbers moved, what they learned,
                                  goals, the moments they witnessed, how others came to see them
A character is asked for by id or by any name they've had on file: a rename (the story revealing who someone is)
leaves one id under two names, and every file is read by that id.
    python -m roleplay.graphlog mind <campaign> <who> [--turn N] [--log DIR]   the same, to read (GM-side: the owner's
                                  console; nothing at the table reads these files)
"""
from __future__ import annotations

from pathlib import Path

from . import fmt, minds

CLIP = 150                        # a memory's text in the summary


def _rows(doc: dict, key: str) -> list[dict]:
    return fmt.rows_of(doc.get(key))


def resolve(doc: dict, who: str) -> str | None:
    """A character by id or name ('magic', 'Dr. A. Brask', 'the bosun') in a minds file - the id, or None."""
    chars = _rows(doc, "characters")
    w = (who or "").strip().lower()
    for c in chars:
        if c["id"].lower() == w:
            return c["id"]
    bare = w.removeprefix("the ")
    for c in chars:
        if (c["name"] or "").lower().removeprefix("the ") == bare:
            return c["id"]
    hits = [c["id"] for c in chars if bare and bare in (c["name"] or "").lower()]
    return hits[0] if len(hits) == 1 else None


def resolve_any(docs, who: str) -> str | None:
    """The id behind a name in any of these minds files (newest first: a name someone has now wins over one somebody
    else had before) - a rename leaves the old name in the files before it."""
    for doc in docs:
        eid = resolve(doc, who)
        if eid is not None:
            return eid
    return None


def file_at(d: Path, turn: int | None = None) -> int | None:
    """The newest minds file at or before `turn` (None: the newest)."""
    on = [t for t in minds.minds_on_file(d) if turn is None or t <= turn]
    return on[-1] if on else None


def _text(cat: dict, nid: str | None) -> str:
    return ((cat.get(nid) or {}).get("text") or "") if nid else ""


def _name(names: dict, cat: dict, eid: str | None) -> str:
    if not eid:
        return "someone"
    if eid in names:
        return names[eid]
    t = _text(cat, eid)
    return t.split(" (", 1)[0] if t else eid


def mind_at(d: Path | str, who: str, turn: int | None = None) -> dict | None:
    """One character's mind as the log has it at `turn` (None: the newest file). None when there's no minds file then;
    a KeyError when nobody by that name is on file."""
    d = Path(d)
    t = file_at(d, turn)
    if t is None:
        return None
    doc = minds.read_minds(d, t)
    eid = resolve(doc, who)
    if eid is None:                               # (a name they had before a rename, or have since)
        eid = resolve_any((minds.read_minds(d, x) for x in reversed(minds.minds_on_file(d)) if x != t), who)
        if eid not in {c["id"] for c in _rows(doc, "characters")}:
            raise KeyError(f"nobody called '{who}' in T{t}'s minds file")
    cat = fmt.catalog_at(fmt.read_catalog(d), t)
    chars = {c["id"]: c for c in _rows(doc, "characters")}
    me = chars[eid]
    names = {i: c["name"] for i, c in chars.items()}
    wit, told, own, facts = minds.perspective_sets(doc)
    witnessed = sorted(wit.get(eid, set()), key=lambda s: ((cat.get(s) or {}).get("created_turn") or 0, s))
    salience, source = doc.get("salience", {}).get(eid), "recorded"
    people = doc.get("salience_people", {}).get(eid)
    if salience is None:                          # (not in play that turn: worked out from the turn's own graph file)
        salience, people, source = _salience(d, t, eid, wit, told, own, facts,
                                             {h["item"] for h in _rows(doc, "holdings") if h["holder"] == eid})
    scene = me["scene"]
    with_ = next((w for s, _, w in doc.get("co_presence") or [] if s == scene), [])
    wh = cat.get(f"where:{eid}")
    return {
        "turn": t, "asked": turn, "id": eid, "name": me["name"], "character": me,
        "reconstructed": bool(doc.get("reconstructed")), "exactness": doc.get("exactness") or {},
        "where": {"scene": scene, "scene_title": _text(cat, f"S{scene}").removeprefix("Scene: ") if scene else None,
                  "place": me["place"], "whereabouts": wh.get("text") if wh and wh.get("hash") == me["whereabouts"]
                  else None, "with": [x for x in with_ if x != eid]},
        "attitudes": {r["about"]: r["value"] for r in _rows(doc, "attitudes") if r["holder"] == eid},
        "toward": {r["holder"]: r["value"] for r in _rows(doc, "attitudes") if r["about"] == eid},
        "beliefs": [dict(b, text=_text(cat, b["id"])) for b in _rows(doc, "beliefs") if b["holder"] == eid],
        "held_about": [dict(b, text=_text(cat, b["id"])) for b in _rows(doc, "beliefs") if b["about"] == eid],
        "knows": [dict(k, text=_text(cat, k["node"])) for k in _rows(doc, "knows") if k["holder"] == eid],
        "carries": [h for h in _rows(doc, "holdings") if h["holder"] == eid],
        "agendas": [dict(a, text=_text(cat, a["id"])) for a in _rows(doc, "agendas") if a["actor"] == eid],
        "hooks": [dict(h, text=_text(cat, h["id"])) for h in _rows(doc, "hooks") if h["actor"] == eid],
        "witnessed": witnessed,
        "salience": [[n, r, how, _text(cat, n)] for n, r, how in salience or []], "salience_source": source,
        "salience_people": [[n, r, _name(names, cat, n)] for n, r in people or []],
        "persona": (cat.get(f"persona:{eid}") or {}).get("text") if me["persona"] else None,
        "names": names,
    }


def _salience(d: Path, t: int, eid: str, wit, told, own, facts, carried=()):
    """What's on a mind that wasn't in play at `t`: the same rule (minds.known) over the turn file's own ratios, the
    moments' members from the catalog."""
    if t not in fmt.turns_on_file(d):
        return None, None, None
    ratios = {r[0]: r[6] for r in fmt.read_turn(d, t)["nodes"]["rows"]}
    members = {e["id"]: [tuple(m) for m in e.get("members") or []]
               for e in fmt.catalog_at(fmt.read_catalog(d), t).values() if e.get("kind") == "slice"}
    held, met = minds.known(eid, wit[eid], told[eid], facts[eid], members, own[eid], carried)
    return minds.salience(held, ratios), minds.salience(met, ratios), f"worked out from T{t}'s graph file"


def _involves(ev: dict, eid: str) -> str | None:
    """How a mind event touches someone: theirs, about them (someone else's view or number, a goal or a hook aimed at
    them, an attack on them, someone joining or leaving their outfit), or told by them."""
    if ev.get("who") == eid:
        return "mine"
    about = ev.get("about")
    if eid in (about if isinstance(about, list) else [about]) or eid in (ev.get("targets") or ()) \
            or ev.get("faction") == eid:
        return "about me"
    if ev.get("from") == eid and ev.get("kind") == "learned":
        return "told by me"
    return None


def timeline(d: Path | str, who: str) -> list[dict]:
    """[{turn, events: [event + 'for': mine | about me | told by me], witnessed: [new moments they witnessed]}] - every
    minds file that has something of theirs, oldest first: one id through every file, whatever they were called then.
    A file inside a later one's diff_since is left out - a backfill filled the turn a failed minds file left, and the
    next forward file had counted it already."""
    d = Path(d)
    on = minds.minds_on_file(d)
    eid = resolve_any((minds.read_minds(d, t) for t in reversed(on)), who)
    if eid is None:
        if on:
            raise KeyError(f"nobody called '{who}' in the minds files")
        return []
    out = []
    for t in on:                                  # (one file at a time: 188 of them don't all fit in a reading)
        doc = minds.read_minds(d, t)
        since = (doc.get("meta") or {}).get("diff_since")
        if since is not None:
            out = [x for x in out if not since < x["turn"] < t]
        evs = [dict(e, **{"for": how}) for e in doc.get("events") or [] if (how := _involves(e, eid))]
        seen = [s for s in doc.get("witnessing") or [] if any(w == eid for w, _ in (doc.get("witnesses") or {})
                                                               .get(s, ()))]
        if evs or seen:
            out.append({"turn": t, "reconstructed": bool(doc.get("reconstructed")), "events": evs, "witnessed": seen})
    return out


# ── the CLI's reading ──────────────────────────────────────────────────
def _clip(s: str, n: int = CLIP) -> str:
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[:n - 3].rsplit(" ", 1)[0] + "..."


def _sign(v) -> str:
    return f"{int(v):+d}" if isinstance(v, (int, float)) and float(v).is_integer() else str(v)


def _was(v) -> str:
    return "a first view" if v is None else f"was {_sign(v)}"


def _hit(ev: dict) -> str:
    return f"hit, {ev.get('boxes')} box(es), {ev.get('target_status')}" if ev.get("hit") else "missed"


def _event_line(ev: dict, names: dict, cat: dict) -> str:
    n = lambda x: _name(names, cat, x)            # noqa: E731
    k, why = ev["kind"], ev.get("why")
    tail = (f" ({why}{', ' + ev['phase'] if ev.get('phase') == 'between' else ''}"
            f"{', rebuilt' if ev.get('basis') == 'reconstructed' else ''})" if why else "")
    if ev["for"] == "about me":
        if k == "belief":
            return f"{n(ev['who'])} formed a view of me [{ev.get('id')}]{tail}"
        if k == "attitude":
            return f"{n(ev['who'])} now feels {_sign(ev.get('to'))} about me ({_was(ev.get('from'))}){tail}"
        if k == "attacked":
            return f"{n(ev['who'])} went for me: {_hit(ev)}{tail}"
        if k == "handed":
            return f"{n(ev['who'])} handed me [{ev.get('item')}]{tail}"
        if k in ("joined", "left"):
            return f"{n(ev['who'])} {k} us{tail}"
        return f"{k} by {n(ev['who'])}: {ev.get('id') or ''}{' ' + ev['change'] if ev.get('change') else ''}{tail}"
    if ev["for"] == "told by me":
        return f"I told {n(ev['who'])} about [{ev['node']}]{tail}"
    if k == "belief":
        return (f"I made up my mind about {n(ev.get('about'))} [{ev.get('id')}]: "
                f"\"{_clip(_text(cat, ev.get('id')), 110)}\"{tail}")
    if k == "attitude":
        return f"I feel {_sign(ev.get('to'))} about {n(ev.get('about'))} now ({_was(ev.get('from'))}){tail}"
    if k == "learned":
        src = f" from {n(ev['from'])}" if ev.get("from") else ""
        return f"I heard ({ev.get('how')}{src}) [{ev['node']}]: {_clip(_text(cat, ev['node']), 110)}{tail}"
    if k in ("agenda", "hook"):
        return f"{k} {ev.get('id')} {ev.get('change')}: {_clip(_text(cat, ev.get('id')), 110)}{tail}"
    if k == "condition":
        return f"I'm {ev.get('to')} now (was {ev.get('from')}{', ' + n(ev['by']) if ev.get('by') else ''}){tail}"
    if k == "attacked":
        return f"I went for {n(ev.get('about'))}: {_hit(ev)}{tail}"
    if k == "handed":
        return f"I handed [{ev.get('item')}] to {n(ev.get('about'))}{tail}"
    if k == "renamed":
        return f"on file as {ev.get('to')} now (was {ev.get('from')}){tail}"
    if k in ("joined", "left"):
        return f"I {k} {n(ev.get('faction'))}{tail}"
    if k == "moved":
        return f"I moved from S{ev.get('from')} to S{ev.get('to')}{tail}"
    if k == "kind":
        return f"I went from {ev.get('from')} to {ev.get('to')}{tail}"
    if k == "appeared":
        return f"I came into the story ({ev.get('as')}){tail}"
    if k in ("persona", "whereabouts", "picture", "tier", "sealed", "unsealed", "gone", "departed", "returned"):
        return {"persona": "who I am was written down", "whereabouts": "I went somewhere offscreen",
                "picture": f"the GM's picture of me is {ev.get('id')} now", "tier": f"tier {ev.get('to')} now",
                "sealed": "sealed (the crew doesn't know me yet)", "unsealed": "the crew has met me",
                "gone": "gone from the record", "departed": "I went home to the character ledger",
                "returned": "back from the character ledger"}[k] + tail
    return f"{k}{tail}"


def text(d: Path | str, who: str, turn: int | None = None, lately: int = 6) -> str:
    """The perspective, to read: first person, GM-side (it holds their secrets, their views, what the GM knows)."""
    d = Path(d)
    m = mind_at(d, who, turn)
    if m is None:
        return f"No minds file in {d}" + (f" at or before T{turn}." if turn else ".")
    cat = fmt.catalog_at(fmt.read_catalog(d), m["turn"])
    names, me = m["names"], m["character"]
    n = lambda x: _name(names, cat, x)            # noqa: E731
    head = (f"{m['name']} [{m['id']}] at T{m['turn']}" + (f" (asked for T{m['asked']})" if m["asked"] not in
                                                         (None, m["turn"]) else "")
            + (" - reconstructed by backfill" if m["reconstructed"] else ""))
    who_ = [f"a player character until T{me['former_pc']}, the GM's since" if me["former_pc"] else me["kind"],
            me["condition"] or "", f"tier {me['tier']}"]
    out = [head, "  " + ", ".join(x for x in who_ if x)]
    w = m["where"]
    if w["scene"]:                                # (a closed scene's node holds its summary: its title is the head)
        title = _clip((w["scene_title"] or "").split(". ", 1)[0], 70)
        out.append(f"  Where I am: S{w['scene']}" + (f" {title}" if title else "")
                   + (f", with {', '.join(n(x) for x in w['with'])}" if w["with"] else ""))
    if w["whereabouts"]:
        out.append(f"  Last moved to: {w['whereabouts']}")
    turns = [s for s in m["witnessed"] if s[:1] == "T"]
    out.append(f"I've lived through {len(m['witnessed'])} moment(s) ({len(turns)} at the table"
               + (f", {turns[0]}..{turns[-1]}" if turns else "") + f"), and heard of {len(m['knows'])} second-hand.")
    if m["salience"]:
        out.append(f"On my mind (the hottest of what I know, x the mean; {m['salience_source']}):")
        out += [f"  {r:6.2f}  [{nid}] ({how}) {_clip(t)}" for nid, r, how, t in m["salience"]]
    if m["salience_people"]:
        out.append("Who's on my mind: " + ", ".join(f"{nm} {r:.1f}" for _, r, nm in m["salience_people"][:8]))
    if m["beliefs"]:
        out.append("How I see people:")
        for b in sorted(m["beliefs"], key=lambda b: -abs(m["attitudes"].get(b["about"], 0) or 0)):
            att = m["attitudes"].get(b["about"])
            out.append(f"  {_sign(att) if att is not None else ' ?'} {n(b['about'])} [{b['id']}, T{b['created_turn']}]: "
                       f"\"{_clip(b['text'], 120)}\"")
    rest = {a: v for a, v in m["attitudes"].items() if a not in {b["about"] for b in m["beliefs"]}}
    if rest:
        out.append("  (numbers without a view on file: " + ", ".join(f"{n(a)} {_sign(v)}" for a, v in rest.items())
                   + ")")
    if m["toward"]:
        out.append("How they feel about me: " + ", ".join(f"{n(h)} {_sign(v)}" for h, v in
                                                          sorted(m["toward"].items(), key=lambda kv: -kv[1])))
    goals = [a for a in m["agendas"] if a["status"] == "active"]
    if goals:
        out.append("What I'm after:")
        out += [f"  [{a['id']}] {_clip(a['text'], 130)} ({a['steps']} step(s), since T{a['created_turn']})"
                for a in goals]
    if m["knows"]:
        out.append("What I was told (newest first):")
        for k in sorted(m["knows"], key=lambda k: -(k["turn"] or 0))[:8]:
            src = f" by {n(k['source'])}" if k["source"] else ""
            out.append(f"  T{k['turn']} {k['how']}{src} [{k['node']}]: {_clip(k['text'], 110)}")
    if m["carries"]:
        out.append("What I carry: " + ", ".join(f"{h['name']} [{h['item']}]" + (f" x{h['qty']}" if h["qty"] != 1
                                                                                  else "") for h in m["carries"]))
    try:
        tl = [x for x in timeline(d, m["id"]) if x["turn"] <= m["turn"]][-lately:]
    except KeyError:
        tl = []
    if tl:
        out.append(f"Lately (the last {len(tl)} turn(s) with something of mine):")
        for x in tl:
            out.append(f"  T{x['turn']}:" + (f" I was there for {', '.join(x['witnessed'])}" if x["witnessed"]
                                             else ""))
            out += [f"    - {_event_line(e, names, cat)}" for e in x["events"]]
    sure: dict[str, list[str]] = {}               # (the file's exactness map, by how sure: the details are in it)
    for k, v in m["exactness"].items():
        if k != "*" and not str(v).startswith("exact"):
            sure.setdefault(str(v).split(":", 1)[0].split()[0], []).append(k)
    if sure:
        out.append("(how sure the file is - " + "; ".join(f"{how}: {', '.join(ks)}" for how, ks in sure.items())
                   + "; the rest exact)")
    return "\n".join(out)
