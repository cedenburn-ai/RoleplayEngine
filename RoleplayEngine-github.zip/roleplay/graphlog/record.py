"""The forward log: after every committed turn, the graph and the turn's process to campaigns/<campaign>_graph/.

Two hooks feed it. Substrate.touch hands each touch to the Recorder (what was deposited where, by whom - the caller is
read off the stack, so no caller changes); Substrate.renormalize says when a scene close divided by the mean. After
the turn's snapshot (turn._record_metrics, right after Substrate.observe) `after_turn` reads the graph, diffs it
against the last file, parses what the packet surfaced and writes the file. The buffer between files is on disk as it
grows (pending.jsonl): a restart between turns keeps the offscreen world's touches. Nothing here may cost or fail a
turn: every entry point catches and logs (as flags.record does), and with the log off the recorder isn't even attached.
"""
from __future__ import annotations

import json
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from . import fmt, minds

# Why a touch happened, by who called Substrate.touch ("module:function", the roleplay. prefix dropped). The memory
# pass's two touches are told apart by their origins: the slice touch's only origin is the turn's own new slice (the
# quantum can't tell them - retrieval_quantum is a knob, and at 1.0 every retrieval read as a slice).
WHY_BY_CALLER = {"dm.turn:run_turn": "gm-facts",          # the GM's <dm> facts, held until the memory pass placed them
                 "dm.turn:askdm": "askdm-lookup", "setup:seed_history": "seed"}
WHY_BY_MODULE = {"dm.aside": "aside-lookup", "dm.minds": "belief", "dm.world": "offscreen",
                 "encounters": "fight-memory", "setup": "seed", "dm.witness": "askdm-lookup",
                 "newparty": "new-party",                # (the old crew's minds, at a new party)
                 "seed": "seed"}                         # (a story seed read in, and its opening)
KNOB_NAMES = ("touch_quantum", "propagation_share", "negligibility_fraction", "propagation_floor_ratio", "wave_cap",
              "traversal_carves", "retrieval_quantum", "lookup_quantum", "spine_strength", "recall_strength")
# What a recorder that can't vouch for everything since the last file marks "partial" (exactness): the buffer's fields
GAP_FIELDS = ("process.touches", "process.deposits", "nodes.deposited", "process.renormalized", "process.marks")
BOOKS_TOLERANCE = 1e-6        # of the total: float sums close to ~1e-12, one missed touch mints ~half the mean


def why_of(by: str, origins, turn: int) -> str:
    if by == "dm.commit:commit_turn":
        return "slice" if list(origins) == [f"T{int(turn)}"] else "retrieval"
    return WHY_BY_CALLER.get(by) or WHY_BY_MODULE.get(by.split(":")[0]) or by


def enabled(game) -> bool:
    """On unless settings.graph_log is False (every campaign) or the campaign's own switch is off
    (`python -m roleplay.graphlog off <campaign>`)."""
    return bool(getattr(game.settings, "graph_log", True)) and game.ledger.meta("graphlog", "on") != "off"


def attach(game) -> None:
    """Game.__init__: give the campaign's substrate a recorder (left None when the log is off - then it costs nothing)."""
    try:
        retire_former(game)
    except Exception as exc:
        _say(game, f"a former world's log under this name couldn't move aside: {exc}")
    try:
        if getattr(game.settings, "graph_log", True):
            game.sub.recorder = Recorder(game)
    except Exception as exc:                      # (the log is never a reason a campaign doesn't open)
        _say(game, f"graph log off this run: {exc}")


def retire_former(game) -> Path | None:
    """A world with no turns has no log yet: turn files under its name are a former world's - console/autoplay --new
    and multisim delete the .db and start over under the same name, and the new world's files overwrote the old one a
    turn at a time while the rest stayed and read as its own. Moved to archive/ beside it (as archive_campaign moves
    the folder with its world), never deleted."""
    d = fmt.log_dir(game.path)
    if not fmt.turns_on_file(d) or game.turn_no():
        return None
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = d.parent / "archive" / f"{game.path.stem}-{stamp}{fmt.DIR_SUFFIX}"
    n = 1
    while dest.exists():                          # (two fresh starts in one second: a sim's setup, a test)
        n += 1
        dest = d.parent / "archive" / f"{game.path.stem}-{stamp}-{n}{fmt.DIR_SUFFIX}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    d.rename(dest)
    _say(game, f"a former world's log under this name moved to {dest}")
    return dest


def _say(game, line: str) -> None:
    try:
        game.out(f"  (graph log: {line})")
    except Exception:
        pass


class Recorder:
    """What the substrate did since the last snapshot - touches (with every deposit), renormalizations and marks: the
    buffer the next turn file takes. It is on disk as it grows (fmt.PENDING), because the offscreen world touches right
    after every turn and the bot restarts between turns (a deploy, a crash, a session's end): held only in memory those
    deposits were lost while the record kept them, and the next file still said exact. `base` is the turn file the
    buffer counts from; `gap` says why it may not hold everything since (that file's touches then read "partial")."""

    def __init__(self, game):
        self.dir = fmt.log_dir(game.path)
        self.campaign = game.path.stem
        self.conn = game.conn
        self.lock = threading.RLock()             # (re-entrant: an append that finds the file unsynced persists it)
        self.touches: list[dict] = []
        self.renorms: list[dict] = []
        self.marks: list[dict] = []               # what the engine set down between turns (a new party): mark()
        self.prev: dict | None = None             # the last file's state, for the diffs (None: read it from disk)
        self.minds_prev: dict | None = None       # the last minds file's state (minds.py; None: read it from disk)
        self.minds_before: dict | None = None     # the minds as a seed found them, for its own file (before_seed)
        self.catalog: dict[str, str] | None = None   # id -> hash of the text on file (None: read the catalog)
        self.base: int | None = None              # the newest turn file: the buffer holds what happened since it
        self.gap: str | None = None               # why the buffer may not hold all of that (None: it does)
        self.on = enabled(game)                   # (the campaign's switch, as the last turn read it: off, no disk)
        self.synced = False                       # pending.jsonl has the header: lines can be appended to it
        self._resume()

    def _resume(self) -> None:
        """The buffer as the last process left it. Reading only - a second Game on this world (the dashboard's) must
        not rewrite the bot's. A buffer counted from an older file than the newest went into that file before a crash
        could reset it; none at all beside files on disk means what came after the newest was never recorded (a log
        backfilled before the recorder started, an older recorder that kept its buffer in memory)."""
        on_file = fmt.turns_on_file(self.dir)
        self.base = on_file[-1] if on_file else None
        head, items = fmt.read_pending(self.dir)
        if head is not None and head.get("turn") == self.base:
            lists = {"touch": self.touches, "renorm": self.renorms, "mark": self.marks}
            for item in items:
                if item.get("k") in lists and isinstance(item.get("ev"), dict):
                    lists[item["k"]].append(item["ev"])
            self.gap = head.get("gap")
        elif self.base is not None:
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self.gap = (f"touches after T{self.base}'s file and before {now} (when this recorder started) weren't "
                        "recorded" + ("" if head is None else f" - the buffer on disk counted from "
                                                               f"T{head.get('turn')}, older than that file"))

    def _items(self) -> list[dict]:
        return ([{"k": "base", "turn": self.base, "gap": self.gap}] + [{"k": "touch", "ev": e} for e in self.touches]
                + [{"k": "renorm", "ev": e} for e in self.renorms] + [{"k": "mark", "ev": e} for e in self.marks])

    def persist(self) -> None:
        """pending.jsonl = the buffer as it stands (after a turn file, a clear, a rewind, an undo)."""
        try:
            if not self.on and not self.dir.exists():
                return                            # (a campaign whose log is off and never had one: no folder)
            with self.lock:                       # (under the lock: the file is the buffer, line for line)
                fmt.write_pending(self.dir, self._items())
                self.synced = True
        except Exception:
            self.synced = False

    def _append(self, kind: str, ev: dict) -> None:
        """One more line as it happens - the whole buffer with its header the first time this process writes."""
        if not self.on:
            return                                # (the log is off: the next turn drops the buffer anyway)
        try:
            with self.lock:
                if self.synced:
                    fmt.append_pending(self.dir, {"k": kind, "ev": ev})
                else:
                    self.persist()
        except Exception:
            self.synced = False

    # ── the substrate's hooks ───────────────────────────────────────────
    def touched(self, origins, turn: int, ratio: float, counts: bool, graph, stats) -> None:
        try:
            caller = sys._getframe(2)             # (0 this, 1 Substrate.touch, 2 whoever touched)
            mod = str(caller.f_globals.get("__name__", "?")).removeprefix("roleplay.")
            by = f"{mod}:{caller.f_code.co_name}"
            deposited = dict(graph.deposited)
            used = [o for o in dict.fromkeys(origins) if o in graph.energy]
            if not used:
                return                            # (a fight round's empty touch: nothing happened)
            before = (graph.total - sum(deposited.values())) / graph.count if graph.count else 0.0
            ev = {"turn": int(turn), "by": by, "why": why_of(by, used, turn), "quantum_ratio": ratio,
                  "counts_as_touch": bool(counts), "origins": used,
                  "skipped": [o for o in dict.fromkeys(origins) if o not in graph.energy],
                  "mean_before": before, "stats": dict(stats.__dict__), "diode_hops": graph.diode_hops,
                  "deposited": deposited}
            with self.lock:                       # (the buffer and its line together)
                self.touches.append(ev)
                self._append("touch", ev)
        except Exception:
            pass

    def renormalized(self, mean: float, turn: int | None = None) -> None:
        try:
            if turn is None:                      # (a scene close, mid-commit: the turn under way is the newest row)
                turn = self.conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0]
            ev = {"turn": turn, "mean": mean}
            with self.lock:
                self.renorms.append(ev)
                self._append("renorm", ev)
        except Exception:
            pass

    def clear(self, before: int | None = None, gap: str | None = None) -> None:
        """Drop the buffer (before=N: only what happened at turn N or later - an undo's). Dropping all of it leaves the
        next file short: `gap` says why (the first reason stands until a file is written)."""
        with self.lock:
            if before is None:
                self.touches, self.renorms, self.marks = [], [], []
                self.gap = self.gap or gap
            else:
                self.touches = [e for e in self.touches if e["turn"] < before]
                self.renorms = [e for e in self.renorms if (e.get("turn") or 0) < before]
                self.marks = [e for e in self.marks if (e.get("turn") or 0) < before]
        self.persist()

    def rolled_back(self, turn: int, kept: tuple[list, list, list] | None, gap: str | None = None) -> None:
        """Game.undo took back `turn`: what happened at it or later goes, and what its file held from before it
        (`kept`: the between-turns touches, renormalizations and marks - the restored record still has them) waits
        for the next file again, counted from the file before it - as complete as the undone file was (`gap`)."""
        touches, renorms, marks = kept or ([], [], [])
        with self.lock:
            self.touches = list(touches) + [e for e in self.touches if e["turn"] < turn]
            self.renorms = list(renorms) + [e for e in self.renorms if (e.get("turn") or 0) < turn]
            self.marks = list(marks) + [e for e in self.marks if (e.get("turn") or 0) < turn]
            self.prev, self.catalog, self.minds_prev = None, None, None
            if kept is not None:                  # (its file was there: the buffer now counts from the one before)
                older = [t for t in fmt.turns_on_file(self.dir) if t < turn]
                self.base, self.gap = (older[-1] if older else None), gap

    def mark(self, ev: dict) -> None:
        """Something the engine did between turns that no touch says - a new party (newparty.py): the crew changed,
        the clock jumped. It rides into the next turn's file (process.marks) and goes on marks.jsonl at once."""
        try:
            with self.lock:
                self.marks.append(ev)
                self._append("mark", ev)
            fmt.append_mark(self.dir, ev)
        except Exception:
            pass

    def checkpoint(self) -> tuple[int, int, int]:
        """Where the buffer stands - for rewind, when what's about to happen may be rolled back."""
        with self.lock:
            return len(self.touches), len(self.renorms), len(self.marks)

    def rewind(self, cp) -> None:
        """The buffer back to a checkpoint: the touches, renormalizations and marks since go (a new party that was
        rolled back, or taken back - the record they described is gone)."""
        if not cp:
            return
        with self.lock:
            self.touches, self.renorms, self.marks = (self.touches[:cp[0]], self.renorms[:cp[1]],
                                                      self.marks[:cp[2]])
        self.persist()

    # ── the turn file ───────────────────────────────────────────────────
    def _caught_up(self, turn: int) -> None:
        """Another process on this world wrote a forward file since this buffer's base (the console's seed: a second
        Game, its own recorder): it took the buffer from pending.jsonl and started it again from its file. This one's
        memory still holds what went in there, so the buffer, the diffs' base and the caches come from disk again -
        what this process touched since is on pending.jsonl after that file's header. (A backfill's reconstructed
        files never carry a buffer: those leave it alone.)"""
        older = [t for t in fmt.turns_on_file(self.dir) if t < turn]
        if not older or older[-1] == self.base or (self.base is not None and older[-1] < self.base):
            return
        try:
            if fmt.read_turn(self.dir, older[-1]).get("reconstructed"):
                return
        except Exception:
            return
        with self.lock:
            self.touches, self.renorms, self.marks = [], [], []
            self.prev, self.catalog, self.minds_prev, self.gap = None, None, None, None
            self._resume()
            self.synced = False

    def write(self, game, ctx=None, info=None, packet: str = "") -> int:
        t0 = time.perf_counter()
        turn = int(ctx.turn_id) if ctx is not None else game.turn_no()
        self._caught_up(turn)
        with self.lock:
            touches, self.touches = self.touches, []
            renorms, self.renorms = self.renorms, []
            marks, self.marks = self.marks, []
            gap = self.gap
        doc, state = build(game, turn, touches, renorms, ctx, info, packet, self._prev(turn), self.campaign, gap)
        doc["process"]["marks"] = marks
        self._catalog_update(game, doc, turn)
        size = fmt.write_turn(self.dir, doc)
        self.prev, self.base, self.gap = state, turn, None     # (on file: the buffer starts again from this one)
        self.persist()
        mind = minds.after_file(self, game, doc, marks)   # who everyone is and what's on their mind (never raises)
        try:
            fmt.append_csv(self.dir, fmt.csv_row(doc, size, (time.perf_counter() - t0) * 1000, mind))
        except Exception as exc:                  # (the quick look missed a row; the turn's file is written)
            _say(game, f"turns.csv missed T{turn} - {type(exc).__name__}: {exc}")
        return size

    def _prev(self, turn: int) -> dict | None:
        """The state of the newest file before `turn` - the cache while it is still the newest on disk, else read off
        disk."""
        older = [t for t in fmt.turns_on_file(self.dir) if t < turn]
        if not older:
            return None
        if self.prev is not None and self.prev["turn"] == older[-1]:
            return self.prev
        try:
            return state_of(fmt.read_turn(self.dir, older[-1]))
        except Exception:
            return None

    def _catalog_update(self, game, doc: dict, turn: int) -> None:
        if self.catalog is None:
            self.catalog = {e["id"]: e.get("hash") or fmt.text_hash(e.get("text"))
                            for e in fmt.catalog_at(fmt.read_catalog(self.dir)).values()}
        fresh, changed = catalog_entries(game.conn, self.catalog, turn)
        fmt.append_catalog(self.dir, fresh)
        for e in fresh:
            self.catalog[e["id"]] = e["hash"]
        doc["process"]["text_changed"] = changed


def catalog_entries(conn, have: dict[str, str], turn: int) -> tuple[list[dict], list[str]]:
    """Catalog lines for nodes new to the catalog or whose text changed, and the ids that changed."""
    ekind = {r[0]: r[1] for r in conn.execute("SELECT id, kind FROM entities")}
    out, changed = [], []
    for r in conn.execute("SELECT id, kind, text, created_turn, scene_id FROM nodes"):
        h = fmt.text_hash(r[2])
        if have.get(r[0]) == h:
            continue
        if r[0] in have:
            changed.append(r[0])
        e = {"id": r[0], "kind": r[1], "ekind": ekind.get(r[0]), "created_turn": r[3], "scene_id": r[4],
             "since": turn, "hash": h, "text": r[2]}
        if r[1] == "slice":
            e["members"] = [[m[0], m[1]] for m in conn.execute(
                "SELECT node_id, role FROM members WHERE slice_id=? ORDER BY rowid", (r[0],))]
        out.append(e)
    return out, changed


def state_of(doc: dict) -> dict:
    """What a turn file's successor diffs against."""
    nodes = doc["nodes"]
    i_id = nodes["columns"].index("id")
    links = doc["links"]
    c = {k: links["columns"].index(k) for k in ("a", "b", "kind", "strength")}
    return {"turn": doc["meta"]["turn"], "reconstructed": bool(doc.get("reconstructed")),
            "total": doc["meta"].get("total"), "nodes": {r[i_id] for r in nodes["rows"]},
            "links": {(r[c["a"]], r[c["b"]]): r[c["strength"]] for r in links["rows"]},
            "supersedes": {(r[0], r[1]) for r in doc.get("supersedes") or []},
            "knows": {(r[0], r[1]) for r in doc.get("knows") or []},
            "doubts": {r[0]: r[1] for r in doc.get("doubts") or []},
            "presented": set((doc.get("process") or {}).get("table_presented") or [])}


def _fight(game, scene_id: int | None, turn: int) -> dict | None:
    """The fight on in the scene at the snapshot (or the one that ended this turn) - a fight round is a turn too."""
    if scene_id is None:
        return None
    r = game.conn.execute("SELECT id, round, status, started_turn FROM encounters WHERE scene_id=? AND "
                          "(status='active' OR ended_turn=?) ORDER BY id DESC LIMIT 1", (scene_id, turn)).fetchone()
    return {"id": r[0], "round": r[1], "status": r[2], "started_turn": r[3]} if r else None


def presented_since(conn, turn: int, prev: dict | None) -> list[str]:
    """The portraits first shown big since the last file. The Discord table shows them after run_turn returns - after
    that turn's file - stamped with its number (presented.turn = turn_no()), so `WHERE turn=?` never found one: what's
    stamped at or after the last file's turn and wasn't in it is new (a stamp is never older than the file before
    it)."""
    rows = conn.execute("SELECT entity_id, turn FROM presented ORDER BY turn, rowid").fetchall()
    if prev is None:
        return [r[0] for r in rows if r[1] == turn]
    logged = prev.get("presented") or set()
    return [r[0] for r in rows if (r[1] or 0) >= prev["turn"] and r[0] not in logged]


def build(game, turn: int, touches: list[dict], renorms: list[dict], ctx, info, packet: str, prev: dict | None,
          campaign: str, gap: str | None = None) -> tuple[dict, dict]:
    """One turn's document, and the state the next one diffs against. `gap`: why the touches may not be all of them
    (Recorder.gap) - those fields go "partial"."""
    c, knobs = game.conn, game.settings.knobs
    rows = c.execute("SELECT n.id, n.kind, n.created_turn, n.scene_id, n.visibility, e.energy, e.touch_count, "
                     "e.last_touched_turn FROM nodes n LEFT JOIN energy e ON e.node_id=n.id ORDER BY n.rowid").fetchall()
    energies = [r[5] for r in rows if r[5] is not None]
    total = sum(energies)
    mean = total / len(energies) if energies else 0.0
    arrows = {r[0]: r[1] for r in c.execute("SELECT old_id, new_id FROM supersedes ORDER BY confidence ASC")}
    dep: dict[str, float] = {}
    for ev in touches:
        for nid, amount in ev["deposited"].items():
            dep[nid] = dep.get(nid, 0.0) + amount
    # (deposited at 12 digits: a newborn's birth energy is its energy less it - the books close on that, not to 1e-6)
    nodes = [[r[0], r[1], r[2], r[3], r[4], r[5], fmt.rnd(r[5] / mean) if r[5] is not None and mean else None,
              r[6], r[7], arrows.get(r[0]), fmt.rnd(dep[r[0]], 12) if r[0] in dep else None] for r in rows]
    links = [list(r) for r in c.execute("SELECT a, b, kind, strength, together, last_turn FROM links ORDER BY id")]
    sup = [list(r) for r in c.execute("SELECT old_id, new_id, confidence, installed_by, turn FROM supersedes "
                                      "ORDER BY turn, rowid")]
    knows = [list(r) for r in c.execute("SELECT holder, node_id, how, source, turn FROM knows ORDER BY turn, rowid")]
    doubts = [list(r) for r in c.execute("SELECT id, status, raised_turn, resolved_turn FROM doubts ORDER BY rowid")]

    # ── the diffs against the last file ──
    ids = {r[0] for r in rows}
    lmap = {(r[0], r[1]): r[3] for r in links}
    if prev is not None:
        new_nodes = [r[0] for r in rows if r[0] not in prev["nodes"]]
        removed_nodes = sorted(prev["nodes"] - ids)
        new_links = [r[:4] for r in links if (r[0], r[1]) not in prev["links"]]
        changes = [[a, b, prev["links"][(a, b)], s] for (a, b), s in lmap.items()
                   if (a, b) in prev["links"] and prev["links"][(a, b)] != s]
        removed_links = [list(k) for k in prev["links"] if k not in lmap]
        new_sup = [r for r in sup if (r[0], r[1]) not in prev["supersedes"]]
        new_knows = [r for r in knows if (r[0], r[1]) not in prev["knows"]]
        raised = [d[0] for d in doubts if d[1] == "open" and prev["doubts"].get(d[0]) != "open"]
        settled = [d[0] for d in doubts if d[1] != "open" and prev["doubts"].get(d[0]) == "open"]
    else:                                          # (no file before this one: what this turn's turn numbers say)
        new_nodes = [r[0] for r in rows if r[2] == turn]
        removed_nodes, removed_links, changes = [], [], []
        new_links = [r[:4] for r in links if r[5] == turn]
        new_sup = [r for r in sup if r[4] == turn]
        new_knows = [r for r in knows if r[4] == turn]
        raised = [d[0] for d in doubts if d[2] == turn]
        settled = [d[0] for d in doubts if d[3] == turn]

    # ── the process ──
    recalled = set((info or {}).get("recalled") or [])
    expanded = set(getattr(ctx, "expanded", None) or ())
    # the engine puts the facts the GM writes (establish_fact, a <dm> fact) with what it opened, for their retrieval
    # touch - made this turn, they're its own words, not a lookup (V5 §5's expansion choice is what it opened)
    born_here = {r[0] for r in rows if r[2] == turn} & set(new_nodes)
    authored = expanded & born_here
    mentioned = {e for e, r in ((info or {}).get("members") or {}).items() if r == "mentioned"}
    out_touches, deposits = [], []
    for i, ev in enumerate(touches):
        t = {k: v for k, v in ev.items() if k != "deposited"}
        t["i"] = i
        t["phase"] = "turn" if ev["turn"] == turn else "between"
        t["mean_before"] = fmt.rnd(ev["mean_before"], 12)
        if ev["why"] == "retrieval" and t["phase"] == "turn":
            t["origin_why"] = {o: "recalled" if o in recalled else "authored" if o in authored
                               else "looked-up" if o in expanded else "mentioned" if o in mentioned else "other"
                               for o in ev["origins"]}
        out_touches.append(t)
        deposits += [[i, nid, fmt.rnd(a)] for nid, a in ev["deposited"].items()]
    looked = None
    if ctx is not None:
        looked = {"expanded": sorted(expanded - authored), "authored": sorted(authored),
                  "seen": list(getattr(ctx, "seen", None) or ()),
                  "tools": list(getattr(ctx, "tool_names", None) or ()), "recalled": sorted(recalled)}
    presented = presented_since(c, turn, prev)
    # the books, as the file is written: energy is only ever minted by a touch, born at a node's creation, divided by
    # a renormalization or moved by a merge - so the change since the last file must be the touches' mint plus what
    # the newborns were born with. If it isn't, something touched that the recorder never saw (another process on
    # this world, a path no hook covers): the file says so rather than claim it's whole
    if gap is None and prev is not None and prev.get("total") is not None and not renorms:
        born = sum(r[5] - dep.get(r[0], 0.0) for r in rows if r[5] is not None and r[0] not in prev["nodes"])
        minted = sum((ev.get("stats") or {}).get("energy_minted") or 0.0 for ev in touches)
        off = total - prev["total"] - minted - born
        if abs(off) > BOOKS_TOLERANCE * max(abs(total), 1.0):
            gap = (f"the books don't close: {off:+.6g} of energy since T{prev['turn']}'s file that no recorded touch "
                   "accounts for")
    exactness = {"*": "exact"}
    if gap:
        exactness.update({k: f"partial: {gap}" for k in GAP_FIELDS})
    scene_id = getattr(ctx, "scene_id", None)
    if scene_id is None:
        s = game.ledger.current_scene()
        scene_id = s["id"] if s else None
    met = c.execute("SELECT * FROM turn_metrics WHERE turn=?", (turn,)).fetchone()
    metrics = dict(met) if met else {}
    for key in ("stats", "tools"):                 # (JSON in the table: JSON in the file)
        if isinstance(metrics.get(key), str):
            try:
                metrics[key] = json.loads(metrics[key])
            except ValueError:
                pass
    if not met:                                    # (a seeded turn: the engine's numbers from the energies themselves)
        metrics.update(observe_numbers(energies))
    slice_id = (info or {}).get("slice_id") if info is not None else (f"T{turn}" if f"T{turn}" in ids else None)
    doc = {
        "schema": fmt.SCHEMA, "reconstructed": False, "exactness": exactness,
        "meta": {"campaign": campaign, "turn": turn, "scene_id": scene_id, "slice_id": slice_id,
                 "private": getattr(ctx, "private", None), "fight": _fight(game, scene_id, turn),
                 "story_time": game.clock(), "session": game.ledger.session(), "mean": mean, "total": total,
                 "nodes": len(rows), "citizens": len(energies), "links": len(links),
                 "knobs": {k: getattr(knobs, k, None) for k in KNOB_NAMES},
                 "diff_since": prev["turn"] if prev else None,
                 "diff_base_reconstructed": bool(prev and prev.get("reconstructed")),   # (its links: approximate)
                 "written_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
        "metrics": metrics,
        "nodes": fmt.table(fmt.NODE_COLUMNS, nodes),
        "links": fmt.table(fmt.LINK_COLUMNS, links),
        "supersedes": sup, "knows": knows, "doubts": doubts,
        "process": {
            "touches": out_touches, "deposits": fmt.table(fmt.DEPOSIT_COLUMNS, deposits),
            "surfaced": fmt.surfaced(packet, ids) if packet else {},
            "looked_up": looked,
            "new_nodes": new_nodes, "removed_nodes": removed_nodes,
            "new_links": fmt.table(["a", "b", "kind", "strength"], new_links),
            "strength_changes": fmt.table(["a", "b", "old", "new"], changes), "removed_links": removed_links,
            "supersessions": new_sup, "knows_added": new_knows, "doubts_raised": raised, "doubts_settled": settled,
            "renormalized": renorms, "text_changed": [],
            "table_presented": presented,
        },
    }
    state = {"turn": turn, "total": total, "nodes": ids, "links": lmap, "supersedes": {(r[0], r[1]) for r in sup},
             "knows": {(r[0], r[1]) for r in knows}, "doubts": {d[0]: d[1] for d in doubts},
             "presented": set(presented)}
    return doc, state


def observe_numbers(energies: list[float]) -> dict:
    """Substrate.observe's summary of a distribution (warm >= mean, hot >= 2x, gini, top-5 share) - the same
    definitions, for turns that have no turn_metrics row and for the analysis."""
    if not energies:
        return {"warm": 0, "hot": 0, "gini": 0.0, "top5_share": 0.0}
    es = sorted(energies, reverse=True)
    total = sum(es)
    n = len(es)
    mean = total / n
    asc = es[::-1]
    gini = (2 * sum((i + 1) * e for i, e in enumerate(asc)) / (n * total) - (n + 1) / n) if total else 0.0
    return {"warm": sum(1 for e in es if e >= mean), "hot": sum(1 for e in es if e >= 2 * mean), "gini": gini,
            "top5_share": sum(es[:5]) / total if total else 0.0}


# ── the entry points (each catches everything: the log never costs a turn) ──
def after_turn(game, ctx=None, info=None, packet: str = "", obs=None):
    """After the turn's snapshot: write its file. Returns the file's size in bytes, or None (off, or it failed)."""
    rec = getattr(game.sub, "recorder", None)
    if rec is None:
        return None
    turn = getattr(ctx, "turn_id", None) or "?"
    try:
        turn = getattr(ctx, "turn_id", None) or game.turn_no()
        rec.on = enabled(game)
        if not rec.on:
            rec.clear(gap=f"the log was off from T{turn} (its touches went unrecorded)")
            return None
        return rec.write(game, ctx, info, packet)
    except Exception as exc:
        rec.prev = None                            # (read the last good file next time)
        rec.clear(gap=f"T{turn}'s file wasn't written ({type(exc).__name__}) - its touches went with it")
        _say(game, f"T{turn} not written - {type(exc).__name__}: {exc}")
        return None


def before_seed(game) -> None:
    """seed.apply, before its first change: the minds as they stand, so the seed's own file can tell what the seed did
    from what came just before it (a new party's catch-up, the offscreen world). Never raises."""
    rec = getattr(game.sub, "recorder", None)
    if rec is not None and rec.on:
        minds.before_seed(rec, game)


def kept_by(doc: dict, turn: int) -> tuple[tuple[list, list, list], str | None]:
    """What an undone turn's file held from before it - (between-turns touches with their deposits, renormalizations,
    marks) - and why its touches were partial, if they were."""
    pr = doc.get("process") or {}
    marks = [m for m in pr.get("marks") or [] if (m.get("turn") or 0) < turn]          # (a new party before it)
    deps: dict[int, dict] = {}
    for r in (pr.get("deposits") or {}).get("rows", []):
        deps.setdefault(r[0], {})[r[1]] = r[2]
    touches = []
    for t in pr.get("touches") or []:
        if t.get("phase") == "between":
            ev = {k: v for k, v in t.items() if k not in ("i", "phase", "origin_why")}
            ev["deposited"] = deps.get(t["i"], {})
            touches.append(ev)
    renorms = [r for r in pr.get("renormalized") or [] if (r.get("turn") or 0) < turn]
    note = str((doc.get("exactness") or {}).get("process.touches", ""))
    return (touches, renorms, marks), (note.removeprefix("partial: ") if note.startswith("partial") else None)


def undone(game, turn: int) -> None:
    """Game.undo took back `turn`: its file and any later go, turns.csv and the catalog lose their lines, and the touches
    that happened before it began (the offscreen world between turns - still in the restored record) wait for the next
    turn's file again. The buffer is put right first and each file step stands alone: a turns.csv held open by a
    spreadsheet (Windows refuses the replace) once skipped everything after it, so the replayed turn logged touches
    the undo had rolled back and lost the ones it had kept."""
    rec = getattr(game.sub, "recorder", None)
    d = fmt.log_dir(game.path)
    kept, gap = None, None
    try:
        if fmt.turn_file(d, turn).exists():
            kept, gap = kept_by(fmt.read_turn(d, turn), turn)
    except Exception as exc:
        kept = ([], [], [])
        gap = f"T{turn}'s file couldn't be read at its undo - the touches it held from before it are lost"
        _say(game, f"undo of T{turn}: {type(exc).__name__}: {exc}")
    if rec is not None:
        try:
            rec.rolled_back(turn, kept, gap)
        except Exception as exc:
            _say(game, f"undo of T{turn}: the buffer - {type(exc).__name__}: {exc}")

    def files():
        for t in fmt.turns_on_file(d):
            if t >= turn:
                fmt.turn_file(d, t).unlink(missing_ok=True)
        for t in minds.minds_on_file(d):          # (its minds too: the record they read is gone)
            if t >= turn:
                minds.minds_file(d, t).unlink(missing_ok=True)

    def csv_rows():
        rows = fmt.read_csv(d)
        if any(t >= turn for t in rows):
            fmt.write_csv(d, {t: r for t, r in rows.items() if t < turn})

    def catalog():
        cat = fmt.read_catalog(d)
        if any((e.get("since") or 0) >= turn for e in cat):
            fmt.write_catalog(d, [e for e in cat if (e.get("since") or 0) < turn])
    steps = [("its file", files)] + ([("the buffer on disk", rec.persist)] if rec is not None else []) + [
        ("turns.csv", csv_rows), ("the catalog", catalog)]
    for what, step in steps:
        try:
            step()
        except Exception as exc:
            _say(game, f"undo of T{turn}: {what} not updated - {type(exc).__name__}: {exc}")
