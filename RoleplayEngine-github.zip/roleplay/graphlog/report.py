"""report.html: the analysis as one self-contained page - inline SVG charts drawn by a few lines of script from the
numbers embedded in it, no server, no CDN. Light and dark from the same tokens; hover for the values; every number
also in the tables (and measures.csv)."""
from __future__ import annotations

import html
import json

CHARTS = [   # (id, title, what it tests, [(series key, label)], y range, format, reference line)
    ("pop", "Warm and hot share of citizens", "V5 §7: a stable population (critical), draining to empty "
     "(subcritical) or one lump (supercritical). Warm = ratio >= 1, hot >= 2 (Substrate.observe).",
     [("warm_share", "warm (>= mean)"), ("hot_share", "hot (>= 2x mean)")], [0, None], "pct", None),
    ("conc", "Concentration", "The one-lump test: the top 5% of citizens' share of the energy (half or more: one "
     "lump), inequality, the top five's share and the effective number of nodes (as a share of citizens). The "
     "largest warm connected piece without the PCs is in the evidence and measures.csv.",
     [("top5pct_share", "top 5% share"), ("gini", "gini"), ("top5_share", "top-5 share"),
      ("effective_share", "effective size / citizens")], [0, 1], "pct", None),
    ("jw", "Warm-set turnover", "Jaccard of the warm set against 1, 5 and 10 turns back: 1 = the same nodes. A "
     "critical set holds its size while its membership drifts with distance.",
     [("j1_warm", "vs 1 back"), ("j5_warm", "vs 5 back"), ("j10_warm", "vs 10 back")], [0, 1], "num", None),
    ("jh", "Hot-set turnover", "The same for the hot set (>= 2x): the working set proper.",
     [("j1_hot", "vs 1 back"), ("j5_hot", "vs 5 back"), ("j10_hot", "vs 10 back")], [0, 1], "num", None),
    ("entry", "Who enters the hot set", "Of the hot set, the share that wasn't in it ten turns back: newborn (made "
     "since - every turn's slice starts hot) or re-warmed (an old node back above 2x). Births turn any set over; "
     "re-entries are what 'turns over as topics change' means.",
     [("reentry10_hot", "re-warmed vs 10 back"), ("born10_hot", "newborn vs 10 back"),
      ("reentry1_hot", "re-warmed vs 1 back")], [0, None], "pct", None),
    ("topic", "Does heat follow the topic?", "How much of the turn's slice (its members) is warm, how much of the "
     "hot set is the slice, and how much of what the packet showed was warm.",
     [("topic_warm_share", "slice members warm"), ("hot_in_topic_share", "hot set in the slice"),
      ("surfaced_warm_share", "surfaced and warm")], [0, 1], "pct", None),
    ("growth", "The rising mean", "Mean energy growth per turn (forgetting: everything untouched sinks by this much "
     "relative to the mean). Scene closes renormalize and are left out.",
     [("mean_growth", "mean growth / turn")], [0, None], "pct", None),
    ("mint", "Minted per deposit", "Energy minted / the turn's deposits: the lakes-and-rivers honest mint is 2x "
     "whatever the topology (dashed line).", [("mint_ratio", "minted / deposited")], [0, None], "num", 2.0),
    ("dry", "Dry channels", "Share of links whose two ends are both under half the mean - rivers carved but "
     "barely carrying water (no-delete keeps them).", [("dry_share", "dry links")], [0, 1], "pct", None),
]

FIRST_GROUP = {"pop", "conc", "jw", "jh", "entry", "topic"}     # criticality, turnover and topic; the rest: lakes

PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Graph Log Report</title>
<style>
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--ring:rgba(11,11,11,.10);--s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;--s4:#eda100;
--good:#006300;--warn:#a35f00}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;
--ink:#f0efec;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;--ring:rgba(255,255,255,.10);
--s1:#3987e5;--s2:#d95926;--s3:#199e70;--s4:#c98500;--good:#0ca30c;--warn:#fab219}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;
--muted:#898781;--grid:#2c2c2a;--axis:#383835;--ring:rgba(255,255,255,.10);--s1:#3987e5;--s2:#d95926;--s3:#199e70;
--s4:#c98500;--good:#0ca30c;--warn:#fab219}
*{box-sizing:border-box}
body{margin:0;background:var(--page);color:var(--ink);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1100px;margin:0 auto;padding:24px 16px 64px}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:32px 0 8px}h3{font-size:14px;margin:0 0 2px}
p{margin:6px 0}.sub{color:var(--ink2)}.muted{color:var(--muted);font-size:12px}
.card{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:14px 16px;margin:12px 0}
.verdict{font-size:20px;font-weight:600;margin:2px 0 6px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px}
.chart{position:relative;min-height:230px}.chart svg{display:block;width:100%;height:220px;overflow:visible}
.legend{display:flex;flex-wrap:wrap;gap:4px 14px;margin:6px 0 2px;color:var(--ink2);font-size:12px}
.key{display:inline-block;width:14px;height:2px;vertical-align:middle;margin-right:6px;border-radius:1px}
.tip{position:absolute;pointer-events:none;background:var(--surface);border:1px solid var(--ring);border-radius:8px;
padding:6px 8px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,.12);display:none;white-space:nowrap;z-index:2}
.tip b{font-weight:600}.tip .k{display:inline-block;width:10px;height:2px;margin-right:6px;vertical-align:middle}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;padding:4px 8px;border-bottom:1px solid var(--grid)}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}th{color:var(--ink2);font-weight:600}
.scroll{overflow-x:auto}details summary{cursor:pointer;color:var(--ink2)}
ul{margin:6px 0;padding-left:20px}code{font-size:12px}
</style></head>
<body><main>
<h1>Graph log report</h1>
<p class="sub">__TITLE__</p>
<div class="card"><div class="muted">V5 spec §7 - the regime reading</div><div class="verdict">__REGIME__</div>
<p>__WHY__</p>__EVIDENCE__<p class="muted">Caveats</p><ul>__CAVEATS__</ul></div>
<h2>Criticality, turnover and topic</h2>
<div class="grid" id="charts1"></div>
<div class="card"><h3>Turnover at scene boundaries vs inside a scene</h3>
<p class="muted">If the warm set tracks the query stream, it should turn over faster when the scene (the topic) changes.
1 - Jaccard against the turn before.</p>__BOUNDARY__</div>
<h2>Lakes and rivers</h2>
<div class="grid" id="charts2"></div>
<div class="grid"><div class="card"><h3>Forgetting curve</h3><p class="muted">Median heat by age (turns since a node
was made; born at the mean, so age 0 = 1.0). Untouched, a node sinks under the rising mean.</p>
<div class="chart" id="ages"></div>__AGES__</div>
<div class="card"><h3>The mint and the books</h3>__LAKES__</div></div>
<h2>Echo chamber (V5 §8.9)</h2>
<div class="grid"><div class="card"><h3>Repeat-surfacing intervals</h3><p class="muted">Turns between one surfacing
of a node in the packet and its next, every section.</p><div class="chart" id="intervals"></div></div>
<div class="card"><h3>Persistent core vs topic-clustered</h3>__ECHO__</div></div>
__CHAPTERS__
<h2>Exactness</h2><div class="card">__EXACT__</div>
<h2>Per turn</h2><div class="card"><details><summary>The numbers behind the charts (all of them: measures.csv)</summary>
<div class="scroll">__TABLE__</div></details></div>
</main>
<div class="tip" id="tip"></div>
<script>
const ROWS = __ROWS__;
const CHARTS = __CHARTS__;
const AGES = __AGEDATA__;
const INTERVALS = __INTDATA__;
const NS = "http://www.w3.org/2000/svg";
const tip = document.getElementById("tip");
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const fmt = (v, f) => v == null || isNaN(v) ? "-" : f === "pct" ? (v * 100).toFixed(Math.abs(v) < 0.1 ? 2 : 1) + "%"
  : Math.abs(v) >= 100 ? Math.round(v).toLocaleString() : (+v).toFixed(3);
function el(tag, attrs, parent) {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}
function ticks(lo, hi, n) {
  const span = hi - lo || 1, step0 = span / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const step = [1, 2, 2.5, 5, 10].map(s => s * mag).find(s => s >= step0);
  const out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + step * 1e-6; v += step) out.push(+v.toFixed(10));
  return out;
}
function frame(box, title, desc, legend) {
  const card = document.createElement("div"); card.className = "card";
  const h = document.createElement("h3"); h.textContent = title; card.appendChild(h);
  const p = document.createElement("p"); p.className = "muted"; p.textContent = desc; card.appendChild(p);
  if (legend.length > 1) {
    const lg = document.createElement("div"); lg.className = "legend";
    legend.forEach(([label, color]) => { const s = document.createElement("span"); const k = document.createElement("span");
      k.className = "key"; k.style.background = color; s.appendChild(k); s.appendChild(document.createTextNode(label));
      lg.appendChild(s); });
    card.appendChild(lg);
  }
  const c = document.createElement("div"); c.className = "chart"; card.appendChild(c); box.appendChild(card);
  return c;
}
function showTip(holder, x, y, head, lines) {
  tip.replaceChildren();
  const h = document.createElement("div"); h.className = "muted"; h.textContent = head; tip.appendChild(h);
  lines.forEach(([label, value, color]) => { const d = document.createElement("div");
    if (color) { const k = document.createElement("span"); k.className = "k"; k.style.background = color; d.appendChild(k); }
    const b = document.createElement("b"); b.textContent = value; d.appendChild(b);
    d.appendChild(document.createTextNode("  " + label)); tip.appendChild(d); });
  tip.style.display = "block";
  const r = holder.getBoundingClientRect(), tw = tip.offsetWidth;
  let left = window.scrollX + r.left + x + 14; if (left + tw > window.scrollX + document.documentElement.clientWidth - 8) left -= tw + 28;
  tip.style.left = left + "px"; tip.style.top = (window.scrollY + r.top + y - 10) + "px";
}
function lineChart(holder, spec) {
  holder.replaceChildren();
  const W = holder.clientWidth || 600, H = 220, m = {l: 48, r: 12, t: 8, b: 26};
  const xs = ROWS.map(r => r.turn), colors = spec.series.map((_, i) => css("--s" + (i + 1)));
  const vals = spec.series.flatMap(([k]) => ROWS.map(r => r[k])).filter(v => v != null && !isNaN(v));
  if (!vals.length) { const p = document.createElement("p"); p.className = "muted"; p.textContent = "No data in this log."; holder.appendChild(p); return; }
  let lo = spec.y[0] != null ? spec.y[0] : Math.min(...vals), hi = spec.y[1] != null ? spec.y[1] : Math.max(...vals);
  if (spec.ref != null) hi = Math.max(hi, spec.ref * 1.1);
  if (hi <= lo) hi = lo + 1;
  const x0 = Math.min(...xs), x1 = Math.max(...xs) || x0 + 1;
  const X = t => m.l + (W - m.l - m.r) * (x1 === x0 ? 0.5 : (t - x0) / (x1 - x0));
  const Y = v => m.t + (H - m.t - m.b) * (1 - (v - lo) / (hi - lo));
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": spec.title}, holder);
  ticks(lo, hi, 4).forEach(v => { el("line", {x1: m.l, x2: W - m.r, y1: Y(v), y2: Y(v), stroke: css("--grid"), "stroke-width": 1}, svg);
    const t = el("text", {x: m.l - 6, y: Y(v) + 4, "text-anchor": "end", "font-size": 11, fill: css("--muted")}, svg);
    t.textContent = spec.fmt === "pct" ? Math.round(v * 1000) / 10 + "%" : v; });
  ticks(x0, x1, 6).forEach(v => { const t = el("text", {x: X(v), y: H - 6, "text-anchor": "middle", "font-size": 11, fill: css("--muted")}, svg);
    t.textContent = "T" + v; });
  el("line", {x1: m.l, x2: W - m.r, y1: H - m.b, y2: H - m.b, stroke: css("--axis"), "stroke-width": 1}, svg);
  ROWS.forEach(r => { if (r.boundary) el("line", {x1: X(r.turn), x2: X(r.turn), y1: H - m.b, y2: H - m.b + 4, stroke: css("--axis")}, svg); });
  if (spec.ref != null) el("line", {x1: m.l, x2: W - m.r, y1: Y(spec.ref), y2: Y(spec.ref), stroke: css("--muted"), "stroke-dasharray": "4 4"}, svg);
  spec.series.forEach(([k], i) => {
    let d = "", pen = false;
    ROWS.forEach(r => { const v = r[k]; if (v == null || isNaN(v)) { pen = false; return; }
      d += (pen ? "L" : "M") + X(r.turn).toFixed(1) + " " + Y(Math.min(hi, Math.max(lo, v))).toFixed(1); pen = true; });
    el("path", {d, fill: "none", stroke: colors[i], "stroke-width": 2, "stroke-linejoin": "round", "stroke-linecap": "round"}, svg);
  });
  const cross = el("line", {y1: m.t, y2: H - m.b, stroke: css("--axis"), "stroke-width": 1, visibility: "hidden"}, svg);
  const hit = el("rect", {x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: "transparent", tabindex: 0}, svg);
  const at = px => { let best = 0; ROWS.forEach((r, i) => { if (Math.abs(X(r.turn) - px) < Math.abs(X(ROWS[best].turn) - px)) best = i; }); return best; };
  const show = i => { const r = ROWS[i], px = X(r.turn); cross.setAttribute("x1", px); cross.setAttribute("x2", px); cross.setAttribute("visibility", "visible");
    showTip(holder, px * holder.clientWidth / W, 30, `T${r.turn} · scene S${r.scene_id}${r.reconstructed ? " · reconstructed" : ""}`,
      spec.series.map(([k, label], j) => [label, fmt(r[k], spec.fmt), colors[j]])); };
  hit.addEventListener("pointermove", e => { const b = svg.getBoundingClientRect(); show(at((e.clientX - b.left) * W / b.width)); });
  hit.addEventListener("pointerleave", () => { cross.setAttribute("visibility", "hidden"); tip.style.display = "none"; });
  let kb = ROWS.length - 1;
  hit.addEventListener("focus", () => show(kb));
  hit.addEventListener("keydown", e => { if (e.key === "ArrowLeft") kb = Math.max(0, kb - 1); else if (e.key === "ArrowRight") kb = Math.min(ROWS.length - 1, kb + 1); else return; show(kb); e.preventDefault(); });
  hit.addEventListener("blur", () => { cross.setAttribute("visibility", "hidden"); tip.style.display = "none"; });
}
function barChart(holder, data, label, f) {
  holder.replaceChildren();
  if (!data.length) { const p = document.createElement("p"); p.className = "muted"; p.textContent = "No data in this log."; holder.appendChild(p); return; }
  const W = holder.clientWidth || 600, H = 220, m = {l: 48, r: 12, t: 8, b: 26}, color = css("--s1");
  const hi = Math.max(...data.map(d => d[1] || 0)) || 1;
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": label}, holder);
  const Y = v => m.t + (H - m.t - m.b) * (1 - v / hi);
  ticks(0, hi, 4).forEach(v => { el("line", {x1: m.l, x2: W - m.r, y1: Y(v), y2: Y(v), stroke: css("--grid")}, svg);
    const t = el("text", {x: m.l - 6, y: Y(v) + 4, "text-anchor": "end", "font-size": 11, fill: css("--muted")}, svg); t.textContent = v; });
  const band = (W - m.l - m.r) / data.length, bw = Math.min(24, band * 0.6);
  data.forEach(([k, v], i) => {
    const cx = m.l + band * (i + 0.5), y = Y(v || 0), h = H - m.b - y, r = Math.min(4, h / 2, bw / 2);
    const g = el("g", {tabindex: 0}, svg);
    el("rect", {x: cx - band / 2, y: m.t, width: band, height: H - m.t - m.b, fill: "transparent"}, g);
    el("path", {d: `M${cx - bw / 2} ${H - m.b}V${y + r}Q${cx - bw / 2} ${y} ${cx - bw / 2 + r} ${y}H${cx + bw / 2 - r}Q${cx + bw / 2} ${y} ${cx + bw / 2} ${y + r}V${H - m.b}Z`, fill: color}, g);
    const t = el("text", {x: cx, y: H - 6, "text-anchor": "middle", "font-size": 11, fill: css("--muted")}, svg); t.textContent = k;
    const on = () => showTip(holder, cx * holder.clientWidth / W, y, label + " " + k, [["", f(v), color]]);
    g.addEventListener("pointermove", on); g.addEventListener("focus", on);
    g.addEventListener("pointerleave", () => tip.style.display = "none"); g.addEventListener("blur", () => tip.style.display = "none");
  });
  el("line", {x1: m.l, x2: W - m.r, y1: H - m.b, y2: H - m.b, stroke: css("--axis")}, svg);
}
const holders = [];
CHARTS.forEach((c, i) => {
  const box = document.getElementById(c.group === 1 ? "charts1" : "charts2");
  const h = frame(box, c.title, c.desc, c.series.map(([, label], j) => [label, css("--s" + (j + 1))]));
  holders.push([h, c]);
});
function draw() {
  holders.forEach(([h, c]) => lineChart(h, c));
  barChart(document.getElementById("ages"), AGES, "age", v => fmt(v, "num") + "x the mean");
  barChart(document.getElementById("intervals"), INTERVALS, "interval", v => v + " repeat(s)");
}
draw();
let timer; addEventListener("resize", () => { clearTimeout(timer); timer = setTimeout(draw, 150); });
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", draw);
</script></body></html>
"""

TABLE_KEYS = ["turn", "scene_id", "reconstructed", "citizens", "warm", "hot", "gini", "top5_share", "j1_warm",
              "j10_warm", "j1_hot", "j10_hot", "reentry10_hot", "born10_hot", "mean_growth", "mint_ratio", "dry_share",
              "surfaced"]
TABLE_PCT = {"top5_share", "reentry10_hot", "born10_hot", "mean_growth", "dry_share"}


def _f(v, pct=False) -> str:
    if v is None:
        return "-"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, float):
        return f"{v * 100:.1f}%" if pct else (f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.3f}")
    return html.escape(str(v))


def _table(head: list[str], rows: list[list], numeric: set[int] = frozenset()) -> str:
    th = "".join(f'<th class="{"n" if i in numeric else ""}">{html.escape(h)}</th>' for i, h in enumerate(head))
    trs = "".join("<tr>" + "".join(f'<td class="{"n" if i in numeric else ""}">{c}</td>' for i, c in enumerate(r))
                  + "</tr>" for r in rows)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table>"


EVIDENCE = [("warm_share_mean", "warm share (mean, second half)", True), ("warm_share_cv", "warm share CV", False),
            ("warm_share_slope_per_100", "warm share trend per 100 turns", True),
            ("hot_share_mean", "hot share (mean)", True), ("hot_share_cv", "hot share CV", False),
            ("j1_warm", "warm Jaccard vs 1 back", False), ("j10_warm", "warm Jaccard vs 10 back", False),
            ("j1_hot", "hot Jaccard vs 1 back", False), ("j10_hot", "hot Jaccard vs 10 back", False),
            ("reentry10_hot", "hot set re-warmed vs 10 back (old nodes back)", True),
            ("born10_hot", "hot set newborn vs 10 back", True),
            ("top5pct_share", "top 5% of citizens' share of energy", True),
            ("top5_share", "top-5 share of energy", True), ("gini", "gini", False),
            ("effective_share", "effective size / citizens", True),
            ("warm_lump_no_pc", "largest warm piece (no PCs) / warm", True),
            ("topic_warm_share", "slice members that are warm", True)]


def _topic_row(label: str, t: dict | None) -> list[str]:
    """One topic test (analyze.topic_test) as a table row: the effect, its interval, the placebo p."""
    t = t or {}
    ci = t.get("ci") or [None, None]
    pts = lambda x: "-" if x is None else f"{x * 100:+.1f}"           # noqa: E731
    p = lambda x: "-" if x is None else f"{x:.3f}"                     # noqa: E731
    return [html.escape(label), pts(t.get("mean")), f"{pts(ci[0])} to {pts(ci[1])}",
            f"{p(t.get('p'))} / {p(t.get('p_lower'))}", _f(t.get("events")), _f(t.get("placebos"))]


def _chapters(chapters: list[dict]) -> str:
    """A new party (newparty.py, the log's marks): the old crew's heat across the change of crews - "" if none."""
    if not chapters:
        return ""
    out = ["<h2>Changes of crew</h2>"]
    for c in chapters:
        days = (c.get("gap_minutes") or 0) / 1440
        after = c.get("crew_ratio_after") or []
        out.append(
            f"<div class='card'><h3>After T{_f(c.get('after_turn'))}: {html.escape(', '.join(c['former_pcs']))} "
            f"stop being player characters</h3><p class='muted'>The story skipped {days:.0f} days. Their mean heat "
            f"(energy / mean) over the five files before: {_f(c.get('crew_ratio_before'))}; warm-set Jaccard across "
            f"the change: {_f(c.get('warm_jaccard_across'))}. Nobody plays them now - do they drain like any node left "
            f"untouched, or does the world keep them warm?</p>"
            + (_table(["file", "their mean heat"], [[_f(t), _f(v)] for t, v in after], {0, 1}) if after else "")
            + "</div>")
    return "".join(out)


def render(summary: dict, rows: list[dict]) -> str:
    crit = summary["criticality"]
    ev = crit.get("evidence") or {}
    evidence = _table(["measure", "value"], [[html.escape(label), _f(ev.get(k), pct)] for k, label, pct in EVIDENCE
                                             if k in ev], {1})
    caveats = "".join(f"<li>{html.escape(c)}</li>" for c in crit.get("caveats") or [])
    boundary = _table(["", "warm set", "hot set", "turns"], [
        ["scene changed", _f(ev.get("turnover_at_boundaries"), True), _f(ev.get("hot_turnover_at_boundaries"), True),
         _f(ev.get("boundaries"))],
        ["same scene", _f(ev.get("turnover_inside_scenes"), True), _f(ev.get("hot_turnover_inside_scenes"), True),
         _f(len(rows) - 1 - (ev.get("boundaries") or 0))],
        ["five turns across a change (vs 5 back)", "", _f(ev.get("hot_turnover5_across_a_change"), True), ""],
        ["five turns inside a scene (vs 5 back)", "", _f(ev.get("hot_turnover5_inside_a_scene"), True), ""]],
        {1, 2, 3}) + (
        "<p class='muted'>A cut lands mid-turn and the new scene heats up over the next few turns, so five-turn "
        "windows are compared - and, because turnover drifts as the graph grows, each change against the in-scene "
        "windows within 15 turns of it (a run of changes within five turns counts once). Points of the hot set; the "
        "interval is 95%; p is a placebo test - the log's pattern of changes shifted round the log, how often a "
        "shift does as well. The re-entry test (old nodes back in the hot set) is the one the regime reading uses: "
        "plain turnover counts the newborn slices every turn makes.</p>"
        + _table(["across a change vs around it", "points", "95% interval", "placebo p (as high / as low)",
                  "changes", "shifts"],
                 [_topic_row("re-entries into the hot set (decides)", ev.get("topic_reentry")),
                  _topic_row("hot-set turnover (1 - Jaccard)", ev.get("topic_turnover"))], {1, 3, 4, 5}))
    lk = summary["lakes"]
    mint_rows = [[html.escape(str(k)), _f(v["median"]), _f(v["min"]), _f(v["max"]), _f(v["n"])]
                 for k, v in lk["mint_ratio_by_why"].items()]
    half = lk.get("untouched_half_life_turns")
    q = lk.get("new_link_local_ratio_quartiles")
    lakes = (_table(["touch", "minted / deposit (median)", "min", "max", "touches"], mint_rows, {1, 2, 3, 4})
             + f'<p class="muted">{html.escape(lk["mint_ratio_note"])}. Above 2.0, of the '
               f'{lk["touches_measured"]} touches measured exactly (forward): {lk["mint_over_2"]} '
               f'({lk["diode_touches_over_2"]} of them through a diode). A touch with no recorded deposit '
               f'(reconstructed, or an older file) is measured against its origins x one mean - the last '
               f'snapshot\'s for a reconstruction - so it reads high: every later origin met a higher mean.</p>'
             + _table(["", ""], [
                 ["median mean growth a turn", _f(lk.get("median_mean_growth_per_turn"), True)],
                 ["an untouched node's heat halves in", f"{half:.0f} turns" if half else "-"],
                 ["the books: |change in total - minted - born| / change (median over "
                  f"{_f(lk.get('books_turns'))} exact turns, each one file after the last)",
                  _f(lk.get("books_unexplained_median"), True)],
                 ["dry channels now", _f(lk.get("dry_share_last"), True)],
                 ["new link strength / its ends' local mean (median)", _f(lk.get("new_link_local_ratio_median"))],
                 ["... quartiles", " / ".join(_f(x) for x in q) if q else "-"],
                 ["rehydrations (under 0.25x the mean to 0.5x or more in one turn)", _f(lk.get("rehydrations"))]],
                {1}))

    def core(e: dict, what: str) -> str:
        if not e.get("turns"):
            return f"<p class='muted'>{what}: no surfacing data in this log.</p>"
        body = _table(["node", "turns", "scenes", "text"], [[html.escape(c["id"]), _f(c["turns"]), _f(c["scenes"]),
                                                             html.escape(c["text"])] for c in e["core"][:12]], {1, 2})
        return (f"<p><b>{what}</b>: {e['nodes']} nodes surfaced {e['surfacings']} times over {e['turns']} turns. "
                f"Persistent core (in half the turns or more, across half the scenes or more): {len(e['core'])} "
                f"node(s), {e['core_share'] * 100:.1f}% of all surfacings; topic-clustered (80%+ of a node's "
                f"surfacings in one scene, 5+ surfacings): {e['clustered']}.</p>" + (body if e["core"] else ""))
    echo = (core(summary["echo_all_sections"], "Every section")
            + core(summary["echo_energy_ranked"], "The energy-ranked sections (facts in play, associated memories)")
            + "<p class='muted'>Who's in the room is printed every turn by design (the PRESENT section), so the core "
              "of every section is partly the fixtures; the energy-ranked sections are where heat chooses what is "
              "shown - the self-confirmation loop §8.9 worries about. In this engine being shown is not a touch "
              "(only what the turn drew on is): surfaced and also a touch origin this turn, on average: "
            + _f(summary["topic"].get("surfaced_origin_share_mean"), True) + ".</p>")
    ages = summary["lakes"]["forgetting_curve"]
    age_table = _table(["age (turns)", "median heat", "nodes"], [[_f(a), _f(m), _f(n)] for a, m, n in ages], {0, 1, 2})
    exact = summary.get("exactness") or {}
    partial = summary.get("partial_turns") or {}
    exact_html = ("<p>Every turn file is exact (written forward).</p>" if not exact and not partial else
                  "" if not exact else "<p>Reconstructed files (backfill) carry this exactness map:</p>"
                  + _table(["field", "how exact"], [[html.escape(k), html.escape(v)] for k, v in sorted(exact.items())]))
    if partial:                                    # (forward files whose touches the recorder couldn't vouch for)
        exact_html += (f"<p>{len(partial)} forward file(s) say their touches are partial - left out of the books:</p>"
                       + _table(["file", "why"], [[f"T{t}", html.escape(why)] for t, why in sorted(partial.items())]))
    table = _table(TABLE_KEYS, [[_f(r.get(k), k in TABLE_PCT) for k in TABLE_KEYS] for r in rows],
                   set(range(len(TABLE_KEYS))))
    charts = [{"id": c[0], "title": c[1], "desc": c[2], "series": c[3], "y": c[4], "fmt": c[5], "ref": c[6],
               "group": 1 if c[0] in FIRST_GROUP else 2} for c in CHARTS]
    keep = {k for c in CHARTS for k, _ in c[3]} | {"turn", "scene_id", "boundary", "reconstructed"}
    data = [{k: (v if not isinstance(v, float) else round(v, 6)) for k, v in r.items() if k in keep}
            for r in rows]
    for r, src in zip(data, rows):
        r["effective_share"] = round(src["effective_n"] / src["citizens"], 6) if src.get("effective_n") and \
            src.get("citizens") else None
    chapters = _chapters(summary.get("chapters") or [])
    title = (f"{summary['log']} - {summary['turns']} turn(s), T{summary['first_turn']}..T{summary['last_turn']}; "
             f"{summary['exact_turns']} written forward, {summary['reconstructed_turns']} reconstructed")
    js = lambda o: json.dumps(o).replace("</", "<\\/")       # noqa: E731
    out = PAGE
    for key, val in (("__TITLE__", html.escape(title)), ("__REGIME__", html.escape(crit.get("regime", ""))),
                     ("__WHY__", html.escape(crit.get("why", ""))), ("__EVIDENCE__", evidence),
                     ("__CAVEATS__", caveats), ("__BOUNDARY__", boundary), ("__LAKES__", lakes),
                     ("__AGES__", age_table), ("__ECHO__", echo), ("__CHAPTERS__", chapters),
                     ("__EXACT__", exact_html), ("__TABLE__", table),
                     ("__ROWS__", js(data)), ("__CHARTS__", js(charts)),
                     ("__AGEDATA__", js([[str(a), m] for a, m, _ in ages])),
                     ("__INTDATA__", js(summary["echo_all_sections"].get("intervals") or []))):
        out = out.replace(key, val)
    return out
