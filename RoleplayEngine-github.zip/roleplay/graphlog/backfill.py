"""Backfill: rebuild the graph log of a campaign played before it existed - T1..Tn from the history on file, read-only.

    python -m roleplay.graphlog backfill [campaign] [--out DIR] [--force]

What history can and can't give back (every file says so: "reconstructed": true and an exactness map):
  exact        which citizens existed and their heat each turn (energy_history is a full snapshot a turn), the mean and
               total (mean_log), supersessions (supersedes.turn), hearsay (knows.turn), slice membership, turn_metrics,
               what the packet surfaced (turns.packet is the very packet the GM saw - parsed like the forward log's),
               and which turns renormalized (events: scene_closed)
  approximate  when a link was born (no earlier than both its ends; members, spine, knows, diodes and shared scenes
               pin most), link strength (only today's value is on file; assoc links are rebuilt from shared scenes),
               the memory pass's touches (the slice, plus its recalled and mentioned members)
  missing      every deposit, the GM's own lookups (what it opened and what its searches showed it), the offscreen
               world's touches, touch counts, text as it was (the catalog has today's)
A turn that already has a forward (exact) file is left alone unless --force. The minds files (T<turn>.minds.json.gz)
are rebuilt after them, the same way (minds_backfill.py: what history keeps of who felt, believed and knew what).
"""
from __future__ import annotations

import json
import sqlite3
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ..config import Knobs
from . import fmt
from .record import KNOB_NAMES, observe_numbers

EXACTNESS = {
    "meta.mean": "exact (mean_log)", "meta.total": "exact (mean_log)", "meta.citizens": "exact (energy_history)",
    "meta.session": "exact (turns)", "meta.private": "exact (turns)", "meta.scene_id": "exact (turn_metrics/turns)",
    "meta.slice_id": "exact", "meta.links": "approximate: the reconstructed links (meta.links_on_file: the count then)",
    "meta.story_time": "approximate: the clock when this turn's slice (else the latest before it) was written",
    "meta.fight": "approximate: from the encounter's start and end turns; round missing",
    "meta.knobs": "approximate: today's defaults",
    "metrics": "exact (turn_metrics); warm/hot/gini/top5_share recomputed from the energies where it has none",
    "nodes.existence": "exact for citizens (energy_history); notes and pictures (no energy) by created_turn",
    "nodes.energy": "exact (energy_history ratio x mean_log mean)", "nodes.ratio": "exact (energy_history)",
    "nodes.superseded_by": "exact (supersedes.turn)", "nodes.kind": "approximate: today's (a merged entity reads merged)",
    "nodes.visibility": "approximate: today's", "nodes.touch_count": "missing", "nodes.last_touched_turn": "missing",
    "nodes.deposited": "missing",
    "links.existence": "approximate: born no earlier than both ends; pinned by members, spine, knows, supersedes and "
                       "shared scenes (scene_presence)",
    "links.strength": "approximate: today's value; assoc links rebuilt from the scenes shared by then",
    "links.together": "approximate (as strength)", "links.last_turn": "approximate",
    "supersedes": "exact", "knows": "exact", "doubts": "approximate: today's status, dated by raised/resolved turns",
    "process.touches": "approximate: the memory pass's touches rebuilt from the slice and its recalled and mentioned "
                       "members (stats: the slice touch's own, from turn_metrics); the GM's lookups, the offscreen "
                       "world's, minds' and every other touch missing",
    "process.deposits": "missing", "process.surfaced": "exact (parsed from turns.packet, the packet the GM saw)",
    "process.looked_up": "tools exact (turn_metrics), recalled exact (members); expanded and seen missing",
    "process.new_nodes": "exact for citizens", "process.new_links": "approximate (as links.existence)",
    "process.strength_changes": "approximate: assoc links only", "process.removed_nodes": "missing (merges)",
    "process.removed_links": "missing", "process.supersessions": "exact", "process.knows_added": "exact",
    "process.renormalized": "approximate: inferred where the mean fell (only a renormalization lowers it)",
    "process.text_changed": "missing", "process.table_presented": "exact for a portrait's first showing",
    "catalog": "today's text (a scene's summary, an entity's description as they read now)",
}
RENORM_EXACT = "exact turns (events: scene_closed, logged just before close_scene's renormalize); the mean missing"
PINNED_KINDS = ("member", "recall", "spine", "contains", "about", "holds", "step")   # written with their newer end
NEVER = 10 ** 9                    # (a turn no file reaches: a node made after the last snapshot)


def connect_ro(db: Path) -> sqlite3.Connection:
    """The campaign file, read-only (never a write, never a lock the bot would wait on)."""
    c = sqlite3.connect(f"file:{Path(db).resolve().as_posix()}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


def _has(c, table: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _cols(c, table: str) -> set[str]:
    return {r[1] for r in c.execute(f"PRAGMA table_info({table})")}


class History:
    """Everything the backfill reads, read once."""

    def __init__(self, c: sqlite3.Connection):
        q = lambda sql: c.execute(sql).fetchall()       # noqa: E731
        self.nodes = {r["id"]: dict(r) for r in q("SELECT * FROM nodes ORDER BY rowid")}
        self.order = list(self.nodes)
        self.ekind = {r["id"]: r["kind"] for r in q("SELECT id, kind FROM entities")}
        self.ratios: dict[int, dict[str, float]] = defaultdict(dict)
        for r in c.execute("SELECT turn, node_id, ratio FROM energy_history"):
            self.ratios[r[0]][r[1]] = r[2]
        self.means = {r["turn"]: r for r in q("SELECT turn, mean, total, nodes, links FROM mean_log ORDER BY rowid")}
        self.metrics = {r["turn"]: dict(r) for r in q("SELECT * FROM turn_metrics")} if _has(c, "turn_metrics") else {}
        tcols = _cols(c, "turns")
        pick = ", ".join(x for x in ("id", "scene_id", "status", "session", "private", "packet") if x in tcols)
        self.turns = {r["id"]: dict(r) for r in q(f"SELECT {pick} FROM turns")}
        self.links = [dict(r) for r in q("SELECT * FROM links ORDER BY id")]
        self.sup = [dict(r) for r in q("SELECT * FROM supersedes ORDER BY turn, rowid")]
        self.knows = [dict(r) for r in q("SELECT * FROM knows ORDER BY turn, rowid")]
        self.members: dict[str, list] = defaultdict(list)
        for r in q("SELECT slice_id, node_id, role FROM members ORDER BY rowid"):
            self.members[r[0]].append((r[1], r[2]))
        self.presence: dict[str, dict[int, int]] = defaultdict(dict)        # entity -> {scene: first turn}
        for r in q("SELECT scene_id, entity_id, first_turn FROM scene_presence"):
            self.presence[r[1]][r[0]] = r[2]
        self.doubts = [dict(r) for r in q("SELECT * FROM doubts")] if _has(c, "doubts") else []
        self.presented = defaultdict(list)
        for r in q("SELECT entity_id, turn FROM presented"):
            self.presented[r[1]].append(r[0])
        self.fights = [dict(r) for r in q("SELECT id, scene_id, status, started_turn, ended_turn FROM encounters")] \
            if _has(c, "encounters") else []
        self.closes, self.renorm_exact = self._closes(c)
        # when each node is first on file: a citizen at its first snapshot (one the offscreen world made after a
        # snapshot shows up in the next), the rest (notes, pictures) at the turn they were written
        self.first: dict[str, int] = {}
        for t in sorted(self.ratios):
            for nid in self.ratios[t]:
                self.first.setdefault(nid, t)
        citizens = {r[0] for r in c.execute("SELECT node_id FROM energy")}
        for nid, n in self.nodes.items():
            if nid not in self.first:            # (a citizen in no snapshot was made after the last one: not yet)
                self.first[nid] = NEVER if nid in citizens else n["created_turn"]
        self.birth = [self._birth(l) for l in self.links]

    @staticmethod
    def _closes(c) -> tuple[dict[int, list[tuple[int, int | None]]], bool]:
        """{file turn: [(the turn it was logged at, scene)]} for every renormalization, and whether the events said so.
        Only close_scene renormalizes, and it logs scene_closed on the line before: the turns are on file exactly - the
        falling-mean guess missed back-to-back closes (the mean 1.0 to 1.0: 6 of 21 live). A close in a turn's memory
        pass is in that turn's snapshot; a new party closes its scene after the snapshot (its meta records say which),
        so that renormalization is in the next file."""
        out: dict[int, list[tuple[int, int | None]]] = defaultdict(list)
        if not _has(c, "events"):
            return out, False
        from ..newparty import KEY
        between = set()
        row = c.execute("SELECT value FROM meta WHERE key=?", (KEY,)).fetchone()
        try:
            between = {(int(r["turn"]), int(r["scene_closed"])) for r in json.loads(row[0])} if row else set()
        except (ValueError, TypeError, KeyError):
            pass
        found = False
        for r in c.execute("SELECT turn_id, payload FROM events WHERE kind='scene_closed' ORDER BY seq"):
            if r[0] is None:
                continue
            try:
                scene = json.loads(r[1] or "{}").get("scene")
            except ValueError:
                scene = None
            found = True
            out[r[0] + 1 if (r[0], scene) in between else r[0]].append((r[0], scene))
        return out, found

    def _turn_of_pair(self, rows, a: str, b: str, ka: str, kb: str) -> int | None:
        ts = [r["turn"] for r in rows if {r[ka], r[kb]} == {a, b}]
        return min(ts) if ts else None

    def _birth(self, l: dict) -> tuple[int, bool]:
        """(the turn a link is first on file, pinned?) - never before both its ends are."""
        a, b, kind = l["a"], l["b"], l["kind"]
        lo = max(self.first.get(a, 0), self.first.get(b, 0))
        if kind in PINNED_KINDS:
            return lo, True                  # (written with its newer end: a slice's members, a fact's subjects...)
        if kind == "diode":
            t = self._turn_of_pair(self.sup, a, b, "old_id", "new_id")
            return (max(lo, t), True) if t is not None else (lo, False)
        if kind == "knows":
            t = self._turn_of_pair(self.knows, a, b, "holder", "node_id")
            return (max(lo, t), True) if t is not None else (lo, False)
        if kind == "assoc":
            pa, pb = self.presence.get(a, {}), self.presence.get(b, {})
            shared = [max(pa[s], pb[s]) for s in pa.keys() & pb.keys()]
            return (max(lo, min(shared)), True) if shared else (lo, False)
        return lo, False

    def shared_by(self, a: str, b: str, t: int) -> int:
        pa, pb = self.presence.get(a, {}), self.presence.get(b, {})
        return sum(1 for s in pa.keys() & pb.keys() if max(pa[s], pb[s]) <= t)


def _strength_at(H: History, i: int, t: int, final_shared: dict) -> tuple[float, int, int]:
    """(strength, together, last_turn) of link i at turn t - today's, except an assoc link, rebuilt from the scenes
    its two ends had shared by then (one +1 a shared scene: Substrate.mark_copresence)."""
    l = H.links[i]
    if l["kind"] != "assoc":
        last = l["last_turn"] if l["last_turn"] <= t else H.birth[i][0]
        return l["strength"], l["together"], last
    key = (l["a"], l["b"])
    if key not in final_shared:
        final_shared[key] = H.shared_by(l["a"], l["b"], NEVER)
    gap = final_shared[key] - H.shared_by(l["a"], l["b"], t)
    strength = max(min(1.0, l["strength"]), l["strength"] - gap)
    together = max(0, l["together"] - gap)
    pa, pb = H.presence.get(l["a"], {}), H.presence.get(l["b"], {})
    entries = [max(pa[s], pb[s]) for s in pa.keys() & pb.keys() if max(pa[s], pb[s]) <= t]
    last = min(l["last_turn"], max(entries)) if entries else min(l["last_turn"], t)
    return strength, together, last


def build_turn(H: History, t: int, campaign: str, prev_links: dict | None, final_shared: dict) -> tuple[dict, dict]:
    ratios = H.ratios[t]
    ml = H.means.get(t)
    mean = ml["mean"] if ml else None
    total = ml["total"] if ml else None
    exist = [nid for nid in H.order if H.first.get(nid, NEVER) <= t]
    ids = set(exist)
    sup_on = [s for s in H.sup if max(s["turn"], H.first.get(s["new_id"], 0), H.first.get(s["old_id"], 0)) <= t]
    arrows = {s["old_id"]: s["new_id"] for s in sorted(sup_on, key=lambda s: s["confidence"])}
    nodes = []
    for nid in exist:
        n = H.nodes[nid]
        r = ratios.get(nid)
        nodes.append([nid, n["kind"], n["created_turn"], n["scene_id"], n["visibility"],
                      r * mean if r is not None and mean is not None else None, fmt.rnd(r) if r is not None else None,
                      None, None, arrows.get(nid), None])
    links, lmap = [], {}
    for i, l in enumerate(H.links):
        b, _ = H.birth[i]
        if b > t or l["a"] not in ids or l["b"] not in ids:
            continue
        s, tog, last = _strength_at(H, i, t, final_shared)
        links.append([l["a"], l["b"], l["kind"], s, tog, last])
        lmap[(l["a"], l["b"])] = (s, l["kind"], b)
    knows_on = [k for k in H.knows if max(k["turn"], H.first.get(k["node_id"], 0), H.first.get(k["holder"], 0)) <= t]
    doubts = [[d["id"], ("open" if not d.get("resolved_turn") or d["resolved_turn"] > t else d["status"]),
               d["raised_turn"], d.get("resolved_turn") if (d.get("resolved_turn") or NEVER) <= t else None]
              for d in H.doubts if (d.get("raised_turn") or 0) <= t]

    # ── the process, as far as history keeps it ──
    tid = f"T{t}"
    slice_id = tid if H.first.get(tid) == t and H.nodes.get(tid, {}).get("kind") == "slice" else None
    met = dict(H.metrics.get(t) or {})
    for key in ("stats", "tools"):
        if isinstance(met.get(key), str):
            try:
                met[key] = json.loads(met[key])
            except ValueError:
                pass
    mem = H.members.get(tid, []) if slice_id else []
    recalled = [m for m, r in mem if r == "recalled"]
    mentioned = [m for m, r in mem if r == "mentioned"]
    touches = []
    if slice_id:
        fight_end = any(f["ended_turn"] == t for f in H.fights) and (H.nodes[tid]["text"] or "").startswith("The fight:")
        touches.append({"turn": t, "by": "encounters:end" if fight_end else "dm.commit:commit_turn",
                        "why": "fight-memory" if fight_end else "slice", "quantum_ratio": 1.0, "counts_as_touch": True,
                        "origins": [tid], "stats": met.get("stats") if isinstance(met.get("stats"), dict) else None,
                        "i": 0, "phase": "turn", "reconstructed": True})
    if recalled or mentioned:
        touches.append({"turn": t, "by": "dm.commit:commit_turn", "why": "retrieval",
                        "quantum_ratio": Knobs().retrieval_quantum, "counts_as_touch": True,
                        "origins": recalled + mentioned, "stats": None, "i": len(touches), "phase": "turn",
                        "origin_why": {**{o: "recalled" for o in recalled}, **{o: "mentioned" for o in mentioned}},
                        "reconstructed": True, "partial": "what the GM opened by id (looked-up) isn't on file"})
    if H.renorm_exact:                     # (the events say which turns: exact)
        renorm = [{"turn": at, "mean": None, "scene": s} for at, s in H.closes.get(t, [])]
    else:                                  # (a world from before the event: only a renormalization lowers the mean)
        prev_mean = H.means[t - 1]["mean"] if t - 1 in H.means else None
        renorm = [{"turn": t, "mean": None, "inferred": "the mean fell"}] if (
            prev_mean and mean is not None and mean < prev_mean * 0.999) else []
    packet = (H.turns.get(t) or {}).get("packet")
    if prev_links is not None:
        new_links = [[a, b, k, s] for (a, b), (s, k, _) in lmap.items() if (a, b) not in prev_links]
        changes = [[a, b, prev_links[(a, b)][0], s] for (a, b), (s, k, _) in lmap.items()
                   if (a, b) in prev_links and prev_links[(a, b)][0] != s]
    else:
        new_links = [[a, b, k, s] for (a, b), (s, k, born) in lmap.items() if born == t]
        changes = []
    scene_id = met.get("scene_id") if met.get("scene_id") is not None else (H.turns.get(t) or {}).get("scene_id")
    fight = next(({"id": f["id"], "round": None, "status": "ended" if f["ended_turn"] == t else "active",
                   "started_turn": f["started_turn"]} for f in sorted(H.fights, key=lambda f: -f["id"])
                  if f["scene_id"] == scene_id and (f["started_turn"] or 0) <= t
                  and (f["ended_turn"] is None or f["ended_turn"] >= t)), None)
    story = [H.nodes[n]["story_time"] for n in (tid,) if slice_id and H.nodes[n].get("story_time") is not None]
    if not story:
        older = [(H.first[n], H.nodes[n].get("story_time")) for n in exist
                 if H.nodes[n]["kind"] == "slice" and H.nodes[n].get("story_time") is not None]
        story = [max(older)[1]] if older else [None]
    energies = [r * mean for r in ratios.values()] if mean is not None else list(ratios.values())
    if not met:
        met = observe_numbers(energies)
    doc = {
        "schema": fmt.SCHEMA, "reconstructed": True,
        "exactness": dict(EXACTNESS, **({} if packet else {"process.surfaced": "missing (no packet on file)"}),
                          **({"process.renormalized": RENORM_EXACT} if H.renorm_exact else {})),
        "meta": {"campaign": campaign, "turn": t, "scene_id": scene_id, "slice_id": slice_id,
                 "private": (H.turns.get(t) or {}).get("private"), "fight": fight, "story_time": story[0],
                 "session": (H.turns.get(t) or {}).get("session"), "mean": mean, "total": total,
                 "nodes": len(exist), "citizens": len(ratios), "links": len(links),
                 "links_on_file": ml["links"] if ml else None,
                 "knobs": {k: getattr(Knobs(), k, None) for k in KNOB_NAMES},
                 "diff_since": t - 1 if prev_links is not None else None,
                 "written_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
        "metrics": met,
        "nodes": fmt.table(fmt.NODE_COLUMNS, nodes),
        "links": fmt.table(fmt.LINK_COLUMNS, links),
        "supersedes": [[s["old_id"], s["new_id"], s["confidence"], s["installed_by"], s["turn"]] for s in sup_on],
        "knows": [[k["holder"], k["node_id"], k["how"], k["source"], k["turn"]] for k in knows_on],
        "doubts": doubts,
        "process": {
            "touches": touches, "deposits": fmt.table(fmt.DEPOSIT_COLUMNS, []),
            "surfaced": fmt.surfaced(packet, ids) if packet else {},
            "looked_up": {"expanded": None, "seen": None, "tools": met.get("tools") if isinstance(met.get("tools"), list)
                          else None, "recalled": recalled},
            "new_nodes": [n for n in exist if H.first[n] == t], "removed_nodes": [],
            "new_links": fmt.table(["a", "b", "kind", "strength"], new_links),
            "strength_changes": fmt.table(["a", "b", "old", "new"], changes), "removed_links": [],
            "supersessions": [[s["old_id"], s["new_id"], s["confidence"], s["installed_by"], s["turn"]] for s in sup_on
                              if max(s["turn"], H.first.get(s["new_id"], 0), H.first.get(s["old_id"], 0)) == t],
            "knows_added": [[k["holder"], k["node_id"], k["how"], k["source"], k["turn"]] for k in knows_on
                            if max(k["turn"], H.first.get(k["node_id"], 0), H.first.get(k["holder"], 0)) == t],
            "doubts_raised": [d["id"] for d in H.doubts if d.get("raised_turn") == t],
            "doubts_settled": [d["id"] for d in H.doubts if d.get("resolved_turn") == t],
            "renormalized": renorm, "text_changed": [], "table_presented": list(H.presented.get(t, [])),
        },
    }
    return doc, lmap


def backfill(db: Path | str, out: Path | str | None = None, force: bool = False, say=print, minds: bool = True) -> dict:
    """Rebuild the log's turn files from the campaign's history - and their minds files (minds_backfill.py). Returns
    {written, skipped, bytes, seconds, turns, minds}."""
    db = Path(db)
    t0 = time.perf_counter()
    c = connect_ro(db)
    try:
        H = History(c)
        d = Path(out) if out else fmt.log_dir(db)
        res = _backfill(H, d, db, force, say, t0)
        if minds:                                    # (its own reads: the same read-only connection)
            from .minds_backfill import backfill_minds, check_line
            m = backfill_minds(c, H, d, db.stem, force)
            res["minds"] = m
            say(f"backfilled {len(m['written'])} minds file(s)" + (f" ({m['bytes'] / len(m['written']) / 1e3:.0f} KB "
                                                                  "a turn)" if m["written"] else "")
                + (f"; kept {len(m['skipped'])} forward minds file(s)" if m["skipped"] else "")
                + (f"; left {len(m['covered'])} turn(s) a forward file's events already cover" if m["covered"] else ""))
            say(check_line(m["check"]))
    finally:
        c.close()
    res["seconds"] = time.perf_counter() - t0
    return res


def _backfill(H: History, d: Path, db: Path, force: bool, say, t0: float) -> dict:
    """The turn files and their catalog lines (the minds files follow: minds_backfill.py)."""
    on_file = fmt.read_csv(d)
    have = set(fmt.turns_on_file(d))
    forward = set()
    for t in have:                                   # (a forward file is exact: never replaced by a reconstruction)
        row = on_file.get(t)
        if row is not None:
            if str(row.get("reconstructed")) == "0":
                forward.add(t)
        else:
            try:
                if not fmt.read_turn(d, t).get("reconstructed"):
                    forward.add(t)
            except Exception:
                pass
    written, skipped, size = [], [], 0
    prev_links, final_shared = None, {}
    rows = dict(on_file)
    for t in sorted(H.ratios):
        doc, lmap = build_turn(H, t, db.stem, prev_links, final_shared)
        prev_links = lmap
        if t in forward and not force:
            skipped.append(t)
            continue
        n = fmt.write_turn(d, doc)
        size += n
        written.append(t)
        rows[t] = fmt.csv_row(doc, n, None)
    fmt.write_csv(d, rows)
    # a node needs an entry in force from the turn it's first on file. The forward log may already have one - from
    # its own first turn (deploy, a turn, then backfill: every node catalogued since=T189), which catalog_at(t) skips
    # for every turn before - so it's enough only when it starts that early; otherwise the oldest text on file goes
    # in from the node's first turn (the forward lines still win from theirs: catalog_at sorts by since)
    earliest: dict[str, dict] = {}
    for e in fmt.read_catalog(d):
        if e["id"] not in earliest or (e.get("since") or 0) < (earliest[e["id"]].get("since") or 0):
            earliest[e["id"]] = e
    fresh = []
    for nid in H.order:
        first = H.first.get(nid, NEVER)
        have = earliest.get(nid)
        if first >= NEVER or (have is not None and (have.get("since") or 0) <= first):
            continue
        n = H.nodes[nid]
        text = have.get("text") if have is not None else n["text"]
        e = {"id": nid, "kind": n["kind"], "ekind": H.ekind.get(nid), "created_turn": n["created_turn"],
             "scene_id": n["scene_id"], "since": first, "hash": fmt.text_hash(text), "text": text,
             "reconstructed": True}
        if n["kind"] == "slice":
            e["members"] = [[m, r] for m, r in H.members.get(nid, [])]
        fresh.append(e)
    fmt.append_catalog(d, fresh)
    secs = time.perf_counter() - t0
    if written:
        say(f"backfilled {len(written)} turn file(s) T{written[0]}..T{written[-1]} into {d} "
            f"({size / 1e6:.1f} MB, {size / len(written) / 1e3:.0f} KB a turn, {secs:.1f}s)"
            + (f"; kept {len(skipped)} forward file(s)" if skipped else ""))
    else:
        say(f"nothing to backfill in {d}" + (f" (kept {len(skipped)} forward file(s))" if skipped else ""))
    return {"written": written, "skipped": skipped, "bytes": size, "seconds": secs, "dir": str(d),
            "turns": sorted(H.ratios)}
