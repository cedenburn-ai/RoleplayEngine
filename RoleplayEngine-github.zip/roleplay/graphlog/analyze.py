"""Analyze the graph log: per-turn measures (measures.csv), a reading of them (summary.json) and a report (report.html).

    python -m roleplay.graphlog analyze [campaign] [--out DIR]

What it tests, where the data allows (DESIGN.md §8f):
  (a) V5 spec §7 criticality - the warm set (ratio >= 1) and hot set (>= 2), the engine's own definitions
      (Substrate.observe): their population and its stability, membership turnover (Jaccard against 1, 5 and 10
      turns back, and who entered: newborns vs re-entries, old nodes back in the hot set), concentration (gini, the
      top five's and the top 5% of citizens' share, effective number of nodes, the largest warm connected
      component's share with and without the PCs - the "one lump" test), and a regime reading with its evidence.
  (b) does the warm set track the query stream - re-entries into the hot set across a scene change against the
      in-scene windows around it, with an interval and a placebo p-value; and how much of the turn's slice (its
      members: the topic) is warm.
  (c) lakes and rivers - energy minted per touch against its deposit (the 2x rule), the energy books (does what was
      minted plus what was born add up to the change in total?), the rising mean (forgetting) and a forgetting curve
      by age, dry channels (links whose ends have both cooled), new links' strength against their ends' local mean,
      rehydration (a cold node lit again).
  (d) V5 §8.9 echo chamber - per node, the intervals between surfacings in the packet; a persistent core that
      surfaces whatever the scene vs topic-clustered surfacing; does being shown feed heat.
Plain stdlib: the log is the input, nothing else is read.
"""
from __future__ import annotations

import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from . import fmt
from .record import observe_numbers

WARM, HOT = 1.0, 2.0          # ratio to the mean: Substrate.observe's warm (>= mean) and hot (>= 2x)
DRY = 0.5                     # a channel whose ends are both under half the mean carries next to nothing
COLD = 0.25                   # rehydration: from under a quarter of the mean ...
LIT = 0.5                     # ... to half of it or more in one turn (a retrieval touch deposits half the mean)
LAGS = (1, 5, 10)
AGES = (0, 1, 2, 5, 10, 20, 50, 100, 150, 200, 300, 500)
ENERGY_RANKED = ("facts_in_play", "associated_memories")   # packet sections ordered by heat ("hottest first")
CORE_TURNS, CORE_SCENES = 0.5, 0.5     # the persistent core: surfaced in half the turns, across half the scenes
LOCAL = 15                    # a scene change is compared with the in-scene windows this many turns either side
WINDOW = 5                    # ... in five-turn windows (a cut lands mid-turn; the new scene heats over the next few)
STRONG_TRACKING = 0.05        # 5 points more of the hot set re-warmed across a change than around it: the topic leads
ALPHA = 0.05                  # the topic test passes on a placebo p under this ...
MIN_PLACEBOS = 19             # ... given the shifts to get there (with fewer, p can't go under 1/20)
# two-sided 95% t by degrees of freedom 1..30 (then the normal's 1.96): the topic effect's interval over few changes
T95 = (12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228, 2.201, 2.179, 2.160, 2.145, 2.131,
       2.120, 2.110, 2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042)
# The regime call (V5 §7). Warm and hot are measured against the mean, and the mean moves with the energy: a lump
# makes the warm set small as surely as a drained graph would, so concentration is read first, from energy shares.
LUMP_FRACTION, LUMP_SHARE = 0.05, 0.5    # one lump: the top 5% of citizens hold half the energy (the live world: 23%)
EMPTY_HOT = 0.005             # subcritical: under 0.5% of citizens hot with nothing concentrated (a flat graph) ...
FLEETING_J1 = 0.25            # ... or a hot set that hardly carries over a turn (Jaccard against the turn before)
TURNING_REENTRY = 0.02        # turning over: 2%+ of the hot set is old nodes re-warmed against ten back (the live
#                               world 8%; a conveyor of newborns over a frozen core 0 - births alone don't count)
STABLE_CV, STABLE_SLOPE = 0.25, 0.1      # a stable population: warm-share CV, and its trend per 100 turns
INTERVAL_BINS = ((1, 1), (2, 2), (3, 5), (6, 10), (11, 25), (26, 50), (51, 10 ** 9))

MEASURES = ["turn", "reconstructed", "scene_id", "boundary", "consecutive", "citizens", "links", "mean", "total",
            "mean_growth", "renormalized", "warm", "hot", "warm_share", "hot_share", "gini", "top5_share",
            "top1pct_share", "top5pct_share", "effective_n",
            "warm_lcc_share", "warm_lcc_share_no_pc", "hot_lcc_share", "j1_warm", "j5_warm", "j10_warm", "j1_hot",
            "j5_hot", "j10_hot", "reentry1_hot", "reentry5_hot", "reentry10_hot", "born1_hot", "born5_hot",
            "born10_hot", "dry_links", "dry_share", "new_links", "new_link_local_ratio", "rehydrated",
            "touches", "minted", "expected_deposit", "mint_ratio", "births", "born_energy", "delta_total",
            "energy_unexplained", "surfaced",
            "surfaced_warm_share", "hot_surfaced_share", "topic_nodes", "topic_warm_share", "hot_in_topic_share",
            "surfaced_origin_share"]


def jaccard(a: set, b: set) -> float | None:
    if not a and not b:
        return None
    return len(a & b) / len(a | b)


def largest_component(nodes: set, edges) -> int:
    """The size of the largest connected piece of the subgraph on `nodes` (union-find over the links)."""
    parent = {n: n for n in nodes}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in edges:
        if a in parent and b in parent:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
    sizes = Counter(find(n) for n in nodes)
    return max(sizes.values()) if sizes else 0


def _median(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else None


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _slope(ys) -> float | None:
    """Least-squares slope per step."""
    pts = [(i, y) for i, y in enumerate(ys) if y is not None]
    if len(pts) < 2:
        return None
    mx = sum(i for i, _ in pts) / len(pts)
    my = sum(y for _, y in pts) / len(pts)
    den = sum((i - mx) ** 2 for i, _ in pts)
    return sum((i - mx) * (y - my) for i, y in pts) / den if den else 0.0


def _cv(ys) -> float | None:
    ys = [y for y in ys if y is not None]
    if len(ys) < 2:
        return None
    m = sum(ys) / len(ys)
    return statistics.pstdev(ys) / m if m else None


def _top_share(es_desc: list[float], fraction: float) -> float | None:
    """The share of the energy held by the top `fraction` of citizens (at least one)."""
    total = sum(es_desc)
    return sum(es_desc[:max(1, math.ceil(len(es_desc) * fraction))]) / total if es_desc and total else None


def measure(d: Path) -> dict:
    """Walk the log once; return {rows: per-turn measures, ...the aggregates the reading needs}."""
    turns = fmt.turns_on_file(d)
    entries = fmt.read_catalog(d)
    catalog = fmt.catalog_at(entries)
    pcs = {e["id"] for e in entries if e.get("ekind") == "pc"}     # (ever a PC: a new party makes the old crew NPCs)
    names = {i: (e.get("text") or "")[:80] for i, e in catalog.items()}
    rows: list[dict] = []
    # turn -> (citizens, warm, hot): the lags go by turn number, not by file - a log with a gap (`graphlog off` then
    # on, a write that failed) compared "1 turn back" across four and called four turns' growth one turn's
    hist: dict[int, tuple[set, set, set]] = {}
    prev = None                                    # the previous file's {turn, meta, ratios}
    ages: dict[int, list[float]] = defaultdict(list)
    mint_ratios: list[dict] = []
    new_link_ratios: list[float] = []
    surf_turns: dict[str, list[int]] = defaultdict(list)       # node -> turns it surfaced (any section)
    surf_ranked: dict[str, list[int]] = defaultdict(list)      # ... in the energy-ranked sections
    scene_of_turn: dict[int, int] = {}
    surfaced_turns = 0
    exact_turns, rebuilt_turns = 0, 0
    exactness: dict[str, str] = {}
    partial: dict[int, str] = {}
    pc_heat: dict[int, dict[str, float | None]] = {}
    marks: list[dict] = []
    for t in turns:
        try:
            doc = fmt.read_turn(d, t)
        except Exception:
            continue
        meta, pr = doc["meta"], doc.get("process") or {}
        rebuilt = bool(doc.get("reconstructed"))
        rebuilt_turns += rebuilt
        exact_turns += not rebuilt
        if rebuilt and not exactness:
            exactness = doc.get("exactness") or {}
        elif not rebuilt:                          # (a forward file that couldn't vouch for its touches: why)
            note = str((doc.get("exactness") or {}).get("process.touches", ""))
            if note.startswith("partial"):
                partial[t] = note.removeprefix("partial: ")
        nodes = fmt.rows_of(doc["nodes"])
        ratio = {n["id"]: n["ratio"] for n in nodes if n["ratio"] is not None}
        pc_heat[t] = {p: ratio.get(p) for p in pcs}            # (a new party: does the old crew drain? chapters())
        marks += [dict(x, file_turn=t) for x in pr.get("marks") or []]
        energies = [n["energy"] for n in nodes if n["energy"] is not None]
        created = {n["id"]: n["created_turn"] for n in nodes}
        warm = {i for i, r in ratio.items() if r >= WARM}
        hot = {i for i, r in ratio.items() if r >= HOT}
        obs = observe_numbers(energies)
        total = sum(energies)
        eff = (total * total / sum(e * e for e in energies)) if energies and total else None
        desc = sorted(energies, reverse=True)
        # one step from the last file, and measured against it (diff_since): per-turn rates and the books hold
        consecutive = prev is not None and prev["turn"] == t - 1 and meta.get("diff_since") == prev["turn"]
        li = doc["links"]["columns"]
        ia, ib, istr = li.index("a"), li.index("b"), li.index("strength")
        edges = [(r[ia], r[ib]) for r in doc["links"]["rows"]]
        dry = sum(1 for a, b in edges if a in ratio and b in ratio and ratio[a] < DRY and ratio[b] < DRY)
        citizen_links = sum(1 for a, b in edges if a in ratio and b in ratio)
        lcc_w = largest_component(warm, edges)
        lcc_w_np = largest_component(warm - pcs, edges)
        lcc_h = largest_component(hot, edges)
        scene = meta.get("scene_id")
        scene_of_turn[t] = scene
        boundary = prev is not None and prev["meta"].get("scene_id") != scene

        # (c) the rising mean, the books, the 2x rule
        renorm = bool(pr.get("renormalized"))
        growth = None
        if consecutive and not renorm and prev["meta"].get("mean") and meta.get("mean"):
            growth = meta["mean"] / prev["meta"]["mean"] - 1
        touches = pr.get("touches") or []
        tq = (meta.get("knobs") or {}).get("touch_quantum") or 1.0
        minted = expected = 0.0
        have_stats = False
        for tc in touches:
            st = tc.get("stats") or {}
            if not st.get("energy_minted"):
                continue
            # the deposit is each origin's quantum at the mean it met (touch_all re-reads it per origin, I-5); a file
            # without it - reconstructed, or from before stats.deposit - has origins x one mean: approximate, and
            # high for many origins in a small graph (each later origin met a higher mean)
            dep, approx = st.get("deposit"), False
            if not dep:
                approx = True
                mb = tc.get("mean_before")
                if mb is None and prev is not None:
                    mb = prev["meta"].get("mean")  # (reconstructed: the last snapshot's mean, the touch's own unknown)
                if not mb:
                    continue
                dep = st.get("origins", len(tc.get("origins") or [])) * mb * tq * (tc.get("quantum_ratio") or 1.0)
            have_stats = True
            minted += st["energy_minted"]
            expected += dep
            if dep:
                mint_ratios.append({"turn": t, "why": tc.get("why"), "ratio": st["energy_minted"] / dep,
                                    "diode_hops": tc.get("diode_hops"), "approx": approx,
                                    "waves": st.get("waves"), "reached": st.get("nodes_deposited")})
        newborn = [n for n in nodes if n["energy"] is not None and prev is not None and n["id"] not in prev["ratio"]]
        births = len(newborn)
        # each was born at the mean in force when it was made - higher than the last snapshot's once anything touched
        # first (the offscreen world, a late <dm> fact) - so what it holds less what was deposited on it, exactly
        born_energy = sum(n["energy"] - (n.get("deposited") or 0.0) for n in newborn) if prev is not None else None
        delta = total - prev["meta"]["total"] if consecutive and not renorm else None
        unexplained = None                         # (the books: the change in total = minted + what was born)
        if delta is not None and have_stats and not rebuilt and fmt.exact(doc, "process.deposits"):
            unexplained = delta - minted - born_energy
        rehyd = (sum(1 for i, r in ratio.items() if r >= LIT and prev["ratio"].get(i, 1) < COLD)
                 if consecutive else None)
        for i, r in ratio.items():                 # the forgetting curve: heat by age (born at the mean: 1.0)
            age = t - (created.get(i) or 0)
            if age in AGES:
                ages[age].append(r)

        # new rivers against the local mean width
        nl = fmt.rows_of(pr.get("new_links"))
        if nl:
            strengths = defaultdict(list)
            fresh = {(x["a"], x["b"]) for x in nl}
            for r in doc["links"]["rows"]:
                if (r[ia], r[ib]) not in fresh:
                    strengths[r[ia]].append(r[istr])
                    strengths[r[ib]].append(r[istr])
            turn_ratios = []
            for x in nl:
                local = strengths.get(x["a"], []) + strengths.get(x["b"], [])
                if local and x["strength"]:
                    turn_ratios.append(x["strength"] / (sum(local) / len(local)))
            new_link_ratios += turn_ratios
        else:
            turn_ratios = []

        # (b) topic: the turn's slice and its members
        sl = meta.get("slice_id")
        topic = set()
        if sl:
            topic = {m for m, _ in (catalog.get(sl) or {}).get("members") or []} | {sl}
        topic_c = {x for x in topic if x in ratio}

        # (d) what the packet surfaced
        surf = pr.get("surfaced") or {}
        shown = {i for ids in surf.values() for i in ids}
        if surf:
            surfaced_turns += 1
            for i in shown:
                surf_turns[i].append(t)
            for sec in ENERGY_RANKED:
                for i in surf.get(sec, []):
                    surf_ranked[i].append(t)
        origins = {o for tc in touches if tc.get("phase", "turn") == "turn" for o in tc.get("origins") or []}
        shown_c = {i for i in shown if i in ratio}

        hist[t] = (set(ratio), warm, hot)
        row = {"turn": t, "reconstructed": int(rebuilt), "consecutive": int(consecutive), "scene_id": scene,
               "boundary": int(boundary),
               "citizens": len(ratio), "links": len(edges), "mean": meta.get("mean"), "total": total,
               "mean_growth": growth, "renormalized": int(renorm), "warm": len(warm), "hot": len(hot),
               "warm_share": len(warm) / len(ratio) if ratio else None,
               "hot_share": len(hot) / len(ratio) if ratio else None, "gini": obs["gini"],
               "top5_share": obs["top5_share"], "top1pct_share": _top_share(desc, 0.01),
               "top5pct_share": _top_share(desc, LUMP_FRACTION), "effective_n": eff,
               "warm_lcc_share": lcc_w / len(warm) if warm else None,
               "warm_lcc_share_no_pc": lcc_w_np / len(warm - pcs) if warm - pcs else None,
               "hot_lcc_share": lcc_h / len(hot) if hot else None,
               "dry_links": dry, "dry_share": dry / citizen_links if citizen_links else None,
               "new_links": len(nl), "new_link_local_ratio": _median(turn_ratios), "rehydrated": rehyd,
               "touches": len(touches), "minted": minted if have_stats else None,
               "expected_deposit": expected if have_stats else None,
               "mint_ratio": minted / expected if have_stats and expected else None, "births": births,
               "born_energy": born_energy,
               "delta_total": delta, "energy_unexplained": unexplained, "surfaced": len(shown) if surf else None,
               "surfaced_warm_share": len(shown_c & warm) / len(shown_c) if shown_c else None,
               "hot_surfaced_share": len(hot & shown) / len(hot) if hot and surf else None,
               "topic_nodes": len(topic_c), "topic_warm_share": len(topic_c & warm) / len(topic_c) if topic_c else None,
               "hot_in_topic_share": len(hot & topic) / len(hot) if hot and topic else None,
               "surfaced_origin_share": (len(shown & origins) / len(shown)) if shown and not rebuilt else None}
        for lag in LAGS:                           # turnover against the turn `lag` turns back (if it has a file)
            back = hist.get(t - lag)
            row[f"j{lag}_warm"] = jaccard(warm, back[1]) if back else None
            row[f"j{lag}_hot"] = jaccard(hot, back[2]) if back else None
            # who entered the hot set since: nodes born since (a conveyor of new slices turns any set over) and old
            # nodes that were below 2x then and came back - the re-entries V5 §7's "turns over as topics change" means
            entrants = hot - back[2] if back else set()
            row[f"reentry{lag}_hot"] = len(entrants & back[0]) / len(hot) if back and hot else None
            row[f"born{lag}_hot"] = len(entrants - back[0]) / len(hot) if back and hot else None
        for old in [k for k in hist if k <= t - max(LAGS)]:
            del hist[old]
        rows.append(row)
        prev = {"turn": t, "meta": dict(meta, total=total), "ratio": ratio}
    marks = with_marks_file(d, marks, sorted(pc_heat))
    return {"rows": rows, "ages": ages, "mint": mint_ratios, "new_link_ratios": new_link_ratios,
            "surf_turns": surf_turns, "surf_ranked": surf_ranked, "scene_of_turn": scene_of_turn,
            "surfaced_turns": surfaced_turns, "names": names, "pcs": pcs, "exact_turns": exact_turns,
            "rebuilt_turns": rebuilt_turns, "exactness": exactness, "partial": partial, "pc_heat": pc_heat,
            "marks": marks}


def standing_marks(d: Path) -> list[dict]:
    """marks.jsonl as it stands: what the engine set down between turns, less each new party taken back (a
    'new-party-undone' cancels the newest new party after the same turn)."""
    out: list[dict] = []
    for mk in fmt.read_marks(d):
        if mk.get("kind") == "new-party-undone":
            hit = [i for i, x in enumerate(out) if x.get("kind") == "new-party" and x.get("turn") == mk.get("turn")]
            if hit:
                del out[hit[-1]]
        else:
            out.append(mk)
    return out


def with_marks_file(d: Path, marks: list[dict], turns: list[int]) -> list[dict]:
    """The turn files' marks, plus any on marks.jsonl that no file carries - each on the first file after it. The
    file's copy rides the recorder's buffer to the next turn, and a buffer lost before that turn (a log that was off,
    a file that failed to write, a buffer on disk that went missing over a restart) took the change of crew out of the
    analysis while marks.jsonl, written the moment it happened, still had it (review 2026-10-27)."""
    have = {(x.get("kind"), x.get("turn")) for x in marks}
    out = list(marks)
    for mk in standing_marks(d):
        if (mk.get("kind"), mk.get("turn")) in have:
            continue
        first = next((t for t in turns if t > int(mk.get("turn") or 0)), None)
        if first is not None:                      # (no file after it yet: the next one will carry it)
            out.append(dict(mk, file_turn=first, from_marks_file=True))
    return sorted(out, key=lambda x: x["file_turn"])


def chapters(m: dict, before: int = 5, after: int = 40) -> list[dict]:
    """Each new party in the log (a process mark): the old crew's heat (their mean ratio) over the files before it and
    each file after, and the warm set's turnover across it - does the persistent core drain once nobody plays it, and
    how fast (the forgetting curve on the ones who left the table)?"""
    heat, turns = m["pc_heat"], sorted(m["pc_heat"])
    j1 = {r["turn"]: r.get("j1_warm") for r in m["rows"]}
    out = []
    for mk in m["marks"]:
        if mk.get("kind") != "new-party":
            continue
        at, crew = mk["file_turn"], list(mk.get("former_pcs") or [])

        def avg(ts):
            vals = [heat[t][c] for t in ts for c in crew if heat[t].get(c) is not None]
            return sum(vals) / len(vals) if vals else None
        out.append({"after_turn": mk.get("turn"), "first_file": at, "former_pcs": crew,
                    "gap_minutes": mk.get("gap_minutes"), "crew_ratio_before": avg([t for t in turns if t < at][-before:]),
                    "crew_ratio_after": [[t, avg([t])] for t in [t for t in turns if t >= at][:after]],
                    "warm_jaccard_across": j1.get(at)})
    return out


def echo(surf: dict[str, list[int]], scene_of_turn: dict[int, int], n_turns: int, names: dict) -> dict:
    """V5 §8.9: how often each node comes back into the packet, and whether it comes back with its topic."""
    if not n_turns:
        return {"turns": 0}
    intervals = Counter()
    scenes_seen = {s for s in scene_of_turn.values() if s is not None}
    core, clustered, all_counts = [], 0, 0
    total = sum(len(v) for v in surf.values())
    for nid, ts in surf.items():
        ts = sorted(set(ts))
        all_counts += 1
        for a, b in zip(ts, ts[1:]):
            gap = b - a
            for lo, hi in INTERVAL_BINS:
                if lo <= gap <= hi:
                    intervals[f"{lo}" if lo == hi else (f"{lo}-{hi}" if hi < 10 ** 9 else f"{lo}+")] += 1
                    break
        sc = Counter(scene_of_turn.get(x) for x in ts)
        if len(ts) >= 5 and sc.most_common(1)[0][1] / len(ts) >= 0.8:
            clustered += 1
        if len(ts) >= CORE_TURNS * n_turns and len(sc) >= CORE_SCENES * len(scenes_seen):
            core.append({"id": nid, "turns": len(ts), "scenes": len(sc), "text": names.get(nid, "")})
    core.sort(key=lambda c: -c["turns"])
    core_share = sum(len(set(surf[c["id"]])) for c in core) / total if total else 0
    labels = [f"{lo}" if lo == hi else (f"{lo}-{hi}" if hi < 10 ** 9 else f"{lo}+") for lo, hi in INTERVAL_BINS]
    return {"turns": n_turns, "nodes": all_counts, "surfacings": total, "core": core, "core_share": core_share,
            "clustered": clustered, "intervals": [[lab, intervals.get(lab, 0)] for lab in labels]}


def topic_test(rows: list[dict], y: dict[int, float], window: int = WINDOW, local: int = LOCAL) -> dict:
    """Does a window's measure (`y`: turn -> the value for the `window` turns ending there) run higher across a scene
    change than in the in-scene windows around it? Each change - a run of changes within `window` turns counts once,
    they aren't independent - against the windows within `local` turns of it that cross none (the graph grows and
    turnover drifts with it: a global comparison misled). The mean difference with a 95% interval, and a placebo
    p-value: the same statistic with the log's own pattern of changes shifted round the log by more than a window, and
    how often a shift does as well. Without the p-value a coin-flip +1.6 points read as tracking (live, 2026-10-27)."""
    turns = [r["turn"] for r in rows]
    flags = [bool(r["boundary"]) for r in rows]

    def diffs(fl: list[bool]) -> list[float]:
        changes = [turns[i] for i, f in enumerate(fl) if f]
        bset = set(changes)
        clear = {t: not any(b in bset for b in range(t - window + 1, t + 1)) for t in y}
        out, last = [], None
        for b in changes:
            run, last = last is not None and b - last <= window, b
            yb = y.get(b + window - 1)
            if run or yb is None:
                continue
            near = [y[k] for k in range(b - local, b + local) if k in y and clear[k]]
            if near:
                out.append(yb - sum(near) / len(near))
        return out
    obs = diffs(flags)
    res = {"events": len(obs), "mean": _mean(obs), "ci": None, "p": None, "p_lower": None, "placebos": 0,
           "above": (sum(1 for x in obs if x > 0) / len(obs)) if obs else None}
    if len(obs) < 2:
        return res
    m = res["mean"]
    tq = T95[len(obs) - 2] if len(obs) - 1 <= len(T95) else 1.96
    half = tq * statistics.stdev(obs) / math.sqrt(len(obs))
    res["ci"] = [m - half, m + half]
    null = []
    for s in range(window + 1, len(flags) - window):     # (a shift within a window would re-measure the same changes)
        d = diffs(flags[-s:] + flags[:-s])
        if d:
            null.append(sum(d) / len(d))
    res["placebos"] = len(null)
    if len(null) >= MIN_PLACEBOS:                          # (p: as high by chance; p_lower: as low - the other way)
        res["p"] = (1 + sum(1 for x in null if x >= m)) / (1 + len(null))
        res["p_lower"] = (1 + sum(1 for x in null if x <= m)) / (1 + len(null))
    return res


def _pc(x, digits: int = 1) -> str:
    return "-" if x is None else f"{x * 100:.{digits}f}%"


def _pts(x) -> str:
    return "-" if x is None else f"{x * 100:+.1f}"


def reading(m: dict) -> dict:
    """The regime call (V5 §7) with the numbers behind it - honest about what the warm set can and can't show.
    Concentration first (a lump shrinks a mean-relative warm set as surely as draining does), subcritical read from
    persistence, turnover from re-entries (old nodes back in the hot set - births alone turn any set over), and topic
    tracking only when it clears a placebo test."""
    rows = m["rows"]
    if len(rows) < 3:
        return {"regime": "too few turns", "evidence": [], "caveats": []}
    half = rows[len(rows) // 2:]
    ws = [r["warm_share"] for r in half]
    hs = [r["hot_share"] for r in half]
    j1 = _mean(r["j1_warm"] for r in half)
    j10 = _mean(r["j10_warm"] for r in half)
    j1h = _mean(r["j1_hot"] for r in half)
    j10h = _mean(r["j10_hot"] for r in half)
    top5 = _mean(r["top5_share"] for r in half)
    top5p = _mean(r.get("top5pct_share") for r in half)
    gini = _mean(r["gini"] for r in half)
    eff = _mean((r["effective_n"] or 0) / r["citizens"] for r in half if r["citizens"])
    lump = _mean(r["warm_lcc_share_no_pc"] for r in half)
    re1, re10 = _mean(r.get("reentry1_hot") for r in half), _mean(r.get("reentry10_hot") for r in half)
    b1, b10 = _mean(r.get("born1_hot") for r in half), _mean(r.get("born10_hot") for r in half)
    slope_w = _slope(ws)
    bnd = [1 - r["j1_warm"] for r in rows if r["boundary"] and r["j1_warm"] is not None]
    inside = [1 - r["j1_warm"] for r in rows if not r["boundary"] and r["j1_warm"] is not None]
    bnd_h = [1 - r["j1_hot"] for r in rows if r["boundary"] and r["j1_hot"] is not None]
    inside_h = [1 - r["j1_hot"] for r in rows if not r["boundary"] and r["j1_hot"] is not None]
    changes = {r["turn"] for r in rows if r["boundary"]}

    def crossing(t: int) -> bool:                 # a scene change inside the five turns ending at t
        return any(b in changes for b in range(t - WINDOW + 1, t + 1))
    # (a cut lands mid-turn and the new scene heats up over the next few: five turns across a change vs five inside)
    cross5 = [1 - r["j5_hot"] for r in rows if r["j5_hot"] is not None and crossing(r["turn"])]
    within5 = [1 - r["j5_hot"] for r in rows if r["j5_hot"] is not None and not crossing(r["turn"])]
    # the topic test on re-entries (decides) and on plain turnover (shown): each change against its neighbourhood
    t_re = topic_test(rows, {r["turn"]: r["reentry5_hot"] for r in rows if r.get("reentry5_hot") is not None})
    t_to = topic_test(rows, {r["turn"]: 1 - r["j5_hot"] for r in rows if r["j5_hot"] is not None})
    topic = _mean(r["topic_warm_share"] for r in rows)
    ev = {"warm_share_mean": _mean(ws), "warm_share_cv": _cv(ws), "warm_share_slope_per_100": (slope_w or 0) * 100,
          "hot_share_mean": _mean(hs), "hot_share_cv": _cv(hs), "j1_warm": j1, "j10_warm": j10, "j1_hot": j1h,
          "j10_hot": j10h, "top5_share": top5, "top5pct_share": top5p,
          "top1pct_share": _mean(r.get("top1pct_share") for r in half), "gini": gini, "effective_share": eff,
          "warm_lump_no_pc": lump, "reentry1_hot": re1, "reentry10_hot": re10, "born1_hot": b1, "born10_hot": b10,
          "turnover_at_boundaries": _mean(bnd), "turnover_inside_scenes": _mean(inside),
          "hot_turnover_at_boundaries": _mean(bnd_h), "hot_turnover_inside_scenes": _mean(inside_h),
          "hot_turnover5_across_a_change": _mean(cross5), "hot_turnover5_inside_a_scene": _mean(within5),
          "topic_reentry": t_re, "topic_turnover": t_to,
          "boundaries": len(bnd), "topic_warm_share": topic, "turns_read": len(half)}
    cv = ev["warm_share_cv"]
    lumped = (top5p or 0) >= LUMP_SHARE or (top5 or 0) > 0.5 or (eff is not None and eff < 0.02)
    empty = ev["hot_share_mean"] is not None and ev["hot_share_mean"] < EMPTY_HOT
    fleeting = j1h is not None and j1h < FLEETING_J1
    stable = cv is not None and cv < STABLE_CV and abs(ev["warm_share_slope_per_100"]) < STABLE_SLOPE
    turning = re10 is not None and re10 >= TURNING_REENTRY
    tracks = t_re["p"] is not None and t_re["p"] < ALPHA and (t_re["mean"] or 0) > 0
    if lumped:
        regime = "supercritical"
        why = (f"the energy sits in a few nodes: the top 5% of citizens hold {_pc(top5p, 0)} of it (the top five "
               f"{_pc(top5, 0)}, effective size {_pc(eff)} of citizens)")
        if j10h is not None and j10h >= 0.8:
            why += (f" and the hot set stays put ({j10h:.2f} Jaccard against ten turns back) - one lump answering "
                    "everything")
        elif j10h is not None:
            why += (f" - though the hot set moves ({j10h:.2f} against ten back): a concentrated spotlight more than "
                    "a lump")
    elif empty or fleeting:
        regime = "subcritical"
        why = (f"nothing stands above the rising mean: {_pc(ev['hot_share_mean'], 2)} of citizens are hot and no few "
               f"nodes hold the energy (the top 5%: {_pc(top5p, 0)})" if empty else
               f"the hot set hardly carries over ({j1h:.2f} Jaccard against the turn before): what a turn touches "
               "sinks before the next")
    elif stable and turning:
        regime = ("critical" if tracks and t_re["mean"] >= STRONG_TRACKING else
                  "critical (topic tracking weak)" if tracks else "critical (topic tracking unproven)")
        ci = t_re["ci"] or [None, None]
        other = t_re["p_lower"] is not None and t_re["p_lower"] < ALPHA
        why = (f"a stable warm population (CV {cv:.2f}) whose hot set takes old members back - {_pc(re10)} of it "
               f"re-warmed against ten turns back, {_pc(b10)} newborn. Across a scene change the share of the hot "
               f"set that is re-warmed old nodes runs {_pts(t_re['mean'])} points against the in-scene windows "
               f"around it (95% CI {_pts(ci[0])} to {_pts(ci[1])}, placebo p "
               + ("-" if t_re["p"] is None else f"{t_re['p']:.2f}") + f", {t_re['events']} changes, a run within "
               f"{WINDOW} turns counted once)"
               + (" - the signature V5 §7 calls continuity" if regime == "critical" else " - real, but small"
                  if tracks else " - the other way round: fewer old nodes come back across a change" if other
                  else " - not distinguishable from noise")
               + f". Raw: hot-set turnover {_pc(ev['hot_turnover_at_boundaries'])} at a change vs "
               f"{_pc(ev['hot_turnover_inside_scenes'])} inside a scene, over five turns "
               f"{_pc(ev['hot_turnover5_across_a_change'])} vs {_pc(ev['hot_turnover5_inside_a_scene'])}")
    elif stable:
        regime = "stable but frozen"
        why = (f"the population holds, but old nodes hardly come back into the hot set ({_pc(re10)} re-warmed against "
               "ten turns back) - ")
        why += (f"only newborns come and go ({_pc(b10)}): a recency conveyor over a fixed core, not a working set "
                "that re-warms with its topic" if (b10 or 0) > (re10 or 0) else "its membership hardly turns over")
    else:
        regime = "indeterminate"
        why = "the population isn't stable over the second half of the log"
    caveats = [
        "Warm is ratio >= 1 (Substrate.observe). In a right-skewed distribution a good third of the graph is always "
        "warm, so the warm set's size is partly arithmetic; the hot set (>= 2x) and its turnover carry the regime "
        "call more than the warm count does.",
        "Warm and hot are measured against the mean, which moves with the energy: a small warm set can't tell a "
        "drained graph from one lump. So the lump call comes first and reads energy shares (the top 5% of "
        "citizens' share, the top five's, the effective size), and subcritical is read from persistence (does the "
        "hot set carry over from turn to turn?), not from size.",
        "Nearly every node entering the warm set is newborn - every turn's slice starts hot - so plain turnover "
        "(Jaccard) falls with distance whatever retrieval does. 'Turning over' and the topic test count re-entries: "
        "old nodes, below 2x the mean at the earlier turn, back in the hot set.",
        f"The topic test's p-value is a placebo test: the log's own pattern of scene changes shifted round the log; "
        f"changes within {WINDOW} turns of each other count once. Under p {ALPHA} it says tracking, otherwise "
        "unproven.",
        "The mean is global (V5/IRD O8 imagines regional attention); a busy region raises everyone's waterline.",
        "The PCs are in nearly every slice and hub the graph, so any warm set is one connected piece through them: "
        "the lump test drops them (warm_lcc_share_no_pc). Even then the spine chains the recent slices and the "
        "scene and fact links tie them to their people, so a connected warm set is the graph's shape, not "
        "concentration - the energy shares (top-5, effective size) carry the lump call.",
        "A scene close renormalizes (mean -> 1), so the rising mean is read turn to turn, never across a close; and "
        "only from one file to the next turn's - across a gap in the log, growth, the books and rehydration are "
        "left out and the lags find no file.",
    ]
    if m["rebuilt_turns"]:
        caveats.append(f"{m['rebuilt_turns']} of {m['rebuilt_turns'] + m['exact_turns']} turns are reconstructed: "
                       "heat and existence are exact there, link strength and touches approximate, deposits and the "
                       "GM's lookups missing (see each file's exactness map).")
    return {"regime": regime, "why": why, "evidence": ev, "caveats": caveats}


def analyze(d: Path | str, out: Path | str | None = None) -> dict:
    """Read the log in `d`; write measures.csv, summary.json and report.html to `out` (default: d/analysis)."""
    d = Path(d)
    out = Path(out) if out else d / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    m = measure(d)
    rows = m["rows"]
    with open(out / "measures.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, MEASURES, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: (fmt.rnd(v) if isinstance(v, float) else v) for k, v in r.items()})
    ages = [[a, _median(m["ages"][a]), len(m["ages"][a])] for a in AGES if m["ages"].get(a)]
    mint = m["mint"]
    by_why = defaultdict(list)
    for x in mint:
        by_why[x["why"] + (" (approximate: origins x one mean)" if x["approx"] else "")].append(x["ratio"])
    mean_growth = [r["mean_growth"] for r in rows if r["mean_growth"] is not None]
    g = _median(mean_growth)
    unexplained = [abs(r["energy_unexplained"]) / abs(r["delta_total"]) for r in rows
                   if r["energy_unexplained"] is not None and r["delta_total"]]
    summary = {
        "log": str(d), "turns": len(rows), "exact_turns": m["exact_turns"], "reconstructed_turns": m["rebuilt_turns"],
        "first_turn": rows[0]["turn"] if rows else None, "last_turn": rows[-1]["turn"] if rows else None,
        "criticality": reading(m),
        "echo_all_sections": echo(m["surf_turns"], m["scene_of_turn"], m["surfaced_turns"], m["names"]),
        "echo_energy_ranked": echo(m["surf_ranked"], m["scene_of_turn"], m["surfaced_turns"], m["names"]),
        "lakes": {
            "mint_ratio_by_why": {k: {"median": _median(v), "min": min(v), "max": max(v), "n": len(v)}
                                  for k, v in sorted(by_why.items())},
            "mint_ratio_note": "energy_minted / the touch's deposit (stats.deposit: each origin's quantum at the mean "
                               "it met - touch_all re-reads it per origin; where a file has none, origins x the mean "
                               "before x touch_quantum x quantum_ratio, approximate); the honest mint is 2.0 for an "
                               "infinite cascade, a little under where packets stop at the floor; a diode passes its "
                               "full arrival on and keeps half, so diode hops mint above it",
            "mint_over_2": sum(1 for x in mint if not x["approx"] and x["ratio"] > 2.0 + 1e-9),
            "touches_measured": sum(1 for x in mint if not x["approx"]),
            "diode_touches_over_2": sum(1 for x in mint if not x["approx"] and x["ratio"] > 2.0 + 1e-9
                                        and x.get("diode_hops")),
            "median_mean_growth_per_turn": g,
            "untouched_half_life_turns": (math.log(2) / math.log(1 + g)) if g and g > 0 else None,
            "forgetting_curve": ages,
            "dry_share_last": rows[-1]["dry_share"] if rows else None,
            "new_link_local_ratio_median": _median(m["new_link_ratios"]),
            "new_link_local_ratio_quartiles": (statistics.quantiles(m["new_link_ratios"], n=4)
                                               if len(m["new_link_ratios"]) >= 4 else None),
            "rehydrations": sum(r["rehydrated"] or 0 for r in rows),
            "books_unexplained_median": _median(unexplained) if unexplained else None,
            "books_turns": len(unexplained),
            "gaps": sum(1 for r in rows[1:] if not r["consecutive"]),   # (files measured against no file a turn back)
        },
        "topic": {"topic_warm_share_mean": _mean(r["topic_warm_share"] for r in rows),
                  "hot_in_topic_share_mean": _mean(r["hot_in_topic_share"] for r in rows),
                  "surfaced_warm_share_mean": _mean(r["surfaced_warm_share"] for r in rows),
                  "surfaced_origin_share_mean": _mean(r["surfaced_origin_share"] for r in rows)},
        "exactness": m["exactness"],
        "partial_turns": m["partial"],             # (forward files whose touches couldn't be vouched for, and why)
        "chapters": chapters(m),                   # (new parties: the old crew's heat across the change of crews)
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=1, default=str), encoding="utf-8")
    from .report import render
    (out / "report.html").write_text(render(summary, rows), encoding="utf-8")
    return {"turns": len(rows), "csv": str(out / "measures.csv"), "html": str(out / "report.html"),
            "summary": summary}
