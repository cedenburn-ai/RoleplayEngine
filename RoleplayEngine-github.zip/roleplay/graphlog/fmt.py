"""The graph log's files (schema 1): where they live, how they're packed, and what the packet showed.

    campaigns/<campaign>_graph/
      T000189.json.gz   the graph after turn 189 and the process that made it (FORMAT below)
      T000189.minds.json.gz   who everyone is and what's on their mind after it (minds.py, FORMAT below)
      catalog.jsonl     node text, one line per version (text never repeats in the turn files)
      turns.csv         one row a turn, for a quick look in a spreadsheet
      FORMAT.txt        the format, for whoever opens the folder
      marks.jsonl       what the engine did between turns that no touch says (a new party), as it happened
      pending.jsonl     the recorder's buffer: what happened since the newest turn file (a working file)

Tables are packed {"columns": [...], "rows": [[...], ...]} - a turn's 2,000 nodes and 7,000 links as dicts would
repeat every key 9,000 times. `rows_of(table)` unpacks one. Everything stdlib: gzip + json.
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import os
import re
from pathlib import Path

from ..substrate.store import SLICE_RE, norm_id

SCHEMA = 1
DIR_SUFFIX = "_graph"
CATALOG = "catalog.jsonl"
TURNS_CSV = "turns.csv"
FORMAT_TXT = "FORMAT.txt"
_TURN_FILE = re.compile(r"^T(\d{6})\.json\.gz$")

NODE_COLUMNS = ["id", "kind", "created_turn", "scene_id", "visibility", "energy", "ratio", "touch_count",
                "last_touched_turn", "superseded_by", "deposited"]
LINK_COLUMNS = ["a", "b", "kind", "strength", "together", "last_turn"]
DEPOSIT_COLUMNS = ["touch", "node", "amount"]
CSV_COLUMNS = ["turn", "reconstructed", "scene_id", "session", "private", "fight", "slice_id", "nodes", "citizens",
               "links", "mean", "total", "warm", "hot", "gini", "top5_share", "touches", "minted", "nodes_deposited",
               "surfaced", "looked_up", "new_nodes", "new_links", "strength_changes", "supersessions", "knows_added",
               "renormalized", "bytes", "ms", "minds_bytes"]
SIG = 6          # significant digits for derived floats (ratios, per-touch deposits): exact enough, and gzip likes them


def log_dir(db_path: Path | str) -> Path:
    """campaigns/<campaign>_graph/, beside the campaign file (as _art and _undo are)."""
    p = Path(db_path)
    return p.parent / f"{p.stem}{DIR_SUFFIX}"


def turn_file(d: Path, turn: int) -> Path:
    return d / f"T{int(turn):06d}.json.gz"


def turns_on_file(d: Path) -> list[int]:
    if not d.exists():
        return []
    return sorted(int(m.group(1)) for p in d.iterdir() if (m := _TURN_FILE.match(p.name)))


def rnd(x, sig: int = SIG):
    """A derived float at SIG significant digits (None stays None)."""
    return None if x is None else float(f"{x:.{sig}g}")


def table(columns: list[str], rows: list) -> dict:
    return {"columns": list(columns), "rows": [list(r) for r in rows]}


def rows_of(tbl: dict | None) -> list[dict]:
    """A packed table as dicts."""
    if not tbl:
        return []
    cols = tbl["columns"]
    return [dict(zip(cols, r)) for r in tbl["rows"]]


def write_turn(d: Path, doc: dict) -> int:
    """Write one turn's file atomically (a reader never sees half a file). Returns its size in bytes."""
    d.mkdir(parents=True, exist_ok=True)
    data = gzip.compress(json.dumps(doc, separators=(",", ":"), ensure_ascii=False).encode("utf-8"), compresslevel=6)
    path = turn_file(d, doc["meta"]["turn"])
    tmp = path.with_name(path.name + ".part")
    tmp.write_bytes(data)
    os.replace(tmp, path)
    if not (d / FORMAT_TXT).exists() or (d / FORMAT_TXT).read_text(encoding="utf-8") != FORMAT:
        (d / FORMAT_TXT).write_text(FORMAT, encoding="utf-8")     # (kept current: the format grows a field)
    return len(data)


def read_turn(d: Path, turn: int) -> dict:
    return json.loads(gzip.decompress(turn_file(d, turn).read_bytes()).decode("utf-8"))


# ── the catalog: node text once per version ─────────────────────────────
def text_hash(text: str | None) -> str:
    return hashlib.blake2b((text or "").encode("utf-8"), digest_size=8).hexdigest()


def read_catalog(d: Path) -> list[dict]:
    p = d / CATALOG
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:            # (a line cut short by a crash: skip it, never the whole catalog)
                continue
    return out


def catalog_at(entries: list[dict], turn: int | None = None) -> dict[str, dict]:
    """{id: the catalog entry in force at `turn`} (None: the newest of each)."""
    out: dict[str, dict] = {}
    for e in sorted(entries, key=lambda e: (e.get("since") or 0)):
        if turn is None or (e.get("since") or 0) <= turn:
            out[e["id"]] = e
    return out


def append_catalog(d: Path, entries: list[dict]) -> None:
    if not entries:
        return
    d.mkdir(parents=True, exist_ok=True)
    with open(d / CATALOG, "a", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e, separators=(",", ":"), ensure_ascii=False) + "\n")


def write_catalog(d: Path, entries: list[dict]) -> None:
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / (CATALOG + ".part")
    with open(tmp, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e, separators=(",", ":"), ensure_ascii=False) + "\n")
    os.replace(tmp, d / CATALOG)


# ── marks.jsonl: what the engine did between turns that no touch says ────
MARKS = "marks.jsonl"


def append_mark(d: Path, ev: dict) -> None:
    d.mkdir(parents=True, exist_ok=True)
    with open(d / MARKS, "a", encoding="utf-8") as f:
        f.write(json.dumps(ev, separators=(",", ":"), ensure_ascii=False) + "\n")


def read_marks(d: Path) -> list[dict]:
    p = d / MARKS
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            out.append(json.loads(line))
        except ValueError:                # (a line cut short by a crash)
            continue
    return out


# ── pending.jsonl: the recorder's buffer on disk (what the next turn file will carry) ──
# The offscreen world touches right after every turn and the bot restarts between turns (a deploy, a crash): held only
# in memory, those deposits were gone while the record kept them. First line: the buffer's base - the turn file it
# counts from - and why it may be incomplete; then one line per touch, renormalization and mark as it happens.
PENDING = "pending.jsonl"


def append_pending(d: Path, item: dict) -> None:
    d.mkdir(parents=True, exist_ok=True)
    with open(d / PENDING, "a", encoding="utf-8") as f:
        f.write(json.dumps(item, separators=(",", ":"), ensure_ascii=False) + "\n")


def write_pending(d: Path, items: list[dict]) -> None:
    """The whole buffer, rewritten atomically (after a turn file, a clear, a rewind, an undo)."""
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / (PENDING + ".part")
    with open(tmp, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, separators=(",", ":"), ensure_ascii=False) + "\n")
    os.replace(tmp, d / PENDING)


def read_pending(d: Path) -> tuple[dict | None, list[dict]]:
    """(the header - {k: "base", turn, gap} - or None, the items after it)."""
    p = d / PENDING
    if not p.exists():
        return None, []
    head, items = None, []
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except ValueError:                # (a line cut short by a crash: that one touch is lost, not the rest)
            continue
        if item.get("k") == "base" and head is None and not items:
            head = item
        else:
            items.append(item)
    return head, items


def exact(doc: dict, field: str) -> bool:
    """Is this field of a turn file exact? (its exactness map: the field's own entry, else "*")."""
    ex = doc.get("exactness") or {}
    return str(ex.get(field, ex.get("*", ""))).startswith("exact")


# ── turns.csv ────────────────────────────────────────────────────────────
def read_csv(d: Path) -> dict[int, dict]:
    p = d / TURNS_CSV
    if not p.exists():
        return {}
    with open(p, newline="", encoding="utf-8") as f:
        return {int(r["turn"]): r for r in csv.DictReader(f) if (r.get("turn") or "").isdigit()}


def write_csv(d: Path, rows: dict[int, dict]) -> None:
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / (TURNS_CSV + ".part")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, CSV_COLUMNS, extrasaction="ignore")
        w.writeheader()
        for t in sorted(rows):
            w.writerow(rows[t])
    os.replace(tmp, d / TURNS_CSV)


def append_csv(d: Path, row: dict) -> None:
    """One more row - or, if the turn is already there (a re-run after an undo the log missed) or the file's header is
    an older one (a column added since), the file rewritten."""
    p = d / TURNS_CSV
    have = read_csv(d) if p.exists() else {}
    if p.exists():
        with open(p, newline="", encoding="utf-8") as f:
            old = next(csv.reader(f), None) != CSV_COLUMNS
    else:
        old = False
    if old or int(row["turn"]) in have or (have and max(have) > int(row["turn"])):
        have[int(row["turn"])] = row
        write_csv(d, have)
        return
    new = not p.exists()
    with open(p, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, CSV_COLUMNS, extrasaction="ignore")
        if new:
            w.writeheader()
        w.writerow(row)


def csv_row(doc: dict, size: int, ms: float | None, minds_bytes: int | None = None) -> dict:
    """The quick-look row for one turn file (minds_bytes: its minds file's size - empty when it wasn't written)."""
    m, met, pr = doc["meta"], doc.get("metrics") or {}, doc.get("process") or {}
    touches = pr.get("touches") or []
    minted = sum((t.get("stats") or {}).get("energy_minted") or 0 for t in touches)
    return {"turn": m["turn"], "reconstructed": int(bool(doc.get("reconstructed"))), "scene_id": m.get("scene_id"),
            "session": m.get("session"), "private": int(bool(m.get("private"))),
            "fight": (m.get("fight") or {}).get("id", ""), "slice_id": m.get("slice_id") or "",
            "nodes": m.get("nodes"), "citizens": m.get("citizens"), "links": m.get("links"),
            "mean": rnd(m.get("mean")), "total": rnd(m.get("total")), "warm": met.get("warm"), "hot": met.get("hot"),
            "gini": rnd(met.get("gini")), "top5_share": rnd(met.get("top5_share")), "touches": len(touches),
            "minted": rnd(minted), "nodes_deposited": len({r[1] for r in (pr.get("deposits") or {}).get("rows", [])}),
            "surfaced": len({i for ids in (pr.get("surfaced") or {}).values() for i in ids}),
            "looked_up": len(set((pr.get("looked_up") or {}).get("expanded") or [])
                             | set((pr.get("looked_up") or {}).get("seen") or [])),
            "new_nodes": len(pr.get("new_nodes") or []), "new_links": len((pr.get("new_links") or {}).get("rows", [])),
            "strength_changes": len((pr.get("strength_changes") or {}).get("rows", [])),
            "supersessions": len(pr.get("supersessions") or []), "knows_added": len(pr.get("knows_added") or []),
            "renormalized": len(pr.get("renormalized") or []), "bytes": size,
            "ms": "" if ms is None else round(ms, 1), "minds_bytes": "" if minds_bytes is None else minds_bytes}


# ── what the packet surfaced ─────────────────────────────────────────────
_HEADER = re.compile(r"^\s*={3,}\s*(.+?)\s*$")
_BRACKETS = re.compile(r"\[([^\[\]\n]{1,120})\]")
_SPLIT = re.compile(r"[,;\s]+")
# "Current picture (GM-only) [C73, T133]" (substrate/packet.py): the T is the turn the picture was made - a date, not a
# memory shown. Counted, it put T34 in 47 live packets that never printed it (a DM note's "(T149, on ...)" never was).
_PICTURE_STAMP = re.compile(r"^\s*(C\d+)\s*,\s*T\d+\s*$", re.IGNORECASE)


def section_key(header: str) -> str:
    """'FACTS IN PLAY (canon about...) ===' -> facts_in_play; 'SCENE S12: The Bar ===' -> scene."""
    head = re.split(r"\s*[(:·]|\s+-\s+|\s*={3,}", header, maxsplit=1)[0]
    words = [w for w in head.split() if not SLICE_RE.match(w)]
    return "_".join(words).lower() or "top"


def surfaced(packet: str, known) -> dict[str, list[str]]:
    """{packet section: the node ids it printed, in order} - every [id] in the memory packet the GM saw, by the
    section it sat in. `known` is the node ids that existed then: a bracket that isn't a node ('[GUARD]') is skipped."""
    out: dict[str, list[str]] = {}
    section = "top"
    for line in (packet or "").splitlines():
        m = _HEADER.match(line)
        if m:
            section = section_key(m.group(1))
            continue
        for inner in _BRACKETS.findall(line):
            pic = _PICTURE_STAMP.match(inner)
            for tok in [pic.group(1)] if pic else _SPLIT.split(inner):
                if not tok:
                    continue
                nid = norm_id(tok)
                if nid in known:
                    ids = out.setdefault(section, [])
                    if nid not in ids:
                        ids.append(nid)
    return out


FORMAT = """THE GRAPH LOG (roleplay/graphlog, schema 1) - one file per turn: the memory graph after the turn, and the
process that made it.

T<turn>.json.gz - gzipped JSON, analysable on its own with the catalog:
  schema, reconstructed (true: rebuilt from history by `python -m roleplay.graphlog backfill`), exactness
    ({field: "exact" | "partial: why" | "approximate: why" | "missing: why"} - what a reconstructed file could and
    couldn't recover; "*" covers every field not named. A forward file is exact, except "partial" touches and deposits
    when the recorder can't vouch for everything since the last file: it started after touches it never saw (a log
    backfilled before it, an older recorder), the log was off, a file failed to write, or the books don't close - the
    change in total isn't the touches' mint plus what the newborns were born with)
  meta     campaign, turn, scene_id, slice_id (null: a fight round - its round goes in the fight log, not the graph),
           private (a whisper's sender), fight ({id, round, status} while one is on), story_time (minutes),
           session, mean and total energy (citizens), nodes, citizens, links, knobs (the physics constants),
           diff_since (the turn the new/changed lists below are measured against; diff_base_reconstructed: that
           file was a backfill's, so link changes against it are approximate), written_at
  metrics  warm (ratio >= 1), hot (ratio >= 2), gini, top5_share - the engine's own (Substrate.observe) - plus the
           turn's turn_metrics row (seconds, cost, dm_steps, tools...)
  nodes    table: id, kind, created_turn, scene_id, visibility, energy, ratio (energy / mean), touch_count,
           last_touched_turn, superseded_by (the diode's target), deposited (energy deposited on it since the last
           snapshot). Notes and pictures (N#, C#) aren't citizens: no energy.
  links    table: a, b, kind, strength, together, last_turn (symmetric, a < b)
  supersedes [old, new, confidence, by, turn] - every diode on file;  knows [holder, node, how, source, turn];
  doubts   [id, status, raised_turn, resolved_turn]
  process  what happened since the last snapshot:
    touches  each Substrate.touch: why (slice: the memory pass's touch of this turn's own new slice / retrieval: its
             touch of what the turn drew on / gm-facts / offscreen / belief / fight-memory / askdm-lookup /
             aside-lookup / new-party / seed), by (the calling module:function), turn, phase (turn: this turn's;
             between: after the last snapshot and before this turn - the offscreen world, !askdm), quantum_ratio,
             origins (+ origin_why for a retrieval: recalled / authored (a fact the GM wrote this turn) / looked-up /
             mentioned), mean_before, stats (origins, nodes_deposited, energy_minted, links_traversed, waves, deposit:
             the origins' quanta summed, each at the mean it met - the 2x rule's denominator), diode_hops
    deposits table: touch (index into touches), node, amount - every deposit each touch made
    surfaced {packet section: [ids]} - what the memory packet showed the GM, parsed from the packet text itself (a
             picture's "[C#, T#]" counts the picture only: the T# is the turn it was made)
    looked_up {expanded: what the GM opened by id (recall, read_turn), authored: facts the GM wrote this turn
             (establish_fact, a <dm> fact - the engine puts them with what it opened, for the retrieval touch), seen:
             what its searches and timelines showed it, in order, tools: the turn's tool calls, recalled: what the
             memory pass said it drew on}
    new_nodes, removed_nodes, new_links (table), strength_changes (table a, b, old, new), removed_links,
    supersessions, knows_added, doubts_raised, doubts_settled, text_changed (ids with a new catalog entry),
    renormalized ([{turn, mean}] - a scene close divided every energy by the mean), table_presented (portraits the
             table saw big for the first time since the last file - the Discord table shows them after the turn's
             file is written, so they land in the next)
    marks    what the engine did between the last snapshot and this turn that no touch says (absent in older files):
             {kind: "new-party", turn, story_time_from, story_time_to, gap_minutes, former_pcs, scene_closed,
             scene_opened, session, passes, events_after (the event log's seq when the reset began: the lines after
             it are the reset's), rows_after ({nodes, entities, knows}: each table's newest rowid then - a goal, step,
             hook, hearsay row or newcomer above it is the reset's; absent before 2026-10-28)} - the crew changed and
             the clock jumped (roleplay/newparty.py)

T<turn>.minds.json.gz - beside each turn file (roleplay/graphlog/minds.py, its own schema 1): who everyone is and what's
  on their mind after the turn. Every table is the whole state at the snapshot (a keyframe a turn - ~9 KB on the live
  world), so any turn's minds are one file; `events` is what changed since the last minds file, and why. Absent beside
  files from before 2026-10-27 (backfill rebuilds them; a turn file never depends on one).
  schema, kind ("minds"), reconstructed, exactness (as the turn file's; events "partial" in the first minds file of a
           world with history: only what that turn's own numbers date; "approximate" in the first exact file after a
           reconstructed one: see basis below)
  meta       campaign, turn, diff_since (the minds file the events are measured against), events_seq (the event log
             up to this snapshot: the next file's events are the lines after it), scene_id, story_time, written_at,
             characters, in_play, ms (what writing it cost)
  characters table: id, kind (pc | npc | faction), name, condition (sr_lite.condition: ok, wounded, unconscious, dying,
             dead; null for an outfit), tier (2: has a mind), player (a PC's handle), control (player | gm | idle),
             former_pc (the turn a new party made them the GM's), scene (where they are: Ledger.scene_of), place (their
             whereabouts' place, else their scene's), whereabouts (hash: the catalog's where:<id>), moved_at (the story
             minute of that offscreen move), factions ([[outfit, role]]), picture (the GM's current C#), persona (hash:
             the catalog's persona:<id>), sealed (a story seed's secret the crew hasn't met), created_turn, status
             (active | departed: gone home to the character ledger - still on file, their views and numbers standing)
             - every PC, NPC and outfit in the world
  attitudes  table: holder, about, value - every attitude:<id> stat (-3..+3): the whole sparse matrix
  beliefs    table: id (the B#: its text in the catalog), holder, about, created_turn, attitude (what it was formed
             with - the number may have cooled since), why (belief: an NPC thinking a scene over, minds.reflect_scene /
             world / new-party / seed / gm), replaces (the view it superseded) - every current (unsuperseded) view
  knows      table: holder, node, how (told | rumor | on the line | discovered), source (who told them; null: a rumor
             with no teller, a voice on a call, found out), turn - every hearsay row (the turn file's knows, again here
             so a perspective needs only this file)
  agendas    table: id (A#: the goal in the catalog), actor, status (active | done | dropped), targets, steps,
             created_turn, updated_turn (last advanced), next_time (due, story minutes), by (world | gm | seed |
             newparty)
  hooks      table: id (H#), actor, agenda, status (ready | landed | stale), about, created_turn, landed_turn
  holdings   table: holder, item, name, qty - what each character carries (witness.Scope counts it as known)
  witnesses  {slice: [[id, role]]} - every T#/W# slice and who witnessed it by witness.py's own rule: a member in a
             witness role (actor, target, present, location), and a whisper only its sender. A perspective is what
             they witnessed + what they were told (knows)
  witnessing [slices] new since the last minds file, or whose witnesses changed (a merge)
  facts      {id: [F#]} - the canon each character would know, by witness.py's rule (Scope._facts: a fact from a
             moment they hold, one set down in a turn they were in or outside play, one a moment they witnessed drew
             on, one they were told)
  co_presence [[scene, status, [ids]]] - who is in which scene at the snapshot (the active and parked scenes'
             rosters)
  salience   {id: [[node, ratio, how]]} - for each character in play (the PCs, whoever is in the scene or a new
             moment - an offscreen actor who moved - and anyone whose mind changed; never one gone home): the 12
             hottest (energy / mean, the turn file's ratio) of what they hold - how: witnessed, told, fact (facts
             above), belief / agenda (their own current views and active goals); never themselves. What's on their mind
             as the substrate sees it
  salience_people {id: [[node, ratio]]} - the 12 hottest of the people, places and things in those moments and what
             they carry
  events     [{kind, who, ..., why, phase, turn}] since the last minds file - the states diffed, the event log since
             events_seq replayed for the why (marks.jsonl for a new party in between); phase: turn (this turn's) |
             between (before it: the offscreen world, a new party, a read-back) | null (nothing dates it); during:
             "new-party" for a reset's own (its lines after the mark's events_after; with no line, a row above its
             rows_after - the catch-up's goals, steps, hooks, hearsay, newcomers - else the old crew's own changes,
             the rumors it spread and the moves the story clock puts in its gap, after its first minute). A change no
             line dates is a new party's when it's the old crew's, a seed's when the seed made or tied them in
             (seed:applied; a seed's own file splits at the moment it began: everything after is the seed's, nothing
             before), and a move is dated by its story minute. basis: "reconstructed" on a change in a field the file
             before rebuilt from history (the first exact file after a backfill) - with why "reconstruction" where nothing on file explains
             it: the rebuild's, not the world's. Kinds:
             belief {about, id, attitude, replaces} (a view formed - or id null: one gone, unlogged),
             attitude {about, from, to} (why belief | world | new-party | seed | gm | cool: time apart, minds.cool |
             unlogged: a number no line of the log moved), learned {node, how, from} (why told | rumor | on-the-line |
             world | seed), attacked {about: the target, hit, boxes, target_status} (why attack | ram: sr_lite's),
             handed {about: who got it, item, qty} (transfer_item; why gm | world), agenda / hook {id, change: new |
             advanced (steps, moments) | done | dropped | landed | stale, targets / about, reason (a read-back's, or a
             GM's fix: why gm)}, condition {from, to, by (the attacker whose hit did it; a healer), reason} (to dead: a
             death; why damage | heal | repair | time | seed), kind {from, to} (pc -> npc: new-party), renamed {from,
             to} (why gm: a `name` line - the GM's in a turn, an aside's or the owner's !rename between), joined / left
             {faction, role}, moved {from, to} (scenes), whereabouts {place, story_time}, persona, picture {id}, tier,
             sealed / unsealed, appeared {as} (why seed | setup | player: a new runner | world | turn), departed /
             returned (why ledger: !characterledger checkin / checkout), gone (merged)
catalog.jsonl also holds persona:<id> (kind persona: the persona as JSON) and where:<id> (kind whereabouts: where they
  went), one line per version, as node text.
`python -m roleplay.graphlog mind <campaign> <who> [--turn N]` reads one character's mind from these (GM-side), by id or
  any name they've had on file. `status` counts the minds files and names any turn file without one.
marks.jsonl - the same marks, one a line, written the moment they happen (a "new-party-undone" line when the owner
  takes one back with `!rp newparty undo`). The analysis puts any mark no turn file carries (its buffer lost before
  the next turn) on the first file after it.
pending.jsonl - the recorder's buffer: what happened since the newest turn file (its first line names that file), one
  line per touch, renormalization and mark as it happens, so a restart between turns loses none of it. The next turn
  file takes them and the buffer starts again. Not part of the log - a working file.
A world opened with no turns but a folder of turn files under its name (`--new`, a sim's setup: the .db deleted and
  started over) moves that folder to archive/<campaign>-<time>_graph first: a former world's files never mix in.
catalog.jsonl - one line per node version: id, kind, ekind (an entity's kind: pc, npc, location...), created_turn,
  scene_id, since (the first turn this text was on file), text, members ([[id, role]] for a slice). Text changes
  (an entity's description, a scene's summary at close) append a new line.
turns.csv - one row per turn file: the counts above, for a quick look (minds_bytes empty: no minds file beside it).

Reading one in Python:
  import gzip, json; doc = json.loads(gzip.open("T000189.json.gz").read())
  nodes = [dict(zip(doc["nodes"]["columns"], r)) for r in doc["nodes"]["rows"]]
`python -m roleplay.graphlog analyze <campaign>` writes measures.csv and report.html from these.
"""
