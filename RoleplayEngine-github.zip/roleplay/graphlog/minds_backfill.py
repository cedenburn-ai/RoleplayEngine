"""The minds backfill (DESIGN.md §8f, 'Minds per turn'): a minds file for every turn of a campaign played before they
were recorded - read-only, beside the turn files backfill.py rebuilds, each "reconstructed": true with an exactness
map. `python -m roleplay.graphlog backfill` runs it after the graph files; a forward (exact) minds file is never
replaced unless --force, and neither is a turn a forward file's events already cover (one whose own minds file failed:
the next one diffs from the file before it).

What history gives back:
  exact        the attitude matrix (the event log replayed: belief, attitude_cooled) and the views held (belief events
               and their supersessions) - each line placed before or after its turn's snapshot by its time against
               mean_log's stamp of that snapshot; who witnessed each moment (slice membership, energy_history for
               when it is first on file, the whisper's sender); hearsay rows; which goals and hooks exist (their nodes'
               first snapshot), a goal's steps (the moments hung off it that aren't a message - every one of the live
               world's 71 agrees with agendas.steps); a hook landing; who's a PC (a new party's own turn); salience's
               ratios (energy_history)
  approximate  condition (the damage and heal lines' boxes replayed - rest and first aid log none), the scene (the
               newest one they had entered: leaving isn't on file - after an offscreen move, today's), whereabouts
               (today's, from the file the story clock puts its move in), outfits (member_of links, born no earlier
               than both ends), the picture (by its turn), persona (today's), tier (an NPC's mind from their first
               view), name (today's, back through each rename), player (today's), departed (a departure's line), a
               goal's status and updated_turn, a hook going stale (a retirement, a GM's fix, else the actor's next
               hook), who was together (everyone who had entered the turn's scene), the story clock
  missing      control, who carried what (a hand-off is an event), a goal's due as it was
The check: the attitudes replayed to the end must be the ledger's attitude stats exactly, and the views the record's
current beliefs; what came after the last snapshot (the next forward file's) is listed, not counted against it.
"""
from __future__ import annotations

import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ..seed import NOT_MET
from . import fmt, minds
from .backfill import NEVER, History, _has

EXACTNESS = {
    "*": "exact (what isn't named below: created_turn, former_pc, the meta but its story_time, salience_people's "
         "ratios)",
    "meta.story_time": "approximate: the clock when this turn's slice (else the latest before it) was written",
    "attitudes": "exact (the event log replayed - belief, attitude_cooled - each line placed before or after its turn's "
                 "snapshot by its time against mean_log's, to the second)",
    "beliefs": "exact (belief events and supersedes, placed the same way)",
    "knows": "exact (the rows; placed by knows.turn - one the offscreen world told or found after a turn's snapshot "
             "(a call whose W# is first on file in the next, a discovery), or a rumor a new party's scene close "
             "spread, in the next file)",
    "agendas.existence": "exact (the A# node's first snapshot)", "agendas.targets": "exact",
    "agendas.steps": "exact (the moments hung off it that aren't a message)",
    "agendas.status": "approximate: from a retirement's event, else its updated_turn",
    "agendas.updated_turn": "approximate: its newest step by then", "agendas.next_time": "approximate: today's",
    "hooks.existence": "exact (the H# node's first snapshot)", "hooks.landed": "exact (landed_turn)",
    "hooks.stale": "approximate: from a retirement's or a GM's fix line (correct: dropped), else the actor's next hook",
    "witnesses": "exact (slice membership; energy_history for when each slice is on file; the whisper's sender)",
    "witnessing": "exact",
    "facts": "exact (witness.Scope's rule over what was on file by then; a fight's members as they are now)",
    "characters.id": "exact (the entity's node in energy_history; a merged one until its merge)",
    "characters.kind": "exact (a new party's turn)",
    "characters.name": "approximate: today's, back through each renamed line (the name it replaced, before it)",
    "characters.condition": "approximate: every damage and heal line's boxes replayed on both tracks against today's "
                            "monitor ('ok' before any; a damage line's own status where it gives one) - a rest or "
                            "first aid logs no boxes, so its healing waits for the next line",
    "characters.tier": "approximate: today's - an NPC's mind (2) from the file of their first view "
                       "(minds.reflect_scene, a seed's feeling), 1 before it",
    "characters.player": "approximate: today's (a former PC's own before)",
    "characters.control": "missing",
    "characters.whereabouts": "approximate: today's, from the first file whose story clock is at or after its move "
                              "(whereabouts.time: a move in the same minute as several files lands in the first); "
                              "none before",
    "characters.moved_at": "approximate: as whereabouts",
    "characters.scene": "approximate: the newest scene they had entered by then (scene_presence; leaving isn't on "
                        "file); from their whereabouts' file, today's (the move took them off screen, and nothing has "
                        "brought them back since: that clears whereabouts)",
    "characters.place": "approximate: their whereabouts' place once it's on file, else their scene's",
    "characters.factions": "approximate: member_of links, born no earlier than both ends; today's roles",
    "characters.picture": "approximate: the newest picture by its turn (one the offscreen world or a new party wrote, "
                          "after that turn's snapshot: the next file)",
    "characters.persona": "approximate: today's, from their first turn on file (a former PC's from their new party's "
                          "file: a player's character has none)",
    "characters.sealed": "approximate: from its seed's turn until a public moment or fact from play has them",
    "characters.status": "approximate: departed from a departure's line (charledger.check_in) and active again from a "
                         "return's; with no line, departed after their last moment on file",
    "co_presence": "approximate: the turn's scene - everyone who had entered it by then",
    "holdings": "missing: the record keeps only who carries what now (each hand-off is an event: transfer_item)",
    "salience": "exact (energy_history's ratios over what they hold: witnesses, knows, facts, views, goals)",
    "events": "approximate: as exact as the fields they diff (belief, attitude, learned events: exact)",
}
BETWEEN_BY = ("world", "newparty")                # (a line only the offscreen world or a new party writes)
BETWEEN_KINDS = ("retired", "new_party")          # (a read-back between turns; the reset's own)


class MindHistory:
    """What the minds backfill reads beyond the graph's History, read once."""

    def __init__(self, c, H: History):
        self.H = H
        q = lambda sql, *a: c.execute(sql, a).fetchall()     # noqa: E731
        self.ents = [dict(r) | {"props": json.loads(r["props"] or "{}")} for r in q(
            f"SELECT * FROM entities WHERE kind IN ({','.join('?' * len(minds.KINDS))}) ORDER BY rowid", *minds.KINDS)]
        self.scenes = {r["id"]: dict(r) for r in q("SELECT id, title, location_id FROM scenes")}
        self.turn_scene = {t: (H.metrics.get(t) or {}).get("scene_id") or (H.turns.get(t) or {}).get("scene_id")
                           for t in H.ratios}
        self.seeds = {r[0] for r in q("SELECT id FROM turns WHERE status='seed'")}
        self.senders = {f"T{r[0]}": r[1] for r in q("SELECT id, private FROM turns WHERE private IS NOT NULL AND "
                                                    "status IN ('committed','seed')")}
        self.snaps = sorted(H.ratios)
        self.stamp: dict[int, str] = {}
        if "created_at" in {r[1] for r in c.execute("PRAGMA table_info(mean_log)")}:
            for r in q("SELECT turn, created_at FROM mean_log ORDER BY rowid"):
                self.stamp[r[0]] = r[1]
        self.events = [{"seq": r[0], "turn": r[1], "kind": r[2], "actor": r[3], "p": _load(r[4]), "at": r[5]}
                       for r in q("SELECT seq, turn_id, kind, actor, payload, created_at FROM events ORDER BY seq")]
        self.file_of: dict[int, int] = {}        # seq -> the file it lands in (NEVER: after the last snapshot)
        self._place()
        self.agendas = [dict(r) for r in q("SELECT * FROM agendas ORDER BY rowid")]
        self.hooks = [dict(r) for r in q("SELECT * FROM hooks ORDER BY rowid")]
        self.pictures = [dict(r) for r in q("SELECT id, target_id, created_turn, by FROM clarifications")]
        self.replaces = {s["new_id"]: s["old_id"] for s in H.sup if str(s["new_id"]).startswith("B")}
        self.attitudes = {(r[0], r[1].split(":", 1)[1]): minds._num(r[2]) for r in q(
            "SELECT entity_id, key, value FROM stats WHERE key LIKE 'attitude:%'")}
        self.current = {r[0] for r in q("SELECT id FROM nodes WHERE kind='belief' AND id NOT IN "
                                        "(SELECT old_id FROM supersedes)")}
        by_kind = defaultdict(list)
        for i, l in enumerate(H.links):
            by_kind[l["kind"]].append((l, H.birth[i][0]))
        self.links = by_kind
        targeted = {s for s, ms in H.members.items() if any(r == "target" for _, r in ms)}
        self.steps: dict[str, list[str]] = defaultdict(list)     # A# -> its steps (W#, never a message)
        for l, _ in by_kind["step"]:
            a, w = (l["a"], l["b"]) if str(l["a"]).startswith("A") else (l["b"], l["a"])
            if w not in targeted:                                # (a message hangs off its goal too: world.reach_out)
                self.steps[a].append(w)
        self.about: dict[str, list[str]] = defaultdict(list)
        for l, _ in by_kind["about"]:
            for x, y in ((l["a"], l["b"]), (l["b"], l["a"])):
                if str(x)[:1] in ("A", "H"):
                    self.about[x].append(y)
        # the canon's inputs (witness.Scope._facts): each fact's moments - the one it came out of (about), the ones that
        # drew on it (recall) - with when each link is on file, what the read-back set down between turns, the turns
        self.fact_links: list[tuple[str, str, str, int]] = []    # (about | recall, fact, slice, first on file)
        for kind in ("about", "recall"):
            for l, born in by_kind[kind]:
                ka, kb = H.nodes.get(l["a"], {}).get("kind"), H.nodes.get(l["b"], {}).get("kind")
                if {ka, kb} == {"fact", "slice"}:
                    f, s = (l["a"], l["b"]) if ka == "fact" else (l["b"], l["a"])
                    self.fact_links.append((kind, f, s, born))
        from ..dm.dmblock import between_turns
        self.between = between_turns(c)
        self.on_file = {r[0] for r in q("SELECT id FROM turns")}
        self.whispers = defaultdict(set)
        for r in q("SELECT id, private FROM turns WHERE private IS NOT NULL AND status IN ('committed','seed')"):
            self.whispers[r[1]].add(r[0])
        self.fights = []                                         # (who was in it, its rounds) - Scope._rounds
        if _has(c, "encounters"):
            for e in q("SELECT scene_id, started_turn, ended_turn, members, positions FROM encounters"):
                try:
                    inside = set(json.loads(e[3] or "{}")) | set(json.loads(e[4] or "{}"))
                except (ValueError, TypeError):
                    continue
                if e[1] is not None and inside:
                    self.fights.append((inside, {r[0] for r in q(
                        "SELECT id FROM turns WHERE scene_id=? AND id BETWEEN ? AND ? AND private IS NULL AND "
                        "status='committed'", e[0], e[1], e[2] or NEVER)}))
        sealed = set(json.loads((c.execute("SELECT value FROM meta WHERE key='seed:sealed'").fetchone() or ["[]"])[0]
                                or "[]"))
        applied = json.loads((c.execute("SELECT value FROM meta WHERE key='seed:applied'").fetchone() or ["[]"])[0]
                             or "[]")
        self.sealed = sealed
        self.sealed_from = min((int(a.get("turn") or 0) for a in applied), default=None) if sealed else None
        from ..newparty import KEY
        row = c.execute("SELECT value FROM meta WHERE key=?", (KEY,)).fetchone()
        try:
            self.parties = [r for r in json.loads(row[0]) if r.get("status") != "running"] if row else []
        except ValueError:
            self.parties = []
        self.resets = {(int(r["turn"]), r.get("scene_closed")) for r in self.parties if r.get("turn") is not None}
        self.knows_file = {(k["holder"], k["node_id"]): self._knows_file(k) for k in H.knows}
        self.seed_cast = minds.seed_cast(c)
        # each snapshot's story clock, as backfill.py's meta has it: its turn's slice's, else the latest before
        stamped = sorted((H.first.get(s, NEVER), n["story_time"]) for s, n in H.nodes.items()
                         if n["kind"] == "slice" and n.get("story_time") is not None)
        self.clock: dict[int, int | None] = {}
        best, i = None, 0
        for t in self.snaps:
            while i < len(stamped) and stamped[i][0] <= t:
                best, i = stamped[i], i + 1
            own = (H.nodes.get(f"T{t}") or {}).get("story_time")
            self.clock[t] = own if own is not None else (best[1] if best else None)
        # today's whereabouts, from the first file the story clock puts the move in (world.move stamps its time);
        # from then on the scene is today's too - the move took them off screen, and coming back on clears it
        self.scene_now = minds.scenes_now(c)
        self.moved: dict[str, tuple[int, dict]] = {}
        for e in self.ents:
            w = e["props"].get("whereabouts") or {}
            if w.get("where"):
                at = w.get("time")
                f = next((t for t in self.snaps if at is not None and self.clock.get(t) is not None
                          and self.clock[t] >= at), NEVER)
                self.moved[e["id"]] = (max(f, H.first.get(e["id"], 0)), w)
        self.conditions = self._conditions(c)
        self.pic_file = {p["id"]: self._next(p["created_turn"] or 0, strictly=p["by"] in BETWEEN_BY)  # (written
                         for p in self.pictures}                       # between turns by them: after the snapshot)
        self.renames: dict[str, list[tuple[int, str]]] = defaultdict(list)      # id -> [(file, the name before it)]
        self.homes: dict[str, list[tuple[int, str]]] = defaultdict(list)        # id -> [(file, status from it)]
        self.first_view: dict[str, int] = {}                                     # id -> their first view's file
        for e in self.events:
            if not e["actor"]:
                continue
            if e["kind"] == "renamed":
                self.renames[e["actor"]].append((self.file_of[e["seq"]], e["p"].get("from")))
            elif e["kind"] in ("departed", "returned"):
                self.homes[e["actor"]].append((self.file_of[e["seq"]],
                                               "departed" if e["kind"] == "departed" else "active"))
            elif e["kind"] == "belief":
                self.first_view.setdefault(e["actor"], self.file_of[e["seq"]])
        for e in self.ents:                       # (gone home before the line was logged: after their last moment)
            if e["status"] == "departed" and not self.homes.get(e["id"]):
                last = max((H.first.get(s, 0) for s, ms in H.members.items() if any(m == e["id"] for m, _ in ms)),
                           default=None)
                self.homes[e["id"]] = [(self._next(last, strictly=True) if last is not None
                                        else H.first.get(e["id"], 0), "departed")]

    # ── when each line lands ──
    def _next(self, t: int, strictly: bool) -> int:
        for s in self.snaps:
            if s > t or (s == t and not strictly):
                return s
        return NEVER

    def _place(self) -> None:
        """Each line's file: its turn's, unless it came after that turn's snapshot (later than mean_log's stamp - or in
        the same second, once a line only the offscreen world, a read-back or a new party writes has come: the event
        log's order is the game thread's), then the next snapshot's."""
        after_from: dict[int, int] = {}          # turn -> the first seq known to come after its snapshot
        for e in self.events:
            t, s = e["turn"], self.stamp.get(e["turn"])
            if t is None:                         # (no turn: by its time, the first snapshot stamped at or after it)
                self.file_of[e["seq"]] = next((x for x in self.snaps if (self.stamp.get(x) or "") >= (e["at"] or "")),
                                              NEVER)
                continue
            if t not in self.H.ratios:
                self.file_of[e["seq"]] = self._next(t, strictly=False)
                continue
            late = (s is not None and e["at"] is not None and e["at"] > s) or (
                (e["p"].get("by") in BETWEEN_BY or e["kind"] in BETWEEN_KINDS) and (s is None or e["at"] == s))
            if late or (t in after_from and e["seq"] >= after_from[t]):
                after_from.setdefault(t, e["seq"])
                self.file_of[e["seq"]] = self._next(t, strictly=True)
            else:
                self.file_of[e["seq"]] = t

    def _knows_file(self, k: dict) -> int:
        """A hearsay row's file: its turn's, or the next when the offscreen world told it or found it out after that
        turn's snapshot (a call is a W# both ends lived, first on file in the next snapshot), or a new party's scene
        close spread it (a rumor of a moment in the scene the reset closed, at its turn)."""
        H, t = self.H, int(k["turn"] or 0)
        late = k["how"] == "discovered" or (k["how"] == "rumor" and (
            t, (H.nodes.get(k["node_id"]) or {}).get("scene_id")) in self.resets)
        if k["how"] == "told" and k["source"]:
            for w, ms in H.members.items():
                if H.nodes.get(w, {}).get("created_turn") == t and H.first.get(w, 0) > t and \
                        (k["source"], "actor") in ms and (k["holder"], "target") in ms:
                    late = True
                    break
        base = self._next(t, strictly=late) if (late or t not in H.ratios) else t
        return max(base, H.first.get(k["node_id"], 0), H.first.get(k["holder"], 0))

    def _conditions(self, c) -> dict[str, list[tuple[int, str]]]:
        """{id: [(file, their condition from it)]} - the damage and heal lines' boxes replayed on the two tracks
        against today's monitor, by sr_lite's own rules (stun past its track spills into physical, one box for two;
        the thresholds of sr_lite.condition); a damage line's own status where it gives one (on the live world every
        one agrees with the replay). A repair that says someone died, dead."""
        st: dict[str, dict] = defaultdict(dict)
        for r in c.execute("SELECT entity_id, key, value FROM stats WHERE key IN ('body', 'willpower')"):
            st[r[0]][r[1]] = r[2]
        people = {e["id"] for e in self.ents if e["kind"] in ("pc", "npc")}
        tracks: dict[str, tuple[float, float]] = {}
        out: dict[str, list[tuple[int, str]]] = defaultdict(list)
        for e in self.events:
            eid, p = e["actor"], e["p"]
            if eid not in people or e["kind"] not in ("damage", "heal", "repair"):
                continue
            body = st[eid].get("body", 2)
            pmax, smax = 8 + math.ceil(body / 2), 8 + math.ceil(st[eid].get("willpower", 2) / 2)
            phys, stun = tracks.get(eid, (0, 0))
            boxes = p.get("boxes") or 0
            if e["kind"] == "damage":
                if p.get("type") == "stun":
                    phys, stun = phys + max(0, stun + boxes - smax) // 2, min(stun + boxes, smax)
                else:
                    phys += boxes
            elif e["kind"] == "heal":
                if p.get("full"):
                    phys, stun = 0, 0
                elif p.get("type") == "stun":
                    stun = max(0, stun - boxes)
                else:
                    phys = max(0, phys - boxes)
            elif p.get("what") == "died":
                phys = pmax + body + 1
            else:
                continue
            tracks[eid] = (phys, stun)
            cond = ("dead" if phys > pmax + body else "dying" if phys > pmax else "unconscious"
                    if phys >= pmax or stun >= smax else "wounded" if phys or stun else "ok")
            out[eid].append((self.file_of[e["seq"]], (p.get("status") if e["kind"] == "damage" else None) or cond))
        return out

    # ── the state at one snapshot ──
    def characters(self, t: int, sealed: set[str]) -> list[list]:
        H, rows = self.H, []
        merged = {e["p"].get("dropped"): self.file_of[e["seq"]] for e in self.events if e["kind"] == "merge"}
        party = {e["actor"]: self.file_of[e["seq"]] for e in self.events if e["kind"] == "new_party"}
        member_of = [(l, born) for l, born in self.links["member_of"] if born <= t]
        kinds = {e["id"]: e["kind"] for e in self.ents}
        for e in self.ents:
            eid = e["id"]
            if H.first.get(eid, e["created_turn"]) > t:
                continue
            if e["status"] not in ("active", "departed") and merged.get(eid, 0) <= t:
                continue
            fp = e["props"].get("former_pc") or {}
            was_pc = bool(fp) and t < party.get(eid, NEVER)
            kind = "pc" if was_pc else e["kind"]
            cond = None
            if kind != "faction":
                cond = next((s for f, s in reversed(self.conditions.get(eid, [])) if f <= t), "ok")
            entered = [(ft, sid) for sid, ft in H.presence.get(eid, {}).items() if ft <= t]
            scene = max(entered)[1] if entered else None
            off, w = self.moved.get(eid, (NEVER, {}))
            if off <= t:                          # (off screen since their last move: today's scene, today's place)
                scene = self.scene_now.get(eid)
            place = (w.get("place") if off <= t else None) or (self.scenes.get(scene) or {}).get("location_id")
            facs = []
            for l, _ in member_of:
                other = l["b"] if l["a"] == eid else l["a"] if l["b"] == eid else None
                if other and kinds.get(other) == "faction":
                    role = (next((x["props"].get("members") or {} for x in self.ents if x["id"] == other), {})
                            .get(eid, "member"))
                    facs.append([other, role])
            pics = [p for p in self.pictures if p["target_id"] == eid and self.pic_file[p["id"]] <= t]
            pic = max(pics, key=lambda p: (p["created_turn"] or 0, int(str(p["id"])[1:] or 0)))["id"] if pics else None
            tier = 1 if (kind == "npc" and e["tier"] == 2 and t < self.first_view.get(eid, -1)) else e["tier"]
            name = next((old for f, old in self.renames.get(eid, []) if f > t and old), e["name"])
            status = next((s for f, s in reversed(self.homes.get(eid, [])) if f <= t), "active")
            rows.append([eid, kind, name, cond, tier,
                         (fp.get("handle") if was_pc else e["player"]) if kind == "pc" else None, None,
                         fp.get("turn") if fp and not was_pc else None, scene, place,
                         minds.digest(w.get("where")) if off <= t else None, w.get("time") if off <= t else None,
                         facs, pic, None if was_pc else minds.digest(e["props"].get("persona")), eid in sealed,
                         e["created_turn"], status])
        return rows

    def sealed_at(self, t: int) -> set[str]:
        """seed.sealed_ids as of t: sealed from its seed's turn, until a public moment from play has them (or a
        public fact about them a seed didn't file)."""
        if not self.sealed or self.sealed_from is None or t < self.sealed_from:
            return set()
        H, met = self.H, set()
        for s, ms in H.members.items():
            n = H.nodes.get(s) or {}
            if n.get("kind") == "slice" and n.get("visibility") == "public" and H.first.get(s, NEVER) <= t:
                met |= {m for m, r in ms if r not in NOT_MET and m in self.sealed}
        for f, x, born in ((l["a"], l["b"], b) for l, b in self.links["about"]):
            for fid, eid in ((f, x), (x, f)):
                n = H.nodes.get(fid) or {}
                if eid in self.sealed and n.get("kind") == "fact" and n.get("visibility") == "public" and \
                        born <= t and n.get("created_turn") not in self.seeds:
                    met.add(eid)
        return self.sealed - met

    def agendas_at(self, t: int, retired: dict[str, int]) -> list[list]:
        H, out = self.H, []
        for a in self.agendas:
            if H.first.get(a["id"], NEVER) > t:
                continue
            steps = [w for w in self.steps.get(a["id"], []) if H.first.get(w, NEVER) <= t]
            done_at = retired.get(a["id"])
            if done_at is None and a["status"] != "active":
                done_at = self._next(a["updated_turn"] or 0, strictly=a["by"] == "world")
            status = a["status"] if done_at is not None and done_at <= t else "active"
            last = max([H.nodes[w]["created_turn"] for w in steps] + [a["created_turn"]])
            out.append([a["id"], a["npc_id"], status, self.about.get(a["id"], []), len(steps), a["created_turn"],
                        a["updated_turn"] if status != "active" else last, a["next_time"], a["by"]])
        return out

    def hooks_at(self, t: int, retired: dict[str, int]) -> list[list]:
        H, out = self.H, []
        dropped = {e["actor"]: self.file_of[e["seq"]] for e in self.events     # (a GM's fix: correct, what=hook)
                   if e["kind"] == "correct" and e["p"].get("what") == "hook"}
        mine = defaultdict(list)
        for h in self.hooks:
            mine[h["npc_id"]].append(h)
        for h in self.hooks:
            if H.first.get(h["id"], NEVER) > t:
                continue
            status = "ready"
            if h["status"] == "landed" and (h["landed_turn"] or NEVER) <= t:
                status = "landed"
            elif h["status"] == "stale":
                at = retired.get(h["id"], dropped.get(h["id"]))
                if at is None:                    # (the actor's next hook: MAX_READY_HOOKS, hook_replaces)
                    later = [H.first.get(x["id"], NEVER) for x in mine[h["npc_id"]]
                             if H.first.get(x["id"], NEVER) > H.first.get(h["id"], NEVER)]
                    at = min(later, default=NEVER)
                status = "stale" if at <= t else "ready"
            out.append([h["id"], h["npc_id"], h["agenda_id"], status, self.about.get(h["id"], []), h["created_turn"],
                        h["landed_turn"] if status == "landed" else None])
        return out

    def facts_at(self, t: int, ids, wit: dict[str, list], knows: list[list]) -> dict[str, list[str]]:
        """{id: the canon they'd know} as of t - minds.canon over what was on file by then."""
        H = self.H
        vis = {f: (n["visibility"], n["created_turn"]) for f, n in H.nodes.items()
               if n["kind"] == "fact" and n["visibility"] in ("public", "private") and H.first.get(f, NEVER) <= t}
        source: dict[str, set[str]] = defaultdict(set)
        drawn: dict[str, set[str]] = defaultdict(set)
        for kind, f, s, born in self.fact_links:
            if born <= t:
                (source if kind == "about" else drawn)[f].add(s)
        seen: dict[str, set[str]] = defaultdict(set)
        for s, ws in wit.items():
            for w, _ in ws:
                seen[w].add(s)
        heard: dict[str, set[str]] = defaultdict(set)
        for h, node, *_ in knows:
            n = H.nodes.get(node) or {}
            if n.get("kind") in ("slice", "fact") and n.get("visibility") != "gm" and node not in seen[h]:
                heard[h].add(node)
        turns_of = {}
        for eid in ids:
            turns = {int(s[1:]) for s in seen.get(eid, ()) if s[:1] == "T" and s[1:].isdigit()}
            turns |= {x for x in self.whispers.get(eid, ()) if x <= t}
            for inside, rounds in self.fights:
                if eid in inside:
                    turns |= {x for x in rounds if x <= t}
            turns_of[eid] = turns
        return minds.canon(ids, vis, source, drawn, self.between, self.on_file, seen, heard, turns_of)

    def witnesses_at(self, t: int, roles) -> tuple[dict, dict]:
        H = self.H
        wit, members = {}, {}
        for s in H.order:
            n = H.nodes[s]
            if n["kind"] != "slice" or H.first.get(s, NEVER) > t:
                continue
            ms = H.members.get(s, [])
            members[s] = list(ms)
            wit[s] = [[m, r] for m, r in ms if r in roles and (n["visibility"] != "private" or self.senders.get(s) == m)]
        return wit, members


def _load(raw):
    try:
        return json.loads(raw or "{}")
    except ValueError:
        return {}


def backfill_minds(c, H: History, d: Path, campaign: str, force: bool = False, roles=None) -> dict:
    """Write the minds files for H's turns into d. Returns {written, skipped, covered, bytes, check} - covered: the
    turns left out because a forward file's events already span them (its diff_since is before them: their own
    minds file failed, and the next one healed it - a rebuilt one there would count its events twice)."""
    from ..config import Knobs
    roles = tuple(roles or Knobs().witness_roles)
    M = MindHistory(c, H)
    forward, spans = set(), {}
    for t in minds.minds_on_file(d):               # (a forward minds file is exact: never replaced by a rebuild)
        try:
            doc = minds.read_minds(d, t)
            if not doc.get("reconstructed"):
                forward.add(t)
                spans[t] = (doc.get("meta") or {}).get("diff_since")
        except Exception:
            pass
    gaps = {x: t for t, since in spans.items() if since is not None for x in M.snaps if since < x < t}
    placed: dict[int, list[dict]] = defaultdict(list)
    for e in M.events:
        placed[M.file_of[e["seq"]]].append(e)
    retired = {e["p"].get("id"): M.file_of[e["seq"]] for e in M.events if e["kind"] == "retired"}
    pictures = {p["id"]: (p["by"], p["created_turn"]) for p in M.pictures}
    # where each new party began in the event log, as the forward log marked it (marks.jsonl) - none for a reset from
    # before the minds: its turn says what's its (minds._during)
    logged = {int(m["turn"]): m["events_after"] for m in fmt.read_marks(d)
              if m.get("kind") == "new-party" and m.get("events_after") is not None}
    tides = {int(m["turn"]): m["rows_after"] for m in fmt.read_marks(d)     # (and where its tables stood: rows_after)
             if m.get("kind") == "new-party" and m.get("rows_after")}
    at_rows = minds.rows(c)
    att: dict[tuple[str, str], object] = {}
    beliefs: dict[str, list] = {}
    prev, prev_doc = None, None
    written, skipped, covered, size, seq = [], [], [], 0, 0
    since_of: dict[str, int] = {}                  # persona:<id> / where:<id> -> the first file with it
    i_persona, i_where = minds.CHAR_COLUMNS.index("persona"), minds.CHAR_COLUMNS.index("whereabouts")
    for t in M.snaps:
        log = [e for e in placed.get(t, []) if e["kind"] in minds.LOGGED]
        seq = max([seq] + [e["seq"] for e in placed.get(t, [])])
        for e in log:                             # the matrix and the views, replayed
            p = e["p"]
            if e["kind"] == "belief":
                if p.get("attitude") is not None:
                    att[(e["actor"], p.get("about"))] = p["attitude"]
                bid = p.get("belief")
                beliefs.pop(M.replaces.get(bid), None)
                beliefs[bid] = [bid, e["actor"], p.get("about"), (H.nodes.get(bid) or {}).get("created_turn"),
                                p.get("attitude"), minds.WHY_BY.get(p.get("by"), p.get("by")), M.replaces.get(bid)]
            elif e["kind"] == "attitude_cooled":
                att[(e["actor"], p.get("about"))] = p.get("to")
        sealed = M.sealed_at(t)
        chars = M.characters(t, sealed)
        ids = {r[0] for r in chars}
        wit, members = M.witnesses_at(t, roles)
        scene = M.turn_scene.get(t)
        here = sorted(i for i in ids if (H.presence.get(i) or {}).get(scene, NEVER) <= t) if scene else []
        knows = [[k["holder"], k["node_id"], k["how"], k["source"], k["turn"]] for k in H.knows
                 if M.knows_file[(k["holder"], k["node_id"])] <= t]
        now = {"characters": chars, "attitudes": [[h, a, v] for (h, a), v in sorted(att.items())],
               "beliefs": list(beliefs.values()), "knows": knows, "agendas": M.agendas_at(t, retired),
               "hooks": M.hooks_at(t, retired), "holdings": [], "witnesses": wit, "members": members,
               "co_presence": [[scene, "active", here]] if here else [], "reconstructed": True,
               "knows_late": {(k[0], k[1]) for k in knows if M.knows_file[(k[0], k[1])] > (k[4] or 0)}}
        pw = prev["witnesses"] if prev else {}
        fresh = [s for s, ws in wit.items() if s not in pw or [tuple(w) for w in ws] != pw[s]]
        new = set(fresh)
        marks = [{"kind": "new-party", "turn": r["turn"], "former_pcs": [o["id"] for o in r.get("old_crew") or []],
                  "story_time_from": r.get("clock_from"), "story_time_to": r.get("clock_to"),
                  "events_after": logged.get(int(r["turn"])), "rows_after": tides.get(int(r["turn"]))}
                 for r in M.parties if M._next(int(r["turn"]), strictly=True) == t]
        ctx = {"seeds": M.seeds, "seed_cast": M.seed_cast, "replaces": M.replaces, "pictures": pictures,
               "steps": {a: [w for w in ws if w in new] for a, ws in M.steps.items() if new.intersection(ws)},
               "rows": at_rows}
        evs = minds.events(t, now, prev, log, marks, ctx)
        now["facts"] = M.facts_at(t, ids, wit, knows)
        sal, people = minds.minds_of(now, minds.in_play(now, fresh, evs), H.ratios[t])
        doc = minds.document(campaign, t, now, fresh, evs, sal, people,
                             {"diff_since": prev["turn"] if prev else None, "events_seq": seq, "scene_id": scene,
                              "story_time": M.clock.get(t),
                              "written_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                             dict(EXACTNESS), reconstructed=True)
        prev, prev_doc = minds.state_of(doc), doc
        for r in chars:
            if r[i_persona]:
                since_of.setdefault(f"persona:{r[0]}", t)
            if r[i_where]:
                since_of.setdefault(f"where:{r[0]}", t)
        if t in forward and not force:
            skipped.append(t)
            continue
        if t in gaps and not force:
            covered.append(t)
            continue
        size += minds.write_minds(d, doc)
        written.append(t)
    # persona and whereabouts text in the catalog from the first file with each - today's, the record keeps no older
    # one (as the graph's own catalog lines: a forward line from a later turn leaves the turns before it without one)
    ents = {e["id"]: e for e in M.ents}
    earliest: dict[str, dict] = {}
    for e in fmt.read_catalog(d):
        if e.get("kind") in ("persona", "whereabouts") and (e["id"] not in earliest or (e.get("since") or 0) <
                                                            (earliest[e["id"]].get("since") or 0)):
            earliest[e["id"]] = e
    fresh_lines = []
    for key, first in sorted(since_of.items()):
        kind, eid = ("persona" if key.startswith("persona:") else "whereabouts"), key.split(":", 1)[1]
        have = earliest.get(key)
        if have is not None and (have.get("since") or 0) <= first:
            continue
        p = ents[eid]["props"]
        text = have.get("text") if have is not None else (
            json.dumps(p["persona"], sort_keys=True, ensure_ascii=False) if kind == "persona"
            else p["whereabouts"]["where"])
        fresh_lines.append({"id": key, "kind": kind, "ekind": None, "created_turn": None, "scene_id": None,
                            "since": first, "hash": fmt.text_hash(text), "text": text, "reconstructed": True})
    fmt.append_catalog(d, fresh_lines)
    return {"written": written, "skipped": skipped, "covered": covered, "bytes": size,
            "check": check(M, att, beliefs, prev_doc)}


def check(M: MindHistory, att: dict, beliefs: dict, last: dict | None) -> dict:
    """The end state against the record: the attitudes replayed through the last file plus what came after its
    snapshot must be the ledger's attitude stats exactly, and the views held the record's current beliefs."""
    after = [e for e in M.events if M.file_of[e["seq"]] >= NEVER and e["kind"] in minds.LOGGED]
    final, held = dict(att), {b for b in beliefs}
    for e in after:
        p = e["p"]
        if e["kind"] not in ("belief", "attitude_cooled"):
            continue
        if e["kind"] == "belief":
            if p.get("attitude") is not None:
                final[(e["actor"], p.get("about"))] = p["attitude"]
            held.discard(M.replaces.get(p.get("belief")))
            held.add(p.get("belief"))
        else:
            final[(e["actor"], p.get("about"))] = p.get("to")
    db = M.attitudes
    mism = sorted([list(k) + [final.get(k), db.get(k)] for k in set(final) | set(db) if final.get(k) != db.get(k)],
                  key=str)
    return {"last_turn": (last or {}).get("meta", {}).get("turn"),
            "attitudes": {"record": len(db), "replayed": len(final), "mismatch": mism},
            "beliefs": {"record": len(M.current), "replayed": len(held), "missing": sorted(M.current - held),
                        "extra": sorted(held - M.current)},
            "after_last_snapshot": [{"seq": e["seq"], "turn": e["turn"], "kind": e["kind"], "who": e["actor"],
                                     "about": e["p"].get("about") or e["p"].get("id"), "by": e["p"].get("by")}
                                    for e in after]}


def check_line(chk: dict) -> str:
    """The check, in one line for the console."""
    a, b = chk["attitudes"], chk["beliefs"]
    ok = not a["mismatch"] and not b["missing"] and not b["extra"]
    head = (f"minds check at T{chk['last_turn']}: attitudes {a['replayed']}/{a['record']}, current beliefs "
            f"{b['replayed']}/{b['record']} - " + ("match the record exactly" if ok else "MISMATCH"))
    if a["mismatch"]:
        head += "; attitudes off: " + ", ".join(f"{h}->{x} {r} vs {d}" for h, x, r, d in a["mismatch"][:8])
    if b["missing"] or b["extra"]:
        head += f"; beliefs missing {b['missing'][:8]} extra {b['extra'][:8]}"
    if chk["after_last_snapshot"]:
        kinds: dict[str, int] = {}
        for e in chk["after_last_snapshot"]:
            kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
        head += (f" (after the last snapshot, the next forward file's: "
                 + ", ".join(f"{n} {k}" for k, n in sorted(kinds.items())) + " - counted in)")
    return head
