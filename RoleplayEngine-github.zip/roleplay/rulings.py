"""Table rulings (DESIGN.md §9a): the house rules this table has agreed on, always in the GM's context.

Small on purpose: at most MAX active, each a sentence or two. The GM records one when it settles a rules
question it'll want to repeat (`ruling: ...` in its <dm> block, `ruling R3: ...` to revise one); players
and the owner can add them too. Every new ruling is announced at the table and anyone can veto it -
the players' blessing, without stopping play for a vote. Revisions keep the old text on record.

The table's commands don't wait for the GM: a turn holds the game thread for a minute or more, so `!ruling` and
`!rulings` run on a connection of their own (`on_side`) - WAL lets it read and write between the turn's statements,
and a ruling made mid-turn applies from the GM's next reply. Every change is one transaction, so the two can't
hand out the same R#. An undo (or a failed turn rolled back) keeps what the table did to its rulings (`keep`); the
GM's own rulings go with the turn that made them.
"""
from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from types import SimpleNamespace

from .engine.ledger import LedgerError

MAX = 15
MAX_CHARS = 280
_ID = re.compile(r"^\s*(?:R\s*)?#?\s*(\d+)\s*:?\s*$", re.IGNORECASE)


def norm_id(rid: str) -> str:
    """'R3', 'r3', '3', '#3', 'R3:' -> 'R3' (anything else comes back upper-cased, to fail the lookup honestly)."""
    m = _ID.match(rid or "")
    return f"R{int(m.group(1))}" if m else (rid or "").strip().upper()


class _write:
    """One ruling change, one transaction (the table's side connection and the GM's turn can both be writing)."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn, self.own = conn, not conn.in_transaction

    def __enter__(self):
        if self.own:
            self.conn.execute("BEGIN IMMEDIATE")

    def __exit__(self, kind, exc, tb):
        if self.own:
            self.conn.execute("ROLLBACK" if kind else "COMMIT")
        return False


def _seq(conn) -> int:
    row = conn.execute("SELECT value FROM meta WHERE key='seq_ruling'").fetchone()
    top = conn.execute("SELECT MAX(CAST(substr(id, 2) AS INTEGER)) FROM rulings").fetchone()[0] or 0
    return max(int(row[0]) if row else 0, top)


def _next(conn) -> str:
    n = _seq(conn) + 1
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('seq_ruling', ?)", (str(n),))
    return f"R{n}"


def active(game) -> list[dict]:
    return [dict(r) for r in game.conn.execute("SELECT * FROM rulings WHERE status='active' ORDER BY rowid")]


def get(game, rid: str) -> dict | None:
    row = game.conn.execute("SELECT * FROM rulings WHERE id=?", (norm_id(rid),)).fetchone()
    return dict(row) if row else None


def _not_active(game, rid: str, verb: str = "") -> LedgerError:
    """Why R# can't be used - and what can (the table shouldn't have to guess the ids)."""
    r, rid = get(game, rid), norm_id(rid)
    if r and r["status"] == "replaced" and r["replaced_by"]:
        return LedgerError(f"{rid} was already revised - it's {r['replaced_by']} now.")
    if r:
        return LedgerError(f"{rid} was {r['status']}.")
    ids = ", ".join(x["id"] for x in active(game))
    return LedgerError(f"No active ruling {rid}{verb}" + (f" - the table has {ids}." if ids else " - there are none yet."))


def add(game, text: str, by: str, replaces: str | None = None) -> dict:
    text = " ".join((text or "").split())
    if not text:
        raise LedgerError("A ruling needs some words.")
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS - 3].rsplit(" ", 1)[0] + "..."
    c = game.conn
    with _write(c):
        old = None
        if replaces:
            old = get(game, replaces)
            if not old or old["status"] != "active":
                raise _not_active(game, replaces, " to revise")
        elif len(active(game)) >= MAX:
            raise LedgerError(f"The table already has {MAX} rulings - revise or drop one instead of adding another.")
        rid = _next(c)
        turn = c.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0]
        c.execute("INSERT INTO rulings(id, text, status, by, created_turn, replaces) VALUES(?,?,?,?,?,?)",
                  (rid, text, "active", by, turn, old["id"] if old else None))
        if old:
            c.execute("UPDATE rulings SET status='replaced', replaced_by=? WHERE id=?", (rid, old["id"]))
    return get(game, rid)


def retire(game, rid: str, status: str, who: str) -> dict:
    """veto (a player objects) or drop (the owner retires it)."""
    with _write(game.conn):
        r = get(game, rid)
        if not r or r["status"] != "active":
            raise _not_active(game, rid)
        game.conn.execute("UPDATE rulings SET status=?, closed_by=? WHERE id=?", (status, who, r["id"]))
    return get(game, r["id"])


def on_side(path: Path | str, fn, *args):
    """Run fn(<game-like>, *args) on a connection of its own - off the game thread, so the table's ruling commands
    answer in a second instead of after the GM's turn."""
    conn = sqlite3.connect(str(path), isolation_level=None, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout = 10000")
        conn.execute("PRAGMA synchronous = NORMAL")        # (see db.connect)
        return fn(SimpleNamespace(conn=conn), *args)
    finally:
        conn.close()


def keep(conn: sqlite3.Connection):
    """House rules belong to the table, not the story. Call before an undo restores a snapshot, then call what this
    returns: whatever the table did to its rulings since (added, edited, vetoed, dropped - mid-turn included) is put
    back. The GM's own rulings still go with the turn that made them."""
    before = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM rulings")}
    seq = _seq(conn)
    table = lambda rid: rid in before and before[rid]["by"] != "gm"          # noqa: E731

    def kept(rid) -> bool:                                     # the table's - or the GM's, touched by the table
        return rid in before and (table(rid) or bool(before[rid]["closed_by"]) or table(before[rid]["replaced_by"]))

    def put_back() -> None:
        after = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM rulings")}
        with _write(conn):
            for rid, b in before.items():
                if not kept(rid):
                    continue                                   # the GM's, untouched by the table: undone with it
                row = dict(b)
                if b["status"] == "replaced" and not kept(b["replaced_by"]):    # its revision is being undone
                    was = after.get(rid)
                    row["status"], row["replaced_by"] = (was["status"], was["replaced_by"]) if was else ("active", None)
                conn.execute(f"INSERT OR REPLACE INTO rulings({', '.join(row)}) VALUES({', '.join('?' * len(row))})",
                             tuple(row.values()))
            conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('seq_ruling', ?)",
                         (str(max(seq, _seq(conn))),))                 # (an undone R# is never handed out again)
    return put_back


def packet_lines(game) -> list[str]:
    rows = active(game)
    if not rows:
        return []
    return (["\n=== TABLE RULINGS (house rules this table agreed - they override your defaults) ==="]
            + [f"[{r['id']}] {r['text']}" for r in rows]
            + [f"({len(rows)}/{MAX} - add `ruling: ...` or revise `ruling R#: ...` in your <dm> block)"])


TABLE_RULES = ("\n=== TABLE RULES (this table's house rulings - they outrank every memory, note, goal and hook below. "
               "Never plan around a time or deadline they rule out, revive a storyline they closed, or re-open what "
               "they settled) ===")


def table_rules(game) -> list[str]:
    """The table's rulings for the models that plan and frame without the GM's packet: the offscreen world's minds
    (world._agent_job) and the scene frame (frame.gather). Live (flag #42, T147): R11's timeline lock ("no other
    deadlines") and R20 ("there is no 08:00 Low Wharf deadline") stood at the top of the GM's packet, but the
    offscreen world never saw them - its hooks kept a Day 5 08:00 meeting and a noon draw pressing - and at T188
    Marisol's mind started a goal for "before Thursday" in the storyline R27 had closed."""
    rows = active(game)
    return [TABLE_RULES] + [f"[{r['id']}] {r['text']}" for r in rows] if rows else []


def listing(game) -> str:
    rows = active(game)
    if not rows:
        return "No table rulings yet. `!ruling add <text>` - or the GM records one when it settles a question."
    return "\n".join(f"**{r['id']}** {r['text']}" + (f"  -# (revises {r['replaces']})" if r["replaces"] else "")
                     for r in rows) + (f"\n-# {len(rows)}/{MAX} · `!ruling veto R#` to object · `!ruling add <text>` · "
                                       "`!ruling <question>` asks the GM")
