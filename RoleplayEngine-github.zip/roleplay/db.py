"""One SQLite file per campaign: the ledger (hard state) and the substrate (memory) side by side.

Undo is a pre-turn snapshot via SQLite's backup API: exact and dead simple while the game
has a single writer. When background world workers start writing concurrently (phase 6)
this becomes the Orchard-style turn journal instead (DESIGN.md §1.4).
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);

-- ── Ledger: authoritative hard state ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS entities(
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,                 -- pc | npc | location | item | host
    name TEXT NOT NULL,
    aliases TEXT NOT NULL DEFAULT '[]',
    description TEXT NOT NULL DEFAULT '',
    tier INTEGER NOT NULL DEFAULT 1,    -- 0 background, 1 named, 2 has a mind
    player TEXT,                        -- console/discord handle for PCs
    status TEXT NOT NULL DEFAULT 'active',
    props TEXT NOT NULL DEFAULT '{}',   -- item/host properties (DV, AP, armor, rating...)
    created_turn INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS stats(
    entity_id TEXT NOT NULL, key TEXT NOT NULL, value REAL NOT NULL,
    PRIMARY KEY(entity_id, key)
);
CREATE TABLE IF NOT EXISTS holdings(
    owner_id TEXT NOT NULL, item_id TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 1,
    state TEXT NOT NULL DEFAULT '{}',   -- e.g. {"loaded": 12}
    PRIMARY KEY(owner_id, item_id)
);
CREATE TABLE IF NOT EXISTS scenes(
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    location_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',  -- active | parked | closed
    created_turn INTEGER NOT NULL DEFAULT 0,
    closed_turn INTEGER
);
CREATE TABLE IF NOT EXISTS scene_roster(       -- who is in the scene right now
    scene_id INTEGER NOT NULL, entity_id TEXT NOT NULL,
    PRIMARY KEY(scene_id, entity_id)
);
CREATE TABLE IF NOT EXISTS scene_presence(     -- who was ever in the scene (lift + together)
    scene_id INTEGER NOT NULL, entity_id TEXT NOT NULL, first_turn INTEGER NOT NULL,
    PRIMARY KEY(scene_id, entity_id)
);
CREATE TABLE IF NOT EXISTS turns(
    id INTEGER PRIMARY KEY,
    scene_id INTEGER,
    inputs TEXT NOT NULL DEFAULT '[]',
    narration TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',   -- open | committed | seed
    cost REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events(             -- audit log of every engine mutation
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_id INTEGER, kind TEXT NOT NULL, actor TEXT, payload TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_id INTEGER, actor_id TEXT, spec TEXT, dice TEXT,
    hits INTEGER, glitch INTEGER, crit_glitch INTEGER, success INTEGER, net INTEGER
);

-- ── Substrate: the Orchard memory graph ──────────────────────────────────
CREATE TABLE IF NOT EXISTS nodes(
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,                 -- entity | slice | scene | fact | note
    text TEXT NOT NULL DEFAULT '',
    created_turn INTEGER NOT NULL DEFAULT 0,
    scene_id INTEGER,
    visibility TEXT NOT NULL DEFAULT 'public'   -- public | gm | private (a whisper) | offscreen (W#)
);
CREATE TABLE IF NOT EXISTS energy(              -- Orchard node_energy (notes are not citizens)
    node_id TEXT PRIMARY KEY,
    energy REAL NOT NULL,
    touch_count INTEGER NOT NULL DEFAULT 0,
    last_touched_turn INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS links(               -- symmetric, canonical a < b
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    a TEXT NOT NULL, b TEXT NOT NULL,
    kind TEXT NOT NULL,                 -- assoc | member | spine | recall | about | contains
    strength REAL NOT NULL,
    together INTEGER NOT NULL DEFAULT 0,  -- shared scenes (entity-entity links)
    last_turn INTEGER NOT NULL DEFAULT 0,
    UNIQUE(a, b)
);
CREATE INDEX IF NOT EXISTS idx_links_a ON links(a);
CREATE INDEX IF NOT EXISTS idx_links_b ON links(b);
CREATE TABLE IF NOT EXISTS members(             -- the turn hyperedge
    slice_id TEXT NOT NULL, node_id TEXT NOT NULL, role TEXT NOT NULL,
    PRIMARY KEY(slice_id, node_id, role)
);
CREATE INDEX IF NOT EXISTS idx_members_node ON members(node_id);
CREATE TABLE IF NOT EXISTS spine(
    prev_id TEXT NOT NULL, next_id TEXT NOT NULL, kind TEXT NOT NULL,
    PRIMARY KEY(prev_id, next_id)
);
CREATE TABLE IF NOT EXISTS annotates(           -- DM notes ride their targets
    note_id TEXT NOT NULL, target_id TEXT NOT NULL,
    PRIMARY KEY(note_id, target_id)
);
CREATE INDEX IF NOT EXISTS idx_annotates_target ON annotates(target_id);
CREATE TABLE IF NOT EXISTS clarifications(       -- the GM's current picture of a node (node C#, rides it via annotates)
    id TEXT PRIMARY KEY, target_id TEXT NOT NULL,
    upto_note INTEGER NOT NULL DEFAULT 0,         -- notes N1..N<upto> on the target are folded into it
    status TEXT NOT NULL DEFAULT 'current',       -- current | superseded
    created_turn INTEGER NOT NULL DEFAULT 0, by TEXT
);
CREATE INDEX IF NOT EXISTS idx_clarifications_target ON clarifications(target_id, status);
CREATE TABLE IF NOT EXISTS encounters(           -- a fight (encounters.py): zones, positions, sides and a round log
    id INTEGER PRIMARY KEY AUTOINCREMENT, scene_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',        -- active | ended
    round INTEGER NOT NULL DEFAULT 0, zones TEXT, positions TEXT, sides TEXT, log TEXT, jump TEXT, members TEXT,
    attacks TEXT, quiet INTEGER NOT NULL DEFAULT 0, ending TEXT, started_turn INTEGER, started_time INTEGER,
    ended_turn INTEGER, outcome TEXT, map TEXT
);
CREATE TABLE IF NOT EXISTS tensions(             -- a question the story keeps pressing on (node Q#; dm/tensions.py)
    id TEXT PRIMARY KEY, question TEXT NOT NULL, stakes INTEGER NOT NULL DEFAULT 2,
    status TEXT NOT NULL DEFAULT 'open',          -- open | shelved | resolved
    pressure REAL NOT NULL DEFAULT 0,             -- rises while the table leaves it alone; play releases it
    next TEXT, public TEXT,                       -- the next pressure point (GM) / what the PCs know (recap)
    due_time INTEGER, due_fired INTEGER NOT NULL DEFAULT 0,
    created_turn INTEGER NOT NULL DEFAULT 0, updated_turn INTEGER NOT NULL DEFAULT 0,
    resolved_turn INTEGER, resolution TEXT, by TEXT
);
CREATE TABLE IF NOT EXISTS doubts(               -- where the record doesn't add up (node X#; dm/doubts.py)
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'open',          -- open | resolved | dismissed (never deleted: the history)
    raised_turn INTEGER NOT NULL DEFAULT 0,
    raised_by TEXT NOT NULL DEFAULT 'gm',         -- gm | canon | commit | aside | askdm
    times INTEGER NOT NULL DEFAULT 1,             -- raised again with near-identical words: bumped, not doubled
    last_turn INTEGER,                            -- last raised, worked on or settled
    resolved_turn INTEGER, resolution TEXT,       -- what's true (resolved) or why it never was a doubt (dismissed)
    resolved_by TEXT
);
CREATE TABLE IF NOT EXISTS jobs(                 -- the crew's runs, offered to finished (jobs.py; J1, J2...)
    id TEXT PRIMARY KEY, title TEXT NOT NULL,
    client_id TEXT,                               -- who hired them (an entity id), if known
    objective TEXT NOT NULL DEFAULT '', pay TEXT NOT NULL DEFAULT '', deadline TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'offered',       -- offered | active | done | failed | dropped
    progress TEXT NOT NULL DEFAULT '',            -- where it stands, one line
    created_turn INTEGER NOT NULL DEFAULT 0, updated_turn INTEGER NOT NULL DEFAULT 0, closed_turn INTEGER,
    by TEXT                                       -- commit (the memory pass) | backfill | gm
);
CREATE TABLE IF NOT EXISTS agendas(              -- what an NPC or faction is pursuing offscreen (node A#)
    id TEXT PRIMARY KEY, npc_id TEXT NOT NULL, goal TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',        -- active | done | dropped
    next_turn INTEGER NOT NULL DEFAULT 0,         -- (legacy; pacing is next_time, in story minutes)
    next_time INTEGER NOT NULL DEFAULT 0, steps INTEGER NOT NULL DEFAULT 0,
    created_turn INTEGER NOT NULL DEFAULT 0, updated_turn INTEGER NOT NULL DEFAULT 0, by TEXT
);
CREATE TABLE IF NOT EXISTS hooks(                -- an offscreen consequence waiting for the DM to land it (node H#)
    id TEXT PRIMARY KEY, agenda_id TEXT, npc_id TEXT,
    status TEXT NOT NULL DEFAULT 'ready',         -- ready | landed | stale (superseded by a newer one)
    created_turn INTEGER NOT NULL DEFAULT 0, landed_turn INTEGER
);
CREATE TABLE IF NOT EXISTS world_actors(         -- when each NPC/faction last took a turn offscreen
    npc_id TEXT PRIMARY KEY, last_turn INTEGER NOT NULL DEFAULT 0, last_time INTEGER, last_seq INTEGER
);
CREATE TABLE IF NOT EXISTS world_inbox(          -- someone reached out offscreen: wakes the recipient next pass
    id INTEGER PRIMARY KEY AUTOINCREMENT, npc_id TEXT NOT NULL, slice_id TEXT NOT NULL,
    from_id TEXT, turn INTEGER, read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS rulings(              -- table house rules, always in the GM's context (rulings.py)
    id TEXT PRIMARY KEY, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',   -- active|replaced|vetoed|dropped
    by TEXT, created_turn INTEGER, replaces TEXT, replaced_by TEXT, closed_by TEXT
);
CREATE TABLE IF NOT EXISTS narrative(            -- the table's standing story directions (narrative.py)
    id TEXT PRIMARY KEY, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',   -- active|done|removed
    by TEXT, by_name TEXT, created_turn INTEGER, closed_by TEXT, closed_turn INTEGER
);
CREATE TABLE IF NOT EXISTS voice_assets(         -- a portrait's Discord copy, used as the NPC's webhook avatar
    entity_id TEXT PRIMARY KEY, version INTEGER, channel_id TEXT, message_id TEXT, url TEXT, expires INTEGER
);
CREATE TABLE IF NOT EXISTS control(              -- who plays a character: player | gm | idle (explicit overrides)
    entity_id TEXT PRIMARY KEY, mode TEXT NOT NULL, handle TEXT, since_turn INTEGER
);
CREATE TABLE IF NOT EXISTS presented(            -- whose portrait the table has seen big (then thumbnails)
    entity_id TEXT PRIMARY KEY, turn INTEGER
);
CREATE TABLE IF NOT EXISTS players(              -- Discord user -> the PC handle they play
    discord_id TEXT PRIMARY KEY, handle TEXT NOT NULL, name TEXT, afk INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS art(                 -- images belong to entities; never regenerated by accident
    entity_id TEXT NOT NULL,
    version INTEGER NOT NULL,
    path TEXT NOT NULL,
    status TEXT NOT NULL,               -- pending | ready | failed
    prompt TEXT NOT NULL DEFAULT '',
    caption TEXT NOT NULL DEFAULT '',   -- story details shown with the image
    story TEXT NOT NULL DEFAULT '',     -- the public story context the prompt was written from
    provider TEXT, model TEXT, error TEXT,
    created_turn INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(entity_id, version)
);
CREATE TABLE IF NOT EXISTS knows(               -- hearsay: what someone learned without witnessing it
    holder TEXT NOT NULL, node_id TEXT NOT NULL,
    how TEXT NOT NULL,                  -- told | rumor
    source TEXT,                        -- who told them
    turn INTEGER NOT NULL,
    PRIMARY KEY(holder, node_id)
);
CREATE TABLE IF NOT EXISTS supersedes(           -- the Orchard diode: old -> new, energy flows forward
    old_id TEXT NOT NULL, new_id TEXT NOT NULL,
    confidence REAL NOT NULL, installed_by TEXT NOT NULL, turn INTEGER NOT NULL,
    PRIMARY KEY(old_id, new_id)
);
CREATE INDEX IF NOT EXISTS idx_supersedes_new ON supersedes(new_id);
CREATE TABLE IF NOT EXISTS mean_log(
    turn INTEGER, mean REAL, total REAL, nodes INTEGER, links INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Instrumentation (graph browser + dynamics analysis) ──────────────────
CREATE TABLE IF NOT EXISTS energy_history(       -- every citizen's heat (energy / mean) after each turn
    turn INTEGER NOT NULL, node_id TEXT NOT NULL, ratio REAL NOT NULL,
    PRIMARY KEY(turn, node_id)
);
CREATE TABLE IF NOT EXISTS turn_metrics(
    turn INTEGER PRIMARY KEY,
    scene_id INTEGER,
    seconds REAL, cost REAL,
    dm_steps INTEGER, tool_calls INTEGER, tool_errors INTEGER, tools TEXT,
    packet_chars INTEGER,
    nodes INTEGER, links INTEGER, mean REAL,
    warm INTEGER,          -- nodes at or above the mean
    hot INTEGER,           -- nodes at 2x the mean or more
    gini REAL,             -- inequality of the energy distribution (0 equal .. 1 one lump)
    top5_share REAL,       -- share of all energy held by the 5 hottest nodes
    recalled INTEGER, facts_new INTEGER, notes_new INTEGER, entities_new INTEGER,
    stats TEXT             -- propagation stats JSON
);
"""


MIGRATIONS = [   # additive column changes for campaign files created by earlier builds
    "ALTER TABLE turns ADD COLUMN session INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE turns ADD COLUMN packet TEXT",        # exactly what the DM saw (debugging memory)
    "ALTER TABLE turns ADD COLUMN extraction TEXT",    # what the commit model said (debugging memory)
    "ALTER TABLE turns ADD COLUMN private TEXT",       # a whisper: the character who sent it (else NULL)
    "ALTER TABLE nodes ADD COLUMN story_time INTEGER",  # slices: in-story minutes when it happened (engine/clock.py)
    "ALTER TABLE agendas ADD COLUMN next_time INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE world_actors ADD COLUMN last_time INTEGER",
    "ALTER TABLE world_actors ADD COLUMN last_seq INTEGER",   # the event log as of their last move
    # (a whole new table - doubts, 2026-10-26 - needs no line here: SCHEMA's CREATE TABLE IF NOT EXISTS makes it in an
    # older file, and ensure() runs again after an undo's restore)
]


def ensure(conn: sqlite3.Connection) -> None:
    """Today's tables and columns in a campaign file: a new one, one an earlier build made - or one an undo has just
    restored from a snapshot an earlier build took. That snapshot comes back without the newer tables, so the first
    !undo after the doubts table shipped would have dropped it from under the running game."""
    conn.executescript(SCHEMA)
    for sql in MIGRATIONS:
        try:
            conn.execute(sql)
        except sqlite3.OperationalError:          # already applied
            pass


def connect(path: Path | str) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), isolation_level=None, check_same_thread=False)  # autocommit
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")     # the graph browser reads while the game writes
    conn.execute("PRAGMA synchronous = NORMAL")   # WAL's own advice: no disk flush per write (on a spinning drive a
    #   turn's ~1,200 autocommit writes waited ~30 ms each - a minute a turn). Still never corrupts; a power cut can
    #   lose the last moments, which the undo snapshots and backups cover.
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA foreign_keys = OFF")
    ensure(conn)
    return conn


def snapshot(conn: sqlite3.Connection, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    out = sqlite3.connect(str(dest))
    try:
        conn.backup(out)
    finally:
        out.close()


def restore(conn: sqlite3.Connection, src: Path) -> None:
    snap = sqlite3.connect(str(src))
    try:
        snap.backup(conn)
    finally:
        snap.close()
    ensure(conn)                                   # (a snapshot from before an upgrade: today's tables back in place)
