"""Campaign setup. `demo` seeds a small world WITH history, so memory is visible from turn one:
three sessions ago Razor broke a ganger's arm in Kaz's bar. Kaz remembers. Kaz also has a secret.
"""
from __future__ import annotations

from . import graphlog
from .game import Game


def seed_history(game: Game, scene_title: str, location: str, present: list[str], summaries: list[tuple],
                 facts: list[tuple] = ()) -> int:
    """Write past turns directly (no LLM): each summary is (text, {entity: role})."""
    L, S = game.ledger, game.sub
    t0 = game.turn_no() + 1
    sid = game.new_scene(scene_title, location, present, t0)
    last_slice = None
    for text, roles in summaries:
        tid = L.begin_turn(sid, [], status="seed")
        members = ([(location, "location")] if location else []) + [(e, r) for e, r in roles.items()]
        members += [(e, "present") for e in present if e not in roles]
        last_slice = S.write_slice(tid, sid, text, members, [])
        S.touch([last_slice], tid)
        L.finish_turn(tid, "", 0.0, status="seed")
        S.observe(tid)
        graphlog.after_turn(game)                     # (a seeded past is turns too: the log starts at T1)
    for text, about in facts:
        S.add_fact(text, about, game.turn_no(), last_slice)
    return sid


def setup_demo(game: Game) -> None:
    L = game.ledger
    t = 0
    lucky = game.introduce("location", "The Lucky Shot", "a cramped dive bar in the Redmond Barrens: flickering "
                           "neon, a scarred chrome counter, a jukebox with a bullet hole, ork-sized stools",
                           aliases=["Lucky Shot"], turn=t)[0]
    razor = game.create_pc("Razor", "street_samurai", player="razor",
                           description="human street samurai, chrome left arm, smartlink eyes, long black coat",
                           turn=t)
    ghost = game.create_pc("Ghost", "decker", player="ghost",
                           description="elf decker, shaved head with trodes, oversized hoodie, twitchy and sardonic",
                           turn=t)
    kaz = game.introduce("npc", "Kaz", "ork bartender and owner of the Lucky Shot, tusks capped in brass, "
                         "apron over an old Lone Star vest, gravel voice, misses nothing", template="contact",
                         aliases=["Kazimir"], turn=t)[0]
    joey = game.introduce("npc", "Joey Two-Knives", "skinny elf ganger of the Ancients with two knife tattoos on his "
                          "neck and a grudge", template="ganger", aliases=["Joey"], turn=t)[0]
    tanaka = game.introduce("npc", "Tanaka", "soft-spoken human fence in Chinatown who pays fair and asks nothing",
                            template="contact", turn=t)[0]

    # ── history: three sessions ago ──
    L.set_meta("session", "1")
    s1 = seed_history(game, "Bar fight at the Lucky Shot", lucky, [razor, kaz, joey], [
        ("Joey Two-Knives of the Ancients shook Kaz down for protection money at the Lucky Shot while Razor drank "
         "at the counter.", {joey: "actor", kaz: "target", razor: "present"}),
        ("Razor broke Joey Two-Knives' arm and threw him through the jukebox; Kaz banned the Ancients from the bar "
         "and told Razor his drinks are on the house.", {razor: "actor", joey: "target", kaz: "actor"}),
    ], facts=[("Kaz banned the Ancients gang from the Lucky Shot after Razor's fight with Joey Two-Knives.", [kaz, lucky]),
              ("Kaz owes Razor a favor for running off the Ancients.", [kaz, razor])])
    game.sub.add_note([kaz], "Secret: Kaz sells information to Lone Star when rent is short. He likes Razor, but "
                      "he'd trade a name to save his bar.", game.turn_no())
    game.sub.add_note([joey], "Joey wants payback on Razor. The Ancients are watching the Lucky Shot.", game.turn_no())

    # ── history: last session (Ghost and Razor got a hot chip) ──
    L.set_meta("session", "3")
    seed_history(game, "The Renraku courier job", None, [razor, ghost], [
        ("Razor and Ghost ambushed a Renraku courier on the 520 bridge and took a sealed datachip.",
         {razor: "actor", ghost: "actor"}),
    ])
    chip = game.introduce("item", "Renraku datachip", "a sealed black datachip with the Renraku logo and an "
                          "encryption seal, still warm from the courier's pocket", aliases=["the chip", "datachip"],
                          owner_id=ghost, turn=game.turn_no())[0]
    game.sub.add_fact("Tanaka is a fence in Chinatown who buys hot corporate data.", [tanaka], game.turn_no())
    game.sub.add_fact("Kaz knows Tanaka the fence from his Lone Star days; they still trade favors.",
                      [kaz, tanaka], game.turn_no())
    game.sub.add_note([chip], "The chip holds Renraku R&D files on a prototype cyberarm; Renraku will send a team "
                      "to recover it within a day. The encryption is a rating 5 host.", game.turn_no())

    # ── now: back at the Lucky Shot ──
    L.set_meta("session", "4")
    game.new_scene("Selling the chip", lucky, [razor, ghost, kaz], game.turn_no())
    L.set_meta("campaign", "demo")


def setup_blank(game: Game, location: str, description: str) -> None:
    loc = game.introduce("location", location, description, turn=0)[0]
    game.new_scene("Opening", loc, [], 0)


def setup_rage(game: Game) -> None:
    """A fresh world for one decker: Rage, average gear and skills, gets a call from a fixer. The job is
    Horizon's Seattle client list - a Matrix run from the first scene."""
    L = game.ledger
    t = 0
    home = game.introduce("location", "Rage's apartment", "a one-room walk-up over a shuttered noodle shop in "
                          "Renton: a mattress, a sagging couch, a desk buried in cables and a dead soykaf "
                          "maker, the window steamed and pink with neon", aliases=["the apartment"],
                          where={"district": "Renton"}, turn=t)[0]
    rage = game.create_pc("Rage", "decker", player="rage",
                          description="a working decker with a datajack behind the ear, a worn armored jacket "
                                      "and a battered cyberdeck on a strap", turn=t)
    for k, v in dict(logic=5, intuition=4, hacking=5, cybercombat=4, electronics=4, firearms=3, stealth=3).items():
        L.set_stat(rage, k, v)                         # average: a working decker, not a legend
    deck = next(i for i in L.holdings(rage) if i["props"].get("deck"))
    L.update_entity(deck["id"], name="Sony CIY-720", description="a second-hand Sony CIY-720 cyberdeck, scuffed and "
                    "reliable", props={**deck["props"], "deck": 3, "bonus": {"hacking": 1, "cybercombat": 1,
                                                                              "electronics": 1}})
    game.set_control(rage, "player")                   # the GM never answers for Rage, even before anyone joins
    dutch = game.introduce("npc", "Dutch", "dwarf fixer who runs jobs out of a pawnshop in Tacoma: gravel voice, "
                           "nicotine-yellow beard, reading glasses on a chain, pays on time and never says who "
                           "the client is", template="contact", turn=t)[0]
    horizon = game.introduce("faction", "Horizon", "Horizon Group, the AAA corp of media, PR and reputation - "
                             "they sell how the world sees you, and they guard their clients jealously",
                             aliases=["Horizon Group"], nuyen=500000, turn=t)[0]
    office = game.introduce("location", "Horizon Seattle office", "twelve glass floors in downtown Seattle: "
                            "holo-ads on the lobby walls, a smiling security desk, a server room on 9",
                            aliases=["the Horizon office", "Horizon tower"], where={"district": "Downtown"}, turn=t)[0]
    host = game.introduce("host", "Horizon Seattle host", "Horizon's office host, sculpted as a sunlit gallery of "
                          "living portraits - every client a painting that smiles back", rating=4, turn=t)[0]
    for name, desc, secure in [
            ("Horizon Seattle client list", "every account the Seattle office handles: names, retainers, contacts, "
             "and the 'sensitive accounts' flag", True),
            ("Q4 campaign decks", "glossy pitch decks for next quarter's campaigns", False),
            ("Staff directory", "names, desks and badge photos for the Seattle office", False)]:
        fid = game.introduce("item", name, desc, owner_id=host, turn=t)[0]
        L.update_entity(fid, props={**L.get(fid)["props"], "file": True, **({"secure": True} if secure else {})})
    game.sub.add_fact("Dutch is a fixer in Tacoma who has sent Rage work before; he pays on time.", [dutch, rage], t)
    game.sub.add_fact("Horizon's Seattle office is downtown; its host is where the office keeps its client files.",
                      [horizon, office, host], t)
    game.sub.add_note([dutch], "The job: pull Horizon Seattle's client list tonight, before Horizon's weekly data "
                      "purge at 06:00. Pay 6,000 nuyen, 2,000 more if Horizon never learns it was taken. Dutch's "
                      "client is a Saeder-Krupp PR liaison who wants to poach Horizon's accounts - Dutch won't say "
                      "so unless pressed hard.", t)
    game.sub.add_note([host], "The client list is secure (admin access). Its 'sensitive accounts' section hides "
                      "GLASSWING: Horizon is quietly burying a Knight Errant unit's cover-up of a shooting in "
                      "Puyallup. That's worth more than the job - and dangerous to know. A Horizon security "
                      "spider works the night shift and takes data theft personally.", t)
    from .dm import tensions                       # the questions the story opens with (dm/tensions.py)
    tensions.open_tension(game, "Can Rage pull Horizon's client list before the 06:00 purge - without Horizon ever "
                          "knowing?", [rage, host], t, stakes=3, due=1800,
                          next_="Horizon's night-shift spider sweeps the host around 02:00",
                          public="The job: Horizon Seattle's client list before their 06:00 purge - 6,000 nuyen, "
                                 "2,000 more if Horizon never knows", by="seed")
    tensions.open_tension(game, "Who is Dutch's buyer, and what do they really want the list for?", [dutch], t,
                          stakes=2, next_="The buyer pushes Dutch for an early delivery", by="seed")
    tensions.open_tension(game, "What is GLASSWING, and who gets hurt when it comes out?", [horizon, host], t,
                          stakes=3, next_="Someone else is already poking at the sensitive accounts", by="seed")
    L.set_meta("session", "1")
    game.new_scene("A call from Dutch", home, [rage], t)
    L.set_meta("campaign", "rage")
    L.set_meta("opening", "Late night in Rage's apartment. Rage's commlink buzzes: Dutch, a fixer Rage has worked "
               "with before, calling with a job - get into Horizon's Seattle office network and pull their client "
               "list. Play the call as Dutch (the pitch, the pay, the deadline) and stop when Rage has to answer. "
               "Don't decide anything for Rage.")


SEEDS = {"demo": setup_demo, "rage": setup_rage}
