"""The character sheet as pictures (DESIGN.md §12b): an AR runner record in two pages.

Page 1 - the runner: portrait, identity, karma / nuyen / Edge / Essence, attribute tiles (each with its
`!advance` number and the karma the next point costs), condition monitors as Shadowrun box tracks, and every
skill with the exact dice pool the engine rolls. Page 2 - kit and gifts: weapons with their attack pools,
armor, chrome, gear, the Matrix / Magic / Resonance panels, drones, and what karma can buy.

Everything comes from the ledger through sr_lite, so the picture is the rules - nothing an image model drew.
"""
from __future__ import annotations

import functools
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

from .engine import clock
from .engine.rules import machines, magic, matrix, resonance, sr_lite

W = 1600
BG = (10, 14, 22)
PANEL = (17, 24, 37)
LINE = (44, 62, 88)
CYAN = (80, 220, 255)
MAGENTA = (255, 74, 166)
AMBER = (255, 186, 70)
GREEN = (96, 232, 146)
RED = (255, 86, 86)
INK = (228, 236, 246)
DIM = (130, 148, 172)
FAINT = (70, 86, 110)
NATURAL = ("body", "agility", "reaction", "strength", "willpower", "logic", "intuition", "charisma")


@functools.lru_cache(maxsize=64)
def font(size: int, style: str = "Regular") -> ImageFont.FreeTypeFont:
    try:
        f = ImageFont.truetype("bahnschrift.ttf", size)
        want = style.encode()
        if want in f.get_variation_names():
            f.set_variation_by_name(want)
        return f
    except (OSError, AttributeError):
        from .maps import _font
        return _font(size, bold="Bold" in style)


@functools.lru_cache(maxsize=32)
def mono(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    for name in (("consolab.ttf",) if bold else ("consola.ttf",)) + ("DejaVuSansMono.ttf",):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return font(size)


def wrap(text: str, f, width: int) -> list[str]:
    avg = max(1.0, f.getlength("abcdefghij klmnopqrstuvwxyz") / 27)
    lines = []
    for para in (text or "").split("\n"):
        lines += textwrap.wrap(para, max(8, int(width / avg))) or [""]
    return lines


def _canvas(h: int) -> Image.Image:
    img = Image.new("RGB", (W, h), BG)
    d = ImageDraw.Draw(img)
    for x in range(0, W, 40):
        d.line([(x, 0), (x, h)], fill=(14, 20, 31))
    for y in range(0, h, 40):
        d.line([(0, y), (W, y)], fill=(14, 20, 31))
    glow = Image.new("RGBA", (W, h), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse([-400, -500, 700, 400], fill=(80, 220, 255, 26))
    g.ellipse([W - 600, h - 500, W + 500, h + 500], fill=(255, 74, 166, 22))
    return Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(140)))


def _panel(d: ImageDraw.ImageDraw, box, title: str | None = None, accent=CYAN) -> None:
    x0, y0, x1, y1 = box
    c = 16
    d.polygon([(x0, y0), (x1 - c, y0), (x1, y0 + c), (x1, y1), (x0 + c, y1), (x0, y1 - c)], fill=PANEL, outline=LINE)
    if title:
        d.rectangle([x0, y0, x0 + 6, y0 + 40], fill=accent)
        d.text((x0 + 22, y0 + 20), title, font=font(24, "SemiBold SemiCondensed"), fill=accent, anchor="lm")


def _topbar(d: ImageDraw.ImageDraw, left: str, right: str) -> None:
    d.rectangle([0, 0, W, 50], fill=(13, 19, 30))
    d.line([(0, 50), (W, 50)], fill=CYAN, width=2)
    d.text((40, 25), left, font=font(22, "SemiBold SemiCondensed"), fill=CYAN, anchor="lm")
    d.text((W - 40, 25), right, font=font(22, "SemiCondensed"), fill=DIM, anchor="rm")


def _brackets(d: ImageDraw.ImageDraw, box, col=CYAN, n=26, w=4) -> None:
    x0, y0, x1, y1 = box
    for (x, y, dx, dy) in ((x0, y0, 1, 1), (x1, y0, -1, 1), (x0, y1, 1, -1), (x1, y1, -1, -1)):
        d.line([(x, y), (x + dx * n, y)], fill=col, width=w)
        d.line([(x, y), (x, y + dy * n)], fill=col, width=w)


def _portrait(path: Path | None, w: int, h: int) -> Image.Image:
    if path and Path(path).exists():
        src = Image.open(path).convert("RGB")
        return ImageOps.fit(src, (w, h), method=Image.LANCZOS, centering=(0.5, 0.22))
    img = Image.new("RGB", (w, h), (24, 32, 46))
    d = ImageDraw.Draw(img)
    d.ellipse([w * 0.3, h * 0.16, w * 0.7, h * 0.46], fill=(44, 58, 80))
    d.rounded_rectangle([w * 0.16, h * 0.5, w * 0.84, h * 1.05], 70, fill=(44, 58, 80))
    d.text((w / 2, h * 0.9), "NO PORTRAIT YET", font=font(22, "SemiBold"), fill=DIM, anchor="mm")
    return img


def _boxes(d: ImageDraw.ImageDraw, x: int, y: int, filled: int, size: int, col, box=38, gap=7,
           ticks: bool = True) -> int:
    """A condition monitor: one box per point, filled for damage, a wound-penalty tick every third."""
    for i in range(size):
        bx = x + i * (box + gap)
        on = i < filled
        d.rectangle([bx, y, bx + box, y + box], fill=col if on else (20, 28, 42), outline=col if on else FAINT, width=2)
        if on:
            d.line([(bx + 7, y + 7), (bx + box - 7, y + box - 7)], fill=(30, 10, 14), width=3)
        if ticks and (i + 1) % 3 == 0:
            d.text((bx + box / 2, y + box + 14), f"-{(i + 1) // 3}", font=mono(16), fill=FAINT, anchor="mm")
    return x + size * (box + gap)


def _pool(L, eid: str, skill: str, attr: str | None = None) -> tuple[int, list]:
    try:
        return sr_lite.build_pool(L, eid, skill, attr)
    except Exception:
        return 0, []


def _joined(items) -> str:
    """'#11 Athletics · #12 Close Combat': wraps between items, never inside one or before a dot."""
    return " ·  ".join(i.replace(" ", " ") for i in items)


def _short(name: str) -> str:
    return name.split("'s ", 1)[-1] if "'s " in name else name


# ── page 1: the runner ──────────────────────────────────────────────────

def page_one(game, eid: str, out: Path) -> Path:
    L = game.ledger
    ent = L.require(eid)
    s = L.stats(eid)
    p = ent["props"]
    is_pc = ent["kind"] == "pc"
    karma = int(s.get("karma", 0))
    refs = {k: r for r, k in sr_lite.advancement_refs().items()}
    skills = []
    for k in sr_lite.SKILLS:
        if s.get(k):
            n, parts = _pool(L, eid, k)
            skills.append((n, k, parts))
    skills.sort(key=lambda t: (-t[0], t[1]))
    rows = (len(skills) + 1) // 2
    sk_top = 790
    h = sk_top + 110 + max(1, rows) * 62 + 40
    img = _canvas(h)
    d = ImageDraw.Draw(img)
    _topbar(d, "SHADOWRUN  //  RUNNER RECORD", f"{game.path.stem}  ·  {clock.short(game.clock())}")

    # portrait
    art = game.art.latest(game.conn, eid, ready_only=True)
    pic = _portrait(Path(art["path"]) if art else None, 360, 470)
    img.paste(pic, (50, 86))
    d.rectangle([50, 86, 410, 556], outline=LINE, width=2)
    _brackets(d, (42, 78, 418, 564))

    # who
    x0 = 452
    d.text((x0, 76), ent["name"].upper(), font=font(76, "Bold SemiCondensed"), fill=INK)
    role = (p.get("archetype") or p.get("template") or ent["kind"]).replace("_", " ")
    sub = " ".join(x for x in (p.get("metatype", ""), role) if x).title()
    d.text((x0, 172), sub, font=font(32, "SemiBold"), fill=CYAN)
    tail = "  ·  ".join(x for x in (p.get("pronouns"), f"played by {ent['player']}" if is_pc and ent["player"] else
                                    ("an NPC you're playing" if not is_pc else "")) if x)
    if tail:
        d.text((x0 + font(32, "SemiBold").getlength(sub) + 18, 178), "·  " + tail, font=font(24), fill=DIM)
    desc = ent["description"]
    if p.get("pronouns") and desc.endswith(f"({p['pronouns']})"):
        desc = desc[: -len(p["pronouns"]) - 2].strip()
    for i, line in enumerate(wrap(desc, font(22), W - x0 - 50)[:3]):
        d.text((x0, 222 + i * 30), line, font=font(22), fill=(176, 190, 210))

    # resources
    chips = []
    if is_pc:
        chips.append(("KARMA", str(karma), AMBER))
    chips += [("NUYEN", f"¥{int(s.get('nuyen', 0)):,}", INK),
              ("EDGE", f"{int(s.get('edge_points', 0))} / {int(s.get('edge', 0))}", INK)]
    if "essence" in s:
        chips.append(("ESSENCE", f"{s['essence']:g}", INK))
    for gift_key, col in (("magic", MAGENTA), ("resonance", MAGENTA)):
        if s.get(gift_key):
            chips.append((gift_key.upper(), str(int(s[gift_key])), col))
    attr, n, _ = sr_lite.initiative_rating(L, eid)       # (every 10 of it is an action in a fight)
    if n:
        chips.append(("INITIATIVE", f"{attr} + {n}D6", INK))
    cw = (W - 50 - x0 - 12 * (len(chips) - 1)) / len(chips)
    for i, (label, value, col) in enumerate(chips):
        cx = x0 + i * (cw + 12)
        d.rounded_rectangle([cx, 326, cx + cw, 406], 10, fill=PANEL, outline=LINE, width=2)
        d.text((cx + 18, 342), label, font=font(18, "SemiBold"), fill=DIM)
        d.text((cx + 18, 366), value, font=font(34, "Bold"), fill=col)

    # attributes: value, !advance number, what the next point costs
    tw = (W - 50 - x0 - 7 * 10) / 8
    for i, a in enumerate(NATURAL):
        tx, ty = x0 + i * (tw + 10), 424
        d.rounded_rectangle([tx, ty, tx + tw, ty + 132], 10, fill=PANEL, outline=LINE, width=2)
        d.text((tx + tw / 2, ty + 22), sr_lite.ABBR[a], font=font(22, "SemiBold"), fill=CYAN, anchor="mm")
        d.text((tx + tw / 2, ty + 68), str(int(s.get(a, 0))), font=font(56, "Bold"), fill=INK, anchor="mm")
        if is_pc:
            new, cost, why = sr_lite.advance_cost(L, eid, a)
            note, col = ("max", FAINT) if why else (f"▲{cost}", GREEN if cost <= karma else DIM)
            d.text((tx + 12, ty + 116), f"#{refs[a]}", font=mono(17), fill=FAINT, anchor="lm")
            d.text((tx + tw - 12, ty + 116), note, font=mono(17, True), fill=col, anchor="rm")

    # condition monitors
    _panel(d, (50, 594, W - 50, 764), "CONDITION")
    pmax, smax = sr_lite.monitor_max(L, eid)
    phys, stun = int(s.get("physical_damage", 0)), int(s.get("stun_damage", 0))
    for row, (label, dmg, size, col) in enumerate((("PHYSICAL", phys, pmax, RED), ("STUN", stun, smax, AMBER))):
        y = 646 + row * 58
        d.text((80, y + 19), label, font=font(24, "SemiBold"), fill=INK, anchor="lm")
        end = _boxes(d, 230, y, dmg, size, col, box=34, gap=6, ticks=row == 1)
        d.text((end + 14, y + 19), f"{dmg}/{size}", font=mono(22, True), fill=DIM, anchor="lm")
    status = sr_lite.condition(L, eid)
    pen = sr_lite.wound_penalty(L, eid)
    scol = GREEN if status == "ok" and not pen else AMBER if status in ("ok", "wounded") else RED
    d.text((W - 80, 660), status.upper(), font=font(40, "Bold"), fill=scol, anchor="rm")
    d.text((W - 80, 712), f"-{pen} to every pool" if pen else "no wound penalty", font=font(22), fill=DIM, anchor="rm")

    # skills & dice pools
    _panel(d, (50, sk_top, W - 50, h - 40), "SKILLS & DICE POOLS")
    d.text((W - 80, sk_top + 20), "skill + attribute + gear = the dice the engine rolls  ·  hits on 5s and 6s",
           font=font(20), fill=DIM, anchor="rm")
    colw = (W - 100 - 60) / 2
    for i, (n, k, parts) in enumerate(skills):
        cx = 80 + (i // rows if rows else 0) * (colw + 30)
        cy = sk_top + 70 + (i % rows) * 62
        if is_pc:
            d.text((cx, cy + 20), f"#{refs[k]}", font=mono(17), fill=FAINT, anchor="lm")
        name_f, how_f = font(28, "SemiBold"), font(17)
        d.text((cx + 50, cy + 4), sr_lite.nice(k), font=name_f, fill=INK)
        how = " + ".join(f"{_short(label).split(' (')[0]} {v}" for label, v in parts).replace("+ -", "- ")
        room = colw - 50 - 90
        while how_f.getlength(how) > room and " " in how:
            how = how.rsplit(" ", 1)[0].rstrip("+- ") + "..."
        d.text((cx + 50, cy + 38), how, font=how_f, fill=DIM)
        d.text((cx + colw - 6, cy + 22), str(n), font=font(46, "Bold"), fill=CYAN, anchor="rm")
        start = cx + 50 + name_f.getlength(sr_lite.nice(k)) + 20          # the dice, as pips, after the name
        for j in range(min(n, 24)):
            px = cx + colw - 84 - j * 11
            if px < start:
                break
            d.rectangle([px, cy + 18, px + 7, cy + 25], fill=(52, 120, 150))
    if not skills:
        d.text((80, sk_top + 80), "No trained skills - untrained rolls use the attribute - 1.", font=font(24), fill=DIM)
    return _save(img, out)


# ── page 2: kit, gifts and karma ────────────────────────────────────────

# The gift panels' room: a list item is drawn at font(20) in a 270px column, the right one ending at the panel's
# edge (260px); a note at font(18) gets the panel's width, never wrapped. test_charsheet measures against these.
GIFT_X = 1020
LIST_COL = 270
LIST_W = W - 50 - (GIFT_X + LIST_COL)
NOTE_W = W - 50 - GIFT_X


def magic_panel(L, eid: str, s: dict) -> list[tuple]:
    """The MAGIC panel: each spell with its drain code and, in brackets, the drain at full Magic ('Physical Barrier
    F-1 (5)'). Live, flag #62: '(drain 5)' with no Force read as the spell's modifier, and the note said drain
    turns physical above Force 6 - the engine and SR5 p. 281 go by the hits."""
    m = int(s["magic"])
    known = magic.known(L, eid) or list(magic.SPELLS)
    return [("big", f"Magic {m}  ·  drain resist {int(s.get('willpower', 0)) + int(s.get('logic', 0))} dice"),
            ("pools", [("Sorcery", _pool(L, eid, "sorcery")[0]), ("Conjuring", _pool(L, eid, "conjuring")[0])]),
            ("list", [f"{magic.SPELLS[k]['name']}  {magic.drain_code(magic.SPELLS[k]['drain'])} "
                      f"({magic.drain_value(m, magic.SPELLS[k]['drain'])})" for k in known]),
            ("note", f"F = the Force cast at, drain never under 2  ·  (n) = at Force {m}"),
            ("note", f"Force 1-{2 * m}  ·  physical when your hits beat Magic {m}")]


def resonance_panel(L, ent: dict, s: dict) -> list[tuple]:
    """The RESONANCE panel: each form with its fading code and the fading at full Resonance."""
    r = int(s["resonance"])
    known = list(ent["props"].get("forms") or resonance.FORMS)
    return [("big", f"Resonance {r}  ·  fading resist {int(s.get('willpower', 0)) + r} dice"),
            ("pools", [("Software", _pool(L, ent["id"], "software")[0]),
                       ("Compiling", _pool(L, ent["id"], "compiling")[0])]),
            ("list", [f"{resonance.FORMS[k]['name']}  {resonance.fading_code(resonance.FORMS[k]['fading'])} "
                      f"({resonance.fading_value(r, resonance.FORMS[k]['fading'])})" for k in known]),
            ("note", f"L = the Level, fading never under 2  ·  (n) = at Level {r}"),
            ("note", f"Levels 1-{2 * r}  ·  physical when your hits beat Resonance {r}"),
            ("note", "you are the deck - no hardware to fry")]


def page_two(game, eid: str, out: Path) -> Path:
    L = game.ledger
    ent = L.require(eid)
    s = L.stats(eid)
    is_pc = ent["kind"] == "pc"
    items = L.holdings(eid)
    weapons = [i for i in items if "dv" in i["props"]]
    armor = [i for i in items if "armor" in i["props"] and "dv" not in i["props"]]
    chrome = [i for i in items if i["props"].get("augmentation")]
    other = [i for i in items if i not in weapons and i not in armor and i not in chrome]

    # left column: gear (measure first, then draw)
    left: list[tuple] = []                        # (kind, payload) rows, drawn top to bottom
    if weapons:
        left.append(("head", "WEAPONS"))
        for w in weapons:
            pp = w["props"]
            n, _ = _pool(L, eid, pp.get("skill", "firearms"))
            bits = [f"DV {pp['dv']}{'S' if pp.get('damage_type') == 'stun' else 'P'}"]
            if pp.get("ap"):
                bits.append(f"AP {pp['ap']}")
            if "ammo_capacity" in pp:
                bits.append(f"{w['state'].get('loaded', pp['ammo_capacity'])}/{pp['ammo_capacity']} rds")
            if pp.get("accuracy"):
                bits.append(f"ACC +{pp['accuracy']}")
            if pp.get("explosive"):
                bits.append("blast")
            qty = f"{w['qty']}× " if w["qty"] > 1 else ""
            left.append(("weapon", (qty + _short(w["name"]), "  ·  ".join(bits), n, sr_lite.nice(pp.get("skill", "firearms")))))
    if armor:
        left.append(("head", "ARMOR"))
        best, _label = sr_lite.best_armor(L, eid)
        for a in armor:
            v = a["props"]["armor"]
            left.append(("line", (_short(a["name"]), f"armor {v}" + ("  ·  worn" if v == best else ""))))
    if chrome:
        left.append(("head", "AUGMENTATIONS"))
        for c in chrome:
            pp = c["props"]
            fx = pp.get("effect") or ", ".join(f"+{v} {sr_lite.nice(k)}" for k, v in (pp.get("bonus") or {}).items())
            left.append(("line", (_short(c["name"]), f"{fx}  ·  ESS {pp.get('essence', 0):g}".strip(" ·"))))
    if other:
        left.append(("head", "GEAR"))
        for o in other:
            pp = o["props"]
            bits = []
            if pp.get("deck"):
                bits.append(f"deck {pp['deck']}" + ("  ·  BRICKED" if matrix.bricked(L, eid) == o["id"] else ""))
            if pp.get("control_rig"):
                bits.append(f"control rig {pp['control_rig']}")
            if pp.get("bonus"):
                bits.append(", ".join(f"+{v} {sr_lite.nice(k)}" for k, v in pp["bonus"].items()))
            qty = f"{o['qty']}× " if o["qty"] > 1 else ""
            left.append(("line", (qty + _short(o["name"]), "  ·  ".join(bits))))
    if not left:
        left.append(("line", ("Nothing but lint.", "")))
    lh = {"head": 54, "weapon": 70, "line": 52}
    left_h = 70 + sum(lh[k] for k, _ in left) + 20

    # right column: gifts and rides
    right = []
    rating, deck_name = matrix.deck(L, eid)
    if rating:
        st = matrix.state(L, eid)
        lines = [("big", f"{_short(deck_name)}  ·  rating {rating}")]
        if not matrix.living(L, eid):
            lines.append(("boxes", (int(st.get("deck_damage", 0)), matrix.deck_monitor(rating))))
        lines.append(("pools", [("Hack", _pool(L, eid, "hacking")[0]), ("Brute force", _pool(L, eid, "cybercombat")[0]),
                                ("Search", _pool(L, eid, "electronics", "intuition")[0]),
                                ("Control / data", _pool(L, eid, "electronics")[0])]))
        fw = matrix.firewall(L, eid)                 # (the soaks too - flags #29, #30)
        lines.append(("note", f"+2 dice in hot-sim VR · IC defense {int(s.get('intuition', 0)) + fw} dice · soak "
                              f"{rating + fw} · Black IC {int(s.get('willpower', 0)) + fw}"))
        if matrix.living(L, eid):                 # (its own line: on one it ran off the panel)
            lines.append(("note", "Matrix damage hits your mind as stun"))
        right.append(("MATRIX", CYAN, lines))
    if s.get("magic"):
        right.append(("MAGIC", MAGENTA, magic_panel(L, eid, s)))
    if s.get("resonance"):
        right.append(("RESONANCE", MAGENTA, resonance_panel(L, ent, s)))
    rides = machines.owned_by(L, eid)
    if rides:
        lines = []
        for m in rides:
            ms = L.stats(m["id"])
            pmax, _ = sr_lite.monitor_max(L, m["id"])
            lines.append(("ride", (m["name"].split("'s ", 1)[-1], int(ms.get("physical_damage", 0)), pmax,
                                   " · ".join(f"{k.title()} {int(ms[k])}" for k in ("body", "armor", "pilot", "speed")
                                              if k in ms))))
        right.append(("DRONES & VEHICLES", AMBER, lines))
    rh = {"big": 48, "boxes": 52, "pools": 78, "note": 34, "ride": 92}

    def right_height(block) -> int:
        _, _, lines = block
        total = 70
        for kind, payload in lines:
            total += rh.get(kind, 0) if kind != "list" else 34 * ((len(payload) + 1) // 2) + 8
        return total + 16
    right_h = sum(right_height(b) + 24 for b in right)

    # bottom: karma, or an inhabited NPC's feelings
    karma = int(s.get("karma", 0))
    learn = []
    if is_pc:
        for ref, key in sr_lite.advancement_refs().items():
            if key in sr_lite.SKILLS and not s.get(key) and not sr_lite.advance_cost(L, eid, key)[2]:
                learn.append(f"#{ref} {sr_lite.nice(key)}")
        adv = ["Spend with !advance <#> - the numbers are on page 1. An attribute costs its new rating × 5, a skill "
               "its new rating × 2; a green cost means you can afford it now."]
        if learn:
            adv.append("Learn a new skill (2 karma, starts at 1):  " + _joined(learn))
        # (the costs are the engine's: a form is 4, not the 5 this said; an empty list knows them all - nothing to learn)
        if s.get("magic") and magic.learnable(L, eid):
            adv.append(f"Learn a spell ({magic.LEARN_COST} karma, !advance spell <name>):  " + _joined(
                magic.spell_label(k) for k in magic.learnable(L, eid)))
        if s.get("resonance") and resonance.learnable(L, eid):
            adv.append(f"Learn a complex form ({resonance.LEARN_COST} karma, !advance form <name>):  " + _joined(
                resonance.form_label(k) for k in resonance.learnable(L, eid)))
    else:
        adv = [b["text"] for b in game.sub.beliefs_of(eid)[:4]] or ["(no settled feelings yet)"]
    adv_lines = [ln for a in adv for ln in wrap(a, font(22), W - 200)]
    adv_h = 80 + len(adv_lines) * 32 + 20

    top = 76
    h = top + max(left_h, right_h) + 30 + adv_h + 40
    img = _canvas(h)
    d = ImageDraw.Draw(img)
    _topbar(d, f"SHADOWRUN  //  {ent['name'].upper()}  //  KIT, GIFTS & KARMA",
            f"{game.path.stem}  ·  {clock.short(game.clock())}")

    # gear
    lx1 = 960 if right else W - 50
    _panel(d, (50, top, lx1, top + max(left_h, right_h if right else 0)), "GEAR")
    y = top + 62
    for kind, payload in left:
        if kind == "head":
            d.text((80, y + 22), payload, font=font(20, "SemiBold"), fill=DIM, anchor="lm")
            d.line([(80 + font(20, "SemiBold").getlength(payload) + 14, y + 23), (lx1 - 30, y + 23)], fill=LINE)
        elif kind == "weapon":
            name, bits, n, skill = payload
            d.text((80, y + 4), name, font=font(28, "SemiBold"), fill=INK)
            d.text((80, y + 40), bits, font=mono(19), fill=DIM)
            d.text((lx1 - 30, y + 18), f"{n}", font=font(44, "Bold"), fill=CYAN, anchor="rm")
            d.text((lx1 - 30 - font(44, "Bold").getlength(str(n)) - 10, y + 22), f"{skill} dice", font=font(18),
                   fill=DIM, anchor="rm")
        else:
            name, bits = payload
            d.text((80, y + 8), name, font=font(26, "SemiBold"), fill=INK)
            if bits:
                d.text((lx1 - 30, y + 22), bits, font=mono(19), fill=DIM, anchor="rm")
        y += lh[kind]

    # gifts and rides
    y = top
    for title, col, lines in right:
        bh = right_height((title, col, lines))
        _panel(d, (990, y, W - 50, y + bh), title, col)
        yy = y + 62
        for kind, payload in lines:
            if kind == "big":
                d.text((1020, yy), payload, font=font(28, "SemiBold"), fill=INK)
                yy += rh["big"]
            elif kind == "boxes":
                dmg, size = payload
                d.text((1020, yy + 16), "DECK", font=font(20, "SemiBold"), fill=DIM, anchor="lm")
                _boxes(d, 1090, yy, dmg, size, CYAN, box=30, gap=6, ticks=False)
                yy += rh["boxes"]
            elif kind == "pools":
                pw = (W - 50 - 1020 - 30) / len(payload)
                for i, (label, n) in enumerate(payload):
                    px = 1020 + i * pw
                    d.text((px, yy), label, font=font(18), fill=DIM)
                    d.text((px, yy + 22), str(n), font=font(42, "Bold"), fill=col)
                yy += rh["pools"]
            elif kind == "list":
                for i, item in enumerate(payload):
                    d.text((GIFT_X + (i % 2) * LIST_COL, yy + (i // 2) * 34), item, font=font(20), fill=INK)
                yy += 34 * ((len(payload) + 1) // 2) + 8
            elif kind == "note":
                d.text((GIFT_X, yy), payload, font=font(18), fill=DIM)
                yy += rh["note"]
            elif kind == "ride":
                name, dmg, size, stats = payload
                d.text((1020, yy), name, font=font(26, "SemiBold"), fill=INK)
                _boxes(d, 1020, yy + 36, dmg, size, AMBER, box=20, gap=4, ticks=False)
                d.text((1020 + size * 24 + 14, yy + 46), stats, font=font(17), fill=DIM, anchor="lm")
                yy += rh["ride"]
        y += bh + 24

    # karma / feelings
    ay = top + max(left_h, right_h) + 30
    _panel(d, (50, ay, W - 50, ay + adv_h), f"ADVANCEMENT  ·  KARMA {karma}" if is_pc else "HOW YOU FEEL",
           AMBER if is_pc else MAGENTA)
    for i, line in enumerate(adv_lines):
        d.text((80, ay + 66 + i * 32), line, font=font(22), fill=INK if i else (210, 220, 234))
    return _save(img, out)


def _save(img: Image.Image, out: Path) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(out, optimize=True)
    return out


def render(game, eid: str, out_dir: Path | None = None) -> list[Path]:
    out_dir = Path(out_dir) if out_dir else game.path.parent / "sheets"
    stem = f"{game.path.stem}_{eid}"
    return [page_one(game, eid, out_dir / f"{stem}_1.png"), page_two(game, eid, out_dir / f"{stem}_2.png")]
