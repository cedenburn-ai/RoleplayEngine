"""Turning engine output into Discord-sized pieces - including the story cards from the old C# bot:
a location card, item cards, one purple card per narration paragraph, and a card per line of
dialogue (big portrait the first time a character is shown, a thumbnail after, gray for extras).
"""
from __future__ import annotations

import re
from pathlib import Path

MSG_LIMIT = 1900          # Discord hard limit is 2000 per message
EMBED_LIMIT = 4000        # embed description hard limit is 4096
EMBEDS_PER_MESSAGE = 5    # the old bot batched 5; Discord allows 10 / 6000 chars per message

# card colors carried over from DungeonsAndDiscords/Program.cs
NARRATION = 0x9B59B6
LOCATION = 0x1ABC9C
LOCATION_STRIP = 0x2C3E50
ITEM = 0xF1C40F
SPEAKER_MAJOR = 0x3498DB
SPEAKER_MINOR = 0x95A5A6
SPEAKER_PC = 0x4FC3F7

SPEAKER = re.compile(r"\*\*([^*\n]{1,48}?):\*\*\s*")    # **Kaz:** "line"


def parse_story(narration: str) -> list[dict]:
    """Narration -> ordered segments: {'kind': 'narration', 'text'} | {'kind': 'dialogue', 'speaker', 'text'}.
    A paragraph that opens with (or contains) **Name:** becomes a dialogue card from that point on."""
    segs: list[dict] = []
    for para in re.split(r"\n\s*\n", narration.strip()):
        para = para.strip()
        if not para:
            continue
        marks = list(SPEAKER.finditer(para))
        if not marks:
            segs.append({"kind": "narration", "text": para})
            continue
        before = para[:marks[0].start()].strip().rstrip(":").strip()
        if before:
            segs.append({"kind": "narration", "text": before})
        for i, m in enumerate(marks):
            end = marks[i + 1].start() if i + 1 < len(marks) else len(para)
            line = para[m.end():end].strip()
            if line:
                segs.append({"kind": "dialogue", "speaker": m.group(1).strip(), "text": line})
    return segs


def thumbnail(path: str | None, size: int = 256) -> str | None:
    """A small JPEG next to the art (cached), so speaking characters don't re-upload 2 MB portraits."""
    if not path or not Path(path).exists():
        return None
    src = Path(path)
    out = src.parent / "thumbs" / f"{src.stem}.jpg"
    if out.exists() and out.stat().st_mtime >= src.stat().st_mtime:
        return str(out)
    try:
        from PIL import Image
        out.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(src) as im:
            im = im.convert("RGB")
            im.thumbnail((size, size))
            im.save(out, "JPEG", quality=85)
        return str(out)
    except Exception:
        return str(src)          # no Pillow / unreadable: fall back to the full image

# engine output lines players should see (mechanics); everything else is GM-side logging. ([FIGHT] was log-only until
# 2026-10-24 - the table never saw who had how many actions; [INITIATIVE] is each new round's, posted after the map.
# [SHOP] too: a GM's buy moved a runner's money where nobody could see it, and a delivery arriving is news.)
PLAYER_PREFIXES = ("[ROLL]", "[DAMAGE]", "[HEAL]", "[GEAR]", "[NUYEN]", "[KARMA]", "[RULING]", "[MATRIX]", "[FIX]",
                   "[FIGHT]", "[INITIATIVE]", "[SHOP]")
# [CALL]: a roll a player called that wasn't made, and why (flag #51 - the only trace was a developer flag)
NOTICE_PREFIXES = ("[NEW]", "[SCENE]", "[MERGE]", "[CALL]")


def classify(line: str) -> str:
    s = line.lstrip()
    if s.startswith(PLAYER_PREFIXES):
        return "card"
    if s.startswith(NOTICE_PREFIXES):
        return "notice"
    return "log"            # [MINDS], [RUMOR], [art], tool rejections... GM-side only


def chunks(text: str, limit: int) -> list[str]:
    """Split on paragraph, then line, then hard boundaries."""
    out: list[str] = []
    buf = ""
    for para in text.split("\n"):
        piece = para + "\n"
        if len(buf) + len(piece) <= limit:
            buf += piece
            continue
        if buf:
            out.append(buf.rstrip())
        while len(piece) > limit:
            out.append(piece[:limit])
            piece = piece[limit:]
        buf = piece
    if buf.strip():
        out.append(buf.rstrip())
    return out


def card_messages(cards: list[str], color: bool = False) -> list[str]:
    """Roll cards as code blocks (monospace keeps the pool math aligned) - coloured (ansi.py) unless the table's
    switched colours off."""
    if not color:
        return [f"```\n{b}\n```" for b in chunks("\n".join(cards), MSG_LIMIT - 10)]
    from .ansi import card_block
    return [f"```ansi\n{b}\n```" for b in chunks(card_block("\n".join(cards)), MSG_LIMIT - 12)]


def notice_text(line: str) -> str:
    s = line.strip()
    for p in NOTICE_PREFIXES:
        if s.startswith(p):
            s = s[len(p):].strip()
    s = s.replace(" (from narration)", "")
    return f"-# {s}"     # Discord's small subtext line
