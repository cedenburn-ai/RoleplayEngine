"""The bot as a background program (DESIGN.md §5b): one copy at a time, a heartbeat, and a polite way to stop it.

The dashboard starts the bot as its own process and never talks to it over a port. Everything goes through three
small files in campaigns/.run/:

- bot.lock         an OS file lock the bot holds for as long as it runs. A second copy refuses to start, and anyone
                   can ask "is a bot up?" by trying the lock. It frees itself when the process ends, however it ends.
- bot_status.json  rewritten every few seconds: pid, connection and latency, the tables it serves, whose actions
                   are queued, who's been active, whether a turn is being resolved, what it has spent since it started.
- bot_control.json the dashboard drops a request here ({"cmd": "stop"}). The bot picks it up within a second, lets
                   a turn in progress finish (and the offscreen world, the posts, the portraits being painted), tells a
                   table whose queued actions it has to drop, and closes cleanly.

The Discord token comes from keys.py: config.toml, else DISCORD_BOT_TOKEN (the environment, or the Windows user
environment), else the old C# bot's DungeonsAndDiscords/Program.cs. It is read into the bot's own memory and never
printed or written anywhere.
"""
from __future__ import annotations

import asyncio
import json
import math
import os
import sys
import time
from pathlib import Path

from .. import keys
from ..config import CAMPAIGN_DIR, ROOT

RUN_DIR = CAMPAIGN_DIR / ".run"
LOCK, STATUS, CONTROL = "bot.lock", "bot_status.json", "bot_control.json"
BEAT = 5.0                       # seconds between heartbeats
WAITS = {"turn": 240.0, "world": 90.0, "posts": 45.0, "art": 90.0}    # how long a stop waits for each, at most


# ── files ───────────────────────────────────────────────────────────────
def run_dir(folder: Path | None = None) -> Path:
    d = Path(folder or RUN_DIR)
    d.mkdir(parents=True, exist_ok=True)
    return d


def write_json(p: Path, data: dict) -> None:
    """Atomic: write a sibling, then swap it in (retrying - a reader may hold the old one open for a moment)."""
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, default=str), encoding="utf-8")
    for _ in range(20):
        try:
            os.replace(tmp, p)
            return
        except PermissionError:
            time.sleep(0.05)
    tmp.unlink(missing_ok=True)


def read_json(p: Path) -> dict | None:
    for _ in range(3):
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (PermissionError, ValueError):
            time.sleep(0.05)
    return None


def code_stamp() -> float:
    """The newest source file's mtime - the dashboard compares it with the running bot's to say 'restart to update'.
    (The dashboard's own files don't count: the bot never loads them.)"""
    skip = ROOT / "roleplay" / "dashboard"
    return max((p.stat().st_mtime for p in (ROOT / "roleplay").rglob("*.py") if skip not in p.parents), default=0.0)


def find_token() -> str | None:
    """The bot token: config.toml, the environment, the Windows user environment, the old C# project (keys.py).
    Never logged."""
    return keys.get("discord_token")


def token_source() -> str | None:
    """Where the token would come from (for the dashboard) - the place, never the token."""
    return keys.source("discord_token")


# ── one copy at a time ──────────────────────────────────────────────────
class InstanceLock:
    """An OS lock on campaigns/.run/bot.lock (one byte of it). Released by the OS if the process dies."""

    def __init__(self, folder: Path | None = None):
        self.path = run_dir(folder) / LOCK
        self.fh = None

    def acquire(self) -> bool:
        fh = open(self.path, "a+b")
        try:
            fh.seek(0)
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fh.close()
            return False
        self.fh = fh
        return True

    def release(self) -> None:
        if self.fh is None:
            return
        try:
            self.fh.seek(0)
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        self.fh.close()
        self.fh = None


def running(folder: Path | None = None) -> bool:
    """Is a bot up? Try its lock and hand it straight back."""
    lk = InstanceLock(folder)
    if lk.acquire():
        lk.release()
        return False
    return True


def request_stop(folder: Path | None = None, why: str = "stop") -> None:
    write_json(run_dir(folder) / CONTROL, {"cmd": "stop", "why": why, "at": time.time()})


# ── inside the bot ──────────────────────────────────────────────────────
class Runtime:
    """Attached to the RPBot: writes the heartbeat, watches for a stop request, and drains the tables on the way out."""

    def __init__(self, bot, folder: Path | None = None):
        self.bot = bot
        self.dir = run_dir(folder)
        self.started = time.time()
        self.stamp = code_stamp()
        self.state, self.detail = "connecting", ""
        self.errors, self.last_error = 0, None
        self.tasks: list[asyncio.Task] = []

    def start(self) -> None:
        loop = asyncio.get_running_loop()
        (self.dir / CONTROL).unlink(missing_ok=True)          # a request from before we started isn't for us
        self.tasks = [loop.create_task(self._beat()), loop.create_task(self._watch())]

    def set(self, state: str, detail: str = "") -> None:
        self.state, self.detail = state, detail
        self.write()

    def error(self, what: str) -> None:
        self.errors += 1
        self.last_error = {"at": time.time(), "what": what[:300]}

    def snapshot(self) -> dict:
        bot = self.bot
        lat = getattr(bot, "latency", None)
        tables = []
        for cid, t in list(getattr(bot, "tables", {}).items()):
            ch = bot.get_channel(cid)
            d = t.director
            u = t.game._llm.usage if getattr(t.game, "_llm", None) is not None else None
            tables.append({
                "channel_id": str(cid), "channel": getattr(ch, "name", None),
                "guild": getattr(getattr(ch, "guild", None), "name", None),
                "campaign": t.game.path.stem, "busy": bool(d.resolving),
                "queued": [h for h, _ in d.queue], "waiting_on": sorted(d.waiting_on()) if d.queue else [],
                "expected": sorted(t.expected), "active": dict(t.last_active),
                "active_now": sorted(t.active_players()) if hasattr(t, "active_players") else [],
                "seated": len(t.handles),
                "chargens": len(t.chargens),
                "spend": round(getattr(u, "total", 0.0), 4) if u else 0.0,
                "spend_by_purpose": dict(getattr(u, "by_purpose", {})) if u else {},
            })
        return {
            "pid": os.getpid(), "state": self.state, "detail": self.detail, "started": self.started,
            "beat": time.time(), "code": self.stamp,
            "user": str(bot.user) if getattr(bot, "user", None) else None,
            "latency_ms": round(lat * 1000) if isinstance(lat, float) and math.isfinite(lat) else None,
            "guilds": [{"id": str(g.id), "name": g.name, "members": g.member_count} for g in getattr(bot, "guilds", [])],
            "bindings": dict(getattr(bot, "bindings", {})), "tables": tables,
            "channels": {key: {"name": getattr(ch, "name", None), "guild": getattr(getattr(ch, "guild", None), "name", None)}
                         for key in getattr(bot, "bindings", {}) for ch in [bot.get_channel(int(key))] if ch},
            "errors": self.errors, "last_error": self.last_error, "args": sys.argv[1:],
        }

    def write(self) -> None:
        try:
            write_json(self.dir / STATUS, self.snapshot())
        except Exception as exc:                      # a heartbeat must never take the bot down
            print(f"[runtime] status not written: {exc}", flush=True)

    async def _beat(self) -> None:
        while True:
            self.write()
            await asyncio.sleep(BEAT)

    async def _watch(self) -> None:
        path = self.dir / CONTROL
        while True:
            await asyncio.sleep(1.0)
            req = read_json(path)
            if not req:
                continue
            path.unlink(missing_ok=True)
            if req.get("at", 0) < self.started - 2:
                continue
            if req.get("cmd") == "stop":
                print(f"[runtime] {req.get('why', 'stop')} requested", flush=True)
                await self.stop(req.get("why", "stop"))
                return

    async def stop(self, why: str = "stop") -> None:
        """Finish what's in flight, tell anyone whose actions get dropped, close every table, then the client."""
        bot = self.bot
        bot.stopping = True
        tables = list(getattr(bot, "tables", {}).items())
        loop = asyncio.get_running_loop()

        async def until(cond, seconds: float) -> bool:
            end = loop.time() + seconds
            while not cond():
                if loop.time() > end:
                    return False
                await asyncio.sleep(0.5)
            return True

        busy = [f"#{getattr(bot.get_channel(cid), 'name', cid)}" for cid, t in tables if t.director.resolving]
        if busy:
            self.set("stopping", f"finishing the turn in {', '.join(busy)}")
            await until(lambda: not any(t.director.resolving for _, t in tables), WAITS["turn"])
        for cid, t in tables:
            dropped = list(dict.fromkeys(h for h, _ in t.director.queue))      # (in the order they posted)
            t.director.queue.clear()
            if t.director._task and not t.director._task.done():
                t.director._task.cancel()
            if dropped:
                names = [((await t.run(t.game.character_for, h)) or {}).get("name", h) for h in dropped]
                back = "back in a minute" if why == "restart" else "going offline for now"
                try:
                    await t.ch.send(f"🔧 The GM is {back} - {', '.join(names)}: your last action wasn't resolved, "
                                    "post it again when I'm back.")
                except Exception:
                    pass
        self.set("stopping", "letting the offscreen world finish")
        await until(lambda: all(t.world_task is None or t.world_task.done() for _, t in tables), WAITS["world"])
        self.set("stopping", "posting what's left")
        for _, t in tables:
            try:
                await asyncio.wait_for(t.drain(), WAITS["posts"])
            except (asyncio.TimeoutError, Exception):
                pass
        painting = [t for _, t in tables if getattr(t.game.art, "_pool", None) is not None]
        if painting:
            self.set("stopping", "waiting for portraits being painted")

            def finish_art():
                for t in painting:
                    t.game.art._pool.shutdown(wait=True, cancel_futures=True)
            try:
                await asyncio.wait_for(loop.run_in_executor(None, finish_art), WAITS["art"])
            except (asyncio.TimeoutError, Exception):
                pass
        self.set("stopping", "closing the tables")
        for cid, t in tables:
            try:
                await t.close()
            except Exception as exc:
                print(f"[runtime] closing {t.game.path.stem}: {exc}", flush=True)
            bot.tables.pop(cid, None)
        self.set("stopped", why)
        for task in self.tasks:
            if task is not asyncio.current_task():
                task.cancel()
        await bot.close()
