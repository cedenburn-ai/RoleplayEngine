"""Discord components preview (`!menus`): buttons, a dropdown and a pop-up form built from the new modal
components (Label + text inputs, a radio group and select menus inside the modal). Every answer is ephemeral -
only the person who clicked sees it. This is the UI planned for slash commands, character creation, confirmations
and shops; nothing here touches a game yet.
"""
from __future__ import annotations

import random

import discord

from .. import chargen
from ..chargen import CATALOG

PRONOUNS = ("she/her", "he/him", "they/them")
SHOP_DEMO = ("heavy-pistol", "armored-jacket", "smartlink", "medkit", "fly-spy", "he-grenade")


def _role_options() -> list[discord.SelectOption]:
    return [discord.SelectOption(label=name, value=key, description=what[:100], emoji=icon)
            for key, (icon, name, what) in chargen.ROLE_SHOW.items()]


def _meta_options() -> list[discord.SelectOption]:
    return [discord.SelectOption(label=m.title(), value=m, description=v["blurb"][:100], emoji=chargen.META_SHOW[m])
            for m, v in chargen.METATYPES.items()]


class RunnerForm(discord.ui.Modal):
    """One pop-up instead of ten DM steps: name, pronouns, metatype, role, concept."""

    def __init__(self):
        super().__init__(title="Build a runner", custom_id="menus:form")
        self.name = discord.ui.TextInput(placeholder="A street name, e.g. Glitch", max_length=24, custom_id="name")
        self.pronouns = discord.ui.RadioGroup(custom_id="pronouns", options=[
            discord.RadioGroupOption(label=p, value=p, default=p == "they/them") for p in PRONOUNS])
        self.meta = discord.ui.Select(custom_id="meta", placeholder="Human, elf, dwarf, ork or troll",
                                      options=_meta_options())
        self.role = discord.ui.Select(custom_id="role", placeholder="What you do on a run", options=_role_options())
        self.concept = discord.ui.TextInput(style=discord.TextStyle.paragraph, required=False, max_length=400,
                                            custom_id="concept",
                                            placeholder="ork rigger who drives getaway for the Yakuza")
        self.add_item(discord.ui.Label(text="Name", component=self.name))
        self.add_item(discord.ui.Label(text="Pronouns", component=self.pronouns))
        self.add_item(discord.ui.Label(text="Metatype", description="what you are", component=self.meta))
        self.add_item(discord.ui.Label(text="Role", description="what you do on a run", component=self.role))
        self.add_item(discord.ui.Label(text="Concept (optional)", description="the GM builds the rest from this",
                                       component=self.concept))

    async def on_submit(self, interaction: discord.Interaction) -> None:
        meta, role = self.meta.values[0], self.role.values[0]
        icon, rname, what = chargen.ROLE_SHOW[role]
        e = discord.Embed(title=f"🧬 {self.name.value}", color=0x8E44AD, description=(
            f"{chargen.META_SHOW[meta]} **{meta.title()}** {icon} **{rname}** · {self.pronouns.value}\n"
            f"*{self.concept.value or 'no concept - the GM would surprise you'}*\n\n"
            "In the real thing the GM would now propose the whole build right here, with buttons for "
            "**Attributes**, **Skills**, **Gear** (each its own little form) and **Done**."))
        e.set_footer(text="Only you can see this.")
        await interaction.response.send_message(embed=e, ephemeral=True)


class ShopPick(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)
        sel = discord.ui.Select(placeholder="Pick up to 3 things to buy", min_values=1, max_values=3, options=[
            discord.SelectOption(label=CATALOG[k]["name"], value=k, description=f"{CATALOG[k]['cost']:,}¥ · "
                                 f"{CATALOG[k]['cat']}") for k in SHOP_DEMO])
        sel.callback = self.picked
        self.sel = sel
        self.add_item(sel)

    async def picked(self, interaction: discord.Interaction) -> None:
        total = sum(CATALOG[k]["cost"] for k in self.sel.values)
        names = ", ".join(CATALOG[k]["name"] for k in self.sel.values)
        await interaction.response.send_message(
            f"🛒 You'd buy **{names}** for **{total:,}¥**. In the real thing this charges your nuyen and the items "
            "land on your sheet.", ephemeral=True)


class MenusDemo(discord.ui.View):
    """Persistent: every item has a custom_id and no timeout, so the buttons survive bot restarts."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.select(custom_id="menus:role", placeholder="Read about a role…", options=_role_options(), row=0)
    async def role(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        icon, name, what = chargen.ROLE_SHOW[select.values[0]]
        await interaction.response.send_message(f"{icon} **{name}** - {what}", ephemeral=True)

    @discord.ui.button(label="Build a runner", emoji="📝", style=discord.ButtonStyle.primary, custom_id="menus:form",
                       row=1)
    async def form(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(RunnerForm())

    @discord.ui.button(label="Shop", emoji="🛒", style=discord.ButtonStyle.secondary, custom_id="menus:shop", row=1)
    async def shop(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_message("**Kaz's back room** has a few things under the counter:",
                                                view=ShopPick(), ephemeral=True)

    @discord.ui.button(label="Roll 8 dice", emoji="🎲", style=discord.ButtonStyle.secondary, custom_id="menus:roll",
                       row=1)
    async def roll(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        dice = sorted((random.randint(1, 6) for _ in range(8)), reverse=True)
        hits = sum(d >= 5 for d in dice)
        await interaction.response.send_message(f"🎲 {' '.join(map(str, dice))} → **{hits} hit{'s' if hits != 1 else ''}**",
                                                ephemeral=True)

    @discord.ui.button(label="Hand over Razor", emoji="✅", style=discord.ButtonStyle.success, custom_id="menus:yes",
                       row=2)
    async def yes(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_message("✅ That's how seat requests and `!rp restart` would ask - one click, "
                                                "and only the right person's click counts.", ephemeral=True)

    @discord.ui.button(label="Keep playing", emoji="✖️", style=discord.ButtonStyle.danger, custom_id="menus:no", row=2)
    async def no(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_message("✖️ Kept. (Replies like this are *ephemeral* - only you see them, "
                                                "so personal stuff can stay in the channel instead of DMs.)",
                                                ephemeral=True)


def demo_embed() -> discord.Embed:
    return discord.Embed(title="🧪 Interactive menus - a preview", color=0x5865F2, description=(
        "Try these - every answer is private to whoever clicks:\n"
        "• **Dropdown** - read about each role\n"
        "• **📝 Build a runner** - a pop-up form: name, pronouns (radio buttons), metatype and role (dropdowns), "
        "concept\n"
        "• **🛒 Shop** - a private multi-select shopping list\n"
        "• **🎲 Roll** - a private dice roll\n"
        "• **✅ / ✖️** - how confirmations and seat requests would look\n\n"
        "-# Nothing here changes the game yet - it's a look at the UI before we build it in for real."))


async def post(channel) -> None:
    await channel.send(embed=demo_embed(), view=MenusDemo())
