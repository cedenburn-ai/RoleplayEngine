"""Coloured text for Discord: ```ansi code blocks (DESIGN.md §5a).

Discord colours a code block tagged `ansi` with terminal escape codes - on desktop; the phone apps may show it plain.
Two things use it, both switched off together by the owner's `!colors off`:
- roll cards: the engine's plain card lines are coloured here, as they're posted - the hits in green, ones in red, the
  outcome by how it went - so the console, the logs and the tests keep the plain text;
- the help screen: commands in green, what you type after them in cyan, headings in yellow, each item wrapped with a
  hanging indent to the width of a Discord card.
"""
from __future__ import annotations

import re

ESC = "\x1b"
GRAY, RED, GREEN, YELLOW, BLUE, PINK, CYAN, WHITE = "0;30", "0;31", "0;32", "0;33", "0;34", "0;35", "0;36", "0;37"
BOLD_RED, BOLD_GREEN, BOLD_YELLOW, BOLD_WHITE = "1;31", "1;32", "1;33", "1;37"

TAGS = {"[ROLL]": "1;36", "[DAMAGE]": "1;31", "[HEAL]": "1;32", "[GEAR]": "1;33", "[NUYEN]": "1;33",
        "[KARMA]": "1;35", "[RULING]": "1;34", "[MATRIX]": "1;32", "[FIX]": "1;33", "[FIGHT]": "1;31",
        "[INITIATIVE]": "1;35", "[SHOP]": "1;32"}
LABELS = ("Why", "Team", "Pool", "Roll", "vs", "Edge", "Attack", "Defend", "Soak", "Throw", "Blast", "Ammo", "Cast",
          "Call", "Drain", "Fade", "Fading", "Damage", "Resist",     # ('Fading NS' was never coloured)
          "Action", "Strike", "Spell", "Thrown", "Initiative",
          "Pools", "Ram", "Barrier",                                 # (control_drone's comparison; the crash card)
          "Smoke", "Gas", "Cloud")                                   # (a smoke or gas grenade's card)
GOOD = {"SUCCESS", "HIT", "FOUND", "COMPILED", "ANSWERS", "CRASHED"}       # (CRASHED: the IC derezzed)
BAD = {"FAILURE", "FAILED", "MISS", "CRITICAL", "TRACED", "DUMPSHOCK", "STUCK", "CONVERGENCE", "HOST"}

HEAD = re.compile(r"^(\[[A-Z]+\])(.*)$")
LABEL = re.compile(r"^(  )(" + "|".join(LABELS) + r")\b( +)(.*)$")
OUTCOME = re.compile(r"^(  )([A-Z]{3,}(?: [A-Z]{3,})?)(?=[\s:(.]|$)(.*)$")
DICE = r"[1-6](?: [1-6])*(?: \+ [1-6](?: [1-6])* \(sixes exploded\))?"
TOKEN = re.compile(
    rf"(?P<dice>(?:(?<=-> )|^){DICE}(?= ->))"
    r"|(?P<crit>CRITICAL GLITCH)"
    r"|(?P<glitch>\bGLITCH\b)"
    r"|(?P<hits>\b\d+ hits?\b)"
    r"|(?P<pool>= \d+d6)"
    r"|(?P<minus> - [A-Za-z][^+=\-\n]*? \d+(?= [+=-]| ->|$))"
    r"|(?P<takes>\btakes \d+ (?:physical|stun)\b)"
    r"|(?P<bonus>\+\d+ dice? to\b)"
    r"|(?P<note>\[[^\]\n]*\]$)")


def paint(text: str, code: str | None) -> str:
    return f"{ESC}[{code}m{text}{ESC}[0m" if code and text else text


def _dice(faces: str) -> str:
    """"6 6 5 4 3 1" -> the hits green, the misses gray, the ones red - a run each (the engine sorts them high to low),
    so a card stays about the size it was."""
    runs: list[tuple[str, list[str]]] = []
    for d in faces.split():
        code = BOLD_GREEN if d in "56" else RED if d == "1" else GRAY
        if runs and runs[-1][0] == code:
            runs[-1][1].append(d)
        else:
            runs.append((code, [d]))
    return " ".join(paint(" ".join(ds), code) for code, ds in runs)


def _content(s: str) -> str:
    def one(m: re.Match) -> str:
        k, t = m.lastgroup, m.group(0)
        if k == "dice":
            base, _, extra = t.replace(" (sixes exploded)", "").partition(" + ")
            return _dice(base) + (" + " + _dice(extra) + paint(" (sixes exploded)", PINK) if extra else "")
        return paint(t, {"crit": BOLD_RED, "glitch": BOLD_YELLOW, "hits": BOLD_WHITE, "pool": BOLD_WHITE,
                         "minus": RED, "takes": BOLD_RED, "note": GRAY, "bonus": BOLD_GREEN}[k])
    return TOKEN.sub(one, s)


def card_line(line: str) -> str:
    """One line of a roll card, coloured."""
    m = HEAD.match(line)
    if m:
        return paint(m.group(1), TAGS.get(m.group(1), BOLD_WHITE)) + paint(m.group(2), BOLD_WHITE)
    m = LABEL.match(line)
    if m:
        return m.group(1) + paint(m.group(2), PINK if m.group(2) == "Edge" else GRAY) + m.group(3) + _content(m.group(4))
    m = OUTCOME.match(line)
    if m:
        word = m.group(2)
        first = word.split()[0]
        code = (BOLD_RED if first in BAD or word == "CRITICAL GLITCH" else BOLD_GREEN if first in GOOD
                else BOLD_YELLOW)
        return m.group(1) + paint(word, code) + _content(m.group(3))
    return _content(line)


def card_block(text: str) -> str:
    return "\n".join(card_line(x) for x in text.split("\n"))


# ── the help screen ─────────────────────────────────────────────────────
SPAN = re.compile(r"`([^`]+)`|\*\*([^*]+)\*\*|\*([^*]+)\*")
ARG = re.compile(r"(<[^>]+>|\[[^\]]+\])")
WIDTH = 50                     # a Discord card's code block fits ~54 monospace characters on desktop


def segments(md: str) -> list[tuple[str, str | None]]:
    """Discord markdown -> (text, colour) runs: `commands` green with <args> cyan, **bold** yellow, *italics* white."""
    out: list[tuple[str, str | None]] = []
    at = 0
    for m in SPAN.finditer(md):
        if m.start() > at:
            out.append((md[at:m.start()], None))
        if m.group(1) is not None:
            for i, part in enumerate(ARG.split(m.group(1))):
                if part:
                    out.append((part, CYAN if i % 2 else BOLD_GREEN))
        elif m.group(2) is not None:
            out.append((m.group(2), BOLD_YELLOW))
        else:
            out.append((m.group(3), WHITE))
        at = m.end()
    if at < len(md):
        out.append((md[at:], None))
    return out


def wrap(segs: list[tuple[str, str | None]], width: int = WIDTH, first: str = "• ", indent: str = "  ") -> list[str]:
    """Word-wrap coloured runs to `width` visible characters, the second line on indented."""
    words: list[list[tuple[str, str | None]]] = []      # a word can span runs ("`!join`," is one word)
    gap = True
    for text, code in segs:
        for piece in re.findall(r"\s+|\S+", text):
            if piece.isspace():
                gap = True
            elif gap or not words:
                words.append([(piece, code)])
                gap = False
            else:
                words[-1].append((piece, code))
    lines: list[list[tuple[str, str | None]]] = [[(first, GRAY)]] if first else [[]]
    used = len(first)
    for w in words:
        n = sum(len(t) for t, _ in w)
        fresh = used == len(first if len(lines) == 1 else indent)
        if not fresh and used + 1 + n > width:
            lines.append([(indent, None)])
            used, fresh = len(indent), True
        if not fresh:
            lines[-1].append((" ", None))
            used += 1
        lines[-1].extend(w)
        used += n
    return ["".join(_merged(line)) for line in lines]


def _merged(line):
    run, code = "", None
    for t, c in line:
        if c != code and run:
            yield paint(run, code)
            run = ""
        run, code = run + t, c
    if run:
        yield paint(run, code)


def help_block(lines: list[str], intro: bool = False) -> list[str]:
    """A help section's lines (Discord markdown, items joined with "  ·  ") -> coloured, wrapped lines - one item
    each. An intro line (the first in a section that isn't a command) has no bullet."""
    out: list[str] = []
    for i, line in enumerate(lines):
        if i == 0 and intro:
            out += wrap(segments(line), first="", indent="")
            continue
        for item in line.split("  ·  "):
            out += wrap(segments(item.strip()))
    return out
