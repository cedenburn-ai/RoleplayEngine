"""One campaign bound to one Discord channel.

All game access runs on a single worker thread (the engine and SQLite are synchronous), so turns,
commands and lookups never interleave. Engine output (roll cards) and finished art arrive from
other threads and are posted in order through an outbox. The Discord specifics live behind the
small `Channel` protocol, so this whole layer is testable with a fake channel.
"""
from __future__ import annotations

import asyncio
import difflib
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Awaitable, Callable, Protocol

from .. import (battlemap, chargen, charledger, charsheet, chronicle, divider, encounters, maps, netmap, recap,
               rosterart, rulings, shops)
from ..engine import clock
from ..engine.ledger import LedgerError
from ..engine.rules import sr_lite
from ..game import Game
from .render import (EMBED_LIMIT, ITEM, LOCATION, LOCATION_STRIP, NARRATION, SPEAKER_MAJOR, SPEAKER_MINOR,
                     SPEAKER_PC, card_messages, chunks, classify, notice_text, parse_story, thumbnail)
from . import ansi
from .chargen_flow import Chargen, load as load_draft
from .table import TableDirector
from ..dm import aside, speakers, spoilers
from .. import flags, narrative
from .. import newparty

NARRATION_COLOR = NARRATION
ACTIVE_WINDOW = 600           # seconds: a player seen this recently is "at the table" for the GM's spotlight
WHISPER = 0x2C3E50            # a whisper's narration: dark slate, so it never reads like the table's story
ART_STYLE = {"npc": ("👤", SPEAKER_MAJOR), "pc": ("🎲", SPEAKER_PC), "location": ("📍", LOCATION), "item": ("✨", ITEM)}

HELP_SECTIONS = [
    ("⚡ Slash commands", 0x5865F2, [
        "Type `/` for buttons-and-forms versions of the main commands - answers about you are private:",
        "`/newchar` build a runner (a form, then a private review)  ·  `/pregen` let the GM roll one up",
        "`/sheet` your sheet  ·  `/shop` buy from where you stand  ·  `/askgm` rules questions  ·  `/whisper` do "
        "something on the quiet",
        "`/join` · `/checkout` · `/advance` (with autocomplete)  ·  `/party` · `/dossier` · `/begin` · `/recap` · "
        "`/roles` · `/help`"]),
    ("🎮 Playing", 0x1ABC9C, [
        "Just type what your character says and does - the GM answers when everyone at the table has acted. "
        "Once someone acts, the others get 30 seconds (more while they're typing) - a turn card counts it down.",
        "`!go` - resolve the turn now  ·  `!wait` - I need more time  ·  `!pass` - I sit this turn out "
        "(or the card's ⏩ ✋ 💤 buttons)",
        "**Edge:** say it in your post, on any roll - *push it* / *reroll 6s* (+Edge dice, 6s explode, the only "
        "way past a spell's Force) · *reroll my misses* (a second chance, spent now - it never raises the Force) · "
        "*Edge if I miss* (the same, only if the roll falls short). Burn Edge to survive a killing blow. "
        "It refills every session.",
        "**Fights:** every 10 of your Initiative is one action a round - an attack, a spell or a grenade (the "
        "[FIGHT] and [INITIATIVE] cards show everyone's) · *splits his katana between Fenn and Garvey* (one action, "
        "the dice split) · *throws two knives* · *parries* / *blocks* / *dodges* a melee blow (-5 Initiative) · "
        "*full defense* (+Willpower all round, -10) · `!combathelp` - the whole of a round, in plain words",
        "`!ooc ...` or `((...))` - table talk the GM ignores",
        "**Hey DM ...** (or `!gm ...`) - talk to the GM out of character: questions, corrections, \"skip ahead\" - it "
        "answers without moving the story",
        "`!undo` - take back the last turn: everyone else at the table has to agree (✅ / `!yes`). Dice, damage, "
        "Overwatch, money and memories all go back; again for the turn before (up to 10). The old messages stay "
        "in the channel, and a GM's in-story retcon doesn't reset any numbers - `!undo` does",
        "`!reportbug <what went wrong>` (or `/reportbug`) - tell the developers; this turn goes with it",
        "`!stuck [what's going in circles]` - the story's looping? The engine reads the last turns and the next one "
        "breaks the loop (no turn spent)",
        "`!companion <name>` - the GM plays them (a crew companion)  ·  `!park <name>` - they step out of the "
        "story  ·  `!join <name>` - take one back",
        "`!afk` / `!back` - step away (the GM plays your character, turns stop waiting on you), come back - "
        "post while away and you'll be asked if you're back",
        "**Whisper:** DM me what your character does on the quiet - only whoever notices will know",
        "`!askgm <question>` - rules, your dice pools, what you remember or what was said, how far it is (answered "
        "by DM)"]),
    ("🧬 Your character", 0x8E44AD, [
        "`!newchar` - build a runner with the GM, step by step in your DMs",
        "`!pregen [concept]` - let the GM roll one up for you  ·  `!roles` - what you can play (roles and metatypes)",
        "`!newchar <Name> <archetype>` - instant ({archetypes})",
        "`!join <character>` - play a PC, or step into an NPC in the scene  ·  `!leave` hands them back",
        "`!characterledger` (`!cl`) - runners that travel between worlds: `checkout <name>`, `return`, `save`, "
        "`share <name>`, or a name to see their file",
        "Someone else's character? `!join` asks them first - ✅ / `!yes` hands it over, ❌ / `!no` keeps it",
        "`!sheet` (or `!cs`) - your sheet as pictures, by DM  ·  `!sheet text` the quick text version",
        "`!advance <#>` - spend karma (the numbers are on your sheet)  ·  `!karma` - everyone's karma",
        "`!shop` - what's for sale where you are, or the dealer on the line (the GM opens shops in the story)  ·  "
        "`!shop <name>` another shop open to you  ·  `!buy <#>` buy it from the shop you last looked at  ·  "
        "`!buy <#> onto <drone>` straight onto your drone  ·  `!buy <#> from <shop>` - delivered gear shows when it "
        "arrives"]),
    ("🗺️ The table", 0x3498DB, [
        "`!party` - the whole crew for the table: health, Edge, armor, gear, spells held, where everyone is",
        "`!dossier <name>` - put the crew's file on someone on the table (`!dossier` lists who there's a file on)",
        "`!recap` - previously on, with NPC dossiers  ·  `!chronicle` - the story so far as your character lived it",
        "`!map` the metroplex  ·  `!map here` close up  ·  `!net` your decker's network map  ·  `!matrixhelp` what "
        "a decker can do in a host",
        "`!who` who's here and who plays them  ·  `!scene`  ·  `!time`  ·  `!art <name>` see someone's picture",
        "`!battle` - the battlefield (fights get one live map that redraws each round)",
        "`!rulings` the house rules  ·  `!ruling add <text>`  ·  `!ruling veto R#` object to one  ·  "
        "`!ruling <question>` asks the GM to rule  ·  `!rulings review` the ones that could go",
        "`!narrative add <where you want the story to go>` - steer the GM out of character; it stands until it lands  "
        "·  `!narrative` lists them  ·  `!narrative remove D#`"]),
    ("🎬 Starting a game", 0xF1C40F, [
        "`!rp start <world>` - play a world in this channel: `rage` and `demo` are ready-made, any other name "
        "starts a blank one",
        "Then everyone makes a runner (`!newchar`, `!pregen` or `!join`), and `!begin` opens the first scene - add "
        "what kind of run you want: `!begin a heist on a Renraku data vault`",
        "`!rp restart` - archive this world and start it over (owner; asks you to confirm)",
        "`!rp newparty [3 weeks] [| how the old story ended]` - a new crew in the same world: the old crew stay on as "
        "the GM's characters with goals of their own, the story skips ahead and the world catches up (owner; asks you "
        "to confirm; a backup first - `!rp newparty undo` takes it back before the new crew's first turn)",
        "`!rp stop` - unbind this channel (the world is kept)  ·  `!rp status`"]),
    ("🛠️ GM controls (campaign owner / server managers)", 0x95A5A6, [
        "`!karma <character> +N [reason]` - award karma",
        "`!dmplay <name>` the GM plays them  ·  `!idle <name>` they sit quietly  ·  `!companions on|off` the GM "
        "plays an `!afk` player's character",
        "`!undo` - take back the last turn (at once; a player's `!undo` asks the table)",
        "`!gmmodel opus|sonnet|haiku|fable`  ·  `!gmeffort low|medium|high|xhigh|max`",
        "`!difficulty story|easy|normal|hard|brutal`  ·  or `!difficulty threshold +1` / `opposition -1` - one "
        "dial for every roll, the Matrix's hosts and IC too",
        "`!timer wait|cap|grace <seconds>`  ·  `!time evening` / `!time tomorrow morning` / "
        "`!time 3 days later, evening` / `!time 6 months later`",
        "`!art on|off`  ·  `!art redo <name> [change]`  ·  `!voices on|off` NPC voices",
        "`!dividers picture|line|off` - the strip between turns",
        "`!colors on|off` - coloured roll cards and help (off if a phone shows codes like [1;32m)",
        "`!rename <who> = <new name>` - someone's real name came out (the old one stays as an alias)",
        "`!map gm` every place and who's where (by DM)  ·  `!map restyle` repaint the map",
        "`!world` what NPCs and factions are up to offscreen (by DM - spoilers)  ·  `!world on|off`",
        "`!reconcile` - read the whole story back now and rebuild the canon (it also runs every ~20 turns)  ·  "
        "`!canon` the reconciled record (by DM - spoilers)  ·  `!rulings tidy` drop the rulings the review says can go",
        "`!frame` who everyone in the scene is now and where they stand with each other (by DM - spoilers)  ·  "
        "`!frame now` reframe the scene",
        "`!doubts` where the record doesn't add up: the open doubts the GM is checking, and how the last ones were "
        "settled (by DM - spoilers)",
        "`!seed <name>` - read a story from seeds/ into the world (or attach .md / .txt files, or paste it): a "
        "spoiler-free preview, then `!seed confirm` - the crew's `!begin` opens it  ·  `!seed preview full` (by DM)",
        "`!chronicle <anyone>` - the story as that NPC lived it: what they saw, did offscreen, heard and felt (by DM)",
        "`!backup` - zip every world, the ledger and the art now (it also runs daily)",
        "`!pov <npc>` (by DM)  ·  `!minds`  ·  `!merge <keep> <drop>`  ·  `!graph` (browser on the host)  ·  "
        "`!settings`  ·  `!cost`"]),
]


def matrix_help_cards(color: bool = False) -> list[dict]:
    """!matrixhelp: what a decker can actually do in a host, in plain words (matrix.HELP)."""
    from ..engine.rules import matrix as _m
    if not color:
        return [{"title": "🕸️ In the Matrix", "color": 0x50DCFF,
                 "description": "\n".join(("• " if i else "") + line for i, line in enumerate(_m.HELP))}]
    rows = ansi.help_block(_m.HELP, intro=True)
    return [{"title": "🕸️ In the Matrix", "color": 0x50DCFF, "description": "```ansi\n" + "\n".join(rows) + "\n```"}]


def combat_help_cards(color: bool = False) -> list[dict]:
    """!combathelp: what a fight round holds - Initiative, actions, splits, throws, defenses, finishing (encounters.HELP)."""
    if not color:
        return [{"title": "⚔️ In a fight", "color": 0xFF5A5A,
                 "description": "\n".join(("• " if i else "") + line for i, line in enumerate(encounters.HELP))}]
    rows = ansi.help_block(encounters.HELP, intro=True)
    parts, buf = [], []
    for row in rows:                                     # (longer than the Matrix card: split across cards if needed)
        if buf and len("\n".join(buf + [row])) > EMBED_LIMIT - 20:
            parts.append(buf)
            buf = []
        buf.append(row)
    parts.append(buf)
    return [{"title": "⚔️ In a fight" + (f" ({k + 1}/{len(parts)})" if len(parts) > 1 else ""), "color": 0xFF5A5A,
             "description": "```ansi\n" + "\n".join(p) + "\n```"} for k, p in enumerate(parts)]


def help_cards(sections=None, color: bool = False) -> list[dict]:
    """The help screen, a card per section. color: each section is one coloured block (ansi.py) - commands green,
    what you type cyan - split across cards if it's too long for one."""
    archetypes = ", ".join(sr_lite.ARCHETYPES)
    out = []
    for title, col, lines in HELP_SECTIONS:
        if sections is not None and title not in sections:
            continue
        lines = [line.format(archetypes=archetypes) for line in lines]
        if not color:
            out.append({"title": title, "color": col,
                        "description": "\n".join(f"• {line}" if i or not line.startswith("Just") else line
                                                 for i, line in enumerate(lines))})
            continue
        parts, buf = [], []
        for row in ansi.help_block(lines, intro=not lines[0].startswith(("`", "**"))):
            if buf and len("\n".join(buf + [row])) > EMBED_LIMIT - 20:
                parts.append(buf)
                buf = []
            buf.append(row)
        parts.append(buf)
        out += [{"title": title if k == 0 else f"{title} (more)", "color": col,
                 "description": "```ansi\n" + "\n".join(p) + "\n```"} for k, p in enumerate(parts)]
    return out


class Channel(Protocol):
    async def send(self, text: str | None = None, *, title: str | None = None, description: str | None = None,
                   color: int | None = None, footer: str | None = None, image: str | None = None) -> None: ...

    async def send_cards(self, cards: list[dict]) -> None:
        """Embeds batched into messages. Card keys: title, description, color, footer, author,
        thumbnail (local path), image (local path)."""

    def typing(self): ...

    async def dm(self, user_id: str, text: str) -> None: ...

    async def dm_cards(self, user_id: str, cards: list[dict]) -> None: ...


React = Callable[[str], Awaitable[None]]
def _sheet_kind(cmd: str, rest: str) -> tuple[str, str]:
    """`!sheet` is the picture sheet, the same as `/sheet` (it used to be the text one, and the two names for one
    thing gave different answers); `!sheet text` is the quick text version."""
    if cmd != "sheet":
        return cmd, rest
    return ("textsheet", rest[4:].strip()) if rest.lower().split()[:1] == ["text"] else ("charactersheet", rest)

SLOW = 1.5                                       # a command still working after this gets a ⏳ (it's waiting on the GM)
WORK_EVERY = 2.5                                 # the work card redraws at most this often (Discord's edit budget)


def _utc(stamp: str | None) -> float:
    """SQLite's CURRENT_TIMESTAMP (UTC) -> unix time."""
    from datetime import datetime, timezone
    try:
        return datetime.strptime(stamp[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except (TypeError, ValueError):
        return 0.0


def _expiry(url: str) -> int:
    """Discord's signed attachment links carry their expiry (hex unix time) in ?ex=."""
    from urllib.parse import parse_qs, urlparse
    try:
        return int(parse_qs(urlparse(url).query)["ex"][0], 16)
    except (KeyError, ValueError, IndexError):
        return int(time.time()) + 20 * 3600


# Every command, for "did you mean" - and the names people naturally reach for.
COMMANDS = ("help", "ooc", "go", "wait", "pass", "join", "yes", "no", "newchar", "pregen", "roles", "begin", "characterledger", "backup",
            "shop", "buy", "menus", "chronicle", "battle", "leave",
            "afk",
            "back", "dmplay",
            "idle", "companions",
            "map", "net", "matrixhelp", "combathelp", "stuck",
            "rulings", "ruling", "reconcile", "canon", "narrative", "frame", "doubts",
            "voices", "dividers", "colors", "advance", "karma", "charactersheet", "sheet", "party", "dossier", "askdm", "who",
            "scene", "recap",
            "time",
            "settings", "gmmodel", "gmeffort", "difficulty", "timer", "undo", "pov", "world", "minds", "merge", "art",
            "graph", "cost", "rename", "companion", "park", "gm", "reportbug")
COMMANDS += ("seed",)                            # (!seed: a story read into the world - seed.py)
ALIASES = {"classes": "roles", "races": "roles", "metatypes": "roles", "archetypes": "roles", "class": "roles",
           "crew": "party", "team": "party", "squad": "party", "group": "party",
           "colours": "colors", "color": "colors", "colour": "colors", "dm": "gm",
           "fighthelp": "combathelp", "combat": "combathelp", "cbhelp": "combathelp", "initiativehelp": "combathelp",
           "mhelp": "matrixhelp", "nethelp": "matrixhelp", "deckhelp": "matrixhelp", "hackhelp": "matrixhelp",
           "loop": "stuck", "looping": "stuck", "circles": "stuck",
           "narratives": "narrative", "steer": "narrative", "direction": "narrative", "directions": "narrative",
           "doubt": "doubts", "continuity": "doubts", "inconsistencies": "doubts",
           "bug": "reportbug", "bugreport": "reportbug", "report": "reportbug",
           "dossiers": "dossier", "file": "dossier", "files": "dossier", "intel": "dossier",
           "cl": "characterledger", "roster": "characterledger", "stable": "characterledger",
           "checkout": "characterledger", "rules": "rulings", "houserules": "rulings", "askgm": "askdm", "ask": "askdm", "q": "askdm", "cs": "charactersheet", "character": "charactersheet",
           "char": "charactersheet", "gmplay": "dmplay", "levelup": "advance", "spend": "advance", "commands": "help"}


class CampaignTable:
    def __init__(self, game: Game, channel: Channel, owner_id: str, timers: dict | None = None):
        self.game, self.ch, self.owner_id = game, channel, owner_id
        self.loop = asyncio.get_running_loop()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"game-{game.path.stem}")
        t = {"wait": 30.0, "cap": 300.0, "grace": 4.0, **(timers or {})}
        if "quiet" in t:                             # (bindings saved before the turn card call it quiet)
            t["wait"] = t.pop("quiet")
        # it waits on the seated players in the scene who've been around lately - never on someone long gone
        self.director = TableDirector(self._resolve, lambda: self.expected & self.active_players(),
                                      on_change=self._turn_changed, **t)
        self.expected: set[str] = set()
        self.handles: dict[str, str] = {}            # discord id -> PC handle
        self.names: dict[str, str] = {}              # PC handle -> character name (for the turn card)
        self.card = None                             # the turn card on the channel (whatever the channel returns)
        self._card_task: asyncio.Task | None = None
        self._card_dirty = False
        self._card_shown = ""
        self.outbox: asyncio.Queue = asyncio.Queue()
        self.sender = self.loop.create_task(self._sender())
        self.hinted: set[str] = set()
        self.graph_server = None
        self.world_task: asyncio.Task | None = None
        self.canon_task: asyncio.Task | None = None         # the sleep cycle's read-back (canon.py), when it's due
        self.frame_task: asyncio.Task | None = None         # the scene frame (frame.py), when the scene needs one
        self.requests: dict[str, dict] = {}         # seat requests waiting on the holder (by card message id)
        self.away: set[str] = set()                  # discord ids marked !afk
        self.comebacks: dict[str, dict] = {}         # "back in?" cards for away players who posted (by message id)
        self.undo_votes: dict[str, dict] = {}        # a player's !undo, waiting on the rest of the table
        self.redos: dict = {}                                # {turn: {n, tries, at}} - undone, retried, undone...
        self.chargens: dict[str, Chargen] = {}       # players building a character in their DMs
        self.last_active: dict[str, float] = {}      # handle -> when they last typed, posted or used a command
        self.shop_seen: dict[str, str] = {}          # discord id -> the shop their last !shop / /shop card showed
                                                     # (its holder: !buy <#> is that card's number - shops.chosen)
        self.paused = False                          # a new party under way (newparty.py): no posts go into a turn
        game.out = self._from_thread
        game.progress = self._from_progress
        self._work: dict | None = None               # the work card: what the GM is doing right now
        game.art.out = lambda s: print(f"[{game.path.stem}] {s}")
        game.art.listeners.append(lambda info: self.loop.call_soon_threadsafe(self.outbox.put_nowait, ("art", info)))

    # ── plumbing ────────────────────────────────────────────────────────
    async def run(self, fn, *args):
        return await self.loop.run_in_executor(self.pool, fn, *args)

    async def aside(self, fn, *args):
        """fn(<the game, read through a connection of its own>, *args), off the game thread - for whatever has to
        answer Discord fast (a form gets 3 seconds) and mustn't wait out the GM's turn."""
        g = self.game
        return await self.side(lambda v: fn(g.on(v.conn), *args))

    async def side(self, fn, *args):
        """fn(<game-like>, *args) on a connection of its own, off the game thread - for the table's own business
        (rulings) that mustn't wait out the GM's turn."""
        return await self.loop.run_in_executor(None, rulings.on_side, self.game.path, fn, *args)

    def _from_thread(self, line: str) -> None:
        if classify(line) != "log":                   # (what the table reads: never a name it hasn't learned - §12l)
            line = spoilers.card(self.game, line)
        self.loop.call_soon_threadsafe(self.outbox.put_nowait, ("line", line))

    async def _sender(self) -> None:
        while True:
            batch = [await self.outbox.get()]
            while not self.outbox.empty():
                batch.append(self.outbox.get_nowait())
            try:
                await self._post(batch)
            except Exception as exc:              # a failed post must never stall the table
                print(f"[{self.game.path.stem}] post failed: {exc}")
            finally:
                for _ in batch:
                    self.outbox.task_done()

    async def _post(self, batch) -> None:
        cards: list[str] = []

        async def flush():
            for m in card_messages(cards, self.colors_on()):
                await self.ch.send(m)
            cards.clear()

        for kind, payload in batch:
            if kind == "line":
                c = classify(payload)
                if c == "card":
                    cards.append(payload)
                elif c == "notice":
                    await flush()
                    await self.ch.send(notice_text(payload))
                else:
                    print(f"[{self.game.path.stem}] {payload}")
            elif kind == "art":
                await flush()
                await self._post_art(payload)
        await flush()

    async def drain(self) -> None:
        await self.outbox.join()

    async def _post_art(self, info: dict) -> None:
        """A freshly painted picture is the character's (or place's, or item's) big introduction."""
        icon, color = ART_STYLE.get(info["kind"], ("🎨", NARRATION))
        title = f"{icon} {info['name']}" + (" - changed" if info.get("edited") else "")
        desc = info.get("caption") or ""
        if info.get("edited") and info.get("change"):
            desc += f"\n*{info['change']}*"
        # (the GM's update_art words and the caption written from them: an art post never meets the out hook - §12l)
        desc = await self.run(spoilers.card, self.game, desc)
        where = await self.ch.send_cards([{"title": title, "description": desc[:EMBED_LIMIT], "color": color,
                                           "image": info["path"]}])
        g = self.game
        if where and where[0] and info["kind"] in ("npc", "pc"):     # this card is now their avatar's home
            await self.run(self._remember_asset, info["entity_id"], info.get("version"), where[0])
        await self.run(lambda: g.conn.execute("INSERT OR IGNORE INTO presented(entity_id, turn) VALUES(?,?)",
                                              (info["entity_id"], g.turn_no())))

    # ── the offscreen world: NPC moves between turns, never posted ─────
    def kick_world(self) -> None:
        """After a turn: let offscreen NPCs move, in the background. The Haiku thinking runs off the
        game thread, so a player who acts right away isn't kept waiting."""
        if self.world_task is None or self.world_task.done():
            self.world_task = self.loop.create_task(self._world_pass())
        self.kick_canon()
        self.kick_frame()

    async def _world_pass(self) -> None:
        from ..dm import world
        g, tag = self.game, self.game.path.stem
        try:
            jobs = await self.run(world.plan, g)
            if not jobs:
                return
            results = await asyncio.gather(*(self.loop.run_in_executor(None, world.think, g, j) for j in jobs),
                                           return_exceptions=True)
            for line in await self.run(world.apply_all, g, jobs, results):
                print(f"[{tag}] {line}", flush=True)
        except Exception as exc:                  # the world failing must never touch the table
            print(f"[{tag}] world pass failed: {exc}", flush=True)

    # ── story directions: the table steering, out of character (narrative.py) ──
    NARRATIVE_COLOR = 0x1ABC9C

    async def narrative_cmd(self, uid: str, uname: str, rest: str, admin: bool) -> None:
        verb, _, tail = rest.partition(" ")
        verb, tail = verb.lower(), tail.strip()
        later = "\n-# The GM's mid-turn - it sees this from its next reply." if self.director.resolving else ""
        if not rest or verb in ("list", "show"):
            await self.ch.send(title="🧭 Story directions", description=await self.side(narrative.listing),
                               color=self.NARRATIVE_COLOR)
        elif verb in ("help", "?"):
            await self.ch.send("`!narrative add <where you want the story to go>` - the GM steers toward it, out of "
                               "character, until it's done  ·  `!narrative` lists them  ·  `!narrative remove D#` "
                               "(yours, or any if you're the owner)  ·  owner: `!narrative clear`")
        elif verb in ("remove", "rm", "drop", "delete", "del", "done"):
            did = tail.split()[0] if tail else ""
            r = await self.side(narrative.get, did)
            if r and r["status"] == "active" and r["by"] != uid and not admin:
                await self.ch.send(f"**{r['id']}** is {r['by_name'] or 'someone else'}'s - they or the campaign "
                                   "owner can remove it.")
                return
            r = await self.side(narrative.close, did, "done" if verb == "done" else "removed", uid)
            await self.ch.send(f"🧭 **{r['id']}** {'done' if verb == 'done' else 'removed'} - the GM stops steering "
                               "toward it." + later)
        elif verb == "clear":
            if not admin:
                await self.ch.send("Clearing every direction is for the campaign owner - `!narrative remove D#` "
                                   "takes back one of yours.")
                return
            gone = await self.side(narrative.clear, uid)
            await self.ch.send(f"🧭 Cleared {', '.join(f'**{d}**' for d in gone)}." if gone
                               else "No directions standing.")
        else:                                             # `!narrative add ...` - or just `!narrative <text>`
            text = tail if verb in ("add", "+", "new") else rest
            r = await self.side(narrative.add, text, uid, uname)
            await self.ch.send(f"🧭 **{r['id']}** {r['text']}\n-# The GM steers toward it until it lands · "
                               f"`!narrative remove {r['id']}` · `!narrative` lists them" + later)

    # ── the scene frame: who everyone here is now, toward each other (frame.py) ──
    def kick_frame(self, force: bool = False) -> bool:
        if self.frame_task is not None and not self.frame_task.done():
            return False
        self.frame_task = self.loop.create_task(self._frame_pass(force))
        return True

    async def _frame_pass(self, force: bool = False) -> None:
        from ..dm import frame
        g, tag = self.game, self.game.path.stem
        try:
            if self.canon_task is not None and not self.canon_task.done():
                await asyncio.wait({self.canon_task})        # (a fresh canon first - the frame stands on it)
            sid = await self.run(g.current_scene_id)
            if not force and not await self.run(frame.due, g, sid):
                return
            gathered = await self.run(frame.gather, g, sid)
            data = await self.loop.run_in_executor(None, frame.think, g, gathered)
            f = await self.run(frame.apply, g, gathered, data)
            print(f"[{tag}] frame S{sid} T{f['turn']}: {len(f['people'])} people"
                  + (f", retired {', '.join(f['retired'])}" if f["retired"] else ""), flush=True)
        except Exception as exc:                  # the frame failing must never touch the table
            print(f"[{tag}] frame pass failed: {exc}", flush=True)

    # ── the sleep cycle: the story read back and reconciled (canon.py) ──
    def kick_canon(self, force: bool = False) -> bool:
        """After a turn: when it's due (every canon.CANON_EVERY turns, or a new session), the strong model reads the
        story back and writes the canon - in the background, so nobody waits on it. False if one's already running."""
        if self.canon_task is not None and not self.canon_task.done():
            return False
        self.canon_task = self.loop.create_task(self._canon_pass(force))
        return True

    async def _canon_pass(self, force: bool = False) -> None:
        from ..dm import canon
        g, tag = self.game, self.game.path.stem
        try:
            if not force and not await self.run(canon.due, g):
                return
            print(f"[{tag}] canon: reading the story back...", flush=True)
            gathered = await self.run(canon.gather, g)
            data = await self.loop.run_in_executor(None, canon.think, g, gathered)
            res = await self.run(canon.apply, g, gathered, data)
            print(f"[{tag}] canon T{res['turn']}: {res['settled']} settled, {len(res['fixed'])} fixes"
                  + (f", {len(res['unplaced'])} unplaced" if res.get("unplaced") else "")
                  + (f" ({', '.join(res['skipped'])} skipped)" if res["skipped"] else "")
                  + (f", doubts settled {', '.join(res['doubts_resolved'])}" if res.get("doubts_resolved") else "")
                  + (f", left open as doubts {', '.join(res['doubts_raised'])}" if res.get("doubts_raised") else "")
                  + (f", settled while it read (its answer a note) {', '.join(res['doubts_late'])}"
                     if res.get("doubts_late") else ""), flush=True)
            review = await self.run(canon.review_text, g)
            key = ",".join(sorted(f"{r['id']}:{r['verdict']}" for r in res["review"] if r["verdict"] != "keep"))
            if review and (force or key != await self.run(g.ledger.meta, "canon_review_posted", "")):
                await self.ch.send(title="⚖️ Rulings review", description=review[:EMBED_LIMIT], color=0xC9A227)
                await self.run(g.ledger.set_meta, "canon_review_posted", key)
            if force:
                await self.ch.send(f"📚 The story's been read back and reconciled (as of T{res['turn']}): "
                                   f"{res['settled']} things settled"
                                   + (f", {len(res['fixed'])} corrections to the record" if res["fixed"] else "")
                                   + ".\n-# `!canon` sends the owner the whole record · `!rulings review`")
        except Exception as exc:                  # the canon failing must never touch the table
            print(f"[{tag}] canon pass failed: {exc}", flush=True)
            if force:
                await self.ch.send(f"⚠️ The read-back failed: {exc}")

    async def close(self) -> None:
        if self.card is not None and hasattr(self.ch, "drop_turn_card"):
            try:
                await self.ch.drop_turn_card(self.card)
            except Exception:
                pass
            self.card = None
        if self.world_task and not self.world_task.done():
            self.world_task.cancel()
        for task in (self.canon_task, self.frame_task):
            if task and not task.done():
                task.cancel()
        self.sender.cancel()
        await self.run(self.game.close)
        self.pool.shutdown(wait=False)

    # ── who is playing ──────────────────────────────────────────────────
    def _snapshot(self) -> tuple[set[str], dict[str, str], dict[str, str], dict[str, float], set[str]]:
        g = self.game
        roster = set(g.ledger.roster(g.current_scene_id()))
        handles, expected, names, away = {}, set(), {}, set()
        for r in g.conn.execute("SELECT discord_id, handle, afk FROM players"):
            handles[r["discord_id"]] = r["handle"]
            if r["afk"]:
                away.add(r["discord_id"])
            ch = g.character_for(r["handle"])
            names[r["handle"]] = ch["name"] if ch else r["handle"]
            if ch and ch["id"] in roster and not r["afk"]:
                expected.add(r["handle"])
        seen: dict[str, float] = {}                  # when each handle last posted a turn (survives a bot restart)
        for r in g.conn.execute("SELECT inputs, created_at FROM turns WHERE status='committed' ORDER BY id DESC "
                                "LIMIT 40"):
            at = _utc(r["created_at"])
            for h, _ in json.loads(r["inputs"] or "[]"):
                seen.setdefault(h, at)
        return expected, handles, names, seen, away

    async def refresh(self) -> None:
        self.expected, self.handles, self.names, seen, self.away = await self.run(self._snapshot)
        for h, at in seen.items():                   # (after a restart the table still knows who was just playing)
            if at > self.last_active.get(h, 0):
                self.last_active[h] = at

    def typing(self, discord_id: str) -> None:
        handle = self.handles.get(discord_id)
        if handle:
            self.last_active[handle] = time.time()
            self.director.typing(handle)

    # ── the work card: what the GM is doing while it works ────────────────
    # A turn is 20 s to a couple of minutes of "typing..." - which looks like a hang. The card says where it's up to
    # (reading, thinking, the roll it's making, writing and how far, remembering) and how long it's been, redrawn in
    # place as the turn moves on and taken down when the story posts. Never names who's being introduced.
    def _from_progress(self, text: str, key: str | None = None) -> None:
        """game.progress, from the game thread."""
        self.loop.call_soon_threadsafe(self._stage, text, key or text)

    def _stage(self, text: str, key: str) -> None:
        w = self._work
        if w is None:
            return
        if key != w["key"]:
            done = re.sub(r"^\W+\s*", "", w["text"]).split(" (")[0]
            if done and (not w["done"] or w["done"][-1] != done):
                w["done"].append(done)
            w["key"] = key
        w["text"] = text
        w["wake"].set()

    def work_text(self, w: dict) -> str:
        done = "  ·  ".join(f"✓ {d}" for d in w["done"][-4:])
        return (f"⏳ **The GM is on it**  ·  started <t:{int(w['started'])}:R>\n" + (f"-# {done}\n" if done else "")
                + f"{w['text']}...")

    def _work_begin(self) -> None:
        if not hasattr(self.ch, "work_card"):
            return
        self._work = w = {"ref": None, "started": time.time(), "done": [], "key": "start",
                          "text": "📖 reading your moves", "shown": "", "stop": False,
                          "wake": asyncio.Event(), "over": asyncio.Event()}
        self.loop.create_task(self._work_loop(w))

    def _work_end(self) -> None:
        w, self._work = self._work, None
        if w:
            w["stop"] = True
            w["wake"].set()
            w["over"].set()

    async def _work_loop(self, w: dict) -> None:
        """Draws the card at once, then whenever the turn moves on (at most every WORK_EVERY seconds), and takes it
        down when the turn's done - after any edit in flight, so no card is left behind."""
        try:
            while not w["stop"]:
                text = self.work_text(w)
                if text != w["shown"]:
                    try:
                        w["ref"] = await self.ch.work_card(w["ref"], text)
                        w["shown"] = text
                    except Exception as exc:
                        print(f"[{self.game.path.stem}] work card: {exc}", flush=True)
                try:
                    await asyncio.wait_for(w["over"].wait(), WORK_EVERY)
                except asyncio.TimeoutError:
                    pass
                while not w["stop"] and self.work_text(w) == w["shown"]:
                    w["wake"].clear()
                    await w["wake"].wait()
        finally:
            if w["ref"] is not None:
                await self.ch.drop_turn_card(w["ref"])

    # ── the turn card: who the GM is waiting on, a countdown, ⏩ ✋ 💤 ──────
    def _turn_changed(self) -> None:
        """The director moved (an action, typing, a pass...): redraw the card, coalescing bursts."""
        self._card_dirty = True
        if self._card_task is None or self._card_task.done():
            self._card_task = self.loop.create_task(self._draw_card())

    async def _draw_card(self) -> None:
        while self._card_dirty:
            self._card_dirty = False
            try:
                await self._update_card()
            except Exception as exc:                 # a card that won't draw must never stall the table
                print(f"[{self.game.path.stem}] turn card: {exc}", flush=True)
            await asyncio.sleep(1.0)

    def card_text(self, snap: dict) -> str:
        name = lambda h: self.names.get(h, h)       # noqa: E731
        ids = {h: uid for uid, h in self.handles.items()}
        due = int(time.time() + (snap["in"] or 0))
        parts = [f"✅ {name(h)}" for h in snap["acted"]]
        parts += [f"✍️ {name(h)} *(typing)*" if h in snap["typing"] else f"⌛ <@{ids[h]}>" if h in ids else f"⌛ {name(h)}"
                  for h in snap["waiting"]]
        parts += [f"💤 {name(h)}" for h in snap["passed"]]
        return (f"⏳ **The GM moves <t:{due}:R>** - or as soon as everyone's in.\n" + "  ·  ".join(parts) + "\n"
                "-# ⏩ go now  ·  ✋ more time  ·  💤 sit this one out  (or `!go` `!wait` `!pass`)")

    async def _update_card(self) -> None:
        if not hasattr(self.ch, "turn_card"):
            return
        snap = self.director.snapshot()
        if not snap or snap["resolving"] or not snap["waiting"]:
            if self.card is not None:                # everyone's in, or the GM is on it: the card goes
                card, self.card, self._card_shown = self.card, None, ""
                await self.ch.drop_turn_card(card)
            return
        text = self.card_text(snap)
        if text == self._card_shown:
            return
        ping = [] if self.card is not None else [uid for uid, h in self.handles.items() if h in snap["waiting"]]
        self.card = await self.ch.turn_card(self.card, text, ping)
        self._card_shown = text

    async def turn_button(self, discord_id: str, action: str) -> str | None:
        """⏩ / ✋ / 💤 on the turn card (and !go / !wait / !pass). Returns a note for the presser, if any."""
        handle = self.handles.get(discord_id)
        if not handle:
            return "You're not playing at this table - `!join <character>` first."
        self.last_active[handle] = time.time()
        d = self.director
        if action == "go":
            return None if d.go() else "Nothing's waiting to resolve."
        if action == "wait":
            if handle not in d.waiting_on():
                return "The turn isn't waiting on you." if d.queue else "Nothing's waiting to resolve."
            return None if d.hold(handle) else "That's all the extra time this turn - post when you're ready."
        if action == "pass":
            if handle not in d.waiting_on():
                return "The turn isn't waiting on you." if d.queue else "Nothing to sit out yet."
            d.pass_(handle)
            return None
        return None

    def active_players(self) -> set[str]:
        """Handles seen in the last ACTIVE_WINDOW seconds: who the GM can turn to with 'and you?'."""
        now = time.time()
        return {h for h, t in self.last_active.items() if now - t <= ACTIVE_WINDOW}

    # ── messages ────────────────────────────────────────────────────────
    async def handle(self, author_id: str, author_name: str, content: str, is_admin: bool, react: React,
                     unreact: React | None = None) -> None:
        text = content.strip()
        if author_id in self.handles:
            self.last_active[self.handles[author_id]] = time.time()     # any sign of life counts
        if not text or text.startswith("(("):
            return
        if self.paused and not text.startswith("!"):
            await react("⏸️")                               # (the crew's changing: a post now would be the old crew's)
            return
        if text.startswith("!"):
            t0, name = time.time(), text.split(None, 1)[0][:24]
            job = asyncio.ensure_future(self.command(author_id, author_name, text,
                                                     is_admin or author_id == self.owner_id, react))
            done, _ = await asyncio.wait({job}, timeout=SLOW)
            if not done:                                  # most likely the GM's mid-turn: say it was heard
                await react("⏳")
            err = None
            try:
                await job
            except LedgerError as exc:
                err = str(exc)
                await self.ch.send(f"⚠️ {exc}")
            finally:
                if not done and unreact:
                    await unreact("⏳")
            took = time.time() - t0
            if took >= SLOW or err:
                print(f"[{self.game.path.stem}] {name} ({author_name}) {took:.1f}s"
                      + (" - waited on the GM's turn" if not done and self.director.resolving else "")
                      + (f" - {err}" if err else ""), flush=True)
            if author_id in self.handles:                 # (a !join seats them - that's activity too)
                self.last_active[self.handles[author_id]] = time.time()
            return
        if aside.table_talk(text):                        # "Hey DM, ..." / "the DM ignored it" / "((...))" / a bug
                                                          # report - out of character, not a move (T151, T158-T161)
            await self.gm_aside(author_id, author_name, text, react)
            return
        handle = self.handles.get(author_id)
        if not handle:
            if author_id not in self.hinted:
                self.hinted.add(author_id)
                await self.ch.send(f"<@{author_id}> you're not playing anyone yet - `!join <character>` "
                                   f"or `!newchar <Name> <archetype>`.")
            return
        if author_id in self.away:                        # marked !afk: ask before it counts
            await self._ask_back(author_id, handle, text, react)
            return
        self.director.add(handle, text)
        await react("📝")

    # ── the GM aside: a player talks to the GM out of character (dm/aside.py) ──
    async def gm_aside(self, uid: str, uname: str, text: str, react: React) -> None:
        g = self.game
        if not aside.TO_GM.sub("", text).strip() and not text.strip():
            await self.ch.send("`!gm <question>` - or start a message with \"Hey DM\" - asks the GM out of character.")
            return
        handle = self.handles.get(uid)

        def who():
            ch = g.character_for(handle) if handle else None
            return f"{uname} (plays {ch['name']} [{ch['id']}])" if ch else f"{uname} (not playing anyone right now)"
        label = await self.run(who)
        await react("🎙️")
        try:
            async with self.ch.typing():
                res = await self.run(aside.ask, g, label, text, handle)
        except LedgerError as exc:
            await self.ch.send(f"⚠️ {exc}")
            return
        except Exception as exc:
            print(f"[{g.path.stem}] GM aside failed: {exc}", flush=True)
            flags.record(g, "engine", "aside failed", f"{type(exc).__name__}: {str(exc)[:500]}", who=uname,
                         context={"message": text})
            await self.ch.send(f"⚠️ The GM couldn't step out of the story just now ({type(exc).__name__}) - try again.")
            return
        if res["is_move"]:                                 # it was a move after all: into the turn it goes
            if handle and uid not in self.away:
                self.director.add(handle, text)
                await react("📝")
            elif handle:
                await self._ask_back(uid, handle, text, react)
            return
        body = res["answer"] or "Noted."
        if res["direction"]:
            body += f"\n\n-# Next turn: {res['direction']}"
        if res.get("checked"):                             # the turns it read before answering (never a W# or a note)
            body += f"\n-# Checked the record: {', '.join(res['checked'][:8])}"
        if res["fixed"]:
            body += f"\n-# Fixed in the record: {', '.join(res['fixed'])}"
        for line in res.get("cards") or []:                # the numbers it set right, exactly (aside.ask scrubbed them)
            body += f"\n🔧 {line[6:]}"
        await self.ch.send(title=f"🎙️ GM aside - to {uname}", description=body, color=0x95A5A6)

    # ── !reportbug: a player tells the developers something's wrong (flags.py) ──
    async def report_bug(self, uid: str, uname: str, text: str, reply=None) -> int | None:
        g, reply = self.game, reply or self.ch
        if not text.strip():
            await reply.send("`!reportbug <what went wrong>` - it goes to the developers with this turn attached.")
            return None

        def where(v):
            t = v.conn.execute("SELECT MAX(id) FROM turns").fetchone()[0]
            n = v.conn.execute("SELECT narration FROM turns WHERE id=?", (t,)).fetchone() if t else None
            scene = v.ledger.current_scene()
            ch = v.character_for(self.handles.get(uid, "")) if self.handles.get(uid) else None
            return t, {"scene": scene["title"] if scene else None, "character": ch["name"] if ch else None,
                       "story_time": v.clock_line(), "last_narration": (n["narration"] if n else "")[:600]}
        turn, context = await self.aside(where)
        fid = await self.loop.run_in_executor(None, lambda: flags.record(g, "player", "bug report", text, who=uname,
                                                                         turn=turn, context=context))
        await reply.send(f"🐞 Thanks - logged as **#{fid}**." if fid else "⚠️ Couldn't log that - tell the owner.")
        return fid

    # ── !stuck: a player says the story's going in circles (pacing.py) ──
    async def report_stuck(self, uid: str, uname: str, text: str = "") -> None:
        from ..dm import pacing
        await self.ch.send("🔁 Reading the last few turns...")
        try:
            res = await self.aside(pacing.player_says_stuck, uname, text)
        except Exception as exc:
            await self.ch.send(f"⚠️ Couldn't read the turns just now ({type(exc).__name__}) - say it to the GM: "
                               "\"Hey DM, we're going in circles.\"")
            return
        body = (f"**What's repeating:** {res['what']}\n**Next turn:** {res['break_it']}" if res["looping"] else
                "The engine didn't spot a loop - but you know the table, so the next turn will close whatever's open "
                "and move on.")
        await self.ch.send(title=f"🔁 Going in circles? - from {uname}", description=body
                           + "\n-# No turn spent. It's on the developers' flag log too.", color=0x95A5A6)

    # ── !undo by a player: the rest of the table agrees, or the turn stands ──
    # Five turns in one night asked the GM to "reset that turn" - but only the owner could !undo, so the GM pretended
    # in the fiction while the dice, damage and memories stood. A player can take back the last turn now, if everyone
    # else at the table agrees (✅ / `!yes`); one ✖️ keeps it. Alone at the table, it's just done. The owner's is instant.
    UNDO_TTL = 600
    UNDO_NOTE = ("-# Everything the game keeps is back to just before it: dice, damage, Overwatch, money, memories, "
                 "the world. The messages from that turn stay in the channel - the game has forgotten them. Undo goes "
                 "back one turn at a time; a retcon the GM only writes into the story doesn't change the numbers - if "
                 "something looks off, `!reportbug`.")

    REDO_FLAG = 3                                         # the same turn undone this often: the table's fighting it

    async def _undo_now(self, why: str = "") -> None:
        def undo():
            t = self.game.undo_target()
            row = self.game.conn.execute("SELECT inputs FROM turns WHERE id=?", (t["id"],)).fetchone() if t else None
            return t, json.loads(row["inputs"] or "[]") if row else [], self.game.undo()
        target, inputs, msg = await self.run(undo)
        await self.ch.send(f"↩️ {msg}{why}\n{self.UNDO_NOTE}")
        await self.refresh()
        if target:
            now = time.time()
            redo = self.redos.get(target["id"])
            if not redo or now - redo["at"] > 3 * 3600:
                redo = self.redos[target["id"]] = {"n": 0, "tries": [], "at": now}
            redo["n"] += 1
            redo["tries"].append(" / ".join(x for _, x in inputs)[:300])
            if redo["n"] == self.REDO_FLAG:                    # (a player redid T155 five times before it rolled right)
                flags.record(self.game, "engine", "redo loop",
                             f"T{target['id']} was undone {redo['n']} times - the table kept retrying it. Tries: "
                             + " | ".join(redo["tries"]), turn=target["id"])

    async def _ask_undo(self, uid: str, uname: str, target: dict | None) -> None:
        g = self.game
        if not target:
            await self.ch.send("Nothing to undo.")
            return
        if self.director.resolving:
            await self.ch.send("↩️ The GM's mid-turn - `!undo` once it lands.")
            return
        if uid not in self.handles:
            await self.ch.send(f"<@{uid}> only someone playing at the table can ask to undo a turn.")
            return
        now = time.time()
        self.undo_votes = {k: v for k, v in self.undo_votes.items() if v["expires"] > now}
        active = self.active_players()
        need = {d for d, h in self.handles.items() if d != uid and d not in self.away and h in active}
        if not need:                                      # nobody else here to ask
            await self._undo_now()
            return

        def gist():
            row = g.conn.execute("SELECT text FROM nodes WHERE kind='slice' AND created_turn=? ORDER BY rowid LIMIT 1",
                                 (target["id"],)).fetchone()
            if row:
                return row["text"]
            n = g.conn.execute("SELECT narration FROM turns WHERE id=?", (target["id"],)).fetchone()
            return (n["narration"] if n else "")[:300]
        what = await self.run(gist)
        if not hasattr(self.ch, "ask"):
            await self.ch.send("↩️ Undoing a turn needs everyone's ✅ - the campaign owner can `!undo` it.")
            return
        key = await self.ch.ask(
            " ".join(f"<@{d}>" for d in sorted(need)),
            {"title": f"↩️ {uname} wants to take back turn T{target['id']}",
             "description": (f"*{what}*\n\n" if what else "") + "✅ to take it back (or `!yes`) · ❌ to keep it (or "
                            "`!no`). Everyone at the table has to agree - the rolls, damage, Overwatch, money and "
                            "memories of that turn all go, as if it never happened (its messages stay in the channel). "
                            "Open for 10 minutes.", "color": 0xE67E22},
            ["✅", "❌"])
        if key:
            self.undo_votes[key] = {"turn": target["id"], "requester": uid, "need": need, "yes": set(),
                                    "expires": now + self.UNDO_TTL}

    async def vote_undo(self, uid: str, yes: bool, key: str | None = None) -> bool:
        """A ✅ / ❌ (or `!yes` / `!no`) on an undo vote. False if this person has nothing to vote on."""
        now = time.time()
        self.undo_votes = {k: v for k, v in self.undo_votes.items() if v["expires"] > now}
        k = key if key in self.undo_votes else next((k for k, v in self.undo_votes.items() if uid in v["need"]
                                                     and uid not in v["yes"]), None)
        if k is None or uid not in self.undo_votes[k]["need"]:
            return False
        v = self.undo_votes[k]
        if not yes:
            self.undo_votes.pop(k)
            await self.ch.send(f"🔒 <@{uid}> keeps turn T{v['turn']} - it stands.")
            return True
        v["yes"].add(uid)
        if v["yes"] < v["need"]:
            return True
        self.undo_votes.pop(k)
        target = await self.run(self.game.undo_target)
        if not target or target["id"] != v["turn"] or self.director.resolving:
            await self.ch.send(f"↩️ Turn T{v['turn']} isn't the latest any more - the vote's off.")
            return True
        await self._undo_now(" (the table agreed)")
        return True

    # ── back from !afk: a post from someone marked away is held, and they're asked ──
    # The GM is playing their character (or it's hanging back), so the post can't just go in - and they may only be
    # chatting. A card only they can answer: ✅ back in (the held posts go into the turn) or ✖️ stay away (set aside).
    COMEBACK_TTL = 900

    async def _ask_back(self, uid: str, handle: str, text: str, react: React) -> None:
        now = time.time()
        self.comebacks = {k: c for k, c in self.comebacks.items() if c["expires"] > now}
        pending = next((c for c in self.comebacks.values() if c["uid"] == uid), None)
        await react("⏸️")
        if pending:                                       # (already asked: this one waits with the rest)
            pending["posts"].append(text)
            return
        if not hasattr(self.ch, "ask"):                   # no buttons here: posting is coming back
            await self._come_back(uid, [text])
            return
        g, name = self.game, self.names.get(handle, handle)
        ch = await self.run(g.character_for, handle)
        mode = await self.run(g.control_of, ch["id"]) if ch else None
        key = await self.ch.ask(
            f"<@{uid}>", {"title": "💤 You're marked away",
                          "description": (f"The GM is playing **{name}** for you" if mode == "gm" else
                                          f"**{name}** is hanging back quietly") + ". Back in?\n"
                                         "✅ **I'm back** - your post goes into this turn\n"
                                         "✖️ **Stay away** - your post is set aside (`!back` any time)",
                          "color": 0x95A5A6}, ["✅", "❌"], holder=uid)
        if key is None:                                   # (the card didn't post: don't lose the move)
            await self._come_back(uid, [text])
            return
        self.comebacks[key] = {"uid": uid, "handle": handle, "posts": [text], "expires": now + self.COMEBACK_TTL}

    async def answer_back(self, uid: str, yes: bool, key: str | None = None) -> bool:
        """✅ / ✖️ on a "back in?" card (or `!yes` / `!no` / `!back`). False if nothing was waiting."""
        now = time.time()
        self.comebacks = {k: c for k, c in self.comebacks.items() if c["expires"] > now}
        k = key if key in self.comebacks else next((k for k, c in self.comebacks.items() if c["uid"] == uid), None)
        if k is None or self.comebacks[k]["uid"] != uid:
            return False
        c = self.comebacks.pop(k)
        if yes:
            await self._come_back(uid, c["posts"])
        else:
            n = len(c["posts"])
            await self.ch.send(f"💤 <@{uid}> stays away - {'your post was' if n == 1 else f'{n} posts were'} set aside.")
        return True

    async def _come_back(self, uid: str, posts: list[str]) -> None:
        g = self.game
        await self.run(lambda: g.conn.execute("UPDATE players SET afk=0 WHERE discord_id=?", (uid,)))
        await self.refresh()
        handle = self.handles.get(uid)
        if handle is None:                                # (no seat any more - the crew changed while they were away)
            await self.ch.send(f"💤 <@{uid}> - there's no runner of yours at this table now, so "
                               f"{'your post was' if len(posts) == 1 else 'your posts were'} set aside.")
            return
        self.last_active[handle] = time.time()
        for post in posts:
            self.director.add(handle, post)
        await self.ch.send(f"👍 <@{uid}> is back - **{self.names.get(handle, handle)}** is yours again"
                           + (" - your post's in this turn." if posts else "."))

    async def _resolve(self, inputs: list[tuple[str, str]]) -> None:
        g = self.game
        from .. import seed
        if await seed.before_turn(self, inputs):          # a seeded story opens first; these posts play next (seed.py)
            return
        sid0 = await self.run(g.current_scene_id)
        self._work_begin()
        try:
            async with self.ch.typing():
                g.active_players = self.active_players()
                g.passed = set(self.director.batch_passed)      # who chose to sit this one out
                res = await self.run(g.run_turn, inputs)
        except Exception as exc:
            self._work_end()
            flags.record(g, "engine", "turn failed", f"{type(exc).__name__}: {str(exc)[:500]}",
                         turn=await self.run(g.turn_no) + 1, context={"inputs": inputs})
            await self.drain()
            await self.ch.send(f"⚠️ The GM fumbled that one ({type(exc).__name__}: {str(exc)[:300]}). "
                               "The turn was rolled back - say it again, or `!go`.")
            return
        self._work_end()
        await self.drain()                                    # roll cards first, then the story
        moved = bool(res.info.get("auto_cut")) or (await self.run(g.current_scene_id)) != sid0
        await self._post_story(await self.run(self._story_cards, res, moved))
        await self._post_netmaps(res.cards, self.ch.send_cards)
        await self._post_battlemap(res.turn_id)
        await self._post_initiative(res.turn_id)
        await self._post_divider()
        await self.refresh()
        self.kick_world()

    async def _post_divider(self) -> None:
        """The strip that opens the next turn (divider.py): after the story and any map, before the players' posts."""
        g = self.game
        style = await self.run(g.ledger.meta, "dividers", "picture")
        if style == "off":
            return
        if style == "picture" and hasattr(self.ch, "banner"):
            try:
                path = await self.run(divider.render, g, g.path.parent / "sheets" / f"{g.path.stem}_divider.png")
                await self.ch.banner(str(path))
                return
            except Exception as exc:                  # no picture: the line says the same
                print(f"[{g.path.stem}] divider: {exc}", flush=True)
        await self.ch.send(await self.run(divider.line, g))

    # ── story cards (the old bot's look, in story order) ────────────────
    def _location(self) -> tuple[dict, dict | None, dict | None]:
        g = self.game
        s = g.ledger.scene(g.current_scene_id())
        loc = g.ledger.get(s["location_id"]) if s["location_id"] else None
        art = g.art.latest(g.conn, loc["id"], ready_only=True) if loc else None
        return s, loc, art

    def _location_card(self, trip: str | None = None) -> dict:
        s, loc, art = self._location()
        district = ((loc or {}).get("props") or {}).get("geo", {}).get("district")
        return {"title": f"📍 {loc['name'] if loc else s['title']}" + (f" · {district}" if district else ""),
                "description": (f"*{loc['description']}*\n" if loc else "") + f"**{s['title']}**"
                               + (f"\n-# {trip}" if trip else ""),
                "color": LOCATION, "image": art["path"] if art else None}

    def _story_cards(self, res, moved: bool) -> list[dict]:
        """Location card (big when the party arrived somewhere, a strip otherwise), item cards for new
        items, then one card per narration paragraph and per line of dialogue, in story order."""
        g, L = self.game, self.game.ledger
        s, loc, loc_art = self._location()
        cards = [self._location_card(res.info.get("trip"))] if moved else (
            [{"description": f"📍 *{loc['name']}*", "color": LOCATION_STRIP,
              "thumbnail": thumbnail(loc_art["path"]) if loc_art else None}] if loc else [])
        for eid in res.info.get("introduced", []):
            e = L.get(eid)
            if e and e["kind"] == "item" and e["tier"] >= 1:
                art = g.art.latest(g.conn, eid, ready_only=True)
                cards.append({"title": f"✨ {e['name']}", "description": f"*{e['description']}*", "color": ITEM,
                              "image": art["path"] if art else None})
        for seg in parse_story(res.narration):
            if seg["kind"] == "narration":
                cards += [{"description": part, "color": NARRATION} for part in chunks(seg["text"], EMBED_LIMIT)]
            else:
                cards.append(self._dialogue_card(seg, said=res.info.get("speakers")))
        if cards:
            cards[-1]["footer"] = f"T{res.turn_id} · {s['title']} · {clock.short(g.clock())}"
        return cards

    # ── the recap: a pirate-trid "previously on", where things stand, and the dossiers ──
    async def post_party(self, ch=None) -> None:
        """The crew roster for the whole table (rosterart.py). Read on a connection of its own, so it shows even while
        the GM is mid-turn."""
        g = self.game
        await (ch or self.ch).send_cards(await self.side(lambda v: rosterart.cards(rosterart.view(g, v.conn))))

    async def post_dossier(self, name: str, ch=None) -> None:
        """The crew's file on someone, for the table (recap.file_on): from the public record only, and off the game
        thread like the roster. With no name: who there's a file on."""
        g, ch = self.game, ch or self.ch

        def pull(v):
            view = g.on(v.conn)
            if not name.strip():
                return None, recap.known_people(view)
            try:
                here = view.current_scene_id()
            except LedgerError:
                here = None
            ent = view.find_speaker(name, here) or view.ledger.find(name)
            if not ent or ent["kind"] not in recap.FILE_KINDS:
                raise LedgerError(f"No file on anyone called '{name}'. `!dossier` lists who there's one on.")
            card = recap.file_on(view, ent["id"])
            if not card:
                raise LedgerError(f"The crew has no file on {ent['name']} - they haven't crossed paths yet.")
            return card, None
        async with ch.typing():
            card, people = await self.side(pull)
        if card:
            await ch.send_cards([{"title": f"🗂️ {card['name']}", "color": 0xC9A227, "image": card["image"]}])
        elif people:
            await ch.send(title="🗂️ The crew's files", color=0xC9A227,
                          description=" · ".join(people) + "\n-# `!dossier <name>` puts one on the table")
        else:
            await ch.send("No files yet - the crew hasn't met anyone.")

    async def post_recap(self) -> None:
        g = self.game
        try:
            async with self.ch.typing():
                rec = await self.run(recap.build, g)
        except Exception as exc:                          # the recap is a nicety: fall back to the plain one
            print(f"[{g.path.stem}] recap failed: {exc}", flush=True)
            from ..dm.turn import recap as plain
            await self.ch.send(title="Previously on...", description=await self.run(plain, g), color=NARRATION_COLOR)
            return
        if rec is None:
            await self.ch.send("Nothing's happened yet - no story to recap.")
            return
        a = rec["anchor"]
        avatar = await self._anchor_avatar(rec.get("anchor_image"))
        if not (self.voices_on() and await self.ch.voice(f"{a['name']} · {a['show']}", rec["broadcast"], avatar)):
            await self.ch.send(title=f"📺 {a['show']} - previously on...", description=rec["broadcast"][:EMBED_LIMIT],
                               color=0xE91E63)
        if rec["standing"]:
            await self.ch.send(title="📍 Where things stand", description="\n".join(f"• {s}" for s in rec["standing"]),
                               color=LOCATION)
        files = [{"title": f"🗂️ {d['name']}", "color": 0xC9A227, "image": d["image"]} for d in rec["dossiers"]]
        if files:
            await self.ch.send_cards(files)

    async def _anchor_avatar(self, path) -> str | None:
        """The anchor's portrait as a webhook avatar: uploaded once to the Cast thread, refreshed when stale."""
        if not path or not hasattr(self.ch, "store_asset"):
            return None
        g = self.game
        row = await self.run(lambda: g.conn.execute("SELECT * FROM voice_assets WHERE entity_id='_anchor'").fetchone())
        row = dict(row) if row else None
        if row and row["expires"] > time.time() + 600:
            return row["url"]
        if row and row["message_id"]:
            url = await self.ch.refresh_asset(row["channel_id"], row["message_id"])
            if url:
                await self.run(self._remember_asset, "_anchor", 1, {**row, "url": url})
                return url
        where = await self.ch.store_asset(str(path), recap.anchor(g)["name"])
        if where:
            await self.run(self._remember_asset, "_anchor", 1, where)
            return where["url"]
        return None

    # ── the network map: posted after a turn where someone acted in the Matrix ──
    async def _post_battlemap(self, turn_id: int) -> None:
        """One live map per fight: posted when it starts, redrawn in place each round, final frame when it ends."""
        g = self.game

        def draw():
            row = g.conn.execute("SELECT id FROM encounters WHERE status='active' OR ended_turn=? ORDER BY id DESC "
                                 "LIMIT 1", (turn_id,)).fetchone()
            if not row:
                return None, None
            enc = encounters.get(g, row["id"])
            return enc, str(battlemap.render(g, enc["id"]))
        try:
            enc, path = await self.run(draw)
        except Exception as exc:                          # a map must never break the table
            print(f"[{g.path.stem}] battle map failed: {exc}", flush=True)
            return
        if not enc:
            return
        over = enc["status"] == "ended"
        card = {"title": "⚔️ The fight is over" if over else f"⚔️ Round {enc['round'] + 1}", "image": path,
                "color": 0x2ECC71 if over else 0xE74C3C}
        if hasattr(self.ch, "live_card"):
            ref = await self.ch.live_card(enc.get("map") or None, card)
            if ref and ref != enc.get("map"):
                def keep():
                    e = encounters.get(g, enc["id"])
                    e["map"] = ref
                    encounters.save(g, e)
                await self.run(keep)
        else:
            await self.ch.send_cards([card])

    async def _post_initiative(self, turn_id: int) -> None:
        """The next round's Initiative, one line, after the story and the map - so the table sees who has how many
        actions before they post. commit rolls it once the fight goes on; it can't ride the turn's own cards, which go
        out before the story (they'd sit above the narration of the round before)."""
        g = self.game

        def card():
            enc = encounters.active(g)
            if not enc or not g.conn.execute("SELECT 1 FROM events WHERE turn_id=? AND kind='initiative'",
                                             (turn_id,)).fetchone():
                return None
            return encounters.initiative_card(g, enc)
        try:
            line = await self.run(card)
        except Exception as exc:                          # a card must never break the table
            print(f"[{g.path.stem}] initiative card failed: {exc}", flush=True)
            return
        if line:
            for m in card_messages([line], self.colors_on()):
                await self.ch.send(m)

    async def _post_netmaps(self, cards: list[str], send) -> None:
        if not any(c.startswith("[MATRIX]") for c in cards):
            return
        g = self.game

        def draw():
            out, seen = [], set()
            for kind in ("pc", "npc"):
                for e in g.ledger.entities(kind=kind):
                    hid = netmap.host_for(g, e["id"])
                    if hid and hid not in seen and any(e["name"] in c.splitlines()[0] for c in cards if c.startswith("[MATRIX]")):
                        seen.add(hid)
                        out.append({"title": f"🕸️ {g.ledger.get(hid)['name']}", "color": 0x50DCFF,
                                    "image": str(netmap.render(g, e["id"]))})
            return out
        try:
            maps_ = await self.run(draw)
        except Exception as exc:                          # a map must never break the table
            print(f"[{g.path.stem}] netmap failed: {exc}", flush=True)
            return
        if maps_:
            await send(maps_)

    def colors_on(self) -> bool:
        """Coloured roll cards and help (ansi.py) - `!colors off` if someone's client shows the codes instead."""
        return self.game.ledger.meta("colors", "on") != "off"

    # ── voices: lines of dialogue posted as the character (webhook) ────
    def voices_on(self) -> bool:
        return self.game.ledger.meta("voices", "on") == "on" and hasattr(self.ch, "voice")

    async def _post_story(self, cards: list[dict]) -> None:
        """Cards in story order; with voices on, each line of dialogue goes out under the speaker's own
        name and portrait instead (a character's first line still gets the big portrait card first)."""
        if not self.voices_on():
            await self.ch.send_cards(cards)
            return
        batch: list[dict] = []
        for c in cards:
            if not c.get("dialogue"):
                batch.append(c)
                continue
            if batch:
                await self.ch.send_cards(batch)
                batch = []
            if c.get("image"):                                   # first appearance: the reveal
                where = await self.ch.send_cards([{"title": f"{'🎲' if c['color'] == SPEAKER_PC else '👤'} "
                                                            f"{c['author']}", "color": c["color"],
                                                   "image": c["image"]}])
                if where and where[0] and c.get("speaker_id"):
                    await self.run(self._remember_asset, c["speaker_id"], None, where[0])
            if await self.ch.voice(c["author"], c["description"], await self._avatar(c.get("speaker_id"))):
                if c.get("footer"):
                    batch.append({"footer": c["footer"], "color": NARRATION})
            else:                                                # no webhook: the card it would have been
                batch.append({k: v for k, v in c.items() if k != "image"} | (
                    {"thumbnail": thumbnail(c["image"])} if c.get("image") else {}))
        if batch:
            await self.ch.send_cards(batch)

    def _remember_asset(self, eid: str, version: int | None, where: dict) -> None:
        g = self.game
        if version is None:
            art = g.art.latest(g.conn, eid, ready_only=True)
            version = art["version"] if art else 0
        g.conn.execute("INSERT OR REPLACE INTO voice_assets(entity_id, version, channel_id, message_id, url, expires) "
                       "VALUES(?,?,?,?,?,?)", (eid, version, where.get("channel_id"), where.get("message_id"),
                                               where["url"], _expiry(where["url"])))

    async def _avatar(self, eid: str | None) -> str | None:
        """A portrait URL Discord will accept as a webhook avatar: the remembered one while it's fresh,
        a refreshed link from the message it lives in, or a new upload."""
        if not eid:
            return None
        g = self.game

        def lookup():
            art = g.art.latest(g.conn, eid, ready_only=True)
            row = g.conn.execute("SELECT * FROM voice_assets WHERE entity_id=?", (eid,)).fetchone()
            return art, dict(row) if row else None
        art, row = await self.run(lookup)
        if not art:
            return None
        if row and row["version"] == art["version"]:
            if row["expires"] > time.time() + 600:
                return row["url"]
            if row["message_id"]:
                url = await self.ch.refresh_asset(row["channel_id"], row["message_id"])
                if url:
                    await self.run(self._remember_asset, eid, art["version"], {**row, "url": url})
                    return url
        name = (await self.run(lambda: g.ledger.get(eid)) or {}).get("name", eid)
        where = await self.ch.store_asset(thumbnail(art["path"]), name)
        if not where:
            return None
        await self.run(self._remember_asset, eid, art["version"], where)
        return where["url"]

    def _dialogue_card(self, seg: dict, private: bool = False, said: dict | None = None) -> dict:
        g, L = self.game, self.game.ledger
        eid = (said or {}).get(seg["speaker"])                 # the GM's tag: exactly who (dm/speakers.py)
        ent = (L.get(eid) if eid else None) or g.find_speaker(seg["speaker"], g.current_scene_id())
        if not ent or ent["kind"] not in ("npc", "pc") or ent["tier"] < 1:      # extras: gray, no portrait
            return {"author": seg["speaker"], "description": seg["text"], "color": SPEAKER_MINOR, "dialogue": True}
        card = {"author": ent["name"], "description": seg["text"], "dialogue": True, "speaker_id": ent["id"],
                "color": SPEAKER_PC if ent["kind"] == "pc" else SPEAKER_MAJOR}
        art = g.art.latest(g.conn, ent["id"], ready_only=True)
        if art:
            if private or g.conn.execute("SELECT 1 FROM presented WHERE entity_id=?", (ent["id"],)).fetchone():
                card["thumbnail"] = thumbnail(art["path"])       # seen before (or a whisper): thumbnail
            else:
                card["image"] = art["path"]                                       # first time: big portrait
                g.conn.execute("INSERT OR IGNORE INTO presented(entity_id, turn) VALUES(?,?)",
                               (ent["id"], g.turn_no()))
        return card

    async def scene_header(self) -> None:
        await self.ch.send_cards([await self.run(self._location_card)])

    # ── a new world: session zero, then !begin ──────────────────────────
    def _started(self) -> bool:
        """Has this chapter's story begun? (After a new party: the new crew's first turn - newparty.chapter_turn.)"""
        return self.game.conn.execute("SELECT 1 FROM turns WHERE status='committed' AND id>? LIMIT 1",
                                      (newparty.chapter_turn(self.game),)).fetchone() is not None

    async def welcome(self, campaign: str) -> None:
        """The table comes online. A story in progress picks up; a fresh world starts with session zero -
        everyone makes a runner, then `!begin` (a seeded world whose players are already seated opens now)."""
        g = self.game

        def look():
            pcs = g.ledger.entities(kind="pc")
            seated = [p for p in pcs if g.conn.execute("SELECT 1 FROM players WHERE handle=?", (p["player"],)).fetchone()]
            return self._started(), pcs, seated, g.ledger.meta("opening"), g.settings_line()
        started, pcs, seated, opening, settings = await self.run(look)
        chapter = None if started else await self.run(newparty.pending, g)
        if chapter:                                       # a new party in an old world: the new crew's session zero
            await self.ch.send_cards([await self.run(newparty.card, g, chapter)])
            if hasattr(self.ch, "build_button"):
                await self.ch.build_button("📝 Tap to build your runner (or type `/newchar`) - the form is private to you.")
            return
        pick = ", ".join(f"`!join {p['player']}` ({p['name']})" for p in pcs)
        if started or (seated and opening):
            await self.ch.send(title=f"🎲 The GM is online - {campaign}",
                               description=settings + f"\n\n**Pick a character:** {pick or 'none yet'} - or `!newchar` "
                                                      "to build one.\nThen just type what you do. `!help` for everything.",
                               color=0x1ABC9C)
            await self.scene_header()
            if not started:
                await self.open_scene()
            return
        await self.ch.send(title=f"🌆 A new world: {campaign}", color=0xF1C40F, description=(
            "**Session zero** - before the story starts, everyone needs a runner:\n"
            "• `!newchar` - build one with me, step by step in your DMs\n"
            "• `!pregen` - I'll roll one up for you (`!pregen ork rigger who owes the Yakuza` to steer me)\n"
            "• `!roles` - not sure what's out there? the roles and metatypes you can play\n"
            + (f"• `!join <name>` - take one who's waiting: {pick}\n" if pcs else "")
            + "\nWhen everyone has a runner, type `!begin` - and tell me what kind of run you're in the mood for if "
              "you like (`!begin a heist on a Renraku data vault`). `!help` for everything."))
        if hasattr(self.ch, "build_button"):
            await self.ch.build_button("📝 Tap to build your runner (or type `/newchar`) - the form is private to you.")

    async def begin(self, pitch: str) -> None:
        """Session zero is over: the GM opens the first scene around the crew (or the seed's own opening)."""
        g, L = self.game, self.game.ledger
        from .. import seed
        if await seed.begin(self, pitch):                 # a story read in with !seed opens its own scene (seed.py)
            return

        def ready():
            if self._started():
                return None, "started"
            party = [p for p in (g.character_for(h) for h in sorted(set(self.handles.values()))) if p]
            if not party:
                return None, "nobody"
            crew = "; ".join(f"{p['name']} ({' '.join(x for x in (p['props'].get('metatype'), (p['props'].get('archetype') or p['props'].get('template') or p['kind']).replace('_', ' ')) if x)}): {p['description'][:200]}"
                             for p in party)
            opening = L.meta("opening") or ""
            chapter = "" if opening else newparty.opening(g, crew, pitch)   # (a new party: the new chapter's own)
            if chapter:
                opening = chapter                         # (the crew and the pitch are in it already)
            elif not opening:
                opening = (f"Open the campaign for this crew - {crew}. "
                           + (f"The players asked for: {pitch}. " if pitch else "Give them a job hook that fits who they are. ")
                           + "Start somewhere that suits them (one of their places, a bar, a fixer's back room), bring in "
                             "a fixer or a Mr. Johnson with the job, and stop when the players have to respond. Don't "
                             "decide anything for the player characters.")
            elif pitch:
                opening += f" The players also asked for: {pitch}."
            L.set_meta("opening", opening)
            for p in party:
                if L.scene_of(p["id"]) is None:
                    g.enter_scene([p["id"]], g.turn_no())
            return [p["name"] for p in party], None
        names, why = await self.run(ready)
        if why == "started":
            await self.ch.send("The story's already going - `!recap` catches you up.")
        elif why == "nobody":
            await self.ch.send("Nobody has a runner yet - `!newchar`, `!pregen` or `!join <name>` first.")
        else:
            await self.ch.send(f"🎬 Here we go: **{', '.join(names)}**.")
            await self.open_scene()

    async def open_scene(self) -> None:
        """A seeded campaign can carry an opening stage direction (meta 'opening'): before anyone has
        played, the GM performs it as the first turn - the fixer's call, the body on the floor."""
        g = self.game

        def pending():
            text = g.ledger.meta("opening")
            played = self._started()                      # (this chapter's: a new party's crew opens afresh)
            return None if played else text
        text = await self.run(pending)
        if not text:
            return
        await self._resolve([("scene", f"(Stage direction from the table, not a character - open the scene: {text})")])
        if await self.run(self._started):
            await self.run(g.ledger.set_meta, "opening", "")

    # ── commands ────────────────────────────────────────────────────────
    def saw_shop(self, uid: str, holder_id: str | None) -> None:
        """Remember the shop a player's card showed (`!shop`, `/shop`): their next `!buy <#>` buys that card's number
        there, not the newest shop's (shops.chosen)."""
        if holder_id:
            self.shop_seen[uid] = holder_id
        else:
            self.shop_seen.pop(uid, None)

    async def command(self, uid: str, uname: str, text: str, admin: bool, react: React) -> None:
        g, L = self.game, self.game.ledger
        cmd, rest = ((text[1:].split(None, 1)) + ["", ""])[:2]   # any whitespace ends the command (phones send newlines)
        cmd, rest = cmd.lower(), rest.strip()
        cmd, rest = _sheet_kind(ALIASES.get(cmd, cmd), rest)
        need_admin = {"gmmodel", "gmeffort", "difficulty", "timer", "pov", "minds", "merge", "rename", "graph",
                      "cost",
                      "dmplay", "idle", "companions", "world", "backup", "reconcile", "canon", "frame", "doubts"}
        if cmd in need_admin and not admin and (rest or cmd not in ("difficulty", "gmmodel", "gmeffort", "companions")):
            await self.ch.send("That one's for the campaign owner.")
            return

        if cmd == "help":
            await self.ch.send_cards(help_cards(color=self.colors_on()))
        elif cmd == "begin":
            await self.begin(rest)
        elif cmd == "pregen":
            await self.start_pregen(uid, uname, rest)
        elif cmd == "backup":
            from .. import backup
            async with self.ch.typing():
                z = await self.loop.run_in_executor(None, backup.run)
            await self.ch.send(f"💾 Backed up every world, the character ledger and the art: `{z.name}` "
                               f"({z.stat().st_size / 1e6:.1f} MB, newest {backup.KEEP} kept).")
        elif cmd == "shop":
            def look():                                    # (!shop <name>: another shop open here, a remote dealer)
                ch = g.character_for(self.handles.get(uid, ""))
                if not ch:
                    return shops.card(g, None), None
                pick = shops.look(g, ch["id"], rest)
                return shops.card(g, ch["id"], pick), (shops.where(g, ch["id"], pick)[0] or {}).get("id")
            card, shown = await self.run(look)
            self.saw_shop(uid, shown)
            await self.ch.send_cards([card])
        elif cmd == "buy":
            m = re.match(r"\s*(.+?)(?:\s*x\s*(\d+))?(?:\s+(?:onto|on)\s+(.+?))?(?:\s+from\s+(.+?))?\s*$", rest)
            if not rest or not m:
                await self.ch.send("`!buy <#>` (numbers from `!shop`), `!buy 3 x2`, `!buy 5 onto <drone>`, or "
                                   "`!buy 2 from <shop>`.")
                return

            def purchase():
                ch = g.character_for(self.handles.get(uid, ""))
                if not ch:
                    raise LedgerError("You're not playing anyone - `!join` first.")
                pick = shops.chosen(g, ch["id"], m.group(1), self.shop_seen.get(uid), m.group(4))
                return shops.buy(g, ch["id"], m.group(1), int(m.group(2) or 1), g.turn_no(), shop_id=pick,
                                 onto=m.group(3))
            res = await self.run(purchase)
            await self.ch.send(f"🛒 {res['card'][len('[SHOP] '):]}")
        elif cmd == "battle":
            def look():
                row = g.conn.execute("SELECT id FROM encounters ORDER BY id DESC LIMIT 1").fetchone()
                return str(battlemap.render(g, row["id"])) if row else None
            path = await self.run(look)
            if not path:
                await self.ch.send("No fight yet.")
            else:
                await self.ch.send_cards([{"title": "⚔️ The battlefield", "image": path, "color": 0xE74C3C}])
        elif cmd == "chronicle":
            def tell():
                mine = g.character_for(self.handles.get(uid, ""))
                who = L.find(rest) if rest else mine
                if not who or who["kind"] not in ("pc", "npc"):
                    raise LedgerError("`!chronicle <character>` - the story as they lived it.")
                if not admin and (not mine or who["id"] != mine["id"]):
                    raise LedgerError("Your own character's chronicle is yours to read - anyone else's is for the "
                                      "campaign owner (it spoils their secrets).")
                return who, chronicle.save(g, who["id"])
            async with self.ch.typing():
                who, text = await self.run(tell)
            cards = [{"title": f"📖 {who['name']}'s story" if i == 0 else None, "description": part, "color": 0xC9A227}
                     for i, part in enumerate(chunks(text, 3900))]
            try:
                await self.ch.dm_cards(uid, cards)
                await react("📬")
            except Exception:
                await self.ch.send("I couldn't DM you the chronicle - `/chronicle` shows it privately right here.")
        elif cmd == "menus":
            if hasattr(self.ch, "menus_demo"):
                await self.ch.menus_demo()
            else:
                await self.ch.send("The interactive menus only work in Discord.")
        elif cmd == "roles":
            await self.ch.send(title="🧬 What you can play", description=chargen.options_text()
                               + "\n\n`!newchar` builds one with the GM  ·  `!pregen [concept]` rolls one up for you",
                               color=0x8E44AD)
        elif cmd == "characterledger":
            await self.character_ledger(uid, uname, rest, text[1:].split(None, 1)[0].lower() == "checkout", admin)
        elif cmd == "ooc":
            return
        elif cmd in ("go", "wait", "pass"):
            note = await self.turn_button(uid, cmd)
            if note:
                await self.ch.send(f"<@{uid}> {note}")
            else:
                await react({"go": "⏩", "wait": "✋", "pass": "💤"}[cmd])
        elif cmd == "join":
            await self._join(uid, uname, rest)
        elif cmd == "gm":
            await self.gm_aside(uid, uname, rest, react)
        elif cmd == "reportbug":
            await self.report_bug(uid, uname, rest)
        elif cmd in ("yes", "no"):
            if not await self.answer_back(uid, cmd == "yes") and not await self.vote_undo(uid, cmd == "yes"):
                await self.answer_request(uid, cmd == "yes")
        elif cmd == "newchar" and not rest and hasattr(self.ch, "build_button"):
            await self.ch.build_button(f"🧬 <@{uid}> tap below to build your runner - the form and the review are "
                                       "private to you (or use `/newchar`).")
        elif cmd == "newchar" and not rest:
            await self.start_chargen(uid, uname)
        elif cmd == "newchar":
            await self._newchar(uid, uname, rest)
        elif cmd == "leave":
            def leave():
                ch = g.character_for(self.handles.get(uid, ""))
                if ch:
                    charledger.sync(g, ch["id"])               # a ledger runner's progress goes home
                g.conn.execute("DELETE FROM players WHERE discord_id=?", (uid,))
                if ch and ch["kind"] == "pc":
                    return ch, self._park(ch)                       # a PC nobody holds steps out of the story
                return ch, f"{self._hands(g.control_of(ch['id']))}." if ch else None
            ch, now = await self.run(leave)
            await self.refresh()
            if ch:
                await self.ch.send(f"👋 <@{uid}> steps away from **{ch['name']}**.\n-# {now}")
            else:
                await react("👋")
        elif cmd == "back" and await self.answer_back(uid, True):
            pass
        elif cmd in ("afk", "back"):
            def away():
                g.conn.execute("UPDATE players SET afk=? WHERE discord_id=?", (1 if cmd == "afk" else 0, uid))
                ch = g.character_for(self.handles.get(uid, ""))
                return ch, g.control_of(ch["id"]) if ch else None
            ch, now = await self.run(away)
            await self.refresh()
            if ch and cmd == "afk":
                await self.ch.send(f"💤 <@{uid}> is away - {self._hands(now, ch['name'])}.")
            elif ch:
                await self.ch.send(f"👍 <@{uid}> is back - **{ch['name']}** is yours again.")
            else:
                await react("💤" if cmd == "afk" else "👍")
        elif cmd in ("companion", "park"):
            await self._companion(uid, rest, admin, cmd == "companion")
        elif cmd in ("dmplay", "idle"):
            await self._set_control(uid, rest, "gm" if cmd == "dmplay" else "idle")
        elif cmd == "companions":
            if rest.lower() in ("on", "off"):
                await self.run(g.set_companions, rest.lower() == "on")
            on = (await self.run(g.companions)) == "gm"
            await self.ch.send("🎭 Companions **on** - while a player is `!afk`, the GM plays their character." if on
                               else "🎭 Companions **off** - an `!afk` player's character hangs back quietly.")
        elif cmd == "stuck":
            await self.report_stuck(uid, uname, rest)
        elif cmd == "matrixhelp":
            await self.ch.send_cards(matrix_help_cards(self.colors_on()))
        elif cmd == "combathelp":
            await self.ch.send_cards(combat_help_cards(self.colors_on()))
        elif cmd == "net" or (cmd == "map" and rest.lower().startswith("matrix")):
            words = rest.split()[1:] if cmd == "map" else rest.split()
            gm = admin and "gm" in (w.lower() for w in words)
            name = " ".join(w for w in words if w.lower() != "gm") if admin else ""   # players see their own decker's
            def draw():
                who = L.find(name) if name else g.character_for(self.handles.get(uid, ""))
                if not who and gm and not name:               # the owner isn't playing: whoever's been jacked in
                    who = next((e for k in ("pc", "npc") for e in L.entities(kind=k) if netmap.host_for(g, e["id"])), None)
                if not who:
                    raise LedgerError(f"No character '{name}'." if name else "You're not playing anyone - `!join` first.")
                return str(netmap.render(g, who["id"], gm=gm)), netmap.host_for(g, who["id"])
            path, hid = await self.run(draw)
            card = {"title": f"🕸️ {(L.get(hid) or {}).get('name', 'Matrix')}", "color": 0x50DCFF, "image": path,
                    "footer": "!matrixhelp - what you can do in here"}
            if gm:
                await self.ch.dm_cards(uid, [card | {"title": card["title"] + " (GM view)"}])
                await react("📬")
            else:
                await self.ch.send_cards([card])
        elif cmd == "map":
            view = rest.lower().split()[0] if rest else "metro"
            if view in ("gm", "restyle") and not admin:
                await self.ch.send("That one's for the campaign owner.")
                return
            if view == "restyle":
                from ..art import provider_from_env
                await self.ch.send("🗺️ Repainting the metroplex map (about half a minute)...")
                await self.loop.run_in_executor(None, maps.restyle, provider_from_env())
                view = "metro"
            path = await self.run(maps.render, g, "here" if view == "here" else "metro", view == "gm")
            card = {"title": "🗺️ " + ("Close up" if view == "here" else "Seattle Metroplex"), "color": LOCATION,
                    "image": str(path), "footer": await self.run(g.clock_line)}
            if view == "gm":
                await self.ch.dm_cards(uid, [card | {"title": "🗺️ The whole board (GM eyes only)"}])
                await react("📬")
            else:
                await self.ch.send_cards([card])
        elif cmd in ("rulings", "ruling") and rest.lower() in ("tidy", "review"):
            from ..dm import canon
            if rest.lower() == "review":
                text = await self.side(canon.review_text)
                text = text or ("Nothing to tidy - the last read-back found every standing ruling still needed.\n"
                                "-# `!reconcile` (owner) reads the story back now")
                await self.ch.send(title="⚖️ Rulings review", description=text[:EMBED_LIMIT], color=0xC9A227)
            elif not admin:
                await self.ch.send("Tidying the rulings is for the campaign owner - `!rulings review` shows what "
                                   "would go.")
            else:
                gone = await self.side(canon.tidy_rulings, uid)
                await self.ch.send(f"📜 Dropped {', '.join(f'**{r}**' for r in gone)} - the engine handles them now, "
                                   "or their moment passed." if gone else "Nothing to tidy right now.")
        elif cmd == "narrative":                          # the table steering the story (narrative.py)
            await self.narrative_cmd(uid, uname, rest, admin)
        elif cmd == "reconcile":
            if self.kick_canon(force=True):
                self.kick_frame(force=True)                     # (it waits for the canon, then frames the scene)
                await self.ch.send("📚 Reading the whole story back to reconcile it - a minute or two; play on.")
            else:
                await self.ch.send("📚 A read-back is already running.")
        elif cmd == "frame":
            from ..dm import frame
            if rest.lower() in ("now", "redo", "refresh", "again"):
                started = self.kick_frame(force=True)
                await react("🎬" if started else "⏳")
                return
            text = await self.run(lambda: frame.render(frame.current(g), g))
            await self.ch.dm(uid, "**The scene frame** (GM eyes only - spoilers!)\n```\n" + text.replace("```", "``")
                             + "\n```")
            await react("📬")
        elif cmd == "canon":
            from ..dm import canon
            await self.ch.dm(uid, "**The canon** (GM eyes only - spoilers!)\n```\n"
                             + (await self.run(lambda: canon.render(canon.current(g)))).replace("```", "``")
                             + "\n```")
            await react("📬")
        elif cmd == "doubts":                             # where the record doesn't add up (doubts.py) - GM eyes
            from ..dm import doubts
            await self.ch.dm(uid, "**Doubts** - where the record doesn't add up (GM eyes only - spoilers!)\n```\n"
                             + (await self.run(doubts.render, g)).replace("```", "``") + "\n```")
            await react("📬")
        elif cmd == "rulings" or (cmd == "ruling" and not rest):     # (rulings never wait on the GM: see side())
            await self.ch.send(title="📜 Table rulings", description=await self.side(rulings.listing), color=0xC9A227)
        elif cmd == "ruling":
            verb, _, tail = rest.partition(" ")
            verb, tail = verb.lower(), tail.strip()
            if verb in ("edit", "drop") and not admin:
                await self.ch.send("Editing and dropping rulings is for the campaign owner - `!ruling veto R#` objects.")
                return
            later = "\n-# The GM's mid-turn - this applies from its next reply." if self.director.resolving else ""
            if verb == "add":
                r = await self.side(rulings.add, tail, "owner" if admin else f"player:{uid}")
                await self.ch.send(f"📜 **{r['id']}** {r['text']}  -# `!ruling veto {r['id']}` to object" + later)
            elif verb == "veto":
                r = await self.side(rulings.retire, tail.split()[0] if tail else "", "vetoed", uid)
                await self.ch.send(f"📜 **{r['id']}** vetoed by <@{uid}> - the GM won't use it." + later)
            elif verb == "drop":
                r = await self.side(rulings.retire, tail.split()[0] if tail else "", "dropped", uid)
                await self.ch.send(f"📜 **{r['id']}** dropped." + later)
            elif verb == "edit":
                rid, _, text = tail.partition(" ")
                r = await self.side(rulings.add, text, "owner", rid)
                await self.ch.send(f"📜 **{r['id']}** (revises {r['replaces']}): {r['text']}" + later)
            elif verb in ("help", "?"):
                await self.ch.send("`!rulings` · `!ruling add <text>` · `!ruling veto R#` · `!ruling <question>` asks "
                                   "the GM to rule · owner: `!ruling edit R# <text>` / `!ruling drop R#`")
            else:
                await self.ruling_request(uid, rest, react)
        elif cmd == "dividers":
            if rest.lower() in divider.STYLES:
                if not admin:
                    await self.ch.send("That one's for the campaign owner.")
                    return
                await self.run(g.ledger.set_meta, "dividers", rest.lower())
            style = await self.run(g.ledger.meta, "dividers", "picture")
            await self.ch.send(f"Turn dividers: **{style}**  -# `!dividers picture | line | off` (owner)")
        elif cmd == "colors":
            if rest.lower() in ("on", "off"):
                if not admin:
                    await self.ch.send("That one's for the campaign owner.")
                    return
                await self.run(g.ledger.set_meta, "colors", rest.lower())
            await self.ch.send(f"🎨 Coloured roll cards and help are **{'on' if self.colors_on() else 'off'}**"
                               "  -# `!colors on | off` (owner) - off if someone's phone shows codes like `[1;32m`")
        elif cmd == "voices":
            if rest.lower() in ("on", "off"):
                if not admin:
                    await self.ch.send("That one's for the campaign owner.")
                    return
                await self.run(g.ledger.set_meta, "voices", rest.lower())
            await self.ch.send(f"🎙️ NPC voices are **{'on' if self.voices_on() else 'off'}**"
                               + ("" if hasattr(self.ch, "voice") else " (not available in this channel)") + ".")
        elif cmd == "advance":
            if not rest:
                await self.ch.send("`!advance <#>` - the numbers are on your `!charactersheet`.")
                return
            def spend():
                ch = g.character_for(self.handles.get(uid, ""))
                if not ch:
                    raise LedgerError("You're not playing anyone yet.")
                return g.advance(ch["id"], rest)
            res = await self.run(spend)
            await self.ch.send(f"📈 {res['card'][len('[KARMA] '):]}")
        elif cmd == "karma":
            words = rest.split()
            if len(words) >= 2 and admin:
                def give():
                    ch = L.find(words[0])
                    if not ch:
                        raise LedgerError(f"No character '{words[0]}'.")
                    return sr_lite.award_karma(L, g.turn_no(), ch["id"], int(words[1]), " ".join(words[2:]))
                try:
                    line = await self.run(give)
                except ValueError:
                    await self.ch.send("`!karma <character> <+N> [reason]`")
                    return
                await self.ch.send(f"✨ {line[len('[KARMA] '):]}")
            else:
                def totals():
                    return " · ".join(f"**{p['name']}** {int(L.stat(p['id'], 'karma'))}" for p in L.entities(kind="pc"))
                await self.ch.send(f"✨ Karma: {await self.run(totals)}")
        elif cmd in ("charactersheet", "cs", "character"):
            def build():
                ch = L.find(rest) if rest and admin else g.character_for(self.handles.get(uid, ""))
                return charsheet.image_cards(g, ch["id"]) if ch else None
            cards = await self.run(build)
            if not cards:
                await self.ch.send("You're not playing anyone yet - `!join <character>` first.")
                return
            await self.ch.dm_cards(uid, cards)
            await react("📬")
        elif cmd == "textsheet":
            def sheet():
                pc = L.find(rest) if rest and admin else g.character_for(self.handles.get(uid, ""))
                return sr_lite.sheet(L, pc["id"]) if pc else "You're not playing anyone yet."
            await self.ch.dm(uid, f"```\n{await self.run(sheet)}\n```")
            await react("📬")
        elif cmd == "askdm":
            handle = self.handles.get(uid)
            if not handle:
                await self.ch.send("Join a character first (`!join <name>`).")
                return
            await react("🤔")
            answer = await self.run(g.askdm, handle, rest)
            await self.ch.dm(uid, f"**You asked:** {rest}\n{answer}")
            await react("📬")
        elif cmd == "who":
            def who():
                played_by = {}                                   # character id -> discord id
                for discord_id, handle in self.handles.items():
                    ch = g.character_for(handle)
                    if ch:
                        played_by[ch["id"]] = discord_id
                lines = []
                for eid in L.roster(g.current_scene_id()):
                    e = L.get(eid)
                    if not e or e["kind"] not in ("pc", "npc"):
                        continue
                    mode = g.control_of(eid)
                    if eid in played_by:
                        tag = f" (<@{played_by[eid]}>{', away' if mode != 'player' else ''})"
                    elif e["kind"] == "pc":
                        tag = " (GM-played companion)" if mode == "gm" else " (idle)"
                    else:
                        tag = ""
                    lines.append(f"**{e['name']}**{tag} - {sr_lite.condition_line(L, eid)}")
                return lines
            lines = await self.run(who)
            waiting = self.director.waiting_on() if self.director.queue else set()
            tail = f"\n*Waiting on: {', '.join(sorted(waiting))}*" if waiting else ""
            await self.ch.send("\n".join(lines) + tail)
        elif cmd == "scene":
            await self.scene_header()
        elif cmd == "recap":
            await self.post_recap()
        elif cmd == "party":
            await self.post_party()
        elif cmd == "dossier":
            await self.post_dossier(rest)
        elif cmd == "time":
            if rest and not admin:
                await self.ch.send("Only the campaign owner can set the clock.")
                return
            if rest:
                try:
                    await self.run(lambda: g.set_clock(clock.parse(rest, g.clock())))
                except ValueError as exc:
                    await self.ch.send(f"⚠️ {exc}")
                    return
            await self.ch.send(f"🕒 {await self.run(g.clock_line)}")
        elif cmd == "settings":
            t = self.director
            await self.ch.send(f"{await self.run(g.settings_line)} | timers: wait {t.wait:.0f}s, cap {t.cap:.0f}s, "
                               f"grace {t.grace:.0f}s | art {'on' if g.art.active else 'off'}")
        elif cmd in ("gmmodel", "gmeffort", "difficulty"):
            if rest:
                fn = {"gmmodel": g.set_dm_model, "gmeffort": g.set_dm_effort}.get(cmd)
                if fn:
                    await self.run(fn, rest)
                else:
                    d = await self.run(g.set_difficulty, rest.split())
                    await self.ch.send(f"*{d.get('stance', '')}*")
            await self.ch.send(await self.run(g.settings_line))
        elif cmd == "timer":
            parts = rest.split()
            if len(parts) == 2 and parts[0] in ("wait", "quiet", "cap", "grace") and parts[1].isdigit():
                setattr(self.director, "wait" if parts[0] == "quiet" else parts[0], float(parts[1]))
                await react("⏱️")
            else:
                await self.ch.send("`!timer wait 30` (how long the others get once someone acts) / `!timer cap 300` / "
                                   "`!timer grace 4`")
        elif cmd == "undo":
            target = await self.run(g.undo_target)
            if target and target["private"] and rest.lower() != "whisper":
                await self.ch.send("↩️ The last turn was a private one. Its player can `!undo` it in DMs, "
                                   "or `!undo whisper` takes it back from here.")
                return
            if not admin:                                 # a player asks the table
                await self._ask_undo(uid, uname, target)
                return
            await self._undo_now()
        elif cmd == "pov":
            def pov():
                ent = L.find(rest)
                if not ent:
                    return "No such NPC."
                from ..dm import world
                lines = [f"**{ent['name']}** (GM eyes only)"]
                if world.persona_line(ent):
                    lines.append(f"Persona: {world.persona_line(ent)}")
                lines += [f"Agenda [{a['id']}]: {a['goal']} ({a['steps']} step(s))" for a in world.agendas_of(g, ent["id"])]
                att = {k.split(':', 1)[1]: v for k, v in L.stats(ent["id"]).items() if k.startswith("attitude:")}
                if att:
                    lines.append("Attitudes: " + ", ".join(f"{(L.get(k) or {}).get('name', k)} {int(v):+d}"
                                                           for k, v in att.items()))
                lines += [f"Believes: {b['text']}" for b in g.sub.beliefs_of(ent["id"])[:4]]
                lines += [f"Heard ({h['how']}): {h['text'][:160]}" for h in g.sub.heard(ent["id"], 4)]
                lines += [f"Note: {n['text'][:200]}" for n in g.sub.notes_for(ent["id"], 3)]
                return "\n".join(lines)
            await self.ch.dm(uid, await self.run(pov))
            await react("📬")
        elif cmd == "world":
            from ..dm import world
            if rest.lower() in ("on", "off"):
                await self.run(g.set_world, rest.lower() == "on")
                await self.ch.send(f"🌍 Offscreen world **{rest.lower()}**.")
                return
            await self.ch.dm(uid, "**The world in motion** (GM eyes only - spoilers!)\n"
                                  + await self.run(world.summary, g))
            await react("📬")
        elif cmd == "minds":
            from ..dm.minds import reflect_scene
            made = await self.run(lambda: reflect_scene(g, g.current_scene_id(), g.turn_no()))
            await react("🧠" if made else "🤷")
        elif cmd == "rename":
            who, eq, new = rest.partition("=")
            if not eq or not who.strip() or not new.strip():
                await self.ch.send("`!rename <who> = <new name>` - the old name stays on file as an alias.")
                return

            def rename():
                ent = g.find_speaker(who.strip(), g.current_scene_id()) or L.find(who.strip())
                if not ent:
                    raise LedgerError(f"No one called '{who.strip()}'.")
                return speakers.rename(g, ent["id"], new, g.turn_no())
            await self.ch.send(f"📇 {await self.run(rename)}.")
        elif cmd == "merge":
            parts = rest.split()
            if len(parts) != 2:
                await self.ch.send("`!merge <keep> <drop>`")
                return
            await self.ch.send(await self.run(g.merge_entities, parts[0], parts[1], g.turn_no()))
        elif cmd == "art":
            await self._art(rest, admin, react)
        elif cmd == "graph":
            if self.graph_server is None:
                from ..browser.server import serve
                port = int(rest) if rest.isdigit() else 8765
                self.graph_server = serve(g.path, port, background=True)
            port = self.graph_server.server_port
            await self.ch.send(f"Graph browser is running on the host machine: http://127.0.0.1:{port} · "
                               f"fly it in 3D: http://127.0.0.1:{port}/graph3d (or the dashboard's Memory page)")
        elif cmd == "cost":
            u = g._llm.usage if g._llm else None
            total = await self.run(g.ledger.total_cost)
            await self.ch.send(f"This run: ${u.total:.3f} over {u.calls} calls · campaign turns total ${total:.3f}"
                               if u else f"Campaign turns total ${total:.3f}")
        elif cmd == "seed":                                # a story read into the world (seed.py)
            from .. import seed
            await seed.command(self, uid, uname, rest, admin)
        else:
            guess = difflib.get_close_matches(cmd, COMMANDS, n=1, cutoff=0.6)
            await self.ch.send(f"❓ No `!{cmd}`" + (f" - did you mean `!{guess[0]}`?" if guess else "") + " (`!help` lists them)")

    @staticmethod
    def _hands(mode: str | None, name: str | None = None) -> str:
        """What happens to a character nobody is driving: the GM plays them, or they hang back."""
        if mode == "gm":
            return f"the GM plays {f'**{name}**' if name else 'them'} for now"
        return f"{f'**{name}**' if name else 'they'} will hang back quietly"

    def _park(self, ent: dict | None) -> str | None:
        """The character someone just left (game thread): a PC steps out of the story - nobody plays them, and the
        GM leaves them be - unless they're a companion. Returns the line saying so."""
        g = self.game
        if not ent or ent["kind"] != "pc":
            return None
        if g.control_of(ent["id"]) == "gm":
            return f"**{ent['name']}** stays with the crew - the GM plays them."
        sid = g.ledger.scene_of(ent["id"])
        if sid is not None:
            g.ledger.leave(sid, [ent["id"]])
        return (f"**{ent['name']}** steps out of the story for now - `!join {ent['name']}` to switch back, or "
                f"`!companion {ent['name']}` to have the GM play them.")

    async def _companion(self, uid: str, name: str, admin: bool, gm: bool) -> None:
        """`!companion <name>`: the GM plays them (you give up your seat if it's yours). `!park <name>`: they step out
        of the story - nobody plays them. Yours, one you made, or (the owner) anyone's; `!join` takes them back."""
        g, L = self.game, self.game.ledger
        if not name:
            await self.ch.send("`!companion <name>` - the GM plays them  ·  `!park <name>` - they step out of the "
                               "story  ·  `!join <name>` takes one back")
            return

        def hand():
            try:
                here = g.current_scene_id()
            except LedgerError:
                here = None
            ent = g.find_speaker(name, here) or L.find(name)
            if not ent or ent["kind"] != "pc":
                raise LedgerError(f"No player character called '{name}' in this world.")
            seat = g.conn.execute("SELECT discord_id FROM players WHERE handle=?", (ent["player"],)).fetchone()
            if seat and seat["discord_id"] != uid and not admin:
                raise LedgerError(f"<@{seat['discord_id']}> is playing {ent['name']} - only they (or the campaign "
                                  "owner) can hand them over.")
            r = charledger.get(g, ent["name"])
            if not seat and not admin and r and r["owner_id"] != uid:
                raise LedgerError(f"{ent['name']} is {r['owner_name'] or 'someone else'}'s to hand over.")
            if seat:
                g.conn.execute("DELETE FROM players WHERE handle=?", (ent["player"],))
            g.set_control(ent["id"], "gm" if gm else "idle")
            sid = L.scene_of(ent["id"])
            if gm and here is not None and sid != here:
                g.enter_scene([ent["id"]], g.turn_no())       # a companion is with the crew
            elif not gm and sid is not None:
                L.leave(sid, [ent["id"]])
            return ent
        ent = await self.run(hand)
        await self.refresh()
        await self.ch.send(f"🎭 **{ent['name']}** is a companion now - the GM plays them. `!join {ent['name']}` takes "
                           "them over any time." if gm else
                           f"🅿️ **{ent['name']}** steps out of the story for now - `!join {ent['name']}` or "
                           f"`!companion {ent['name']}` brings them back.")

    async def _join(self, uid: str, uname: str, who: str, handed: bool = False) -> None:
        """Take a seat: a PC (yours, an absent friend's, or one the GM has been playing) or an NPC in the
        scene. One seat per person - switching hands the old character to the GM (or idle)."""
        g, L = self.game, self.game.ledger
        prev_handle = self.handles.get(uid, "")
        if not who:
            await self.ch.send("`!join <character>` - a PC, or an NPC who's in this scene.")
            return

        def claim():
            ent = L.pc_for_player(who) or L.find(who)
            if not ent or ent["kind"] not in ("pc", "npc"):
                names = ", ".join(p["name"] for p in L.entities(kind="pc"))
                raise LedgerError(f"No character '{who}'. PCs: {names or 'none yet - try !newchar'} "
                                  "(or step into an NPC who's in this scene).")
            if ent["kind"] == "npc" and ent["id"] not in L.roster(g.current_scene_id()):
                raise LedgerError(f"{ent['name']} isn't in this scene - you can step into someone who's here.")
            if ent["kind"] == "pc" and not ent["player"]:
                g.conn.execute("UPDATE entities SET player=? WHERE id=?", (ent["id"], ent["id"]))
                ent = L.get(ent["id"])
            handle = ent["player"] if ent["kind"] == "pc" else ent["id"]
            taken = g.conn.execute("SELECT discord_id FROM players WHERE handle=? AND discord_id<>?",
                                   (handle, uid)).fetchone()
            if taken:                                  # someone's seat: only they can give it up
                return "taken", ent, taken["discord_id"]
            before = g.control_of(ent["id"])
            prev = g.character_for(prev_handle) if prev_handle else None
            g.conn.execute("INSERT OR REPLACE INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)",
                           (uid, handle, uname))
            g.conn.execute("DELETE FROM control WHERE entity_id=?", (ent["id"],))  # leaving restores the default
            if L.scene_of(ent["id"]) is None:
                g.enter_scene([ent["id"]], g.turn_no())
            switched = prev if prev and prev["id"] != ent["id"] else None
            after = self._park(switched) if switched else None
            return "seated", ent, before, switched, after, g.catch_up(ent["id"])
        res = await self.run(claim)
        if res[0] == "taken":
            await self._request_seat(uid, uname, res[1], res[2])
            return
        ent, before, switched, after, brief = res[1:]
        await self.refresh()
        if handed:                                    # (a player just gave them up - see answer_request)
            line = f"🎲 <@{uid}> is playing **{ent['name']}**."
        elif ent["kind"] == "npc":
            line = f"🎭 <@{uid}> steps into **{ent['name']}** - the GM hands them over."
        elif before == "gm":
            line = f"🎭 <@{uid}> takes over **{ent['name']}** from the GM."
        else:
            line = f"🎲 <@{uid}> is playing **{ent['name']}**."
        if switched and after:
            line += f"\n-# {after}"
        await self.ch.send(line)
        try:
            await self.ch.dm(uid, f"**You're playing {ent['name']}.** Here's where they're at:\n```\n{brief}\n```")
        except Exception as exc:                          # (closed DMs: the seat still counts)
            print(f"[join] couldn't DM {uid} the catch-up: {exc}", flush=True)

    # ── character creation: a guided build in the player's DMs (chargen_flow.py) ──
    async def chargen_for(self, uid: str) -> Chargen | None:
        if uid in self.chargens:
            return self.chargens[uid]
        d = await self.run(load_draft, self.game, uid)          # (a bot restart mid-build picks up here)
        if d:
            self.chargens[uid] = Chargen(self, uid, d.get("uname") or uid, d)
        return self.chargens.get(uid)

    async def start_chargen(self, uid: str, uname: str) -> None:
        building = await self.chargen_for(uid)
        if building:
            await self.ch.dm(uid, f"Picking up where you left off{' with ' + building.d['name'] if building.d['name'] else ''}"
                                  " - `cancel` to start over.")
        else:
            d = chargen.new_draft()
            d["uname"] = uname
            building = self.chargens[uid] = Chargen(self, uid, uname, d)
        try:
            await building.show()
        except Exception as exc:                          # (Discord refuses DMs when a player has them off)
            self.chargens.pop(uid, None)
            print(f"[chargen] couldn't DM {uid}: {exc}", flush=True)
            await self.ch.send(f"<@{uid}> I couldn't DM you - turn on *Allow direct messages from server members* "
                               "for this server (Privacy Settings), then `!newchar` again.")
            return
        if not building.d["concept"] and building.d["step"] == "concept":
            await self.ch.send(f"🧬 <@{uid}> is building a new runner with the GM - check your DMs.")

    # ── the character ledger: runners that travel between worlds (charledger.py) ──
    async def character_ledger(self, uid: str, uname: str, rest: str, checkout_alias: bool = False,
                               admin: bool = False) -> None:
        g = self.game
        verb, _, arg = rest.partition(" ")
        verb, arg = verb.lower(), arg.strip()
        if checkout_alias:                                 # `!checkout Rage`
            verb, arg = "checkout", rest.strip()
        try:
            if verb in ("checkout", "out", "take"):
                await self._ledger_checkout(uid, uname, arg)
            elif verb in ("return", "in", "checkin"):
                await self._ledger_return(uid)
            elif verb == "save":
                await self._ledger_save(uid, uname)
            elif verb in ("share", "unshare"):
                r = await self.run(charledger.set_shared, g, arg, uid, verb == "share")
                await self.ch.send(f"📒 **{r['name']}** " + ("can now be checked out by anyone." if verb == "share"
                                                            else "is yours alone again."))
            elif verb == "release":
                r = await self.run(charledger.release, g, arg, uid, admin)
                await self.ch.send(f"📒 **{r['name']}** is back on the shelf (last saved progress stands).")
            elif verb in ("hide", "unhide", "restore"):
                r = await self.run(charledger.set_hidden, g, arg, uid, verb == "hide", admin)
                await self.ch.send(f"📒 **{r['name']}** is put away - off the list, nothing lost. "
                                   f"`!characterledger unhide {r['name']}` brings them back." if verb == "hide" else
                                   f"📒 **{r['name']}** is back on the list.")
            elif verb == "hidden":
                rows = await self.run(charledger.runners, g, True)
                await self.ch.send(title="📒 Put away", color=0x95A5A6, description=(
                    "\n".join(f"• {charledger.summary(r)}" for r in rows) or "Nobody's hidden.")
                    + "\n-# `!characterledger unhide <name>` brings one back")
            elif rest.strip():
                await self._ledger_card(rest.strip())
            else:
                rows = await self.run(charledger.runners, g)
                away = len(await self.run(charledger.runners, g, True))
                body = "\n".join(f"• {charledger.summary(r)}" for r in rows) or (
                    "Empty so far - runners land here when you make them (`!newchar`, `!pregen`) or save them "
                    "(`!characterledger save`).")
                await self.ch.send(title="📒 The Character Ledger", color=0xC9A227, description=(
                    body + "\n\n`!characterledger checkout <name>` bring one into this world  ·  `return` send yours "
                    "back to the shelf  ·  `save` save your progress  ·  `share <name>` let anyone play yours  ·  "
                    "`<name>` see their file  ·  `hide <name>` put one away (nothing's deleted)"
                    + (f"  ·  `hidden` the {away} put away" if away else "")
                    + "\n-# A runner plays in one world at a time; what they earn comes home "
                    "with them, and the story they lived becomes backstory."))
        except LedgerError as exc:
            await self.ch.send(f"⚠️ {exc}")

    async def _ledger_card(self, name: str) -> None:
        r = await self.run(charledger.get, self.game, name)
        if not r:
            await self.ch.send(f"No {name} in the character ledger.")
            return
        st = r["data"]["stats"]
        attrs = "  ".join(f"**{sr_lite.ABBR[a]}** {int(st[a])}" for a in sr_lite.ATTRIBUTES if st.get(a))
        skills = ", ".join(f"{sr_lite.nice(k)} {int(v)}" for k, v in sorted(st.items(), key=lambda kv: -kv[1])
                           if k in sr_lite.SKILLS and v)
        gear = ", ".join(i["name"] + (f" ×{i['qty']}" if i["qty"] > 1 else "") for i in r["data"]["items"])
        past = "\n".join(f"*{b['world']}:* {b['text']}" for b in r["backstory"][-3:])
        await self.ch.send_cards([{"title": f"📒 {r['name']}", "color": 0xC9A227, "thumbnail": r["portrait"],
                                   "description": (charledger.summary(r) + f"\n{r['data']['description']}\n\n{attrs}\n"
                                                   f"{skills}\n**Kit:** {gear or 'nothing'}"
                                                   + (f"\n\n**Before:**\n{past}" if past else ""))[:EMBED_LIMIT],
                                   "footer": f"!characterledger checkout {r['name']}"}])

    async def _ledger_checkout(self, uid: str, uname: str, name: str) -> None:
        g = self.game
        if not name:
            await self.ch.send("`!characterledger checkout <name>` - `!characterledger` lists who's on the shelf.")
            return

        def go():
            eid, back = charledger.check_out(g, name, uid, g.turn_no())
            ent = g.ledger.get(eid)
            holder = g.conn.execute("SELECT discord_id FROM players WHERE handle=? AND discord_id<>?",
                                    (ent["player"], uid)).fetchone()
            if holder:
                return ent, holder["discord_id"], back
            g.conn.execute("INSERT OR REPLACE INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)",
                           (uid, ent["player"], uname))
            g.conn.execute("DELETE FROM control WHERE entity_id=?", (eid,))
            if g.ledger.scene_of(eid) is None:
                g.enter_scene([eid], g.turn_no())
            return ent, None, back
        ent, holder, back = await self.run(go)
        if holder:                                        # someone's already playing them here: ask
            await self._request_seat(uid, uname, ent, holder)
            return
        await self.refresh()
        later = "" if await self.run(self._started) else "\n-# When everyone has a runner: `!begin`."
        await self.ch.send(f"📒 <@{uid}> checks **{ent['name']}** out of the character ledger"
                           + (" - back in this world." if back else ".") + later)
        await self.ch.dm_cards(uid, await self.run(charsheet.image_cards, g, ent["id"]))

    async def _ledger_return(self, uid: str) -> None:
        g = self.game

        def go():
            ch = g.character_for(self.handles.get(uid, ""))
            if not ch:
                raise LedgerError("You're not playing anyone.")
            if not charledger.linked(g, ch["id"]):
                raise LedgerError(f"{ch['name']} isn't in the character ledger - `!characterledger save` puts them there.")
            story = charledger.check_in(g, ch["id"])
            return ch, int(g.ledger.stat(ch["id"], "karma")), story
        async with self.ch.typing():
            ch, karma, story = await self.run(go)
        await self.refresh()
        await self.ch.send(f"📒 **{ch['name']}** heads back to the character ledger with {karma} karma."
                           + (f"\n*{story}*" if story else ""))

    async def _ledger_save(self, uid: str, uname: str) -> None:
        g = self.game

        def go():
            ch = g.character_for(self.handles.get(uid, ""))
            if not ch or ch["kind"] != "pc":
                raise LedgerError("You're not playing a runner - only player characters go in the ledger.")
            if charledger.linked(g, ch["id"]):
                charledger.sync(g, ch["id"])
                return ch, False
            charledger.register(g, ch["id"], uid, uname)
            return ch, True
        ch, new = await self.run(go)
        await self.ch.send(f"📒 **{ch['name']}** " + ("is in the character ledger now - yours to take into any world."
                                                     if new else "- progress saved to the character ledger."))

    def check_in_all(self) -> list[str]:
        """A world is being archived: every ledger runner in it goes home, with their story as backstory."""
        g, done = self.game, []
        for pc in g.ledger.entities(kind="pc"):
            if charledger.linked(g, pc["id"]) and pc["status"] != "departed":
                try:
                    charledger.check_in(g, pc["id"])
                    done.append(pc["name"])
                except LedgerError:
                    pass
        return done

    # ── a new party in the same world (newparty.py): the owner's `!rp newparty`, after its ✅ ──
    def _hold_still(self) -> str | None:
        """Why the table can't change crews this second (None: it can) - and the background passes stop: a world
        pass planned before the skip would land after it."""
        if self.director.resolving or self.director.queue:
            return "The GM's mid-turn (or a turn is waiting) - once it lands, ask again."
        for task in (self.world_task, self.canon_task, self.frame_task):
            if task is not None and not task.done():
                task.cancel()
        return None

    def _forget_old_table(self) -> None:
        """The crew changed (a new party, or one taken back): the cards waiting on the old seats go - a "back in?"
        answered after it queued a post with no handle and crashed the turn (review 2026-10-27), and a seat request
        or an undo vote was about seats and turns that aren't the table's any more."""
        self.comebacks.clear()
        self.requests.clear()
        self.undo_votes.clear()

    async def new_party(self, uid: str, gap: int, label: str, ending: str = "") -> dict | None:
        """The reset itself (on the game thread), then the table's card, the owner's summary by DM, and a canon
        read-back in the background so the GM's record knows the crew changed. Returns the result, or None."""
        g = self.game
        why = self._hold_still()
        if why:
            await self.ch.send(f"⚠️ {why}")
            return None
        self.paused = True                                # (no await before this: a post in that gap became a turn)
        try:
            await self.ch.send(f"⏳ The old crew go their separate ways and the story skips {newparty.in_words(label)} "
                               "- the world is catching up (a minute or two; the table waits).")
            async with self.ch.typing():
                res = await self.run(lambda: newparty.run(g, gap, label, ending=ending))
            self._forget_old_table()
        except LedgerError as exc:
            await self.ch.send(f"⚠️ {exc}")
            return None
        except Exception as exc:
            flags.record(g, "engine", "new party failed", f"{type(exc).__name__}: {str(exc)[:500]}")
            await self.ch.send(f"⚠️ The new party didn't go through ({type(exc).__name__}: {str(exc)[:200]}) - the "
                               "world is as it was (put back from the backup).")
            return None
        finally:
            self.paused = False
            await self.refresh()
        await self.ch.send_cards([await self.run(newparty.card, g, res["record"])])
        if hasattr(self.ch, "build_button"):
            await self.ch.build_button("📝 Tap to build your runner (or type `/newchar`) - the form is private to you.")
        old = ", ".join(f"**{o['name']}**" for o in res["crew"]) or "nobody"
        are = "is" if len(res["crew"]) == 1 else "are"
        await self.ch.send(f"♻️ New party ready - {old} {are} the GM's now. Backup: `{res['record']['backup']}`\n"
                           "-# `!rp newparty undo` takes it back until the new crew's first turn · the owner has the "
                           "details by DM")
        try:
            await self.ch.dm(uid, await self.run(newparty.owner_text, g, res))
        except Exception as exc:                          # (closed DMs: the channel line above has the backup)
            print(f"[{g.path.stem}] new party: couldn't DM the owner the summary: {exc}", flush=True)
        self.kick_canon(force=True)                       # (the record's people and threads, read back with the crew changed)
        return res

    async def undo_new_party(self, uid: str) -> dict | None:
        """`!rp newparty undo`, after its ✅: the backup back in place - the old crew at the table again."""
        g = self.game
        why = self._hold_still()
        if why:
            await self.ch.send(f"⚠️ {why}")
            return None
        self.paused = True
        try:
            rec = await self.run(newparty.undo, g)
            self._forget_old_table()
        except LedgerError as exc:
            await self.ch.send(f"⚠️ {exc}")
            return None
        finally:
            self.paused = False
            await self.refresh()
        old = ", ".join(f"**{o['name']}**" for o in rec["old_crew"]) or "the old crew"
        notes = rec.get("ledger_notes") or []
        await self.ch.send(f"↩️ The new party is taken back - {old} are back at the table, {clock.fmt(rec['clock_from'])}"
                           f" (from `{rec['backup']}`)." + "".join(f"\n-# 📒 {n}" for n in notes))
        await self.scene_header()
        return rec

    async def start_pregen(self, uid: str, uname: str, concept: str) -> None:
        """The GM rolls up a whole runner from a concept (or a surprise) and hands it over for review."""
        if await self.chargen_for(uid):
            await self.ch.send(f"<@{uid}> you're already building a runner - check your DMs (`cancel` there drops it).")
            return
        d = chargen.new_draft()
        d["uname"] = uname
        building = self.chargens[uid] = Chargen(self, uid, uname, d)
        await self.ch.send(f"🎲 <@{uid}> - rolling up a runner for you. Check your DMs.")
        try:
            await building.pregen(concept)
        except Exception as exc:                          # (DMs closed)
            self.chargens.pop(uid, None)
            await self.run(lambda: self.game.ledger.set_meta(f"chargen:{uid}", ""))
            print(f"[chargen] couldn't DM {uid}: {exc}", flush=True)
            await self.ch.send(f"<@{uid}> I couldn't DM you - turn on *Allow direct messages from server members* "
                               "for this server (Privacy Settings), then try again.")

    async def finish_chargen(self, uid: str, uname: str, d: dict, reply=None) -> None:
        g = self.game

        def make():
            handle = base = d["name"].lower().replace(" ", "-")
            n = 1
            while g.conn.execute("SELECT 1 FROM players WHERE handle=?", (handle,)).fetchone() or \
                    g.ledger.pc_for_player(handle):
                n += 1
                handle = f"{base}{n}"
            if charledger.taken(g, d["name"]):
                raise LedgerError(f"There's already a {d['name']} in the character ledger - pick another name "
                                  "(`go name`).")
            eid = chargen.build(g, d, handle, g.turn_no())
            charledger.register(g, eid, uid, uname)               # player-made runners outlive the story
            g.enter_scene([eid], g.turn_no())
            parked = None
            if d.get("for_gm"):                                   # a companion: the GM plays them, you keep your seat
                g.set_control(eid, "gm")
            else:
                prev = g.character_for(self.handles.get(uid, "")) if self.handles.get(uid) else None
                g.conn.execute("INSERT OR REPLACE INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)",
                               (uid, handle, uname))
                parked = self._park(prev) if prev and prev["id"] != eid else None
            g.ledger.set_meta(f"chargen:{uid}", "")
            if g.art.active:
                g.request_art(eid)                                 # their portrait, painted now
            return eid, g.ledger.get(eid), parked
        eid, ent, parked = await self.run(make)
        self.chargens.pop(uid, None)
        await self.refresh()
        what = f"{d['metatype']} {d['role'].replace('_', ' ')}"
        later = "" if await self.run(self._started) else "\n-# When everyone has a runner: `!begin`."
        if d.get("for_gm"):
            await self.ch.send(title=f"🎭 {ent['name']} joins the crew",
                               description=f"<@{uid}>'s companion: **{ent['name']}**, {what} ({d['pronouns']}) - the "
                                           f"GM plays them.\n{ent['description']}\n-# `!join {ent['name']}` takes "
                                           f"them over · `!park {ent['name']}` sets them aside{later}", color=0x8E44AD)
        else:
            await self.ch.send(title=f"🎲 {ent['name']} joins the table",
                               description=f"<@{uid}>'s new runner: **{ent['name']}**, {what} ({d['pronouns']}).\n"
                                           f"{ent['description']}{later}"
                                           + (f"\n-# {parked}" if parked else ""), color=0x8E44AD)
        cards = await self.run(charsheet.image_cards, g, eid)
        if reply is not None:                             # (the form flow answers privately in the channel)
            await reply.send_cards(cards)
            return
        if d.get("for_gm"):
            return
        try:
            await self.ch.dm(uid, f"**{ent['name']} is in the game.** Head back to the table and tell the GM what "
                                  "they're doing - your portrait is being painted.")
            await self.ch.dm_cards(uid, cards)
        except Exception as exc:                          # closed DMs never undo a finished character
            print(f"[chargen] couldn't DM {uid} their sheet: {exc}", flush=True)

    # ── seat requests: nobody takes over a character without their player's say-so ──
    REQUEST_TTL = 900

    async def _request_seat(self, uid: str, uname: str, ent: dict, holder: str) -> None:
        now = time.time()
        self.requests = {k: r for k, r in self.requests.items()
                         if r["expires"] > now and not (r["requester"] == uid and r["entity"] == ent["id"])}
        card = {"title": f"🔐 {uname} asks to play {ent['name']}",
                "description": f"<@{holder}> is playing **{ent['name']}** - nobody takes over a character without "
                               f"their player's say-so.\n\n<@{holder}>: react ✅ to hand **{ent['name']}** to "
                               f"<@{uid}>, or ❌ to keep playing (`!yes` / `!no` work too). The ask expires in "
                               f"{self.REQUEST_TTL // 60} minutes.", "color": 0xF1C40F}
        key = None
        if hasattr(self.ch, "ask"):
            key = await self.ch.ask(f"<@{holder}>", card, ["✅", "❌"], holder=holder)
        else:
            await self.ch.send(f"<@{holder}>")
            await self.ch.send_cards([card])
        self.requests[key or f"ask{now:.6f}"] = {"requester": uid, "name": uname, "entity": ent["id"],
                                                 "ent_name": ent["name"], "holder": holder,
                                                 "expires": now + self.REQUEST_TTL}

    async def reaction(self, message_id: str, uid: str, emoji: str) -> None:
        """A ✅ or ❌ on a seat request card - only the character's player can answer it."""
        from .. import seed
        if await seed.reaction(self, message_id, uid, emoji):     # (the !seed confirm card - seed.py)
            return
        if message_id in self.comebacks and emoji in ("✅", "❌"):
            await self.answer_back(uid, emoji == "✅", message_id)
            return
        if message_id in self.undo_votes and emoji in ("✅", "❌"):
            await self.vote_undo(uid, emoji == "✅", message_id)
            return
        req = self.requests.get(message_id)
        if req and uid == req["holder"] and emoji in ("✅", "❌"):
            await self.answer_request(uid, emoji == "✅", message_id)

    async def answer_request(self, uid: str, yes: bool, key: str | None = None) -> None:
        now = time.time()
        self.requests = {k: r for k, r in self.requests.items() if r["expires"] > now}
        mine = [k for k, r in self.requests.items() if r["holder"] == uid and (key is None or k == key)]
        if not mine:
            if key is None:
                await self.ch.send("Nobody's asking for your character right now.")
            return
        k = mine[-1]                                  # the latest ask for your character
        req = self.requests.pop(k)
        if not yes:
            await self.ch.send(f"🔒 <@{uid}> keeps **{req['ent_name']}**. <@{req['requester']}> - maybe next scene.")
            return
        g = self.game

        def release():
            ent = g.ledger.get(req["entity"])
            handle = ent["player"] if ent["kind"] == "pc" else ent["id"]
            g.conn.execute("DELETE FROM players WHERE discord_id=? AND handle=?", (uid, handle))
        await self.run(release)
        await self.refresh()
        await self.ch.send(f"🤝 <@{uid}> hands **{req['ent_name']}** to <@{req['requester']}>.")
        await self._join(req["requester"], req["name"], req["ent_name"], handed=True)

    # ── whispers: private turns in DMs ──────────────────────────────────
    async def whisper(self, uid: str, text: str, reply: Channel) -> None:
        """A DM to the bot is a private turn: the GM resolves it like any other (rolls, authority and
        all) and answers in the DM. Only whoever perceived it remembers it; the public story picks up
        the consequences without revealing it."""
        g = self.game
        text = text.strip()
        if not text or text.startswith("((") or text.lower().startswith("!ooc"):
            return
        if text.lower().startswith("!newchar") and not text[8:].strip():
            await self.start_chargen(uid, getattr(reply, "name", "") or uid)
            return
        building = await self.chargen_for(uid)
        if building:
            if not await building.handle(text):
                self.chargens.pop(uid, None)
            return
        handle = self.handles.get(uid)
        if not handle:
            await reply.send("You're not playing anyone at the table yet - `!join <character>` in the game "
                             "channel first (or `!newchar` to build one), then whisper me here.")
            return
        if text.startswith("!"):
            await self._whisper_command(handle, text, reply)
            return

        def private_turn():
            ch = g.character_for(handle)
            if not ch:
                raise LedgerError("You're not playing anyone right now.")
            lines, out = [], g.out
            # (this turn's cards and notices go to the whisperer only - and never with a name they haven't learned)
            g.out = lambda x: lines.append(spoilers.card(g, x) if classify(x) != "log" else x)
            try:
                res = g.run_turn([(handle, text)], private=ch["id"])
            finally:
                g.out = out
            if res.info.get("ooc"):               # a rules question, answered: take it back out of the story
                g.undo()
            return res, lines
        try:
            async with reply.typing():
                res, lines = await self.run(private_turn)
        except LedgerError as exc:
            await reply.send(f"⚠️ {exc}")
            return
        except Exception as exc:
            await reply.send(f"⚠️ The GM fumbled that one ({type(exc).__name__}: {str(exc)[:300]}). "
                             "Nothing happened - whisper it again.")
            return
        for m in card_messages([x for x in lines if classify(x) == "card"], self.colors_on()):
            await reply.send(m)
        for x in lines:
            if classify(x) == "notice":
                await reply.send(notice_text(x))
        if res.info.get("ooc"):
            await reply.send(title="Out of character", description=res.narration[:EMBED_LIMIT], color=WHISPER,
                             footer="Just for you - not part of the story")
            return
        await reply.send_cards(await self.run(self._whisper_cards, res))
        await self._post_netmaps(res.cards, reply.send_cards)
        await self.refresh()
        self.kick_world()

    def _whisper_cards(self, res) -> list[dict]:
        g, L = self.game, self.game.ledger
        cards = []
        for seg in parse_story(res.narration):
            if seg["kind"] == "narration":
                cards += [{"description": part, "color": WHISPER} for part in chunks(seg["text"], EMBED_LIMIT)]
            else:
                cards.append(self._dialogue_card(seg, private=True, said=res.info.get("speakers")))
        sender = g.conn.execute("SELECT private FROM turns WHERE id=?", (res.turn_id,)).fetchone()["private"]
        noticed = [L.get(e)["name"] for e, r in res.info.get("members", {}).items()
                   if r in ("actor", "target", "present") and e != sender and L.get(e)
                   and L.get(e)["kind"] in ("pc", "npc")]
        if cards:
            cards[-1]["footer"] = (f"🤫 Whisper · T{res.turn_id} · {clock.short(g.clock())} · " +
                                   (f"{', '.join(noticed)} know{'s' if len(noticed) == 1 else ''} too" if noticed
                                    else "nobody else knows"))
        return cards

    async def _whisper_command(self, handle: str, text: str, reply: Channel) -> None:
        g = self.game
        cmd, rest = ((text[1:].split(None, 1)) + ["", ""])[:2]   # any whitespace ends the command (phones send newlines)
        cmd, rest = cmd.lower(), rest.strip()
        cmd, rest = _sheet_kind(ALIASES.get(cmd, cmd), rest)
        if cmd == "undo":
            def undo():
                target, ch = g.undo_target(), g.character_for(handle)
                if not (target and ch and target["private"] == ch["id"]):
                    return "Only your own whisper, and only while it's still the latest turn - the story has moved on."
                return g.undo()
            await reply.send(f"↩️ {await self.run(undo)}")
            await self.refresh()
        elif cmd == "party":
            await self.post_party(reply)
        elif cmd == "dossier":
            await self.post_dossier(rest, reply)
        elif cmd in ("charactersheet", "cs", "character"):
            def build():
                ch = g.character_for(handle)
                return charsheet.image_cards(g, ch["id"]) if ch else None
            cards = await self.run(build)
            if cards:
                await reply.send_cards(cards)
            else:
                await reply.send("You're not playing anyone yet.")
        elif cmd == "textsheet":
            def sheet():
                ch = g.character_for(handle)
                return sr_lite.sheet(g.ledger, ch["id"]) if ch else "You're not playing anyone yet."
            await reply.send(f"```\n{await self.run(sheet)}\n```")
        elif cmd == "askdm":
            async with reply.typing():
                answer = await self.run(g.askdm, handle, rest)
            await reply.send(f"**You asked:** {rest}\n{answer}")
        elif cmd == "advance":
            if not rest:
                await reply.send("`!advance <#>` - the numbers are on your `!charactersheet`.")
                return

            def spend():
                ch = g.character_for(handle)
                if not ch:
                    raise LedgerError("You're not playing anyone yet.")
                return g.advance(ch["id"], rest)
            try:
                res = await self.run(spend)
            except LedgerError as exc:
                await reply.send(f"⚠️ {exc}")
                return
            await reply.send(f"📈 {res['card'][len('[KARMA] '):]}")
        elif cmd == "karma":
            def mine():
                ch = g.character_for(handle)
                return f"**{ch['name']}** has {int(g.ledger.stat(ch['id'], 'karma'))} karma." if ch else "Nobody yet."
            await reply.send(f"✨ {await self.run(mine)} Spend it with `!advance <#>`.")
        else:
            await reply.send("Whisper me what your character does on the quiet and the GM resolves it privately - "
                             "only whoever notices will know. Here you can also use `!askgm <question>`, "
                             "`!charactersheet`, `!sheet`, `!advance <#>`, `!karma`, and `!undo` (your last whisper, "
                             "if nothing has happened since).")

    async def _set_control(self, uid: str, name: str, mode: str) -> None:
        """Owner override: the GM plays this character (or it hangs back), taking it off any player's seat."""
        g, L = self.game, self.game.ledger
        if not name:
            await self.ch.send(f"`!{'dmplay' if mode == 'gm' else 'idle'} <character>`")
            return

        def apply():
            ent = L.find(name)
            if not ent or ent["kind"] not in ("pc", "npc"):
                raise LedgerError(f"No character '{name}'.")
            if ent["kind"] == "npc" and mode == "idle":
                raise LedgerError("NPCs nobody is inhabiting are always the GM's.")
            seat = g.conn.execute("SELECT discord_id FROM players WHERE handle IN (?, ?)",
                                  (ent["player"] or "\0", ent["id"])).fetchone()
            if seat:
                g.conn.execute("DELETE FROM players WHERE discord_id=?", (seat["discord_id"],))
            g.set_control(ent["id"], mode)
            return ent, seat["discord_id"] if seat else None
        ent, bumped = await self.run(apply)
        await self.refresh()
        what = self._hands(mode, ent["name"])
        line = f"🎭 {what[0].upper()}{what[1:]}"
        if bumped:
            line += f" (<@{bumped}> is off the seat - `!join {ent['name']}` takes them back)"
        await self.ch.send(line + ".")

    async def _newchar(self, uid: str, uname: str, rest: str) -> None:
        parts = rest.split()
        if len(parts) < 2:
            await self.ch.send(f"`!newchar <Name> <archetype> [description]` - archetypes: "
                               f"{', '.join(sr_lite.ARCHETYPES)}. Or just `!newchar` and the GM walks you through "
                               "it (`!roles` shows what they all are).")
            return
        name, arch, desc = parts[0], parts[1].lower(), " ".join(parts[2:])
        g = self.game

        def make():
            if charledger.taken(g, name):
                raise LedgerError(f"There's already a {name} in the character ledger - names are unique across "
                                  f"every world (`!characterledger checkout {name}` if they're yours).")
            eid = g.create_pc(name, arch, name.lower(), desc, g.turn_no())
            charledger.register(g, eid, uid, uname)
            g.enter_scene([eid], g.turn_no())
            g.conn.execute("INSERT OR REPLACE INTO players(discord_id, handle, name, afk) VALUES(?,?,?,0)",
                           (uid, name.lower(), uname))
            return sr_lite.sheet(g.ledger, eid)
        sheet = await self.run(make)
        await self.refresh()
        await self.ch.send(f"🎲 <@{uid}> rolled up **{name}** ({arch.replace('_', ' ')}).")
        await self.ch.dm(uid, f"```\n{sheet}\n```")

    async def ruling_request(self, uid: str, text: str, react: React) -> None:
        """`!ruling <anything>`: a player asks the GM to rule on something. It joins their input for the next turn,
        marked as a request, and the GM answers in a [GM RULING] line (a lasting one becomes a ruling too)."""
        handle = self.handles.get(uid)
        if not handle:
            await self.ch.send(f"<@{uid}> the GM takes ruling requests from the players at the table - `!join` "
                               "first, or `!ruling add <text>` to propose a house rule.")
            return
        self.director.add(handle, f"[RULING REQUEST - out of character, to the GM] {text}")
        await react("📝")
        await self.ch.send("📜 Asked the GM - it rules on that " + ("in the reply after this one (it's mid-turn)."
                                                                   if self.director.resolving else "in its next reply."))

    async def _art(self, rest: str, admin: bool, react: React) -> None:
        g = self.game
        words = rest.split()
        if not words:
            from ..console import art_command
            await self.ch.send(await self.run(art_command, g, ""))
            return
        if words[0].lower() in ("on", "off", "redo") and not admin:
            await self.ch.send("That one's for the campaign owner.")
            return
        if words[0].lower() in ("on", "off"):
            await self.run(g.set_art, words[0].lower() == "on")
            await react("🎨")
            return
        redo = words[0].lower() == "redo"
        name = words[1] if redo and len(words) > 1 else words[0]

        def look():
            ent = g.ledger.find(name)
            if not ent:
                return None, None, None
            if redo:
                return ent, None, g.request_art(ent["id"], force=True, direction=" ".join(words[2:]))
            rec = g.art.latest(g.conn, ent["id"], ready_only=True)
            return ent, rec, (None if rec else g.request_art(ent["id"]))
        ent, rec, how = await self.run(look)
        if not ent:
            await self.ch.send(f"No one called '{name}'.")
        elif rec:
            icon, color = ART_STYLE.get(ent["kind"], ("🎨", NARRATION))
            await self.ch.send_cards([{"title": f"{icon} {ent['name']}", "color": color, "image": rec["path"],
                                       "description": await self.run(spoilers.card, g, rec["caption"])}])   # (§12l)
        else:
            await self.ch.send(f"🎨 {ent['name']}: {how} - it'll show up here when it's painted.")
