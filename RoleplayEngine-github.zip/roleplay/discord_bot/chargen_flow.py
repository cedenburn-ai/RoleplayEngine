"""The character-creation conversation (DESIGN.md §7c), in the player's DMs with the bot.

`!newchar` (no arguments) starts it. The GM reads the player's concept and proposes a whole build;
every step then shows the current pick and takes `ok` or an edit - nothing reaches the ledger until the
review step's `done`. Drafts are kept in campaign meta (`chargen:<discord id>`), so a bot restart
doesn't lose a half-built runner.
"""
from __future__ import annotations

import json
import re

from .. import chargen as C
from .. import charledger
from ..engine.ledger import LedgerError
from ..engine.rules import magic, resonance, sr_lite

STEPS = ("concept", "name", "pronouns", "metatype", "role", "attributes", "skills", "magic", "gear", "look", "review")
TITLES = {"concept": "Concept", "name": "Name", "pronouns": "Pronouns", "metatype": "Metatype", "role": "Role",
          "attributes": "Attributes", "skills": "Skills", "magic": "Spells & forms", "gear": "Gear",
          "look": "Description", "review": "Review"}
PRONOUNS = ("she/her", "he/him", "they/them")
COLOR = 0x8E44AD
FOOTER = "back · go <step> · cancel"
NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 '.\-]{1,23}$")


def steps_for(d: dict) -> list[str]:
    return [s for s in STEPS if s != "magic" or d["role"] in C.AWAKENED]


def load(game, uid: str) -> dict | None:
    raw = game.ledger.meta(f"chargen:{uid}")
    try:
        return json.loads(raw) if raw else None
    except ValueError:
        return None


def save(game, uid: str, d: dict | None) -> None:
    game.ledger.set_meta(f"chargen:{uid}", json.dumps(d) if d else "")


# ── what each step shows ────────────────────────────────────────────────

def _star(d: dict, field: str, value: str) -> str:
    return " ★" if d.get("picks", {}).get(field) == value else ""


def prompt(game, d: dict) -> dict:
    step = d["step"]
    order = steps_for(d)
    title = f"🧬 New runner · {order.index(step) + 1}/{len(order)} {TITLES[step]}"
    name = d["name"] or "your runner"
    if step == "concept":
        body = ("**The GM:** Let's build your runner. Here's what you can be:\n\n" + C.options_text()
                + "\n\n**Your turn:** give me the concept in a line or two - mix a role and a metatype with a hook, "
                  "like *ork rigger who drives getaway for the Yakuza* or *elf decker with a grudge against "
                  "Renraku* - and I'll build the whole thing for you to tweak. Or reply a role's **number** to start "
                  "from that role, or **skip**.")
    elif step == "name":
        ideas = "  ·  ".join(f"**{i + 1}** {n}" for i, n in enumerate(d["name_ideas"]))
        body = ((f"**The GM:** {d['pitch']}\n\n" if d["pitch"] else "")
                + "What do they go by? A street name is fine." + (f"\nIdeas: {ideas}" if ideas else ""))
    elif step == "pronouns":
        body = (f"How should the GM refer to **{name}**?\n" + "  ·  ".join(f"**{i + 1}** {p}" for i, p in enumerate(PRONOUNS))
                + "\n...or type your own.")
    elif step == "metatype":
        body = "\n".join(f"{C.META_SHOW[m]} **{i + 1}  {m.title()}**{_star(d, 'metatype', m)} - {v['blurb']}"
                         + ("  ← **current**" if m == d["metatype"] else "")
                         for i, (m, v) in enumerate(C.METATYPES.items()))
        body += (f"\n\nReply a number, or **ok** to stay {d['metatype']}.\n-# Bonuses are free extra attribute "
                 "points; the limits are the most a natural attribute can reach. ★ = the GM's pick for your concept.")
    elif step == "role":
        body = "\n".join(f"{C.ROLE_SHOW[r][0]} **{i + 1}  {C.ROLE_SHOW[r][1]}**{_star(d, 'role', r)} - "
                         f"{C.ROLE_SHOW[r][2]}" + ("  ← **current**" if r == d["role"] else "")
                         for i, r in enumerate(C.ROLES))
        body += (f"\n\nReply a number, or **ok** to stay a {d['role'].replace('_', ' ')}. "
                 "Switching role resets attributes, skills and gear to that role's starting build.")
    elif step == "attributes":
        aug = C.augmented(d)
        rows = []
        for a in C.BASE_ATTRS:
            boost = f" (+{aug[a] - d['attrs'][a]} chrome)" if aug[a] > d["attrs"][a] else ""
            rows.append(f"`{sr_lite.ABBR[a]}` **{d['attrs'][a]}**{boost}  ({C.base(d, a)}-{C.cap(d, a)})")
        body = ("  ·  ".join(rows[:4]) + "\n" + "  ·  ".join(rows[4:])
                + f"\nEdge **{C.METATYPES[d['metatype']]['edge']}**"
                + (f"  ·  {C.AWAKENED[d['role']].title()} **{C.gift(d)}**" if d["role"] in C.AWAKENED else "")
                + f"\n\n**{C.attr_left(d)}** point(s) left of {C.ATTR_POINTS}. Reply changes like "
                  "`agility +1, logic -1` (or `cha 3`), or **ok**.\n"
                + "-# " + "  ·  ".join(f"{sr_lite.ABBR[a]} {C.ATTR_HELP[a]}" for a in C.BASE_ATTRS)
                + "  ·  numbers in brackets are your range")
    elif step == "skills":
        have = ", ".join(f"{sr_lite.nice(k)} **{v}**" for k, v in sorted(d["skills"].items(), key=lambda kv: -kv[1]))
        allowed = [k for k in sr_lite.SKILLS if C.GIFT_SKILLS.get(k, d["role"]) == d["role"]]
        groups = []
        for label, keys in C.SKILL_GROUPS:
            mine = [k for k in keys if k in allowed]
            if mine:
                groups.append(f"**{label}** " + " · ".join(f"{sr_lite.nice(k)} ({sr_lite.ABBR[sr_lite.SKILLS[k]]})"
                                                          for k in mine))
        body = (f"{have or '(none yet)'}\n\n**{C.skill_left(d)}** point(s) left of {C.SKILL_POINTS} (max "
                f"{C.SKILL_MAX} each). Reply `stealth +2, con 3` (0 drops a skill), or **ok**.\n\n"
                + "\n".join(groups) + "\n-# A roll is skill + its attribute (in brackets) in dice; 5s and 6s are hits.")
    elif step == "magic":
        field = "spells" if d["role"] == "mage" else "forms"
        table = magic.SPELLS if field == "spells" else resonance.FORMS
        limit = C.SPELL_PICKS if field == "spells" else C.FORM_PICKS
        code = ((lambda v: magic.drain_code(v["drain"])) if field == "spells"
                else (lambda v: resonance.fading_code(v["fading"])))
        # the code in brackets: 'Stunbolt F-3 - a mana jolt' put the code's hyphen against the separator
        body = "\n".join(f"{'✅' if k in d[field] else '▫️'} **{i + 1}** {v['name']} ({code(v)}) - {v['text']}"
                         for i, (k, v) in enumerate(table.items()))
        body += (f"\n\n{len(d[field])}/{limit} picked. Reply numbers to toggle (`2 5 7`), or **ok**. "
                 + ("Drain: F is the Force you cast at - F-3 is the Force minus 3, never under 2. "
                    if field == "spells" else
                    "Fading: L is the Level you thread at - L+2 is the Level plus 2, never under 2. ")
                 + f"More can be learned later for karma "
                   f"({magic.LEARN_COST if field == 'spells' else resonance.LEARN_COST} each).")
    elif step == "gear":
        menu, lines, cat = C.gear_menu(d), [], None
        for n, k in menu:
            item = C.CATALOG[k]
            if item["cat"] != cat:
                cat = item["cat"]
                lines.append(f"**{cat}**")
            have = d["gear"].get(k, 0)
            mark = f" ✅{'x' + str(have) if have > 1 else ''}" if have else ""
            extra = (f", Essence {item['ess']}" if item.get("ess") else "") + (f", {item['avail']}" if item.get("avail")
                                                                                else "")
            lines.append(f"`{n}` {item['name']} - {item['cost']:,}¥{extra}{mark}")
        left = C.budget(d) - C.spent(d)
        body = ("\n".join(lines) + f"\n\n**{C.spent(d):,}** of {C.budget(d):,}¥ spent - {left:,} left "
                f"(up to {C.CASH_CAP:,} comes along as cash) · Essence **{C.essence(d)}**"
                + (f" · {C.AWAKENED[d['role']].title()} {C.gift(d)}" if d["role"] in C.AWAKENED else "")
                + f"\nSR5's own prices. Availability (R restricted, F forbidden) at most {C.AVAIL_MAX} to start; "
                  "drones come bare - their autosofts and weapon mounts are bought here too."
                + "\nReply `buy 3`, `buy 12 x2`, `sell 3`, or **ok**.")
    elif step == "look":
        body = ((f"**The GM's sketch:** {d['look']}\n\n" if d["look"] else "")
                + f"Describe **{name}** - looks, style, vibe, anything people notice. The portrait is painted from "
                  "this." + (" Or **ok** to keep the sketch." if d["look"] else ""))
    else:
        bad = C.problems(d)
        body = (f"```\n{preview(d)}\n```" + ("\n⚠️ " + "; ".join(bad) if bad else "")
                + f"\n\n**done** to bring {name} into the game, **go <step>** to change something "
                  f"(e.g. `go gear`), or **cancel**.")
    return {"title": title, "description": body[:4000], "color": COLOR, "footer": FOOTER}


def preview(d: dict) -> str:
    aug = C.augmented(d)
    attrs = " ".join(f"{sr_lite.ABBR[a]} {aug[a]}" for a in C.BASE_ATTRS)
    gift = f" | {sr_lite.ABBR[C.AWAKENED[d['role']]]} {C.gift(d)}" if d["role"] in C.AWAKENED else ""
    gear = ", ".join(f"{C.CATALOG[k]['name']}{' x' + str(q) if q > 1 else ''}" for k, q in d["gear"].items())
    out = [f"{d['name'] or '?'} ({d['pronouns'] or '?'}) - {d['metatype']} {d['role'].replace('_', ' ')}",
           f"{attrs} | EDG {C.METATYPES[d['metatype']]['edge']}{gift} | ESS {C.essence(d)}",
           "Skills: " + ", ".join(f"{sr_lite.nice(k)} {v}" for k, v in sorted(d["skills"].items(), key=lambda kv: -kv[1])),
           f"Gear: {gear or 'nothing'}",
           f"Cash: {min(C.CASH_CAP, C.budget(d) - C.spent(d)):,} nuyen"]
    if d["role"] == "mage":
        out.append("Spells: " + ", ".join(magic.spell_label(s) for s in d["spells"]))
    if d["role"] == "technomancer":
        out.append("Forms: " + ", ".join(resonance.form_label(f) for f in d["forms"]))
    if d["look"]:
        out.append(d["look"])
    return "\n".join(out)


# ── what each step does with a reply ────────────────────────────────────

def _pick(text: str, options) -> str | None:
    options = list(options)
    t = text.strip().lower().replace(" ", "_")
    if t.isdigit() and 1 <= int(t) <= len(options):
        return options[int(t) - 1]
    hits = [o for o in options if o.startswith(t)] if t else []
    return hits[0] if len(hits) == 1 else None


def advance(d: dict) -> None:
    order = steps_for(d)
    d["step"] = order[min(order.index(d["step"]) + 1, len(order) - 1)]


def reply(game, d: dict, text: str) -> tuple[list[str], bool]:
    """Apply one message to the draft. Returns (notes for the player, whether to move to the next step).
    The concept step (it calls the GM) and 'done' are handled by the caller."""
    step, t = d["step"], text.strip()
    ok = t.lower() in ("ok", "okay", "k", "yes", "y", "keep", "next", "👍")
    if step == "name":
        if t.isdigit() and 1 <= int(t) <= len(d["name_ideas"]):
            t = d["name_ideas"][int(t) - 1]
        if not NAME_OK.match(t):
            return ["Names are 2-24 letters, numbers, spaces, ' . or -."], False
        if game.ledger.find(t):
            return [f"Someone in this world is already called {t} - pick another."], False
        if charledger.taken(game, t):
            return [f"There's already a {t} in the character ledger - names are unique across every world."], False
        d["name"] = t
        return [], True
    if step == "pronouns":
        d["pronouns"] = PRONOUNS[int(t) - 1] if t.isdigit() and 1 <= int(t) <= 3 else t[:30]
        return [], bool(d["pronouns"])
    if step == "metatype":
        if ok:
            return [], True
        m = _pick(t, C.METATYPES)
        if not m:
            return ["Reply a number from the list, or ok."], False
        C.set_metatype(d, m)
        return [], True
    if step == "role":
        if ok:
            return [], True
        r = _pick(t, C.ROLES)
        if not r:
            return ["Reply a number from the list, or ok."], False
        if r != d["role"]:
            C.apply_role(d, r)
            return [f"Reset to the {r.replace('_', ' ')} starting build."], True
        return [], True
    if step in ("attributes", "skills"):
        if ok:
            left = C.attr_left(d) if step == "attributes" else C.skill_left(d)
            return ([f"({left} point(s) left unspent.)"] if left > 0 else []), True
        return C.edit(d, "attrs" if step == "attributes" else "skills", t), False
    if step == "magic":
        if ok:
            return [], True
        return C.toggle(d, "spells" if d["role"] == "mage" else "forms", t), False
    if step == "gear":
        if ok:
            return [], True
        m = re.match(r"\s*(buy|sell|drop|remove)\s+(.+)", t, re.IGNORECASE)
        if not m:
            return ["Reply `buy 3`, `sell 3`, or ok."], False
        return C.shop(d, "buy" if m.group(1).lower() == "buy" else "sell", m.group(2)), False
    if step == "look":
        if ok and d["look"]:
            return [], True
        if len(t) < 8 or ok:
            return ["A sentence or two, please - the portrait is painted from it."], False
        d["look"] = t[:600]
        return [], True
    return [], False


SURPRISE = "Surprise me: a fun, distinctive, very playable runner for a new crew - any metatype, any role."


class Chargen:
    """One player's draft at one table; the table routes their DMs here until they finish or cancel."""

    def __init__(self, table, uid: str, uname: str, d: dict):
        self.table, self.uid, self.uname, self.d = table, uid, uname, d

    async def show(self, notes=()) -> None:
        card = await self.table.run(prompt, self.table.game, self.d)
        if notes:
            card["description"] = "\n".join(f"-# {n}" for n in notes) + "\n\n" + card["description"]
        await self.table.ch.dm_cards(self.uid, [card])

    async def handle(self, text: str) -> bool:
        """Returns False once the draft is finished or cancelled."""
        g, d, t = self.table.game, self.d, text.strip()
        low = t.lower()
        if low in ("cancel", "!cancel", "quit"):
            await self.table.run(save, g, self.uid, None)
            await self.table.ch.dm(self.uid, "Character creation cancelled. `!newchar` starts over.")
            return False
        if low in ("back", "!back") and d["step"] != "concept":
            order = steps_for(d)
            d["step"] = order[max(0, order.index(d["step"]) - 1)]
            return await self._next()
        if low.startswith("go "):
            target = _pick(low[3:], steps_for(d)) or _pick(low[3:].replace("attrs", "attributes"), steps_for(d))
            if target and target != "concept":
                d["step"] = target
                return await self._next()
            return await self._next([f"No step '{low[3:]}'. Steps: {', '.join(steps_for(d)[1:])}"])
        if low in ("help", "?", "options", "list", "!help"):
            return await self._next(["Here are the options for this step again."])
        if d["step"] == "concept":
            if low.isdigit() and 1 <= int(low) <= len(C.ROLES):    # a role straight off the list
                await self.table.run(C.apply_role, d, list(C.ROLES)[int(low) - 1])
                d["picks"] = {"role": d["role"]}
                advance(d)
                return await self._next([f"Starting from a {d['role'].replace('_', ' ')} - you'll pick your metatype "
                                         "and can change everything along the way."])
            if t.endswith("?") or re.match(r"(what|which|how|who|list|show|options?|help|can i|are there)\b", low):
                return await self._next(["That sounds like a question - here's everything you can pick from. When "
                                         "you're ready, describe your runner, reply a role number, or say skip."])
            if low != "skip":
                d["concept"] = t[:400]
                await self.table.ch.dm(self.uid, "🎲 *The GM reads your concept and sketches a build...*")
                try:
                    s = await self.table.run(C.suggest, g, d["concept"])
                    await self.table.run(C.apply_suggestion, d, s)
                except Exception as exc:                  # the GM's pitch is a nicety; the rules aren't
                    print(f"[chargen] suggestion failed: {exc}", flush=True)
                    d["pitch"] = ""
            advance(d)
            return await self._next()
        if d["step"] == "review":
            if low not in ("done", "done gm", "done companion"):
                return await self._next(["Say **done** (you play them), **done gm** (a companion the GM plays), "
                                         "**go <step>**, or **cancel**."])
            d["for_gm"] = low != "done"
            try:
                await self.table.finish_chargen(self.uid, self.uname, d)
            except LedgerError as exc:
                return await self._next([str(exc)])
            return False
        notes, move = await self.table.run(reply, g, d, t)
        if move:
            advance(d)
        return await self._next(notes)

    async def pregen(self, concept: str) -> None:
        """!pregen: the GM builds the whole runner; the player lands on the review and can change anything."""
        g, d = self.table.game, self.d
        d["concept"] = (concept or "").strip()[:400]
        try:
            s = await self.table.run(C.suggest, g, d["concept"] or SURPRISE)
            await self.table.run(C.apply_suggestion, d, s)
        except Exception as exc:
            print(f"[chargen] pregen suggestion failed: {exc}", flush=True)
        d["name"] = await self.table.run(lambda: next((n for n in d["name_ideas"] if NAME_OK.match(n)
                                                       and not g.ledger.find(n) and not charledger.taken(g, n)), ""))
        d["pronouns"] = d["pronouns"] or "they/them"
        d["step"] = "review" if d["name"] else "name"
        await self.table.ch.dm(self.uid, (f"**The GM:** {d['pitch']}\n\n" if d["pitch"] else "")
                               + "Here's a runner I rolled up for you. Pronouns are they/them until you say otherwise "
                                 "(`go pronouns`) - change anything with `go <step>`, or `done` to take them.")
        await self._next()

    async def _next(self, notes=()) -> bool:
        await self.table.run(save, self.table.game, self.uid, self.d)
        await self.show(notes)
        return True
