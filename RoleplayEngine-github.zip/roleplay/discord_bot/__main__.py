"""python -m roleplay.discord_bot [--announce] [--menus-demo]

One copy at a time (campaigns/.run/bot.lock); the dashboard starts and stops it (runtime.py). The keys come from
config.toml or the environment (keys.py); the token is read into this process only, never printed.
"""
import sys

from .. import keys
from .runtime import InstanceLock, Runtime, find_token


def main() -> None:
    lock = InstanceLock()
    if not lock.acquire():
        raise SystemExit("A copy of the bot is already running (campaigns/.run/bot_status.json says which) - "
                         "not starting a second one.")
    try:
        if keys.problem():
            print(f"[keys] {keys.problem()} - looking in the environment instead", flush=True)
        token = find_token()
        if not token:
            raise SystemExit(f"No bot token: {keys.how_to_set('discord_token')}, and run again.\n"
                             "In the Discord developer portal, enable the bot's MESSAGE CONTENT INTENT.")
        if "anthropic_api_key" not in keys.export_api_keys():
            raise SystemExit(f"No Anthropic API key - the GM can't think without one: "
                             f"{keys.how_to_set('anthropic_api_key')}, and run again.")
        from .bot import RPBot
        bot = RPBot(announce="--announce" in sys.argv, menus_demo="--menus-demo" in sys.argv)
        bot.runtime = Runtime(bot)
        bot.run(token)
    finally:
        lock.release()


main()
