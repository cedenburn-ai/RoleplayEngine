"""Discord interactions (DESIGN.md §5a): slash commands, forms, buttons and dropdowns over the same table.

The `!` commands keep working; this is a second front door. Personal things answer ephemerally - only the person
who asked sees them - so sheets, rules answers, shopping and whispers don't need DMs. Character creation is a
pop-up form (name, pronouns, metatype, role, concept) followed by a private review with buttons that open small
forms and dropdowns for attributes, skills, gear, spells and looks; the rules engine (chargen.py) checks every
change. Confirmations - seat requests, restarts - are buttons that only the right person can press.
"""
from __future__ import annotations

import discord
from discord import app_commands

from .. import chargen as C
from .. import charledger, charsheet, shops
from ..engine.ledger import LedgerError
from ..engine.rules import magic, resonance, sr_lite
from .chargen_flow import NAME_OK, PRONOUNS, SURPRISE, load as load_draft, preview, save as save_draft
from .render import chunks

PURPLE, GREEN = 0x8E44AD, 0x2ECC71
WORKING = "🎲 *The GM reads your concept and sketches a build...*"


# ── an ephemeral "channel": the table's own code can answer just the person who asked ──
class _NoTyping:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


class Ephemeral:
    def __init__(self, interaction: discord.Interaction):
        self.i = interaction

    async def _ready(self) -> None:
        if not self.i.response.is_done():
            await self.i.response.defer(ephemeral=True, thinking=True)

    async def send(self, text=None, *, title=None, description=None, color=None, footer=None, image=None):
        await self._ready()
        if title is None and description is None and image is None:
            for part in chunks(text or "", 1900):
                await self.i.followup.send(part, ephemeral=True)
            return
        await self.send_cards([{"title": title, "description": description, "color": color, "footer": footer,
                                "image": image}])

    async def send_cards(self, cards):
        from .bot import DiscordChannel
        await self._ready()
        i = self.i

        class _Target:
            async def send(self, **kw):
                return await i.followup.send(**kw, ephemeral=True, wait=True)
        return await DiscordChannel._send_cards(_Target(), cards)

    def typing(self):
        return _NoTyping()

    async def dm(self, user_id, text):
        await self.send(text)

    async def dm_cards(self, user_id, cards):
        await self.send_cards(cards)


async def _table(bot, interaction: discord.Interaction):
    table = await bot.table_for(interaction.channel) if interaction.channel else None
    if table is None:
        msg = "No game in this channel - `!rp start <world>` begins one."
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    return table


def _uid(interaction) -> str:
    return str(interaction.user.id)


# ── character creation ──────────────────────────────────────────────────
def review_embed(d: dict, notes=()) -> discord.Embed:
    bad = C.problems(d)
    top = (f"**The GM:** {d['pitch']}\n\n" if d.get("pitch") else "")
    top += "".join(f"-# {n}\n" for n in notes)
    body = (f"```\n{preview(d)}\n```"
            f"Attributes **{C.attr_left(d)}** pts left · Skills **{C.skill_left(d)}** left · "
            f"Nuyen **{C.budget(d) - C.spent(d):,}¥** left · Essence **{C.essence(d)}**"
            + (f"\n⚠️ {'; '.join(bad)}" if bad else ""))
    e = discord.Embed(title=f"🧬 {d['name'] or 'New runner'}", description=(top + body)[:4000], color=PURPLE)
    e.set_footer(text="Only you can see this · change anything below, then ✅ Done")
    return e


class BasicsForm(discord.ui.Modal):
    """Name, pronouns, metatype, role, concept - the first screen, and the 'Basics' button later."""

    def __init__(self, bot, table, d: dict, first: bool):
        super().__init__(title="Build a runner" if first else "Basics")
        self.bot, self.table, self.d, self.first = bot, table, d, first
        self.name = discord.ui.TextInput(placeholder="A street name, e.g. Glitch", max_length=24,
                                         default=d["name"] or None)
        self.pronouns = discord.ui.RadioGroup(options=[
            discord.RadioGroupOption(label=p, value=p, default=p == (d["pronouns"] or "they/them")) for p in PRONOUNS])
        self.meta = discord.ui.Select(options=[
            discord.SelectOption(label=m.title(), value=m, description=v["blurb"][:100], emoji=C.META_SHOW[m],
                                 default=m == d["metatype"]) for m, v in C.METATYPES.items()])
        self.role = discord.ui.Select(options=[
            discord.SelectOption(label=name, value=key, description=what[:100], emoji=icon, default=key == d["role"])
            for key, (icon, name, what) in C.ROLE_SHOW.items()])
        self.add_item(discord.ui.Label(text="Name", component=self.name))
        self.add_item(discord.ui.Label(text="Pronouns", component=self.pronouns))
        self.add_item(discord.ui.Label(text="Metatype", description="what you are", component=self.meta))
        self.add_item(discord.ui.Label(text="Role", description="what you do on a run (changing it resets the build)",
                                       component=self.role))
        if first:
            self.concept = discord.ui.TextInput(style=discord.TextStyle.paragraph, required=False, max_length=400,
                                                placeholder="ork rigger who drives getaway for the Yakuza")
            self.add_item(discord.ui.Label(text="Concept (optional)", description="the GM builds the rest from it - "
                                           "leave empty to start from the role", component=self.concept))

    async def on_submit(self, interaction: discord.Interaction) -> None:
        g, d, uid = self.table.game, self.d, _uid(interaction)
        name = self.name.value.strip()
        taken = await self.table.aside(lambda v: bool(v.ledger.find(name)) or charledger.taken(v, name))
        if not NAME_OK.match(name) or (taken and name.lower() != (d["name"] or "").lower()):
            why = ("Names are 2-24 letters, numbers, spaces, ' . or -." if not NAME_OK.match(name)
                   else f"There's already a {name} in this world or the character ledger - names are unique.")
            if self.first:
                await interaction.response.send_message(f"⚠️ {why}", view=BuildView(self.bot), ephemeral=True)
            else:
                await interaction.response.edit_message(embed=review_embed(d, [why]), view=ReviewView(self.bot, self.table, d))
            return
        meta, role = self.meta.values[0], self.role.values[0]
        notes = []
        if self.first:
            d["metatype"] = meta
            C.apply_role(d, role)                          # (the draft's own edits are instant - no game thread)
            concept = (self.concept.value or "").strip()
            if concept:
                await interaction.response.defer(ephemeral=True, thinking=True)
                d["concept"] = concept
                try:                                       # the GM builds for the picks the player made
                    s = await self.table.loop.run_in_executor(
                        None, C.suggest, g, f"{concept} (they picked: {meta} {role.replace('_', ' ')})")
                    C.apply_suggestion(d, s)
                except Exception as exc:
                    print(f"[chargen] suggestion failed: {exc}", flush=True)
                if (d["metatype"], d["role"]) != (meta, role):
                    d["metatype"] = meta
                    C.apply_role(d, role)
            d["picks"] = {"metatype": meta, "role": role}
        else:
            if role != d["role"]:
                C.apply_role(d, role)
                notes.append(f"Reset to the {role.replace('_', ' ')} starting build.")
            if meta != d["metatype"]:
                C.set_metatype(d, meta)
        d.update(name=name, pronouns=self.pronouns.value or "they/them", uname=interaction.user.display_name)
        view, embed = ReviewView(self.bot, self.table, d), review_embed(d, notes)
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        elif self.first:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.edit_message(embed=embed, view=view)
        await _save(self.table, uid, d)


class SpreadForm(discord.ui.Modal):
    """Attributes or skills as one editable line - checked as a whole spread."""

    def __init__(self, bot, table, d: dict, what: str):
        super().__init__(title="Attributes" if what == "attrs" else "Skills")
        self.bot, self.table, self.d, self.what = bot, table, d, what
        text = C.attrs_text(d) if what == "attrs" else C.skills_text(d)
        hint = (f"{C.ATTR_POINTS} points above your base; ranges are in the review" if what == "attrs"
                else f"{C.SKILL_POINTS} points, max {C.SKILL_MAX} each - skills you leave out are dropped")
        self.field = discord.ui.TextInput(style=discord.TextStyle.paragraph, default=text, max_length=600)
        self.add_item(discord.ui.Label(text="Edit the numbers", description=hint[:100], component=self.field))
        legend = ("  ·  ".join(f"{sr_lite.ABBR[a]} {C.ATTR_HELP[a]}" for a in C.BASE_ATTRS) if what == "attrs" else
                  "\n".join(f"**{label}** " + ", ".join(sr_lite.nice(k) for k in keys) for label, keys in C.SKILL_GROUPS
                            if any(C.GIFT_SKILLS.get(k, d["role"]) == d["role"] for k in keys)))
        self.add_item(discord.ui.TextDisplay(legend[:1500]))

    async def on_submit(self, interaction: discord.Interaction) -> None:
        errors = C.set_all(self.d, self.what, self.field.value)
        await interaction.response.edit_message(embed=review_embed(self.d, ["⚠️ " + e for e in errors] or ["Saved."]),
                                                view=ReviewView(self.bot, self.table, self.d))
        await _save(self.table, _uid(interaction), self.d)


class LookForm(discord.ui.Modal):
    def __init__(self, bot, table, d: dict):
        super().__init__(title="How they look")
        self.bot, self.table, self.d = bot, table, d
        self.field = discord.ui.TextInput(style=discord.TextStyle.paragraph, default=d["look"] or None, min_length=8,
                                          max_length=600, placeholder="Silver-haired elf in a patched techie jacket...")
        self.add_item(discord.ui.Label(text="Description", description="looks, style, vibe - the portrait is painted "
                                       "from this", component=self.field))

    async def on_submit(self, interaction: discord.Interaction) -> None:
        self.d["look"] = self.field.value.strip()
        await interaction.response.edit_message(embed=review_embed(self.d, ["Saved."]),
                                                view=ReviewView(self.bot, self.table, self.d))
        await _save(self.table, _uid(interaction), self.d)


class ReviewView(discord.ui.View):
    def __init__(self, bot, table, d: dict):
        super().__init__(timeout=3600)
        self.bot, self.table, self.d = bot, table, d
        if d["role"] not in C.AWAKENED:
            self.remove_item(self.magic)
        else:
            self.magic.label = "Spells" if d["role"] == "mage" else "Forms"

    @discord.ui.button(label="Basics", emoji="🧬", row=0)
    async def basics(self, interaction, button):
        await interaction.response.send_modal(BasicsForm(self.bot, self.table, self.d, first=False))

    @discord.ui.button(label="Attributes", emoji="💪", row=0)
    async def attrs(self, interaction, button):
        await interaction.response.send_modal(SpreadForm(self.bot, self.table, self.d, "attrs"))

    @discord.ui.button(label="Skills", emoji="🎯", row=0)
    async def skills(self, interaction, button):
        await interaction.response.send_modal(SpreadForm(self.bot, self.table, self.d, "skills"))

    @discord.ui.button(label="Gear", emoji="🛒", row=1)
    async def gear(self, interaction, button):
        view = GearView(self.bot, self.table, self.d)
        await interaction.response.edit_message(embed=view.embed(), view=view)

    @discord.ui.button(label="Spells", emoji="🔮", row=1)
    async def magic(self, interaction, button):
        view = MagicView(self.bot, self.table, self.d)
        await interaction.response.edit_message(embed=view.embed(), view=view)

    @discord.ui.button(label="Look", emoji="🪞", row=1)
    async def look(self, interaction, button):
        await interaction.response.send_modal(LookForm(self.bot, self.table, self.d))

    @discord.ui.button(label="Done", emoji="✅", style=discord.ButtonStyle.success, row=2)
    async def done(self, interaction, button):
        await self._finish(interaction, for_gm=False)

    @discord.ui.button(label="Done - the GM plays them", emoji="🎭", style=discord.ButtonStyle.secondary, row=2)
    async def done_gm(self, interaction, button):
        await self._finish(interaction, for_gm=True)

    async def _finish(self, interaction, for_gm: bool) -> None:
        """Into the world - played by you, or a companion the GM plays (you keep your own seat)."""
        self.d["for_gm"] = for_gm
        if not self.d["look"]:
            await interaction.response.send_modal(LookForm(self.bot, self.table, self.d))
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            await self.table.finish_chargen(_uid(interaction), interaction.user.display_name, self.d,
                                            reply=Ephemeral(interaction))
        except LedgerError as exc:
            await interaction.followup.send(f"⚠️ {exc}", ephemeral=True)
            return
        await interaction.edit_original_response(embed=discord.Embed(
            title=f"✅ {self.d['name']} is in the game", color=GREEN,
            description=("The GM plays them - a companion for the crew. `!join` takes them over any time; the "
                         "portrait is being painted.") if for_gm else
                        "Head back to the table and tell the GM what they're doing - the portrait is being painted."),
            view=None)

    @discord.ui.button(label="Cancel", emoji="✖️", style=discord.ButtonStyle.danger, row=2)
    async def cancel(self, interaction, button):
        self.table.chargens.pop(_uid(interaction), None)
        await interaction.response.edit_message(embed=discord.Embed(title="Character creation cancelled",
                                                                    color=0x95A5A6), view=None)
        await _save(self.table, _uid(interaction), None)


class GearView(discord.ui.View):
    """A category dropdown and the items in it - what you pick is what you carry (the engine checks the money)."""

    def __init__(self, bot, table, d: dict, cat: str | None = None, notes=()):
        super().__init__(timeout=3600)
        self.bot, self.table, self.d, self.notes = bot, table, d, list(notes)
        cats = [c for c in C.CATEGORIES if self._items(c)]
        self.cat = cat if cat in cats else cats[0]
        pick = discord.ui.Select(placeholder="Category", row=0, options=[
            discord.SelectOption(label=c, value=c, default=c == self.cat,
                                 description=f"{sum(1 for k in d['gear'] if C.CATALOG[k]['cat'] == c)} picked")
            for c in cats])
        pick.callback = self.on_cat
        self.pick = pick
        self.add_item(pick)
        items = self._items(self.cat)
        sel = discord.ui.Select(placeholder=f"{self.cat} you carry", row=1, min_values=0, max_values=len(items),
                                options=[discord.SelectOption(
                                    label=C.CATALOG[k]["name"][:100], value=k, default=k in d["gear"],
                                    description=(f"{C.CATALOG[k]['cost']:,}¥" + (f" · Essence {C.CATALOG[k]['ess']}"
                                                 if C.CATALOG[k].get("ess") else "")
                                                 + (f" · {C.avail_text(C.CATALOG[k])}" if C.CATALOG[k].get("avail")
                                                    else ""))[:100]) for k in items])
        sel.callback = self.on_items
        self.sel = sel
        self.add_item(sel)

    def _items(self, cat: str) -> list[str]:
        return [k for k, v in C.CATALOG.items() if v["cat"] == cat and (v.get("needs") != "magic" or self.d["role"] == "mage")]

    def embed(self) -> discord.Embed:
        d = self.d
        have = "\n".join(f"• {C.CATALOG[k]['name']}" + (f" ×{q}" if q > 1 else "") for k, q in d["gear"].items())
        e = discord.Embed(title="🛒 Gear", color=PURPLE, description=(
            "".join(f"-# ⚠️ {n}\n" for n in self.notes) + (have or "*nothing yet*")
            + f"\n\n**{C.spent(d):,}** of {C.budget(d):,}¥ spent - up to {C.CASH_CAP:,} left over comes along as cash · "
              f"Essence **{C.essence(d)}**" + (f" · {C.AWAKENED[d['role']].title()} {C.gift(d)}" if d["role"] in C.AWAKENED else "")))
        e.set_footer(text="Pick a category, then tick what you carry · ⬅ Back when you're done")
        return e

    async def on_cat(self, interaction):
        view = GearView(self.bot, self.table, self.d, self.pick.values[0])
        await interaction.response.edit_message(embed=view.embed(), view=view)

    async def on_items(self, interaction):
        notes = C.set_category(self.d, self.cat, list(self.sel.values))
        view = GearView(self.bot, self.table, self.d, self.cat, notes)
        await interaction.response.edit_message(embed=view.embed(), view=view)
        await _save(self.table, _uid(interaction), self.d)

    @discord.ui.button(label="Back", emoji="⬅", row=2)
    async def back(self, interaction, button):
        await interaction.response.edit_message(embed=review_embed(self.d), view=ReviewView(self.bot, self.table, self.d))


class MagicView(discord.ui.View):
    def __init__(self, bot, table, d: dict):
        super().__init__(timeout=3600)
        self.bot, self.table, self.d = bot, table, d
        self.field = "spells" if d["role"] == "mage" else "forms"
        table_ = magic.SPELLS if self.field == "spells" else resonance.FORMS
        limit = C.SPELL_PICKS if self.field == "spells" else C.FORM_PICKS
        sel = discord.ui.Select(placeholder=f"Pick up to {limit}", min_values=0, max_values=limit, row=0, options=[
            discord.SelectOption(label=self.label(k), value=k, description=v["text"][:100], default=k in d[self.field])
            for k, v in table_.items()])
        sel.callback = self.on_pick
        self.sel = sel
        self.add_item(sel)

    def label(self, key: str) -> str:
        """'Stunbolt F-3' / 'Puppeteer L+2': the name with its drain or fading code (the value stays the key)."""
        return magic.spell_label(key) if self.field == "spells" else resonance.form_label(key)

    def embed(self) -> discord.Embed:
        how = ("-# F is the Force you cast at: F-3 drains the Force minus 3, never under 2." if self.field == "spells"
               else "-# L is the Level you thread at: L+2 fades the Level plus 2, never under 2.")
        return discord.Embed(title="🔮 Spells" if self.field == "spells" else "📡 Complex forms", color=PURPLE,
                             description=("\n".join(f"• {self.label(k)}" for k in self.d[self.field]) or "*none yet*")
                             + "\n" + how)

    async def on_pick(self, interaction):
        self.d[self.field] = list(self.sel.values)
        view = MagicView(self.bot, self.table, self.d)
        await interaction.response.edit_message(embed=view.embed(), view=view)
        await _save(self.table, _uid(interaction), self.d)

    @discord.ui.button(label="Back", emoji="⬅", row=1)
    async def back(self, interaction, button):
        await interaction.response.edit_message(embed=review_embed(self.d), view=ReviewView(self.bot, self.table, self.d))


async def _save(table, uid: str, d: dict | None) -> None:
    """Save a draft - after Discord has its answer, on a connection of its own. A form gets 3 seconds, and the game
    thread can be busy with the GM's turn for a minute: saving first is what made "How they look" fail."""
    try:
        await table.aside(save_draft, uid, d)
    except Exception as exc:                              # (the answer's already shown; say so in the log)
        print(f"[chargen] couldn't save {uid}'s draft: {exc}", flush=True)


async def open_builder(bot, interaction: discord.Interaction) -> None:
    """The 📝 button and /newchar: resume a draft in progress, or open the first form."""
    table = await _table(bot, interaction)
    if table is None:
        return
    d = await table.aside(load_draft, _uid(interaction))
    if d and d.get("name"):
        await interaction.response.send_message("Picking up where you left off:", embed=review_embed(d),
                                                view=ReviewView(bot, table, d), ephemeral=True)
        return
    await interaction.response.send_modal(BasicsForm(bot, table, C.new_draft(), first=True))


class BuildView(discord.ui.View):
    """A persistent '📝 Build a runner' button for session zero and `!newchar` in the channel."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Build a runner", emoji="📝", style=discord.ButtonStyle.primary, custom_id="rp:build")
    async def build(self, interaction, button):
        await open_builder(self.bot, interaction)


# ── confirmations, shops, whispers ──────────────────────────────────────
class ChoiceView(discord.ui.View):
    """✅ / ❌ that only one person can answer (seat requests, restarts)."""

    def __init__(self, holder: str, on_choice, timeout: float = 900):
        super().__init__(timeout=timeout)
        self.holder, self.on_choice = holder, on_choice

    async def _answer(self, interaction, yes: bool):
        if _uid(interaction) != self.holder:
            await interaction.response.send_message(f"That one's for <@{self.holder}> to answer.", ephemeral=True)
            return
        await interaction.response.edit_message(view=None)
        await self.on_choice(interaction, yes)

    @discord.ui.button(emoji="✅", style=discord.ButtonStyle.success)
    async def yes(self, interaction, button):
        await self._answer(interaction, True)

    @discord.ui.button(emoji="✖️", style=discord.ButtonStyle.danger)
    async def no(self, interaction, button):
        await self._answer(interaction, False)


class TurnView(discord.ui.View):
    """The turn card's buttons: ⏩ go now · ✋ more time · 💤 sit this one out (session.turn_button decides)."""

    def __init__(self, client, channel_id: int):
        super().__init__(timeout=None)
        self.client, self.channel_id = client, channel_id

    async def _press(self, interaction, action: str):
        table = self.client.tables.get(self.channel_id)
        note = await table.turn_button(_uid(interaction), action) if table else "This table isn't running right now."
        if note:
            await interaction.response.send_message(note, ephemeral=True)
        else:
            await interaction.response.defer()

    @discord.ui.button(emoji="⏩", label="Go now", style=discord.ButtonStyle.primary)
    async def go_now(self, interaction, button):
        await self._press(interaction, "go")

    @discord.ui.button(emoji="✋", label="More time", style=discord.ButtonStyle.secondary)
    async def more_time(self, interaction, button):
        await self._press(interaction, "wait")

    @discord.ui.button(emoji="💤", label="Sit this one out", style=discord.ButtonStyle.secondary)
    async def sit_out(self, interaction, button):
        await self._press(interaction, "pass")


class ShopView(discord.ui.View):
    """Buy from the shop where your character stands - the engine charges you and hands it over."""

    def __init__(self, table, shop: dict, shop_id: str | None = None):
        super().__init__(timeout=1800)
        self.table, self.shop_id = table, shop_id         # (the shop this select was built from - buys go there)
        def blurb(k):                                    # price · Avail 10R · arrives in a few days · 2 left
            o = shop["items"][k]
            bits = [f"{o['price']:,}¥", C.avail_text(C.CATALOG[k])]
            if o.get("hours"):
                bits.append(f"arrives {shops.when(table.game, o['hours'])}")
            if o["stock"] > 1:
                bits.append(f"{o['stock']} left")
            return " · ".join(b for b in bits if b)[:100]
        sel = discord.ui.Select(placeholder="Buy something...", options=[
            discord.SelectOption(label=C.CATALOG[k]["name"][:100], value=k, description=blurb(k))
            for _, k in shops.menu(shop)][:25])
        sel.callback = self.on_buy
        self.sel = sel
        self.add_item(sel)

    async def on_buy(self, interaction):
        g, uid = self.table.game, _uid(interaction)

        def purchase():
            ch = g.character_for(self.table.handles.get(uid, ""))
            if not ch:
                raise LedgerError("You're not playing anyone - `/join` first.")
            return shops.buy(g, ch["id"], self.sel.values[0], 1, g.turn_no(), shop_id=self.shop_id)
        await interaction.response.defer(ephemeral=True, thinking=True)   # (Discord first: the GM may be mid-turn)
        try:
            res = await self.table.run(purchase)
        except LedgerError as exc:
            await interaction.followup.send(f"⚠️ {exc}", ephemeral=True)
            return
        await interaction.followup.send(f"🛒 Done - {res['card'][len('[SHOP] '):]}", ephemeral=True)
        await self.table.ch.send(f"🛒 {res['card'][len('[SHOP] '):]}")


class WhisperForm(discord.ui.Modal):
    def __init__(self, table):
        super().__init__(title="Whisper to the GM")
        self.table = table
        self.field = discord.ui.TextInput(style=discord.TextStyle.paragraph, max_length=1500,
                                          placeholder="I palm the keycard while Kaz isn't looking...")
        self.add_item(discord.ui.Label(text="What does your character do on the quiet?",
                                       description="only whoever notices will know", component=self.field))

    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        await self.table.whisper(_uid(interaction), self.field.value, Ephemeral(interaction))


# ── slash commands ──────────────────────────────────────────────────────
def install(bot) -> None:
    tree = bot.tree

    async def character(interaction, table):                     # (asked before answering: never the game thread)
        return await table.aside(lambda v: v.character_for(table.handles.get(_uid(interaction), "")))

    @tree.command(name="newchar", description="Build a new runner with the GM (a form, then a private review)")
    async def newchar(interaction: discord.Interaction):
        await open_builder(bot, interaction)

    @tree.command(name="pregen", description="Let the GM roll up a whole runner for you to review")
    @app_commands.describe(concept="optional - e.g. 'ork rigger who owes the Yakuza'")
    async def pregen(interaction: discord.Interaction, concept: str | None = None):
        table = await _table(bot, interaction)
        if table is None:
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        g, d = table.game, C.new_draft()
        try:                                               # (the model, off the game thread: a turn can be running)
            s = await table.loop.run_in_executor(None, C.suggest, g, concept or SURPRISE)
            C.apply_suggestion(d, s)
        except Exception as exc:
            print(f"[chargen] pregen failed: {exc}", flush=True)
        d["concept"] = concept or ""
        d["name"] = await table.aside(lambda v: next((n for n in d["name_ideas"] if NAME_OK.match(n)
                                                      and not v.ledger.find(n) and not charledger.taken(v, n)), ""))
        d.update(pronouns="they/them", uname=interaction.user.display_name)
        await interaction.followup.send(embed=review_embed(d, ["Pronouns are they/them until you change them (Basics)."]),
                                        view=ReviewView(bot, table, d), ephemeral=True)
        await _save(table, _uid(interaction), d)

    @tree.command(name="sheet", description="Your character sheet (only you see it)")
    async def sheet(interaction: discord.Interaction):
        table = await _table(bot, interaction)
        if table is None:
            return
        ch = await character(interaction, table)
        if not ch:
            await interaction.response.send_message("You're not playing anyone - `/join` or `/newchar` first.",
                                                    ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        await Ephemeral(interaction).send_cards(await table.run(charsheet.image_cards, table.game, ch["id"]))

    @tree.command(name="shop", description="What's for sale where your character is")
    async def shop(interaction: discord.Interaction):
        table = await _table(bot, interaction)
        if table is None:
            return
        ch = await character(interaction, table)
        card = await table.run(shops.card, table.game, ch["id"] if ch else None)
        holder, here = await table.run(shops.where, table.game, ch["id"]) if ch else (None, None)
        table.saw_shop(_uid(interaction), (holder or {}).get("id"))      # (a `!buy <#>` after it means this card)
        e = discord.Embed(title=card["title"], description=card["description"], color=card["color"])
        if card.get("footer"):
            e.set_footer(text=card["footer"])
        await interaction.response.send_message(
            embed=e, view=ShopView(table, here, holder["id"]) if here and here["items"] else None, ephemeral=True)

    @tree.command(name="askgm", description="Ask the GM a rules or memory question (only you see the answer)")
    async def askgm(interaction: discord.Interaction, question: str):
        table = await _table(bot, interaction)
        if table is None:
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        handle = table.handles.get(_uid(interaction), "")
        answer = await table.run(table.game.askdm, handle, question)
        await Ephemeral(interaction).send(f"**You asked:** {question}\n{answer}")

    @tree.command(name="whisper", description="Do something on the quiet - the GM resolves it privately")
    async def whisper(interaction: discord.Interaction):
        table = await _table(bot, interaction)
        if table is None:
            return
        if _uid(interaction) not in table.handles:
            await interaction.response.send_message("You're not playing anyone - `/join` first.", ephemeral=True)
            return
        await interaction.response.send_modal(WhisperForm(table))

    async def _public(interaction, coro_factory, done: str = "👍"):
        table = await _table(bot, interaction)
        if table is None:
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            await coro_factory(table)
        except LedgerError as exc:
            await interaction.followup.send(f"⚠️ {exc}", ephemeral=True)
            return
        await interaction.followup.send(done, ephemeral=True)

    async def names(interaction, current: str, kinds=("pc",), ledger=False):
        table = bot.tables.get(interaction.channel_id)
        if table is None:
            return []
        def look(g):                                       # (the game on its own connection: 3 seconds, even mid-turn)
            if ledger:
                pool = [r["name"] for r in charledger.runners(g)]
            else:
                roster = set(g.ledger.roster(g.current_scene_id()))
                pool = [e["name"] for e in g.ledger.entities(kind="pc")] + \
                       [e["name"] for e in g.ledger.entities(kind="npc") if e["id"] in roster]
            return [n for n in pool if current.lower() in n.lower()][:25]
        return [app_commands.Choice(name=n, value=n) for n in await table.aside(look)]

    @tree.command(name="join", description="Play a character (another player's? they'll be asked first)")
    async def join(interaction: discord.Interaction, character: str):
        await _public(interaction, lambda t: t._join(_uid(interaction), interaction.user.display_name, character))

    @join.autocomplete("character")
    async def join_names(interaction, current: str):
        return await names(interaction, current)

    @tree.command(name="checkout", description="Bring one of your runners in from the character ledger")
    async def checkout(interaction: discord.Interaction, runner: str):
        await _public(interaction, lambda t: t._ledger_checkout(_uid(interaction), interaction.user.display_name, runner))

    @checkout.autocomplete("runner")
    async def checkout_names(interaction, current: str):
        return await names(interaction, current, ledger=True)

    @tree.command(name="advance", description="Spend karma to raise a stat")
    async def advance(interaction: discord.Interaction, stat: str):
        async def go(t):
            ch = await character(interaction, t)
            if not ch:
                raise LedgerError("You're not playing anyone.")
            res = await t.run(t.game.advance, ch["id"], stat)
            await t.ch.send(f"📈 {res['card'][len('[KARMA] '):]}")
        await _public(interaction, go)

    @advance.autocomplete("stat")
    async def advance_stats(interaction, current: str):
        table = bot.tables.get(interaction.channel_id)
        if table is None:
            return []
        uid = _uid(interaction)

        def look(g):
            ch = g.character_for(table.handles.get(uid, ""))
            if not ch:
                return []
            out = []
            karma = int(g.ledger.stat(ch["id"], "karma"))
            for ref, key in sr_lite.advancement_refs().items():
                now = int(g.ledger.stat(ch["id"], key, 0))
                if key in sr_lite.SPECIAL and not now:
                    continue
                new, cost, why = sr_lite.advance_cost(g.ledger, ch["id"], key)
                if why:
                    continue
                label = sr_lite.ABBR[key] if key in sr_lite.ATTRIBUTES else sr_lite.nice(key)
                text = f"#{ref} {label} {now} → {new} ({cost} karma{' ✓' if cost <= karma else ''})"
                if current.lower() in text.lower():
                    out.append(app_commands.Choice(name=text[:100], value=str(ref)))
            return out[:25]
        return await table.aside(look)

    @tree.command(name="begin", description="Session zero's done - the GM opens the first scene")
    @app_commands.describe(pitch="optional - what kind of run you're in the mood for")
    async def begin(interaction: discord.Interaction, pitch: str | None = None):
        await _public(interaction, lambda t: t.begin(pitch or ""), "🎬")

    @tree.command(name="party", description="The whole crew for the table - health, Edge, armor, gear, spells held")
    async def party(interaction: discord.Interaction):
        await _public(interaction, lambda t: t.post_party(), "🛡️")

    @tree.command(name="dossier", description="Put the crew's file on someone on the table")
    @app_commands.describe(name="who - anyone the crew has crossed paths with")
    async def dossier_(interaction: discord.Interaction, name: str):
        await _public(interaction, lambda t: t.post_dossier(name), "🗂️")

    @dossier_.autocomplete("name")
    async def dossier_names(interaction, current: str):
        from .. import recap
        table = bot.tables.get(interaction.channel_id)
        if table is None:
            return []
        g = table.game
        people = await table.side(lambda v: recap.known_people(g.on(v.conn)))
        return [app_commands.Choice(name=n, value=n) for n in people if current.lower() in n.lower()][:25]

    @tree.command(name="reportbug", description="Tell the developers something's wrong - this turn goes with it")
    @app_commands.describe(what="what went wrong")
    async def reportbug(interaction: discord.Interaction, what: str):
        table = await _table(bot, interaction)
        if table is None:
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        await table.report_bug(_uid(interaction), interaction.user.display_name, what, reply=Ephemeral(interaction))

    @tree.command(name="recap", description="Previously on... with NPC dossiers")
    async def recap_(interaction: discord.Interaction):
        await _public(interaction, lambda t: t.post_recap(), "📺")

    @tree.command(name="chronicle", description="The story so far, as one character lived it (only you see it)")
    async def chronicle_(interaction: discord.Interaction, character: str | None = None):
        from .. import chronicle
        table = await _table(bot, interaction)
        if table is None:
            return
        uid = _uid(interaction)
        perms = getattr(interaction.user, "guild_permissions", None)
        admin = bool(perms and perms.manage_guild) or uid == table.owner_id
        await interaction.response.defer(ephemeral=True, thinking=True)

        def tell():
            g = table.game
            mine = g.character_for(table.handles.get(uid, ""))
            who = g.ledger.find(character) if character else mine
            if not who or who["kind"] not in ("pc", "npc"):
                raise LedgerError("No such character.")
            if not admin and (not mine or who["id"] != mine["id"]):
                raise LedgerError("Your own character's chronicle is yours - anyone else's is for the campaign owner.")
            return who, chronicle.save(g, who["id"])
        try:
            who, text = await table.run(tell)
        except LedgerError as exc:
            await interaction.followup.send(f"⚠️ {exc}", ephemeral=True)
            return
        await Ephemeral(interaction).send_cards([
            {"title": f"📖 {who['name']}'s story" if i == 0 else None, "description": part, "color": 0xC9A227}
            for i, part in enumerate(chunks(text, 3900))])

    @chronicle_.autocomplete("character")
    async def chronicle_names(interaction, current: str):
        return await names(interaction, current)

    @tree.command(name="battle", description="The battlefield of the current (or last) fight")
    async def battle(interaction: discord.Interaction):
        from .. import battlemap
        table = await _table(bot, interaction)
        if table is None:
            return
        await interaction.response.defer(ephemeral=True, thinking=True)

        def draw():
            row = table.game.conn.execute("SELECT id FROM encounters ORDER BY id DESC LIMIT 1").fetchone()
            return str(battlemap.render(table.game, row["id"])) if row else None
        path = await table.run(draw)
        if not path:
            await interaction.followup.send("No fight yet.", ephemeral=True)
            return
        await Ephemeral(interaction).send_cards([{"title": "⚔️ The battlefield", "image": path, "color": 0xE74C3C}])

    @tree.command(name="roles", description="The roles and metatypes you can play")
    async def roles(interaction: discord.Interaction):
        await interaction.response.send_message(embed=discord.Embed(title="🧬 What you can play", color=PURPLE,
                                                                    description=C.options_text()), ephemeral=True)

    @tree.command(name="matrixhelp", description="What a decker can do inside a host")
    async def matrixhelp(interaction: discord.Interaction):
        from .session import matrix_help_cards
        table = bot.tables.get(interaction.channel.id) if interaction.channel else None
        await Ephemeral(interaction).send_cards(matrix_help_cards(table.colors_on() if table else True))

    @tree.command(name="combathelp", description="What a fight round holds: Initiative, actions, defenses")
    async def combathelp(interaction: discord.Interaction):
        from .session import combat_help_cards
        table = bot.tables.get(interaction.channel.id) if interaction.channel else None
        await Ephemeral(interaction).send_cards(combat_help_cards(table.colors_on() if table else True))

    @tree.command(name="help", description="Everything you can do at the table")
    async def help_(interaction: discord.Interaction):
        from .session import help_cards
        table = bot.tables.get(interaction.channel.id) if interaction.channel else None   # (colours: the world's say)
        await Ephemeral(interaction).send_cards(help_cards(color=table.colors_on() if table else True))
