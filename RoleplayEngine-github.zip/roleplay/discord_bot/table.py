"""Table mode: when does a turn resolve? (DESIGN.md §4)

Players post actions; the director decides when the GM answers:
  - everyone it's waiting on has acted or passed      -> resolve after a short grace (for follow-ups)
  - `wait` seconds after the first action of the batch -> whoever hasn't acted sits this one out
      - a waiting player typing holds the turn open a little (`typing_grace` after each typing event)
      - a waiting player can ask for more time (`hold`: `extend` more seconds, `holds` times a turn)
  - `cap` seconds after the first action, no matter what
  - someone says go (!go, or the turn card's button)
Who it waits on comes from the table (`expected`): seated players whose character is in the scene, not away, and
active lately - nobody waits on a player who left an hour ago. Actions that arrive while the GM is working start the
next batch, and its window opens when the GM's answer lands, so nobody is rushed to answer a story they haven't read.
`on_change` hears about every change (the Discord table draws its turn card from `snapshot`). Pure asyncio, no
Discord, so it can be tested with a fast clock.
"""
from __future__ import annotations

import asyncio
import time
from typing import Awaitable, Callable

TYPING_SHOWN = 12.0              # seconds a typing event keeps someone marked "typing" on the card


class TableDirector:
    def __init__(self, resolve: Callable[[list[tuple[str, str]]], Awaitable[None]],
                 expected: Callable[[], set[str]], wait: float = 30.0, cap: float = 300.0, grace: float = 4.0,
                 typing_grace: float = 15.0, extend: float = 60.0, holds: int = 2,
                 clock: Callable[[], float] = time.monotonic, on_change: Callable[[], None] | None = None,
                 quiet: float | None = None):
        self.resolve = resolve
        self.expected = expected
        self.wait = quiet if quiet is not None else wait      # (`quiet` is this timer's old name)
        self.cap, self.grace = cap, grace
        self.typing_grace, self.extend, self.holds = typing_grace, extend, holds
        self.clock = clock
        self.on_change = on_change
        self.queue: list[tuple[str, str]] = []
        self.resolving = False
        self.batch_passed: set[str] = set()                   # who sat out the batch being resolved (the GM is told)
        self._reset()
        self._wake = asyncio.Event()
        self._task: asyncio.Task | None = None

    def _reset(self) -> None:
        self.first_at: float | None = None
        self.last_at: float | None = None
        self.passed: set[str] = set()
        self.hold_until = 0.0                                  # "more time" - counts only while someone's awaited
        self.typing_until = 0.0                                # someone typing - an answer or a follow-up
        self.holds_used: dict[str, int] = {}
        self.typing_at: dict[str, float] = {}
        self._force = False

    # ── events ──────────────────────────────────────────────────────────
    def add(self, handle: str, text: str) -> None:
        now = self.clock()
        self.queue.append((handle, text))
        self.passed.discard(handle)                            # (they had passed, then thought of something)
        self.typing_at.pop(handle, None)
        if self.first_at is None:
            self.first_at = now
        self.last_at = now
        self._kick()

    def typing(self, handle: str) -> None:
        """Someone at the table is typing: if the turn is waiting on them (or they're adding to their post),
        hold it open a little longer."""
        if not self.queue or self.resolving or handle not in self.expected() | self.acted():
            return
        now = self.clock()
        self.typing_at[handle] = now
        self.typing_until = max(self.typing_until, now + self.typing_grace)
        self._kick()

    def hold(self, handle: str) -> bool:
        """A waiting player asks for more time."""
        if not self.queue or self.resolving or handle not in self.waiting_on():
            return False
        if self.holds_used.get(handle, 0) >= self.holds:
            return False
        self.holds_used[handle] = self.holds_used.get(handle, 0) + 1
        self.hold_until = self.deadline() + self.extend         # a full `extend` on top of whatever was left
        self._kick()
        return True

    def pass_(self, handle: str) -> bool:
        """A waiting player sits this turn out."""
        if not self.queue or self.resolving or handle not in self.waiting_on():
            return False
        self.passed.add(handle)
        self.last_at = self.clock()
        self._kick()
        return True

    def go(self) -> bool:
        if not self.queue:
            return False
        self._force = True
        self._kick()
        return True

    def acted(self) -> set[str]:
        return {h for h, _ in self.queue}

    def waiting_on(self) -> set[str]:
        return self.expected() - self.acted() - self.passed

    # ── timing ──────────────────────────────────────────────────────────
    def deadline(self) -> float:
        now = self.clock()
        if self._force:
            return now
        if self.waiting_on():
            base = max(self.first_at + self.wait, self.hold_until)
        else:
            base = self.last_at + self.grace
        return min(self.first_at + self.cap, max(base, self.typing_until))

    def snapshot(self) -> dict | None:
        """The batch as the turn card shows it (None when nothing is happening)."""
        if not self.queue and not self.resolving:
            return None
        now = self.clock()
        waiting = self.waiting_on() if self.queue else set()
        return {"acted": list(dict.fromkeys(h for h, _ in self.queue)), "waiting": sorted(waiting),
                "passed": sorted(self.passed), "resolving": self.resolving,
                "typing": sorted(h for h, t in self.typing_at.items() if now - t < TYPING_SHOWN and h in waiting),
                "in": max(0.0, self.deadline() - now) if self.queue and not self.resolving else None,
                "holds_left": {h: self.holds - self.holds_used.get(h, 0) for h in waiting}}

    def _changed(self) -> None:
        if self.on_change:
            try:
                self.on_change()
            except Exception:                                  # a card that can't draw must never stall the table
                pass

    # ── loop ────────────────────────────────────────────────────────────
    def _kick(self) -> None:
        self._wake.set()
        if self._task is None or self._task.done():
            self._task = asyncio.get_running_loop().create_task(self._loop())
        self._changed()

    async def _loop(self) -> None:
        while self.queue:
            delay = self.deadline() - self.clock()
            if delay > 0:
                self._wake.clear()
                try:
                    await asyncio.wait_for(self._wake.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    pass
                continue
            inputs, self.queue = self.queue, []
            self.batch_passed = set(self.passed)
            self._reset()
            self.resolving = True
            self._changed()
            try:
                await self.resolve(inputs)
            finally:
                self.resolving = False
                if self.queue:                                 # posted while the GM worked: the window opens now
                    now = self.clock()
                    self.first_at = max(self.first_at or now, now)
                    self.last_at = max(self.last_at or now, now)
                self._changed()
