"""discord.py wiring: channels <-> CampaignTable. Everything game-shaped lives in session.py."""
from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

import discord
from discord import app_commands

from ..config import CAMPAIGN_DIR
from ..game import Game
from .. import recap
from ..setup import SEEDS, setup_blank
from .render import MSG_LIMIT, chunks
from .session import CampaignTable, help_cards

BINDINGS = CAMPAIGN_DIR / "discord_bindings.json"
VOICE_HOOK = "StoryEngine"                # the old C# bot's webhook name - reused if this bot owns it
CAST_THREAD = "🎭 Cast"


def _hook_name(name: str) -> str:
    """Webhook usernames: 1-80 chars, and Discord refuses 'discord' / 'clyde' in them."""
    clean = name.replace("discord", "d1scord").replace("Discord", "D1scord").replace("clyde", "clyd3")
    return (clean.strip() or "Someone")[:80]
SESSION_GAP_HOURS = 3          # this long without a turn and the next table opening starts a new session


class DiscordChannel:
    """The small surface CampaignTable needs, over a real Discord channel."""

    def __init__(self, channel: discord.abc.Messageable, client: discord.Client):
        self.channel, self.client = channel, client
        self._hook = None                         # the voices webhook (False: unavailable here)
        self._thread = None                       # the "Cast" thread portraits live in (False: unavailable)

    async def send(self, text: str | None = None, *, title: str | None = None, description: str | None = None,
                   color: int | None = None, footer: str | None = None, image: str | None = None) -> None:
        if title is None and description is None and image is None:
            for part in chunks(text or "", MSG_LIMIT):
                await self.channel.send(part, allowed_mentions=discord.AllowedMentions(users=True, everyone=False))
            return
        await self.send_cards([{"title": title, "description": description, "color": color, "footer": footer,
                                "image": image}])

    async def send_cards(self, cards: list[dict]) -> list[dict | None]:
        return await self._send_cards(self.channel, cards)

    async def live_card(self, ref: dict | None, card: dict) -> dict | None:
        """Post a card with an image, or redraw it in place if `ref` (channel/message ids) still exists."""
        e = discord.Embed(title=card.get("title"), description=card.get("description"), color=card.get("color"))
        name = "live" + Path(card["image"]).suffix
        e.set_image(url=f"attachment://{name}")
        if ref:
            try:
                ch = self.client.get_channel(int(ref["channel_id"])) or await self.client.fetch_channel(int(ref["channel_id"]))
                msg = await ch.fetch_message(int(ref["message_id"]))
                await msg.edit(embed=e, attachments=[discord.File(card["image"], filename=name)])
                return ref
            except (discord.HTTPException, ValueError, KeyError):
                pass                                      # (deleted or too old: post a fresh one)
        try:
            msg = await self.channel.send(embed=e, file=discord.File(card["image"], filename=name))
            return {"channel_id": str(msg.channel.id), "message_id": str(msg.id)}
        except discord.HTTPException as exc:
            print(f"[battle map] {exc}", flush=True)
            return None

    async def turn_card(self, ref, text: str, ping: list[str]):
        """Post the turn card - pinging whoever the turn waits on - or redraw it in place. Returns the message."""
        from .ui import TurnView
        view = TurnView(self.client, self.channel.id)
        if ref is not None:
            try:
                await ref.edit(content=text, view=view)
                return ref
            except discord.HTTPException:
                pass                                      # (deleted: post a fresh one)
        allowed = (discord.AllowedMentions(users=[discord.Object(int(u)) for u in ping], everyone=False, roles=False)
                   if ping else discord.AllowedMentions.none())
        return await self.channel.send(text, view=view, allowed_mentions=allowed)

    async def banner(self, path: str) -> None:
        """A bare picture, no embed around it (the turn divider): quiet, like a rule line."""
        await self.channel.send(file=discord.File(path, filename="turn.png"), silent=True)

    async def work_card(self, ref, text: str):
        """The work card (what the GM is doing): post it quietly - no ping, no notification - or redraw it in place."""
        if ref is not None:
            try:
                await ref.edit(content=text)
                return ref
            except discord.HTTPException:
                pass
        return await self.channel.send(text, silent=True, allowed_mentions=discord.AllowedMentions.none())

    async def drop_turn_card(self, ref) -> None:
        try:
            await ref.delete()
        except discord.HTTPException:
            pass

    async def build_button(self, text: str) -> None:
        """A message with the persistent 📝 Build a runner button (opens the form for whoever taps it)."""
        from .ui import BuildView
        await self.channel.send(text, view=BuildView(self.client),
                                allowed_mentions=discord.AllowedMentions(users=True, everyone=False))

    async def menus_demo(self) -> None:
        from .menus import post
        await post(self.channel)

    async def ask(self, content: str, card: dict, emojis: list[str], holder: str | None = None) -> str | None:
        """A card with ✅/❌ buttons only `holder` can press (reactions too, as a fallback); returns its message id
        so the answer can find it."""
        from .ui import ChoiceView
        e = discord.Embed(title=card.get("title"), description=card.get("description"), color=card.get("color"))
        sent: dict = {}

        async def chose(interaction, yes):
            table = self.client.tables.get(self.channel.id)
            if table and sent.get("id"):
                await table.reaction(sent["id"], str(interaction.user.id), "✅" if yes else "❌")
        try:
            msg = await self.channel.send(content=content, embed=e, view=ChoiceView(holder, chose) if holder else None,
                                          allowed_mentions=discord.AllowedMentions(users=True, everyone=False))
            sent["id"] = str(msg.id)
            if not holder:
                for emoji in emojis:
                    await msg.add_reaction(emoji)
            return str(msg.id)
        except discord.HTTPException as exc:
            print(f"[ask] {exc}", flush=True)
            return None

    # ── voices: NPC lines posted under their own name and portrait ──────
    async def _webhook(self):
        if self._hook is None:
            self._hook = False
            try:                                   # reuse the old C# bot's webhook if it's ours
                for h in await self.channel.webhooks():
                    if h.name == VOICE_HOOK and h.token and h.user and h.user.id == self.client.user.id:
                        self._hook = h
                        break
                else:
                    self._hook = await self.channel.create_webhook(name=VOICE_HOOK)
            except (discord.HTTPException, AttributeError) as exc:
                print(f"[voices] no webhook here ({exc}) - dialogue stays on cards", flush=True)
        return self._hook or None

    async def voice(self, name: str, text: str, avatar_url: str | None) -> bool:
        hook = await self._webhook()
        if hook is None:
            return False
        try:
            for part in chunks(text, MSG_LIMIT):
                await hook.send(content=part, username=_hook_name(name), avatar_url=avatar_url,
                                allowed_mentions=discord.AllowedMentions.none(), wait=True)
            return True
        except discord.HTTPException as exc:
            print(f"[voices] {name}: {exc}", flush=True)
            return False

    async def _cast_thread(self):
        if self._thread is None:
            self._thread = False
            try:
                found = [t for t in getattr(self.channel, "threads", []) if t.name == CAST_THREAD]
                if not found:
                    found = [t async for t in self.channel.archived_threads(limit=50) if t.name == CAST_THREAD]
                self._thread = found[0] if found else await self.channel.create_thread(
                    name=CAST_THREAD, type=discord.ChannelType.public_thread, auto_archive_duration=10080)
            except (discord.HTTPException, AttributeError) as exc:
                print(f"[voices] no cast thread ({exc}) - portraits upload and vanish", flush=True)
        return self._thread or None

    async def store_asset(self, path: str, caption: str) -> dict | None:
        """Give a portrait a Discord home: the Cast thread (kept, refreshable), else upload-and-delete."""
        thread = await self._cast_thread()
        try:
            if thread is not None:
                msg = await thread.send(content=f"**{caption}**", file=discord.File(path))
                return {"channel_id": str(thread.id), "message_id": str(msg.id), "url": msg.attachments[0].url}
            msg = await self.channel.send(file=discord.File(path))
            url = msg.attachments[0].url
            await asyncio.sleep(0.3)
            await msg.delete()
            return {"channel_id": None, "message_id": None, "url": url}
        except (discord.HTTPException, IndexError) as exc:
            print(f"[voices] couldn't store {caption}'s portrait: {exc}", flush=True)
            return None

    async def refresh_asset(self, channel_id: str, message_id: str) -> str | None:
        """Discord attachment links expire; the message they live in hands out a fresh one."""
        try:
            ch = self.client.get_channel(int(channel_id)) or await self.client.fetch_channel(int(channel_id))
            msg = await ch.fetch_message(int(message_id))
            urls = [a.url for a in msg.attachments] + [e.image.url for e in msg.embeds if e.image and e.image.url]
            return urls[0] if urls else None
        except (discord.HTTPException, ValueError):
            return None

    async def dm_cards(self, user_id: str, cards: list[dict]) -> None:
        user = self.client.get_user(int(user_id)) or await self.client.fetch_user(int(user_id))
        await self._send_cards(user, cards)

    @staticmethod
    async def _send_cards(target, cards: list[dict]) -> list[dict | None]:
        """Batch cards into messages (<= 5 embeds, <= 5800 chars, <= 10 files each). Local images are
        attached and referenced as attachment:// URLs; each discord.File is built fresh per message.
        Returns, per card, where its big image ended up on Discord (or None)."""
        out: list[dict | None] = [None] * len(cards)
        pending: list[tuple[int, str]] = []          # (card index, attachment filename) in the current batch
        batch: list[discord.Embed] = []
        files: dict[str, str] = {}                   # local path -> attachment filename (this message)
        size = 0

        async def flush():
            nonlocal batch, files, size, pending
            if batch:
                msg = await target.send(embeds=batch, files=[discord.File(p, filename=n) for p, n in files.items()])
                urls = {a.filename: a.url for a in getattr(msg, "attachments", None) or []}
                for i, name in pending:
                    if name in urls:
                        out[i] = {"channel_id": str(msg.channel.id), "message_id": str(msg.id), "url": urls[name]}
            batch, files, size, pending = [], {}, 0, []

        for idx, c in enumerate(cards):
            e = discord.Embed(title=c.get("title"), description=c.get("description"), color=c.get("color"))
            if c.get("author"):
                e.set_author(name=str(c["author"])[:256])
            if c.get("footer"):
                e.set_footer(text=c["footer"])
            for f in c.get("fields") or []:
                e.add_field(name=str(f["name"])[:256], value=str(f["value"])[:1024], inline=bool(f.get("inline")))
            want = [p for p in (c.get("thumbnail"), c.get("image")) if p and Path(p).exists()]
            new_files = [p for p in want if p not in files]
            if batch and (len(batch) >= 5 or size + len(e) > 5800 or len(files) + len(new_files) > 10):
                await flush()
            for p in want:
                if p not in files:
                    files[p] = f"img{len(files)}{Path(p).suffix}"
            if c.get("thumbnail") in files:
                e.set_thumbnail(url=f"attachment://{files[c['thumbnail']]}")
            if c.get("image") in files:
                e.set_image(url=f"attachment://{files[c['image']]}")
                pending.append((idx, files[c["image"]]))
            batch.append(e)
            size += len(e)
        await flush()
        return out

    def typing(self):
        return self.channel.typing()

    async def dm(self, user_id: str, text: str) -> None:
        user = self.client.get_user(int(user_id)) or await self.client.fetch_user(int(user_id))
        for part in chunks(text, MSG_LIMIT):
            await user.send(part)


class RPBot(discord.Client):
    def __init__(self, announce: bool = False, menus_demo: bool = False):
        intents = discord.Intents.default()
        intents.message_content = True      # privileged: enable "Message Content Intent" in the developer portal
        intents.typing = True               # typing holds the turn open for whoever it's waiting on
        super().__init__(intents=intents)
        self.tables: dict[int, CampaignTable] = {}
        self.bindings: dict[str, dict] = json.loads(BINDINGS.read_text()) if BINDINGS.exists() else {}
        self._opening: dict[int, asyncio.Lock] = {}
        self.pending: dict[int, dict] = {}          # restarts waiting for a ✅ (by channel id)
        self._backups: asyncio.Task | None = None
        self.announce = announce
        self.menus_demo = menus_demo                  # post the components preview in bound channels on startup
        self.tree = app_commands.CommandTree(self)    # slash commands (ui.py), synced to each server on startup
        self._synced = False
        self._announced = False
        self.runtime = None                           # runtime.Runtime: heartbeat + stop requests (set by __main__)
        self.stopping = False                         # a stop is under way: new messages wait for the next start

    def save_bindings(self) -> None:
        BINDINGS.parent.mkdir(parents=True, exist_ok=True)
        BINDINGS.write_text(json.dumps(self.bindings, indent=2))

    async def setup_hook(self) -> None:
        from . import ui
        from .menus import MenusDemo
        ui.install(self)                              # /newchar, /sheet, /shop, /whisper, /askgm, /join, ...
        self.add_view(MenusDemo())                    # persistent buttons keep working across restarts
        self.add_view(ui.BuildView(self))
        if self.runtime:
            self.runtime.start()                      # the heartbeat and the stop watcher (runtime.py)

    async def on_disconnect(self) -> None:
        if self.runtime and not self.stopping:
            self.runtime.set("reconnecting")

    async def on_resumed(self) -> None:
        if self.runtime and not self.stopping:
            self.runtime.set("online")

    async def on_error(self, event: str, *args, **kwargs) -> None:
        import traceback
        if self.runtime:
            self.runtime.error(f"{event}: {traceback.format_exc().strip().splitlines()[-1]}")
        await super().on_error(event, *args, **kwargs)

    async def on_ready(self) -> None:
        print(f"Logged in as {self.user} - {len(self.guilds)} server(s); "
              f"{len(self.bindings)} bound channel(s). Type `!rp start <world>` in a channel to begin.", flush=True)
        if self.runtime and not self.stopping:
            self.runtime.set("online")
        if not self._synced:                          # guild commands show up instantly (global ones take an hour)
            self._synced = True
            for guild in self.guilds:
                try:
                    self.tree.copy_global_to(guild=guild)
                    cmds = await self.tree.sync(guild=guild)
                    print(f"[slash] {len(cmds)} commands ready in {guild.name}", flush=True)
                except discord.HTTPException as exc:
                    print(f"[slash] couldn't register commands in {guild.name}: {exc} - re-invite the bot with the "
                          "applications.commands scope", flush=True)
        if self.menus_demo:
            self.menus_demo = False
            from .menus import post
            for key in self.bindings:
                channel = self.get_channel(int(key))
                if channel is not None:
                    await post(channel)
        if self._backups is None:                         # once a day, in the background (backup.py)
            self._backups = asyncio.get_running_loop().create_task(self._backup_daily())
        if self.announce and not self._announced:          # on_ready can fire again after reconnects
            self._announced = True
            for key in self.bindings:
                channel = self.get_channel(int(key))
                if channel is None:
                    continue
                table = await self.table_for(channel)
                await self.welcome(table, self.bindings[key]["campaign"])

    async def _backup_daily(self) -> None:
        from .. import backup
        while True:
            try:
                if backup.due():
                    z = await asyncio.get_running_loop().run_in_executor(None, backup.run)
                    print(f"[backup] {z} ({z.stat().st_size / 1e6:.1f} MB)", flush=True)
            except Exception as exc:                      # a failed backup must never take the bot down
                print(f"[backup] failed: {exc}", flush=True)
            await asyncio.sleep(3600)

    async def welcome(self, table: CampaignTable, campaign: str) -> None:
        await table.welcome(campaign)

    async def table_for(self, channel) -> CampaignTable | None:
        key = str(channel.id)
        if channel.id in self.tables:
            return self.tables[channel.id]
        if key not in self.bindings:
            return None
        lock = self._opening.setdefault(channel.id, asyncio.Lock())
        async with lock:
            if channel.id in self.tables:
                return self.tables[channel.id]
            b = self.bindings[key]
            table = await open_table(b["campaign"], DiscordChannel(channel, self), b["owner"], b.get("timers"))
            self.tables[channel.id] = table
            return table

    async def on_message(self, msg: discord.Message) -> None:
        if msg.author.bot:
            return
        if self.stopping:                         # shutting down: it won't be resolved - say so with a ⏸️
            if msg.guild is not None and str(msg.channel.id) in self.bindings:
                try:
                    await msg.add_reaction("⏸️")
                except discord.HTTPException:
                    pass
            return
        text = msg.content.strip()
        if msg.guild is None:                     # a DM to the bot is a whisper to the GM
            await self.on_whisper(msg)
            return
        if text.startswith("!rp"):
            await self.rp_command(msg, text)
            return
        table = await self.table_for(msg.channel)
        if table is None:
            return
        if msg.attachments and text.lower().startswith("!seed"):   # a story's files ride in with it (seed.py)
            from ..seed import with_files
            text = await with_files(text, msg.attachments)
        perms = getattr(msg.author, "guild_permissions", None)
        is_admin = bool(perms and perms.manage_guild)

        async def react(emoji: str) -> None:
            try:
                await msg.add_reaction(emoji)
            except discord.HTTPException:
                pass

        async def unreact(emoji: str) -> None:
            try:
                await msg.remove_reaction(emoji, self.user)
            except discord.HTTPException:
                pass
        await table.handle(str(msg.author.id), msg.author.display_name, text, is_admin, react, unreact)

    async def on_whisper(self, msg: discord.Message) -> None:
        """Find the table this person is seated at and hand it the whisper."""
        uid = str(msg.author.id)
        reply = DiscordChannel(msg.channel, self)
        seated, first = [], None
        for key in list(self.bindings):
            channel = self.get_channel(int(key))
            table = await self.table_for(channel) if channel else None
            first = first or table
            if table and (uid in table.handles or await table.chargen_for(uid)):
                seated.append(table)
        if not seated and first and msg.content.strip().lower() == "!newchar":
            await first.start_chargen(uid, msg.author.display_name)      # build one from the DMs
            return
        if not seated:
            await reply.send("You're not playing at any table yet - `!join <character>` in the game channel first "
                             "(or `!newchar` to build one), then whisper me here.")
            return
        await seated[0].whisper(uid, msg.content, reply)

    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent) -> None:
        if self.user and payload.user_id == self.user.id:
            return
        p = self.pending.get(payload.channel_id)
        if p and p["message_id"] == str(payload.message_id) and str(payload.emoji) in ("✅", "❌"):
            channel = self.get_channel(payload.channel_id)
            if channel is not None:
                await self.answer_restart(channel, str(payload.user_id), str(payload.emoji) == "✅")
            return
        table = self.tables.get(payload.channel_id)
        if table:
            await table.reaction(str(payload.message_id), str(payload.user_id), str(payload.emoji))

    async def on_typing(self, channel, user, when) -> None:
        table = self.tables.get(getattr(channel, "id", None))
        if table and not getattr(user, "bot", False):
            table.typing(str(user.id))

    async def rp_command(self, msg: discord.Message, text: str) -> None:
        words = text.split()
        sub = words[1].lower() if len(words) > 1 else "help"
        key = str(msg.channel.id)
        uid = str(msg.author.id)
        perms = getattr(msg.author, "guild_permissions", None)
        owner = self.bindings.get(key, {}).get("owner")
        admin = bool(perms and perms.manage_guild) or owner == uid
        current = self.bindings.get(key, {}).get("campaign")
        if sub in ("start", "play", "new"):
            name = (words[2] if len(words) > 2 else "demo").lower()
            if not name.replace("_", "").replace("-", "").isalnum():
                await msg.channel.send("Campaign names are letters, numbers, - and _.")
                return
            if current == name:
                await msg.channel.send(f"This channel already plays **{name}**. `!rp restart` starts it over.")
                return
            if current:
                if not admin:
                    await msg.channel.send("Only the campaign owner can switch this channel to another world.")
                    return
                table = self.tables.pop(msg.channel.id, None)
                if table:
                    await table.close()
                await msg.channel.send(f"🔀 Switching from **{current}** to **{name}** - {current} is kept "
                                       f"(`!rp start {current}` brings it back).")
            self.bindings[key] = {"campaign": name, "owner": owner or uid}
            self.save_bindings()
            table = await self.table_for(msg.channel)
            await self.welcome(table, name)
        elif sub in ("restart", "reset"):
            if not current:
                await msg.channel.send("No world here to restart - `!rp start <world>` begins one.")
                return
            if not admin:
                await msg.channel.send("Only the campaign owner can restart the world.")
                return
            seeded = " and re-seeds it" if current in SEEDS else ""
            e = discord.Embed(title=f"⚠️ Restart {current}?", color=0xE67E22, description=(
                f"This archives the whole world - story, memory, characters, art - to `campaigns/archive/` and starts "
                f"**{current}** fresh{seeded}. Nothing is deleted.\n\n<@{uid}>: ✅ to restart or ✖️ to keep "
                f"playing (`!rp confirm` / `!rp cancel` work too). This expires in 2 minutes."))
            from .ui import ChoiceView
            channel = msg.channel

            async def chose(interaction, yes):
                await self.answer_restart(channel, str(interaction.user.id), yes)
            ask = await msg.channel.send(content=f"<@{uid}>", embed=e, view=ChoiceView(uid, chose, timeout=120))
            self.pending[msg.channel.id] = {"campaign": current, "uid": uid, "message_id": str(ask.id),
                                            "expires": time.time() + 120}
        elif sub in ("newparty", "newcrew", "newstory"):
            await self.ask_newparty(msg, " ".join(words[2:]), admin, current)
        elif sub in ("confirm", "yes"):
            await self.answer_restart(msg.channel, uid, True)
        elif sub in ("cancel", "no"):
            await self.answer_restart(msg.channel, uid, False)
        elif sub == "stop":
            if not admin:
                await msg.channel.send("Only the campaign owner can stop it.")
                return
            table = self.tables.pop(msg.channel.id, None)
            if table:
                await table.close()
            self.bindings.pop(key, None)
            self.save_bindings()
            await msg.channel.send("Campaign unbound from this channel (the campaign file is kept).")
        elif sub == "status":
            b = self.bindings.get(key)
            await msg.channel.send(f"Playing **{b['campaign']}**, owner <@{b['owner']}>." if b
                                   else "No campaign here. `!rp start <world>` (try `rage` or `demo`).")
        else:
            cards = help_cards(["🎬 Starting a game"], color=True)
            unknown = None
            if sub not in ("help", "?", "commands"):      # (a typo, or a command this bot doesn't have yet - say so,
                import difflib                            #  rather than answering with the help card alone)
                subs = ("start", "restart", "newparty", "confirm", "cancel", "stop", "status")
                guess = difflib.get_close_matches(sub, subs, n=1, cutoff=0.6)
                unknown = (f"`!rp {sub}` isn't a command here" + (f" - did you mean `!rp {guess[0]}`?" if guess
                                                                     else ".") + " Nothing was changed.")
            await msg.channel.send(content=unknown, embed=discord.Embed(
                title=cards[0]["title"], description=cards[0]["description"], color=cards[0]["color"]))

    async def answer_restart(self, channel, uid: str, yes: bool) -> None:
        """Only whoever asked for the restart can confirm it, and only for two minutes."""
        p = self.pending.get(channel.id)
        if not p or p["expires"] < time.time():
            self.pending.pop(channel.id, None)
            await channel.send("Nothing waiting to confirm - `!rp restart` asks again.")
            return
        if p["uid"] != uid:
            return
        self.pending.pop(channel.id, None)
        name = p["campaign"]
        if not yes:
            await channel.send(f"👍 {'Cancelled' if p.get('kind') else 'Restart cancelled'} - **{name}** plays on.")
            return
        if name != self.bindings.get(str(channel.id), {}).get("campaign"):    # (`!rp start` switched worlds meanwhile:
            await channel.send(f"⚠️ This channel has moved on from **{name}** since you asked - nothing was done. "
                               "Ask again if you still want it.")            #  the ✅ ran on a world never previewed)
            return
        if p.get("kind") in ("newparty", "newparty_undo"):    # (the same ✅, a different job: newparty.py)
            table = await self.table_for(channel)
            if table is None:
                await channel.send("No world here any more.")
            elif p["kind"] == "newparty":
                await table.new_party(uid, p["gap"], p["label"], p.get("ending", ""))
            else:
                await table.undo_new_party(uid)
            return
        table = self.tables.pop(channel.id, None)
        if table:
            home = await table.run(table.check_in_all)        # ledger runners go home before the world is boxed up
            if home:
                await channel.send(f"📒 Back to the character ledger: {', '.join(home)}.")
            await table.close()
        where = archive_campaign(name)
        await channel.send(f"♻️ **{name}** is archived as `{where}` - starting fresh.")
        table = await self.table_for(channel)
        await self.welcome(table, name)

    async def ask_newparty(self, msg, rest: str, admin: bool, current: str | None) -> None:
        """`!rp newparty [3 weeks]` / `!rp newparty undo` (newparty.py): what it will do, and the owner's ✅ first -
        two minutes, as a restart's. answer_restart does it."""
        from .. import newparty
        from ..engine.ledger import LedgerError
        uid = str(msg.author.id)
        if not current:
            await msg.channel.send("No world here - `!rp start <world>` begins one.")
            return
        if not admin:
            await msg.channel.send("Only the campaign owner can start a new party.")
            return
        table = await self.table_for(msg.channel)
        how_long, ending = newparty.split_request(rest)         # ("3 weeks | how the old story ended")
        try:
            if how_long.lower() in ("undo", "back", "restore"):
                rec = await table.run(newparty.can_undo, table.game)
                title, body = f"↩️ Take back the new party in {current}?", newparty.undo_confirm_text(rec)
                job = {"kind": "newparty_undo"}
            else:
                gap, label = newparty.parse_gap(how_long)
                plan = await table.run(newparty.preview, table.game, gap, label, ending)
                title, body = f"⚠️ A new party in {current}?", newparty.confirm_text(plan)
                job = {"kind": "newparty", "gap": gap, "label": label, "ending": ending}
        except LedgerError as exc:
            await msg.channel.send(f"⚠️ {exc}")
            return
        e = discord.Embed(title=title, color=0xE67E22, description=(
            f"{body}\n\n<@{uid}>: ✅ to go ahead or ✖️ to keep playing (`!rp confirm` / `!rp cancel` work too). This "
            "expires in 2 minutes."))
        from .ui import ChoiceView
        channel = msg.channel

        async def chose(interaction, yes):
            await self.answer_restart(channel, str(interaction.user.id), yes)
        ask = await msg.channel.send(content=f"<@{uid}>", embed=e,
                                     view=ChoiceView(uid, chose, timeout=newparty.CONFIRM_SECONDS))
        self.pending[msg.channel.id] = {"campaign": current, "uid": uid, "message_id": str(ask.id),
                                        "expires": time.time() + newparty.CONFIRM_SECONDS, **job}


def archive_campaign(name: str) -> str:
    """Move a campaign's file (and its art and undo folders) into campaigns/archive/ - never delete."""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = CAMPAIGN_DIR / "archive"
    dest.mkdir(parents=True, exist_ok=True)
    for suffix in ("", "-wal", "-shm"):
        src = CAMPAIGN_DIR / f"{name}.db{suffix}"
        if src.exists():
            src.rename(dest / f"{name}-{stamp}.db{suffix}")
    for folder in ("_art", "_undo", "_graph"):        # (_graph: the per-turn graph log goes with its world)
        src = CAMPAIGN_DIR / f"{name}{folder}"
        if src.exists():
            src.rename(dest / f"{name}-{stamp}{folder}")
    return f"archive/{name}-{stamp}.db"


async def open_table(campaign: str, channel, owner: str, timers: dict | None = None) -> CampaignTable:
    """Open (or create) a campaign and wrap it in a table. Session counting matches the console."""
    path = CAMPAIGN_DIR / f"{campaign}.db"
    loop = asyncio.get_running_loop()
    game = await loop.run_in_executor(None, lambda: Game(path))
    table = CampaignTable(game, channel, owner, timers)

    def prepare():
        from .. import charledger
        for pc in game.ledger.entities(kind="pc"):            # ledger runners: their progress goes home
            charledger.sync(game, pc["id"])
        # a portrait still 'pending' from an earlier run was never going to finish: free it to be painted again
        game.conn.execute("UPDATE art SET status='failed', error='interrupted (the bot stopped while painting)' "
                          "WHERE status='pending'")
        if game.ledger.meta("companions") is None:     # at a Discord table the GM plays PCs nobody has claimed
            game.set_companions(True)
        if game.ledger.current_scene() is None:
            if campaign in SEEDS:
                SEEDS[campaign](game)
            else:
                setup_blank(game, "Downtown Seattle", "rain-slick streets under corporate arcology lights, "
                                                      "neon signs in six languages, the Barrens glowing to the east")
            return None
        # a new session after a real break - a bot restart mid-evening keeps the same session
        if game.conn.execute("SELECT MAX(created_at) < datetime('now', ?) FROM turns WHERE status='committed' "
                             "AND session=?", (f"-{SESSION_GAP_HOURS} hours", game.ledger.session())).fetchone()[0]:
            return game.ledger.new_session()
        return None
    new_session = await table.run(prepare)
    await table.refresh()
    if new_session:
        await channel.send(f"-# Session {new_session} begins - everyone's Edge is back to full.")
        if await table.run(recap.previous_session_turns, game) >= 3:      # back after a break: previously on...
            loop.create_task(table.post_recap())
    return table
