"""Discord front end for the console-proven engine (DESIGN.md §4-5).

    the token in config.toml (or DISCORD_BOT_TOKEN), then:   .venv/Scripts/python.exe -m roleplay.discord_bot
    in a channel:                                            !rp start demo     (binds the channel to a campaign)
"""
