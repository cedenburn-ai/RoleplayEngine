"""Story directions (DESIGN.md §9b): the table steering the story from outside the turn.

`!narrative add Rook calls with a new job soon` puts a standing direction in front of the GM - at the top of every
packet - until it's done or someone removes it. It isn't a character's move and the characters don't know it: it's
the players, out of character, saying where they want the story to go. The GM works it in when it fits (over a turn
or several, never by derailing a scene) and says `narrative D2: done` in its <dm> block once it has landed; the table
sees that and can `!narrative add` it again if it hasn't.

The one-shot kind already exists - "Hey DM, ..." asides queue a direction for the next turn only (aside.py). These
stand until they're done. Like rulings, the commands run on a side connection (they answer mid-turn) and an undo keeps
what the table did (`keep`) - only a `done` the GM wrote in the undone turn goes with it.
"""
from __future__ import annotations

import re
import sqlite3

from .engine.ledger import LedgerError

MAX = 10
MAX_CHARS = 300
_ID = re.compile(r"^\s*(?:D\s*)?#?\s*(\d+)\s*:?\s*$", re.IGNORECASE)
SCHEMA = """CREATE TABLE IF NOT EXISTS narrative(      -- the table's standing story directions (narrative.py)
    id TEXT PRIMARY KEY, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',   -- active|done|removed
    by TEXT, by_name TEXT, created_turn INTEGER, closed_by TEXT, closed_turn INTEGER
)"""


def norm_id(did: str) -> str:
    """'D3', 'd3', '3', '#3' -> 'D3'."""
    m = _ID.match(did or "")
    return f"D{int(m.group(1))}" if m else (did or "").strip().upper()


def _ensure(conn: sqlite3.Connection) -> None:
    conn.execute(SCHEMA)


class _write:
    def __init__(self, conn: sqlite3.Connection):
        self.conn, self.own = conn, not conn.in_transaction

    def __enter__(self):
        _ensure(self.conn)
        if self.own:
            self.conn.execute("BEGIN IMMEDIATE")

    def __exit__(self, kind, exc, tb):
        if self.own:
            self.conn.execute("ROLLBACK" if kind else "COMMIT")
        return False


def _seq(conn) -> int:
    row = conn.execute("SELECT value FROM meta WHERE key='seq_narrative'").fetchone()
    top = conn.execute("SELECT MAX(CAST(substr(id, 2) AS INTEGER)) FROM narrative").fetchone()[0] or 0
    return max(int(row[0]) if row else 0, top)


def _turn(conn) -> int:
    return conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0]


def active(game) -> list[dict]:
    _ensure(game.conn)
    return [dict(r) for r in game.conn.execute("SELECT * FROM narrative WHERE status='active' ORDER BY rowid")]


def get(game, did: str) -> dict | None:
    _ensure(game.conn)
    row = game.conn.execute("SELECT * FROM narrative WHERE id=?", (norm_id(did),)).fetchone()
    return dict(row) if row else None


def _not_active(game, did: str) -> LedgerError:
    r, did = get(game, did), norm_id(did)
    if r:
        return LedgerError(f"{did} is already {r['status']}.")
    ids = ", ".join(x["id"] for x in active(game))
    return LedgerError(f"No direction {did}" + (f" - the table has {ids}." if ids else " - there are none yet."))


def add(game, text: str, by: str, by_name: str = "") -> dict:
    text = " ".join((text or "").split())
    if not text:
        raise LedgerError("Say where you want the story to go: `!narrative add <direction>`.")
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS - 3].rsplit(" ", 1)[0] + "..."
    c = game.conn
    with _write(c):
        if len(active(game)) >= MAX:
            raise LedgerError(f"There are already {MAX} directions standing - `!narrative remove D#` one first.")
        n = _seq(c) + 1
        c.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('seq_narrative', ?)", (str(n),))
        c.execute("INSERT INTO narrative(id, text, status, by, by_name, created_turn) VALUES(?,?,?,?,?,?)",
                  (f"D{n}", text, "active", by, by_name, _turn(c)))
    return get(game, f"D{n}")


def close(game, did: str, status: str, who: str) -> dict:
    """remove (the table) or done (the GM, from its <dm> block)."""
    c = game.conn
    with _write(c):
        r = get(game, did)
        if not r or r["status"] != "active":
            raise _not_active(game, did)
        c.execute("UPDATE narrative SET status=?, closed_by=?, closed_turn=? WHERE id=?", (status, who, _turn(c), r["id"]))
    return get(game, r["id"])


def clear(game, who: str) -> list[str]:
    ids = [r["id"] for r in active(game)]
    for did in ids:
        close(game, did, "removed", who)
    return ids


def keep(conn: sqlite3.Connection):
    """Call before an undo restores a snapshot, then call what this returns: the table's directions are the table's,
    not the turn's - adds and removals made since are put back. A `done` the GM wrote is the turn's: if the undone
    turn wrote it, the direction stands again."""
    _ensure(conn)
    before = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM narrative")}
    seq = _seq(conn)

    def put_back() -> None:
        _ensure(conn)
        after = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM narrative")}
        with _write(conn):
            for did, b in before.items():
                row = dict(b)
                if b["status"] == "done" and b["closed_by"] == "gm":
                    was = after.get(did)
                    row = was if was else {**b, "status": "active", "closed_by": None, "closed_turn": None}
                conn.execute(f"INSERT OR REPLACE INTO narrative({', '.join(row)}) VALUES({', '.join('?' * len(row))})",
                             tuple(row.values()))
            conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('seq_narrative', ?)",
                         (str(max(seq, _seq(conn))),))
    return put_back


def packet_lines(game) -> list[str]:
    rows = active(game)
    if not rows:
        return []
    return (["\n=== STORY DIRECTIONS FROM THE TABLE (the players, out of character, asking where the story should go - "
             "steer toward them over the coming turns as the fiction allows; the characters don't know them) ==="]
            + [f"[{r['id']}] {r['text']}" for r in rows]
            + ["(When one has landed, write `narrative D#: done` in your <dm> block.)"])


def listing(game) -> str:
    rows = active(game)
    if not rows:
        return ("No story directions standing. `!narrative add <where you want the story to go>` - the GM steers "
                "toward it until it's done or removed.")
    return "\n".join(f"**{r['id']}** {r['text']}" + (f"  · *{r['by_name']}, T{r['created_turn']}*" if r["by_name"] else "")
                     for r in rows) + f"\n-# {len(rows)}/{MAX} · `!narrative add <text>` · `!narrative remove D#`"
