"""The Matrix network map (DESIGN.md §7b, §7h): the host's nodes as the decker knows them, drawn - never hallucinated.

A Genesis-style graph: the host's nodes laid out left to right from the Entry, colored by security (blue open, green,
orange, red admin-only), each tagged with what it is to this decker (open, their login opens it, cracked, locked).
They see where they've been and what's next to it - unexplored nodes are dashed stubs with a "?" - and a search or
the Core shows more. Files and the building's devices sit in their nodes (copied, looped...); IC sits beside the node
it's in (awake ones bright, sleeping ones only once found); the deckers' icons stand where they are. The GM view
shows everything. If the host has art - its sculpting - it's the backdrop; otherwise a procedural grid.
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

from .engine.rules import hostmap, matrix, resonance, sr_lite
from .maps import Labels, _font, _label

W, H = 1400, 900
BG, GRIDC = (6, 10, 16), (18, 32, 44)
CYAN, AMBER, RED, DIM, INK, MAGENTA, GREEN = ((80, 220, 255), (255, 190, 60), (255, 70, 90), (90, 110, 130),
                                             (220, 232, 245), (230, 90, 255), (110, 255, 170))
SEC = {"blue": (90, 170, 255), "green": (110, 230, 150), "orange": (255, 165, 60), "red": (255, 70, 90)}
TAG = {"entry": "IN", "hub": "HUB", "datastore": "DATA", "comms": "COMM", "core": "CORE",
       "cameras": "CAM", "locks": "LOCK", "alarms": "ALARM", "elevators": "LIFT"}
R = 44


def _backdrop(game, hid: str) -> Image.Image:
    art = game.art.latest(game.conn, hid, ready_only=True)
    if art and Path(art["path"]).exists():
        img = Image.open(art["path"]).convert("RGB")
        scale = max(W / img.width, H / img.height)
        img = img.resize((int(img.width * scale) + 1, int(img.height * scale) + 1))
        left, top = (img.width - W) // 2, (img.height - H) // 2
        img = img.crop((left, top, left + W, top + H)).filter(ImageFilter.GaussianBlur(3))
        return ImageEnhance.Brightness(img).enhance(0.3)
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)
    for x in range(0, W, 40):
        d.line([(x, 0), (x, H)], fill=GRIDC)
    for y in range(0, H, 40):
        d.line([(0, y), (W, y)], fill=GRIDC)
    return img


def personas_in(game, hid: str) -> list[dict]:
    """Who's in the host now - on a live run (matrix.live: one the story left behind isn't, flag #11)."""
    L = game.ledger
    return [e for kind in ("pc", "npc") for e in L.entities(kind=kind)
            if (e["props"].get("matrix") or {}).get("host") == hid and matrix.live(L, e["id"]) == hid]


def host_for(game, eid: str) -> str | None:
    """The host a decker is in - or the last one they touched."""
    st = matrix.state(game.ledger, eid)
    return st.get("host") or st.get("last_host") or next(reversed(list((st.get("access") or {}).keys())), None)


def layout(hp: dict) -> dict[str, tuple[float, float]]:
    """The spine - Entry, the hubs, the Core - runs across the middle; what hangs off each spine node (datastores,
    the building's systems, Comms) fans out above and below, in the gap after it."""
    ent = hostmap.entry(hp)["id"]
    core = next((n["id"] for n in hp["nodes"] if n["kind"] == "core"), ent)
    spine = hostmap.path(hp, ent, core)
    on_spine = set(spine)
    slots = max(1, 2 * (len(spine) - 1))
    step = (W - 260) / slots
    mid_y = 470
    pos = {nid: (130 + 2 * i * step, mid_y) for i, nid in enumerate(spine)}
    for i, nid in enumerate(spine):
        leaves = [x for x in hostmap.node(hp, nid)["near"] if x not in on_spine and x not in pos]
        for k, leaf in enumerate(leaves):
            row, side = k // 2 + 1, (-1 if k % 2 == 0 else 1)
            x = 130 + (2 * i + 1) * step + (0 if row <= 2 else (row - 2) * 70 * side)
            y = mid_y + side * 140 * (row if row <= 2 else 2)
            pos[leaf] = (x, min(H - 140, max(195, y)))
    for n in hp["nodes"]:                              # (anything further out: next to whatever it hangs off)
        if n["id"] not in pos:
            px, py = next((pos[x] for x in n["near"] if x in pos), (W / 2, mid_y))
            pos[n["id"]] = (min(W - 130, px + step), py)
    return pos


def _dash(d, a, b, fill, width=2, step=14):
    n = max(1, int(math.dist(a, b) / step))
    for t in range(0, n, 2):
        p, q = t / n, min(1, (t + 1) / n)
        d.line([(a[0] + (b[0] - a[0]) * p, a[1] + (b[1] - a[1]) * p), (a[0] + (b[0] - a[0]) * q, a[1] + (b[1] - a[1]) * q)],
               fill=fill, width=width)


def render(game, eid: str, gm: bool = False, out: Path | None = None) -> Path:
    L = game.ledger
    hid = host_for(game, eid)
    if not hid:
        raise sr_lite.LedgerError(f"{L.require(eid)['name']} hasn't been in any host yet.")
    hp = hostmap.ensure(L, hid)
    host = L.require(hid)
    hr = int(hp.get("rating", 4))
    st = matrix.current(L, eid)                        # (a run that's over reads out: Overwatch 0, no trace)
    seen = set(n["id"] for n in hp["nodes"]) if gm else set((st.get("seen") or {}).get(hid, []))
    scanned = set(n["id"] for n in hp["nodes"]) if gm else set((st.get("scanned") or {}).get(hid, []))
    if not seen:                                       # (never been in: the Entry, at least)
        seen = {hostmap.entry(hp)["id"]}
    alert = int(hp.get("alert", 0))
    pos = layout(hp)
    img = _backdrop(game, hid)
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    d = ImageDraw.Draw(img)
    small, mid, big, huge = _font(15), _font(18, bold=True), _font(24, bold=True), _font(34, bold=True)
    people = personas_in(game, hid) or [L.require(eid)]
    copied = {i["props"].get("copied_from") for p in people for i in L.holdings(p["id"]) if i["props"].get("copied_from")}

    # links: solid between known nodes, a dashed stub with a "?" toward the unexplored
    done = set()
    for n in hp["nodes"]:
        if n["id"] not in seen:
            continue
        for x in n["near"]:
            key = tuple(sorted((n["id"], x)))
            if key in done:
                continue
            done.add(key)
            a, b = pos[n["id"]], pos[x]
            if x in seen:
                gd.line([a, b], fill=CYAN + (40,), width=10)
                d.line([a, b], fill=(70, 110, 140), width=3)
            else:
                mid_pt = (a[0] + (b[0] - a[0]) * 0.45, a[1] + (b[1] - a[1]) * 0.45)
                _dash(d, a, mid_pt, DIM)
                _label(d, mid_pt, "?", mid, DIM, anchor="mm")

    # nodes
    for n in hp["nodes"]:
        if n["id"] not in seen:
            continue
        x, y = pos[n["id"]]
        col = SEC[n["color"]]
        gd.ellipse([x - R - 14, y - R - 14, x + R + 14, y + R + 14], fill=col + (50 if n["kind"] == "core" else 30,))
        d.ellipse([x - R, y - R, x + R, y + R], fill=(10, 16, 24), outline=col, width=5 if n["kind"] == "core" else 4)
        if n.get("state"):
            d.ellipse([x - R + 8, y - R + 8, x + R - 8, y + R - 8], outline=CYAN, width=2)
    img = Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(6))).convert("RGB")
    d = ImageDraw.Draw(img)
    labels = Labels(d, (W, H))
    for n in hp["nodes"]:
        if n["id"] not in seen:
            continue
        x, y = pos[n["id"]]
        col = SEC[n["color"]]
        labels.reserve((x - R, y - R, x + R, y + R))
        _label(d, (x, y - 2), TAG.get(n.get("system") or n["kind"], n["kind"][:4].upper()), mid, col, anchor="mm")
        how = hostmap.open_to(st, hid, n)
        tag = {"open": "open", "login": "login", "cracked": "cracked", None: "locked"}[how]
        labels.place(x, y + R + 16, n["name"], mid, INK, gap=0, around=False, force=True)
        labels.place(x, y + R + 36, f"{n['color']} · {tag}", small, col if how else DIM, gap=0, around=False, force=True)
        row = y + R + 56
        if n["id"] in scanned or n.get("state"):
            for t in n["things"][:3]:
                thing = L.get(t)
                if not thing:
                    continue
                took = t in copied
                labels.place(x, row, thing["name"][:28] + (" - COPIED" if took else ""), small,
                             GREEN if took else AMBER, gap=0, around=False, force=True)
                row += 18
            if n.get("state"):
                labels.place(x, row, n["state"]["effect"][:32].upper(), small, CYAN, gap=0, around=False, force=True)

    # IC beside its node: awake ones always, sleeping ones once the node's been scanned
    by_node: dict[str, list] = {}
    for ic in hp.get("ic", []):
        if ic.get("node") in seen and (ic["active"] or ic.get("node") in scanned):
            by_node.setdefault(ic["node"], []).append(ic)
    for nid, ics in by_node.items():
        x, y = pos[nid]
        for i, ic in enumerate(ics):
            ix, iy = x + R + 26 + 34 * i, y - R + 6
            on = ic["active"]
            col = RED if on and ic["type"] in ("killer", "black ic") else AMBER if on else DIM
            d.polygon([(ix, iy - 15), (ix + 15, iy + 12), (ix - 15, iy + 12)], fill=(20, 10, 14) if on else (16, 18, 22),
                      outline=col, width=3)
            labels.place(ix, iy - 28, matrix.ic_name(ic["type"]).replace(" IC", "") + ("" if on else " zz"), small, col,
                         gap=0, around=False)

    # the deckers where they stand
    for k, p in enumerate(people):
        pst = matrix.current(L, p["id"])
        nid = pst.get("node") if pst.get("host") == hid else None
        if not nid or nid not in pos:
            continue
        x, y = pos[nid]
        px, py = x - R - 30 - 34 * k, y - R + 4
        d.polygon([(px, py - 18), (px + 14, py), (px, py + 18), (px - 14, py)], fill=(12, 20, 30), outline=GREEN, width=3)
        traced = matrix.traced_in(pst)                 # (this run's trace only - flags #17, #26)
        tags = ["VR" if pst.get("mode") == "vr" else "AR"] + (["TRACED"] if traced else []) \
            + (["STUCK"] if pst.get("tarred") else []) + (["VEILED"] if resonance.veiled(L, p["id"]) else [])
        labels.place(px, py - 30, f"{p['name']} · {' '.join(tags)}", small,
                     AMBER if traced or pst.get("tarred") else GREEN, gap=0, around=False, force=True)

    # header: title, the host's state, the Overwatch meter
    _label(d, (30, 38), "MATRIX", huge, CYAN)
    _label(d, (170, 40), host["name"] + ("  ·  GM VIEW" if gm else ""), big, INK)
    hcol = RED if alert >= 2 else AMBER if alert else CYAN
    _label(d, (W - 30, 40), f"rating {hr} · {['quiet', 'NOTICED', 'ALERT'][min(2, alert)]}", mid, hcol, anchor="rm")
    ow = int(st.get("overwatch", 0))
    x0, x1, yb = 30, W - 30, 80
    d.rectangle([x0, yb, x1, yb + 14], outline=DIM)
    d.rectangle([x0, yb, x0 + (x1 - x0) * min(1, ow / matrix.CONVERGENCE), yb + 14],
                fill=RED if ow >= matrix.ALERT else AMBER if ow >= matrix.NOTICED else CYAN)
    for mark, name in ((matrix.NOTICED, "noticed"), (matrix.ALERT, "alert"), (matrix.CONVERGENCE, "convergence")):
        mx = x0 + (x1 - x0) * mark / matrix.CONVERGENCE
        d.line([(mx, yb - 4), (mx, yb + 18)], fill=INK, width=2)
        _label(d, (mx - 4, yb + 28), name, small, DIM, anchor="rm" if mark == matrix.CONVERGENCE else "mm")
    who = L.require(eid)
    hurt = (f"mind {int(L.stat(eid, 'stun_damage'))}/{sr_lite.monitor_max(L, eid)[1]}" if matrix.living(L, eid)
            else f"deck {int(st.get('deck_damage', 0))}/{matrix.deck_monitor(matrix.deck(L, eid)[0])}"
            + (" BRICKED" if matrix.bricked(L, eid) else ""))
    _label(d, (x0, yb + 28), f"Overwatch {ow}/{matrix.CONVERGENCE} · {who['name']} · {hurt}"
           + (f" · host marks {st.get('marks')}/{matrix.TRACE_MARKS}" if st.get("marks") else ""), small, INK)

    # legend and the way in for new players
    lx, ly = 30, H - 30
    for c in ("blue", "green", "orange", "red"):
        d.ellipse([lx, ly - 8, lx + 16, ly + 8], outline=SEC[c], width=3)
        _label(d, (lx + 24, ly), {"blue": "open", "green": "light", "orange": "guarded", "red": "admin only"}[c], small, DIM,
               anchor="lm")
        lx += 130
    _label(d, (lx + 10, ly), "?  unexplored   ·   !matrixhelp - what you can do in here", small, DIM, anchor="lm")
    from .engine import clock
    _label(d, (W - 30, ly), clock.fmt(game.clock()), small, DIM, anchor="rm")
    out = out or (game.path.parent / "maps" / f"{game.path.stem}_matrix_{hid}{'_gm' if gm else ''}.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)
    return out
