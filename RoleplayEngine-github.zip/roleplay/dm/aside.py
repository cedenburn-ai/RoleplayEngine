"""The GM aside (DESIGN.md §4): a player talks to the GM out of character, and the GM answers - without moving the story.

Half of one night's turns opened "Hey DM...": questions, corrections, "reset that turn". Each became a full story turn
(half a minute of the GM's model, the plot nudged on while it answered - a player had to ask it to hold the story
still while a question was answered). A post addressed to the GM ("Hey DM", "DM,", "GM:", or `!gm ...`) comes here instead: the GM's model with
the table as it stands, a short out-of-character answer, and - when the player's right about a mistake - the fix,
recorded through the same lines a turn's <dm> block uses. A request to change the story ("skip to the office", "start
the fight") waits for the next turn as a direction from the table; a message that's really a move goes back into the
turn.

Before it answers, it may look things up (DESIGN.md §8e, 2026-10-26): "didn't we agree at T33 that..." was answered
from the packet's summaries and the last three turns, so the GM agreed or disagreed with a player about a turn it
never read. It has the GM's notebook now, read-only (recall, read_turn, search_memory, timeline), for a few rounds;
what it would change still goes in fixes, where the table hears what landed. Its answer is posted to the whole table,
so the notebook opens at the table's page (research.hidden): public turns and canon, the asker's own whispers - never
another player's whisper, the offscreen world, or the GM's notes, pictures and NPC minds.
"""
from __future__ import annotations

import json
import re

from ..engine.ledger import LedgerError
from ..substrate.packet import build_packet
from . import dmblock, spoilers
from .prompts import FICTION_NOTE
from .research import RESEARCH, _offscreen_roll as offscreen_roll, consult, roll_line, run as research_run
from .tools import TOOLS as GM_TOOLS, TurnContext

LOOKUPS = [t for t in GM_TOOLS if t["name"] in RESEARCH]   # the notebook - nothing in it changes the record
ROLLS_SHOWN = 12                                           # a turn's rolls in THE LAST TURNS (a fight round has more)

TO_GM = re.compile(r"^\s*(?:(?:hey|hi|yo|ok|okay|so|um|uh)\b[\s,]*)?(?:dm|gm)\b(?!['’]s\b)(?!\s+me\b)[\s,:.!?-]*",
                   re.IGNORECASE)
ABOUT_GM = re.compile(r"\b(the|this|that|our) (dm|gm|bot)\b|\bthe (game|rp) engine\b|\bengine (bugs?|issues?|problems?|"
                      r"errors?)\b", re.IGNORECASE)   # talk ABOUT the GM ("I start the engine" is a car - autoplay T10)
# Table talk no character would say (live, T158/T159/T161: a player saying the teamwork check had broken again, one that
# they'd reworded a post around the NPC, one that they'd mostly been filing bug reports on the GM's made-up house rules
# - each played as a story turn, and T159 moved the scene on it). Kept to words a runner
# wouldn't use in the fiction: a bug in the office, a camera loop and "you keep asking" stay moves - and anything this
# sends to the aside that's really a move, the aside hands back to the turn.
META = re.compile(r"\bbug ?reports?\b|\bbugreports?\b|\bbuggy\b|\bthat'?s a bug\b|\bhouse ?rules?\b|\bnpcs?\b|"
                  r"\bpronouns?\b|\bre-?word(ed|ing)?\b|\bmy rolls\b|\bteamwork (checks|rolls)\b|"
                  r"\b(getting|got|stuck|caught) (into|in) (another|a|the same) (narrative |story )?loop\b|"
                  r"\banother (narrative |story )?loop\b|\bgoing in circles\b|\bit keeps (trying|making|asking|"
                  r"doing|using|forgetting|ignoring)\b|\bthe (ai|llm|model)\b|\bout of character\b|\booc\b|"
                  r"\bbored (with|of) (this|the) (story|scene|plot|storyline)\b", re.IGNORECASE)


def table_talk(text: str) -> bool:
    """Out of character - to the GM ("Hey DM, ..."), about it ("the DM ignored it"), ((in double brackets)), or table
    talk no character would say (META). These go to the aside, never into the story."""
    t = text or ""
    return bool(TO_GM.match(t) or ABOUT_GM.search(t) or META.search(t) or t.lstrip().startswith("(("))
FIXABLE = ("note", "fact", "clarify", "tension", "resolve", "shelve", "time", "ruling", "ruled", "name", "karma",
           "flag", "fix", "doubt", "dismiss")
PUBLIC_FIXES = {"fact": "a fact", "time": "the time", "ruling": "a ruling", "name": "a name", "karma": "karma",
                "tension": "an open question", "resolve": "an open question", "shelve": "an open question",
                "note": "the GM's notes", "clarify": "the GM's notes", "ruled": "a ruling",
                "flag": "a flag for the developers", "fix": "the numbers",
                "doubt": "a doubt the GM will look into", "dismiss": "the GM's notes"}


def _public(e: dict) -> str:
    """What the table hears was fixed - `resolve X3` settles a doubt (the GM's notes), `resolve Q3` a question."""
    if e["kind"] == "resolve" and any(str(i).strip().strip("[]").upper().startswith("X") for i in e["ids"]):
        return "the GM's notes"
    return PUBLIC_FIXES.get(e["kind"], e["kind"])
DIRECTIONS = "table_directions"                # meta: what the table asked for between turns (the next turn does it)

SYSTEM = FICTION_NOTE + """ You are the game master of this Shadowrun campaign, played over Discord. A player is talking \
to you directly, out of character - between turns, not as their character. Step out of the story and answer them \
like a person at the table:
- Answer briefly and plainly, 1-4 sentences. No narration, no dice, and don't move the story on - the table hasn't \
taken a turn.
- Your answer is posted in the open channel: the whole table reads it. Answer only from what the table has seen. \
Never repeat - or hint at, or say there was - another player's whisper, anything offscreen (what NPCs do away from \
the crew), or your own GM-only notebook: DM notes, current pictures, NPC minds, personas and secrets, goals and \
hooks. Your packet holds some of that for your judgment - never to say. The whispers the asker sent are theirs to \
hear about; one done to their character is the sender's (a tracker slipped into their coat - "WHISPER ... only Ghost \
knows (Razor too, only if they noticed it)"): say nothing of it - what Razor noticed, the story shows him. When the \
honest answer turns on a secret, answer from what their character has seen ("nothing at the table says so") - a \
refusal ("I can't say") tells them there's something to find.
- Check the record before you answer a question about what happened, what was said or what was agreed ("didn't we \
agree at T33...", "Kaz already paid us", "I never said that"). The packet and the last turns are summaries; the \
record is the source: read_turn for the exact words (around: a phrase, for the passage), search_memory (in_narration \
for what was actually said, about for who it involves), timeline for what has happened between people, recall for a \
memory's whole record. Here they reach what the table has seen. A few lookups at most - several in one message - \
then answer; nothing there changes anything, so fixes are still how you set the record right. Rules and sheet \
questions need no lookup. Here, out of the story, saying what the table's record says is the point: "T33 has you \
agreeing to 5,000 by Friday." A turn you name, and when something happened, come from a turn you opened here - never \
from a stamp in the packet: [C83, T153] or (T150) beside a picture, note or fact is when it was last written down, \
not when it happened. Asked "when was that?", find the moment (search_memory with in_narration, then read_turn) \
before you say. Asked about a roll ("what did the host roll against my crack?"), quote it from the record: THE LAST \
TURNS gives each turn's rolls, read_turn an older turn's, and a Matrix roll's row has the host's (or the IC's) dice \
and hits beside the decker's.
- If they point out a mistake (continuity, who's who, a rule you misapplied, something you forgot) and they're right, \
own it in a sentence and fix what you can with fixes: lines exactly as in your <dm> block - `note <id>, <id>: ...`, \
`fact <ids> (replaces F2): ...`, `clarify <id>: ...`, `time: evening`, `ruling R3: drop`, \
`name <id>: <new name>` (a name the table already has, set right - never one from SEALED: between turns no play \
reveals it, and the engine refuses it), `tension ...` - and `flag: ...` when the engine itself got it wrong (the \
developers see flags). Ids are the [id]s from the packet or your lookups (people, T# turns, F#, Q#, X#), comma-separated: \
`note kaz, ghost: ...`. A fact from a turn names that turn too (`fact razor, ghost, T12: ...`): the \
characters who were there are the ones who remember it. If they're wrong, say so kindly and why - quote their sheet \
or the record.
- If the record disagrees with the player, or with itself, and even after looking you can't tell which is true - or \
what they remember isn't on file at all - don't guess and don't wave it off: say so plainly, and raise it in fixes \
as a doubt, `doubt <ids>: <what doesn't add up - both versions, and what they said>`, with every id on both sides. \
It stays on your DOUBTS list until it's settled, so your next turn researches it. One already on the DOUBTS list \
that you can settle now: `resolve X3: <what's true>` with the fix lines that make it true, or \
`dismiss X3: <why it never was one>`.
- A correction is never a new ruling. Fix the mistake and flag it; don't write a `ruling:` so it "won't happen \
again" - the table vetoes those, and the developers fix the cause. Write `ruling: ...` only when they ask you to \
settle a rule for good.
- If they're reporting a bug - something the engine or you keep getting wrong - thank them in a line and write a \
`flag:` with the concrete detail (what happened, on which turn, what they expected), so the developers can fix it.
- If they say the story is going in circles - an NPC asking again what they already answered, demanding the same \
answer, a conversation that won't land, a loop - set loop true (on a move too): the engine then hands the next turn a \
PACING note naming what's settled. They're right: say so in a line and that the next turn closes it - a promise only \
loop true keeps. Don't re-ask the question in your answer. A camera loop, or a question about what was said, isn't \
one (loop false).
- When you agree the NUMBERS are wrong - a retcon the engine still carries, Overwatch or a trace from a dive that was \
taken back, a host still on alert, a hook for something that never happened - set them right yourself with fix \
lines, one per change: `fix <decker>: overwatch 0`, `fix <decker>: trace off`, `fix <decker>: deck 0`, \
`fix <decker>: jack out`, `fix <host>: alert 0`, `fix <host>: ic off`, `fix H15: hook drop` - each with \
` - why` after it. A deadline or an NPC's plan the table ruled out, and an NPC built from the wrong stat block (a \
doctor carrying a rifle), are fixes too: `fix Q3: due off` (the question stays open), `fix A12: agenda`, \
`fix <npc>: template expert`. They apply at once and the table sees them. Never promise a fix you haven't made in \
fixes.
- If they ask for something in the story (skip ahead, start a fight, have someone turn up, frame the next scene), don't \
narrate it: put it in direction - one or two sentences the next turn will act on, posted with your answer (so in the \
names the crew knows) - and tell them it happens next turn.
- If they want a turn taken back or rerolled, the engine does that properly: tell them `!undo` (the table votes on \
it; again for the turn before, up to 10 back). Never pretend a turn away: a retcon in your notes doesn't touch the \
numbers (Overwatch, damage, money). For something older than undo reaches, say so, and fix the numbers you can - \
and `flag:` the ones you can't.
- Rules questions: answer from the rules and the table's rulings; for dice pools, the numbers on the sheet.
- Who plays which character is the engine's (`!join`, `!companion`, `!park`) - never a ruling.
- If it's table talk about you rather than to you (a remark to the other players about how the GM is doing), \
acknowledge it in a line or two - never move the story on it.
- If the message is really a move for their character (something their character does or says in the story), set \
is_move true and leave the rest empty (loop still says whether they called the story a loop): the engine sends it to \
the turn instead. If it's both - a move plus a remark to you - set is_move true too: the turn sees all of it, and \
nothing their character does is lost."""


def schema() -> dict:
    return {"type": "object", "properties": {
        "answer": {"type": "string"}, "direction": {"type": "string"},
        "fixes": {"type": "array", "items": {"type": "string"}}, "is_move": {"type": "boolean"},
        "loop": {"type": "boolean"}},
        "required": ["answer", "direction", "fixes", "is_move", "loop"], "additionalProperties": False}


def directions(game) -> list[str]:
    try:
        return json.loads(game.ledger.meta(DIRECTIONS) or "[]")
    except ValueError:
        return []


def add_direction(game, text: str) -> None:
    game.ledger.set_meta(DIRECTIONS, json.dumps((directions(game) + [text.strip()])[-5:]))


def clear_directions(game) -> None:
    game.ledger.set_meta(DIRECTIONS, "")


def _recent(game, n: int = 3) -> str:
    """The last few public turns: what the table posted, what the GM narrated - and what the dice said, every roll's
    row (research.roll_line: a Matrix roll's host dice too). Live, flag #25 (T106): asked to show the KD-4 host's roll
    against the T105 crack, the aside had the narration, which never gave the host's dice. (The world's offscreen rolls
    filed under a turn aren't the table's.)"""
    rows = game.conn.execute("SELECT id, inputs, narration FROM turns WHERE status='committed' AND private IS NULL "
                             "ORDER BY id DESC LIMIT ?", (n,)).fetchall()[::-1]
    out = []
    for r in rows:
        moves = "; ".join(f"{h}: {x}" for h, x in json.loads(r["inputs"] or "[]"))
        rolls = [dict(x) for x in game.conn.execute("SELECT * FROM tests WHERE turn_id=? ORDER BY id", (r["id"],))]
        rolls = [roll_line(game.ledger, x) for x in rolls if not offscreen_roll(x)]
        out.append(f"T{r['id']} - the table: {moves[:600]}\nT{r['id']} - you narrated: {(r['narration'] or '')[:1500]}"
                   + (f"\nT{r['id']} - the rolls:\n" + "\n".join(rolls[:ROLLS_SHOWN]) if rolls else "")
                   + (f"\n  (+{len(rolls) - ROLLS_SHOWN} more - read_turn T{r['id']} has them all)"
                      if len(rolls) > ROLLS_SHOWN else ""))
    return "\n\n".join(out) or "(no turns yet)"


def _look(ctx: TurnContext, block) -> dict:
    """One call the aside made: a lookup runs (research.run, as in a turn); anything else is turned away - what it
    would change goes in fixes, where the table hears what landed. A slip is the model's to retry, never a flag:
    nothing here writes (as !askdm's: witness.tool_result). Review (2026-10-26): through tools.run_tool, `recall` with
    no ids filed an engine 'tool error' flag on T{t+1} - a turn not played yet, so the dashboard pinned the aside's
    slip on whatever turn came next."""
    if block.name not in RESEARCH:
        return {"type": "tool_result", "tool_use_id": block.id, "is_error": True,
                "content": f"No {block.name} in an aside - only lookups ({', '.join(RESEARCH)}). What you'd change "
                           "goes in fixes."}
    try:
        args = block.input if isinstance(block.input, dict) else json.loads(block.input)
        return {"type": "tool_result", "tool_use_id": block.id, "content": research_run(ctx, block.name, args)}
    except (LedgerError, KeyError, ValueError, TypeError, OverflowError) as exc:
        return {"type": "tool_result", "tool_use_id": block.id, "is_error": True,
                "content": f"Error: {exc if not isinstance(exc, KeyError) else f'missing field {exc}'}"}


def ask(game, who: str, text: str, handle: str | None = None) -> dict:
    """`who` is how the player reads to the GM ("Alice (plays Razor [razor])"). Returns {answer, direction, fixed (what
    kinds of record it fixed), cards, checked (the turns it looked at), is_move}."""
    scene_id = game.current_scene_id()
    t = game.turn_no()
    # a loop complaint is the table's to make here too: the next turn's pacing check hears it, and it's decisive there
    # (flag #45: live T158's "I think I'm getting into another loop" is table talk now - no turn's check saw it). The
    # words are heard now, so a failed answer loses nothing; the answer's own `loop` settles it below.
    from . import pacing
    pacing.heard(game, who, text)
    packet, _ = build_packet(game, scene_id, [(handle, text)] if handle else [], t + 1)
    pending = directions(game)
    user = (f"STORY TIME: {game.clock_line()}\n\n<memory_packet>\n{packet}\n</memory_packet>\n\n"
            f"THE LAST TURNS (oldest first):\n{_recent(game)}\n\n"
            + ("ALREADY ASKED FOR THE NEXT TURN: " + " | ".join(pending) + "\n\n" if pending else "")
            + f"{who} SAYS TO YOU, OUT OF CHARACTER:\n{text}")
    # (the next turn's: the last one is on file to read) - at the table: the answer is posted for everyone, so its
    # lookups reach what the table has seen and the asker's own whispers (research.hidden)
    asker = (game.character_for(handle) or {}).get("id") if handle else None
    look = TurnContext(game, t + 1, scene_id, by="aside", for_table=True, asker=asker)
    reply, stop, _ = consult(game, game.settings.models.dm, SYSTEM, user, LOOKUPS, lambda b: _look(look, b),
                             game.settings.models.aside_research_steps, schema(), max_tokens=4000, effort="low",
                             fallback=game.settings.models.commit, purpose="aside")
    if stop == "refusal":
        raise RuntimeError("aside refused")
    data = json.loads(reply)
    # The aside promises "the next turn closes it" on its own read of the complaint - so its read arms the hand-off,
    # not only the words pacing knows (review, 2026-10-27: "hey dm Kaz is looping", "the NPCs keep asking for a
    # straight answer" got the promise and no PACING note). A move goes to the turn, which reads the post itself.
    judged = data["loop"] if isinstance(data.get("loop"), bool) else None
    pacing.heard(game, who, text, judged=judged, drop=bool(data.get("is_move")) and not judged)
    if data.get("is_move"):
        return {"answer": "", "direction": "", "fixed": [], "cards": [], "checked": [], "is_move": True}
    if look.expanded:              # what it opened by id gets the lookup touch, as !askdm's do ("retrieval is a touch")
        game.sub.touch(sorted(look.expanded), t, game.settings.knobs.lookup_quantum)
    # The table hears which turns it checked - public ones only: that a whisper bore on the answer is the whisper's.
    public = {r[0] for r in game.conn.execute("SELECT id FROM turns WHERE private IS NULL")}
    checked = sorted((x for x in look.expanded if re.fullmatch(r"T\d+", x) and int(x[1:]) in public),
                     key=lambda x: int(x[1:]))
    fixed, cards = [], []
    lines = [x.strip() for x in data.get("fixes") or [] if x and x.strip()]
    if lines:
        _, entries = dmblock.split("<dm>\n" + "\n".join(lines) + "\n</dm>")
        entries = [e for e in entries if e["kind"] in FIXABLE or e["kind"] == dmblock.UNREAD]   # (unread: logged)
        if entries:
            ctx = TurnContext(game, t, scene_id, by="aside")
            dmblock.apply(ctx, entries)
            # (quoted in the aside's card, posted to the whole table: the fix's why is the GM's own words - its g.out
            # copy went through the out hook, this one never did)
            cards = [spoilers.scrub(game, c)[0] for c in ctx.cards if c.startswith("[FIX]")]
            # only what landed: a note on no one on file, or a time: the clock can't read, isn't "fixed" (live T83)
            landed = [e for e in entries if not any(e is u for u in ctx.unplaced)]
            fixed = sorted({_public(e) for e in landed if e["kind"] != "fix" or cards})
    # (posted to the whole table, from the GM's packet: never a name the table hasn't learned - spoilers.py. The
    # direction too: the card says it under "Next turn" - review 2026-10-28)
    direction = spoilers.answer(game, (data.get("direction") or "").strip(), "The aside's direction", t)
    if direction:
        add_direction(game, direction)
    said = spoilers.answer(game, (data.get("answer") or "").strip(), "The aside's answer", t)
    return {"answer": said, "direction": direction, "fixed": fixed, "cards": cards, "checked": checked,
            "is_move": False}
