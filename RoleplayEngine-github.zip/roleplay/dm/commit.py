"""Commit: turn one finished turn into memory (DESIGN.md §3, §8).

Haiku extracts the summary, who was involved and how, which old memories were used, and any
new canon. Then the engine writes the time slice, links everything, and does the turn's ONE
batch touch - origins are what was *used*, not everything that was shown.
"""
from __future__ import annotations

import re

from ..engine import geo
from ..engine.rules import magic, sr_lite
from ..substrate.rumors import spread_rumors
from . import dmblock, doubts, research, spoilers, tensions
from .. import encounters, jobs, seed, shops
from .clarify import fold_scene
from .minds import cool, reflect_scene
from .prompts import COMMIT_SYSTEM, SCENE_SUMMARY_SYSTEM, commit_schema
from .tools import TurnContext


def _fallback_extraction(narration: str) -> dict:
    sentences = re.split(r"(?<=[.!?])\s+", narration.replace("\n", " ").strip())
    return {"summary": " ".join(sentences[:2])[:500] or "(no narration)", "members": [], "recalled": [],
            "facts": [], "new_entities": []}


def commit_turn(game, ctx: TurnContext, start_scene: int, roster_at_start: list[str],
                inputs: list[tuple[str, str]], narration: str, shown: set[str], private: dict | None = None) -> dict:
    """`private` is a whisper's sender: only who actually perceived it witnesses it, the scene stays put,
    and its slice and facts are marked private so nothing public (recaps, rumors, art) repeats them."""
    L, S, knobs, t = game.ledger, game.sub, game.settings.knobs, ctx.turn_id

    # who could plausibly be involved: the room, the introduced, the named, and anyone active
    # in this scene's recent turns or created lately (so "the drone" resolves instead of duplicating)
    recent_members = [r["node_id"] for r in game.conn.execute(
        "SELECT DISTINCT m.node_id FROM members m JOIN nodes n ON n.id=m.slice_id "
        "WHERE n.scene_id=? AND n.created_turn>=? AND m.role<>'recalled'", (start_scene, t - 6))]
    recent_created = [r["id"] for r in game.conn.execute(
        "SELECT id FROM entities WHERE created_turn>=? AND tier>=1", (t - 10,))]
    candidates = dict.fromkeys(roster_at_start + L.roster(ctx.scene_id) + ctx.introduced
                               + game.resolve_mentions(narration + " " + " ".join(x for _, x in inputs))
                               + recent_members + recent_created)
    known = [L.get(e) for e in candidates]
    in_scene = set(roster_at_start) | set(L.roster(ctx.scene_id))
    # Someone a story seed sealed is here by their handle alone: nothing of them is the crew's yet, and their
    # description is the GM's (rehearsal round 1, 2026-10-28: a sealed NPC nobody had met reached this pass described
    # by the GM file's plot - the pass writes the public summary)
    sealed = seed.sealed_ids(game.conn)
    known_lines = "\n".join(f"{e['id']}: {e['name']} ({e['kind']}{', in the scene' if e['id'] in in_scene else ''})"
                            + (f" aka {', '.join(e['aliases'])}" if e["aliases"] else "")
                            + (f" - {e['description'][:90]}" if e["description"] and e["id"] not in sealed else "")
                            for e in known if e)
    # the extractor needs the memories' TEXT to judge which ones the narration drew on
    # recall means reaching back: the scene's recent turns are continuity (the spine carries that),
    # so they are not recall candidates - otherwise every turn "recalls" the last four
    recent_window = {r["id"] for r in S.recent_slices(start_scene, 6)}
    # what the GM's lookups showed it (search hits, timeline lines) can be recalled too - research.candidates
    looked = shown | ctx.expanded | research.candidates(ctx)
    memory_ids = sorted(i for i in looked if re.match(r"^[TSF]\d+$", i) and i not in recent_window)
    mem_rows = [S.node(i) for i in memory_ids]
    mem_lines = "\n".join(f"[{n['id']}] {n['text'][:240]}" for n in mem_rows if n and n["created_turn"] < t)
    known_facts = {f["id"]: f for e in known if e for f in S.facts_for(e["id"], 8)}
    # (with a settled doubt's answer beside it: a slip it already checked - a dismissed false positive above all - is
    # not one to flag again; review 2026-10-26: the pass never saw the doubts, so it flagged the same one every turn)
    fact_lines = "\n".join(sorted(f"[{f['id']}] {f['text'][:200]}{doubts.answers(game, f['id'])}"
                                  for f in known_facts.values()))
    sc = L.scene(start_scene)
    here = L.get(sc["location_id"]) if sc and sc["location_id"] else None
    whisper = (f"PRIVATE TURN (a whisper): {private['name']} [{private['id']}] did this discreetly. Members are ONLY "
               f"{private['name']} and anyone the narration says actually noticed or was knowingly part of it - "
               "everyone else in the scene did NOT witness it, leave them out. Whoever it was done to without their "
               "noticing (robbed, spied on, hacked unseen) is mentioned, not target. moved_to.location must be "
               "empty. Facts only if the narration establishes something durable.\n\n") if private else ""
    fight = encounters.active(game, start_scene) if not private else None
    # Live T164/T168: a fight that broke out after a mid-turn cut_scene wasn't stepped (only the start scene's was), so
    # it sat at its jump a turn too long - its flat-footed couldn't dodge the next turn's blows either - and an end the
    # GM called in it landed a turn late.
    after_cut = encounters.active(game, ctx.scene_id) if ctx.scene_changed is not None and not private else None
    # Out and back in one turn (cut away, then resume the start scene): the turn ends where it began, so the start
    # scene's fight is the one fight - not stepped twice, not ended because a scene cut (review: round +2 in one turn,
    # two fight_end events, two fight memories paid for).
    if after_cut and fight and after_cut["id"] == fight["id"]:
        after_cut = None
    reading = after_cut or fight                   # (the battlefield the memory pass reports moves on)
    places = ", ".join(geo.GAZETTEER)
    user = whisper + (f"METROPLEX DISTRICTS/LANDMARKS (for where): {places}\n"
                      f"CURRENT SCENE: S{start_scene} \"{sc['title']}\" at "
            f"{here['name'] + ' [' + here['id'] + ']' if here else 'an unnamed place'} - judge moved_to against this.\n\n"
            f"KNOWN ENTITIES (id: name, kind):\n{known_lines}\n\n"
            f"EARLIER MEMORIES THE GM COULD SEE (candidates for 'recalled'):\n{mem_lines or '(none)'}\n\n"
            f"FACTS ALREADY KNOWN (never repeat or rephrase these):\n{fact_lines or '(none)'}\n\n"
            + (encounters.commit_lines(game, reading) + "\n\n" if reading else "")
            + (jobs.commit_lines(game) + "\n\n" if not private else "")
            + "PLAYER INPUTS:\n" + "\n".join(f"{h}: {x}" for h, x in inputs) + "\n\n"
            # (a GM-only line by its kind and ids: this pass writes the public summary - dmblock.for_memory)
            "ENGINE EVENTS (authoritative - dice and state changes):\n" + (dmblock.for_memory(game, ctx.events)
                                                                         or "(none)") + "\n\n"
            f"NARRATION:\n{narration}")
    extraction_failed = False
    game.progress("📝 writing it into the story's memory", "memory")
    try:
        data = game.llm.structured(game.settings.models.commit, COMMIT_SYSTEM, user, commit_schema(),
                                   effort=game.settings.models.commit_effort, purpose="memory")
    except Exception as exc:
        game.out(f"  (memory extraction failed, using a plain summary: {exc})")
        data = _fallback_extraction(narration)
        extraction_failed = True
    # the backstop under it: nothing it files says a name the table hasn't learned, and nobody sealed is unsealed by
    # being talked about - or put in a moment the narration never showed them in (spoilers.memory, DESIGN.md §12l)
    data = spoilers.memory(game, data, narration, t, roster_at_start)

    if not private and not extraction_failed and data.get("job_moved"):    # the crew's runs (jobs.py)
        try:
            for line in jobs.extract(game, t, user):
                ctx.events.append(line)
                game.out(f"[{line}]")
        except Exception as exc:                   # a job missed is a line on the dashboard, never a lost turn
            game.out(f"  (job tracking failed this turn: {exc})")

    # new named things the DM didn't formally introduce still get tracked (tier 1)
    newcomers: list[str] = []
    for ne in data.get("new_entities", []):
        if not L.find(ne["name"]):
            template = "civilian" if ne["kind"] == "npc" else None     # (a faction gets its profile offscreen)
            aliases = [a for a in ne.get("aliases", []) if a and not L.find(a)]
            eid, _ = game.introduce(ne["kind"], ne["name"], ne.get("description", ""), template, aliases, turn=t,
                                    where=ne.get("where"))
            game.out(f"[NEW] {ne['kind']}: {ne['name']} [{eid}] (from narration)")
            if ne.get("present") and ne["kind"] in ("npc", "item"):
                newcomers.append(eid)

    members: dict[str, str] = {}
    rank = {"actor": 4, "target": 3, "present": 2, "location": 2, "remote": 1.5, "mentioned": 1}

    def add(eid: str, role: str) -> None:
        if role not in rank:
            return
        if rank[role] > rank.get(members.get(eid, ""), 0):
            members[eid] = role

    for m in data.get("members", []):
        ent = L.find(m.get("id", ""))
        if ent:
            add(ent["id"], m.get("role", "present"))
    for handle, _ in inputs:                       # whoever acted is an actor (a PC, or an inhabited NPC)
        ch = game.character_for(handle)
        if ch:
            add(ch["id"], "actor")
    scene = L.scene(start_scene)
    if extraction_failed and not private:          # no judgment available: assume the room saw it
        for eid in roster_at_start:
            ent = L.get(eid)
            if ent and eid != scene["location_id"]:
                add(eid, "present")
    # otherwise the extractor's members ARE the witnesses: being in the scene isn't enough if you
    # were across the street or on the other end of a phone (knowledge boundaries stay honest)
    for eid in newcomers:                          # in the room per the narration
        add(eid, "present")
    if scene["location_id"]:
        members[scene["location_id"]] = "location"

    # anyone the narration put in the room but the DM forgot to move in
    in_room = set(L.roster(ctx.scene_id))
    strays = [e for e, r in members.items()
              if r in ("actor", "target", "present") and e not in in_room and e not in roster_at_start
              and (L.get(e) or {}).get("kind") == "npc"]
    if strays:
        game.enter_scene(strays, t, ctx.scene_id)
    for eid in members:
        S.ensure_entity(L.get(eid), t)
    on_the_line = [e for e, r in members.items() if r == "remote"]   # a voice on a call: heard it, saw nothing

    allowed = looked
    recalled = [r.upper() for r in data.get("recalled", [])
                if r.upper() in allowed and r.upper() not in recent_window and S.exists(r.upper())
                and S.node(r.upper())["created_turn"] < t]
    summary = data.get("summary") or _fallback_extraction(narration)["summary"]
    # (story time is narrative now: a turn doesn't tick it - the GM moves it with `time:` when the story does)
    hows = {}                                       # encounter id -> how it ended this turn
    c = data.get("combat") or {}
    rounds = [f for f in (fight, after_cut) if f and not encounters.opening(f, t)]   # (no blow yet: no round)
    for f in rounds:                                # a fight: the round goes in its log, not the memory graph
        cx = c if f is reading else {}
        hows[f["id"]] = encounters.step(game, encounters.get(game, f["id"]), t, summary, cx.get("moves") or [],
                                        members, cx.get("zones") or None, cx.get("yields") or []) or (
            (cx.get("how") or "it was over") if cx.get("over") else None)
    fight_how = hows.get(fight["id"]) if fight else None
    if rounds:
        slice_id = None
    else:
        slice_id = S.write_slice(t, start_scene, summary, list(members.items()), recalled, story_time=game.clock())
        if private:
            S.set_visibility(slice_id, "private")
        for eid in on_the_line:                  # what they know of it is what came down the line
            S.add_knows(eid, slice_id, "on the line", None, t)

    for line in tensions.step(game, t, members, ctx.tensions_touched):     # pressure: neglect builds it
        ctx.events.append(line)

    new_facts = []
    for f in data.get("facts", [])[:3]:
        about = [e["id"] for e in (L.find(a) for a in f.get("about", [])) if e]
        for a in about:
            S.ensure_entity(L.get(a), t)
        new_facts.append(S.add_fact(f["text"], about, t, slice_id, replaces=(f.get("replaces") or None),
                                    confidence=0.85, by="commit"))
        if private:
            S.set_visibility(new_facts[-1], "private")

    # A narration that contradicts a fact the pass was shown: a doubt for the GM, never a quiet second version - it
    # already compares each narration with FACTS ALREADY KNOWN to avoid restating them (DESIGN.md §12k). One a turn, on
    # a fact it was really shown, and one doubt a fact (doubts.slip): the same slip again bumps the open one, stays
    # dismissed when the GM dismissed it, reopens a resolved one.
    for c in (data.get("contradictions") or [])[:1]:
        fid, how = str(c.get("fact") or "").strip().strip("[]").upper(), " ".join(str(c.get("how") or "").split())
        if fid in known_facts and how:
            r = doubts.slip(game, fid, how, t, slice_id)
            if r["status"] == "settled":
                game.out(f"  (memory pass: T{t} against {fid} again - {r['id']} was dismissed: "
                         f"{r['doubt']['resolution']})")
                continue
            ctx.events.append(f"DOUBT {r['id']} ({r['status']}, the memory pass): T{t} against {fid} - {how}")
            game.out(f"[DOUBT] {r['id']} {r['status']} (the memory pass): T{t} against {fid} - {how}")

    heard = 0                                      # hearsay: the listener now knows, second-hand
    for told in data.get("told", []):
        listener, teller = L.find(told.get("listener", "")), L.find(told.get("teller", ""))
        mem = (told.get("memory") or "").upper()
        if listener and mem in allowed and S.exists(mem):
            witnessed = game.conn.execute(
                f"SELECT 1 FROM members WHERE slice_id=? AND node_id=? AND role IN "
                f"({','.join('?' * len(knobs.witness_roles))})", (mem, listener["id"], *knobs.witness_roles)).fetchone()
            if not witnessed and S.add_knows(listener["id"], mem, "told", teller["id"] if teller else None, t):
                heard += 1

    # The turn's touches. The slice is the hyperedge: it takes the one full deposit and its member
    # links carry energy to everyone in the turn. What was actually *retrieved* - memories the turn
    # recalled, nodes the DM expanded, things the players named - gets a retrieval touch on top
    # ("retrieval is a touch"). Touching every member at full quantum, as the first build did,
    # minted ~15 quanta a turn into a ~50-node world: the mean grew 2.4x per turn and anything
    # untouched for two turns was effectively forgotten.
    stats = S.touch([slice_id] if slice_id else [], t, 1.0)
    mentioned = [e for e, r in members.items() if r == "mentioned"]
    retrieved = list(dict.fromkeys(recalled + sorted(ctx.expanded) + mentioned))
    if retrieved:
        S.touch(retrieved, t, knobs.retrieval_quantum)

    # art for anything in this turn that doesn't have a picture yet (a few per turn; the story so far,
    # including this turn, shapes the prompt). Never regenerates: the art table remembers.
    art_queued = []
    if game.art.active and not private:            # art posts publicly when ready; a whisper waits for the open
        for eid in list(dict.fromkeys(list(members) + ctx.introduced + newcomers)):
            if len(art_queued) >= knobs.art_per_turn or members.get(eid) == "mentioned":
                continue
            ent = L.get(eid)
            if ent and ent["tier"] >= 1 and ent["kind"] in ("pc", "npc", "location", "item", "drone", "vehicle", "host") \
                    and not game.art.has_art(game.conn, eid):
                if game.request_art(eid) == "queued":
                    art_queued.append(eid)

    # the whole party ended the turn somewhere else and the DM didn't cut: the engine cuts (or
    # resumes the parked scene at that place), so scene-close mechanics actually happen
    auto = None
    moved = data.get("moved_to") or {}
    if ctx.scene_changed is None and not private and (moved.get("location") or "").strip():
        auto = auto_cut(game, ctx, start_scene, moved, t)

    fought = set()
    left = ctx.scene_changed is not None and ctx.scene_id != start_scene     # the turn ended away (auto_cut too)
    if fight and (fight_how or left):               # the whole fight becomes one memory, before any scene close
        how = fight_how or "the scene moved on"     # reads the scene back (a closing start scene reflects anyway)
        enc = encounters.get(game, fight["id"])
        fought = set(enc["members"])
        fs = encounters.end(game, enc, t, how, reflect=ctx.scene_changed != start_scene)
        ctx.events.append(f"FIGHT OVER ({how})" + (f" -> memory {fs}" if fs else ""))
    if after_cut and hows.get(after_cut["id"]):     # (its scene isn't the one closing: it reflects on its own)
        how = hows[after_cut["id"]]
        fs = encounters.end(game, encounters.get(game, after_cut["id"]), t, how, reflect=True)
        ctx.events.append(f"FIGHT OVER ({how})" + (f" -> memory {fs}" if fs else ""))
    for f in rounds:                                # the next round's Initiative - only now that it's known the fight
        enc = encounters.get(game, f["id"])          # goes on (step's how, a scene that closed: rolled, it would be
        if enc and enc["status"] == "active":        # dice and an event for a round nobody gets to play)
            encounters.roll_initiative(game, enc, t)
            line = encounters.summary(game, encounters.get(game, f["id"]))
            ctx.events.append(f"INITIATIVE round {enc['round'] + 1}: {line}")
            game.out(f"  (fight: round {enc['round'] + 1} Initiative - {line})")   # (the table's card: session)

    time_passes(game, ctx, roster_at_start)          # the dying bleed; outside a fight, the hurt rest
    magic.regrow_barriers(game.ledger, t)            # a held Physical Barrier is whole again next Combat Turn (p. 294)
    from ..engine.rules import matrix                # a Matrix run the story left behind ends, quietly (flag #11) -
    ctx.events += matrix.story_out(game.ledger, t, narration)   # one it logs off (or takes back: live T47) at once -
    matrix.keep(game.ledger, t, members, narration)  # and one the narration still has them in goes on (live T181-T188:
    ctx.events += matrix.end_stale_runs(game.ledger, t)   # Filament on Lim's gate camera, no Matrix move since T180)
    # What was bought for delivery is here once the clock gets there - on a table turn: a whisper's cards go only to
    # the whisperer (review E2: Ghost's Steel Lynx was delivered inside Razor's whisper, and only Razor saw it).
    for c in (shops.arrivals(game, t) if not private else []):
        ctx.cards.append(c)
        game.out(c)
        ctx.events.append(c)

    beliefs = []
    if ctx.scene_changed is not None:
        game.progress("🎬 closing the scene - the NPCs take it in", "close")
        left_to_die(game, ctx.scene_changed, t)                  # (before anyone reflects: the dead don't)
        beliefs += reflect_scene(game, ctx.scene_changed, t, fought)     # minds settle when a scene ends
        fold_scene(game, ctx.scene_changed, t)                   # and the GM's notebook gets tidied
        spread_rumors(game, ctx.scene_changed, t)                # and word gets around
        close_scene(game, ctx.scene_changed, t)
        cool(game, t)                                            # and old feelings fade with time apart
    else:
        n_slices = game.conn.execute("SELECT COUNT(*) FROM nodes WHERE kind='slice' AND scene_id=?",
                                     (start_scene,)).fetchone()[0]
        if knobs.reflect_every and n_slices % knobs.reflect_every == 0 and not fight:
            game.progress("🧠 the NPCs take it in", "minds")
            beliefs += reflect_scene(game, start_scene, t)      # long scenes reflect along the way
            fold_scene(game, start_scene, t)
    return {"slice_id": slice_id, "recalled": recalled, "facts": new_facts, "newcomers": newcomers,
            "members": members, "stats": stats.__dict__, "extraction": data, "heard": heard, "beliefs": beliefs,
            "auto_cut": auto, "art_queued": art_queued, "introduced": list(ctx.introduced) + newcomers,
            "trip": _trip_text(game, start_scene, ctx.scene_id)}


def _went_by(minutes: int) -> str:
    """'40 minutes went by', 'an hour went by', '11 hours went by', '3 days went by' - the [HEAL] card's why."""
    hours = minutes // 60
    if not hours:
        return f"{minutes} minute{'s' * (minutes != 1)} went by"
    if hours < 48:
        return "an hour went by" if hours == 1 else f"{hours} hours went by"
    return f"{hours // 24} days went by"


def hurt_this_turn(game, turn: int) -> set[str]:
    """Who took a new wound this turn - any damage but bleeding (that's the clock's own)."""
    return {e["actor"] for e in game.ledger.events(turn) if e["kind"] == "damage" and e["actor"]
            and e["payload"].get("boxes") and e["payload"].get("how") != "bleeding"}


def time_passes(game, ctx: TurnContext, roster_at_start: list[str]) -> list[str]:
    """What the story time that went by this turn (the clock across it: `time:` lines) does to bodies. Everyone dying
    in the scenes the turn touched bleeds - a box every Body minutes until stabilized (SR5 p. 170) - and, outside a
    fight, everyone hurt rests: Stun by the hour, then Physical by the day, the time adding up across turns, and a
    month or more heals them whole (p. 207; sr_lite.recover). The PCs anywhere, the NPCs on screen - and after a month,
    the NPCs offscreen too (logged, not carded). The cards go to the table. Live T175-T178: eleven hours passed and
    Magic still carried 7 boxes of drain; Hollow Joe lay dying the whole time.
    Anyone hurt this turn sits this turn's time out, bleeding and resting alike: the `time:` line lands after the
    tools, so the engine can't tell a skip before the wound from one after it. Review: "three hours later the Ancients
    come through the door; Razor cuts Joey down" bled Joey to death for the three hours before the cut, with the fight
    still on and nobody given a chance to stabilize him. Their clock starts with the next turn's. (Fights don't move
    the clock either, so nobody bleeds out mid-fight - left_to_die closes that at scene end.)"""
    if ctx.clock_start is None:
        return []
    minutes = game.clock() - ctx.clock_start
    if minutes <= 0:
        return []
    L, t = game.ledger, ctx.turn_id
    fresh = hurt_this_turn(game, t)
    here = [e for e in (L.get(x) for x in dict.fromkeys(roster_at_start + L.roster(ctx.scene_id)))
            if e and e["kind"] in ("pc", "npc") and e["id"] not in fresh]
    cards = [c for c in (sr_lite.bleed(L, t, e["id"], minutes) for e in here) if c]
    if not encounters.active(game, ctx.scene_id):
        why = _went_by(minutes)
        seen = dict.fromkeys([e["id"] for e in here] + [p["id"] for p in L.entities(kind="pc") if p["id"] not in fresh])
        for eid in seen:
            cards += sr_lite.recover(L, game.dice, t, eid, minutes, why)
        if minutes >= sr_lite.MEND_ALL:              # a month or more: the whole world's mended, offscreen too
            for npc in L.entities(kind="npc"):       # (live: two KD-4 staff hurt at T65 were still hurt six months on)
                if npc["id"] not in seen and npc["id"] not in fresh:
                    for line in sr_lite.recover(L, game.dice, t, npc["id"], minutes, why):
                        game.out(f"  (offscreen) {line[7:]}")
    for c in cards:
        ctx.cards.append(c)
        game.out(c)
        ctx.events.append(c.splitlines()[0])
    return cards


def left_to_die(game, scene_id: int, turn: int) -> list[str]:
    """The scene moves on and leaves an NPC dying, still bleeding, with nobody conscious there to help: they die (SR5
    p. 170 - a box every Body minutes "if no medical attention is available", and none is coming). Fights don't move
    the story clock, so this is where bleeding out actually happens. Anyone stabilized, or left with someone awake who
    could help or call for it, is the offscreen world's to decide; a PC's fate is never settled here. Live: Hollow Joe
    was left dying in the Boathouse at T177 after 'make sure everyone is dead', and the world pass paid a clinic for his
    care at T188. Returns the ids who died."""
    L = game.ledger
    left = [e for e in (L.get(x) for x in L.roster(scene_id)) if e and e["kind"] in ("pc", "npc")]
    if any(sr_lite.condition(L, e["id"]) not in sr_lite.OUT for e in left):
        return []
    dead = []
    for e in left:
        if e["kind"] != "npc" or sr_lite.condition(L, e["id"]) != "dying" or L.stat(e["id"], "stabilized", 0):
            continue
        pmax, _ = sr_lite.monitor_max(L, e["id"])
        boxes = int(pmax + L.stat(e["id"], "body", 2) + 1 - L.stat(e["id"], "physical_damage"))
        L.add_stat(e["id"], "physical_damage", boxes)
        L.log(turn, "damage", e["id"], {"boxes": boxes, "type": "physical", "status": sr_lite.condition(L, e["id"]),
                                        "how": "left to die"})
        game.out(f"  (scene close: {e['name']} was left dying with nobody to help - bled out, dead)")
        dead.append(e["id"])
    return dead


def _trip_text(game, from_scene: int, to_scene: int) -> str | None:
    """'across town from Granny Brisk's Rooms' - how far the crew came, in words (no minutes to keep track of)."""
    if from_scene == to_scene:
        return None
    a, b = game.ledger.scene(from_scene), game.ledger.scene(to_scene)
    ga = geo.geo_of(game, a["location_id"]) if a and a["location_id"] else None
    gb = geo.geo_of(game, b["location_id"]) if b and b["location_id"] else None
    if not (ga and gb):
        return None
    return f"{geo.how_far(geo.distance_m(ga, gb))} from {game.ledger.get(a['location_id'])['name']}"


def auto_cut(game, ctx: TurnContext, start_scene: int, moved: dict, t: int) -> int | None:
    """Cut to where the party went. Only when every PC in the scene moved - a split party stays one
    scene with narrative cuts (DESIGN.md §4). Returning to a place resumes its parked scene."""
    L = game.ledger
    scene = L.scene(start_scene)
    name = moved["location"].strip()
    loc = L.find(name)
    if loc and loc["kind"] != "location":
        loc = None
    if loc and loc["id"] == scene["location_id"]:
        return None
    pcs_here = [e for e in L.roster(start_scene) if (L.get(e) or {}).get("kind") == "pc"]
    who = [x["id"] for x in (L.find(w) for w in moved.get("who", [])) if x]
    if not pcs_here or not all(p in who for p in pcs_here):
        return None
    lid = loc["id"] if loc else game.introduce("location", name, moved.get("description", ""), turn=t,
                                               where=moved.get("where"))[0]
    parked = game.conn.execute(
        "SELECT id FROM scenes WHERE location_id=? AND id<>? AND status<>'closed' ORDER BY id DESC LIMIT 1",
        (lid, start_scene)).fetchone()
    bring = [w for w in who if (L.get(w) or {}).get("kind") in ("pc", "npc", "item")]
    if parked:
        sid = game.resume_scene(parked["id"], bring, t)
    else:
        sid = game.new_scene(L.get(lid)["name"], lid, bring, t)
    ctx.scene_changed, ctx.scene_id = start_scene, sid
    from ..engine.rules import matrix                # (a decker along for the ride took the run - game.enter_scene)
    game.out(f"[SCENE] {'back to' if parked else 'cut to'} S{sid}: {L.scene(sid)['title']} (the party moved)"
             + matrix.riding_note(L, bring))
    return sid


def close_scene(game, scene_id: int, turn: int) -> None:
    """Scene consolidation (light sleep): summary node over its slices, then renormalize energy."""
    S, L = game.sub, game.ledger
    slices = [s for s in S.recent_slices(scene_id, 40) if s["visibility"] == "public"]  # the public record
    scene = L.scene(scene_id)
    if slices and scene:
        lines = "\n".join(f"- {s['text']}" for s in slices)
        try:
            summary = game.llm.text(game.settings.models.commit, SCENE_SUMMARY_SYSTEM,
                                    f"Scene: {scene['title']}\n{lines}", max_tokens=1500, purpose="memory")
        except Exception:
            summary = " ".join(s["text"] for s in slices[-3:])
        summary = spoilers.answer(game, summary, f"S{scene_id}'s summary", turn)     # (the recap reads it: §12l)
        S.set_text(f"S{scene_id}", f"Scene: {scene['title']}. {summary}")
    left = [e for e in L.roster(scene_id) if (L.get(e) or {}).get("kind") == "npc"]
    L.log(turn, "scene_closed", None, {"scene": scene_id, "left_behind": left})   # the offscreen world's cue
    S.renormalize()
