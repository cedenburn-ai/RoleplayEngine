"""Doubts (DESIGN.md §12k, built 2026-10-26): when the record doesn't add up, it's written down - never let go.

The owner: "the dm needs a way to add tension or doubt ... if the dm notices a story inconsistency we shouldn't let it go
into the ether." A human GM who catches "wait - T140 has Bo at the clinic, T148 has him at Juno's" pencils it in the
margin and sorts it out before it matters. Ours had nowhere to put it. It noticed, picked a version on the spot or
narrated over it, and by the next turn it had forgotten. The canon read-back could only guess when the record couldn't
tell which version was true. Live: since T52 Liesl Kovacs's current picture (C35) has said "Her daughter Juno is about
eight", and Juno [juno] is Bo's mother, an ork in her twenties. Two Junos, or a picture's slip? Nothing ever asked.

A doubt is a node X# (table `doubts`): GM-only and out of the fiction. It's about the record's continuity - not the
story's open questions (tensions, Q#) and not the engine's bugs (flag:). It links `about` everything involved, both
sides. It stays on the packet's DOUBTS list until it's settled, and it's never deleted: how it was settled (what's
true, by whom, when) stays on it, and should come with the fix lines that make the record true.

Who raises one: the GM (`doubt <ids>: ...` in its <dm> block, or the doubt tool mid-turn), the canon read-back (a
conflict it can't settle with confidence), the aside (a player's correction it can't check), the memory pass (a
narration that contradicts a fact it was shown), and !askdm (what one character's memory doesn't square: witness.doubt
- it reopens nothing).
"""
from __future__ import annotations

import difflib
import re

from ..engine.ledger import RulesRefusal
from ..substrate.store import norm_id

PREFIX = "X"
STATUSES = ("open", "resolved", "dismissed")
BY = {"gm": "you", "canon": "the canon read-back", "commit": "the memory pass", "aside": "a player's aside",
      "askdm": "a player's !askdm"}      # (askdm: what one character's memory couldn't square - witness.doubt)
BY["seed"] = "the story seed"         # (a story read in with !seed that disagrees with the record - seed.py)
NAMED = {**BY, "gm": "the GM"}                       # (the same, for the owner's eyes: !doubts, the dashboard)
PRESSING = 10               # turns open before the packet calls one pressing
SHOWN = 8                   # open doubts the packet lists (the rest: a count)
SAME = 0.8                  # how alike two doubts' words must be to be one doubt (difflib ratio)
RECENT = 6                  # settled doubts !doubts and the dashboard show
TEXT_SHOWN = 320            # a doubt's words in the packet
FIXES = ("fact", "note", "clarify")    # what the doubt tool's fixes may hold (the record set right - nothing else)
# Who reopens a settled doubt by raising the same one again in a line (raise_'s `reopen`). The GM and a player mean it:
# they're looking at the record and it still disagrees, so the old answer didn't take. The automatic passes reopen a
# resolved one (the record disagrees again after its answer) but never a dismissal: "it never was one" is the GM's
# word, and a misreading the memory pass repeats doesn't overrule it. Review (2026-10-26): a settled match was a log
# line - the GM raised it again, nothing reached its DOUBTS list, and it never heard why.
REOPENS = {"gm": ("resolved", "dismissed"), "aside": ("resolved", "dismissed"), "canon": ("resolved",),
           "commit": ("resolved",)}
IN_TURN = ("gm", "commit")  # who raises one inside a turn (the canon and the aside write on the last turn's number)

HEADER = ("\n=== DOUBTS (GM-only, out of the fiction: where the record doesn't add up. Before you narrate anything one "
          "touches, research it - read_turn, timeline, search_memory, recall - and settle it: `resolve X#: <what's "
          "true>` with the fix lines that make the record true (`fact <ids> (replaces F#): ...`, `clarify <id>: ...`, "
          "`note <ids>: ...`), or `dismiss X#: <why>` if it never was one. If only the players can know, ask them in "
          "one short out-of-character line - but one marked WHISPER or OFFSCREEN is only theirs who know it: never "
          "ask the table or say it there, settle it from the record. Never narrate over one as if it weren't "
          "there) ===")


# ── reading ─────────────────────────────────────────────────────────────
def _id(xid) -> str:
    return str(xid or "").strip().strip("[]").upper()


def get(game, xid) -> dict | None:
    row = game.conn.execute("SELECT d.*, n.text FROM doubts d JOIN nodes n ON n.id=d.id WHERE d.id=?",
                            (_id(xid),)).fetchone()
    return dict(row) if row else None


def is_doubt(game, nid) -> bool:
    return _id(nid).startswith(PREFIX) and get(game, nid) is not None


def about(conn, xid: str) -> list[str]:
    """Everything a doubt is about, in the order it was linked."""
    return [r[0] for r in conn.execute("SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE (a=? OR b=?) AND "
                                       "kind='about' ORDER BY id", (xid,) * 3)]


def on(game, nid: str) -> list[dict]:
    """The open doubts about nid (recall shows them with the memory)."""
    out = []
    for x in about(game.conn, norm_id(nid)):
        d = get(game, x) if str(x).startswith(PREFIX) else None
        if d and d["status"] == "open":
            out.append(d)
    return out


def _notes(conn, xid: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT n.id, n.text, n.created_turn FROM nodes n JOIN annotates a ON a.note_id=n.id WHERE a.target_id=? "
        "AND n.kind='note' ORDER BY n.created_turn, n.rowid", (xid,))]


def listing(conn, now: int, settled: int = RECENT) -> dict:
    """{open: [...], settled: [the most recent `settled`], settled_total} - each with what it's about (id and label),
    its age in turns at `now`, and the notes on it. A bare connection is enough (the dashboard reads it read-only)."""
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='doubts'").fetchone():
        return {"open": [], "settled": [], "settled_total": 0}
    names = {r[0]: r[1] for r in conn.execute("SELECT id, name FROM entities")}

    def row(r) -> dict:
        d = dict(r)
        d["about"] = [{"id": a, "label": names.get(a, a)} for a in about(conn, d["id"])]
        d["age"] = max(0, now - (d["raised_turn"] or 0))
        d["pressing"] = d["status"] == "open" and d["age"] >= PRESSING
        d["notes"] = _notes(conn, d["id"])
        return d
    q = "SELECT d.*, n.text FROM doubts d JOIN nodes n ON n.id=d.id WHERE "
    opened = [row(r) for r in conn.execute(q + "d.status='open' ORDER BY d.raised_turn, d.rowid")]
    done = [row(r) for r in conn.execute(q + "d.status<>'open' ORDER BY d.resolved_turn DESC, d.rowid DESC LIMIT ?",
                                         (settled,))] if settled else []
    total = conn.execute("SELECT COUNT(*) FROM doubts WHERE status<>'open'").fetchone()[0]
    return {"open": opened, "settled": done, "settled_total": total}


# ── writing ─────────────────────────────────────────────────────────────
def _words(text: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", (text or "").lower())


def _same(conn, d: dict, ids: list[str], text: str) -> bool:
    """One doubt raised twice: about the same ids (or one set inside the other) in near-identical words. Word by word,
    not letter by letter: "the record disagrees about the courier's employer" and "... about the host's rating" share
    most of their letters and are two doubts."""
    a, b = set(about(conn, d["id"])), set(ids)
    if not (a == b or (a and b and (a <= b or b <= a))):
        return False
    return difflib.SequenceMatcher(None, _words(d["text"]), _words(text)).ratio() >= SAME


def _link(game, xid: str, ids, turn: int) -> None:
    # Strength 0: a doubt is GM bookkeeping, not memory. It has no energy, and its links carry none (physics.py shares
    # a node's flow by strength), so a doubt over both sides of a contradiction can't keep both of them warm - and
    # settling it needs no unwiring.
    for nid in ids:
        game.sub.link(xid, nid, "about", 0.0, turn)


def _subjects(game, ids, turn: int) -> list[str]:
    """The ids on file, as nodes (a person gets their node), never another doubt."""
    S, L, out = game.sub, game.ledger, []
    for i in ids or []:
        ent = L.get(str(i))
        if ent:
            S.ensure_entity(ent, turn)
        nid = ent["id"] if ent else norm_id(str(i))
        if S.exists(nid) and nid not in out and not is_doubt(game, nid):
            out.append(nid)
    return out


def raise_(game, text: str, ids, turn: int, by: str = "gm", reopen=()) -> dict:
    """Raise a doubt about ids (both sides). The same doubt raised again - the same ids, near-identical words - bumps
    the open one ('raised 2x') instead of adding another; one already settled comes back with how it was settled,
    unchanged - or, when it was settled as one of `reopen` (REOPENS), opens again with its old answer in a note (work)
    and whatever new side this raise names linked. Returns {id, status: new | bumped | reopened | settled, doubt}."""
    text = " ".join((text or "").split())
    if not text:
        raise ValueError("A doubt needs what doesn't add up - both versions.")
    S, conn = game.sub, game.conn
    on_ids = _subjects(game, ids, turn)
    rows = [dict(r) for r in conn.execute("SELECT d.*, n.text FROM doubts d JOIN nodes n ON n.id=d.id ORDER BY "
                                          "d.status<>'open', d.rowid DESC")]
    for d in rows:
        if _same(conn, d, on_ids, text):
            if d["status"] != "open":
                if d["status"] in reopen:
                    return {"id": d["id"], "status": "reopened",
                            "doubt": work(game, d["id"], f"Raised again: {text}", turn, on_ids, by)}
                return {"id": d["id"], "status": "settled", "doubt": d}
            return {"id": d["id"], "status": "bumped", "doubt": again(game, d["id"], turn, on_ids)}
    xid = S._next(PREFIX)
    S.create_node(xid, "doubt", text, turn, visibility="gm", citizen=False)
    conn.execute("INSERT INTO doubts(id, status, raised_turn, raised_by, times, last_turn) VALUES(?, 'open', ?, ?, 1, ?)",
                 (xid, turn, by, turn))
    _link(game, xid, on_ids, turn)
    return {"id": xid, "status": "new", "doubt": get(game, xid)}


def again(game, xid: str, turn: int, ids=(), text: str = "", by: str = "gm") -> dict:
    """An open doubt raised again: 'raised 2x', anything newly involved linked (the turn that slipped again), and
    what's new as a note on it (`text`) - the age still counts from the first time."""
    conn = game.conn
    conn.execute("UPDATE doubts SET times=times+1, last_turn=? WHERE id=?", (turn, xid))
    _link(game, xid, [i for i in _subjects(game, ids, turn) if i not in about(conn, xid)], turn)
    if text.strip():
        whose = "" if by == "gm" else f"({NAMED.get(by, by)}) "
        game.sub.add_note([xid], whose + " ".join(text.split()), turn)
    return get(game, xid)


def work(game, xid: str, text: str, turn: int, ids=(), by: str = "gm") -> dict | None:
    """More on a doubt (`doubt X3, F47: what you found`): a note on it, anything newly involved linked, and it stays
    open - or opens again, when it had been settled (the old answer goes into the note: the history stays)."""
    d = get(game, xid)
    if not d:
        return None
    _link(game, d["id"], [i for i in _subjects(game, ids, turn) if i not in about(game.conn, d["id"])], turn)
    was = ""
    if d["status"] != "open":
        who = NAMED.get(d["resolved_by"], d["resolved_by"])
        was = f" (reopened - it was {d['status']} at T{d['resolved_turn']} by {who}: {d['resolution']})"
        game.conn.execute("UPDATE doubts SET status='open', resolved_turn=NULL, resolution=NULL, resolved_by=NULL "
                          "WHERE id=?", (d["id"],))
    if text or was:
        whose = "" if by == "gm" else f"({NAMED.get(by, by)}) "          # (the GM's own notes need no byline)
        game.sub.add_note([d["id"]], whose + (" ".join((text or "").split()) or "Raised again.") + was, turn)
    game.conn.execute("UPDATE doubts SET last_turn=? WHERE id=?", (turn, d["id"]))
    return get(game, d["id"])


def settle(game, xid: str, turn: int, how: str, status: str = "resolved", by: str = "gm") -> bool:
    """Resolve (what's true) or dismiss (why it never was a doubt) an open one. Kept, with who and when."""
    if status not in STATUSES[1:]:
        raise ValueError(f"A doubt is settled as {' or '.join(STATUSES[1:])}.")
    cur = game.conn.execute("UPDATE doubts SET status=?, resolved_turn=?, resolution=?, resolved_by=?, last_turn=? "
                            "WHERE id=? AND status='open'",
                            (status, turn, " ".join((how or "").split()), by, turn, _id(xid)))
    return cur.rowcount > 0


def resolve(game, xid: str, turn: int, how: str, by: str = "gm") -> bool:
    return settle(game, xid, turn, how, "resolved", by)


def dismiss(game, xid: str, turn: int, why: str, by: str = "gm") -> bool:
    return settle(game, xid, turn, why, "dismissed", by)


# ── the memory pass's slips (commit.py) ─────────────────────────────────
SLIPPED = re.compile(r"^(?:\([^)]*\)\s*)?(?:Raised again:\s*)?T\d+'s narration (?:doesn't fit \[[A-Z]\d+\]|again):\s*",
                     re.IGNORECASE)
REOPENED = re.compile(r"\s*\(reopened - .*\)\s*$")


def on_fact(game, fid: str) -> list[dict]:
    """Every doubt about a fact, any status, newest first."""
    return [dict(r) for r in game.conn.execute(
        "SELECT d.*, n.text FROM doubts d JOIN nodes n ON n.id=d.id WHERE d.id IN (SELECT CASE WHEN a=? THEN b ELSE a "
        "END FROM links WHERE (a=? OR b=?) AND kind='about') ORDER BY d.rowid DESC", (fid,) * 3)]


def _hows(game, d: dict) -> list[str]:
    """What a memory-pass doubt said each time - its words and its notes, without the 'T4's narration ...' that
    changes every turn."""
    return [REOPENED.sub("", SLIPPED.sub("", x)) for x in [d["text"]] + [n["text"] for n in _notes(game.conn, d["id"])]]


def slip(game, fid: str, how: str, turn: int, moment: str | None = None) -> dict:
    """The memory pass caught this turn's narration (its slice, `moment`) against fact fid: one doubt a fact, not one a
    turn. Its open doubt on that fact is bumped - this turn linked, its words a note. A settled one that said the same
    thing (SAME, past the 'T4's narration' prefix) is kept as it was settled when it was dismissed - the GM's "never
    was one" isn't the memory pass's to overrule - and reopens when it was resolved, the old answer in the note: the
    record disagrees again after it. Anything else is a new doubt. Returns raise_'s {id, status, doubt}.
    Review (2026-10-26): raised on [F2, T4], then [F2, T5] - neither set inside the other, so raise_ never matched it:
    every turn that repeated the slip opened another X#, each '1x', and a dismissed false positive came back as new
    the very next turn."""
    how = " ".join((how or "").split())
    ids = [fid] + ([moment] if moment else [])
    again_ = f"T{turn}'s narration again: {how}"
    mine = [d for d in on_fact(game, fid) if d["raised_by"] == "commit"]
    live = next((d for d in mine if d["status"] == "open"), None)
    if live:
        return {"id": live["id"], "status": "bumped", "doubt": again(game, live["id"], turn, ids, again_, by="commit")}
    words = _words(how)
    for d in mine:                                       # (settled ones, newest first)
        if any(difflib.SequenceMatcher(None, _words(x), words).ratio() >= SAME for x in _hows(game, d)):
            if d["status"] not in REOPENS["commit"]:
                return {"id": d["id"], "status": "settled", "doubt": d}
            return {"id": d["id"], "status": "reopened", "doubt": work(game, d["id"], again_, turn, ids, by="commit")}
    return raise_(game, f"T{turn}'s narration doesn't fit [{fid}]: {how}", ids, turn, by="commit",
                  reopen=REOPENS["commit"])


def answers(game, fid: str) -> str:
    """For the memory pass's FACTS ALREADY KNOWN: the latest settled doubt on a fact, so a slip it checked isn't flagged
    again ('' when none)."""
    d = next((x for x in on_fact(game, fid) if x["status"] != "open"), None)
    return (f" (checked: a doubt on it was {d['status']} T{d['resolved_turn']} - {_clip(d['resolution'] or '', 160)})"
            if d else "")


# ── the doubt tool (tools.dispatch) ─────────────────────────────────────
def _list(v) -> list[str]:
    if v is None:
        return []
    return [str(x) for x in ([v] if isinstance(v, str) else v) if str(x).strip()]


def run(ctx, args: dict) -> str:
    """raise / resolve / dismiss, mid-turn - right after the lookup that settled it. A resolve's fixes are <dm> lines
    (fact, note, clarify) applied now; it's resolved once every one of them has landed, so a fix that went nowhere
    can't close the doubt and let the contradiction go."""
    from . import dmblock                                  # (dmblock routes its doubt lines here: no import loop)
    g, t = ctx.game, ctx.turn_id
    action = str(args.get("action") or "raise").strip().lower()
    text = " ".join(str(args.get("text") or "").split())
    refs = _list(args.get("ids"))
    # (the GM's slips come back as refusals - the GM's to correct, not an engine fault for the flags page)
    if action not in ("raise", "resolve", "dismiss"):
        raise RulesRefusal("action is raise, resolve or dismiss.")
    if not text:
        raise RulesRefusal({"raise": "Say what doesn't add up - both versions - in text.",
                            "resolve": "Say what's true in text.", "dismiss": "Say why it never was one in text."}[action])
    if action == "raise":
        ids, unknown = dmblock.resolve_ids(g, ", ".join(refs))
        xs = [x for x in ids if is_doubt(g, x)]
        miss = f" (not on file, left out: {', '.join(unknown)})" if unknown else ""
        if xs:                                             # more on one already raised (a settled one reopens)
            was = {x: get(g, x)["status"] for x in xs}
            for x in xs:
                work(g, x, text, t, [i for i in ids if i not in xs], ctx.by)
                ctx.events.append(dmblock.gm_only(f"DOUBT {x} worked on: {text}", f"DOUBT {x} worked on (GM-only)"))
            return "Added to " + ", ".join(f"[{x}]" + (f" (reopened - it was {s})" if s != "open" else "")
                                           for x, s in was.items()) + f" - open.{miss}"
        r = raise_(g, text, ids, t, ctx.by)
        d = r["doubt"]
        if r["status"] == "settled":
            return (f"[{r['id']}] already settled this ({d['status']} T{d['resolved_turn']}): {d['resolution']} - if "
                    f"the record still disagrees, raise it with what's new (ids: [\"{r['id']}\", ...]).")
        said = "raised" if r["status"] == "new" else "raised again"      # (the memory pass reads it as GM-only)
        on_ids = about(g.conn, r["id"])
        ctx.events.append(dmblock.gm_only(f"DOUBT {r['id']} {said} on {', '.join(on_ids) or 'nothing on file'}: {text}",
                                          f"DOUBT {r['id']} {said} (GM-only)"))
        g.out(f"[DOUBT] {r['id']} {r['status']} ({NAMED.get(ctx.by, ctx.by)}): {text}")
        return (f"[{r['id']}] " + ("is on your DOUBTS list" if r["status"] == "new" else
                                   f"was already open - raised {d['times']}x now")
                + (f", about {', '.join(on_ids)}" if on_ids else " (about nothing on file - give it ids)") + miss
                + ". Settle it when you can: resolve with what's true and the fix lines, or dismiss.")
    xid = _id(args.get("id") or next((r for r in refs if _id(r).startswith(PREFIX)), ""))
    d = get(g, xid) if xid else None
    if not d:
        raise RulesRefusal(f"No doubt '{xid or '?'}' on file - the DOUBTS list has their X#.")
    if d["status"] != "open":
        return f"[{d['id']}] is already {d['status']} (T{d['resolved_turn']}): {d['resolution']}"
    made = []
    if action == "resolve":
        lines = _list(args.get("fixes"))
        if lines:
            _, entries = dmblock.split("<dm>\n" + "\n".join(lines) + "\n</dm>")
            ok = [e for e in entries if e["kind"] in FIXES or e["kind"] == dmblock.UNREAD]
            wrong = [e["line"] for e in entries if e not in ok]
            # All of them or none: a resolve that half-lands is taken back whole. Review (2026-10-26): the lines that
            # did land stayed written, and the retry the refusal asked for - the whole list, one line corrected - wrote
            # them again: two identical facts, both replacing F2 (store.add_fact keeps both).
            before, said, seen = len(ctx.unplaced), len(ctx.events), set(ctx.expanded)
            g.conn.execute("SAVEPOINT doubt_fixes")
            try:
                made = dmblock.apply(ctx, ok)
                lost = [e["line"] for e in ctx.unplaced[before:]] + wrong
                if lost:
                    g.conn.execute("ROLLBACK TO doubt_fixes")
                    del ctx.events[said:]
                    ctx.expanded.intersection_update(seen)
            except BaseException:
                g.conn.execute("ROLLBACK TO doubt_fixes")
                g.conn.execute("RELEASE doubt_fixes")
                raise
            g.conn.execute("RELEASE doubt_fixes")
            if lost:
                return (f"[{d['id']}] NOT resolved - these fix lines didn't land: " + " | ".join(lost)
                        + (f" (fixes hold only {', '.join(FIXES)} lines)" if wrong else "")
                        + (f". The rest ({len(made)}) were taken back with them: nothing was written" if made else "")
                        + ". Correct them and resolve again with every fix line (the [id]s from the packet, "
                          "comma-separated).")
    done = "resolved" if action == "resolve" else "dismissed"
    settle(g, d["id"], t, text, done, ctx.by)
    ctx.events.append(dmblock.gm_only(f"DOUBT {d['id']} {done}: {text}", f"DOUBT {d['id']} {done} (GM-only)"))
    g.out(f"[DOUBT] {d['id']} {done} ({NAMED.get(ctx.by, ctx.by)}): {text}")
    if action == "dismiss":
        return f"[{d['id']}] dismissed: {text}"
    return (f"[{d['id']}] resolved: {text}" + (f" Record fixed: {', '.join(made)}." if made else
                                               " (No fix lines: if the record still says otherwise anywhere, set it "
                                               "right too - fact (replaces F#), clarify, note.)"))


# ── whose it is: a whisper's doubt ──────────────────────────────────────
def _whisperer(conn, turn) -> str | None:
    row = conn.execute("SELECT private FROM turns WHERE id=?", (turn,)).fetchone() if turn is not None else None
    return row[0] if row and row[0] else None


def secret(game, d: dict) -> dict:
    """A doubt out of a whisper or the offscreen world: {label, who, offscreen} - the label marks it as the packet marks
    a whisper's slice ('WHISPER, private - only Razor knows: '), who are the ids who know, '' and empty when it's the
    table's. It's a whisper's when a side of it is private or offscreen (a whisper's slice or fact, a W#), or when it
    was raised inside a whisper's turn (its words may be the whisper's). Review (2026-10-26): a whisper's slip came
    back on the next public packet as "[X1] ... T4's narration doesn't fit [F2]: Razor palmed Kaz's keycard..." with no
    mark, under a header that said to ask the table."""
    from ..substrate.packet import _whisper, whisper_knowers   # (packet imports this module inside build_packet)
    L, S, conn = game.ledger, game.sub, game.conn
    ids = [a["id"] if isinstance(a, dict) else a for a in (d.get("about") or about(conn, d["id"]))]
    who, label, offscreen, private = [], "", False, False
    if d.get("raised_by") in IN_TURN:
        who.append(_whisperer(conn, d.get("raised_turn")))
    for a in ids:
        n = None if L.get(a) else S.node(a)
        if not n or n["visibility"] not in ("private", "offscreen"):
            continue
        offscreen |= n["visibility"] == "offscreen"
        private |= n["visibility"] == "private"
        if n["kind"] == "slice":
            label = label or _whisper(game, n)
            # (a whisper's: who sent it and who heard since - not whoever it was done to, who may never have noticed:
            # review 2026-10-26, the aside for Razor's player counted him in on Ghost's tracker in his coat)
            roles = game.settings.knobs.witness_roles
            who += (whisper_knowers(game, n) if n["visibility"] == "private" else
                    [m for m, r in S.members_of(a) if r in roles] + [_whisperer(conn, n["created_turn"])])
        else:                                        # (a whisper's fact: its turn's, or the moment it names)
            who += [_whisperer(conn, n["created_turn"])] + [_whisperer(conn, int(o[1:])) for o in S.neighborhood(a)
                                                            if re.fullmatch(r"T\d+", o)]
    who = [x for x in dict.fromkeys(who) if x]
    if not label and who:
        names = [(L.get(x) or {}).get("name", x) for x in who]
        label = f"WHISPER, private - only {', '.join(names)} know{'s' if len(names) <= 1 else ''}: "
    elif not label and (private or offscreen):
        label = "WHISPER, private - only those who were there know: " if private else "OFFSCREEN, no PC saw it: "
    return {"label": label, "who": set(who), "offscreen": offscreen}


# ── the packet ──────────────────────────────────────────────────────────
def _near(game, d: dict, here: set[str]) -> int:
    """How close a doubt is to the scene: 2 when it's about someone or something here, 1 about a memory (a turn, a
    fact, a picture) involving an NPC or a thing here, 0 elsewhere. The PCs and the place itself are left out of the
    memories' test - they're in every turn of the scene. Review (2026-10-26): a doubt naming any turn read as here,
    through the PCs in it, so one about Tanaka's fence ranked above the one about Kaz, standing at the bar."""
    L, S = game.ledger, game.sub
    ids = [a["id"] for a in d["about"]]
    if any(a in here for a in ids):
        return 2
    others = {x for x in here if (L.get(x) or {}).get("kind") not in ("pc", "location")}
    return 1 if others and any(not L.get(a) and others & S.neighborhood(a) for a in ids) else 0


def _on(d: dict, most: int = 6) -> str:
    bits = [f"{a['label']} [{a['id']}]" if a["label"] != a["id"] else a["id"] for a in d["about"][:most]]
    return ", ".join(bits) + (f" (+{len(d['about']) - most} more)" if len(d["about"]) > most else "")


def _clip(text: str, n: int) -> str:
    return text if len(text) <= n else text[:n].rsplit(" ", 1)[0] + "..."


def _line(d: dict, mark: str = "") -> str:
    age = d["age"]
    when = "new" if age == 0 else f"open {age} turn{'s' if age != 1 else ''}"
    who = f"raised T{d['raised_turn']} by {BY.get(d['raised_by'], d['raised_by'])}" + (
        f", {d['times']}x" if d["times"] > 1 else "")
    last = d["notes"][-1] if d["notes"] else None
    return (f"[{d['id']}] {when}{' - PRESSING' if d['pressing'] else ''} ({who})"
            + (f" · on {_on(d)}" if d["about"] else "") + f": {mark}{_clip(d['text'], TEXT_SHOWN)}"
            + (f" Latest (T{last['created_turn']}): {_clip(last['text'], 200)}" if last else ""))


HIDDEN_NAMED = 12           # the X#s the overflow line names (recall reads any of them)


def packet_lines(game, turn_id: int, here=()) -> list[str]:
    """=== DOUBTS ===, near the top of the packet: every open one - about who or what is here first, then about a memory
    involving them, then the rest, oldest first in each - at most SHOWN, and the X#s of the others (recall reads one).
    Review (2026-10-26): the overflow line said "search_memory kinds: doubt finds them" - a search with no words finds
    nothing, and it never named them, so the newest doubts past the eighth couldn't be found at all."""
    rows = listing(game.conn, turn_id, settled=0)["open"]
    if not rows:
        return []
    here = set(here)
    tier = {d["id"]: _near(game, d, here) for d in rows}
    near = sorted((d for d in rows if tier[d["id"]]), key=lambda d: -tier[d["id"]])    # (stable: oldest first in each)
    rest = [d for d in rows if not tier[d["id"]]]
    out = [HEADER]
    shown = (near + rest)[:SHOWN]
    for i, d in enumerate(shown):
        if near and i == len(near):
            out.append("Elsewhere in the story:")
        out.append(_line(d, secret(game, d)["label"]))
    hidden = [d["id"] for d in (near + rest)[SHOWN:]]
    if hidden:
        out.append(f"(and {len(hidden)} more open: {', '.join(hidden[:HIDDEN_NAMED])}"
                   + (f" and {len(hidden) - HIDDEN_NAMED} more" if len(hidden) > HIDDEN_NAMED else "")
                   + " - recall one by its X# to read it)")
    return out


def recall_lines(game, nid: str, hide=None) -> list[str]:
    """For recall: the open doubts about a memory or a person, a whisper's marked - and none that `hide` (an aside's
    lookup at the table: research.hidden) says isn't the table's."""
    return [f"  DOUBT [{d['id']}] (open since T{d['raised_turn']}): {secret(game, d)['label']}{_clip(d['text'], 240)}"
            for d in on(game, nid) if not (hide and hide(d["id"]))]


# ── reading it back: !doubts ────────────────────────────────────────────
def render(game) -> str:
    """The owner's !doubts (by DM): every open doubt with what it's about and its age, and the latest settled ones with
    how."""
    v = listing(game.conn, game.turn_no())
    if not v["open"] and not v["settled"]:
        return "No doubts on file - nothing in the record has been caught disagreeing with itself."
    out = [f"OPEN DOUBTS ({len(v['open'])})" if v["open"] else "No open doubts."]
    for d in v["open"]:
        out.append(f"- [{d['id']}] T{d['raised_turn']}, open {d['age']} turn{'s' if d['age'] != 1 else ''}"
                   + (" - PRESSING" if d["pressing"] else "") + f", raised by {NAMED.get(d['raised_by'], d['raised_by'])}"
                   + (f" ({d['times']}x)" if d["times"] > 1 else ""))
        if d["about"]:
            out.append(f"  on: {_on(d, 12)}")
        out.append(f"  {d['text']}")
        out += [f"  T{n['created_turn']}: {n['text']}" for n in d["notes"][-3:]]
    if v["settled"]:
        out.append(f"\nRECENTLY SETTLED ({len(v['settled'])} of {v['settled_total']})")
        for d in v["settled"]:
            who = NAMED.get(d["resolved_by"], d["resolved_by"] or "?")
            out.append(f"- [{d['id']}] {d['status']} T{d['resolved_turn']} by {who} (raised T{d['raised_turn']}): "
                       f"{d['text']}")
            out.append(f"  -> {d['resolution']}")
    return "\n".join(out)
