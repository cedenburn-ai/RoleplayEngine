"""The spoiler guard (DESIGN.md §12l, built 2026-10-28): a name the table hasn't learned never reaches what it reads.

The owner plays in the story he seeds. A real-model rehearsal of the first one (`!rp newparty`, `!seed`, two
runners, `!begin`, two turns at an NPC's booth) found the GM's half reaching the table twice, past the seed's own
guard:
- the memory pass, which writes the public summary, read a waiting <dm> note's GM-only words in ENGINE EVENTS. The
  summary named a sealed NPC by his GM-only name and filed him 'mentioned', which unsealed him - and from the slice
  it went on to a public node, a job, the packet's public lines, !askdm, the aside, the recap and the dashboard;
- the scene frame, written after the opening from everyone's files, put a GM-only label in a public NPC's 'now' line,
  the line the GM plays from - and the GM said it at the table, in three posts.

Both are closed where they start: dmblock writes ENGINE EVENTS that only say a GM-only line waits, the frame is told
the names the crew knows and scrubbed after, the packet opens on a SEALED block, and the GM's rules say it. This is the
backstop under them, deterministic, so a model's slip can't spoil the story:
- the terms: every true name and GM label on file (props true_name / gm_names - or, for a seed filed before they were
  kept, its own GM notes), and the seed's secret terms (meta seed:terms, from its review) that are one of those names
  or the read's own secret words. Less whatever someone on file is called now, or was named by a `name <id>: ...`
  line: a name the story revealed is the crew's from then on - and only that. An alias filed some other way never
  counts (an introduce's: review 2026-10-28, one alias holding a true name switched the guard off for it everywhere),
  nor a name on file that only holds the word ("Lantern" isn't revealed by "the outfit in lantern-red scarves": case
  decides) - nor a handle filed title-cased, which capitalizes a plain word ("The Woman with the Lantern" doesn't
  reveal her label "Lantern"; rehearsal 2026-10-28). A name on file that holds a term stands as written.
  Game words (the rules text) are never a story's secret, nor one word of a longer secret phrase on its own ('dawn' in
  'the dawn shipment'), nor a capital in the GM file that no secret word names (the seed's own guard drops a line for
  one; at the table it's as often a corp's name). A plot word the read called secret (all lowercase, nobody's name) is
  the GM's to keep - SEALED lists it - never the engine's to cut: it isn't a name, a player can say it first, and
  "someone" in its place garbles the line.
- hits / scrub: whole words, never substrings (seed._says), with a plural or possessive ("the Brandts'"), either
  apostrophe. A one-word term the public record also uses as a plain lowercase word (a handle, the rules, a slice)
  is cut only capitalized - "a crime syndicate" keeps its noun. A term someone owns becomes what the crew calls them,
  a title before it ("Mr.") and all; one nobody owns - or that two of them share - "someone".
- where it runs: the GM's narration (sent back once with the reason, then scrubbed and flagged - turn._dm_loop), the
  GM's public facts and new names (dmblock, tools), the memory pass's summary, facts, new names, jobs and the roles it
  files for the sealed (commit), the aside's and !askdm's answers, the aside's direction and fix cards, the recap,
  chronicles and dossiers, a scene's summary and a cut's title, the cards the table reads as they happen (session's
  out hook), an art card, a shop, the frame, the world's newcomers and what it writes of them, every flag. A flag or
  a log line never says the term itself - the owner plays the story too.
"""
from __future__ import annotations

import functools
import json
import re
from dataclasses import dataclass, field

from .. import seed

UNOWNED = "someone"                 # what a term nobody on file owns becomes (a GM proper noun, a secret word)
UNMET = {"npc": "someone", "faction": "some outfit", "location": "somewhere"}   # for a seed.UNSEEN handle, mid-sentence
REAL = re.compile(r"Real name: (.+?) - secret until the story reveals it")        # seed.apply's GM line (before props)
CALLED = re.compile(r"\(The story's GM file calls them (.+?)\.\)")
_START = re.compile(r"(?:^|[.!?]\s+|\n\s*|\*\*\s*|[\"“(]\s*)$")                  # (a stand-in there gets a capital)
_ARTICLE = re.compile(r"(?:the|an?|some)\b|someone|somewhere", re.IGNORECASE)   # (a stand-in that brings its own)
# A title before a term goes with it - "Mr. Vale" is "the man in a green coat", never "Mr. The man in a green coat"
# (its period read as a sentence's end). Capitalized only: "don't miss Vale" keeps its verb.
TITLES = (r"(?:Mr|Mrs|Ms|Mx|Dr|Prof|Lt|Sgt|Capt|Det|Insp)\.?|Miss|Mister|Missus|Doctor|Sir|Madam|Madame|Officer|"
          r"Detective|Inspector|Lieutenant|Sergeant|Captain")
_FOLD = str.maketrans("’‘", "''")   # a curly apostrophe reads as a straight one (same length: the scrub's places hold)
_SPLIT = re.compile(r"[\s*_~`>]+")  # what can sit inside one name in the narration: markdown, a line break, a quote mark
_DETERMINER = re.compile(r"(?<![A-Za-z0-9])(?:the|an?|some|this|that)(?![A-Za-z0-9])", re.IGNORECASE)


@dataclass
class Secret:
    """Someone (or something) on file with names only the GM's half knows."""
    id: str
    kind: str
    name: str                                       # on file: what the crew can call them
    names: list[str] = field(default_factory=list)  # the GM-only ones the story hasn't revealed yet
    sealed: bool = False                            # the crew hasn't met them yet (seed.sealed_ids)


@dataclass
class Guard:
    secrets: list[Secret]
    terms: list[tuple[str, str | None]]             # (term, the id that owns it or None), longest first
    words: list[str] = field(default_factory=list)  # the seed's secret plot words: the GM is told, nothing is cut
    pattern: re.Pattern | None = None
    owner: dict = field(default_factory=dict)       # term, lowercased -> (term, owner)
    shared: dict = field(default_factory=dict)      # term, lowercased -> the ids whose names all hold it (no one owner)
    cased: set = field(default_factory=set)         # terms, lowercased, cut only capitalized (a plain word besides)
    held: re.Pattern | None = None                  # names on file that hold a term: they stand as written


def _rules_text() -> str:
    from .prompts import DM_SYSTEM
    return DM_SYSTEM


@functools.lru_cache(maxsize=1)
def _rules_words() -> tuple[frozenset, frozenset]:
    """The rules text's words (lowercased), and those it writes in lowercase - read once: the text is long, and a
    regex over it for every term was most of a build."""
    toks = re.findall(r"[A-Za-z0-9]+", _rules_text())
    return frozenset(t.lower() for t in toks), frozenset(t for t in toks if t.islower())


def _in_rules(t: str) -> bool:
    return t.lower() in _rules_words()[0] if re.fullmatch(r"[A-Za-z0-9]+", t) else seed._says(_rules_text(), t)


def _says_cased(text: str, phrase: str) -> bool:
    """seed._says with the case as written: 'the outfit in lantern-red scarves' doesn't say 'Lantern'."""
    return bool(phrase) and re.search(rf"(?<![A-Za-z0-9]){re.escape(phrase)}(?![A-Za-z0-9])", text or "") is not None


def _names_on_file(game) -> dict[str, list[str]]:
    """{id: the GM-only names behind it}: props true_name and gm_names (seed.apply), and - for a seed filed before
    those were kept - the real names and GM labels its notes and pictures give."""
    out: dict[str, list[str]] = {}

    def put(eid: str, name) -> None:
        name = " ".join(str(name or "").split()).strip(" .'\"")
        if len(name) >= seed.MIN_NAME and name.lower() not in (n.lower() for n in out.get(eid, [])):
            out.setdefault(eid, []).append(name)
    for e in game.ledger.entities(status=None):
        p = e["props"] or {}
        for n in [p.get("true_name")] + list(p.get("gm_names") or []):
            put(e["id"], n)
    for r in game.conn.execute(
            "SELECT a.target_id, n.text FROM nodes n JOIN annotates a ON a.note_id=n.id WHERE n.kind IN "
            "('note', 'clarification') AND (n.text LIKE '%Real name: %' OR n.text LIKE '%GM file calls them%')"):
        if game.ledger.get(r[0]):
            for m in list(REAL.finditer(r[1])) + list(CALLED.finditer(r[1])):
                put(r[0], m.group(1))
    return out


def _named(game, ents) -> tuple[list[str], list[str]]:
    """Every name the crew has for anyone: (the names on file, every name a `name` line (or !rename) gave or took over -
    speakers.rename logs each) - never an alias filed some other way."""
    given = []
    for r in game.conn.execute("SELECT payload FROM events WHERE kind='renamed'"):
        try:
            p = json.loads(r[0] or "{}")
        except ValueError:
            continue
        given += [str(p[k]) for k in ("from", "to") if isinstance(p, dict) and p.get(k)]
    return [e["name"] for e in ents if e["name"]], given


def _plain(game, word: str, said: set) -> bool:
    """Is this word also a plain lowercase word the table reads - in a name on file (`said`: their lowercase words),
    the rules, the public record?"""
    low = word.lower()
    if low in said or low in _rules_words()[1]:
        return True
    for (text,) in game.conn.execute(
            "SELECT text FROM nodes WHERE visibility='public' AND kind IN ('slice', 'fact', 'entity', 'scene') "
            "AND instr(text, ?) > 0 LIMIT 40", (low,)):
        if _says_cased(text, low):
            return True
    return False


def _build(game) -> Guard:
    L = game.ledger
    behind = _names_on_file(game)
    sealed = seed.sealed_ids(game.conn)
    ents = L.entities(status=None)
    on_file, given = _named(game, ents)
    known = on_file + given
    exact, said = {n.lower() for n in known}, "\n".join(known)
    plain = {w for w in re.findall(r"[A-Za-z0-9]+", said) if w.islower()}

    def revealed(n: str) -> bool:                  # (its own name now, or held - as written - in a name the crew has)
        if n.lower() in exact or _says_cased("\n".join(given), n):
            return True
        holders = [e for e in ents if e["name"] and _says_cased(e["name"], n)]
        # One capitalized word held only by a handle filed title-cased isn't a name the story revealed: "The Woman with
        # the Lantern" capitalizes the plain word her GM label is (rehearsal 2026-10-28: the seed's read filed the
        # handle that way, her items took it, and the label was never a term - not in SEALED, nor the frame's names,
        # nor cut). Plain: the record, the rules or the holder's own description reads it in lowercase.
        return bool(holders) and (" " in n or n.islower() or not (_plain(game, n, plain) or any(
            _says_cased(e["description"], n.lower()) for e in holders)))
    secrets = []
    for e in ents:
        names = [n for n in behind.get(e["id"], []) if not revealed(n)]
        if names or e["id"] in sealed:
            secrets.append(Secret(e["id"], e["kind"], e["name"], names, e["id"] in sealed))
    try:
        kept = json.loads(L.meta(seed.META_TERMS) or "{}")
    except ValueError:
        kept = {}
    kept = kept if isinstance(kept, dict) else {}
    listed = [" ".join(x.split()) for x in kept.get("terms") or [] if isinstance(x, str)]
    named = [" ".join(x.split()) for x in kept.get("secret_words") or [] if isinstance(x, str)]
    lowered = {x.lower() for x in kept.get("cased") or [] if isinstance(x, str)}   # (the seed's texts say it plainly)
    terms: dict[str, tuple[str, str | None]] = {}
    shared: dict[str, list[str]] = {}
    for s in secrets:
        for n in s.names:
            terms.setdefault(n.lower(), (n, s.id))
    words = []
    for t in listed:
        # (two letters is a surname only capitalized: "Ms. Ng")
        if (len(t) < seed.MIN_NAME and not re.fullmatch(r"[A-Z][a-z]", t)) or t.lower() in terms or revealed(t):
            continue
        owners = list(dict.fromkeys(s.id for s in secrets for n in s.names if seed._says(n, t)))
        if len(owners) > 1:                        # (a surname two of them share is neither's to stand in for)
            shared[t.lower()] = owners
        owner = owners[0] if len(owners) == 1 else None
        if not owners:
            # Nobody's name: cut only when the read called it secret (secret_words, or a word of one) - a capital in
            # the GM file the public record hasn't met yet is no secret on its own - as often as not a corp's name: the
            # seed's own guard drops a line for one, the narration mustn't lose the word. Never a game word.
            if _in_rules(t) or not any(seed._says(w, t) for w in named):
                continue
            if t.islower() and " " not in t:
                if not any(len(x) > len(t) and seed._says(x, t) for x in listed):   # (not one word of a longer one)
                    words.append(t)
                continue
        terms[t.lower()] = (t, owner)
    found = sorted(terms.values(), key=lambda x: -len(x[0]))
    # A one-word name that is a plain word too - a word of a handle, a rule's, one a turn's summary used - is cut only
    # capitalized (review 2026-10-28: a GM-only label for a public NPC was a plain word, capitalized, and "Every crime
    # syndicate" lost its noun). Never a two-letter one in any case but its own.
    cased = {t.lower() for t, _ in found if " " not in t and not t.islower()
             and (len(t) < seed.MIN_NAME or t.lower() in lowered or _plain(game, t, plain))}
    g = Guard(secrets, found, sorted(set(words)), shared=shared, cased=cased)
    if found:
        g.owner = {t.lower().translate(_FOLD): (t, o) for t, o in found}

        def alt(t: str) -> str:
            t = t.translate(_FOLD)
            if t.lower() in cased:
                return "|".join(re.escape(x) for x in dict.fromkeys((t, t[:1].upper() + t[1:], t.upper())))
            return "(?i:" + re.escape(t).replace(r"\ ", r"\s+") + ")"
        # (an article right before a term is caught with it: "the Syndicate's" is "the outfit's", never "the the"; a
        # title too; then a plural or a possessive: "the Brandts'", "Vale's")
        g.pattern = re.compile(rf"(?:(?<![A-Za-z0-9])(?P<art>(?i:the|an?))\s+)?(?:(?<![A-Za-z0-9])(?P<hon>{TITLES})"
                               rf"\s+)?(?<![A-Za-z0-9])(?P<term>{'|'.join(alt(t) for t, _ in found)})"
                               rf"(?P<suf>'s|(?<=s)'|s'|(?:(?<=[sxz])|(?<=[cs]h))es|s)?(?![A-Za-z0-9])")
        # A name on file that holds a term - a title-cased handle and what's filed after it ("The Woman with the
        # Lantern's rifle") - stands as written: only the term on its own is cut, never her name into "The Woman with
        # the the woman..."
        names = sorted({e["name"].translate(_FOLD) for e in ents if e["name"] and g.pattern.search(
            e["name"].translate(_FOLD))}, key=len, reverse=True)
        if names:
            alts = (re.escape(n).replace(r"\ ", r"\s+") for n in names)
            g.held = re.compile("|".join(rf"(?<![A-Za-z0-9]){a}(?![A-Za-z0-9])" for a in alts), re.IGNORECASE)
    return g


def _spans(g: Guard, text: str) -> list[tuple[int, int]]:
    """Where the text says a name on file that holds a term (Guard.held): those stand."""
    return [m.span() for m in g.held.finditer(text)] if g.held else []


def _inside(spans: list[tuple[int, int]], m: re.Match) -> bool:
    return any(a <= m.start("term") and m.end("term") <= b for a, b in spans)


def guard(game) -> Guard:
    """The guard as the record stands (cached until the connection writes again)."""
    key = (id(game.conn), game.conn.total_changes)
    held = getattr(game, "_spoiler_guard", None)
    if held and held[0] == key:
        return held[1]
    g = _build(game)
    try:
        game._spoiler_guard = (key, g)
    except AttributeError:
        pass
    return g


def _term(g: Guard, matched: str) -> tuple[str, str | None]:
    return g.owner.get(" ".join(matched.split()).lower().translate(_FOLD), (matched, None))


def _allowed(g: Guard, t: tuple[str, str | None], allow: dict | None) -> bool:
    """May this term stand? Only beside a `name` line that reveals it on its owner's own id (revealed)."""
    if not allow:
        return False
    owners = [t[1]] if t[1] else g.shared.get(t[0].lower(), [])
    return any(o in allow and seed._says(allow[o], t[0]) for o in owners)


def hits(game, text: str, allow: dict | None = None) -> list[tuple[str, str | None]]:
    """The GM-only terms the text says, (term, owner) - whole words. `allow`: what this turn's `name` lines reveal,
    {id: the name} (revealed) - a term of that id's own may stand."""
    g = guard(game)
    if not g.pattern or not text:
        return []
    out, folded = [], text.translate(_FOLD)
    spans = _spans(g, folded)
    for m in g.pattern.finditer(folded):
        if _inside(spans, m):
            continue
        t = _term(g, m.group("term"))
        if t not in out and not _allowed(g, t, allow):
            out.append(t)
    return out


def called(ent: dict) -> str:
    """What the crew calls someone on file: their name - "the outfit in grey coats" rather than the bare "outfit in grey
    coats" an outfit is filed under (world.ensure_faction keeps the 'the' as an alias)."""
    name = ent["name"]
    if not re.match(r"(?:the|a|an)\s", name, re.IGNORECASE):
        name = next((a for a in ent["aliases"] or [] if a.lower() == f"the {name.lower()}"), name)
    return name


def stand_in(game, owner: str | None) -> str:
    """What a term becomes: what the crew calls its owner (the handle), "someone" for a seed's 'someone the crew hasn't
    met' - or "someone" when nobody owns it."""
    ent = game.ledger.get(owner) if owner else None
    if not ent:
        return UNOWNED
    if ent["name"] in seed.UNSEEN.values():
        return UNMET.get(ent["kind"], UNOWNED)
    return called(ent)


def _owned(rep: str, suf: str) -> str:
    """A possessive after the stand-in: "the man in a green coat's", "the outfit in lantern-red scarves'"."""
    apo = "’" if "’" in suf else "'"
    return rep + (apo if rep.endswith("s") else apo + "s")


def scrub(game, text: str, allow: dict | None = None) -> tuple[str, list[tuple[str, str | None]]]:
    """(the text with each GM-only term put as what the crew calls its owner, the terms it held). One name split by
    markdown or a line break ('**Greta** Brandt') is one stand-in, the markup kept."""
    g = guard(game)
    if not g.pattern or not text:
        return text, []
    found: list[tuple[str, str | None]] = []
    out, at, last = [], 0, None
    folded = text.translate(_FOLD)
    spans = _spans(g, folded)
    for m in g.pattern.finditer(folded):
        t = _term(g, m.group("term"))
        if _inside(spans, m) or _allowed(g, t, allow):
            continue
        if t not in found:
            found.append(t)
        gap, suf = text[at:m.start()], text[m.start("suf"):m.end("suf")] if m.group("suf") else ""
        mine = "'" in suf or "’" in suf
        if last and t[1] and last[0] == t[1] and not (m.group("art") or m.group("hon")) and _SPLIT.fullmatch(gap):
            out.append(re.sub(r"[\s>]+", "", gap) + (_owned(last[1], suf)[len(last[1]):] if mine else ""))
            at = m.end()
            continue
        rep, art = stand_in(game, t[1]), m.group("art")
        if art and not _ARTICLE.match(rep):
            rep = f"{art.lower()} {rep}"
        if _START.search(text[:m.start()]) or (art or "")[:1].isupper():
            rep = rep[:1].upper() + rep[1:]
        out.append(gap + (_owned(rep, suf) if mine else rep))
        at, last = m.end(), (t[1], rep)
    out.append(text[at:])
    return "".join(out), found


def revealed(game, text: str) -> dict[str, str]:
    """{id: the name} for each `name <id>: <the name>` line in the text's <dm> blocks that puts a name on someone on
    file - one person, a name holding no one else's GM-only name: those may stand in the narration beside it, theirs
    alone. A line on no one, or on the wrong one, reveals nothing (review 2026-10-28: `name nobody-here: <her name>`
    let her name post while the record kept it hidden)."""
    from .dmblock import resolve_ids, split
    out: dict[str, str] = {}
    for e in split(text or "")[1]:
        if e["kind"] != "name":
            continue
        who = [x for x in resolve_ids(game, e["ids"][0])[0] if game.ledger.get(x)]
        if len(who) == 1 and not bad_name(game, who[0], e["text"]):
            out[who[0]] = " | ".join(x for x in (out.get(who[0]), e["text"]) if x)
    return out


def bad_name(game, eid: str, new: str, between: bool = False) -> str | None:
    """Why a `name` line can't put this name on someone, or None - spoiler-free (a log line, a flag). Never a GM-only
    name that isn't theirs: another's, or a seed's word nobody owns (a wrong id would hand her name to him for good,
    and the guard would let it go). Between turns (the aside, the canon) no play revealed anything: never a GM-only
    name at all, nor a name for someone the crew hasn't met."""
    g = guard(game)
    found = hits(game, new)
    if between and (found or eid in seed.sealed_ids(game.conn)):
        return ("between turns nothing in play reveals a name the table hasn't learned" if found
                else "the crew hasn't met them yet")
    other = [(t, o) for t, o in found if o != eid and not (o is None and eid in g.shared.get(t.lower(), []))]
    if other:
        return f"the name says a GM-only name that isn't theirs ({who(game, other)})"
    return None


def narration(game, text: str) -> list[tuple[str, str | None]]:
    """What the narration - outside its <dm> blocks - says that the table hasn't learned (less what its own `name`
    lines reveal)."""
    from .dmblock import BLOCK
    return hits(game, BLOCK.sub(" ", text or ""), revealed(game, text))


def scrub_narration(game, text: str) -> tuple[str, list[tuple[str, str | None]]]:
    """The narration scrubbed outside its <dm> blocks (the GM's notes in them may hold any name)."""
    from .dmblock import BLOCK
    allow, out, found, at = revealed(game, text), [], [], 0
    for m in list(BLOCK.finditer(text or "")) + [None]:
        piece, h = scrub(game, text[at:m.start() if m else len(text)], allow)
        out.append(piece)
        found += [x for x in h if x not in found]
        if m:
            out.append(m.group(0))
            at = m.end()
    return "".join(out), found


def _content(text: str) -> str:
    """Words without their articles and determiners: "the man in the green coat" is "a man in a green coat"."""
    return " ".join(_DETERMINER.sub(" ", text or "").split())


def says_handle(game, eid: str, text: str) -> bool:
    """Does the text call them by a name the crew has for them (their name on file or an alias, whatever its articles:
    "the man in the green coat" is "the man in a green coat")?"""
    ent = game.ledger.get(eid)
    if not ent or not text:
        return False
    plain = _content(text)
    for n in [ent["name"], *(ent["aliases"] or [])]:
        n = (n or "").strip()
        bare = _content(n)
        if len(bare) >= seed.MIN_NAME and n not in seed.UNSEEN.values() and seed._says(plain, bare):
            return True
    return False


def who(game, found) -> str:
    """The hits, spoiler-free: who they were about by what the crew calls them, never the term - for a flag or a
    log line the owner reads."""
    L, g = game.ledger, guard(game)
    owners = list(dict.fromkeys(o for t, o in found for o in ([o] if o else g.shared.get(t.lower(), []))))
    bits = [f"{(L.get(o) or {}).get('name', o)} [{o}]" for o in owners]
    loose = sum(1 for t, o in found if not o and t.lower() not in g.shared)
    if loose:
        bits.append(f"{loose} GM-only word{'s' * (loose != 1)} from the story seed")
    return ", ".join(bits) or "nothing"


def flag(game, kind: str, where: str, found, turn: int | None, what: str) -> None:
    """A spoiler-free flag: where it slipped, whose GM-only name, what the engine did."""
    from .. import flags
    flags.record(game, "engine", kind, f"{where} said a GM-only name ({who(game, found)}) - {what}", turn=turn)


def send_back(game, found) -> str:
    """The narration back to the GM, once: which names, and what the crew calls each one."""
    L = game.ledger
    said = "; ".join(f'"{t}" (say "{stand_in(game, o)}" [{o}])' if o and L.get(o) else f'"{t}" (GM-only)'
                     for t, o in found)
    return ("(Engine: the narration says names the table hasn't learned - " + said + ". The crew knows people by "
            "what they've seen of them (SEALED, at the top of the packet). Write the whole narration again with the "
            "names the crew knows. A name stays the GM's until play shows the crew learning it - a `name <id>: <the "
            "name>` line is for that alone, on that person's own id, never a way to keep one. Keep everything else, "
            "including any <dm> block. No tools - the rolls stand.)")


def lines(game, head: str) -> list[str]:
    """The SEALED block: for each name the table hasn't learned, what to say instead - for the packet and the frame
    (head: the section's header)."""
    g = guard(game)
    rows = [s for s in g.secrets if s.names or s.sealed]
    loose = [t for t, o in g.terms if not o and t.lower() not in g.shared] + g.words
    if not rows and not loose:
        return []
    out = [head]
    for s in rows:
        never = (" - never " + ", ".join(f'"{n}"' for n in s.names)) if s.names else ""
        name = called(game.ledger.get(s.id) or {"name": s.name, "aliases": []})
        if s.sealed and s.name in seed.UNSEEN.values():          # (nothing seen of them: no name to say at all)
            out.append(f"- ({s.id}) {s.name}: keep them out of what the players hear until play brings the crew to "
                       f"them{never}")
        elif s.sealed:
            out.append(f'- "{name}" ({s.id}), not met yet: keep them out of what the players hear until play brings '
                       f'the crew to them - then they\'re "{name}"{never}')
        else:
            out.append(f'- say "{name}" ({s.id}){never}')
    L = game.ledger
    for t, o in g.terms:
        if not o and t.lower() in g.shared:                      # (one word, two of them: once, with everyone's)
            out.append(f'- "{t}" is a GM-only name of more than one of them ('
                       + ", ".join(f"{called(L.get(x))} ({x})" for x in g.shared[t.lower()] if L.get(x))
                       + ") - never at the table")
    if loose:
        out.append("- GM-only words from the story seed, never at the table: " + ", ".join(f'"{t}"' for t in loose))
    return out


def packet_lines(game) -> list[str]:
    """The packet's SEALED block, read first (substrate/packet.py): every name the table hasn't learned, while any
    are left. Ids in parentheses, not brackets - the graph log counts a bracket as a memory the packet surfaced."""
    return lines(game, "=== SEALED (GM-only - read this before you write a word: names the table hasn't learned. Say "
                       "what the crew calls each one, in narration, dialogue and a speaker's label alike, never the "
                       "name after it - until play reveals it, and then write `name <id>: <the name>` in your <dm> "
                       "block in the same turn) ===")


def memory(game, data: dict, narration: str, turn: int, here=()) -> dict:
    """The memory pass's extraction, guarded before any of it is filed (commit.commit_turn): the summary, facts and new
    names scrubbed to the names the crew knows; a new name that is a GM-only one isn't filed, nor a move to a place
    under one; and someone sealed stays off the moment, and off a fact, unless the narration itself called them by
    their handle - or, for a witness role, they were in the scene when the turn began (`here`). 'Mentioned' never
    unseals them even then (seed.NOT_MET), and any other role does: review 2026-10-28, a pass that filed him 'present'
    when the narration never showed him unsealed him as surely as T191's 'mentioned'. A slip is flagged, spoiler-free."""
    L = game.ledger
    g = guard(game)
    sealed = seed.sealed_ids(game.conn)
    if not g.pattern and not sealed:
        return data
    found: list[tuple[str, str | None]] = []
    here = set(here or ())

    def clean(text) -> str:
        new, h = scrub(game, str(text or ""))
        found.extend(x for x in h if x not in found)
        return new

    def hidden(ref) -> bool:
        ent = L.find(str(ref or ""))
        return bool(ent) and ent["id"] in sealed and not says_handle(game, ent["id"], narration)
    if data.get("summary"):
        data["summary"] = clean(data["summary"])
    for f in data.get("facts") or []:
        f["text"] = clean(f.get("text"))
        f["about"] = [a for a in f.get("about") or [] if not hidden(a)]
    unseen, kept = [], []
    for m in data.get("members") or []:
        if hidden(m.get("id")) and (m.get("role") == "mentioned" or L.find(str(m.get("id")))["id"] not in here):
            if m.get("role") != "mentioned":
                unseen.append(L.find(str(m.get("id")))["id"])
            continue
        kept.append(m)
    data["members"] = kept
    if unseen:
        from .. import flags
        names = ", ".join(f"{L.get(x)['name']} [{x}]" for x in dict.fromkeys(unseen))
        flags.record(game, "engine", "spoiler", f"T{turn}'s memory pass put {names} in the moment, though the narration "
                     "never showed them and they weren't in the scene - left out, still sealed", turn=turn)
        game.out(f"[GUARD] the memory pass put someone sealed in the moment ({names}) - left out")
    kept = []
    for ne in data.get("new_entities") or []:
        h = hits(game, ne.get("name") or "")
        if h:
            found.extend(x for x in h if x not in found)
            game.out(f"  (memory pass: a new {ne.get('kind', 'name')} under a GM-only name ({who(game, h)}) - "
                     "not filed)")
            continue
        ne["description"] = clean(ne.get("description"))
        ne["aliases"] = [a for a in ne.get("aliases") or [] if not hits(game, a)]
        kept.append(ne)
    data["new_entities"] = kept
    moved = data.get("moved_to") or {}
    if moved.get("location"):
        h = hits(game, moved["location"])
        if h:                                      # (a cut there would file the stand-in as a place: "Someone")
            found.extend(x for x in h if x not in found)
            game.out(f"  (memory pass: a move to a place under a GM-only name ({who(game, h)}) - no cut)")
            data["moved_to"] = {**moved, "location": "", "description": "", "who": []}
        else:
            moved["description"] = clean(moved.get("description"))
    if found:
        flag(game, "spoiler", f"T{turn}'s memory pass", found, turn, "scrubbed to the names the crew knows")
        game.out(f"[GUARD] the memory pass said a GM-only name ({who(game, found)}) - scrubbed")
    return data


def answer(game, text: str, where: str, turn: int | None, what: str = "scrubbed before it was posted") -> str:
    """An answer the table (or a player) reads that drew on GM-side context - the aside's, !askdm's - scrubbed and
    flagged when it slipped. (`what`: what the engine did, for the flag.)"""
    new, found = scrub(game, text or "")
    if found:
        flag(game, "spoiler", where, found, turn, what)
        game.out(f"[GUARD] {where} said a GM-only name ({who(game, found)}) - scrubbed")
    return new


def card(game, line: str) -> str:
    """A card or notice the table reads as it happens (a roll's Why, a transfer's reason, karma's: the GM's own words),
    scrubbed - the table's out hook calls it for each one. Flagged, spoiler-free, and it never fails: the out hook
    can't cost a turn."""
    try:
        new, found = scrub(game, line)
        if found:
            flag(game, "spoiler", "A card at the table", found, None, "scrubbed before it posted")
        return new
    except Exception as exc:
        print(f"[spoilers] couldn't check a card: {exc}", flush=True)
        return line


def for_flag(game, text: str, context):
    """A flag's text and context in the names the crew knows (flags.record): the owner reads the flags page, and a GM
    flag line, a tool's input or a rewrite's quote can say any name. Never fails - a flag must always be written."""
    try:
        g = guard(game)
        if not g.pattern:
            return text, context

        def clean(v):
            if isinstance(v, str):
                return scrub(game, v)[0]
            if isinstance(v, dict):
                return {k: clean(x) for k, x in v.items()}
            if isinstance(v, (list, tuple)):
                return [clean(x) for x in v]
            return v
        return clean(str(text)), clean(context)
    except Exception as exc:
        print(f"[spoilers] couldn't check a flag: {exc}", flush=True)
        return text, context


def refuse(game, text: str, what: str) -> str | None:
    """Why a public line can't be filed as written (a GM tool's refusal: introduce, establish_fact), or None."""
    found = hits(game, text)
    if not found:
        return None
    L = game.ledger
    on = "; ".join(f'"{t}" is GM-only - they\'re on file as "{L.get(o)["name"]}" [{o}]' if o and L.get(o)
                   else f'"{t}" is GM-only' for t, o in found)
    return (f"{what} says a name the table hasn't learned ({on}). Write it with what the crew calls them, or keep it "
            "in a note; once the story reveals it, `name <id>: <the name>` in your <dm> block puts it on file.")
