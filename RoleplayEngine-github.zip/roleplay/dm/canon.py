"""The canon (DESIGN.md §10a): a sleep cycle that reconciles a long story with itself.

A long run piles up memory - the new world had 650 turn slices, 302 GM notes, 79 facts and 89 current pictures by
T160 - and each turn's packet shows the GM whatever is hottest right now. So settled things cool out of view (Juno
asked where Bo sleeps after it was settled again and again), the record contradicts itself ("Dr. Brask is confirmed
as a woman"), and stale table rulings keep steering (R11 still told the GM Juno raises Bo on Thursday). Nothing ever
read the whole story back and said what's true now.

The canon pass does, every CANON_EVERY turns (and at the first turn of a session, and on `!reconcile`): the strong
model reads every turn's summary since the last pass, the previous canon, the facts, the current pictures, the open
questions and the table's rulings, and writes the story's record:
- SETTLED - decisions and agreements that mustn't be re-opened, with the turn they were made;
- where everyone stands, who holds what, the timeline, what's coming up, the open threads and the closed ones;
- conflicts in the record, with which version is true - and the fix lines (`fact ... (replaces F12)`, `clarify`,
  `note`, `resolve Q3`), applied at once: the GM's own bookkeeping. One it can't settle with confidence becomes a
  doubt (doubts.py) for the GM to research, never a guess; and the open doubts it's shown, it settles where the
  record can tell;
- a review of every table ruling: keep, built into the engine now, stale, or in conflict. Those go to the TABLE as
  suggestions (`!rulings tidy` takes them) - rulings are the table's, never the engine's to drop.
A compact version rides at the top of every packet (=== CANON ===), outranking older memories. The whole thing is on
the dashboard's Canon page and `!canon` (the owner, by DM: it's full of spoilers).

The read runs off the game thread (like the offscreen world): gather and apply are quick; nobody waits on think.
"""
from __future__ import annotations

import json
import time

from . import dmblock, doubts, tensions
from .prompts import FICTION_NOTE
from .tools import TurnContext
from .. import rulings
from ..engine import clock

KEY, RULINGS_KEY = "canon", "canon_rulings"
CANON_EVERY = 20             # turns between passes in a long session
SESSION_GAP = 3 * 3600       # a gap this long before a turn: a new session - reconcile after its first turn
FIXABLE = ("fact", "note", "clarify", "resolve", "shelve", "doubt")
ENGINE_RULES = """\
- Teamwork: helpers roll their own pool first (no skill: they default, attribute - 1, where the skill allows it); \
each hit adds a die to the leader, capped at the leader's skill rating - the SR5 book cap, which replaces a ruling's \
"max +4" (the owner's call, 2026-10-27); a helper's glitch is their own complication. The leader is the one the \
player names, else the highest pool of those they name; who helped and the bonus are on the roll's record.
- Edge: refills to full every session; the GM can refresh it (edge refresh); push (6s explode, breaks a spell's \
Force), a called second chance (reroll, spent at once), insurance (if_short), burn. A second chance never passes the \
Force or undoes a glitch.
- Called rolls are binding and the engine enforces them: a player who says who rolls or leads, who helps, the skill, \
or spends Edge gets exactly that roll. A roll that gives it to someone else (an NPC, a helper), the wrong named skill, \
drops a named helper or leaves out their called Edge is turned away before the dice; the GM is sent back if it \
narrates past one, and then the engine rolls the call itself.
- Who rolls for what: persuasion is the PC's social test; judging evidence or doing a task is the judge's/doer's test.
- Going in circles (anti-stall): an NPC question or demand the players have answered, sidestepped or let lie twice \
is settled - the engine catches the third go (same NPC, same thing, however short: "Which is it?") and tells the GM \
it's closed, by name and turn, and NPCs don't raise it again. A player saying the story loops - to the GM, who \
judges it, or in a post ("another loop", "going in circles", "I already answered that", "why does she keep \
asking") - always gets the next turn told to close it; words a character says too ("I told you", "answer me \
straight") get the engine's read, and a camera loop is a move.
- The Heal spell heals Physical only, once per set of wounds; first aid and rest are separate rules.
- Thresholds follow the book (1/2/4/6/8-10); armor turns light hits into Stun; stun overflows 2:1.
- Ambushed characters caught flat-footed can't dodge the opening beat; invisible/unseen attackers are the GM's call.
- Fights: newcomers join the running fight (surprise test, +3 if alerted); a "not yet" battle end is turned away.
- Action Phases (the table's hard limit): every 10 Initiative is one attack, spell or grenade a round, and the engine
  refuses more; mopping up the helpless once nobody stands is free. Multiple Attacks split one pool (half the combat
  skill, rounded up); defenses wear down -1 each; parry/block/dodge (-5) and full defense (-10) cost Initiative.
- Dying: a box every Body minutes of story time until stabilized (First Aid + Logic (3)); an NPC left dying alone
  when the scene moves on dies. A coup de grace (attack finish) kills a helpless living target outright, no roll,
  once nobody stands against the attacker. Story time of an hour+ outside a fight rests the hurt by itself.
- Drones: an owner lends one by their own word (the keys stand until the owner takes the controls back); an NPC's
  changes hands only by a won hack; drones someone runs go where they go, unless taken out of a scene (left behind).
  Crashes and rams are the crash tool (the vehicle's Body; a ram's Body x the speed band, at a person, drone or
  vehicle; a Physical Barrier resists with Armor + Structure and can collapse - rammed on purpose, the driver's hits
  add to the damage).
  A drone carries only what's in its holdings: Body / 3 weapon mounts (a machine gun needs a heavy one), half its
  Pilot in autosofts - grenades aboard need no mount. A bought drone is the book's bare frame.
- Gear: SR5's prices and Availability; a dealer's search when an R/F item is stocked sets its delivery, and what's
  bought for delivery is held but unusable until the story clock gets there - canon can't have it in use sooner.
  Remote dealers (online, a fixer's call) live on their own entity, never the room the runners are in.
- The Matrix: hosts are node maps; legal work inside your access (and anything a real login opens) is free - no roll,
  no Overwatch; only illegal moves feed Overwatch; Track needs 2 host marks; jacking out resets Overwatch and access.
  A run goes where its decker goes (a cut that brings them brings it) and ends at their jack-out, or after 10 turns
  with no Matrix move and nothing of it in the story: the engine closes it quietly, and the next jack-in starts at
  Overwatch 0 with no trace - a trace lasts its run (its hook carries it on), and a host left alone cools.
  A host launches at most one IC a GM turn (one Combat Turn), however many beats it holds. IC damage hits the deck, soaked by Device Rating + Firewall; past a full
  deck it's the decker's Stun; Black IC skips the deck (Willpower + Firewall). A bricked deck gives no bonuses.
  The !difficulty dial reaches the Matrix: hosts and IC get its opposition dice, Matrix thresholds its shift - one
  dial for the room and the net. The host or device a player names is the one the decker goes after (a jack-in, a
  beat or a Matrix test elsewhere, harder than the rating they named, or into a host they ruled out is turned away
  before the dice, and a bare re-call again - it goes only with the GM's stated reason, flagged; a target named a
  turn or two before the dive still holds). Every Matrix roll is on the record with the host's dice (read_turn
  shows them).
- Narrative time: parts of the day, no ticking clock or travel minutes; the GM moves time when the story does
  (and what it moves heals the hurt and bleeds the dying, above). The engine keeps no deadline of its own: a due time
  is one the GM wrote or the crew set (a question's, or a job's), and one the table rules out is lifted with its
  question or job kept open (the GM's `fix Q#: due off` / `fix J#: due off`; this read-back lifts it too). The
  offscreen world's minds and the scene frame read the table's rulings and never plan around a time they ruled out or
  a storyline they closed; goals and hooks that do are retired as over (`fix A#: agenda` / `fix H#: hook` drop one at
  once). But the engine keeps no list of ruled-out times: it honours a timeline lock or a closed storyline only while
  that ruling stands, since the ruling is what the minds, the frame and this read-back read. So such a ruling is
  never built_in - keep it while its times are still ahead or the story could revive it; it's stale once they've
  passed.
- Seats: who plays which character is the engine's (!join / !companion / !park), never a ruling.
- Retcons: the GM's `correct` tool sets the numbers right; !undo takes back recent turns."""

SYSTEM = FICTION_NOTE + """ You keep the canon for a long-running Shadowrun campaign run by an AI game master on \
Discord: the reconciled record of what is TRUE in the story right now. You get the previous canon (if any), the \
summary of every turn since, the facts on file, each important character's current picture, the open questions, \
and the table's house rulings. Write the record:
- settled: decisions, agreements, custody, deals, revelations the players established - things no NPC may re-open or \
re-ask - each with the turn it was settled ("T150"). Be complete here; this is what stops the GM going in circles.
- people: every important NPC (and the PCs), one or two sentences: where they stand now, what they want, what \
they've agreed to, how they feel about the crew. Use their id from the record.
- holdings: who holds which key items, data, leverage and secrets.
- timeline: the key events in story order with their story time ("Day 3, morning"), oldest first, at most 25.
- upcoming: meetings, deadlines and promises still ahead - never a time or deadline a table ruling ruled out.
- open_threads / closed_threads: what's still live, and what's resolved and must not be revived.
- conflicts: where the record disagrees with itself or with the latest turns (a fact, a picture, a note, a summary). \
Say which version is true (the latest turns win unless they're clearly a slip) and give fix lines in the GM's <dm> \
block syntax: `fact <ids> (replaces F12): <the true version>`, `note <ids>: <a correction>`, `resolve Q3: <how it \
was settled>`, or `clarify <id>: <picture>`. <ids> are ids from the record - a person's [id] (the part in \
brackets), T# turns, F#, Q# - comma-separated: `note kaz, ghost, T165: ...`. A fact that comes out of a \
turn names that turn among its ids too (`fact razor, kaz, T4: ...`): the characters who were there are the ones who \
remember it. A clarify REPLACES that character's \
whole current picture, so it must be the full picture rewritten: keep everything still true (who they are, how they \
look and sound, what they \
know, want and feel, their ties) and change only what's wrong or out of date. For a small correction use a note \
instead. Only real contradictions - not things that are merely old. sure: true only when the record makes it clear \
which version is true. When it can't - two turns disagree and nothing later settles it, or only the players would \
know - sure is false and fixes stays empty: it becomes a doubt for the GM to research, never a guess. ids: the \
record's ids on both sides (T#, F#, C#, N#, people's [id]s).
- doubts: OPEN DOUBTS are places where someone already noticed the record doesn't add up. Judge each one from the \
record: verdict resolved when you can tell what's true (truth says it, and fixes are the fix lines that make the \
record true, as for conflicts), still_open when the record can't tell (truth "", fixes []). Never guess to close one. \
An issue already on OPEN DOUBTS goes in doubts only - never list it again under conflicts.
- rulings: judge EVERY table ruling: keep (still needed), built_in (the engine now does this itself - see ENGINE \
RULES), stale (the moment or situation it covered is over), or conflicts (it contradicts the engine, the book or \
another ruling) - with one sentence why. A timeline lock or a closed storyline is never built_in: the engine honours \
it only by reading the ruling, so it's keep while it still matters and stale once it doesn't.
- over: the ids of GOALS (A#) and HOOKS (H#) that are finished, moot or overtaken by the story - they'll be retired \
(a goal for a meeting that happened, a hook into a storyline the table closed, one that plans around a time or \
deadline a table ruling ruled out) - and the Q# or J# of each DEADLINE a table ruling ruled out (its due time is \
lifted; the question or the job stays open) - each with one short reason. Leave out anything still live.
Never invent: everything comes from the record. Prefer the latest turns over older notes. Keep every item short."""


def _arr(item: dict | None = None) -> dict:
    return {"type": "array", "items": item or {"type": "string"}}


def _obj(**props) -> dict:
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def schema() -> dict:
    s = {"type": "string"}
    return _obj(settled=_arr(_obj(what=s, since=s)), people=_arr(_obj(id=s, name=s, stands=s)), holdings=_arr(),
                timeline=_arr(), upcoming=_arr(), open_threads=_arr(), closed_threads=_arr(),
                conflicts=_arr(_obj(issue=s, canon=s, fixes=_arr(), sure={"type": "boolean"}, ids=_arr())),
                doubts=_arr(_obj(id=s, verdict={"type": "string", "enum": ["resolved", "still_open"]}, truth=s,
                                 fixes=_arr())),
                rulings=_arr(_obj(id=s, verdict={"type": "string", "enum": ["keep", "built_in", "stale", "conflicts"]},
                                  why=s)),
                over=_arr(_obj(id=s, why=s)))


# ── state ───────────────────────────────────────────────────────────────
def current(game) -> dict | None:
    try:
        return json.loads(game.ledger.meta(KEY) or "null")
    except ValueError:
        return None


def _last_turn(game) -> int:
    return int(game.conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns WHERE status='committed'").fetchone()[0] or 0)


def due(game) -> bool:
    """After a public turn: time for a pass? Every CANON_EVERY turns; after the first turn of a new session; and once
    a world without a canon has some story to it."""
    c = current(game)
    last = _last_turn(game)
    since = last - int((c or {}).get("turn", 0))
    if not c:
        return last >= 15
    if since >= CANON_EVERY:
        return True
    rows = game.conn.execute("SELECT created_at FROM turns WHERE status='committed' AND private IS NULL "
                             "ORDER BY id DESC LIMIT 2").fetchall()
    if len(rows) == 2 and since >= 5:
        from ..spend import _utc
        return _utc(rows[0][0]) - _utc(rows[1][0]) >= SESSION_GAP
    return False


# ── gather (game thread, quick) ─────────────────────────────────────────
def gather(game) -> dict:
    """Everything the read needs, as text - read on the game thread so think can run off it."""
    conn, L, S = game.conn, game.ledger, game.sub
    prev = current(game)
    upto = _last_turn(game)
    start = max(1, int((prev or {}).get("turn", 0)) - 5)
    turns = []
    for r in conn.execute("SELECT t.id, t.scene_id, t.narration, t.private, n.text FROM turns t LEFT JOIN nodes n "
                          "ON n.id = 'T' || t.id WHERE t.status='committed' AND t.id >= ? ORDER BY t.id", (start,)):
        what = r["text"] or (r["narration"] or "")[:300]
        turns.append(f"T{r['id']} (S{r['scene_id']}{', whisper' if r['private'] else ''}): {what}")
    scenes = [f"S{r['id']} \"{r['title']}\" T{r['created_turn']}-{r['closed_turn'] or 'now'}" for r in
              conn.execute("SELECT id, title, created_turn, closed_turn FROM scenes ORDER BY id")]
    facts = [f"{r['id']} (T{r['created_turn']}): {r['text']}" for r in conn.execute(
        "SELECT id, text, created_turn FROM nodes WHERE kind='fact' AND id NOT IN (SELECT old_id FROM supersedes) "
        "ORDER BY created_turn")]
    people = []
    for e in L.entities(kind="pc") + L.entities(kind="npc"):
        if e.get("tier", 1) < 2 and e["kind"] == "npc":
            continue
        c = S.clarification(e["id"])
        if c:
            people.append(f"{e['name']} [{e['id']}] (C as of T{c['created_turn']}): {c['text']}")
    rules = [f"[{r['id']}] (by {r['by']}, T{r['created_turn']}): {r['text']}" for r in rulings.active(game)]
    from .. import narrative
    from .. import seed                                 # (the owner's story seeds: their intent and arc - seed.py)
    steer = [f"[{d['id']}] (T{d['created_turn']}): {d['text']}" for d in narrative.active(game)]
    goals = [f"[{r['id']}] {(L.get(r['npc_id']) or {}).get('name', r['npc_id'])} (since T{r['created_turn']}, last "
             f"moved T{r['updated_turn']}): {r['goal']}" for r in conn.execute(
                 "SELECT * FROM agendas WHERE status='active' ORDER BY created_turn")]
    hooks = [f"[{r['id']}] (T{r['created_turn']}) {r['text']}" for r in conn.execute(
        "SELECT h.id, h.created_turn, n.text FROM hooks h JOIN nodes n ON n.id=h.id WHERE h.status='ready' "
        "ORDER BY h.created_turn")]
    # every due time the engine holds, by its Q#: the read-back lifts one a ruling ruled out (flag #42 - R11's timeline
    # lock stood from T55, and Q1's Day 5 noon still pressed at T147; OPEN QUESTIONS shows only the top few in full)
    dues = [f"[{r['id']}] due {clock.fmt(r['due_time'])}: {r['question']}" for r in conn.execute(
        "SELECT id, question, due_time FROM tensions WHERE status IN ('open', 'shelved') AND due_time IS NOT NULL "
        "ORDER BY due_time")]
    # ...and an open job's, by its J# (review 2026-10-27: THE JOB's deadline pressed in every packet, and nothing - no
    # lever, no read-back - could lift one a ruling ruled out)
    from .. import jobs
    from . import world
    dues += [f"[{j['id']}] the job \"{j['title']}\" - deadline: {j['deadline']}" for j in jobs.open_jobs(game)
             if (j["deadline"] or "").strip()]
    items = [x.split("]", 1)[0][1:] for x in goals + hooks + dues]
    # each deadline as it was shown: apply lifts only one still the same (one the GM moved since is the GM's)
    marks = {x: world.deadline_mark(game, x) for x in (d.split("]", 1)[0][1:] for d in dues)}
    qs = tensions.packet_lines(game)
    open_doubts = doubts.listing(conn, upto, settled=0)["open"]
    doubt_lines = []
    for d in open_doubts:                                # each with both sides in their own words, to judge it by
        doubt_lines.append(f"[{d['id']}] (raised T{d['raised_turn']} by {doubts.NAMED.get(d['raised_by'], d['raised_by'])}"
                           f", open {d['age']} turns): {d['text']}")
        for a in d["about"]:
            n = S.node(a["id"]) if not L.get(a["id"]) else None
            doubt_lines.append(f"    on {a['id']}" + (f" ({n['kind']}, T{n['created_turn']}): {n['text'][:300]}" if n
                                                     else f" ({a['label']})"))
        doubt_lines += [f"    worked on T{x['created_turn']}: {x['text'][:200]}" for x in d["notes"][-2:]]
    text = ("PREVIOUS CANON (as of T{}):\n{}\n\n".format(prev["turn"], render(prev)) if prev else "")
    text += ("SCENES:\n" + "\n".join(scenes) + "\n\nTURNS" + (f" since T{start}" if prev else "") + ":\n"
             + "\n".join(turns) + "\n\nFACTS ON FILE:\n" + ("\n".join(facts) or "(none)")
             + "\n\nCURRENT PICTURES:\n" + ("\n".join(people) or "(none)")
             + "\n\nOPEN QUESTIONS:\n" + ("\n".join(qs) or "(none)")
             + "\n\nOPEN DOUBTS (where the record was caught disagreeing with itself - settle each you can, in "
               "doubts):\n" + ("\n".join(doubt_lines) or "(none)")
             + "\n\nTABLE RULINGS:\n" + ("\n".join(rules) or "(none)")
             + ("\n\nSTORY DIRECTIONS FROM THE TABLE (where the players want the story to go - keep these threads "
                "open):\n" + "\n".join(steer) if steer else "")
             + seed.canon_text(game)
             + "\n\nGOALS NPCs AND FACTIONS ARE PURSUING (active):\n" + ("\n".join(goals) or "(none)")
             + "\n\nHOOKS WAITING TO LAND:\n" + ("\n".join(hooks) or "(none)")
             + ("\n\nDEADLINES THE ENGINE HOLDS (open questions' due times, open jobs' deadlines):\n" + "\n".join(dues)
                if dues else "")
             + f"\n\nENGINE RULES (what the engine does by itself now):\n{ENGINE_RULES}"
             + f"\n\nSTORY TIME NOW: {game.clock_line()}")
    from .. import newparty
    text += newparty.canon_lines(game, start)            # (a new party in these turns: the skip, newer than them all)
    return {"text": text, "turn": upto, "rulings": [r["id"] for r in rulings.active(game)], "items": items,
            "deadlines": marks, "doubts": {d["id"]: _mark(game, d["id"]) for d in open_doubts}}


def _mark(game, xid: str) -> list | None:
    """A doubt as the read-back was shown it - its words, when it was raised, its status, how often and how lately it
    was raised and worked on - so apply can tell whether it's still that doubt, still open and untouched: think runs
    off the game thread while turns go on (session._canon_pass), and the packet tells the GM to settle a doubt before
    it narrates. (An undo hands an X# out again: the sequence is turn state.)"""
    d = doubts.get(game, xid)
    return [d["text"], d["raised_turn"], d["status"], d["times"], d["last_turn"], len(doubts._notes(game.conn, xid)),
            len(doubts.about(game.conn, xid))] if d else None


# ── think (off the game thread) ─────────────────────────────────────────
def think(game, gathered: dict) -> dict:
    return game.llm.structured(game.settings.models.dm, SYSTEM, gathered["text"], schema(), max_tokens=12000,
                               effort="low", fallback=game.settings.models.commit, purpose="canon")


# ── apply (game thread, quick) ──────────────────────────────────────────
def _whole_picture(game, e: dict, turn: int) -> dict:
    """A clarify replaces someone's whole current picture. One much shorter than the picture it replaces would wipe
    who they are (the first live pass wrote "Storyline closed." over Marisol's 600 characters), so it goes in as a
    correction note instead - the GM reads it beside the picture, and folds it in at its next clarify."""
    if e["kind"] != "clarify" or not e["ids"]:
        return e
    ids, _ = dmblock.resolve_ids(game, ", ".join(e["ids"]))     # (the same reading apply gives it: 'Kaz [kaz]')
    if not ids:
        return e
    old = game.sub.clarification(ids[0])
    if old and len(e["text"]) < max(160, 0.6 * len(old["text"])):
        return {**e, "kind": "note", "text": f"Correction (canon read-back, T{turn}): {e['text']}"}
    return e


def _fix(game, turn: int, lines) -> tuple[list[str], list[str], list[str]]:
    """Fix lines through the GM's own <dm> path, written as the canon: (what landed, the lines that couldn't be
    placed, the kinds that aren't the canon's to write)."""
    lines = [x.strip() for x in lines or [] if x and x.strip()]
    if not lines:
        return [], [], []
    _, entries = dmblock.split("<dm>\n" + "\n".join(lines) + "\n</dm>")
    # (a line in no form at all - `note kaz - alive after all` - is applied too, to land on unplaced)
    ours = [e for e in entries if e["kind"] in FIXABLE or e["kind"] == dmblock.UNREAD]
    keep = [_whole_picture(game, e, turn) for e in ours]
    skipped = [e["kind"] for e in entries if e not in ours]
    if not keep:
        return [], [], skipped
    ctx = TurnContext(game, turn, game.current_scene_id(), by="canon")
    dmblock.apply(ctx, keep)
    # live T181: 'note quiet-lou filament: ...' was lost and the flag listed only what landed - so the T165 slip
    # stayed uncorrected, and the next pass read the conflict as resolved
    return ctx.events, [e["line"] for e in ctx.unplaced], skipped


def _state(game, xid: str, then) -> str:
    """A doubt the read-back was shown, now: fresh (still open, untouched since), worked (open, but raised again or
    worked on since), settled (resolved or dismissed since), or gone (an undo took it - its X# may be another's)."""
    now = _mark(game, xid)
    if not now or (then and now[:2] != then[:2]):
        return "gone"
    if now[2] != "open":
        return "settled"
    return "worked" if then and now != then else "fresh"


def _same_issue(game, ids: list[str], shown: list[str]) -> str | None:
    """The open doubt it was shown that a conflict is about: one sharing a memory with it (a T#, F#, C#, N# - the
    record's pieces that disagree; a person alone is too wide), the most shared first - or, for a conflict naming only
    people, one about the same people. Review (2026-10-26): an open doubt is a conflict in the record by definition, so
    the read-back listed X1 again under conflicts in its own words; a 0.8 word match missed that, and each pass opened
    a second doubt beside the first - or applied the same fix twice, a sure conflict's and X1's verdict's."""
    L = game.ledger
    mine = {i for i in ids if not L.get(i)}
    best, most = None, 0.0
    for x in shown:
        sides = set(doubts.about(game.conn, x))
        n = float(len(mine & {s for s in sides if not L.get(s)}))
        if not mine and ids and sides and (set(ids) <= sides or sides <= set(ids)):
            n = 0.5
        if n > most:
            best, most = x, n
    return best


def _doubts(game, gathered: dict, data: dict, turn: int) -> dict:
    """The read-back's conflicts and its verdicts on the open doubts, against the doubts as they stand NOW. A conflict
    it isn't sure of becomes a doubt (raised by the canon) instead of a guess - its fixes are left alone - unless it's
    one of the open doubts it was shown, which gets the read-back's words as a note instead. Each doubt it was shown
    and could settle is resolved once its fixes have landed: one whose fix went nowhere stays open, with a note saying
    so. A doubt the GM settled or worked on while the read-back was thinking keeps the GM's answer: the read-back's
    goes on it as a note, its fixes unapplied, and it's never reopened. Review (2026-10-26): its stale fixes landed on
    top of the GM's ruling - the record said both, the doubt read settled - a failed one reopened the GM's ruling, and
    after an undo it settled whichever doubt held the X# now."""
    was = gathered.get("doubts") or {}
    was = dict.fromkeys(was) if isinstance(was, list) else was        # (a gather without marks: status checks only)
    state = {x: _state(game, x, m) for x, m in was.items()}
    live = [x for x, s in state.items() if s != "gone"]
    verdicts = {}
    for v in data.get("doubts") or []:
        xid, truth = doubts._id(v.get("id")), (v.get("truth") or "").strip()
        if xid in live and v.get("verdict") == "resolved" and truth:
            verdicts[xid] = {"truth": truth, "fixes": [f for f in v.get("fixes") or [] if f and f.strip()]}
    conflicts = []
    for c in data.get("conflicts") or []:
        ids, _ = dmblock.resolve_ids(game, ", ".join(str(i) for i in c.get("ids") or []))
        conflicts.append((c, ids, _same_issue(game, ids, live)))
    fixed, unplaced, skipped, raised, settled, late = [], [], [], [], [], []

    def note(x: str, what: str, fixes) -> None:          # the read-back's answer, kept - not applied
        d = doubts.get(game, x)
        why = (f"it was {d['status']} first (T{d['resolved_turn']}, by "
               f"{doubts.NAMED.get(d['resolved_by'], d['resolved_by'])})" if d["status"] != "open"
               else "it was worked on since, so that answer may be stale - settle it with what's new")
        game.sub.add_note([x], f"(the canon read-back, reading the record as of T{turn}) {what}"
                          + (f" - with: {' | '.join(fixes)}" if fixes else "") + f" - not applied: {why}.",
                          max(turn, game.turn_no()))         # (after the turns' own work on it: the packet's Latest)
        if x not in late:
            late.append(x)

    lines = []
    for c, ids, x in conflicts:                          # sure: its fixes - unless a doubt it's about has them
        if not c.get("sure", True):
            continue
        fixes = [f for f in c.get("fixes") or [] if f and f.strip()]
        if x in verdicts:                                # (one set of fixes for one issue, not two)
            verdicts[x]["fixes"] = verdicts[x]["fixes"] or fixes
        elif x and state[x] in ("settled", "worked"):
            note(x, f"is sure: {c.get('canon') or c.get('issue')}", fixes)
        else:
            lines += fixes
    fixed, unplaced, skipped = _fix(game, turn, lines)
    for c, ids, x in conflicts:                          # not sure: a doubt for the GM, never a guess
        if c.get("sure", True) or not (c.get("issue") or "").strip():
            continue
        lean = f" (the read-back leans: {c['canon']})" if c.get("canon") else ""
        if x in verdicts:
            continue                                     # (its verdict on that one, below, answers it)
        if x and state[x] == "settled":
            c["settled_as"] = x                          # (settled while it read: the GM's answer stands)
            continue
        if x:                                            # one it was shown, still open: more on it, not another
            doubts.work(game, x, c["issue"] + lean, turn, [i for i in ids if i not in doubts.about(game.conn, x)],
                        by="canon")
            c["doubt"] = x
            continue
        r = doubts.raise_(game, c["issue"] + lean, ids, turn, by="canon", reopen=doubts.REOPENS["canon"])
        if r["status"] == "settled":
            c["settled_as"] = r["id"]                    # (dismissed: not one to bring back - and never "left open")
            continue
        c["doubt"] = r["id"]
        if r["status"] == "reopened":
            c["reopened"] = True
        if r["status"] in ("new", "reopened"):
            raised.append(r["id"])
    for xid, v in verdicts.items():
        if state[xid] != "fresh":
            note(xid, f"would have resolved it: {v['truth']}", v["fixes"])
            continue
        f, u, s = _fix(game, turn, v["fixes"])
        fixed, skipped = fixed + f, skipped + s
        if u:
            unplaced += u
            doubts.work(game, xid, f"Its answer ({v['truth']}) couldn't be written: {' | '.join(u)}", turn, by="canon")
            continue
        if doubts.resolve(game, xid, turn, v["truth"], by="canon"):
            settled.append(xid)
    return {"fixed": fixed, "unplaced": unplaced, "skipped": skipped, "raised": raised, "resolved": settled,
            "late": late}


def apply(game, gathered: dict, data: dict) -> dict:
    """Store the canon, fix the record, settle and raise doubts, keep the rulings review for the table."""
    L, conn = game.ledger, game.conn
    t = gathered["turn"]
    own = not conn.in_transaction
    if own:
        conn.execute("BEGIN IMMEDIATE")
    try:
        dbt = _doubts(game, gathered, data, t)
        fixed, unplaced, skipped = dbt["fixed"], dbt["unplaced"], dbt["skipped"]
        active = set(gathered.get("rulings") or [])
        review = [r for r in data.get("rulings") or [] if rulings.norm_id(r.get("id", "")) in active]
        for r in review:
            r["id"] = rulings.norm_id(r["id"])
        canon = {k: data.get(k) or [] for k in ("settled", "people", "holdings", "timeline", "upcoming",
                                                "open_threads", "closed_threads", "conflicts")}
        from . import world
        shown = set(gathered.get("items") or [])
        overs = [o for o in data.get("over") or [] if str(o.get("id", "")).strip().upper() in shown]
        # A deadline moved or set while it read isn't the one it judged (think runs off the game thread while turns
        # go on): the GM's move stands. Review 2026-10-27: `tension Q1: ... | due day 6 evening` after the gather, and
        # the stale `over` lifted the new Day 6 deadline. (As the late doubts are left alone, above.)
        marks = gathered.get("deadlines") or {}
        moved = [x for x in dict.fromkeys(str(o.get("id")).strip().upper() for o in overs)
                 if x in marks and world.deadline_mark(game, x) != marks[x]]
        retired = world.retire(game, [o for o in overs if str(o.get("id")).strip().upper() not in moved],
                               gathered["turn"])
        moved = [f"{x}'s deadline" for x in moved]
        canon.update(turn=gathered["turn"], at=time.time(), fixed=fixed, unplaced=unplaced, rulings=review,
                     retired=retired, deadlines_moved=moved, doubts={k: dbt[k] for k in ("resolved", "raised", "late")})
        prev = L.meta(KEY)
        if prev:
            L.set_meta(KEY + "_prev", prev)
        L.set_meta(KEY, json.dumps(canon))
        drop = [r for r in review if r["verdict"] in ("built_in", "stale")]
        L.set_meta(RULINGS_KEY, json.dumps(drop))
        if own:
            conn.execute("COMMIT")
    except BaseException:
        if own:
            conn.execute("ROLLBACK")
        raise
    from .. import flags
    if fixed or unplaced or dbt["raised"] or dbt["resolved"] or dbt["late"]:
        flags.record(game, "engine", "canon fixes",
                     (f"The canon pass corrected the record: {'; '.join(fixed)[:1500]}" if fixed else
                      "The canon pass corrected nothing.")
                     + (f" Could not place: {' | '.join(unplaced)[:1000]}" if unplaced else "")
                     + (f" Doubts settled: {', '.join(dbt['resolved'])}." if dbt["resolved"] else "")
                     + (f" Left open as doubts (the record can't tell): {', '.join(dbt['raised'])}." if dbt["raised"]
                        else "")
                     + (f" Settled or worked on while it read (its answer left as a note): {', '.join(dbt['late'])}."
                        if dbt["late"] else ""), turn=gathered["turn"])
    return {"turn": gathered["turn"], "settled": len(canon["settled"]), "fixed": fixed, "skipped": skipped,
            "unplaced": unplaced, "review": review, "drop": drop, "retired": retired, "deadlines_moved": moved,
            "doubts_resolved": dbt["resolved"], "doubts_raised": dbt["raised"], "doubts_late": dbt["late"]}


def run(game) -> dict:
    """All three on one thread (the console, tests, !reconcile when nothing else is going on)."""
    g = gather(game)
    return apply(game, g, think(game, g))


# ── reading it ──────────────────────────────────────────────────────────
VERDICT = {"keep": "keep", "built_in": "the engine does this now", "stale": "stale", "conflicts": "conflicts"}


def render(c: dict | None) -> str:
    """The whole canon, for the next pass, the dashboard and !canon."""
    if not c:
        return "(no canon yet)"
    out = [f"CANON as of T{c.get('turn')}"]

    def sect(title, items):
        if items:
            out.append(f"\n{title}")
            out.extend(f"- {x}" for x in items)
    sect("SETTLED (not to be re-opened)", [f"{s['what']} ({s['since']})" for s in c.get("settled") or []])
    sect("WHERE EVERYONE STANDS", [f"{p['name']} [{p['id']}]: {p['stands']}" for p in c.get("people") or []])
    sect("WHO HOLDS WHAT", c.get("holdings"))
    sect("TIMELINE", c.get("timeline"))
    sect("COMING UP", c.get("upcoming"))
    sect("OPEN THREADS", c.get("open_threads"))
    sect("CLOSED THREADS (don't revive)", c.get("closed_threads"))
    sect("CONFLICTS RESOLVED", [f"{x['issue']} -> {x['canon']}" for x in c.get("conflicts") or []
                                if not x.get("doubt") and not x.get("settled_as")])
    sect("LEFT OPEN AS DOUBTS (the record couldn't tell - the GM researches them)",
         [f"{x['issue']} -> [{x['doubt']}]" + (" (reopened)" if x.get("reopened") else "")
          for x in c.get("conflicts") or [] if x.get("doubt")])
    # (review 2026-10-26: one matching a settled doubt read "-> [X1]" here, as if X1 were open)
    sect("ALREADY SETTLED AS DOUBTS (that answer stands - not reopened)",
         [f"{x['issue']} -> [{x['settled_as']}]" for x in c.get("conflicts") or [] if x.get("settled_as")])
    sect("DOUBTS IT SETTLED", (c.get("doubts") or {}).get("resolved"))
    sect("DOUBTS SETTLED OR WORKED ON WHILE IT READ (its answer is a note on them, not applied)",
         (c.get("doubts") or {}).get("late"))
    sect("FIX LINES THAT COULD NOT BE PLACED (no one on file by those ids, or not in a line's form - give them again: "
         "`note <id>, <id>: ...` with the [id]s)", c.get("unplaced"))
    sect("GOALS AND HOOKS RETIRED AS OVER", c.get("retired"))
    sect("DEADLINES MOVED WHILE IT READ (not lifted - the GM's move stands)", c.get("deadlines_moved"))
    sect("RULINGS REVIEW", [f"{r['id']}: {VERDICT.get(r['verdict'], r['verdict'])} - {r['why']}" for r in c.get("rulings") or []])
    return "\n".join(out)


def packet_lines(game, scene_id: int | None = None) -> list[str]:
    """The compact canon at the top of every packet (~2k tokens at most): what's settled, where the people here
    stand, what's coming, what's open and what's closed."""
    c = current(game)
    if not c:
        return []
    here = set(game.ledger.roster(scene_id)) if scene_id else set()
    people = sorted(c.get("people") or [], key=lambda p: p.get("id") not in here)[:10]
    cut = lambda s, n=170: s if len(s) <= n else s[:n - 1] + "…"          # noqa: E731
    out = [f"\n=== CANON (the story's reconciled record as of T{c['turn']} - it outranks older memories. Never have an "
           "NPC re-open or re-ask anything SETTLED, and don't revive a CLOSED thread; what happened since is below) ==="]
    if c.get("settled"):
        out.append("SETTLED: " + " • ".join(cut(f"{s['what']} ({s['since']})") for s in c["settled"][-20:]))
    if people:
        out.append("WHERE PEOPLE STAND: " + " • ".join(cut(f"{p['name']}: {p['stands']}", 190) for p in people))
    if c.get("upcoming"):
        out.append("COMING UP: " + " • ".join(cut(x, 140) for x in c["upcoming"][:5]))
    if c.get("open_threads"):
        out.append("OPEN THREADS: " + " • ".join(cut(x, 140) for x in c["open_threads"][:6]))
    if c.get("closed_threads"):
        out.append("CLOSED (don't revive): " + " • ".join(cut(x, 110) for x in c["closed_threads"][-8:]))
    return out


# ── the rulings review: the table's call ────────────────────────────────
def _meta(conn, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row[0] if row else None


def suggested(game) -> list[dict]:
    """The rulings the last pass thinks can go (built in, or stale) and that are still standing."""
    try:
        drop = json.loads(_meta(game.conn, RULINGS_KEY) or "[]")
    except ValueError:
        return []
    live = {r["id"] for r in rulings.active(game)}
    return [r for r in drop if r["id"] in live]


def review_text(game) -> str | None:
    """The table's ⚖️ Rulings review card: what the last pass would drop, what conflicts, and how to take it."""
    try:
        review = (json.loads(_meta(game.conn, KEY) or "{}") or {}).get("rulings") or []
    except ValueError:
        return None
    live = {r["id"]: r for r in rulings.active(game)}
    drop = [r for r in suggested(game)]
    clash = [r for r in review if r["verdict"] == "conflicts" and r["id"] in live]
    if not drop and not clash:
        return None
    out = []
    if drop:
        out.append("**Could go** - the engine does it now, or its moment has passed:")
        out += [f"• **{r['id']}** ({VERDICT[r['verdict']]}) {r['why']}" for r in drop]
    if clash:
        out.append("**Clashes** - with the rules, the engine or another ruling (worth a look):")
        out += [f"• **{r['id']}** {r['why']}" for r in clash]
    out.append("-# " + ("Owner: `!rulings tidy` drops the ones that could go · " if drop else "")
               + "`!rulings` shows them all · `!ruling drop R#` for one. Rulings are the table's - nothing is dropped "
               "until you say so.")
    return "\n".join(out)


def tidy_rulings(game, who: str) -> list[str]:
    """`!rulings tidy`: drop the rulings the last canon pass marked built-in or stale. Returns the ids dropped. Runs
    on a side connection (`game` is just a conn), like every other ruling command."""
    done = []
    for r in suggested(game):
        try:
            rulings.retire(game, r["id"], "dropped", who)
            done.append(r["id"])
        except Exception:
            pass                                          # (gone in the meantime)
    game.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?, '[]')", (RULINGS_KEY,))
    return done
