"""Who's speaking (DESIGN.md §12b): dialogue carries the speaker's id, not just a name.

The GM writes `**Pruett [ration-man]:** "..."` - the name the scene uses right now (a first name, a nickname, "the
Sergeant"), and the id from the packet. Names drift - October's Ration Man said "Name's... Pruett" and from then on
spoke as **Pruett:**, which matched nobody, so his lines went out gray with no portrait. The id doesn't drift.

`resolve` strips the ids before anyone reads the narration (players, memory, recaps), hands back who each label was,
and learns a new name the story calls someone by as an alias - so "Pruett" finds him everywhere else too (mentions in
memory, `!dossier Pruett`, the GM's own packet). A label that's already someone else's name isn't learned.
"""
from __future__ import annotations

import re

from ..engine.ledger import LedgerError

TAG = re.compile(r"\*\*([^*\n\[\]]{1,48}?)\s*\[([A-Za-z0-9_'-]{1,64})\]\s*:\*\*")
NAMEISH = re.compile(r"^[A-Za-z][A-Za-z.'\- ]{1,38}$")      # a name or a title, not "Kaz (quietly)" or "Voice, low"


def resolve(game, narration: str, turn: int | None = None) -> tuple[str, dict[str, str], list[str]]:
    """(the narration with the ids stripped, {speaker label: entity id}, the names learned)."""
    L = game.ledger
    speakers: dict[str, str] = {}
    learned: list[str] = []

    def strip(m: re.Match) -> str:
        label, eid = m.group(1).strip(), m.group(2).strip().lower()
        ent = L.get(eid)
        if not ent:
            from .. import flags
            flags.record(game, "engine", "speaker id", f"**{label} [{eid}]** - no character has that id", turn=turn)
        if ent and ent["kind"] in ("pc", "npc"):
            speakers[label] = eid
            known = {ent["name"].lower(), *(a.lower() for a in ent["aliases"])}
            if label.lower() not in known and NAMEISH.match(label) and len(label.split()) <= 4:
                from . import spoilers
                other = L.find(label)
                # (someone else's name stays theirs; a GM-only one is never learned - `name <id>: ...` reveals it)
                if other is None and not spoilers.hits(game, label):
                    L.update_entity(eid, aliases=ent["aliases"] + [label])
                    learned.append(f"{label} = {ent['name']}")
        return f"**{label}:**"
    return TAG.sub(strip, narration), speakers, learned


def rename(game, eid: str, new: str, turn: int | None = None) -> str:
    """Someone's on file under a new name (the story revealed it, or the owner fixed it): the old name stays as an
    alias, and everything that hangs off the id - portrait, voice, memories, dossier - follows."""
    L = game.ledger
    ent = L.require(eid)
    new = " ".join((new or "").split()).strip(" \"'")
    if not new:
        raise LedgerError("A new name needs some words.")
    if new.lower() == ent["name"].lower():
        return f"{ent['name']} is already on file as {new}."
    other = L.find(new)
    if other and other["id"] != eid:
        raise LedgerError(f"{new} is already someone else ({other['name']}) - `!merge` if they're the same person.")
    aliases = [a for a in ent["aliases"] if a.lower() != new.lower()]
    if ent["name"].lower() not in (a.lower() for a in aliases):
        aliases.append(ent["name"])
    L.update_entity(eid, name=new, aliases=aliases)
    L.log(turn, "renamed", eid, {"from": ent["name"], "to": new})
    if game.sub.exists(eid):                                  # (the memory graph's copy of who they are)
        game.sub.ensure_entity(L.get(eid), turn or 0)
    return f"{ent['name']} is on file as {new} now"
