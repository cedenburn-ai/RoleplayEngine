"""The scene frame (DESIGN.md §10b): who everyone in the room is right now, and where they stand with each other.

The packet hands the GM a file on each person present - description, persona, current picture, how they feel about
each PC, what they remember - written at different times and never put together. On the live T161 packet the people
section was 30k of 48k characters: Brask's persona still guarded a secret she'd since testified to, her read on Lou
was from T48 ("an ambush... watch the 12:00 draw"), five of her goals were long over, three hooks waited to reopen a
closed storyline - and how Juno and Brask stood with each other, the most charged pair in the room, wasn't there at
all (NPC-to-NPC views never reach the packet). The GM had to reconcile it all, every turn, in its head.

The frame does that once per scene beat, off the game thread. Given the canon, the job, the table's directions, each
person's files - persona, picture, how they see EACH other person in the room, their goals - the hooks touching them and
the scene so far, the GM's model writes:
- why the crew is here (the intent, or "nothing - downtime") and what presses on the scene;
- for each person: who they are now, what they want here (or nothing), what they won't do, where they stand with each
  other person present (NPCs with each other too), and what's settled between them and the crew;
- which of the goals and hooks it was shown are over - those are the engine's, so they're retired (unlike rulings).
  The table's rulings ride along (TABLE RULES): a goal or hook that plans around a time they ruled out is over too.
It rides right before PRESENT; the files stay below as background, and a "feels about" older than the frame shrinks to
its attitude number. It's rebuilt when the cast changes, every FRAME_EVERY turns in the scene, and after a canon pass.
It's the GM's own planning, and says so: the GM plays from it, so it calls everyone what the crew knows them as. The
names the table hasn't learned are listed at the top of what it's given, and everything it writes is scrubbed to the
crew's names after (spoilers.py; 2026-10-28 - the first seed's rehearsal's first frame put a GM-only label in a public
NPC's 'now', and the GM said it at the table).
"""
from __future__ import annotations

import json
import time

from .prompts import FICTION_NOTE

FRAME_EVERY = 6
SYSTEM = FICTION_NOTE + """ You frame the scene for the AI game master of a long-running Shadowrun campaign on \
Discord. You get the story's canon, the crew's job, what the players asked for, a file on everyone in the room \
(written at different times - the newest material wins), and the scene so far. Write how things stand RIGHT NOW:
- TABLE RULES are the players' own house rulings and outrank every file: nothing in the frame may plan around a time \
or deadline they ruled out, revive a storyline they closed or re-open what they settled.
- intent: why the crew is here and what they're after in this scene, in a sentence or two - or say plainly that \
nothing's being pursued (downtime, a breather).
- pressure: what presses on the scene - a clock, a faction, the place itself, who's watching - or "". Never a clock \
or deadline the TABLE RULES ruled out.
- people: everyone in the room (PCs too), by id:
  - now: who they are at this moment - situation, mood, what's changed for them lately. Current, not their history.
  - wants_here: what they want from this scene or the people in it - or "nothing in particular".
  - wont: what they won't do or give up here (from their persona, limits and promises).
  - toward: one line for EVERY other person in the room they share real history with - where they stand now: \
trust, debts, grudges, a confession or betrayal, what's unspoken between them. NPCs with each other just as much as \
with the crew (the files' "Sees ..." lines are the raw material - bring them up to date). Skip only strangers.
  - settled: what's already settled between them and the crew - answered, agreed, forgiven - that they must not \
re-ask or re-open.
- over: the ids of goals (A#) and hooks (H#) in the files that are finished, moot or overtaken by events - or that \
plan around a time, deadline or storyline the TABLE RULES ruled out - they'll be retired - each with one short \
reason. Leave out anything still live.
Base everything on the record; where files disagree, the latest turns win. Write it all inside the fiction - \
never mention players, the table, logging off, bugs or anything said out of character. Use each person's pronouns \
as their description or picture gives them (older notes sometimes get them wrong). Keep every line short and \
concrete.
- Names: the GM plays from your frame at the table, so call everyone what the crew knows them as - the name in their \
### header, nothing else. NAMES THE TABLE HASN'T LEARNED lists the real names and GM-only labels behind some of them, \
and who the crew hasn't met yet: never write those, even where a file uses them. What a secret means for how someone \
acts can shape their lines; the secret's names never appear."""


def _arr(item: dict | None = None) -> dict:
    return {"type": "array", "items": item or {"type": "string"}}


def _obj(**props) -> dict:
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def schema() -> dict:
    s = {"type": "string"}
    return _obj(intent=s, pressure=s,
                people=_arr(_obj(id=s, now=s, wants_here=s, wont=s, toward=_arr(_obj(id=s, stance=s)),
                                 settled=_arr())),
                over=_arr(_obj(id=s, why=s)))


# ── state ───────────────────────────────────────────────────────────────
def _key(sid: int) -> str:
    return f"frame_S{sid}"


def current(game, sid: int | None = None) -> dict | None:
    sid = sid or game.current_scene_id()
    try:
        return json.loads(game.ledger.meta(_key(sid)) or "null")
    except ValueError:
        return None


def cast(game, sid: int) -> list[str]:
    """The people the frame is about: PCs and named NPCs in the scene."""
    L = game.ledger
    return sorted(e["id"] for e in (L.get(x) for x in L.roster(sid))
                  if e and (e["kind"] == "pc" or (e["kind"] == "npc" and e.get("tier", 1) >= 1)))


def _canon_turn(game) -> int:
    from . import canon
    return int((canon.current(game) or {}).get("turn", 0))


def due(game, sid: int | None = None) -> bool:
    """After a public turn: does this scene need (re)framing? Only scenes with an NPC in them get one."""
    sid = sid or game.current_scene_id()
    people = cast(game, sid)
    if not any((game.ledger.get(x) or {}).get("kind") == "npc" for x in people):
        return False
    f = current(game, sid)
    if not f:
        return True
    if sorted(f.get("cast") or []) != people or _canon_turn(game) > int(f.get("canon", 0)):
        return True
    since = game.conn.execute("SELECT COUNT(*) FROM turns WHERE scene_id=? AND status='committed' AND private IS NULL "
                              "AND id > ?", (sid, int(f.get("turn", 0)))).fetchone()[0]
    return since >= FRAME_EVERY


# ── gather (game thread, quick) ─────────────────────────────────────────
def gather(game, sid: int | None = None) -> dict:
    from .. import jobs, narrative, rulings
    from . import canon, world
    L, S = game.ledger, game.sub
    sid = sid or game.current_scene_id()
    scene = L.scene(sid)
    people = cast(game, sid)
    names = {x: L.get(x)["name"] for x in people}
    upto = int(game.turn_no())
    out = [f"SCENE S{sid}: {scene['title']}", f"Story time: {game.clock_line()}"]
    # the names behind the files (a seed's sealed entities, a real name the story hasn't revealed): the rehearsal's
    # first frame after the opening gave a public NPC a GM-only label in 'now', and the GM said it at the table
    from . import spoilers
    out += spoilers.lines(game, "\n=== NAMES THE TABLE HASN'T LEARNED (never in the frame - call each one what the "
                                "crew knows them as) ===")
    loc = L.get(scene["location_id"]) if scene["location_id"] else None
    if loc:
        out.append(f"Location: {loc['name']} - {loc['description']}")
        pic = S.clarification(loc["id"])
        if pic:
            out.append(f"  GM's picture of it (T{pic['created_turn']}): {pic['text']}")
    out += canon.packet_lines(game, sid) + jobs.packet_lines(game) + narrative.packet_lines(game)
    out += rulings.table_rules(game)        # (its pressure and its goals are never a time R11 ruled out - flag #42)
    out.append("\n=== EVERYONE IN THE ROOM (files written at different times - note the turn on each) ===")
    items = []
    for eid in people:
        e = L.get(eid)
        out.append(f"\n### {e['name']} [{eid}] - {'PC' if e['kind'] == 'pc' else 'NPC'}"
                   + (f" ({e['props'].get('template')})" if e["kind"] == "npc" and e["props"].get("template") else "")
                   + f": {e['description']}")
        if e["kind"] == "npc":
            bible = world.persona_line(e)
            if bible:
                out.append(f"Persona (written when they were introduced): {bible}")
            groups = [f"{f['name']} ({role})" for f, role in world.factions_of(game, eid)]
            if groups:
                out.append("Belongs to: " + ", ".join(groups))
        pic = S.clarification(eid)
        if pic:
            out.append(f"GM's current picture (T{pic['created_turn']}): {pic['text']}")
        for other in people:
            if other == eid:
                continue
            b = S.current_belief(eid, other)
            att = int(L.stat(eid, f"attitude:{other}", 0)) if L.get(other)["kind"] == "pc" else None
            if b or att:
                out.append(f"Sees {names[other]}" + (f" (attitude {att:+d})" if att is not None else "")
                           + (f" [T{b['created_turn']}]: {b['text']}" if b else ""))
        for a in world.agendas_of(game, eid):
            out.append(f"Goal [{a['id']}] (since T{a['created_turn']}, last moved T{a['updated_turn']}): {a['goal']}")
            items.append(a["id"])
    if people:
        marks = ",".join("?" * len(people))
        hooks = game.conn.execute(
            f"SELECT DISTINCT h.id, h.created_turn, n.text FROM hooks h JOIN nodes n ON n.id=h.id JOIN links l "
            f"ON (l.a=h.id OR l.b=h.id) AND l.kind IN ('about', 'from') WHERE h.status='ready' "
            f"AND (l.a IN ({marks}) OR l.b IN ({marks})) ORDER BY h.created_turn", (*people, *people)).fetchall()
        if hooks:
            out.append("\n=== HOOKS WAITING TO LAND ON THEM ===")
            for h in hooks:
                out.append(f"[{h['id']}] (T{h['created_turn']}) {h['text']}")
                items.append(h["id"])
    out.append("\n=== THIS SCENE SO FAR (oldest first) ===")
    out += [f"T{r['created_turn']}: {r['text']}" for r in S.recent_slices(sid, 12)] or ["(nothing yet)"]
    last = L.last_turn(sid, public=True)
    if last and last["narration"]:
        out.append(f"\nThe GM's last narration:\n{last['narration'][:2000]}")
    return {"text": "\n".join(out), "sid": sid, "turn": upto, "cast": people, "canon": _canon_turn(game),
            "items": items}


# ── think (off the game thread) ─────────────────────────────────────────
def think(game, gathered: dict) -> dict:
    return game.llm.structured(game.settings.models.dm, SYSTEM, gathered["text"], schema(), max_tokens=6000,
                               effort="low", fallback=game.settings.models.commit, purpose="frame")


# ── apply (game thread, quick) ──────────────────────────────────────────
def _scrubbed(game, data: dict) -> list:
    """Every line the GM plays from, in the names the crew knows (spoilers.scrub) - the backstop under SYSTEM's rule.
    Returns what it held, spoiler-free to flag."""
    from . import spoilers
    found: list = []

    def clean(text) -> str:
        new, h = spoilers.scrub(game, str(text or ""))
        found.extend(x for x in h if x not in found)
        return new
    for k in ("intent", "pressure"):
        data[k] = clean(data.get(k))
    for p in data.get("people") or []:
        for k in ("now", "wants_here", "wont"):
            p[k] = clean(p.get(k))
        p["settled"] = [clean(s) for s in p.get("settled") or []]
        for t in p.get("toward") or []:
            t["stance"] = clean(t.get("stance"))
    return found


def apply(game, gathered: dict, data: dict) -> dict:
    from . import spoilers, world
    people = set(gathered["cast"])
    found = _scrubbed(game, data)
    if found:
        spoilers.flag(game, "spoiler", f"S{gathered['sid']}'s scene frame", found, gathered["turn"],
                      "scrubbed to the names the crew knows")
    framed = []
    for p in data.get("people") or []:
        if p.get("id") in people:
            p["toward"] = [t for t in p.get("toward") or [] if t.get("id") in people and t["id"] != p["id"]]
            framed.append(p)
    shown = set(gathered.get("items") or [])
    retired = world.retire(game, [o for o in data.get("over") or [] if o.get("id", "").upper() in shown],
                           gathered["turn"])
    f = {"sid": gathered["sid"], "turn": gathered["turn"], "at": time.time(), "cast": gathered["cast"],
         "canon": gathered["canon"], "intent": data.get("intent") or "", "pressure": data.get("pressure") or "",
         "people": framed, "retired": retired}
    game.ledger.set_meta(_key(gathered["sid"]), json.dumps(f))
    return f


def run(game, sid: int | None = None) -> dict:
    g = gather(game, sid)
    return apply(game, g, think(game, g))


# ── reading it ──────────────────────────────────────────────────────────
def framed_at(game, sid: int) -> tuple[int | None, set[str]]:
    """(the turn the frame was written, the ids it covers) - the packet shrinks older "feels about" for them."""
    f = current(game, sid)
    return (int(f["turn"]), {p["id"] for p in f.get("people") or []}) if f else (None, set())


def packet_lines(game, sid: int) -> list[str]:
    f = current(game, sid)
    if not f:
        return []
    L = game.ledger
    here = set(L.roster(sid))
    name = lambda x: (L.get(x) or {}).get("name", x)          # noqa: E731
    from . import spoilers
    g = spoilers.guard(game)
    sealed = " (SEALED, above)" if g.secrets or g.terms or g.words else ""
    out = [f"\n=== SCENE FRAME (GM-only - your own planning, as of T{f['turn']}: who everyone here is right now and "
           "where they stand with each other. Play them from it, never quote it: at the table people go by the names "
           f"the crew knows{sealed}. The files under PRESENT are background; where they disagree, this and the turns "
           "since win) ==="]
    if f.get("intent"):
        out.append(f"WHY THEY'RE HERE: {f['intent']}")
    if f.get("pressure"):
        out.append(f"PRESSURE: {f['pressure']}")
    for p in f.get("people") or []:
        if p["id"] not in here:
            continue
        out.append(f"{name(p['id'])} [{p['id']}] - now: {p['now']} | wants here: {p['wants_here']}"
                   + (f" | won't: {p['wont']}" if p.get("wont") else ""))
        toward = [t for t in p.get("toward") or [] if t["id"] in here]
        if toward:
            out.append("  toward " + "; ".join(f"{name(t['id'])}: {t['stance']}" for t in toward))
        if p.get("settled"):
            out.append("  settled with the crew (don't re-open): " + " • ".join(p["settled"]))
    new = [x for x in cast(game, sid) if x not in set(f.get("cast") or [])]
    if new:
        out.append(f"(Arrived since the frame: {', '.join(name(x) for x in new)} - see their files below.)")
    return out


def render(f: dict | None, game=None) -> str:
    """The whole frame as text, for `!frame` (by DM - spoilers)."""
    if not f:
        return "(no frame for this scene yet)"
    name = (lambda x: (game.ledger.get(x) or {}).get("name", x)) if game else (lambda x: x)
    out = [f"SCENE FRAME S{f['sid']} as of T{f['turn']}", f"Why they're here: {f.get('intent') or '-'}"]
    if f.get("pressure"):
        out.append(f"Pressure: {f['pressure']}")
    for p in f.get("people") or []:
        out.append(f"\n{name(p['id'])}: {p['now']}\n  wants here: {p['wants_here']}"
                   + (f"\n  won't: {p['wont']}" if p.get("wont") else ""))
        out += [f"  toward {name(t['id'])}: {t['stance']}" for t in p.get("toward") or []]
        out += [f"  settled: {s}" for s in p.get("settled") or []]
    if f.get("retired"):
        out.append("\nRetired as over: " + "; ".join(f.get("retired")))
    return "\n".join(out)
