"""Thin wrapper over the Anthropic SDK: the DM tool-loop step, structured extraction, cost tracking."""
from __future__ import annotations

import json
import threading
from concurrent.futures import ThreadPoolExecutor

import anthropic

from .. import keys
from ..config import FALLBACK_MODELS, PRICES, Models

FALLBACK_BETA = "server-side-fallback-2026-07-01"


def ensure_api_key() -> None:
    """The API keys into os.environ for the SDK: config.toml, else the environment, else the Windows user env
    (keys.py - a shell started before the key was set doesn't inherit it)."""
    keys.export_api_keys()


def _price(model: str) -> tuple[float, float, float, float]:
    for key, p in PRICES.items():
        if model.startswith(key):
            return p
    return PRICES["claude-opus-5-5"]


class Usage:
    def __init__(self):
        self.total = 0.0
        self.calls = 0
        self.by_model: dict[str, dict] = {}
        self.by_purpose: dict[str, float] = {}
        self.sink = None                 # called with each call's numbers (spend.Sink: the folder's spend log)
        self._lock = threading.Lock()    # (calls run side by side: the world pass, minds, notebook folds)

    def add(self, model: str, usage, purpose: str = "other") -> float:
        if usage is None:
            return 0.0
        with self._lock:
            return self._add(model, usage, purpose)

    def _add(self, model: str, usage, purpose: str) -> float:
        inp = getattr(usage, "input_tokens", 0) or 0
        out = getattr(usage, "output_tokens", 0) or 0
        cr = getattr(usage, "cache_read_input_tokens", 0) or 0
        cw = getattr(usage, "cache_creation_input_tokens", 0) or 0
        p_in, p_out, p_cr, p_cw = _price(model)
        cost = (inp * p_in + out * p_out + cr * p_cr + cw * p_cw) / 1_000_000
        m = self.by_model.setdefault(model, {"in": 0, "out": 0, "cache_read": 0, "cache_write": 0, "cost": 0.0, "calls": 0})
        m["in"] += inp
        m["out"] += out
        m["cache_read"] += cr
        m["cache_write"] += cw
        m["cost"] += cost
        m["calls"] += 1
        self.by_purpose[purpose] = self.by_purpose.get(purpose, 0.0) + cost
        self.total += cost
        self.calls += 1
        if self.sink is not None:
            try:
                self.sink(model, purpose, inp, out, cr, cw, cost)
            except Exception:                # the spend log must never cost a turn
                pass
        return cost


PARALLEL = 6                             # model calls side by side in one pass


def fan_out(fn, items: list, workers: int = PARALLEL) -> list:
    """fn(item) for every item, side by side - for passes of independent model calls (one per NPC, one per notebook
    page) that used to wait on each other. Results come back in order; a failure comes back as its exception.
    fn must not touch the game's database: build the prompts before, write the results after, on the game thread."""
    def one(item):
        try:
            return fn(item)
        except Exception as exc:          # (each caller says what failed, and carries on)
            return exc
    if len(items) <= 1:
        return [one(i) for i in items]
    with ThreadPoolExecutor(max_workers=min(workers, len(items)), thread_name_prefix="fan-out") as pool:
        return list(pool.map(one, items))


class LLM:
    def __init__(self, models: Models, client: anthropic.Anthropic | None = None):
        if client is None:                   # (a client handed in brings its own key)
            ensure_api_key()
        self.models = models
        self.client = client or anthropic.Anthropic()
        self.usage = Usage()

    def dm_step(self, system: list[dict], tools: list[dict], messages: list[dict], progress=None):
        """One step of the DM's tool loop on Opus 5.5.

        Streaming (avoids HTTP timeouts on long turns). Refusal fallbacks enabled: if a safety
        classifier declines (gritty crime fiction can trip one), the API re-runs on a fallback
        model inside the same call. Caching: an explicit 1h marker on the system prompt
        (tools + rules, shared by every turn) plus automatic caching for the growing tail.
        `progress(kind, detail)` hears the stream as it goes: thinking, writing (words so far), a tool call (its name).
        """
        extra = {"betas": [FALLBACK_BETA], "fallbacks": "default"} if self.models.dm in FALLBACK_MODELS else {}
        with self.client.beta.messages.stream(
            model=self.models.dm,
            max_tokens=self.models.dm_max_tokens,
            system=system,
            tools=tools,
            messages=messages,
            output_config={"effort": self.models.dm_effort},
            cache_control={"type": "ephemeral"},
            **extra,
        ) as stream:
            if progress is not None:
                words, told = 0, -1
                for ev in stream:
                    if ev.type == "content_block_start":
                        kind = getattr(ev.content_block, "type", "")
                        if kind in ("thinking", "redacted_thinking"):
                            progress("thinking", None)
                        elif kind == "text":
                            progress("writing", words)
                        elif kind == "tool_use":
                            progress("tool_call", getattr(ev.content_block, "name", ""))
                    elif ev.type == "content_block_delta" and getattr(ev.delta, "type", "") == "text_delta":
                        words += ev.delta.text.count(" ")
                        if words // 25 != told:          # (every 25 words or so is plenty)
                            told = words // 25
                            progress("writing", words)
            msg = stream.get_final_message()
        self.usage.add(getattr(msg, "model", None) or self.models.dm, msg.usage, "gm")
        return msg

    def structured(self, model: str, system: str, user: str, schema: dict,
                   max_tokens: int = 8000, effort: str = "low", fallback: str | None = None,
                   purpose: str = "other") -> dict:
        """fallback: a model to retry with if this one declines (Opus sometimes refuses a creative retelling that
        Haiku handles fine - a false positive, not a reason to lose the feature). purpose: what the spend log files
        the call under (spend.PURPOSES)."""
        resp = self.client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
            output_config={"effort": effort, "format": {"type": "json_schema", "schema": schema}},
        )
        self.usage.add(model, resp.usage, purpose)
        if resp.stop_reason == "refusal":
            if fallback and fallback != model:
                return self.structured(fallback, system, user, schema, max_tokens, effort, purpose=purpose)
            raise RuntimeError("extraction refused")
        text = next(b.text for b in resp.content if b.type == "text")
        return json.loads(text)

    def consult(self, model: str, system: str, messages: list[dict], tools: list[dict] | None = None,
                schema: dict | None = None, max_tokens: int = 4000, effort: str = "low", fallback: str | None = None,
                purpose: str = "other", tool_choice: dict | None = None):
        """One step of a short research loop out of the story - the GM aside, !askdm (research.consult, DESIGN.md
        §8e): read-only tools to look things up, and with a schema the answer as JSON once it's done (structured
        output constrains the answer, not the tool calls). tool_choice {"type": "none"} on the last step makes it
        answer (Opus 5.5 rejects forced tool use; none is fine). Automatic caching: each step re-sends the packet.
        fallback: a model to re-run the step with if this one declines. Returns the message."""
        out: dict = {"effort": effort}
        if schema:
            out["format"] = {"type": "json_schema", "schema": schema}
        extra: dict = {"tools": tools} if tools else {}
        if tools and tool_choice:
            extra["tool_choice"] = tool_choice
        resp = self.client.messages.create(model=model, max_tokens=max_tokens, system=system, messages=messages,
                                           output_config=out, cache_control={"type": "ephemeral"}, **extra)
        self.usage.add(model, resp.usage, purpose)
        if resp.stop_reason == "refusal" and fallback and fallback != model:
            return self.consult(fallback, system, messages, tools, schema, max_tokens, effort, None, purpose,
                                tool_choice)
        return resp

    def text(self, model: str, system: str, user: str, max_tokens: int = 4000, effort: str = "low",
             fallback: str | None = None, purpose: str = "other") -> str:
        resp = self.client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
            output_config={"effort": effort},
        )
        self.usage.add(model, resp.usage, purpose)
        if resp.stop_reason == "refusal":
            if fallback and fallback != model:
                return self.text(fallback, system, user, max_tokens, effort, purpose=purpose)
            return "(The system declined to answer that one.)"
        return "".join(b.text for b in resp.content if b.type == "text").strip()
