"""The DM's tools: the only way the model can change the world. Every call is validated by the
engine; violations come back as is_error results the model can correct.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import NamedTuple

from ..engine import geo
from ..engine.ledger import LedgerError, RulesRefusal
from ..engine.rules import explosives, machines, magic, matrix, resonance, sr_lite
from ..substrate.store import SEARCH_KINDS, norm_id
from . import calls, corrections, doubts, research, spoilers

_MODS = {"type": "array", "description": "Situational modifiers, each -4..+4 with a short label.",
         "items": {"type": "object", "properties": {"label": {"type": "string"}, "value": {"type": "integer"}},
                   "required": ["label", "value"]}}


def _tool(name: str, description: str, props: dict, required: list[str]) -> dict:
    return {"name": name, "description": description,
            "input_schema": {"type": "object", "properties": props, "required": required}}


from .. import encounters                            # (fights: encounters.py)
from .. import shops as _shops                       # (in-game shops: shops.py)
_SHOP_CATALOG = _shops.catalog_lines()

EDGE_FIELD = {"type": "string", "enum": list(sr_lite.EDGE_USES) + ["none"],
              "description": "ONLY when that character's player said they spend Edge on this roll, as they said it. "
                             "push ('push it', 'add my Edge', 'reroll 6s', 'exploding 6s'): before the roll - +Edge "
                             "dice, sixes explode, the limit ignored (the only way past a spell's Force). reroll "
                             "('reroll my misses/fails', 'second chance'): binding - the misses are rerolled now, held "
                             "only with no misses, at the Force already, or when more hits can't change anything; it "
                             "never raises the Force. if_short ('Edge if I miss', 'if needed', 'just in case'): "
                             "insurance - rerolled only if the roll falls short, the point spent only then. none: "
                             "the Edge they called this turn was for another roll, or a branch that didn't happen."}
# Interrupt defenses, paid from the defender's Initiative (SR5 p. 168, 188) - declared, never assumed.
DEFENSE_FIELD = {"type": "array", "items": {"type": "string", "enum": list(encounters.INTERRUPTS)},
                 "description": "The defender's interrupt for this defense - ONLY when that character's player says so "
                                "(you choose for NPCs and the characters you run: a samurai parries). full: +Willpower "
                                "on every defense for the rest of the round, -10 Initiative, against anything. parry "
                                "(+Close Combat, a melee weapon in hand), block (+Close Combat, empty hands) or dodge "
                                "(+Athletics): one of them, -5 Initiative, against melee only. The engine checks they "
                                "can afford it and says so on the card."}

# Attribute-only tests (SR5 p. 152): when no skill fits, two attributes paired. Live review: Invisibility's card asked
# for Logic + Willpower and request_test could roll only a skill.
ATTRIBUTES_FIELD = {"type": "array", "items": {"type": "string", "enum": list(sr_lite.ATTRIBUTES)},
                    "description": "An attribute-only test instead of a skill (omit skill): the two attributes the "
                                   "book pairs when no skill fits (SR5 p. 152) - Charisma + Willpower to keep your "
                                   "nerve, Logic + Willpower to remember, or to see through a mana illusion like "
                                   "Invisibility (threshold: the spell's hits, on its cast card)."}

_TURN_FIELD = {"type": "integer", "description": "Only from / up to this turn number (150 for T150)."}

TOOLS = [
    # ── research: your notes (DESIGN.md §8d). Lookups don't spend your tool steps, up to a generous allowance. ──
    _tool("recall", "Open memories by id - T#/W# moments, S# scenes, F# facts, N# notes, C# pictures, B# beliefs, A# "
          "goals, H# hooks, Q# tensions - or a person, place or thing (id or name): the full text, the current "
          "picture, who was involved, whether it was SUPERSEDED (by what: the current version) or replaced something, "
          "your DM notes, and its strongest linked memories. A person comes with their sheet and their mind: what "
          "they think of each person now (attitude, since when), their active goals, the last things they heard and "
          "from whom, where they are, and where others stand toward them. A free lookup.",
          {"ids": {"type": "array", "items": {"type": "string"}, "description": "Up to 8 ids or names."}}, ["ids"]),
    _tool("read_turn", "What was actually said: for each turn, the story time and scene, the players' posts and your "
          "narration word for word, and its rolls (who rolled what, the hits, the result). For the exact terms of a "
          "deal, a promise, who said what to whom - a summary is only the gist. W# reads an offscreen moment (who was "
          "in it, its rolls, who has heard of it since). A free lookup.",
          {"turn_ids": {"type": "array", "items": {"type": "string"},
                        "description": "'T150', '150', a range 'T148-T150' (6 turns a call at most), or 'W617'."},
           "around": {"type": "string", "description": "A phrase or a few words: only the passages of the narration "
                                                       "around them, not the whole turn."}},
          ["turn_ids"]),
    _tool("search_memory", "Search everything the world remembers - turns, offscreen moments, scenes, facts, your "
          "notes and pictures, NPC beliefs and goals, hooks, tensions, people - by words (names count, even 'Bo'). "
          "Every word matched ranks first, then the most words, then heat; each hit shows the passage around the "
          "words and is marked when superseded. A free lookup.",
          {"query": {"type": "string", "description": "The words to look for (names, ids, a phrase)."},
           "about": {"type": "array", "items": {"type": "string"},
                     "description": "Only memories linked to or involving ALL of these - people, places, things (ids "
                                    "or names) or memory ids: 'what do I have on Juno and Brask'."},
           "kinds": {"type": "array", "items": {"type": "string", "enum": list(SEARCH_KINDS)},
                     "description": "Only these kinds: turn (T#), offscreen (W#), scene, fact, note, picture (C#), "
                                    "belief, agenda (an NPC's goal), hook, tension, doubt (X#), entity."},
           "from_turn": _TURN_FIELD, "to_turn": _TURN_FIELD,
           "in_narration": {"type": "boolean", "description": "Also search what was actually said - your narration and "
                                                              "the players' posts - for the turn and the passage."},
           "limit": {"type": "integer", "description": "How many hits (default 10, at most 20)."}},
          ["query"]),
    _tool("timeline", "What has happened between people: the turns and offscreen moments involving ALL of them, "
          "oldest first, with story time and summary - the most recent `limit` in the range. One person: their own "
          "story; a place or an item works too. Then read_turn for the exact words of the one that matters. A free "
          "lookup.",
          {"ids": {"type": "array", "items": {"type": "string"}, "description": "People (or a place, an item), by id "
                                                                               "or name."},
           "from_turn": _TURN_FIELD, "to_turn": _TURN_FIELD,
           "limit": {"type": "integer", "description": "How many moments (default 12, at most 30)."}},
          ["ids"]),
    # ── doubts: the record's continuity (dm/doubts.py, DESIGN.md §12k) - a step of only lookups and doubts is free ──
    _tool("doubt", "When the record doesn't add up - two records disagree, the narration would contradict a fact, an "
          "NPC knows what they couldn't, the timeline doesn't fit - never let it pass and never quietly pick a "
          "version. raise: it goes on your DOUBTS list and stays there until settled (ids: everything involved, "
          "both sides; an X# in ids adds to that one). resolve (id: the X#) once you've found what's true: text says "
          "it, and fixes are the <dm> lines that make the record true - `fact <ids> (replaces F45): ...`, `clarify "
          "<id>: ...`, `note <ids>: ...` - applied now; it's resolved once every one lands. dismiss (id): it never "
          "was a contradiction (text: why). Out of the fiction - an in-story open question is a tension, an engine "
          "bug a flag.",
          {"action": {"type": "string", "enum": ["raise", "resolve", "dismiss"]},
           "ids": {"type": "array", "items": {"type": "string"},
                   "description": "raise: every id involved, both sides - T#/W# turns, F# facts, C# pictures, N# notes, "
                                  "B# beliefs, people by id or name."},
           "id": {"type": "string", "description": "resolve / dismiss: the doubt's X#."},
           "text": {"type": "string", "description": "raise: what doesn't add up, both versions; resolve: what's true; "
                                                     "dismiss: why it isn't one."},
           "fixes": {"type": "array", "items": {"type": "string"},
                     "description": "resolve: the fix lines (fact / clarify / note) that make the record true."}},
          ["action", "text"]),
    _tool("request_test", "Roll a skill test for a character. Use a threshold for static difficulty - 1 easy, 2 "
          "average, 4 hard, 6 very hard, 8-10 extreme (SR5) - or "
          "opposed_by for a contest against another entity (an NPC or a host). Roll for whoever's skill is in play: "
          "persuading someone is the PC's social test (the only place attitude modifiers go); judging evidence or doing "
          "a task is the judge's or the doer's own test - an NPC can be the actor - never the messenger's. Handing "
          "something over isn't a test at all. When no skill fits, it's an attribute-only test: attributes, no skill.",
          {"actor_id": {"type": "string"},
           "skill": {"type": "string", "enum": sorted(sr_lite.SKILLS),
                     "description": "The skill - every test but an attribute-only one."},
           "attribute": {"type": "string", "enum": list(sr_lite.ATTRIBUTES),
                         "description": "Optional; defaults to the skill's linked attribute."},
           "attributes": ATTRIBUTES_FIELD,
           "threshold": {"type": "integer"},
           "opposed_by": {"type": "object", "properties": {
               "entity_id": {"type": "string"},
               "skill": {"type": "string", "enum": sorted(sr_lite.SKILLS)},
               "attribute": {"type": "string", "enum": list(sr_lite.ATTRIBUTES)},
               "attributes": {**ATTRIBUTES_FIELD, "description": "Their side as an attribute-only test, no skill "
                                                                 "(Judge Intentions: Willpower + Charisma)."}},
               "required": ["entity_id"]},
           "modifiers": _MODS,
           "reason": {"type": "string", "description": "One line: what is being attempted."},
           "edge": EDGE_FIELD,
           "helpers": {"type": "array", "description": "Teamwork: others pitching in on this same task (the players "
                                                        "say they help). Each rolls their own pool - the same skill "
                                                        "unless you name another - and every hit adds a die to the "
                                                        "actor's pool, up to the actor's rating in the skill. The "
                                                        "engine rolls it all and shows it on the card. When a player "
                                                        "calls the roll, the one they name to lead is the actor and "
                                                        "the ones they name helping are here - the engine turns away "
                                                        "a roll that has a helper or an NPC rolling in their place.",
                       "items": {"type": "object", "properties": {
                           "id": {"type": "string"},
                           "skill": {"type": "string", "enum": sorted(sr_lite.SKILLS)}}, "required": ["id"]}}},
          ["actor_id", "reason"]),
    _tool("attack", "Resolve one attack ACTION: attack roll vs defense, damage, soak, ammo. In a fight it is one of "
          "the attacker's Action Phases this round (the FIGHT section shows them; the engine refuses one past them - "
          "what's left carries into the next round). Several strikes in that one phase - a katana across two gangers, "
          "a fan of throwing knives, a gun in each hand - go in ONE call: target_id for the first, `more` for the rest "
          "(Multiple Attacks: the pool splits evenly, at most half the combat skill rounded up; the same target twice "
          "is fine; a gun fires once a phase, so two shots need a second gun, weapon_id per strike, -2 off-hand). "
          "thrown: the weapon is thrown - Throwing + Agility at range, it lands in the room (several throws: this "
          "zone or the next, and that many in hand). defense: the target's interrupt (full / parry / block / dodge) - "
          "only when their player says so, your choice for NPCs and the characters you run. Omit weapon_id for "
          "unarmed. Edge: edge (the attacker's player - one Edge covers every strike), defense_edge / soak_edge (the "
          "target's player, on the dodge / soak). unaware: the target never sees it coming (a sniper they haven't "
          "spotted, a knife from behind) - no dodge, only cover; ambushed characters caught flat-footed are unaware by "
          "themselves until they act. finish: a coup de grace - the attacker kills a helpless target outright, no roll "
          "(unconscious, dying, or a body left limp by VR, astral projection or a jumped-in rig; a living one, not a "
          "machine), once nobody stands against the attacker - the engine refuses it otherwise. Finishing off the "
          "helpless once nobody stands against you costs no Action Phase (the table's house rule).",
          {"attacker_id": {"type": "string"}, "target_id": {"type": "string"}, "weapon_id": {"type": "string"},
           "modifiers": _MODS, "reason": {"type": "string"}, "unaware": {"type": "boolean"},
           "finish": {"type": "boolean", "description": "A coup de grace on a helpless target: 'kill the survivors', "
                                                        "'make sure they're dead', 'finish him' - the others it "
                                                        "kills go in `more` (one call for all of them). Give it to "
                                                        "whoever is best placed to do it, not whoever has the worst "
                                                        "pool."},
           "thrown": {"type": "boolean", "description": "The weapon is thrown (a knife, shuriken, a hatchet): Throwing "
                                                        "+ Agility at range, no closing in, and it leaves the hand."},
           "defense": DEFENSE_FIELD,
           "more": {"type": "array", "description": "Multiple Attacks: the further strikes in this same Action Phase "
                                                    "(Quiet Lou's Close Combat 6 makes 3 in all).",
                    "items": {"type": "object", "properties": {
                        "target_id": {"type": "string"},
                        "weapon_id": {"type": "string", "description": "only for a second weapon (the off hand)"},
                        "unaware": {"type": "boolean"}, "defense": DEFENSE_FIELD,
                        "defense_edge": EDGE_FIELD, "soak_edge": EDGE_FIELD}, "required": ["target_id"]}},
           "edge": EDGE_FIELD, "defense_edge": EDGE_FIELD, "soak_edge": EDGE_FIELD},
          ["attacker_id", "target_id", "reason"]),
    _tool("fight", "Start a fight BEFORE the first attack, so the engine can roll Initiative (narrate the opening "
          "beat in that order). Each 10 of a fighter's Initiative is one Action Phase a round - one attack, spell or "
          "grenade - and one of your turns is one round. zones: 2-5 areas of the place, each with cover none/"
          "light/hard and the zones it touches; positions: who starts where; ambushers: the side springing an ambush "
          "(their targets roll Reaction + Intuition (3), +3 if they saw it coming, or are caught flat-footed: -10 "
          "Initiative, and they can't dodge until they act); hostile: the runners' enemies when it isn't an ambush - "
          "never bystanders. While a fight is on, call start again for newcomers (reinforcements, a second ambush): "
          "whoever it names who isn't in the fight yet joins this round and rolls for surprise - never a new fight. "
          "action end (with how) closes it - only once it's over.",
          {"action": {"type": "string", "enum": ["start", "end"]},
           "zones": {"type": "array", "items": {"type": "object", "properties": {
               "name": {"type": "string"}, "cover": {"type": "string", "enum": ["none", "light", "hard"]},
               "near": {"type": "array", "items": {"type": "string"}}}, "required": ["name"]}},
           "positions": {"type": "array", "items": {"type": "object", "properties": {
               "id": {"type": "string"}, "zone": {"type": "string"}}, "required": ["id", "zone"]}},
           "ambushers": {"type": "array", "items": {"type": "string"}},
           "hostile": {"type": "array", "items": {"type": "string"}},
           "how": {"type": "string"}}, ["action"]),
    _tool("apply_damage", "Non-attack harm: falls, fire, toxins, a collapsing floor. resist: body_armor (default), "
          "drain (Willpower + Logic), or none. Never for a cast, summon, banish or thread - those take their own "
          "drain - nor a crash or a ram (the crash tool) or a grenade (explode).",
          {"target_id": {"type": "string"}, "dv": {"type": "integer"},
           "damage_type": {"type": "string", "enum": ["physical", "stun"]},
           "resist": {"type": "string", "enum": list(sr_lite.RESISTS)},
           "ap": {"type": "integer"}, "reason": {"type": "string"}, "edge": EDGE_FIELD,
           "source_id": {"type": "string", "description": "Who caused it, if anyone (the mage whose barrier they rode "
                                                          "into, whoever shoved them off the roof): they count as the "
                                                          "attacker in the fight - and it opens one if none is on. A "
                                                          "person, never a thing; one runner's accident on another "
                                                          "is no fight."}},
          ["target_id", "dv", "damage_type", "reason"]),
    _tool("heal", "Healing, by the book (SR5 p. 205-207). how first_aid: the healer (healer_id) rolls First Aid + "
          "Logic (2) - net hits heal, up to their First Aid rating; once per set of wounds, never after magic; -2 "
          "without a medkit. On someone dying it's the stabilization test, First Aid + Logic (3) - by a medic who's "
          "awake, never the dying one. how rest: natural recovery - Stun by the hour (time = hours, Body + Willpower each), "
          "Physical by the day (time = days, Body x 2 each) once the Stun is gone. how care: anything else the story "
          "gives - a street doc, a hospital bed, a stim patch (boxes 1-12, say what in reason). Magical healing is "
          "the Heal spell (cast): Physical only, once per set of wounds.",
          {"target_id": {"type": "string"}, "how": {"type": "string", "enum": ["first_aid", "rest", "care"]},
           "damage_type": {"type": "string", "enum": ["physical", "stun"]},
           "healer_id": {"type": "string", "description": "first_aid: who's treating them (default: themselves - "
                                                          "never for someone dying: name the medic, who must be "
                                                          "awake)"},
           "time": {"type": "integer", "description": "rest: hours (stun) or days (physical)"},
           "boxes": {"type": "integer", "description": "care only"}, "reason": {"type": "string"}},
          ["target_id", "how", "damage_type", "reason"]),
    _tool("reload", "Reload a character's weapon.",
          {"owner_id": {"type": "string"}, "weapon_id": {"type": "string"}}, ["owner_id", "weapon_id"]),
    _tool("introduce", "Create and track a named NPC, location, item, host or faction (a gang, corp, agency or crew "
          "that acts as a group) - returns its id, or the existing id if that name is already known. present=true "
          "puts it in the current scene (never for a faction). Never for someone already known under another name "
          "(the 'Ration Man' turns out to be Pruett) - that's `name <id>: <new name>` in your <dm> block.",
          {"kind": {"type": "string", "enum": ["npc", "location", "item", "host", "faction", "drone", "vehicle"]},
           "name": {"type": "string"},
           "description": {"type": "string", "description": "Concrete and visual: metatype, look, vibe."},
           "template": {"type": "string", "enum": list(sr_lite.NPC_TEMPLATES),
                        "description": "NPC stat block: " + "; ".join(f"{k} = {v}" for k, v in sr_lite.TEMPLATE_TEXT.items())},
           "model": {"type": "string", "enum": list(machines.MODELS),
                     "description": "Drone/vehicle: the catalog model - SR5's stats, and fitted the way it's met on "
                                    "the street (its usual gun, the autosofts its Pilot runs). A runner buys their "
                                    "own in a shop (a bare frame); introduce one for them only when the story gives "
                                    "them one."},
           "aliases": {"type": "array", "items": {"type": "string"}},
           "owner_id": {"type": "string", "description": "Item: who holds it. Drone/vehicle: whose it is - a runner's, "
                                                         "or the NPC who runs it (the spider's security drones), who "
                                                         "can then drive it with no hack."},
           "rating": {"type": "integer", "description": "Host: 1-12."},
           "nuyen": {"type": "integer", "description": "NPC: cash on hand (e.g. a Johnson's payment)."},
           "present": {"type": "boolean"},
           "district": {"type": "string", "enum": list(geo.GAZETTEER),
                        "description": "Location: the metroplex district or landmark it is in or next to."},
           "near_id": {"type": "string", "description": "Location: a known location it is close to (e.g. where "
                                                         "the party just was)."},
           "bearing": {"type": "string", "enum": list(geo.BEARINGS), "description": "Location: direction from near_id."},
           "distance_m": {"type": "integer", "description": "Location: rough distance from near_id in meters "
                                                            "(a block ~100, across the district ~2000)."}},
          ["kind", "name", "description"]),
    _tool("scene_presence", "Entities entering or leaving the current scene.",
          {"enter": {"type": "array", "items": {"type": "string"}},
           "leave": {"type": "array", "items": {"type": "string"}}}, []),
    _tool("cut_scene", "Start a new scene (new place or time jump) and move the listed entities into it, or resume "
          "an earlier scene with resume_scene_id. Introduce the location first.",
          {"title": {"type": "string"}, "location_id": {"type": "string"},
           "bring_ids": {"type": "array", "items": {"type": "string"}},
           "resume_scene_id": {"type": "integer"}},
          ["title", "bring_ids"]),
    _tool("matrix", "A decker acts in the Matrix. One call per beat: the engine rolls the action AND the host's answer "
          "(Overwatch, alerts, IC waking and hunting). A host is a map of nodes the engine draws (THE MATRIX section "
          "shows it): Entry, hubs, datastores (files), the building's systems (cameras, door locks, alarms, elevators "
          "- the real ones in the building it runs), Comms and the Core. Colors: blue open, green/orange need user "
          "access, red admin. jack_in (host_id, mode ar or vr; access user/admin = a real login they hold - it opens "
          "every node at that level, no rolls) puts them at the Entry. move (node) walks there, free through what's "
          "open to them, stopping at the first locked node. hack (node) cracks a locked node next to them and moves "
          "in - sneaky; brute_force - loud. search: files here, the nodes around, where IC sleeps. data (target_id: a "
          "file; effect copy/edit/wipe) and control (target_id: a device or drone, or node: a devices node like "
          "'Cameras'; effect: loop the feed, unlock, kill the alarm, stop the elevator) walk there if the way is open, "
          "and act - legal: no Overwatch. admin (in the Core; effect: stand down the IC / cancel the alert / reveal "
          "the map, or all) - taking the Core makes them admin. fight (target_id: an IC type in their node); hide "
          "cools Overwatch; jack_out leaves (forced=true when yanked - dumpshock in VR); repair fixes a deck once out. "
          "Only illegal moves (hack, brute_force, fight, hide) feed Overwatch and Patrol IC; failures leave the host "
          "marks on the decker - Track IC needs 2 to find their body. The host launches at most one IC a turn, however "
          "many beats; awake IC hunts them node by node. A cut that "
          "brings the decker along brings the run; a run with 10 turns of no Matrix move and nothing of it in the "
          "narration is over (the packet counts it down) - the engine closes it quietly, and the next jack_in starts "
          "clean. Never decide access, Overwatch, the map or IC yourself.",
          {"decker_id": {"type": "string"},
           "action": {"type": "string", "enum": list(matrix.ACTIONS)},
           "host_id": {"type": "string", "description": "jack_in: the host (introduce it as kind 'host' with a rating) - "
                                                        "the one the player named, or that runs the device they named; "
                                                        "never a harder host they didn't pick."},
           "mode": {"type": "string", "enum": ["ar", "vr"], "description": "jack_in: AR (aware) or hot-sim VR (+2 "
                                                                            "dice, body limp)."},
           "target_id": {"type": "string"},
           "node": {"type": "string", "description": "move/hack/brute_force/control: a node by name ('Records', "
                                                     "'Hub B', 'Cameras', 'Core')."},
           "effect": {"type": "string", "description": "control/data: what they make it do (loop the feed, unlock, "
                                                       "copy, wipe...); admin: stand down / cancel alert / reveal / all."},
           "forced": {"type": "boolean"},
           "access": {"type": "string", "enum": ["user", "admin"],
                      "description": "jack_in only: a real login they already hold - no hacking needed for it."},
           "despite": {"type": "string", "description": "Only when the engine turned this beat away for going into a "
                                                       "host the player didn't name, and their post really does mean "
                                                       "this one: why, in a sentence - it's flagged for the table."},
           "reason": {"type": "string"}, "edge": EDGE_FIELD},
          ["decker_id", "action"]),
    _tool("correct", "Set the record right when you and the table agree the numbers are wrong: a retcon the story "
          "already made that the engine still carries (a dive the table took back, a hook for something that never "
          "happened), or a carry-over that shouldn't be there (a deadline or an NPC's goal a table ruling ruled out, "
          "an NPC built from the wrong stat block). Call it FIRST - before any roll this turn - so the round "
          "plays from the right numbers. One call per change; the table sees a [FIX] card. Not for ordinary play "
          "(hide cools Overwatch, heal heals, transfer_nuyen moves money) and not for taking back recent turns - "
          "that's the table's !undo. what: " + "; ".join(f"{k} = {v}" for k, v in corrections.WHAT.items()) + ".",
          {"target_id": {"type": "string", "description": "the decker, host or NPC - or the H# (hook), A# (agenda) "
                                                          "or Q# / J# (due: a tension's or a job's deadline)"},
           "what": {"type": "string", "enum": list(corrections.WHAT)},
           "value": {"type": "string", "description": "overwatch/deck/alert: the number; trace: off or on; due: off; "
                                                      "template: the template it should be"},
           "reason": {"type": "string", "description": "why, in a sentence the table will read (the retcon, the "
                                                       "carry-over)"}},
          ["target_id", "what", "reason"]),
    _tool("cast", "A magician casts a spell (they must know it). You pick the spell, the Force (1 to Magic x 2; above "
          "Magic is overcasting) and the targets; the engine rolls the casting (the Force caps the hits unless Edge is "
          "pushed), the resistance, the damage or effect, and the drain (physical when the hits beat their Magic). "
          "Direct combat spells do their net hits. Mana spells (Manabolt, Stunbolt, Confusion, Control Actions, "
          "Invisibility, Heal...) don't touch machines. Fireball takes each target's range band like a grenade. "
          "A bolt (Manabolt, Stunbolt, Powerbolt, Lightning Bolt) at several targets splits the casting pool - each "
          "its own roll, Force limit and drain, at most Magic targets; other spells go at one target a cast. In a "
          "fight a cast is one of the caster's Action Phases.",
          {"caster_id": {"type": "string"},
           "spell": {"type": "string", "enum": [s["name"] for s in magic.SPELLS.values()]},
           "force": {"type": "integer"},
           "targets": {"type": "array", "items": {"type": "object", "properties": {
               "id": {"type": "string"},
               "range": {"type": "string", "enum": ["point_blank", "close", "near", "far"],
                         "description": "Fireball only: how far from the blast's center."},
               "aware": {"type": "boolean"},
               "defense": {**DEFENSE_FIELD, "description": "Lightning Bolt: the target's full defense, if declared "
                                                           "(parry, block and dodge are for melee)."}},
               "required": ["id"]}},
           "reason": {"type": "string"},
           "edge": EDGE_FIELD,
           "drain_edge": {**EDGE_FIELD, "description": "The caster's player spends Edge resisting the drain, as they "
                                                       "said it: push (+Edge dice, 6s explode), reroll (the misses "
                                                       "rerolled while the drain still hurts), if_short ('Edge on the "
                                                       "drain if it hurts' - the same, as insurance), or none."}},
          ["caster_id", "spell", "force"]),
    _tool("edge", "A player's Edge outside a roll. burn: a dying or just-killed character burns a point of Edge "
          "rating for good to live - not dead yet (only when their player says so). regain: hand a PC back one Edge "
          "point for a truly great moment (rarely; never past their rating). refresh: Edge points back to full - "
          "when a table ruling says Edge comes back (after a fight, a finished run...) or you grant it; "
          "character_id 'all' for every PC.",
          {"action": {"type": "string", "enum": ["burn", "regain", "refresh"]}, "character_id": {"type": "string"},
           "reason": {"type": "string"}},
          ["action", "character_id"]),
    _tool("end_spell", "A magician drops a sustained spell (or all of them) - the -2 dice per spell goes away.",
          {"caster_id": {"type": "string"}, "spell": {"type": "string"},
           "which": {"type": "string", "description": "Only one casting, when they hold that spell more than once: "
                                                      "who it's on, or its number (#2 - the MAGIC section numbers "
                                                      "Physical Barriers). Omit to drop every casting of it."}},
          ["caster_id"]),
    _tool("spirit", "Conjuring. action summon (spirit_type, force) - the engine rolls the summoning and drain, and "
          "the spirit joins the scene owing services; order (spirit_id, task) - a big job uses one service, at zero it "
          "leaves; banish (spirit_id) - opposed, to drive one off, and it drains like summoning. The spirit itself "
          "acts through the usual tools.",
          {"caster_id": {"type": "string"}, "action": {"type": "string", "enum": ["summon", "order", "banish"]},
           "spirit_type": {"type": "string", "enum": list(magic.SPIRITS)}, "force": {"type": "integer"},
           "spirit_id": {"type": "string"}, "task": {"type": "string"}, "reason": {"type": "string"}},
          ["caster_id", "action"]),
    _tool("astral", "A magician shifts to the astral: perceive (sees auras, spirits, magic; -2 to mundane tests) or "
          "project (leaves the body limp and helpless), or return.",
          {"character_id": {"type": "string"}, "mode": {"type": "string", "enum": list(magic.ASTRAL)}},
          ["character_id", "mode"]),
    _tool("thread", "A technomancer threads a complex form (they must know it) while jacked in. Pick the form and a "
          "Level (1 to Resonance x 2; the Level caps the hits, and the fading is physical when the hits beat their "
          "Resonance); the engine rolls Software + Resonance, "
          "the effect, the fading, and the host's answer. Resonance Spike hits active IC (target: its type) or a drone; "
          "Puppeteer seizes a device with no access (loud); Cleaner lowers Overwatch; Editor copies/rewrites a file; "
          "Static Veil and Infusion of Firewall are held (-2 dice each) until released.",
          {"techno_id": {"type": "string"},
           "form": {"type": "string", "enum": [f["name"] for f in resonance.FORMS.values()]},
           "level": {"type": "integer"}, "target_id": {"type": "string"}, "effect": {"type": "string"},
           "reason": {"type": "string"}},
          ["techno_id", "form", "level"]),
    _tool("release_form", "A technomancer lets go of a held complex form (or all of them).",
          {"techno_id": {"type": "string"}, "form": {"type": "string"}}, ["techno_id"]),
    _tool("sprite", "Technomancer sprites. compile (sprite_type, level): Compiling + Resonance vs the Level - net hits "
          "are tasks owed; task (sprite_id, task, target_id): crack = +Level dice on the owner's next Matrix action, "
          "fault = strikes active IC (target: its type), data = finds the host's files and IC, machine = takes a "
          "device (target_id), courier = narrative; each task uses one; decompile (sprite_id) to unravel one.",
          {"techno_id": {"type": "string"}, "action": {"type": "string", "enum": ["compile", "task", "decompile"]},
           "sprite_type": {"type": "string", "enum": list(resonance.SPRITES)}, "level": {"type": "integer"},
           "sprite_id": {"type": "string"}, "task": {"type": "string"}, "target_id": {"type": "string"},
           "reason": {"type": "string"}},
          ["techno_id", "action"]),
    _tool("explode", "A grenade or explosive goes off. You choose who is how close and what kind of space; the engine "
          "rolls the throw, the dives, the blast and the soak. Never compute blast damage yourself. In a fight, "
          "throwing or setting it off is one of the holder's Action Phases. A drone carrying grenades drops or throws "
          "them as the holder (thrown=true rolls its Pilot + Targeting). Smoke (smoke or thermal smoke grenade) hurts "
          "nobody: give zone (or a target to put it on) and the engine puts heavy smoke there for about 4 rounds - "
          "-6 to attacks into, out of, inside or through it (thermographic eyes -3, not through thermal smoke; with "
          "range only the worst counts, p. 173). A CS gas grenade: targets are whoever breathes it - Body + Willpower "
          "(+2 for a dwarf's toxin resistance) against its Power, the rest as Stun.",
          {"item_id": {"type": "string", "description": "The explosive (from someone's gear)."},
           "holder_id": {"type": "string", "description": "Who threw, dropped or set it off (it leaves their gear)."},
           "zone": {"type": "string", "description": "Smoke: the fight zone it fills - one of the fight's zones by "
                                                     "name (none given: the first target's, else the holder's)."},
           "thrown": {"type": "boolean", "description": "True if thrown (Throwing + Agility decides where it lands)."},
           "space": {"type": "string", "enum": list(explosives.SPACE_BONUS),
                     "description": "open ground; a room (+2); tight - a hallway, a van, a vent (+4, chunky salsa)."},
           "targets": {"type": "array", "items": {"type": "object", "properties": {
               "id": {"type": "string"},
               "range": {"type": "string", "enum": list(explosives.BANDS),
                         "description": "point_blank: at their feet; close: a few meters; near: across the room; "
                                        "far: down the street."},
               "aware": {"type": "boolean", "description": "Did they see it coming (they get to dive)?"},
               "cover": {"type": "boolean", "description": "A wall, door frame or corner between them and the "
                                                           "blast (they ducked around it)."},
               "edge": {**EDGE_FIELD, "description": "That target's player spends Edge on their soak."}},
               "required": ["id", "range"]}},
           "reason": {"type": "string"}},
          ["item_id", "holder_id"]),
    _tool("control_drone", "Give a drone or vehicle a driver - its owner; a crewmate holding the owner's keys (or "
          "being handed them now: owner_hands_over); or a decker/rigger who won an opposed Hacking test against it THIS "
          "turn (that's how you steal one - and the only way an NPC's drone changes hands) - or set controller_id "
          "'autonomous' to let its own Pilot run it (lent keys stay lent). remote = the driver's skill + Logic, -2 for "
          "each other machine they run there; jumped = skill + Reaction + control rig - one machine at a time, their "
          "body goes limp, and they feel its hits. The card compares the driver's dice with its own Pilot's: leave it "
          "autonomous unless the driver rolls more. A player's character takes the controls only when their player "
          "says so. The owner taking the controls back takes the keys back too.",
          {"drone_id": {"type": "string"}, "controller_id": {"type": "string"},
           "mode": {"type": "string", "enum": list(machines.MODES)},
           "owner_hands_over": {"type": "boolean", "description": "The owner gives controller_id the keys (SR5 Invite "
                                "Mark / the owner's permission, p. 240-241) - only a runner's machine, and only when "
                                "the owner says so: a player's character on their player's word this turn, a character "
                                "you play on yours. If the one taking it is a player's character whose player hasn't "
                                "posted, they get the keys and take the controls when they say so. The keys stand "
                                "until the owner takes the controls back."}},
          ["drone_id", "controller_id"]),
    _tool("crash", "A drone or vehicle crashes or rams - the engine does the damage by the book (SR5 p. 201-203); "
          "never apply_damage with a DV you pick. Everyone it can hurt must be on file first: introduce unnamed riders "
          "(a group of riders may be one entity). Neither into_id nor barrier_of: it crashes (lost control, a wall, a "
          "pole, a dumpster - anything that's no one) - the vehicle and everyone aboard take its Body (Stun if their "
          "armor is over it). into_id: it rams a person, drone or vehicle - the driver's Piloting + Reaction against "
          "their dodge, for the vehicle's Body times its speed band (a fight's Action Phase for the driver). "
          "barrier_of: it hits that magician's Physical Barrier (a visible, shimmering wall - riders who see it can "
          "try to stop) - the wall resists and may collapse (the spell ends); if it holds, the vehicle stops dead and "
          "everyone aboard crashes. With driver_id it's rammed on purpose: the driver's roll, unopposed, adds its hits "
          "to the damage (SR5 p. 197; an Action Phase in a fight) - leave driver_id out when they couldn't stop. Edge: "
          "edge (the driver's player, on the ram roll), defense_edge / soak_edge (the rammed one's player), each "
          "rider's own on their soak.",
          {"vehicle_id": {"type": "string", "description": "The drone or vehicle on file (it takes damage too)."},
           "model": {"type": "string", "enum": list(machines.MODELS),
                     "description": "Instead of vehicle_id, for one that isn't on file (a ganger's bike: scorpion)."},
           "riders": {"type": "array", "description": "Everyone aboard, the driver first.",
                      "items": {"type": "object", "properties": {
                          "id": {"type": "string"},
                          "edge": {**EDGE_FIELD, "description": "That rider's player spends Edge on their soak."}},
                          "required": ["id"]}},
           "speed_kph": {"type": "integer", "description": "How fast it was going, km/h (mph x 1.6) - a ram's damage "
                                                           "goes by it (up to 12 km/h: Body / 2; 60: Body; 240: x2)."},
           "into_id": {"type": "string", "description": "A ram: the person, drone or vehicle it hits - never a "
                                                        "place or a thing (that's a plain crash, no into_id)."},
           "barrier_of": {"type": "string", "description": "The magician holding the Physical Barrier it hits."},
           "barrier": {"type": "string", "description": "Only when that magician holds more than one Physical "
                                                        "Barrier: which wall it hits - its number in the MAGIC "
                                                        "section (#2) or who it's on. The others aren't touched."},
           "driver_id": {"type": "string", "description": "A ram: who's at the controls - the rider driving it "
                                                          "(Piloting + Reaction), or the rigger running the drone "
                                                          "remotely or jumped in (their pool through it - the same as "
                                                          "leaving it out). Leave it out for a drone on its own Pilot. "
                                                          "With barrier_of: only when they ram the wall on purpose "
                                                          "(their hits add to the damage)."},
           "defense": {**DEFENSE_FIELD, "description": "A ram: the target's full defense or dodge, if declared (no "
                                                       "parry or block against a vehicle)."},
           "edge": {**EDGE_FIELD, "description": "A ram's roll (into_id, or a barrier rammed on purpose): the "
                                                 "driver's player spends Edge, as they said it - the rigger's when "
                                                 "a drone they run rams. Riders' soaks take theirs in riders."},
           "defense_edge": {**EDGE_FIELD, "description": "A ram: the rammed one's player spends Edge on their "
                                                         "dodge."},
           "soak_edge": {**EDGE_FIELD, "description": "A ram: the rammed one's player spends Edge on their soak."},
           "source_id": {"type": "string", "description": "Who caused a crash, if anyone (the decker who seized the "
                                                          "bike, whoever shot out the tires) - they count as the "
                                                          "attacker. A barrier's magician counts by themselves."},
           "reason": {"type": "string"}},
          ["reason"]),
    _tool("transfer_item", "Move an item between holders (stealing, buying, handing over). Into a drone or vehicle: "
          "grenades, mounts and autosofts are fitted and a gun handed to a drone goes on a free mount; anything else "
          "rides as cargo (loot in the van, a datachip on a courier drone, a rifle in the trunk - mount_weapon fits a "
          "gun on a vehicle). Gear still on its way can't be handed over until it arrives.",
          {"item_id": {"type": "string"}, "from_id": {"type": "string"}, "to_id": {"type": "string"},
           "qty": {"type": "integer"}}, ["item_id", "from_id", "to_id"]),
    _tool("transfer_nuyen", "Move money. from_id/to_id may be 'world' for money entering or leaving play "
          "(max 25,000 per call from the world).",
          {"from_id": {"type": "string"}, "to_id": {"type": "string"}, "amount": {"type": "integer"},
           "reason": {"type": "string"}}, ["from_id", "to_id", "amount", "reason"]),
    _tool("clarify", "Rewrite your current picture (C#) of one node - an NPC, place, item, turn, fact or tension - "
          "as of now: everything still true or pending (secrets, promises, debts, deadlines, attitudes). It replaces "
          "the old picture and folds the notes before it, so write the whole picture, not just the change.",
          {"id": {"type": "string"}, "text": {"type": "string"}}, ["id", "text"]),
    _tool("annotate", "Private DM note attached to one or more nodes (entity, T#, S#, F#). Never shown to players.",
          {"target_ids": {"type": "array", "items": {"type": "string"}}, "text": {"type": "string"}},
          ["target_ids", "text"]),
    _tool("open_shop", "Stock a shop from the gear catalog (SR5's own prices and Availability: a number, R "
          "restricted, F forbidden): pick 4-12 items that fit it and a markup (0.8 used/cheap, 1.0 retail, 1.3-1.5 "
          "black market or no questions asked). A place the runners visit (gun shop, pawnshop, street doc, "
          "talismonger, a fixer's back room): location_id is that place. An online dealer or a fixer on the phone: "
          "remote=true on the DEALER's own entity (their place, or the fixer - introduce them first), never the room "
          "the runners are in; it's listed in this scene and everything comes by courier. legal=true for an "
          "above-board store: it can't stock Forbidden gear. Restricted or forbidden items at a shop that isn't legal "
          "take the dealer's search now - contact_id's Negotiation + Charisma (the fixer or dealer NPC; a shop on an "
          "NPC is theirs) against the Availability, +1 die for each 25% of markup - and that sets when each arrives; "
          "nothing fails at the checkout. The engine sets prices and stock and players see it with !shop. Cyberware "
          "(Augmentations) only at a street doc or clinic - it's installed there. Drones are sold as bare frames: "
          "mounts, autosofts and guns are their own items. Catalog (key (name, nuyen, Availability)): "
          + _SHOP_CATALOG,
          {"location_id": {"type": "string", "description": "the shop's place - or, remote, the dealer's own entity"},
           "name": {"type": "string", "description": "the shop's name"},
           "kind": {"type": "string", "description": "e.g. 'pawnshop', 'street doc', 'gun shop', 'online drone dealer'"},
           "items": {"type": "array", "items": {"type": "string"}, "description": "catalog keys"},
           "markup": {"type": "number"},
           "prices": {"type": "array", "description": "Items priced or stocked apart from the rest (a refurb discount, "
                                                      "an under-the-counter gun) - each also in items.",
                      "items": {"type": "object", "properties": {"key": {"type": "string"},
                                                                 "markup": {"type": "number"},
                                                                 "stock": {"type": "integer"}}, "required": ["key"]}},
           "legal": {"type": "boolean", "description": "An above-board, licensed store: no Forbidden gear."},
           "remote": {"type": "boolean", "description": "An online dealer or a fixer's call: on the dealer's entity, "
                                                        "delivered by courier."},
           "contact_id": {"type": "string", "description": "The fixer or dealer NPC who finds the restricted gear "
                                                           "(their Negotiation + Charisma rolls the search)."}},
          ["location_id", "name", "kind", "items"]),
    _tool("buy", "A runner buys something from a shop open to them - where they're standing, or a remote dealer "
          "listed in this scene (shop_id: that dealer, from anywhere). The engine checks the stock and their nuyen, "
          "charges them and delivers: off the shelf at once; from a remote dealer, or a restricted item the dealer had "
          "to find, it's held in transit and usable when the story clock gets there (the card says when, coarsely - "
          "narrate the courier then). Cyberware is installed (on arrival, if it's delivered); drones come as bare "
          "frames. onto_id: straight onto a drone or vehicle the buyer owns, drives or holds the keys to - a gun on a "
          "free mount, grenades aboard, a weapon mount, an autosoft (the engine checks the room). A player's "
          "character buys only on their player's word this turn.",
          {"buyer_id": {"type": "string"}, "item": {"type": "string", "description": "catalog key or the shop's item"},
           "qty": {"type": "integer"}, "shop_id": {"type": "string", "description": "The shop's entity (a remote "
                                                                                    "dealer's) when it isn't the one "
                                                                                    "where they stand."},
           "onto_id": {"type": "string", "description": "A drone or vehicle of theirs it goes straight onto."}},
          ["buyer_id", "item"]),
    _tool("mount_weapon", "Fit a drone or vehicle - its owner, driver or a keyholder (by_id) does it from their own "
          "gear: a gun onto a free weapon mount (a standard mount holds an assault rifle or smaller; a machine gun "
          "needs a heavy one, which takes two slots - a machine has its book Body / 3 slots, the Roto-drone 2, SR5 p. "
          "461), a mount item, an autosoft (half its Pilot, rounded up), or grenades aboard (no mount: it drops or "
          "throws them - explode with the drone as holder). unmount=true takes it back off to by_id. Anything a drone "
          "fires or drops has to be in its holdings - this, or buy onto_id.",
          {"drone_id": {"type": "string"}, "item_id": {"type": "string"},
           "by_id": {"type": "string", "description": "Who does it (owner, driver or keyholder); defaults to the owner."},
           "unmount": {"type": "boolean"}, "qty": {"type": "integer", "description": "grenades: how many (default all)"}},
          ["drone_id", "item_id"]),
    _tool("establish_fact", "Record public canon established in play so it stays consistent. If it makes an "
          "existing fact untrue (debt paid, deal broken), pass that fact's id as replaces_id - the old fact is "
          "superseded, not deleted.",
          {"about_ids": {"type": "array", "items": {"type": "string"}}, "text": {"type": "string"},
           "replaces_id": {"type": "string"}},
          ["about_ids", "text"]),
    _tool("update_art", "Someone's or something's appearance changed visibly and lastingly (a lost eye, new "
          "cyberware, a fresh scar, a burned-out bar, a cracked deck). Edits their existing picture so they keep "
          "their identity. Rare - only for changes worth seeing.",
          {"entity_id": {"type": "string"}, "change": {"type": "string", "description": "What visibly changed."}},
          ["entity_id", "change"]),
    _tool("merge_entities", "Two tracked entities are actually the same person/place/thing (a duplicate). Fold "
          "drop_id into keep_id: memories, links, gear and notes move over, the name becomes an alias.",
          {"keep_id": {"type": "string"}, "drop_id": {"type": "string"}, "reason": {"type": "string"}},
          ["keep_id", "drop_id", "reason"]),
]

WORLD_CAP = 25_000


class MatrixAsk(NamedTuple):
    """One Matrix target a post named (turn.matrix_asks) - what _matrix_target_check holds a decker's dive to."""
    who: str                      # whose post (their character's name)
    words: str                    # the words that named it, for the GM
    decker: str | None = None     # whose dive: a decker the post names, else the poster's own; None - the table's
    host: str | None = None       # a host it goes after (by name, the short way, or through a file or device it holds)
    rating: int | None = None     # ... or the rating it gives the target ("the rating 3 system cameras")
    avoid: bool = False           # the host is one it rules out ("skips the Larkspur host - too hot")
    turn: int | None = None       # named on an earlier turn and held (turn.MATRIX_CARRY); None - this turn's


@dataclass
class TurnContext:
    game: object
    turn_id: int
    scene_id: int
    cards: list[str] = field(default_factory=list)       # roll/damage cards shown to players
    events: list[str] = field(default_factory=list)      # one-line record of each tool effect (for commit)
    expanded: set[str] = field(default_factory=set)      # what the DM chose to look at (touch origins)
    introduced: list[str] = field(default_factory=list)
    scene_changed: int | None = None                     # scene id we cut away from
    steps: int = 0                                       # DM model calls this turn
    research_steps: int = 0                              # of them, the free ones: every call a lookup (turn._dm_loop)
    research_calls: int = 0                              # lookups this turn (capped: models.dm_research_calls)
    seen: dict = field(default_factory=dict)             # what lookups showed the GM, in order (an ordered set): memory-
                                                         # pass candidates, never touched - shown isn't used (§8)
    tool_names: list[str] = field(default_factory=list)
    tool_errors: int = 0
    hacks: set = field(default_factory=set)              # (actor, machine) pairs that won a hack this turn
    private: str | None = None                           # a whisper: who sent it (the scene can't move on)
    clock_set: bool = False                              # the DM set the time outright this turn
    tensions_touched: set = field(default_factory=set)   # Q# the DM moved this turn (releases their pressure)
    ooc: bool = False                                    # the GM marked a whisper as an out-of-character answer
    hands_off: list = field(default_factory=list)        # human-played characters whose player didn't post this turn
    posted: set = field(default_factory=set)             # ids of the characters whose players posted this turn (their
                                                         # word: lending a drone, taking its controls - turn.posted)
    guarded: bool = False                                # the GM was already sent back once for writing for them
    rolled: set = field(default_factory=set)             # who rolled this turn (actors, attackers, casters, deckers...)
    roll_asks: dict = field(default_factory=dict)        # {pc id: (name, what their player said)} - asked for a roll
    calls: list = field(default_factory=list)            # the rolls the players called, read whole (calls.Call): who
                                                         # leads, the skill, the helpers - held before and after the dice
    call_sendbacks: int = 0                              # narrations past a called roll sent back (calls.SEND_BACKS)
    spoiler_sent: bool = False                           # a narration saying a GM-only name was sent back (spoilers.py)
    unplaced: list = field(default_factory=list)         # <dm> entries the record couldn't take (no one on file...)
    held: list = field(default_factory=list)             # <dm> lines naming someone not on file yet: they wait for
                                                         # the memory pass, which may put them on file (live T8)
    edge_asks: dict = field(default_factory=dict)        # {pc id: (name, mode or None, the words)} - called Edge
    edge_settled: set = field(default_factory=set)       # PCs whose called Edge rode a roll, or who were refused once
    matrix_asks: list = field(default_factory=list)      # [MatrixAsk] - the Matrix targets the players named, this turn
                                                         # or held from the last few (turn.matrix_asks)
    matrix_settled: set = field(default_factory=set)     # deckers whose jack-in went to it, or went through flagged
    matrix_turned: dict = field(default_factory=dict)    # {decker: Matrix beats turned away this turn for the target}
    clock_start: int | None = None                       # story time when the turn began (what passed: bleed, rest)
    refused: set = field(default_factory=set)            # turned away for having no Action Phase left: their called
                                                         # roll is answered (the roll guard doesn't loop on it)
    by: str = "gm"                                       # who is writing to the record: gm (a turn), canon, aside -
                                                         # a doubt it raises or settles says so (doubts.BY)
    for_table: bool = False                              # the aside: its answer is posted to the whole table, so its
                                                         # lookups reach only what the table has seen (research.hidden)
    asker: str | None = None                             # ... and the asking player's character: their own whispers too


def _card(ctx: TurnContext, card: str) -> str:
    ctx.cards.append(card)
    ctx.game.out(card)
    return card


def _id(ctx: TurnContext, ref: str) -> str:
    return ctx.game.ledger.require(ref)["id"]


def _open_fight(ctx: TurnContext, reason: str) -> str:
    """The engine opens the fight an attack (a spell, a grenade, harm someone caused) starts - Initiative first. Returns
    the [FIGHT] card with a newline, for the tool result: live, an attack that opened a fight came back to the GM
    with only the attack card, so the GM never saw the round's budget on the turn it began."""
    _, card = encounters.start(ctx.game, ctx.turn_id, reason=reason)
    if not card:
        return ""
    _card(ctx, card)
    ctx.events.append(card.splitlines()[0])
    return card + "\n"


def _budget(ctx: TurnContext, opened: str, actor: str, targets, hint: str = "") -> dict | None:
    """encounters.action_check for a call that may just have opened the fight (opened: its [FIGHT] card). What needs
    no fight was refused before it opened (encounters.ready); what's left is the dice - a fresh roll the wounds leave
    no phase in. The fight stands then (everyone has rolled), so the refusal carries its card: the GM's result was
    the refusal alone, and it never saw the fight it had started."""
    try:
        return encounters.action_check(ctx.game, actor, targets, ctx.turn_id, hint)
    except encounters.NoActionLeft as exc:
        if not opened:
            raise
        raise encounters.NoActionLeft(f"{exc}\n(The fight is on all the same - the attempt started it:)\n"
                                      f"{opened.rstrip()}", exc.actors) from None


def _with_action(card: str, line: str) -> str:
    """The Action line (encounters.spend_action) goes under the card's head - what the action was and what it cost."""
    if not line:
        return card
    lines = card.split("\n")
    return "\n".join(lines[:1] + [line] + lines[1:])


def _choices(v) -> list[str]:
    """A defense field as given - one word or a list."""
    if not v:
        return []
    return [str(x).strip().lower() for x in ([v] if isinstance(v, str) else v)]


def _their_word(ctx: TurnContext, eid: str) -> bool:
    """Is a choice for eid the GM's to make this turn? A player's character's is their player's - who must have posted
    this turn, wherever the character is (ctx.posted) - and so is an idle PC's (an away player's, or one parked that
    nobody plays): turn.hands_off lists them, and the GM writes none of their choices. A companion's (mode gm) or an
    NPC's is the GM's. Review: an !afk player's Steel Lynx was lent on the GM's word in the same turn the packet
    called its owner hands-off."""
    mode = ctx.game.control_of(eid)
    if mode == "player" or (mode == "idle" and (ctx.game.ledger.get(eid) or {}).get("kind") == "pc"):
        return eid in ctx.posted
    return True


def _take_controls(ctx: TurnContext, drone: dict, cid: str, lend: bool, mode: str) -> str:
    """control_drone with a driver. Live T188 (flags #67-#69): the crew bought drones for Filament to run, and there
    was no way to lend one - the engine said to hack a crewmate's drone. Now the owner can hand over the keys, but only
    on the owner's own word: a player's character's player has to have said so this turn (the GM tried to give Magic's
    Lynx away while only Filament had posted - the table's rule is that each player decides for their own character).
    The one taking the controls decides too; when they're a player's character who didn't post, a handover gives them
    the keys only, and they take the controls when they say so. Mid-fight an owner on the other side lends nothing.
    The rest - a runner's machine only, no hijacker, the owner awake - is machines.set_control's. A taker with a claim
    of their own - the keys, a hack won this turn, the controls already - isn't being lent anything: the flag is
    redundant, and the lending checks don't run (review: Ghost out-hacked Kaz's Doberman, and the flag on top got
    'win an opposed Hacking test against it')."""
    g, L = ctx.game, ctx.game.ledger
    owner = L.get(drone["props"].get("owner") or "")
    c = L.require(cid)
    p = drone["props"]
    lend = lend and not (bool(owner and owner["id"] == cid) or cid in (p.get("delegates") or [])
                         or (cid, drone["id"]) in ctx.hacks or p.get("controller") == cid)
    handing = bool(lend and owner)
    if handing:
        if not _their_word(ctx, owner["id"]):
            raise RulesRefusal(f"{owner['name']}'s player hasn't handed {drone['name']} over - only they can. Ask them "
                               f"(end the turn on {owner['name']}).")
        enc = encounters.active(g)
        so, sc = (encounters.side(g, enc, owner["id"]), encounters.side(g, enc, cid)) if enc else ("", "")
        if so != sc and "neutral" not in (so, sc):
            raise RulesRefusal(f"{owner['name']} is on the other side of this fight from {c['name']} and won't hand "
                               f"{drone['name']} over - win an opposed Hacking test against it.")
    if not _their_word(ctx, cid):
        if handing:                                      # the owner's word stands; the controls wait for theirs
            return (machines.lend(L, ctx.turn_id, drone["id"], cid)
                    + f" - {c['name']} takes the controls when their player says so")
        raise RulesRefusal(f"{c['name']}'s player hasn't taken the controls of {drone['name']} - only they decide what "
                           f"{c['name']} does. Ask them.")
    return machines.set_control(L, ctx.turn_id, drone["id"], cid, mode, ctx.hacks, handed_over=lend)


def _along_note(L, along: list[str]) -> str:
    """The drones that came along with whoever runs them (machines.followers) - so the GM knows they're here, and can
    set one autonomous (control_drone) or send it back out (scene_presence leave) if the story left it behind. Out is
    out: a machine that left a scene stays behind - it doesn't follow its driver again or cost them its -2 until it's
    put back in one (machines.beside)."""
    if not along:
        return ""
    return " (came along with whoever runs them: " + "; ".join(
        f"{m['name']} ({'jumped in' if m['props'].get('control') == 'jumped' else 'remote'}: "
        f"{(L.get(m['props'].get('controller') or '') or {}).get('name')})" for m in (L.require(x) for x in along)) + (
        " - if the story left one behind, scene_presence leave it)")


def _source(ctx: TurnContext, ref: str | None, target: str) -> str | None:
    """apply_damage's source_id as the one the harm counts against in a fight: a fighter (pc, npc, drone, spirit) at
    odds with the target (encounters.at_odds) - else None, the harm nobody's attack. Never in a whisper."""
    if not ref or ctx.private:
        return None
    src = ctx.game.ledger.require(ref)
    if src["kind"] not in encounters.FIGHTERS or not encounters.at_odds(ctx.game, src["id"], target):
        return None
    return src["id"]


def _own_side(g, caster: str, riders: list[str], vehicle: dict | None) -> bool:
    """Is what hit a magician's barrier their own side's - one of their side aboard, or at its controls? Everyone aboard
    rides together, so nobody aboard was attacked: a client in the crew's van that misjudges the team mage's wall is
    the crew's accident too (review: Dr. Calloway, riding with Razor into Ghost's barrier, came out of it marked hostile
    and counted a foe still standing). Only a side the fight or the crew knows - a stranger's mage is no one's side."""
    enc = encounters.active(g)
    mine = encounters.side(g, enc, caster)
    if mine == "neutral":
        return False
    drv = ((vehicle or {}).get("props") or {}).get("controller")
    return any(encounters.side(g, enc, x) == mine for x in riders + ([drv] if drv else []))


def _control_ripple(L, drone: dict, cid: str | None) -> list[str]:
    """Whose Initiative a control change can move: the machine, whoever drove it and whoever takes it, and every other
    machine either of them runs (jumping into one drops another back to remote - machines.set_control)."""
    people = [x for x in (drone["props"].get("controller"), cid) if x]
    ids = [drone["id"], *people]
    for kind in sr_lite.MACHINES:
        ids += [m["id"] for m in L.entities(kind=kind) if m["props"].get("controller") in people]
    return [i for i in dict.fromkeys(ids) if L.get(i)]


def _drop_at(ctx: TurnContext) -> str | None:
    """Where a thrown weapon lands: the scene's place (None when it has none - it then stays on the thrower's sheet)."""
    return (ctx.game.ledger.scene(ctx.scene_id) or {}).get("location_id")


def dispatch(ctx: TurnContext, name: str, args: dict) -> str:
    """Run one tool call; raises LedgerError/KeyError/ValueError for the caller to report."""
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    t = ctx.turn_id

    if name in research.RESEARCH:                        # recall, read_turn, search_memory, timeline (research.py)
        return research.run(ctx, name, args)

    if name == "doubt":                                  # raise / resolve / dismiss (doubts.py)
        return doubts.run(ctx, args)

    if name == "request_test":
        team = calls.team_mods(args.get("modifiers"))
        if team:
            # Decision 3 (the owner, 2026-10-27): helpers roll, and what they add is capped at the leader's skill rating.
            # A flat "teamwork (R8)" +4 skips both (flag #38's probe: 11d6 where the book gave Magic 7 + at most 3).
            raise RulesRefusal(f"'{team[0]}' stands in for teamwork - name the ones pitching in as helpers=[{{'id': "
                               "...}}] instead: each rolls their own pool and every hit adds a die, capped at the "
                               "actor's rating in the skill (SR5 - the table's cap, not a ruling's +4). Nothing was "
                               "rolled.")
        opp = args.get("opposed_by")
        if opp:
            opp = dict(opp, entity_id=_id(ctx, opp["entity_id"]))
        res = sr_lite.request_test(L, g.dice, t, _id(ctx, args["actor_id"]), args.get("skill"), args.get("attribute"),
                                   args.get("threshold"), opp, args.get("modifiers"), args.get("reason", ""),
                                   edge=args.get("edge") or args.get("use_edge"),
                                   helpers=[dict(h, id=_id(ctx, h["id"])) for h in args.get("helpers") or []
                                            if h.get("id")], attributes=args.get("attributes"))
        _card(ctx, res["card"])
        if res["success"] and opp and (args.get("skill") or "").lower() in sr_lite.MATRIX_SKILLS:
            ctx.hacks.add((_id(ctx, args["actor_id"]), opp["entity_id"]))
        ctx.events.append(f"TEST {res['card'].splitlines()[0][7:]} -> {'success' if res['success'] else 'failure'}"
                          f" (net {res['net']:+d}{', glitch' if res['glitch'] else ''})")
        return res["card"]

    if name == "fight":
        if ctx.private:
            raise LedgerError("A whisper can't start or end a fight - do it in the open.")
        if args.get("action") == "end":                  # (a "not over" while a hostile stands: RulesRefusal)
            ok = encounters.request_end(g, args.get("how") or "it's over")
            return "The fight ends after this turn." if ok else "There's no fight on."
        pos = {p["id"]: p["zone"] for p in args.get("positions") or [] if p.get("id") and p.get("zone")}
        enc = encounters.active(g)
        if enc:                                          # newcomers join this round, never a second fight (§6a)
            card = encounters.join(g, t, enc, args.get("zones"), pos, args.get("ambushers"), args.get("hostile"))
            if not card:
                return "The fight is already on - layout updated (nobody new to join)."
            _card(ctx, card)
            ctx.events.append(card.splitlines()[0])
            return card + "\n" + "\n".join(encounters.packet_lines(g, encounters.get(g, enc["id"]))[1:4])
        enc, card = encounters.start(g, t, args.get("zones"), pos, args.get("ambushers"), args.get("reason", "the GM"),
                                     hostile=args.get("hostile"))
        _card(ctx, card)
        ctx.events.append(card.splitlines()[0])
        # (zones, positions and the round's Initiative: live, the GM got the zones alone - packet_lines[1:3] - and never
        # saw who had how many actions on the turn a fight began)
        return card + "\n" + "\n".join(encounters.packet_lines(g, encounters.get(g, enc["id"]))[1:4])

    if name == "attack":
        attacker, target = _id(ctx, args["attacker_id"]), _id(ctx, args["target_id"])
        L.require(target)
        if args.get("finish"):                           # a coup de grace: no roll, and nothing to open a fight over
            more = [_id(ctx, m["target_id"]) for m in args.get("more") or [] if isinstance(m, dict) and m.get("target_id")]
            ids = list(dict.fromkeys([target] + more))
            check = encounters.action_check(g, attacker, ids, t)          # (free once nobody stands against them)
            against = encounters.stands_against(g, attacker)
            for x in ids:                                # (every refusal before anyone dies)
                sr_lite.check_finish(L, attacker, x, against)
            if len(ids) > 1 and check and not check["free"]:
                raise RulesRefusal("A coup de grace on a player's character costs an Action Phase - one target a "
                                   "call when it isn't free: finish each in its own attack call.")
            res = sr_lite.finish(L, t, attacker, target, args.get("weapon_id"), args.get("reason", ""),
                                 against=against, more=ids[1:])
            w = L.find(args["weapon_id"]) if args.get("weapon_id") else None
            card = _with_action(res["card"], encounters.spend_action(
                g, check, sr_lite.ATTACK_ACTION.get((w or {}).get("props", {}).get("skill", "close_combat"), "")))
            if encounters.active(g):
                for x in ids:
                    encounters.note_attack(g, attacker, x, True)
            _card(ctx, card)
            ctx.events.append(f"FINISH {res['card'].splitlines()[0][7:]}; " + "; ".join(
                (f"{L.require(s['target'])['name']} " if len(ids) > 1 else "") + f"target now {s['target_status']}"
                for s in res["strikes"]))
            return card
        more = [dict(m, target_id=_id(ctx, m["target_id"])) for m in args.get("more") or []]
        ids = [target] + [m["target_id"] for m in more]
        # Everything that could turn the attack away goes first, before anything is spent or moves: the weapons,
        # strikes and Edge (plan_strikes), the zones (check_multi), the Action Phase (ready before a fight opens,
        # action_check) - then the step toward the target, the round, the Edge (sr_lite.attack).
        plan = sr_lite.plan_strikes(L, attacker, [
            {"target": target, "weapon_id": args.get("weapon_id"), "defense_edge": args.get("defense_edge"),
             "soak_edge": args.get("soak_edge")}] + [
            {"target": m["target_id"], "weapon_id": m.get("weapon_id") or args.get("weapon_id"),
             "defense_edge": m.get("defense_edge"), "soak_edge": m.get("soak_edge")} for m in more],
            bool(args.get("thrown")), args.get("edge") or args.get("use_edge"))
        skill = plan["skill"]
        # Live T167/T170/T171: a cut on someone already down opened a fight each time - a fresh jump, and step() ended
        # it the same turn ("Hollow Joe went down"), so the GM's real fight call that turn found one 'already on'.
        down = all(sr_lite.condition(L, x) in sr_lite.OUT for x in ids)
        fresh = not ctx.private and not down and not encounters.active(g)
        if fresh:                                        # (a refusal that needs no fight starts none)
            encounters.ready(g, attacker)
        opened = _open_fight(ctx, "first attack") if fresh else ""
        encounters.check_multi(g, attacker, ids, skill, plan["thrown"])
        who = L.require(attacker)["name"]
        check = _budget(ctx, opened, attacker, ids, f" Several strikes in one phase go in ONE attack call: "
                        f"target_id plus `more` ({who}: up to {plan['cap']}"
                        + (f" with {sr_lite.nice(skill)} {plan['rating']}" if plan["rating"] else "") + ").")
        now = check["now_pass"] if check else 1

        def guard(choices):                              # what the fight adds to each defense (encounters.defense_parts)
            return lambda tid, melee: encounters.defense_parts(g, tid, choices, melee, now)
        zone_skill = "throwing" if plan["thrown"] else (skill if args.get("weapon_id") else "unarmed")
        notes, strikes = [], []
        for tid, m in [(target, args)] + [(x["target_id"], x) for x in more]:
            situation, cover, moved = encounters.attack_mods(g, attacker, tid, zone_skill)
            notes += moved
            strikes.append({"target": tid, "weapon_id": m.get("weapon_id") if m is not args else None,
                            "situation": situation, "cover": cover, "defend": guard(_choices(m.get("defense"))),
                            "unaware": bool(m.get("unaware")) or encounters.unaware(g, tid),
                            "defense_edge": m.get("defense_edge"), "soak_edge": m.get("soak_edge")})
        main = strikes[0]
        res = sr_lite.attack(L, g.dice, t, attacker, target, args.get("weapon_id"), args.get("modifiers"),
                             args.get("reason", ""), False, main["situation"], main["cover"],
                             edge=args.get("edge") or args.get("use_edge"), defense_edge=args.get("defense_edge"),
                             soak_edge=args.get("soak_edge"), unaware=main["unaware"], defend=main["defend"],
                             thrown=plan["thrown"], drop_at=_drop_at(ctx), more=strikes[1:])
        card = _with_action(res["card"], encounters.spend_action(g, check, sr_lite.ATTACK_ACTION.get(res["skill"], "")))
        for s in res["strikes"]:
            encounters.note_attack(g, attacker, s["target"], s["hit"])
        if notes:
            card += "\n  [" + "; ".join(dict.fromkeys(notes)) + "]"
        _card(ctx, card)
        tally = "; ".join((f"{L.require(s['target'])['name']} " if len(ids) > 1 else "")
                          + (f"hit, {s['boxes']} boxes" if s["hit"] else "miss")
                          + f"; target now {s['target_status']}" for s in res["strikes"])
        ctx.events.append(f"ATTACK {card.splitlines()[0][7:]} -> {tally}")
        return opened + card

    if name == "apply_damage":
        tid = _id(ctx, args["target_id"])
        # source_id: whose doing it was. Live T171: the barrier crash hurt Garvey with no one behind it, so he never
        # counted as a foe and the fight ended itself with him standing. Someone, not something (an item or a place
        # marked hostile would stand forever), and not a crewmate's accident (at_odds).
        src = _source(ctx, args.get("source_id"), tid)
        opened = ""
        if src and not encounters.active(g) and sr_lite.condition(L, tid) not in sr_lite.OUT:
            opened = _open_fight(ctx, "harm someone caused")
        res = sr_lite.apply_damage(L, g.dice, t, tid, args["dv"], args["damage_type"],
                                   args.get("resist", "body_armor"), int(args.get("ap", 0)), args.get("reason", ""),
                                   args.get("edge"))
        if src:
            encounters.note_attack(g, src, tid, res["boxes"] > 0)
        _card(ctx, res["card"])
        ctx.events.append(f"DAMAGE {args['target_id']} {res['boxes']} boxes -> {res['status']}")
        return opened + res["card"]

    if name == "heal":
        tid, how = _id(ctx, args["target_id"]), args.get("how") or "care"
        if how == "first_aid":
            res = sr_lite.first_aid(L, g.dice, t, _id(ctx, args.get("healer_id") or args["target_id"]), tid,
                                    args["damage_type"], args.get("reason", ""))
        elif how == "rest":
            res = sr_lite.rest(L, g.dice, t, tid, args["damage_type"], args.get("time") or 1, args.get("reason", ""))
        else:
            res = sr_lite.heal(L, t, tid, args["damage_type"], args.get("boxes") or 1, args.get("reason", ""))
        _card(ctx, res["card"])
        ctx.events.append(res["card"])
        return res["card"]

    if name == "reload":
        res = sr_lite.reload(L, t, _id(ctx, args["owner_id"]), args["weapon_id"])
        _card(ctx, res["card"])
        return res["card"]

    if name == "introduce":
        # (a name the table hasn't learned is never on file - someone sealed is filed under what the crew sees, and
        # `name <id>: ...` reveals the rest: spoilers.py, DESIGN.md §12l)
        # Whenever it files someone new - its name, description and aliases alike (review 2026-10-28: an alias was
        # never read, and filed it switched the guard off for that name everywhere; and a name on file as another kind,
        # an outfit's place under the outfit's name, skipped the check while game.introduce filed a new one)
        same = L.find(args.get("name", ""))
        if not (same and same["kind"] == args["kind"]):
            why = spoilers.refuse(g, "\n".join([args.get("name", ""), args.get("description", "")]
                                               + [str(a) for a in args.get("aliases") or []]), "That introduction")
            if why:
                raise RulesRefusal(why)
        eid, created = g.introduce(args["kind"], args["name"], args.get("description", ""), args.get("template"),
                                   args.get("aliases") or (), args.get("owner_id"), args.get("rating"),
                                   args.get("nuyen"), bool(args.get("present")), t,
                                   where={"district": args.get("district"), "near": args.get("near_id"),
                                          "bearing": args.get("bearing"), "distance_m": args.get("distance_m")},
                                   model=args.get("model"))
        if created:
            ctx.introduced.append(eid)
            L.log(t, "introduce", eid, {"kind": args["kind"], "name": args["name"]})
            ctx.events.append(f"INTRODUCED {args['kind']} {args['name']} [{eid}]")
            g.out(f"[NEW] {args['kind']}: {args['name']} [{eid}]")
        return (f"{'Created' if created else 'Already known as'} [{eid}].\n" + sr_lite.sheet(L, eid, full=True))

    if name == "scene_presence":
        enter = [_id(ctx, e) for e in args.get("enter") or []]
        leave = [_id(ctx, e) for e in args.get("leave") or []]
        along = machines.followers(L, enter, ctx.scene_id) if enter else []
        if enter:
            g.enter_scene(enter, t, ctx.scene_id)
        if leave:
            g.leave_scene(leave, ctx.scene_id)
        ctx.events.append(f"PRESENCE enter={enter + along} leave={leave}")
        return (f"Scene S{ctx.scene_id} roster: {', '.join(L.roster(ctx.scene_id))}" + _along_note(L, along)
                + matrix.riding_note(L, enter))

    if name == "cut_scene":
        if ctx.private:
            raise LedgerError("This turn is a whisper - the scene can't cut here. Narrate the private result; "
                              "the next public turn can move the story on.")
        bring = [_id(ctx, e) for e in args.get("bring_ids") or []]
        old = ctx.scene_id
        along = machines.followers(L, bring, int(args.get("resume_scene_id") or 0) or None)  # (g.enter_scene moves them)
        if args.get("resume_scene_id"):
            sid = g.resume_scene(int(args["resume_scene_id"]), bring, t)
        else:
            loc = _id(ctx, args["location_id"]) if args.get("location_id") else None
            sid = g.new_scene(spoilers.scrub(g, args["title"])[0], loc, bring, t)   # (a title is the table's)
        if sid != old:
            ctx.scene_changed = old
            ctx.scene_id = sid
        ctx.events.append(f"CUT to S{sid} '{args['title']}' with {bring + along}")
        g.out(f"[SCENE] S{sid}: {L.scene(sid)['title']}")
        # (a decker brought along still jacked in took the run with them - g.enter_scene, matrix.carry: say so, with
        # the way out if the story logged them off - review 2026-10-27, live T126)
        return (f"Now in scene S{sid}. Roster: {', '.join(L.roster(sid))}" + _along_note(L, along)
                + matrix.riding_note(L, bring))

    if name == "correct":
        target = args["target_id"] if args["what"] in corrections.NODES else _id(ctx, args["target_id"])
        line = corrections.correct(g, t, target, args["what"], args.get("value"), args.get("reason", ""))
        _card(ctx, line)
        ctx.events.append(line)
        return line + " (done - narrate from the corrected numbers)"

    if name == "matrix":
        res = matrix.act(L, g.dice, t, _id(ctx, args["decker_id"]), args["action"],
                         _id(ctx, args["host_id"]) if args.get("host_id") else None,
                         _id(ctx, args["target_id"]) if args.get("target_id") and L.find(args["target_id"])
                         else args.get("target_id"), args.get("mode", "ar"), args.get("effect", ""),
                         args.get("reason", ""), bool(args.get("forced")), args.get("edge"), args.get("access"),
                         args.get("node"))
        _card(ctx, res["card"])
        ctx.events.append(res["card"].splitlines()[0][9:] + (" - TRACED" if res["traced"] else ""))
        if res["traced"]:                                  # the real world finds out: a hook for the DM
            from . import world
            decker = _id(ctx, args["decker_id"])
            host = L.get(res["host"]) if res.get("host") else None
            if host and not g.conn.execute("SELECT 1 FROM hooks h JOIN links l ON (l.a=h.id OR l.b=h.id) "
                                           "WHERE h.npc_id=? AND h.status='ready' AND (l.a=? OR l.b=?)",
                                           (host["id"], decker, decker)).fetchone():
                world.add_hook(g, host["id"], None, f"{host['name']}'s security traced {L.get(decker)['name']}'s "
                                                    "physical location - a response team can be on the way.", [decker], t)
        # The host's look and its IC's, for the GM alone (the card is the players'): a dive here is jack_in, every beat
        # and the narration in one turn, and THE MATRIX section that gives the IC's look is only there from the next
        # turn on - review of flag #35: on the T121-style turn the janitor-bot Patrol IC never reached the GM.
        dress = matrix.dress_lines(L, res["host"]) if args["action"] == "jack_in" and res.get("host") else []
        if dress:
            return res["card"] + "\n(GM only - the cut into the Matrix, as this host sculpts itself:)\n" + "\n".join(dress)
        return res["card"]

    if name == "cast":
        caster = _id(ctx, args["caster_id"])
        targets = [dict(x, id=_id(ctx, x["id"])) for x in args.get("targets") or []]
        # A combat spell at someone is an attack: it opens the fight first and marks who's against whom. Live T175: a
        # Manabolt on Fenn resolved outside any fight, and the fight it should have been part of opened after it.
        # (Not Mind Probe or Control Actions - a probe of a bound prisoner is no fight - and never in a whisper.)
        # Whoever casts it: review - a Crows shaman's Manabolt at Razor opened nothing (only a runner's bolt did), so
        # it cost no Action Phase and marked nobody. Only a bolt between two runners isn't a fight (at_odds).
        key = magic.check_cast(L, caster, args["spell"], targets, args.get("edge"))
        harm = not ctx.private and magic.SPELLS[key]["target"] in magic.HARMFUL
        opened = ""
        if harm and not encounters.active(g) and any(
                encounters.at_odds(g, caster, x["id"]) and sr_lite.condition(L, x["id"]) not in sr_lite.OUT
                for x in targets):
            encounters.ready(g, caster)                  # (a refusal that needs no fight starts none)
            opened = _open_fight(ctx, "a combat spell")
        # In a fight every cast is a Complex Action - one Action Phase, a split bolt included (p. 281) - checked
        # before the dice; a whisper during a fight spends it too (the round is the same round).
        check = _budget(ctx, opened, caster, [x["id"] for x in targets])
        now = check["now_pass"] if check else 1
        choices = {x["id"]: _choices(x.get("defense")) for x in targets}
        boosted = (targets[0]["id"] if targets else caster) if key == "increase reflexes" else None
        before = sr_lite.initiative_rating(L, boosted) if boosted else None
        res = magic.cast(L, g.dice, t, caster, args["spell"], args.get("force") or 0, targets,
                         args.get("reason", ""), args.get("edge"), args.get("drain_edge"),
                         defend=lambda tid, melee: encounters.defense_parts(g, tid, choices.get(tid), melee, now))
        card = _with_action(res["card"], encounters.spend_action(g, check, "Complex: Cast Spell"))
        if res.get("boost") and before:                  # Increase Reflexes mid-fight counts this round (p. 160)
            note = encounters.retune(g, res["boost"]["target"], before, t)
            card += ("\n" + note) if note else ""
        if harm:
            for x in targets:
                encounters.note_attack(g, caster, x["id"], any(r["id"] == x["id"] for r in res["results"]))
        _card(ctx, card)
        ctx.events.append(card.splitlines()[0][7:])
        return opened + card

    if name == "edge":
        action = args.get("action")
        who = "all" if action == "refresh" and str(args["character_id"]).strip().lower() in ("all", "everyone") \
            else _id(ctx, args["character_id"])
        fn = {"burn": sr_lite.burn_edge, "refresh": sr_lite.refresh_edge}.get(action, sr_lite.regain_edge)
        res = fn(L, t, who, args.get("reason", ""))
        _card(ctx, res["card"])
        ctx.events.append(res["card"][7:])
        return res["card"]

    if name == "end_spell":
        caster = _id(ctx, args["caster_id"])
        quick = [h["target"] for h in L.require(caster)["props"].get("sustained") or [] if h["spell"] == "increase reflexes"]
        before = {tid: sr_lite.initiative_rating(L, tid) for tid in quick if L.get(tid)}
        line = magic.end_spell(L, caster, args.get("spell"), t, which=args.get("which"))
        line += "".join("\n" + x for x in (encounters.retune(g, tid, b, t) for tid, b in before.items()) if x)
        _card(ctx, line)
        ctx.events.append(line)
        return line

    if name == "spirit":
        caster = _id(ctx, args["caster_id"])
        if args["action"] == "summon":
            res = magic.summon(L, g.dice, t, caster, args.get("spirit_type", ""), args.get("force") or 0,
                               args.get("reason", ""))
            if res["spirit"]:
                g.enter_scene([res["spirit"]], t, ctx.scene_id)
                ctx.introduced.append(res["spirit"])
            card = res["card"]
        elif args["action"] == "order":
            card = magic.order(L, _id(ctx, args["spirit_id"]), args.get("task", ""))
            if L.get(_id(ctx, args["spirit_id"]))["status"] == "departed":
                g.leave_scene([_id(ctx, args["spirit_id"])], ctx.scene_id)
        else:
            card = magic.banish(L, g.dice, t, caster, _id(ctx, args["spirit_id"]))
            if L.get(_id(ctx, args["spirit_id"]))["status"] == "departed":
                g.leave_scene([_id(ctx, args["spirit_id"])], ctx.scene_id)
        _card(ctx, card)
        ctx.events.append(card.splitlines()[0][7:])
        return card

    if name == "astral":
        who = _id(ctx, args["character_id"])
        before = sr_lite.initiative_rating(L, who)
        line = magic.astral(L, t, who, args["mode"])
        note = encounters.retune(g, who, before, t)      # (projecting: Intuition x 2 + 2D6 from now, p. 160)
        line += ("\n" + note) if note else ""
        _card(ctx, line)
        ctx.events.append(line)
        return line

    if name == "thread":
        target = args.get("target_id")
        if target and L.find(target):
            target = _id(ctx, target)
        res = resonance.thread(L, g.dice, t, _id(ctx, args["techno_id"]), args["form"], args.get("level") or 0,
                               target, args.get("effect", ""), args.get("reason", ""))
        _card(ctx, res["card"])
        ctx.events.append(res["card"].splitlines()[0][9:])
        return res["card"]

    if name == "release_form":
        line = resonance.release(L, _id(ctx, args["techno_id"]), args.get("form"))
        _card(ctx, line)
        return line

    if name == "sprite":
        techno = _id(ctx, args["techno_id"])
        if args["action"] == "compile":
            res = resonance.compile_sprite(L, g.dice, t, techno, args.get("sprite_type", ""), args.get("level") or 0,
                                           args.get("reason", ""))
            if res["sprite"]:
                g.enter_scene([res["sprite"]], t, ctx.scene_id)
            card = res["card"]
        elif args["action"] == "task":
            sid = _id(ctx, args["sprite_id"])
            target = args.get("target_id")
            if target and L.find(target):
                target = _id(ctx, target)
            card = resonance.sprite_task(L, g.dice, t, sid, args.get("task", ""), target)["card"]
            if L.get(sid)["status"] == "departed":
                g.leave_scene([sid], ctx.scene_id)
        else:
            sid = _id(ctx, args["sprite_id"])
            card = resonance.decompile(L, g.dice, t, techno, sid)
            if L.get(sid)["status"] == "departed":
                g.leave_scene([sid], ctx.scene_id)
        _card(ctx, card)
        ctx.events.append(card.splitlines()[0][9:])
        return card

    if name == "explode":
        targets = [dict(x, id=_id(ctx, x["id"])) for x in args.get("targets") or []]
        holder = _id(ctx, args["holder_id"])
        item = L.find(args["item_id"])
        smoke = explosives.cloud((item or {}).get("props") or {}) in explosives.SMOKE
        if smoke:                                        # (a zone it can't find: refused before the can is spent)
            encounters.check_cloud_zone(g, args.get("zone"))
        fresh = not ctx.private and not encounters.active(g) and not smoke        # (smoke harms nobody: no fight)
        ids = [x["id"] for x in targets]
        if fresh:                                        # (a limp body's grenade goes nowhere: before the blast)
            encounters.ready(g, holder)
        check = None if fresh or not encounters.active(g) else encounters.action_check(g, holder, ids, t)
        res = explosives.explode(L, g.dice, t, args["item_id"], holder, targets,
                                 args.get("space", "open"), bool(args.get("thrown")), args.get("reason", ""))
        opened = ""
        if res.get("smoke"):                             # the fight's zone fills (encounters.smoke): -6 from now on
            res["card"] += "\n" + encounters.smoke(g, args.get("zone"), ids[0] if ids else holder, res["smoke"])
            targets = []
        if fresh:                                        # a grenade starts a fight too (the Initiative card first)
            opened = _open_fight(ctx, "an explosion")
            try:                                         # (a fresh row; spent after the blast that opened it)
                check = encounters.action_check(g, holder, ids, t)
            except RulesRefusal:
                check = None
        for x in targets:
            encounters.note_attack(g, holder, x["id"], True)
        card = _with_action(res["card"], encounters.spend_action(
            g, check, "Simple: Throw Weapon" if args.get("thrown") else "Simple: Use Simple Device"))
        _card(ctx, card)
        ctx.events.append("EXPLOSION " + "; ".join(f"{r['id']} {r['band']} {r['boxes']} boxes" for r in res["results"]))
        return opened + card

    if name == "control_drone":
        drone = L.require(_id(ctx, args["drone_id"]))
        raw = str(args.get("controller_id") or "autonomous")
        cid = None if raw.lower() in ("autonomous", "none", "auto") else _id(ctx, raw)
        # Mid-fight a control change moves Initiative at once (p. 160, encounters.retune): the drone's own, its old and
        # new driver's, and any drone of theirs dropped back to remote by a jump - and a rigger jumping in or out takes
        # the actions they've used along (carry_used).
        before = {e: sr_lite.initiative_rating(L, e) for e in _control_ripple(L, drone, cid)}
        was = {p: encounters.acts_from(g, p) for p in (drone["props"].get("controller"), cid) if p and L.get(p)}
        if cid is None:
            line = machines.set_control(L, t, drone["id"], "autonomous")
        else:
            line = _take_controls(ctx, drone, cid, bool(args.get("owner_hands_over")), args.get("mode", "remote"))
        line += "".join("\n" + x for x in (encounters.retune(g, e, b, t) for e, b in before.items()) if x)
        for p, row_was in was.items():
            encounters.carry_used(g, p, row_was)
        _card(ctx, line)
        ctx.events.append(line.splitlines()[0])
        return line

    if name == "crash":
        riders = [dict(r) if isinstance(r, dict) else {"id": r} for r in args.get("riders") or []]
        veh = _id(ctx, args["vehicle_id"]) if args.get("vehicle_id") else None
        caster = _id(ctx, args["barrier_of"]) if args.get("barrier_of") else None
        driver = _id(ctx, args["driver_id"]) if args.get("driver_id") else None
        kph = int(args.get("speed_kph") or 0)
        wall = str(args["barrier"]) if args.get("barrier") not in (None, "") else None
        edges = {k: args.get(k) for k in ("edge", "defense_edge", "soak_edge")}
        c = machines.check_crash(L, veh, args.get("model"), riders, kph, args.get("into_id"), caster, driver, wall,
                                 **edges)
        riders = [dict(r, id=e["id"]) for r, (e, _) in zip(riders, c["aboard"])]
        into, actor = (c["target"] or {}).get("id"), (c["actor"] or {}).get("id")
        src = caster or (_id(ctx, args["source_id"]) if args.get("source_id") else None)
        hurt_ids = [r["id"] for r in riders]
        against = [x for x in hurt_ids if src and encounters.at_odds(g, src, x)]   # (a crewmate's car: no fight)
        if caster and _own_side(g, caster, hurt_ids, c["v"]):
            against = []                                 # (the crew's own van in the crew's own wall, client and all)
        opened, check, now = "", None, 1
        # Everything that could turn it away is checked (check_crash, the Action Phase) before a fight opens or a die
        # is rolled. A ram at someone is an attack - it opens the fight and spends the driver's phase, like attack; a
        # crash someone caused (a barrier's magician, source_id) counts them as the attacker, like apply_damage. A
        # barrier rammed on purpose is an attack on the wall (p. 197): the driver's phase too, but no fight of its own.
        if into and not ctx.private and not encounters.active(g) and sr_lite.condition(L, into) not in sr_lite.OUT:
            encounters.ready(g, actor)                   # (a refusal that needs no fight starts none)
            opened = _open_fight(ctx, "a ram")
        elif against and not into and not ctx.private and not encounters.active(g) and any(
                sr_lite.condition(L, x) not in sr_lite.OUT for x in against):
            if c["ram"]:
                encounters.ready(g, actor)
            opened = _open_fight(ctx, "harm someone caused")
        if c["ram"]:
            check = _budget(ctx, opened, actor, [into] if into else [])
            now = check["now_pass"] if check else 1
        choices = [x for x in _choices(args.get("defense")) if x in ("full", "dodge")]   # (no parry, block: p. 203)
        res = machines.crash(L, g.dice, t, veh, args.get("model"), riders, kph, into, caster, driver,
                             args.get("reason", ""),
                             defend=lambda tid, melee: encounters.defense_parts(g, tid, choices, True, now), which=wall,
                             **edges)
        card = (_with_action(res["card"], encounters.spend_action(g, check, "Complex: Ram")) if c["ram"]
                else res["card"])
        if into:
            encounters.note_attack(g, actor, into, bool(res["hit"]))
        if src and not ctx.private:                      # (every rider, hurt or not: they were up against it)
            boxes = {r["id"]: r["boxes"] for r in res["results"]}
            for rid in against:
                encounters.note_attack(g, src, rid, boxes.get(rid, 0) > 0)
        _card(ctx, card)
        ctx.events.append("CRASH " + card.splitlines()[0].split("] ", 1)[-1] + " -> " + "; ".join(
            f"{L.require(r['id'])['name']} {r['boxes']} boxes, {r['status']}" for r in res["results"]))
        return opened + card

    if name == "transfer_item":
        item = _id(ctx, args["item_id"])
        src, dst, qty = _id(ctx, args["from_id"]), _id(ctx, args["to_id"]), max(1, int(args.get("qty") or 1))
        thing = L.require(item)
        if sr_lite.arriving(thing):                      # (review E2: in-transit chrome handed to Ghost was put in
            raise RulesRefusal(f"{thing['name']} is {sr_lite.transit_note(L, thing)} - nobody has it to hand over "
                               "yet.")                   # him when it came, past the Essence floor)
        for side in (src, dst):                          # (an old bundled drone's mount stays put: settle_mounts)
            if L.require(side)["kind"] in sr_lite.MACHINES:
                machines.settle_mounts(L, L.require(side), t)
        if L.require(src)["kind"] in sr_lite.MACHINES:   # off a drone: a mount with a gun on it stays
            machines.check_unload(L, L.require(src), thing)
        how, cargo = "", False
        if L.require(dst)["kind"] in sr_lite.MACHINES:   # onto a drone: the mounts and slots hold (live: nothing
            how, cargo = machines.stow(L, L.require(dst), thing)      # stopped a sniper rifle on a Fly-Spy); the
        state = L.take(src, item, qty)                                # rest rides as cargo
        state.pop(machines.CARGO, None)
        L.give(dst, item, qty, {**state, machines.CARGO: True} if cargo else state)
        L.log(t, "transfer_item", src, {"item": item, "to": dst, "qty": qty} | ({"cargo": True} if cargo else {}))
        msg = (f"[GEAR] {L.get(item)['name']} x{qty}: {L.get(src)['name']} -> {L.get(dst)['name']}"
               + (f" ({how})" if how else ""))
        _card(ctx, msg)
        ctx.events.append(msg)
        return msg

    if name == "transfer_nuyen":
        amount = int(args["amount"])
        if amount <= 0:
            raise ValueError("amount must be positive")
        src = None if args["from_id"].lower() == "world" else _id(ctx, args["from_id"])
        dst = None if args["to_id"].lower() == "world" else _id(ctx, args["to_id"])
        if src is None and amount > WORLD_CAP:
            raise LedgerError(f"At most {WORLD_CAP:,} nuyen can enter play per call; have an NPC pay instead.")
        if src is not None:
            have = int(L.stat(src, "nuyen"))
            if have < amount:
                raise LedgerError(f"{L.get(src)['name']} only has {have:,} nuyen.")
            L.add_stat(src, "nuyen", -amount)
        if dst is not None:
            L.add_stat(dst, "nuyen", amount)
        L.log(t, "nuyen", src, {"to": dst, "amount": amount, "reason": args.get("reason", "")})
        msg = (f"[NUYEN] {amount:,} : {L.get(src)['name'] if src else 'the world'} -> "
               f"{L.get(dst)['name'] if dst else 'the world'} ({args.get('reason', '')})")
        _card(ctx, msg)
        ctx.events.append(msg)
        return msg

    if name == "clarify":
        ref = args["id"]
        nid = norm_id(ref)
        if not (S.exists(nid) or L.get(nid)):
            ent = L.find(ref)
            if ent is None:
                raise LedgerError(f"Unknown id '{ref}'.")
            nid = ent["id"]
        if L.get(nid):
            S.ensure_entity(L.get(nid), t)
        cid = S.clarify(nid, args["text"], t, by="dm")
        ctx.events.append(f"CLARIFY {cid} on {nid}")
        return f"[{cid}] is now your current picture of {(L.get(nid) or {}).get('name', nid)}."

    if name == "annotate":
        targets = []
        for ref in args["target_ids"]:
            nid = norm_id(ref)
            if S.exists(nid) or L.get(nid):
                targets.append(nid)
            else:
                ent = L.find(ref)
                if ent is None:
                    raise LedgerError(f"Unknown id '{ref}'.")
                targets.append(ent["id"])
        nid = S.add_note(targets, args["text"], t)
        ctx.events.append(f"NOTE {nid} on {targets}")
        return f"Noted as [{nid}] on {', '.join(targets)}."

    if name == "open_shop":
        why = spoilers.refuse(g, f"{args.get('name', '')}\n{args.get('kind', '')}", "That shop")   # (its card's)
        if why:
            raise RulesRefusal(why)
        apart = {str(p.get("key", "")).strip().lower(): p for p in args.get("prices") or [] if isinstance(p, dict)}
        items = [dict(apart[k.strip().lower()], key=k) if isinstance(k, str) and k.strip().lower() in apart else k
                 for k in args.get("items") or []]
        items += [p for k, p in apart.items() if k not in {str(i).strip().lower() for i in args.get("items") or []}]
        contact = _id(ctx, args["contact_id"]) if args.get("contact_id") else None
        shop, skipped = _shops.stock(g, _id(ctx, args["location_id"]), args.get("name", ""), args.get("kind", ""),
                                     items, args.get("markup") or 1.0, t, legal=bool(args.get("legal")),
                                     remote=bool(args.get("remote")), contact_id=contact)
        ctx.events.append(f"SHOP stocked at {args['location_id']}{' (remote)' if shop['remote'] else ''}: "
                          f"{', '.join(shop['items'])}")
        found = _shops.search_lines(g, shop)
        return (f"{shop['name']} stocked: " + "; ".join(f"{k} {v['price']}¥ x{v['stock']}" for k, v in shop["items"].items())
                + (f". Skipped: {', '.join(skipped)}" if skipped else "")
                + ("\nThe dealer's searches (Availability, SR5 p. 418):\n" + "\n".join(found) if found else "")
                + ("\nListed in this scene: the runners here can !shop it; buy with shop_id from anywhere later."
                   if shop["remote"] else ""))

    if name == "buy":
        buyer = _id(ctx, args["buyer_id"])
        if not _their_word(ctx, buyer):                  # (their money, their call - like a drone's keys, §7a)
            raise RulesRefusal(f"{L.require(buyer)['name']}'s player hasn't bought that - only they spend "
                               f"{L.require(buyer)['name']}'s nuyen. Ask them.")
        res = _shops.buy(g, buyer, args["item"], int(args.get("qty") or 1), t,
                         shop_id=_id(ctx, args["shop_id"]) if args.get("shop_id") else None,
                         onto=args.get("onto_id") or None)
        _card(ctx, res["card"])
        ctx.events.append(res["card"])
        return res["card"]

    if name == "mount_weapon":
        drone = L.require(_id(ctx, args["drone_id"]))
        by = _id(ctx, args["by_id"]) if args.get("by_id") else (drone["props"].get("owner") or "")
        if not by:
            raise LedgerError(f"{drone['name']} has no owner on file - say who fits it (by_id).")
        if not _their_word(ctx, by):
            raise RulesRefusal(f"{L.require(by)['name']}'s player hasn't fitted {drone['name']} - only they decide "
                               f"what {L.require(by)['name']} does with their gear. Ask them.")
        line = machines.mount_weapon(L, t, drone["id"], args["item_id"], by, bool(args.get("unmount")),
                                     args.get("qty"))
        _card(ctx, line)
        ctx.events.append(line)
        return line

    if name == "establish_fact":
        why = spoilers.refuse(g, args["text"], "That fact")       # (public canon: no name the table hasn't learned)
        if why:
            raise RulesRefusal(why)
        about = [_id(ctx, a) for a in args["about_ids"]]
        for a in about:
            S.ensure_entity(L.get(a), t)
        fid = S.add_fact(args["text"], about, t, replaces=args.get("replaces_id") or None, confidence=0.9, by="dm")
        ctx.expanded.add(fid)
        ctx.events.append(f"FACT {fid}: {args['text']}")
        rep = S.superseded_by(norm_id(args["replaces_id"])) if args.get("replaces_id") else None
        return f"Recorded as [{fid}]." + (f" [{norm_id(args['replaces_id'])}] is now superseded." if rep == fid else "")

    if name == "update_art":
        eid = _id(ctx, args["entity_id"])
        if not g.art.active:
            return "Art is off for this campaign; noted nothing."
        # (the table reads the change on the new picture's card, and its caption is written from it: §12l)
        change = spoilers.answer(g, args["change"], "An art change", t, "scrubbed before the picture was made")
        how = g.request_art(eid, force=True, direction=change)
        ctx.events.append(f"ART {eid}: {change} ({how})")
        return f"Art update for [{eid}]: {how}. It arrives in the background."

    if name == "merge_entities":
        msg = g.merge_entities(args["keep_id"], args["drop_id"], t)
        ctx.events.append(f"MERGE {msg}")
        g.out(f"[MERGE] {msg}")
        return msg

    raise ValueError(f"Unknown tool '{name}'.")


ROLLERS = {"request_test": ("actor_id",), "attack": ("attacker_id", "target_id"), "cast": ("caster_id",),
           "matrix": ("decker_id",), "thread": ("technomancer_id", "techno_id"), "spirit": ("caster_id", "summoner_id"),
           "explode": ("holder_id", "thrower_id"), "apply_damage": ("target_id",), "edge": ("character_id", "id"),
           "crash": ("driver_id", "into_id")}
# Rolls that ride on how a tool is called: First Aid is the healer's (or the patient's own) First Aid + Logic; a
# compile or decompile is the technomancer's. Review of P3: neither counted as anyone's roll, so a bandage or a sprite
# the player called was sent back and the bandage rolled again by the engine.
ROLLS_IF = {"heal": (lambda a: a.get("how") == "first_aid", ("healer_id", "target_id")),
            "sprite": (lambda a: a.get("action") in ("compile", "decompile"), ("techno_id",))}


def _rollers(name: str, args: dict, L=None) -> list[str]:
    """Who rolled in a tool call, by ref: the ROLLERS fields, every further strike's target (their dodge), everyone
    aboard a crash (their soak - not in a ram, where the rammer's riders aren't hit), and the machine that rams with
    nobody named at the wheel. With the ledger (L), a machine someone runs remotely or is jumped into brings its
    driver too: its pool is their skill (sr_lite.machine_pool). Review: Ghost's Roto-drone rammed Joey on Ghost's
    Piloting + Logic and Ghost's action, and the roll guard sent the GM back for the roll Ghost's player asked for."""
    refs = [args.get(key) for key in ROLLERS.get(name, ())]
    if name in ROLLS_IF:                                 # (the first named: a healer_id, else the patient's own aid)
        rolls, keys = ROLLS_IF[name]
        refs = [next((args.get(k) for k in keys if args.get(k)), None)] if rolls(args) else []
    if name == "attack":
        refs += [m.get("target_id") for m in args.get("more") or [] if isinstance(m, dict)]
    if name == "crash":
        if not args.get("into_id"):
            refs += [r.get("id") if isinstance(r, dict) else r for r in args.get("riders") or []]
        if not args.get("driver_id") and args.get("into_id"):
            refs.append(args.get("vehicle_id"))
    refs = [str(r) for r in refs if r]
    if L is not None:
        for ref in list(refs):
            m = L.find(ref)
            p = (m or {}).get("props") or {}
            if m and m["kind"] in sr_lite.MACHINES and p.get("controller") and p.get("control") in machines.MODES:
                refs.append(p["controller"])
    return list(dict.fromkeys(refs))


# The Edge fields that ride on each roll tool, by whose roll it is: an attack's dodge and soak are the target's rolls,
# so their Edge is the target's player's. (thread, spirit and a grenade's throw take no Edge - nothing to check.)
EDGE_ROLLS = {"request_test": (("actor_id", ("edge", "use_edge")),),
              "attack": (("attacker_id", ("edge", "use_edge")), ("target_id", ("defense_edge", "soak_edge"))),
              "cast": (("caster_id", ("edge", "drain_edge")),),
              "matrix": (("decker_id", ("edge",)),),
              "apply_damage": (("target_id", ("edge",)),)}
EDGE_ON = {"edge": "the casting", "drain_edge": "the drain", "defense_edge": "the dodge", "soak_edge": "the soak",
           "riders.edge": "their soak, in riders", ("crash", "edge"): "the ram"}
# Edge fields that ride a defensive roll - a dodge, a soak, drain: there a called reroll and insurance are one thing
DEFENSIVE_EDGE = ("drain_edge", "defense_edge", "soak_edge", "riders.edge")


def _rolls_nothing(L, name: str, args: dict) -> bool:
    """A call that rolls no dice the Edge could ride: a coup de grace, unresisted damage, a smoke grenade (a cloud,
    no soak), a Matrix beat that rolls nothing (matrix.edge_rides: jack_in, move, admin...). Checking one would spend
    the one reminder on a no-op - review: a decker's jack_in was refused, and the hack the Edge was called for then
    went out without it, unchecked (the T164 failure)."""
    if name == "attack":
        return bool(args.get("finish"))
    if name == "apply_damage":
        return args.get("resist") == "none"
    if name == "explode":
        item = L.find(str(args.get("item_id") or ""))
        return explosives.cloud((item or {}).get("props") or {}) in explosives.SMOKE
    if name == "matrix":
        decker = L.find(str(args.get("decker_id") or ""))
        target = L.find(str(args.get("target_id") or ""))
        return not decker or not matrix.edge_rides(L, decker["id"], args.get("action") or "",
                                                   target["id"] if target else args.get("target_id"),
                                                   args.get("node"), bool(args.get("forced")))
    return False


def _edge_calls(L, name: str, args: dict) -> list[tuple[str, dict]]:
    """[(whose roll, {edge field: value})] for one roll tool call - explode's per target. Only rolls: a call that
    rolls nothing for anyone (_rolls_nothing) has no Edge to check."""
    if _rolls_nothing(L, name, args):
        return []
    if name == "explode":
        return [(t.get("id"), {"edge": t.get("edge")}) for t in args.get("targets") or [] if isinstance(t, dict)]
    if name == "crash":
        return _crash_edge_calls(L, args)
    calls =[(args.get(key), {f: args.get(f) for f in fields}) for key, fields in EDGE_ROLLS.get(name, ())]
    if name == "attack":                                 # (each further strike's target dodges and soaks for itself)
        calls += [(m.get("target_id"), {"defense_edge": m.get("defense_edge"), "soak_edge": m.get("soak_edge")})
                  for m in args.get("more") or [] if isinstance(m, dict)]
    return calls


def _crash_edge_calls(L, args: dict) -> list[tuple[str, dict]]:
    """A crash's rolls and whose Edge rides each, one entry a person (the driver is a rider too): the ram's roll -
    into_id, or a barrier rammed on purpose (driver_id) - the driver's, or the rigger's when a drone they run rams
    (machines.ram_roller); the rammed one's dodge and soak; each rider's soak, but never in a ram, where the rammer's
    riders aren't hit. Review: 'pushing my Edge on the ram' was refused, then accepted in a rider's soak field that
    rolled nothing - and a rammed PC's called dodge Edge was never asked for."""
    into = args.get("into_id")
    calls: dict = {}

    def add(ref, fields: dict) -> None:
        ent = L.find(str(ref or ""))
        calls.setdefault(ent["id"] if ent else str(ref), (ref, {}))[1].update(fields)

    if into or (args.get("barrier_of") and args.get("driver_id")):
        v = L.find(str(args.get("vehicle_id") or ""))
        roller = L.find(str(args.get("driver_id") or "")) or machines.ram_roller(
            L, v if v and v["kind"] in sr_lite.MACHINES else None, None)
        if roller:
            add(roller["id"], {"edge": args.get("edge")})
    if into:
        add(into, {"defense_edge": args.get("defense_edge"), "soak_edge": args.get("soak_edge")})
    else:
        for r in args.get("riders") or []:
            if isinstance(r, dict):
                add(r.get("id"), {"riders.edge": r.get("edge")})
    return list(calls.values())


def _same_edge(name: str, field_: str, mode: str | None) -> str | None:
    """On a dodge, a soak or drain, a called reroll and insurance are the same thing - more hits only count while the
    blow still lands or the damage still gets through - so neither is turned away for being the other. (A ram's own
    roll is an attack's: there they differ.)"""
    defensive = field_ in DEFENSIVE_EDGE or name in ("apply_damage", "explode")
    return "reroll" if defensive and mode == "if_short" else mode


def _edge_check(ctx: TurnContext, name: str, args: dict) -> None:
    """A called Edge rides on the roll (§6b). Before any dice: a roll of a PC whose player called Edge this turn must
    carry it - the mode they said, or 'none' when it was for another roll. Otherwise it's turned away once (a
    RulesRefusal, nothing rolled) and the PC is settled. Live T164 (flag #64): "uses edge to reroll fails" went out
    with nothing to show the Edge reached the roll. Never on the last tool step: the GM would have no step to redo it,
    and never on a call that rolls nothing (_edge_calls) - it would settle the PC before the roll that counts.
    """
    if not ctx.edge_asks or ctx.steps - ctx.research_steps >= ctx.game.settings.models.dm_max_steps:
        return                                           # (free research steps aren't the budget's)
    for ref, given in _edge_calls(ctx.game.ledger, name, args):
        ent = ctx.game.ledger.find(str(ref or ""))
        if not ent or ent["id"] not in ctx.edge_asks or ent["id"] in ctx.edge_settled:
            continue
        who, use, quote = ctx.edge_asks[ent["id"]]
        if use == "push" and int(ctx.game.ledger.stat(ent["id"], "edge_points")) <= 0:
            ctx.edge_settled.add(ent["id"])              # (no point to push with: holding the GM to it would only
            continue                                     # make the roll an error - flag #50)
        passed = {f: v for f, v in given.items() if v not in (None, "", False)}
        try:
            got = {f: sr_lite.edge_use(v) for f, v in passed.items()}
        except LedgerError:
            return                                       # (a bad value: the tool's own error lists the modes)
        modes = {m for m in got.values() if m}
        if any(m and (use is None or _same_edge(name, f, m) == _same_edge(name, f, use)) for f, m in got.items()):
            ctx.edge_settled.add(ent["id"])              # it rode on this roll
            continue
        if passed and not modes:
            continue                                     # 'none' - this isn't the roll; it may ride a later one
        ctx.edge_settled.add(ent["id"])                  # (one reminder per player a turn)
        fields = [f for f in given if f != "use_edge"]
        said = f'{who}\'s player called Edge ("...{quote}...")'
        pass_it = " or ".join(f"{f}='{use}'" + (f" for {EDGE_ON.get((name, f)) or EDGE_ON[f]}" if len(fields) > 1
                                                 else "") for f in fields)
        if modes:                                        # the wrong mode: name the one their words mean
            raise RulesRefusal(f"{said}, which is '{use}' - this call passes '{'/'.join(sorted(modes))}'. Pass "
                               f"{pass_it} as they said it, or 'none' if their Edge was for another roll. "
                               "Nothing was rolled.")
        how = (pass_it if use else                       # (never a mode the words didn't decide - §6b: not on a guess)
               f"{' or '.join(fields)} in the mode their words mean - push: +Edge dice, 6s explode; reroll: the "
               "misses rerolled now; if_short: only if it falls short")
        raise RulesRefusal(f"{said} - pass it on this roll as they said it ({how}), or 'none' if it was for another "
                           "roll or a branch that didn't happen. Nothing was rolled.")


def _asks_for(ctx: TurnContext, decker: str | None) -> tuple[dict, dict, dict]:
    """The Matrix targets that bind this decker's dive (all of them, for None): ({host: ask} gone after, {host: ask}
    ruled out, {rating: ask}) - the first post's words for each. A post names a decker's target for that decker, or,
    naming none, for the table's (review of flag #36: one decker's named host held another's jack-in)."""
    asks = [a for a in ctx.matrix_asks or [] if decker is None or a.decker in (None, decker)]
    hosts: dict = {}
    avoid: dict = {}
    ratings: dict = {}
    for a in asks:
        if a.host and not a.avoid:
            hosts.setdefault(a.host, a)
        elif a.host:
            avoid.setdefault(a.host, a)
        if a.rating is not None:
            ratings.setdefault(a.rating, a)
    return hosts, {h: a for h, a in avoid.items() if h not in hosts}, ratings


def matrix_target(ctx: TurnContext, decker: str | None = None) -> dict | None:
    """The Matrix target the posts named for this decker's dive (any decker's, for None - turn.matrix_asks): {host:
    the host they named that's no harder than a rating they named, else None; rating: the highest rating they named,
    or None; avoid: the hosts they ruled out; who, words}. None when nothing was named. For the called-roll
    send-backs (calls._matrix_hint): the dive goes to this host - or, with only a rating, to a host no harder that
    the GM puts on file - never one the player didn't pick, or ruled out. A named host rated above the rating they
    named isn't it (review of flag #36: "the Larkspur host" and "the rating 3 cameras" in one post)."""
    L = ctx.game.ledger
    hosts, avoid, ratings = _asks_for(ctx, decker)
    if not hosts and not ratings and not avoid:
        return None
    cap = max(ratings) if ratings else None
    hid = next((h for h in hosts if cap is None or matrix.rating(L, h) <= cap), None)
    ask = hosts[hid] if hid else ratings[cap] if cap is not None else next(iter(avoid.values()))
    return {"host": hid, "rating": cap, "avoid": list(avoid), "who": ask.who, "words": ask.words}


MATRIX_REFUSALS = 2   # bare re-calls into a host the player didn't name, turned away a turn - the next goes, flagged


def _matrix_target_check(ctx: TurnContext, name: str, args: dict) -> None:
    """The host or device a player names is the one their decker goes after (flag #36), like a roll they call: a
    Matrix beat elsewhere is turned away before any dice (a RulesRefusal, nothing rolled) - a jack_in into a host they
    didn't name, one harder than the rating they named, or one they ruled out; a Matrix-skill request_test against
    such a host, and a complex form or a sprite's task in one (review of flag #36: the request_test went unguarded);
    and a beat in a run on another host when they named one to go after. A post can name a host it doesn't mean, and
    the GM has the words - but a bare re-call is turned away again: it goes through with the matrix tool's `despite`
    (why), or the third time, flagged for the table (MATRIX_REFUSALS). Live T120: the post picked the rating-3 camera
    system, and the dive went into the rating-5 Larkspur host. Only the targets that are this decker's (_asks_for) -
    held from the last few turns too (turn.MATRIX_CARRY). Never on the last tool step (the GM would have no step to
    redo it), as _edge_check."""
    if name not in ("matrix", "request_test", "thread", "sprite") or not ctx.matrix_asks:
        return
    if ctx.steps - ctx.research_steps >= ctx.game.settings.models.dm_max_steps:
        return
    L = ctx.game.ledger
    host = None
    if name == "matrix":
        action = args.get("action")
        decker = L.find(str(args.get("decker_id") or ""))
    elif name == "request_test":
        # (review of flag #36: a request_test with the host as opposed_by is the other way a decker goes at a host -
        # the live GM used it at T103 and T119 - and the camera hack the player called against a rating 3 target was
        # rolled against the rating-5 Larkspur host with no guard at all)
        action = "test"
        decker = L.find(str(args.get("actor_id") or ""))
        opp = args.get("opposed_by") if isinstance(args.get("opposed_by"), dict) else {}
        host = L.find(str(opp.get("entity_id") or "")) if opp.get("entity_id") else None
        if (str(args.get("skill") or "").lower() not in sr_lite.MATRIX_SKILLS + ("software",) or not host
                or host["kind"] != "host"):
            return
    else:                                                # a complex form or a sprite's task, in the host they're in
        action = name
        decker = L.find(str(args.get("techno_id") or ""))
    if not decker or decker["kind"] != "pc" or action in ("jack_out", "repair") or decker["id"] in ctx.matrix_settled:
        return                                           # (a runner's decker: an NPC spider goes where it goes)
    hosts, avoid, ratings = _asks_for(ctx, decker["id"])
    if not hosts and not avoid and not ratings:
        return                                           # (nothing named for this decker's dive)
    inside = matrix.live(L, decker["id"])
    if host is None:
        host = L.find(str(args.get("host_id") or "")) if action == "jack_in" else L.get(inside or "")
    if not host or host["kind"] != "host":
        return                                           # (not jacked in, no such host: the tool's own error says it)
    hid, r = host["id"], matrix.rating(L, host["id"])
    cap = max(ratings) if ratings else None
    fits = hid in hosts or (cap is not None and r <= cap and hid not in avoid)
    if fits:
        ctx.matrix_settled.add(decker["id"])             # (it's the one they named, or no harder than they said)
        return
    if action in ("jack_in", "test") and hid not in avoid and not hosts and cap is None:
        return                                           # (they only ruled out other hosts)
    if action not in ("jack_in", "test") and not hosts:
        return                                           # (a run already going: only a host they go after moves it -
        #                                                   a rating, or a mention of a file another host holds, doesn't)
    dn = decker["name"]
    # Bounded, as a called roll is (decision 4): a bare re-call is turned away again - review of flag #36, one refusal
    # and "call it again" put the dive back in the Larkspur host the GM's own narration had tied the cameras to. With
    # a reason (the matrix tool's `despite`), or the third time, it goes through - flagged for the table.
    despite = str(args.get("despite") or "").strip() if name == "matrix" else ""
    turned = ctx.matrix_turned.get(decker["id"], 0)
    if despite or turned >= MATRIX_REFUSALS:
        ctx.matrix_settled.add(decker["id"])
        from .. import flags
        why_ = f"the GM's reason: {despite}" if despite else f"turned away {turned} times, no reason given"
        flags.record(ctx.game, "engine", "matrix target overridden", f"{dn}'s Matrix {action.replace('_', ' ')} went "
                     f"into {host['name']} though the post named another target ({why_})", turn=ctx.turn_id)
        ctx.game.out(f"[GUARD] {dn}'s Matrix beat on {host['name']} goes through - {why_} - flagged")
        return
    ctx.matrix_turned[decker["id"]] = turned + 1

    def said(a, what: str) -> str:
        return (f"{a.who}'s post{f' at T{a.turn}' if a.turn else ''} {what} (\"...{a.words}...\")"
                + ("" if a.who == dn else f" for {dn}'s dive"))
    bits = [said(a, f"goes after {L.require(h)['name']} [{h}] (rating {matrix.rating(L, h)})")
            for h, a in hosts.items()]
    if ratings:
        bits.append(said(ratings[cap], f"names a {' or '.join(f'rating {n}' for n in ratings)} target"))
    if hid in avoid:
        bits.append(said(avoid[hid], f"rules out {host['name']}"))
    why = (" - the host they ruled out" if hid in avoid else
           f" - harder than the rating {cap} they named" if cap is not None and r > cap else "")
    go = [f"{L.require(h)['name']} [{h}]" for h in hosts if h != hid and (cap is None or matrix.rating(L, h) <= cap)]
    against = action == "test"
    if go:
        fix = (f"Go after the one they named - roll it against {' or '.join(go)}" if against else
               f"Go after the one they named - jack_in to {' or '.join(go)}" + (" (that leaves this one)" if inside else ""))
    elif cap is not None:                                # (never 'go after' a named host above the rating they said)
        fix = (f"{'Roll it against' if against else 'Jack into'} a host on file at rating {cap} or lower that runs "
               f"what they named - or, if it runs on its own lower-grade system (a building contractor's host, the "
               f"device's own), introduce that host (kind 'host', rating {cap}) and "
               f"{'roll it against it' if against else 'jack_in to it'}")
    else:
        fix = "Roll it against the host they do mean" if against else "Jack into the host they do mean"
    held = [a.turn for a in (*hosts.values(), *ratings.values(), *avoid.values()) if a.turn]
    what = (f"This {sr_lite.nice(str(args.get('skill')))} test goes against" if against
            else f"This {action.replace('_', ' ')} goes into")
    ctx.game.out(f"[GUARD] {dn}'s Matrix beat on {host['name']} - the player named another target - sending the GM back")
    raise RulesRefusal(f"{'; '.join(bits)}. {what} {host['name']} (rating {r}){why}. "
                       "The host or device the player names is binding, never a harder one they didn't pick. "
                       f"{fix}. If their post really does mean this host"
                       + (" - or the story has moved on from what they named then" if held else "")
                       + (", call it again with despite='<why>' (the table sees it flagged)" if name == "matrix"
                          else ", go into it with a matrix jack_in and despite='<why>' (the table sees it flagged)")
                       + " - a bare re-call is turned away again. Nothing was rolled.")


def run_tool(ctx: TurnContext, block) -> dict:
    ctx.tool_names.append(block.name)
    try:
        args = block.input if isinstance(block.input, dict) else json.loads(block.input)
        rollers = _rollers(block.name, args, ctx.game.ledger)   # (who runs a drone as it rolled, not after)
        _matrix_target_check(ctx, block.name, args)      # (first: a beat turned away here mustn't settle its Edge)
        answers = calls.check(ctx, block.name, args, rollers)   # the roll a player called: leader, skill, helpers
        _edge_check(ctx, block.name, args)
        content = dispatch(ctx, block.name, args)
        for ref in rollers:                              # (who rolled - a roll a player asked for gets checked)
            ent = ctx.game.ledger.find(ref)
            if ent:
                ctx.rolled.add(ent["id"])
        for call in answers:
            call.met = True                              # (only once it rolled: a refusal past this point rolled nothing)
        return {"type": "tool_result", "tool_use_id": block.id, "content": content}
    except calls.Rolled as done:                         # the GM gave a called roll away a third time: the engine's roll
        return {"type": "tool_result", "tool_use_id": block.id, "content": done.content}
    except RulesRefusal as exc:                          # the table's rules said no - the GM's to fix, not a bug
        # No Action Phase left: the called roll of whoever was turned away (the actor, whose phases it was) is answered,
        # or the roll guard would send the GM back into the same refusal. Only them - review: an NPC's refused swing
        # at Quiet Lou put Lou (its target) on the list too, and his player's own called roll went unguarded.
        if isinstance(exc, encounters.NoActionLeft):
            ctx.refused.update(exc.actors)
        ctx.game.out(f"  (tool {block.name} refused: {exc})")
        return {"type": "tool_result", "tool_use_id": block.id, "content": f"Refused: {exc}", "is_error": True}
    # (OverflowError: a 20-digit turn number bound into SQLite - review 2026-10-26: one bad lookup argument escaped
    # here, and run_turn undid the whole turn. AttributeError: an object argument sent as a JSON string - review of
    # P3: an opposed_by of '{"entity_id": "kaz"}' did the same)
    except (LedgerError, KeyError, ValueError, TypeError, AttributeError, OverflowError) as exc:
        msg = f"Error: {exc}" if not isinstance(exc, KeyError) else f"Error: missing field {exc}"
        ctx.tool_errors += 1
        ctx.game.out(f"  (tool {block.name} rejected: {msg[7:]})")
        from .. import flags
        flags.record(ctx.game, "engine", "tool error", f"{block.name}: {msg[7:]}", turn=ctx.turn_id,
                     context={"input": block.input})
        return {"type": "tool_result", "tool_use_id": block.id, "content": msg, "is_error": True}
