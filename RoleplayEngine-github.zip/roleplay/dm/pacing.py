"""Pacing (DESIGN.md §4): catch the GM looping - an exchange that never lands, NPCs re-asking what's settled - and
break it.

Live (the new world, T126-T150): every turn ended with someone waiting on Magic, a third of them on a literal
question ("Him, you, or me?", "Which is it?", "Who gets it first?"); Brask re-set her terms (a safe place, sleep
first) in six turns, Greta added a demand in four, and Juno asked where Bo sleeps after it was settled - "Did you hit
your head?" The words never repeated (two turns share 0-2% of their phrasing), so it was hard to see; the shape did.
The GM was told to end every turn handing it to a player, and with one player at the table and NPCs who want
things, it did that by having an NPC ask him something else, every time.

So, at the start of every public turn, with no model call:
- a streak of turns in this scene that ended with someone waiting on the players (a question, "your call",
  "name it", "waits to see", "hasn't said a word");
- an NPC asking again what an earlier turn already asked (the question's words overlap);
- the same NPC putting the same question or demand to the players again after they answered it (`raised`);
- a long scene with that streak;
- the players saying so ("are we there yet", "another loop", "I already answered that"; "I told you", "answer me
  straight" only maybe - a character says those too).
When it trips - or a player types `!stuck` - a cheap model reads the last turns' summaries and says what's repeating
and the move that breaks it. That goes to the GM this turn as a PACING note, and onto the flag log.

What the model read may and may not overrule (2026-10-27, flags #39, #40, #41, #45). It used to have the last word,
and kept it for three turns: at T158 a player wrote "I think I'm getting into another loop", the read said looping=false,
nothing reached the GM - and the GM flagged the loop itself that same turn. At T145 one 'no' would have silenced T146
and T147 too, the players' "are we there yet" with them. Now:
- the players saying it's looping is decisive: it always reaches the GM, as a firm note, whatever the read says - in a
  turn's post or in table talk the aside took (`heard`: live T158's post never reached a turn). Decisive are the words
  only a player talking about the story uses, and in table talk the GM aside's own judgment; words a character says
  too ('"I told you, we go at dawn."') are worth a read, and a decker's camera loop is nothing (review, 2026-10-27);
- an NPC who puts the same question or demand a third time, the players having answered it twice, is settled - the
  table's own R22 (once the table has tried to move on a couple of times, the NPC lets it go); firm too, when each
  go is the first go's own question again;
- a read answers for the evidence it read, and only that: anything new on a later turn is read afresh.
And the note says what's settled, by name and turn ("Greta's question about the ward/threshold/door is settled: she put
it at T139, Magic answered at T140 ..."), with the ruling or the canon line that settled it, so the GM can act on it.
The re-raise is matched by speaker and the thing's own words, not by long question sentences: Greta's "Him, you, or
me?", "Which is it?", "Agreed?" and "The ward still goes on the threshold" gave the old check nothing to compare.
"""
from __future__ import annotations

import json
import re

STREAK = 4                  # turns in a row ending on someone waiting on the players
LONG_SCENE = 10             # a scene this long, with a streak of 3, is worth a look
WINDOW = 10                 # turns the checker and the model look back over (a loop carries over a cut: T147-T149)
SHARED = 2                  # key words two lines of one NPC's must share to be the same question or demand
RAISES = 3                  # put a third time, the players having answered it twice: settled (the table's R22)
ASK_TAIL_SENTENCES = 3      # a question left with the players comes in the last few sentences of what's said...
CONTEXT = 2                 # ...and what it's about is in the sentences around it ("...or nobody gets in the van.
                            # Which one?")
SEEN_FOR = 2 * WINDOW       # turns a read's evidence is remembered
GIST = 160                  # characters of a complaint the GM's aside judged one, quoted in the note
HEARD_TEXT, HEARD_KEPT = 600, 3     # what's kept of table talk the aside took, and how many, for the next turn
NOTE, FORCED, SEEN, HEARD = "pacing_note", "pacing_forced", "pacing_seen", "pacing_heard"
SETTLED = "pacing_settled"  # the chains a note named settled - a later go at one is firm (flag #40)
LIGHT = "(maybe) "          # a note's prefix when only a player's soft words tripped it and the read said no (#45)

ASK_TAIL = re.compile(r"\?[\"”'*_)\]\s]*$")
ASK_WORDS = re.compile(r"\b(your call|name it|which is it|who gets|what'?s it (going to|gonna) be|waits? (for|on|to see)|"
                       r"waiting (for|on|to see)|the room is waiting|all eyes|looks? (straight )?at (him|her|them|you)|"
                       r"your move|up to (you|him|her)|"
                       # live T183-T186 ended four running on Magic being waited on, and none of it counted:
                       r"(he|she|they)('s| is| are|'re) (still )?waiting|(he|she|they) waits?|still waiting|"
                       r"(hasn't|haven't|has not|have not) (said a word|moved|answered|stepped back|looked away)|"
                       r"for (an|your|his|her|their) answer)\b", re.I)
ASK_NAME = re.compile(r"\b(look|looks|turn|turns|wait|waits|glance|glances) (straight |up |back )?(at|to|on) "
                      r"[A-Z][a-z]+[.!]?[\"”'*_)]*$"                 # "...both look at Magic."
                      r"|\b[A-Z][a-z]+ (just |only |still |simply )?waits?[.!]?[\"”'*_)]*$")   # "Greta waits." (#39)
STOP = set("""the and that this with what where when who whom whose which from have will would could should there their
them they your you she her him his into about just been then than also only does done dont don't it's its i'm we're
you're isn't won't can't tell me us our out for not but are was were is be an a of to in on at by or if so do""".split())

# ── what the players say ───────────────────────────────────────────────
# A loop complaint. Live: T147 "Are we there yet?", T150 "another loop... 'answer me straight'... Did you hit your
# head?", T151 "wouldn't go forward until a boolean answer", T158 "I think I'm getting into another loop".
# Two tiers (review, 2026-10-27). FIRM_LOOP is decisive - wordings only a player talking about the story uses. SOFT_LOOP
# is worth a read, and the read decides: words a character says too ('"I told you, we go at dawn."', "He asks again:
# where's the chip?", '"We already agreed on 5k"', "answer me straight") or a player narrates ("won't move forward").
# Every one of those had been made decisive, so a line of dialogue closed the scene under the player, whatever the read
# said. A firm wording inside a character's quoted speech is soft; a soft one in a sentence about the GM or the NPCs
# ("Telling the DM she's had her kid all along, it ... wouldn't go forward", T151's shape) is firm, and so is a loop
# word in a post addressed to the GM ("Hey DM, this is a loop").
FIRM_LOOP = re.compile(
    r"(are we there yet|\b(a)?round and (a)?round\b|broken record|groundhog day|"
    r"padd(ed|ing) (it |this |things )?(out )?for time|"
    r"\b(going|go|goes|went|running|run|talking|talk|stuck|spinning|keep going|keeps going) (around |round )?in circles|"
    r"\banother (narrative |story |npc |conversation )?loop\b|"
    r"\b(i'?m|i am|we'?re|we are|you'?re|you are|they'?re|they are) (\w+ ){0,2}(in|into) "
    r"(a|an|the same|this|that) (\w+ )?loop\b|"
    r"\b(stuck|caught|trapped) (\w+ )?(in|into) (a|an|the same|this|that) (\w+ )?loop\b|"
    r"\b(feels?|felt|seems?|looks?) like (a|an|another|the same) (\w+ )?loop\b|"
    r"\b(npcs?|story|storyline|plot|dialogue|conversation|narrative|scene|questions?|gm|dm)('s| is| are| keeps?| just|"
    r" has| have)? loop(s|ing|ed)?\b|"
    r"\b(you'?re|you are|you keep|you'?ve been) looping\b|\byou (just )?looped\b|"
    r"\b(this|it|that)('s| is| feels| seems| looks)( \w+)? (recursive|circular)\b|"
    r"\b(i|we)( have|'ve)? already answered (that|this|it|him|her|them|you)\b|"
    r"\b(i|we)( have|'ve)? answered (that|this|it|him|her|them) (already|before|twice|(\w+ )?times)\b|"
    r"\b(keeps?|kept) (asking|demanding|repeating|re-?asking|bringing (it |that |this )?up|coming back to (it|that|this))"
    r"( me| us)?( for)? (the same|that again|this again|again|over and over)\b|"
    r"\b(why|how come)( does| do| did| is| are| would)?( [\w'’]+){1,3} keep(s|ing)? (asking|demanding|pushing|"
    r"bringing|coming back|repeating)\b|"
    r"\byou keep (asking|repeating|re-?asking|bringing (it |that |this )?up)\b|"
    r"\b(you'?re|you are) (just )?(repeating|re-?asking) (yourself|the same|that|this)\b|"
    r"\bhow many times (do|does|did|have|must|will|should|am) (i|we) (have to |need to |got to |gotta )?"
    r"(say|tell|answer|explain|repeat))", re.I)
SOFT_LOOP = re.compile(
    r"(recursive|circular|hit your head|answer me straight|"
    r"\balready (told|said|answered|agreed|settled|asked|went over|covered|gave)\b|"
    r"\bwe (just|already) (did|said|talked|went over)\b|\bwe'?ve (been over|been through|done) (this|that)\b|"
    # (review of flag #45: "We covered this already", "Here we go again.", "Stuck again." matched nothing)
    r"\b(covered|been over|went over|discussed|talked about|settled) (this|that|it) already\b|\bhere we go again\b|"
    r"\bstuck again\b|"
    r"\b(as|like) i (said|told you)\b|\bi (already |just )?told you\b|\bi (just )?answered (that|this|it)\b|"
    r"\b(she|he|they|you|it)('s| is| are|'re)? ask(s|ed|ing)? (me |us )?(that |this |it )?again\b|"
    r"\b(asked|asking) (me|us) (that |this |it )?again\b|\bask(s|ed|ing)? (that|this|it) (again|already)\b|"
    # (not "...tell her they keep asking him to come in for a checkup" - a plan for a con, live T15 - nor "I'll keep
    # asking around the bar")
    r"\b(keeps|kept|keep) (asking|demanding|pushing|pressing|repeating|bringing (it |that |this )?up|coming back to)\b"
    r"(?! (around|for (him|her|them|it) to)\b)|"
    r"\bstop (asking|re-?asking|repeating)\b|\brepeat(s|ing|ed)? (himself|herself|themselves|itself)\b|"
    r"\bsame (question|conversation|demand|objection|thing|stuff)\b|"
    r"(won'?t|wouldn'?t|doesn'?t|didn'?t|can'?t|couldn'?t) (go|move) forward|won'?t let (it|this|that) go|"
    r"move (it|this|things) along|\b(conversation|exchange|scene|negotiation) (that |which )?(is |was |'s )?"
    r"(clearly |already |long )?over\b|"
    # "it's a loop" is the guard's camera as often as the story ("Relax, the guard sees nothing - it's a loop")
    r"\b(this|that|it)('s| is| was) (\w+ )?(a|the same) (\w+ )?loop\b|\b[\w']+ (is|are|keeps|'s) looping\b|"
    r"\bloop(s|ing|ed)?\b)", re.I)
# A decker's loop is a move: "keeps the cameras in a loop", "the feed's looping", "flick the cop call into a loop and
# stash the log", "the duress channel running on a loop", "a ghost-loop into the grid" (the autoplay worlds), "a
# recursive search on the host". A loop word in a sentence with one of these counts for nothing...
MATRIX = re.compile(r"\b(cams?|cameras?|cctv|feeds?|footage|video|vid|recording|playback|sensors?|signals?|alarms?|"
                    r"channels?|duress|logs?|grid|hosts?|nodes?|deck|cyberdeck|programs?|scripts?|spoof\w*|matrix|"
                    r"icons?|persona|search|drones?|commlink|radio|audio|tracks?|music|song|hud|overlay|display)\b",
                    re.I)                                 # ("I pull a second loop onto his HUD" - autoplay_v2 T7)
LOOPISH = re.compile(r"loop|circle|recursive|circular|round and", re.I)
# ...and so is "keep her in the loop" (live T36: "keep he in to loop"), "loop my deck in", a car looping the block.
IDIOM = re.compile(r"\b(in|into|in to|out of|outta) (the )?loop\b|\bloop(s|ed|ing)? ([\w']+ ){1,3}in\b|"
                   r"\bloop(s|ed|ing)? (around|back|through|over|under|past)\b", re.I)
# Talk about the game, not in it: a soft wording here is a complaint.
META_TALK = re.compile(r"\b(the|this|that|our|your) (gm|dm|bot|engine)\b|\bnpcs?\b|\b(the|an) (ai|llm|model)\b|"
                       r"\bturns? ago\b", re.I)
# ...and so is "it" stalling (the GM, the story - live T151, with no "Telling the DM" in front: it ignored the post
# and wouldn't move on without a yes or a no), and an NPC on file doing the looping ("Juno keeps asking for a straight
# answer" - flag #45's own wording, "Kaz is looping again"). Review of flag #45: each was only a read's, and a 'no'
# read silenced the player. (Not any verb an NPC keeps doing: "Kaz keeps pushing the cart" is the story.)
IT_STALLS = re.compile(r"\bit\b.*\b(ignor(e|es|ed|ing)|(won'?t|wouldn'?t|doesn'?t|didn'?t|can'?t) (go|move) forward)\b",
                       re.I)
NPC_LOOP = re.compile(r"\b(keeps?|kept) (asking|demanding|re-?asking|repeating|pressing|bringing (it |that |this )?up|"
                      r"coming back to)\b(?! around\b)|\b(is|are|'s|keeps) looping\b|\bsame (question|demand|objection)\b|"
                      r"\bwon'?t let (it|this|that) go\b|\bask(s|ed|ing)? (me |us )?(that |this |it )?again\b", re.I)
# A bare "This is a loop." with no camera in the post is the story's (review of flag #45: "it's a loop" stays a
# read's - the guard's feed as often as not).
BARE_LOOP = re.compile(r"\b(this|that)('s| is| was| feels| seems) (\w+ )?(a|the same|another) (\w+ )?loop\b", re.I)
ADDRESSED = re.compile(r"^\s*(?:(?:hey|hi|yo|ok|okay|so|um|uh)\b[\s,]*)?(?:dm|gm)\b(?!['’]s\b)|^\s*\(\(", re.I)
SPOKEN = re.compile(r"[\"“]([^\"“”\n]*)(?:[\"”]|$)", re.M)    # a character's line (unclosed: to the line's end, T150)
SAID_SENTENCES = re.compile(r"(?<=[.!?…])\s+|\s+-\s+")
# Impatience: worth a look (the model decides). Live T156: a player done answering beats that held the plan up; T160:
# a player saying the story had got boring.
IMPATIENT = re.compile(r"\b((i'?m|i am|we'?re|we are|getting|so) bored|(this|it'?s|that'?s|so) boring|drag(s|ging)? on|"
                       r"get on with it|delay(s|ing)? (this|it|us)|force it to happen|wrap (it|this) up|"
                       r"finish (it|this) up|hurry (it|this) up|can we (please )?move on|let'?s move on|"
                       r"move on already)\b", re.I)

# ── what the NPCs say ──────────────────────────────────────────────────
TAG = re.compile(r"\*\*([^*\n]{1,48}?):\*\*")                  # **Greta:** (speakers.resolve strips the [id])
QUOTED = re.compile(r"[\"“]([^\"“”]+)[\"”]")
NAMEISH = re.compile(r"^[A-Za-z][A-Za-z.'\- ]{1,38}$")
TITLE = re.compile(r"^(dr|mr|mrs|ms|miss|sgt|sergeant|officer|detective|doc)\.?\s+", re.I)
SENTENCES = re.compile(r"(?<=[.!?…])(?<!\bDr\.)(?<!\bMr\.)(?<!\bMs\.)(?<!\bMrs\.)(?<!\bSt\.)[\"”'*_)\]]*\s+")
# A demand put to the players without a question mark: "I want a name before you leave this booth", "Name it.", "No
# answer is a yes, as far as I'm concerned", "you still haven't told me" (live T137-T146 had all four shapes).
DEMAND = re.compile(
    r"\b(answer me|(a|my|the) straight answer|i want (an|my|a|the) (answer|name|address)|i want to (hear|know|see)|"
    r"i need (to know|to hear|an? |the |you to)|tell me (who|what|where|why|how|if|whether|straight|the truth|now|"
    r"first)|name it|yes or (a )?no|(still )?(haven'?t|have not|didn'?t|did not) (told|tell|answered|answer|said|say)\b|"
    r"i didn'?t hear a (yes|no)|or nobody|or nothing|or no deal|or (i|we) (walk|go|leave|turn)|not until|which is it|"
    r"(?<!make )your call|before (i|we|she|he) (lift|get|go|walk|sign|hand|move|say|agree)|"
    r"what'?s it (going to|gonna) be)", re.I)
# The same demand again, in words that say only that: "You still haven't answered me", "Yes or no?", "I'm still
# waiting", "That isn't an answer" (flag #39).
REDEMAND = re.compile(r"\b((still )?(haven'?t|have not|didn'?t|did not) (answered|answer|told|tell|said|say)|"
                      r"yes or (a )?no|(i'?m|i am) still waiting|still waiting (for|on)|answer (me|the question)|"
                      r"(that|this)('s| is|'s not| isn'?t| is not| wasn'?t) (not )?an answer|not an answer|"
                      r"i asked you|i'?m asking you)\b", re.I)
HOLD = re.compile(r"\b(still (goes|stands|holds|haven'?t|hasn'?t|don'?t|doesn'?t|won'?t|isn'?t|aren'?t)|"
                  r"(ask|asking|say|saying|tell|telling) (you |it )?again|not negotiable|either way|"
                  r"no matter what|or nobody|or nothing)\b", re.I)    # "The ward still goes on the threshold." (T146)
# Words that carry no "what about": function words, address, and the words every demand is made of.
COMMON = STOP | set("""about after again against all almost already always am any anyone anything anyway around ask
asked asking asks away back bad because before being better big both bring but call came can come comes coming
could course did didn't does doesn't doing done down each either else enough even ever every everyone everything
fine first five four from get gets getting give given go goes going gone good got had hadn't has hasn't haven't
having he'd he'll he's hear heard help her here here's hers herself himself how i'd i'll i've isn't it'll keep kind
know knows last least leave less let let's like little long look looks lot made make makes man many may maybe mean
means might mind mine more most mr mrs ms dr much must my myself name need needs never new next nice nobody none
nor nothing now off oh okay once one ones only other others over own part people please put quite rather really
right said same say says see seen sense she'd she'll she's should shouldn't since some somebody someone something
sometimes soon sorry still such sure take takes talk tell telling than thank thanks that's then there's these
they'd they'll they're they've thing things think those though three through till time today told too took toward
try trying two under until upon very want wants wasn't way we'd we'll we've well went what's whatever where's
whether while who's why will wish without won't word words work would wouldn't yes yet you'd you'll you've yours
yourself answer answers answered question questions straight agree agreed deal fair big man chummer listen look
hmm huh yeah nope okay somewhere anywhere everywhere""".split())
# When, not what: the scene's clock is in every line of it. Review (2026-10-27, live T28-T40 replayed): three of
# Juno's questions about different things - what happens if she walks, where the boy stays Thursday, whose debt it
# is - were made one question on the clock's words ({night, thursday}, {thursday, walk}) - and its third go settled.
TIME = set("""monday tuesday wednesday thursday friday saturday sunday today tonight tomorrow yesterday morning
mornings morn evening evenings afternoon noon midnight dawn dusk night nights hour hours minute minutes week weeks
weekend month months day days clock half quarter late later early earlier ago six seven eight nine ten eleven twelve
twenty thirty forty fifty sixty""".split())
COMMON |= TIME
IRREGULAR = {"slept": "sleep", "kept": "keep", "paid": "pay", "held": "hold", "doorways": "door", "doorway": "door"}
VOCATIVE = set("and so well hey mr ms mrs dr big man chummer kid friend troll".split())   # "And Magic?" asks nothing
SETTLING = re.compile(r"\b(settled|re-?rais|re-?ask|re-?open|closed|accepted|answered|agreed)", re.I)

SYSTEM = """You review the pacing of an AI game master running a Shadowrun game for players on Discord. Below are \
the last turns: what the players posted, a summary of what happened, and how the turn ended. Is the story stuck in \
a loop? Loops look like: an exchange where every NPC reply raises a new condition or question instead of deciding; \
NPCs asking again about things already answered or settled; every turn ending on another question to the same \
player; the scene going around without anything changing. A long negotiation that is actually moving forward is \
NOT a loop. If it is looping, say in one sentence what is repeating (name the NPCs and the thing), and give the \
single move that breaks it, as an instruction to the GM for its next turn (who accepts what, what gets resolved, \
what to skip ahead to). Keep both short."""


def schema() -> dict:
    return {"type": "object", "properties": {"looping": {"type": "boolean"}, "what": {"type": "string"},
                                             "break_it": {"type": "string"}},
            "required": ["looping", "what", "break_it"], "additionalProperties": False}


# ── reading the turns ───────────────────────────────────────────────────
def last_sentence(text: str) -> str:
    body = re.sub(r"\s+", " ", (text or "").strip())
    parts = re.split(r"(?<=[.!?…])[\"”'*_)\]]*\s+(?=[A-Z*\"“(])", body)
    return parts[-1].strip() if parts else ""


def ends_on_ask(text: str) -> bool:
    """Does the turn end with someone waiting on the players - a question, or 'your call', 'waits to see'..."""
    tail = last_sentence(text)
    return bool(ASK_TAIL.search(tail) or ASK_WORDS.search(tail) or ASK_NAME.search(tail))


def questions(text: str) -> list[str]:
    body = re.sub(r"\s+", " ", text or "")
    return [q.strip(" \"“”*") for q in re.findall(r"[^.!?\"“”]{8,}\?", body)]


def _words(s: str) -> set[str]:
    return {w for w in re.findall(r"[a-z']+", s.lower()) if len(w) > 3 and w not in STOP}


def reasked(new: str, older: list[tuple[int, str]]) -> list[tuple[int, str, str]]:
    """Questions in `new` that an earlier turn already asked: (that turn, the question now, the question then)."""
    out = []
    for q in questions(new):
        qa = _words(q)
        if len(qa) < 3:
            continue
        for tid, text in older:
            for old in questions(text):
                ob = _words(old)
                if len(ob) >= 3 and len(qa & ob) / len(qa | ob) >= 0.5:
                    out.append((tid, q, old))
                    break
            else:
                continue
            break
    return out


def _loop_words(sentence: str, firm_ok: bool, upgrade: bool, addressed: bool) -> tuple[set[str], set[str]]:
    """(firm, soft) loop wordings in one sentence. firm_ok: outside a character's quoted speech; upgrade: the sentence
    talks about the GM or the NPCs; addressed: the post opens on the GM ("Hey DM, ...") or (( table talk ))."""
    firm, soft, spans = set(), set(), []
    matrix = bool(MATRIX.search(sentence))
    idioms = [m.span() for m in IDIOM.finditer(sentence)]
    for m in FIRM_LOOP.finditer(sentence):
        hit = m.group(0).lower()
        if matrix and LOOPISH.search(hit):
            continue                                     # (the cameras' loop, not the story's)
        spans.append(m.span())
        (firm if firm_ok else soft).add(hit)
    for m in SOFT_LOOP.finditer(sentence):
        a, b = m.span()
        hit = m.group(0).lower()
        if any(a < y and x < b for x, y in spans):
            continue                                     # (part of a firm wording already)
        loopish = bool(LOOPISH.search(hit))
        if loopish and (matrix or any(x <= a and b <= y for x, y in idioms)):
            continue
        (firm if firm_ok and (upgrade or (addressed and loopish)) else soft).add(hit)
    return firm, soft


def said(text: str, npcs: set[str] | frozenset = frozenset()) -> dict:
    """The players' own words about the pacing: {"loop": [a loop complaint - decisive], "maybe": [loop words a
    character says too - worth a read], "impatient": [worth a read]}. npcs: the name words of the NPCs on file - a
    sentence naming one, outside quotes, with NPC_LOOP's words is a complaint (check passes them)."""
    firm, soft = set(), set()
    cams = bool(MATRIX.search(text or ""))
    for para in re.split(r"\n\s*\n", text or ""):
        addressed = bool(ADDRESSED.match(para))
        spoken = [q for q in SPOKEN.findall(para) if q.strip()]
        rest = SPOKEN.sub(" … ", para)
        for chunk, outside in [(rest, True)] + [(q, False) for q in spoken]:
            for sentence in SAID_SENTENCES.split(chunk):
                about_npc = bool(npcs and NPC_LOOP.search(sentence)
                                 and set(re.findall(r"[a-z]+", sentence.lower())) & npcs)
                upgrade = outside and bool(META_TALK.search(sentence) or IT_STALLS.search(sentence) or about_npc)
                f, s = _loop_words(sentence, outside, upgrade, addressed)
                if outside and not cams:                     # "This is a loop." - no decker's feed in the post
                    for m in BARE_LOOP.finditer(sentence):
                        f.add(m.group(0).lower())
                        s = {x for x in s if x not in m.group(0).lower() and m.group(0).lower() not in x}
                firm |= f
                soft |= s
    return {"loop": sorted(firm), "maybe": sorted(soft - firm),
            "impatient": sorted({m.group(0).lower() for m in IMPATIENT.finditer(text or "")})}


ANSWERED = re.compile(r"\b(already (told|said|answered|gave)|i (already |just )?told you|(as|like) i (said|told you)|"
                      r"i (just )?answered)\b", re.I)


def _npc_words(game) -> set[str]:
    """The name words of the NPCs on file (said(): a sentence naming one with NPC_LOOP's words is a complaint)."""
    out = set()
    for e in game.ledger.entities(kind="npc", status=None):
        for n in [e["name"], *(e.get("aliases") or [])]:
            out |= {w for w in re.findall(r"[a-z]+", n.lower()) if len(w) >= 3 and w not in COMMON and w not in TITLES}
    return out - _pc_words(game.ledger)


TITLES = {"dr", "mr", "mrs", "ms", "miss", "the", "old", "doc", "officer", "detective", "sergeant", "sgt"}


def _stem(w: str) -> str:
    w = IRREGULAR.get(w, w)
    if len(w) > 5 and w.endswith("ing"):
        return w[:-3]
    if len(w) > 4 and w.endswith("ied"):
        return w[:-3] + "y"
    if len(w) > 4 and w.endswith("ed"):
        return w[:-2]
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        return w[:-1]
    return w


def _keys(text: str, drop: set[str] = frozenset()) -> dict[str, str]:
    """What a line is about: {stem: the word as said} - its content words, without the words every demand is made of
    or the names of the people talking."""
    out: dict[str, str] = {}
    for w in re.findall(r"[a-z][a-z'-]*[a-z]|[a-z]", (text or "").lower().replace("’", "'")):
        w = w[:-2] if w.endswith("'s") else w
        if len(w) < 3 or "'" in w or w in COMMON or w in drop:      # (a contraction is a function word)
            continue
        if "-" in w and all(p in COMMON for p in w.split("-")):     # ("seven-thirty", "fifty-one")
            continue
        s = _stem(w)
        if s not in COMMON and s not in drop:
            out.setdefault(s, w)
    return out


def _speaker(L, label: str, cache: dict):
    """(id, name, the name's words) for a dialogue tag - an NPC on file, or a bit part by its label; None for a PC or a
    heading ('**What we can do:**')."""
    if label not in cache:
        bare = TITLE.sub("", label).strip()
        ent = L.find(label) or (L.find(bare) if bare and bare != label else None)
        if ent:                                      # (the name and the tag - not every alias: Greta's "Ward
            names = f"{ent['name']} {label}"         # Maintenance" would take "ward" out of her own demand)
            cache[label] = (None if ent["kind"] == "pc" else
                            (ent["id"], ent["name"], set(re.findall(r"[a-z]+", names.lower()))))
        else:
            cache[label] = (("?" + label.lower(), label, set(re.findall(r"[a-z]+", label.lower()))) if
                            NAMEISH.match(label) and len(label.split()) <= 3 else None)
    return cache[label]


def _pc_words(L) -> set[str]:
    out = set()
    for e in L.entities(kind="pc", status=None):
        out |= set(re.findall(r"[a-z]+", e["name"].lower()))
    return out


def speech(game, text: str, cache: dict | None = None, pcs: set[str] | None = None) -> list[dict]:
    """Each tagged line of NPC dialogue in a narration: {who, name, names, said, asks (the questions and demands it
    leaves with the players), holds (a demand restated mid-speech, a condition held: 'still goes', 'not negotiable'),
    sents, at (where those are), asked (the sentences around them - what's being asked)}. A question is left with the
    players when it comes at the end of what's said: the "Lone Star?" an NPC answers herself in the next breath (live
    T137) isn't, nor is a bare "And Magic?"."""
    L, cache = game.ledger, {} if cache is None else cache
    pcs = _pc_words(L) if pcs is None else pcs
    tags = list(TAG.finditer(text or ""))
    out = []
    for i, m in enumerate(tags):
        sp = _speaker(L, m.group(1).strip(), cache)
        if not sp:
            continue
        end = tags[i + 1].start() if i + 1 < len(tags) else len(text)
        seg = text[m.end():end]
        cut = seg.find("\n\n")
        seg = seg[:cut] if cut >= 0 else seg
        quotes = QUOTED.findall(seg)
        if not quotes and (sp[0].startswith("?") or not seg.strip()):
            continue                                     # (a bit part's label with no speech: a heading)
        words = " ".join(quotes) if quotes else seg.replace("*", " ")
        words = re.sub(r"\s+", " ", words).strip()
        sents = [s.strip(" *_\"“”") for s in SENTENCES.split(words) if s.strip(" *_\"“”")]
        ask = [s.endswith("?") or bool(DEMAND.search(s)) for s in sents]
        put = [j for j, a in enumerate(ask) if a and (j >= len(sents) - ASK_TAIL_SENTENCES or all(ask[j + 1:]))
               and not set(_flat(sents[j]).split()) <= pcs | VOCATIVE]
        # (a demand restated mid-speech carries a question on - T145's shape, "No answer is a yes, as far as I'm
        # concerned" - but never starts one)
        held = [j for j, s in enumerate(sents) if j not in put and (HOLD.search(s) or (ask[j] and not s.endswith("?")))]
        near = {k for j in put + held for k in range(j - CONTEXT, j + CONTEXT + 1) if 0 <= k < len(sents)}
        out.append({"who": sp[0], "name": sp[1], "names": sp[2], "said": words, "asks": [sents[j] for j in put],
                    "holds": [sents[j] for j in held], "hold": bool(held), "sents": sents, "at": sorted(put + held),
                    "asked": " ".join(sents[k] for k in sorted(near))})
    return out


def _flat(s: str) -> str:
    return " ".join(re.findall(r"[a-z]+", s.lower()))


def _same(s: dict, x: dict) -> int:
    """How surely two lines of one NPC's put the same thing: the words they ask about in common (0 if none of those is
    in either one's own question or demand - the scene's words, not the question's). Like with like: what each one
    asks about, never one line's whole speech against the other's question (review, 2026-10-27: T38's speech shared
    {pay, thursday} with T31's question, and T14's "Your call, big man" {tonight, walk} with T7's)."""
    shared = set(s["asked_keys"]) & set(x["asked_keys"])
    if not shared & (set(s["ask_keys"]) | set(x["ask_keys"])):
        return 0
    return max(len(shared), SHARED) if s["flat"] & x["flat"] else len(shared)   # ("Which is it?" again)


def raised(game, rows: list[dict]) -> list[dict]:
    """The same NPC putting the same question or demand to the players again, on a later turn - after their posts in
    between answered it, sidestepped it or let it lie. One chain per NPC and thing, most goes first: {who, name, turns
    (each turn it was put), direct (the turns that put the first go's own question again), firm (put RAISES times,
    the last of them too, each the first go's question), first (how it was first put), last (how it was last put),
    topic (the words it's about), keys, answered (the first turn after it: its turn and who posted), kind
    (question/demand)}. rows: the window's turns, newest first. A line joins a chain when what it asks about shares
    SHARED words with what an earlier go asked about - one of them in the question or demand itself - or it asks the
    very same short question ("Which is it?" twice); a bare "Agreed?" or "Which is it?" is about its whole speech
    (what's agreed to). Only a question or a demand left with the players starts one; a demand restated mid-speech or a
    condition held ('still goes', 'not negotiable') carries it on."""
    L = game.ledger
    pcs = _pc_words(L)
    cache, per = {}, {}
    for r in reversed(rows):                         # oldest first
        for s in speech(game, r["narration"] or "", cache, pcs):
            drop = pcs | s["names"]
            own = _keys(" ".join(s["asks"] + s["holds"]), drop)
            s["turn"], s["keys"] = r["id"], _keys(s["said"], drop)
            s["ask_keys"] = own or s["keys"]
            s["asked_keys"] = _keys(s["asked"], drop) if own else s["keys"]
            s["flat"] = {_flat(a) for a in s["asks"] if len(_flat(a).split()) >= 2}
            per.setdefault(s["who"], []).append(s)
    inputs = {r["id"]: json.loads(r["inputs"] or "[]") for r in rows}
    chains = []
    for who, lines in per.items():
        mine = []
        for s in lines:
            if not (s["asks"] or s["hold"]):
                continue
            best, most = None, 0
            for c in (mine if s["keys"] else []):    # (against what it asked on earlier turns, never this one)
                for x in c["lines"]:
                    if x["turn"] == s["turn"]:
                        continue
                    n = _same(s, x)
                    if n >= SHARED and n > most:
                        best, most = c, n
            if best is None and REDEMAND.search(" ".join(s["asks"] + s["holds"])):
                # The same demand put again in words with nothing in them - "You still haven't answered me. Yes or
                # no?", "Pembrook. Yes or no, Mr. Magic." - carries on this NPC's chain still being put (its last go
                # the turn before, or the one before that), a direct go: review of flag #39, such lines were dropped
                # (no content words), the chain stalled at two goes and a 'no' read silenced it however often she
                # asked. Never one of these that starts a chain.
                open_ = [c for c in mine if 0 < s["turn"] - c["turns"][-1] <= 2]
                c = max(open_, key=lambda c: c["turns"][-1]) if open_ else None
                about = set().union(*(x["asked_keys"] for x in c["lines"])) if c else set()
                if c is not None and (not s["keys"] or set(s["ask_keys"]) & about or len(s["ask_keys"]) <= 1):
                    c["lines"].append(s)
                    c["turns"].append(s["turn"])
                    c["direct"].append(s["turn"])
                    continue
            if not s["keys"]:
                continue
            if best is not None:
                best["lines"].append(s)
                if s["turn"] not in best["turns"]:
                    best["turns"].append(s["turn"])
                # a third go is settled only if it puts the first go's own question again - not one that drifted
                # from it link by link (matching is transitive: the third line never has to resemble the first)
                first = best["turns"][0]
                if any(_same(s, x) >= SHARED for x in best["lines"] if x["turn"] == first) \
                        and s["turn"] not in best["direct"]:
                    best["direct"].append(s["turn"])
            elif s["asks"]:
                mine.append({"who": who, "name": s["name"], "lines": [s], "turns": [s["turn"]],
                             "direct": [s["turn"]]})
        chains += [_chain(L, c, inputs) for c in mine if len(c["turns"]) >= 2]
    return sorted(chains, key=lambda c: (-len(c["turns"]), -c["turns"][-1]))


def _quote(line: dict, shared: list[str]) -> str:
    """The sentence of a line that puts the thing: its question or demand most about the chain's words (a bare
    "Agreed?" with the sentence before it - it says little without what it agrees to)."""
    sents = line["sents"]
    if not line["at"]:
        return line["said"]

    def about(j: int) -> tuple[int, int]:
        return (len(set(_keys(sents[j])) & set(shared)),
                len(set(_keys(" ".join(sents[max(0, j - 1):j + 2]))) & set(shared)))
    at = max(reversed(line["at"]), key=about)
    return f"{sents[at - 1]} {sents[at]}" if at and len(sents[at].split()) < 6 else sents[at]


def _chain(L, c: dict, inputs: dict) -> dict:
    """One re-raised question, put together: what it's about (the words asked about on two or more of its turns, the
    most-repeated first, and only those in the lines it quotes), how it was first put and last put, and who answered
    it first."""
    count: dict[str, int] = {}
    words: dict[str, str] = {}
    for t in c["turns"]:
        for k in {k for x in c["lines"] if x["turn"] == t for k in x["asked_keys"]}:
            count[k] = count.get(k, 0) + 1
    for x in reversed(c["lines"]):                   # (each word as it's said now - its plainest form: "key", not
        for k, w in x["asked_keys"].items():         # the "Keyed to me" of a speech a bare "Agreed?" brings in)
            if k not in words or len(w) < len(words[k]):
                words[k] = w
    shared = sorted((k for k in count if count[k] >= 2), key=lambda k: (-count[k], k))   # (ties: the same every run)
    first, last = _quote(c["lines"][0], shared), _quote(c["lines"][-1], shared)
    quoted = set(_keys(f"{first} {last}"))
    topic = [k for k in shared if k in quoted][:3]   # (a label only from words it's actually put in)
    after = [t for t in sorted(inputs) if t > c["turns"][0]]
    posted = inputs.get(after[0], []) if after else []
    by = sorted({(L.find(h) or {}).get("name") or h for h, _ in posted}) or ["the players"]
    # Firm once it's been put RAISES times as the first go's own question: every go after that is the settled thing
    # raised again, however its words drift - review of flag #40, live T146's "The ward still goes on the threshold"
    # shared only "ward" with T139's door/key question, so the chain went soft and a 'no' read silenced the fifth go.
    return {"who": c["who"], "name": c["name"], "turns": c["turns"], "direct": c["direct"],
            "firm": len(c["direct"]) >= RAISES, "first": first, "last": last,
            "topic": [words[k] for k in topic], "keys": set(words),
            "answered": {"turn": after[0] if after else None, "by": " and ".join(by)},
            "kind": "question" if any(a.endswith("?") for a in c["lines"][0]["asks"]) else "demand"}


def _recent(game, n: int = WINDOW) -> list[dict]:
    return [dict(r) for r in game.conn.execute(
        "SELECT id, scene_id, inputs, narration FROM turns WHERE status='committed' AND private IS NULL "
        "ORDER BY id DESC LIMIT ?", (n,))]


def _heard(game) -> list[dict]:
    try:
        return json.loads(game.ledger.meta(HEARD) or "[]")
    except ValueError:
        return []


def _gist(text: str, n: int = GIST) -> str:
    """A complaint in the player's own words, for the note: without the "Hey DM," it opened on."""
    t = re.sub(r"\s+", " ", ADDRESSED.sub("", text or "", count=1)).strip(" ,:.!-()")
    return t if len(t) <= n else t[:n].rsplit(" ", 1)[0] + " ..."


def check(game, inputs: list[tuple[str, str]] | None = None) -> dict:
    """The free check. inputs: this turn's posts (the players' own words count). Each signal comes with its evidence
    (`evidence`: (key, firm)) - what a read answers for, and whether a read may overrule it at all."""
    rows = _recent(game)
    scene = game.current_scene_id()
    now = game.conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0] or 0   # (this turn, begun)
    signals, evidence, streak = [], [], 0
    for r in rows:                                   # newest first, this scene only
        if r["scene_id"] != scene or not ends_on_ask(r["narration"]):
            break
        streak += 1
    if streak >= STREAK:
        signals.append(f"the last {streak} turns all ended with someone waiting on the players")
        evidence.append((f"streak:S{scene}:T{rows[0]['id']}", False))
    again = reasked(rows[0]["narration"], [(r["id"], r["narration"]) for r in rows[1:]]) if rows else []
    for tid, q, old in again[:2]:
        signals.append(f"T{rows[0]['id']} asks again what T{tid} asked: \"{q[:120]}\"")
        evidence.append((f"reasked:T{rows[0]['id']}:T{tid}", False))
    latest = {r["id"] for r in rows[:2]}             # (still being put: a chain that went quiet is over)
    chains = [c for c in raised(game, rows) if c["turns"][-1] in latest]
    before = _settled_before(game, now)
    for c in chains:
        # Firm, too, when the table ruled the thing settled (R19: "Pembrook's door/key/threshold question is settled...
        # NPCs don't re-raise it") or the engine already told the GM it's settled - review of flag #40: the ruling
        # was only quoted in the note, and a 'no' read kept the note from going out.
        names = set(re.findall(r"[a-z]+", c["name"].lower()))
        if not c["firm"] and (_ruled(game, c["keys"], names) or any(
                b.get("who") == c["who"] and (set(b.get("keys") or ()) & c["keys"] or set(b.get("turns") or ())
                                              & set(c["turns"])) for b in before)):
            c["firm"] = True
    for c in chains[:3]:
        signals.append(f"{c['name']} has put the same {c['kind']} ({', '.join(c['topic']) or 'the same words'}) at "
                       f"{', '.join(f'T{t}' for t in c['turns'])}, the players answering it from "
                       f"T{c['answered']['turn']}: \"{c['last'][:120]}\"")
        evidence.append((f"raised:{c['who']}:T{c['turns'][-1]}", c["firm"]))
    scene_turns = game.conn.execute("SELECT COUNT(*) FROM turns WHERE scene_id=? AND private IS NULL",
                                    (scene,)).fetchone()[0]
    if scene_turns >= LONG_SCENE and streak >= 3 and streak < STREAK:
        signals.append(f"{scene_turns} turns in this scene, the last {streak} ending on a question to the players")
        evidence.append((f"long:S{scene}:T{rows[0]['id']}", False))
    # each post's words are evidence once, keyed by the turn they came in: last turn's post, read again now, is old news
    posts = [(f"T{now}", " ".join(x for _, x in inputs or []), None)]
    if rows:
        posts.append((f"T{rows[0]['id']}", " ".join(x for _, x in json.loads(rows[0]["inputs"] or "[]")), None))
    posts += [(f"heard:T{now}:{i}", h["text"], h) for i, h in enumerate(_heard(game))]
    loop, maybe, impatient = set(), set(), set()
    npcs = _npc_words(game)
    for where, text, h in posts:
        s = said(text, npcs)
        if h and h.get("said_so") and not s["loop"]:
            s["loop"] = [_gist(text)]                # (the GM's aside judged it a loop complaint: their words)
        if not s["loop"] and chains and any(ANSWERED.search(x) for x in s["maybe"]):
            # "I told you, I can't know what Pembrook will do" while an NPC is still putting the thing she's put
            # before (flag #39): the player saying they've answered it is a complaint about that chain
            s["loop"], s["maybe"] = s["maybe"], []
        if s["loop"]:
            loop |= set(s["loop"]) | set(s["maybe"])     # (a complaint's other loop words are part of it: T150)
            evidence.append((f"said:{where}:{'|'.join(s['loop'])}", True))
        elif s["maybe"]:
            maybe |= set(s["maybe"])
            evidence.append((f"maybe:{where}:{'|'.join(s['maybe'])}", False))
        if s["impatient"]:
            impatient |= set(s["impatient"])
            evidence.append((f"impatient:{where}:{'|'.join(s['impatient'])}", False))
    if loop:
        signals.append("the players say so: " + ", ".join(f'"{h}"' for h in sorted(loop)))
    if maybe:
        signals.append("the players' words may say so - or be their characters talking: "
                       + ", ".join(f'"{h}"' for h in sorted(maybe)))
    if impatient:
        signals.append("the players sound impatient: " + ", ".join(f'"{h}"' for h in sorted(impatient)))
    open_asks = []
    if rows:                                         # what the last turn left waiting on the players
        for s in speech(game, rows[0]["narration"] or ""):
            if s["asks"]:
                open_asks.append({"turn": rows[0]["id"], "who": s["who"], "name": s["name"],
                                  "ask": " ".join(s["asks"][-2:]), "keys": set(_keys(s["said"], s["names"]))})
    return {"tripped": bool(signals), "signals": signals, "streak": streak, "scene_turns": scene_turns,
            "reasked": again, "raised": chains, "said": sorted(loop), "maybe": sorted(maybe), "open": open_asks,
            "evidence": evidence}


# ── what's settled ─────────────────────────────────────────────────────
def _settled_line(c: dict) -> str:
    """A re-raised question as the GM should act on it: named, with when it was put and answered - it's closed."""
    n, again = c["name"], c["turns"][1:]
    about = f" about the {'/'.join(c['topic'])}" if c["topic"] else ""
    when = ", ".join(f"T{t}" for t in again[:-1]) + (" and " if len(again) > 1 else "") + f"T{again[-1]}"
    answered = (f"{c['answered']['by']} answered it at T{c['answered']['turn']}, " if c["answered"]["turn"] else "")
    return (f"Settled: {n}'s {c['kind']}{about}. {n} put it at T{c['turns'][0]} (\"{c['first'][:140]}\"), "
            f"{answered}and {n} has raised it again at {when} (last: \"{c['last'][:140]}\"). It's closed: {n} takes "
            "the answer given - or lets it go - and acts on it; nobody asks it again. Move the scene on.")


def _about(text: str, keys: set[str], names: set[str]) -> bool:
    """Whether a ruling or a canon line is about the same thing: SHARED of its words, or one and the NPC's name."""
    k = set(_keys(text))
    shared = k & keys
    return len(shared) >= SHARED or bool(shared and set(re.findall(r"[a-z]+", text.lower())) & names)


def _ruled(game, keys: set[str], names: set[str]) -> bool:
    """Whether an active table ruling settles the thing (R19: "Pembrook's door/key/threshold question is settled")."""
    from .. import rulings
    return any(SETTLING.search(r["text"]) and _about(r["text"], keys, names) for r in rulings.active(game))


def _settled_before(game, now: int) -> list[dict]:
    """The chains a PACING note has already named settled ({who, keys, turns, turn}), the last SEEN_FOR turns."""
    try:
        got = json.loads(game.ledger.meta(SETTLED) or "[]")
    except ValueError:
        return []
    return [b for b in got if isinstance(b, dict) and isinstance(b.get("turn"), int) and now - b["turn"] <= SEEN_FOR]


def _remember_settled(game, chk: dict, note: str, now: int) -> None:
    """The chains this note named settled: a later go at one is firm, whatever its words (flag #40)."""
    named = [c for c in chk.get("raised") or [] if f"Settled: {c['name']}'s" in note]
    if not named:
        return
    keep = _settled_before(game, now) + [{"who": c["who"], "keys": sorted(c["keys"]), "turns": c["turns"], "turn": now}
                                         for c in named]
    game.ledger.set_meta(SETTLED, json.dumps(keep[-6:]))


def _on_file(game, keys: set[str], names: set[str]) -> list[str]:
    """What the record already has settled about the same thing: a table ruling that settles it (R19 for Greta's door),
    the canon's SETTLED list, the scene frame's 'settled with the crew'."""
    from .. import rulings
    from . import canon, frame
    out = []

    def same(text: str) -> bool:
        k = set(_keys(text))
        shared = k & keys
        return len(shared) >= SHARED or bool(shared and set(re.findall(r"[a-z]+", text.lower())) & names)
    for r in rulings.active(game):
        if SETTLING.search(r["text"]) and same(r["text"]):
            out.append(f"The table ruled it settled ({r['id']}: \"{r['text'][:160]}\").")
    for s in (canon.current(game) or {}).get("settled") or []:
        if isinstance(s, dict) and same(s.get("what", "")):
            out.append(f"The canon has it settled since {s.get('since') or 'earlier'}: \"{s['what'][:160]}\".")
    try:
        people = (frame.current(game) or {}).get("people") or []
    except Exception:                                    # (no scene: nothing framed)
        people = []
    for p in people:
        if set(re.findall(r"[a-z]+", str(p.get("id", "")).lower())) & names:
            for s in p.get("settled") or []:
                if set(_keys(s)) & keys:
                    out.append(f"The scene frame has it settled with the crew: \"{s[:160]}\".")
    return out[:2]


GENERIC = ("Close the exchange that's open: the NPCs accept what's already been answered and act on it - no new "
           "conditions, no re-asking - then move the story to its next beat.")


def compose(game, chk: dict, d: dict | None = None, sure: bool = False) -> str:
    """The PACING note: what the players said, what's settled (by name and turn), the read's move if it saw one. A
    question put only twice is named settled when it's sure to be a loop - the players or the read say so, or a
    player's !stuck - else only a firm third go is (the first go's own question, put again)."""
    parts = []
    if chk.get("said"):
        parts.append("The players say the story is going in circles (" + ", ".join(f'"{h}"' for h in chk["said"])
                     + ") - take them at their word.")
    sure = bool(sure or chk.get("said") or (d and d.get("looping")))
    chains = [c for c in chk.get("raised") or [] if sure or c.get("firm")][:2]
    for c in chains:
        parts.append(_settled_line(c))
        parts += _on_file(game, c["keys"], set(re.findall(r"[a-z]+", c["name"].lower())))
    if sure and not chains:
        for o in (chk.get("open") or [])[:2]:
            parts.append(f"Open at the end of T{o['turn']}: {o['name']}'s \"{o['ask'][:200]}\" - the players' post "
                         "answers it or passes it by: take that and move on; nobody asks it again.")
            parts += _on_file(game, o["keys"], set(re.findall(r"[a-z]+", o["name"].lower())))
    if d and d.get("looping"):
        parts.append(f"{d['what']} {d['break_it']}".strip())
    elif not chains:
        parts.append(GENERIC)
    return " ".join(p for p in parts if p)


def light(chk: dict) -> str:
    """The light note (LIGHT): the players' soft words, and what the last turn left open - theirs to answer or pass."""
    words = ", ".join(f'"{h}"' for h in chk.get("maybe") or [])
    opens = " ".join(f"Open at the end of T{o['turn']}: {o['name']}'s \"{o['ask'][:200]}\"." for o in chk["open"][:2])
    return (f"A player's words may say the story is going in circles ({words}) - the engine's read doesn't think so, "
            f"so it's your call. {opens} If their post answers it or passes it by, take that and move on - nobody "
            "asks it again.")


def diagnose(game, chk: dict, why: str = "") -> dict | None:
    """The model read: what's repeating, and the move that breaks it. None if it can't say."""
    rows = list(reversed(_recent(game)))
    if not rows:
        return None
    parts = []
    for r in rows:
        s = game.conn.execute("SELECT text FROM nodes WHERE id=?", (f"T{r['id']}",)).fetchone()
        said_ = " / ".join(f"{h}: {x[:220]}" for h, x in json.loads(r["inputs"] or "[]"))
        parts.append(f"T{r['id']} (scene {r['scene_id']})\n  players: {said_}\n  what happened: "
                     f"{(s['text'] if s else (r['narration'] or '')[:400])}\n  ended: {last_sentence(r['narration'])[:220]}")
    given = ("The players themselves say it's looping - take that as given and say what they're stuck on.\n"
             if chk.get("said") else
             "Some of the players' words may be a loop complaint - or their characters talking (\"I told you, we go at "
             "dawn\"): judge which from the turns.\n" if chk.get("maybe") else "")
    user = ("PACING REVIEW\n" + ("Why you're asked: " + "; ".join(chk.get("signals") or []) + (f"; {why}" if why else "")
                                 + "\n" + given + "\n")
            + "RECENT TURNS (oldest first):\n" + "\n".join(parts))
    try:
        data = game.llm.structured(game.settings.models.commit, SYSTEM, user, schema(), max_tokens=700,
                                   effort="low", purpose="pacing")
    except Exception as exc:
        print(f"[pacing] the check failed: {exc}", flush=True)
        return None
    return {"looping": bool(data.get("looping")), "what": (data.get("what") or "").strip(),
            "break_it": (data.get("break_it") or "").strip()}


def _seen(game, turn: int) -> dict[str, int]:
    try:
        seen = json.loads(game.ledger.meta(SEEN) or "{}")
    except ValueError:
        seen = {}
    return {k: v for k, v in seen.items() if isinstance(v, int) and turn - v <= SEEN_FOR}


def pre_turn(game, inputs: list[tuple[str, str]]) -> str | None:
    """At the start of a public turn: the PACING note for the GM, if the story's looping (else None).

    A read answers for the evidence it read (`SEEN`), and only that: a 'no' never silences a new trip on a later turn
    (live T145: one 'no' kept T146 and T147 quiet). Firm evidence - the players saying it loops, an NPC's third go at a
    question the players answered twice - reaches the GM whatever the read says (live T158)."""
    L = game.ledger
    forced = L.meta(FORCED) or ""
    turn = (game.conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0] or 0)
    chk = check(game, inputs)
    seen = _seen(game, turn)
    fresh = [(k, firm) for k, firm in chk["evidence"] if k not in seen]
    seen.update({k: turn for k, _ in chk["evidence"]})
    L.set_meta(SEEN, json.dumps(seen))
    L.set_meta(HEARD, "")                            # (the aside's complaints: weighed in this check)
    if forced:                                       # !stuck already read it - use what it found
        L.set_meta(FORCED, "")
        return forced
    if not chk["tripped"] or not fresh:
        return None                                  # (nothing tripped, or nothing new since the last read)
    firm = any(f for _, f in fresh)
    game.progress("🔁 checking the pacing", "pacing")
    d = diagnose(game, chk)
    # (no read: a streak is plain enough at STREAK + 2 - at STREAK when an NPC is putting the same thing again,
    # review of flag #40: a failed read at T147 needed a streak of 6, the chain had 5)
    plain = d is None and chk["streak"] >= (STREAK if chk.get("raised") else STREAK + 2)
    if d and d["looping"]:
        note = compose(game, chk, d)
    elif firm or plain:
        note = compose(game, chk)                    # (the players said so, or it's settled - or no read, but plain)
    elif chk.get("maybe") and chk.get("open") and any(k.startswith("maybe:") for k, _ in fresh):
        # A player's soft words, a 'no' read: still a light word on what the last turn left open - never nothing
        # (review of flag #45: "Juno keeps asking for a straight answer" read 'no', and the GM got nothing). No
        # loop flag: the read didn't see one.
        note = LIGHT + light(chk)
        L.set_meta(NOTE, note)
        return note
    else:
        L.set_meta(NOTE, "")
        return None
    L.set_meta(NOTE, note)
    _remember_settled(game, chk, note, turn)
    from .. import flags
    why = ("" if d and d["looping"] else " [firm: the players said so]" if chk["said"] else
           " [firm: put a third time]" if firm else " [no read]")
    # (filed under this turn - begun before the check - not the next one, as it was)
    flags.record(game, "engine", "loop", f"{note} [signals: {'; '.join(chk['signals'])}]{why}", turn=turn)
    return note


def heard(game, who: str, text: str, judged: bool | None = None, drop: bool = False) -> list[str]:
    """Table talk the aside took instead of a turn (live T158: a player saying the teamwork check broke and the GM
    was looping again is a META post now, so no turn's check would ever see it). A loop complaint in it waits for the
    next turn's check, where it's decisive like one in a post. Returns what the next turn will hear ([]: nothing).

    judged: the GM aside's own read of it (`loop` in its answer). The aside promises the table "the next turn closes
    it", and the words alone missed most ways of saying so (review, 2026-10-27: "hey dm Kaz is looping", "the NPCs keep
    asking for a straight answer" - flag #45's own wording - reached nothing). True: a loop complaint whatever the
    words, decisive. False: only firm words stay - a soft "I told you" was the aside's to judge, and it said no. None
    (before it answers, or if it fails): the words decide, firm decisive, soft worth a read. drop: it was a move after
    all - the turn reads the post itself."""
    s = said(text)
    entry = {"who": who, "text": (text or "")[:HEARD_TEXT]}
    before = _heard(game)
    pending = [h for h in before if h.get("text") != entry["text"]]
    hits = [] if drop else s["loop"] + (s["maybe"] if judged is not False else [])
    if judged and not drop:
        entry["said_so"] = True
        hits = hits or [_gist(text)]
    if hits:
        pending.append(entry)
    pending = pending[-HEARD_KEPT:]
    if pending != before:
        game.ledger.set_meta(HEARD, json.dumps(pending) if pending else "")
    return hits


def keep(conn):
    """Call before an undo restores a snapshot, then call what this returns. What the table said between turns is the
    table's, not the turn's (as rulings.keep and narrative.keep): a loop complaint to the GM after the turn it's about
    (`pacing_heard`) and a !stuck read (`pacing_forced`) are put back - review (2026-10-27): "Hey DM, that's another
    loop", then !undo, and the redo heard nothing. What the undone turn used up comes back with the snapshot."""
    def meta(key: str) -> str:
        row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return (row[0] if row else "") or ""
    now_heard, now_forced = meta(HEARD), meta(FORCED)

    def put_back() -> None:
        try:
            was = json.loads(meta(HEARD) or "[]")
            new = json.loads(now_heard or "[]")
        except ValueError:
            was, new = [], []
        texts = {h.get("text") for h in new}
        merged = ([h for h in was if h.get("text") not in texts] + new)[-HEARD_KEPT:]
        conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)", (HEARD, json.dumps(merged) if merged else ""))
        if now_forced:                                   # (a !stuck since: the redo gets it, as the turn would have)
            conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)", (FORCED, now_forced))
    return put_back


def player_says_stuck(game, who: str, text: str = "") -> dict:
    """!stuck: a player feels the story looping. Read it now (no turn spent); the next turn gets the nudge either way -
    the player's feeling counts even when the model doesn't see a loop."""
    chk = check(game, [(who, text)] if text else [])
    d = diagnose(game, chk, why=f"a player ({who}) says the story is stuck" + (f": {text}" if text else ""))
    looping = bool(d and d["looping"])
    note = compose(game, chk, d, sure=True)
    if not chk["said"]:
        note = f"A player feels the story is going in circles. {note}"
    game.ledger.set_meta(FORCED, note)
    from .. import flags
    flags.record(game, "player", "loop report", (text or "the story feels stuck") + f" -> {note}", who=who,
                 turn=(game.conn.execute("SELECT COALESCE(MAX(id), 0) FROM turns").fetchone()[0] or 0) + 1)
    return {"looping": looping, "what": d["what"] if d else "", "break_it": d["break_it"] if d else "",
            "note": note, "signals": chk["signals"]}
