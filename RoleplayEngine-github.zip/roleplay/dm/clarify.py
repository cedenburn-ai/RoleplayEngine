"""Clarifications (DESIGN.md §8a): fold a node's pile of GM notes into one current picture.

Notes are append-only and the packet can only show a few per subject, so a busy NPC's oldest notes -
often the promises and deadlines - fall out of view. A clarification (C#) is the GM's notebook page on
one node: everything still true or still pending, rewritten as of now. It supersedes the previous page
(the diode keeps the history) and the packet stops repeating the notes it folded.

The GM writes one whenever it wants (the clarify tool, or `clarify <id>:` in the <dm> block). At scene
close - and every few turns in a long scene - a cheap pass folds any node with a stack of new notes.
"""
from __future__ import annotations
from .llm import fan_out
from .prompts import FICTION_NOTE

FOLD_SYSTEM = FICTION_NOTE + """ You keep a tabletop game master's private notebook tidy. You get the current notebook page \
for one character, place or thing (it may be empty) and the GM notes written since, oldest first. Write the NEW \
page: what is true and pending NOW, present tense, 40-110 words, plain sentences. Keep everything still true or \
still pending - secrets, motives, promises, debts, deadlines and times, plans, attitudes, who knows what. Drop \
what was resolved or overtaken (a later note wins over an earlier one). No preamble, no headings - just the page."""

MIN_NOTES = 3          # a node needs this many unfolded notes before the automatic pass folds them
PER_PASS = 4           # nodes folded per pass (busiest first)


def candidates(game, scene_id: int) -> list[tuple[str, list[dict]]]:
    """Nodes from this scene (its slices' members, its roster, the scene itself) with notes to fold."""
    S, L = game.sub, game.ledger
    ids = {r["node_id"] for r in game.conn.execute(
        "SELECT DISTINCT m.node_id FROM members m JOIN nodes s ON s.id=m.slice_id WHERE s.scene_id=?", (scene_id,))}
    ids |= set(L.roster(scene_id)) | {f"S{scene_id}"}
    out = []
    for eid in ids:
        notes = S.notes_for(eid, 30, unfolded=True)
        if len(notes) >= MIN_NOTES:
            out.append((eid, notes))
    out.sort(key=lambda p: -len(p[1]))
    return out[:PER_PASS]


def _prompt(game, eid: str, notes: list[dict]) -> str:
    S, L = game.sub, game.ledger
    ent = L.get(eid)
    node = S.node(eid)
    head = (f"{ent['name']} ({ent['kind']}): {ent['description']}" if ent
            else f"[{eid}] ({node['kind'] if node else '?'}) {(node or {}).get('text', '')[:300]}")
    old = S.clarification(eid)
    return (f"{head}\n\nCURRENT PAGE: {old['text'] if old else '(none yet)'}\n\nNOTES SINCE (oldest first):\n"
            + "\n".join(f"- [{n['id']}] (T{n['created_turn']}) {n['text']}" for n in reversed(notes)))


def _write(game, user: str) -> str:
    return game.llm.text(game.settings.models.commit, FOLD_SYSTEM, user, max_tokens=2500,
                         effort=game.settings.models.commit_effort, purpose="notes").strip()


def fold(game, eid: str, notes: list[dict], turn: int) -> str | None:
    text = _write(game, _prompt(game, eid, notes))
    return game.sub.clarify(eid, text, turn, by="fold") if text else None


def fold_scene(game, scene_id: int, turn: int) -> list[str]:
    """The automatic pass, its pages written side by side. A failure here never costs the turn - the notes are
    still there."""
    todo = [(eid, _prompt(game, eid, notes)) for eid, notes in candidates(game, scene_id)]
    made = []
    for (eid, _), text in zip(todo, fan_out(lambda user: _write(game, user), [u for _, u in todo])):
        try:
            if isinstance(text, Exception):
                raise text
            cid = game.sub.clarify(eid, text, turn, by="fold") if text else None
        except Exception as exc:
            game.out(f"  (clarify: couldn't fold {eid}'s notes - {exc})")
            continue
        if cid:
            made.append(cid)
    if made:
        game.out(f"[CLARIFY] folded notes into {', '.join(made)}")
    return made
