"""The offscreen world (DESIGN.md §12): NPCs and factions with personas and agendas who act between scenes.

After each turn, in the background (never on the hot path):
  plan  (game thread) - who needs a persona; which offscreen actors have something to react to
                        (a theft they didn't see, an injury, a rumor, strong feelings, being left
                        behind, someone reaching out to them, a member hurt) or an agenda that's due
                        on the story clock
  think (any thread)  - one Haiku call per actor: write their bible, or decide their next move
  apply (game thread) - the engine validates every proposal: real dice for uncertain steps, real
                        nuyen for costs, hidden truth only on a success. Each step is an offscreen
                        time slice (W#) only its actors witnessed, hung off its agenda (A#). Reaching
                        out to someone is its own slice the other side witnessed too, carries hearsay,
                        and wakes them next pass. Consequences that could reach the players become
                        hooks (H#) the DM lands when the story allows.
Factions (gangs, corps, Lone Star) are actors too: they act through their members and hires, and their
tests roll reach x2. Nothing here posts to the table: the DM sees it in the packet; the players feel it.
"""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field

from .. import rulings
from ..engine import clock, geo
from ..engine.rules import sr_lite
from ..substrate.packet import slice_line
from . import spoilers
from .prompts import FICTION_NOTE

MAX_READY_HOOKS = 2                       # per actor; older ones go stale
MAX_CONTACTS = 3                          # people one step can reach
MIN_WAIT, MAX_WAIT = 5, 7 * clock.DAY     # story minutes between an agenda's moves


def wait_turns(minutes: int) -> int:
    """Story time doesn't tick by itself any more, so a wait is also counted in turns: a short one comes round in a
    turn or two, an overnight one in several - or as soon as the GM moves the clock past it, whichever is first."""
    return max(1, min(8, round(minutes / 120) or 1))
ACTORS = ("npc", "faction")

PERSONA_FIELDS = ("temperament", "motivations", "lines", "prejudices", "voice", "backstory", "hooks",
                  "connections", "secret", "affiliations")
FACTION_FIELDS = ("summary", "wants", "methods", "resources", "territory", "leadership", "rivals", "secret",
                  "reach", "funds")

PERSONA_SYSTEM = """You are a game master's prep assistant for a Shadowrun-style tabletop campaign. Write the \
private character bible for one NPC so the GM can play them consistently over a long campaign, and so their \
offscreen mind knows who they are. Everything must fit what is already established - description, stats, facts, \
the GM's notes (their secrets), and what they've done on screen. Never contradict it; add depth, not changes.

Make them specific and playable, with texture: a real temperament (how they react under pressure, what sets them \
off), what they want, what they fear or won't do, prejudices and loyalties (Sixth World: metatypes, corps, magic, \
the Matrix, gangs, Lone Star), how they talk, a short backstory with one or two loose threads the GM could pull on \
later, who they could call on (contacts, favors, muscle), and a secret if it fits. ONE short sentence per field \
(under 25 words), at most two threads. Third person, present tense. This rides in the GM's notes every time they \
appear, so every word should help play them.

affiliations: organizations they CURRENTLY belong to or work for - a gang, corp, police force, syndicate, crew - \
with their role in it ("ganger", "security operative", "informant"). Not former employers, not loose social \
circles or regulars. Usually zero or one. Use the organization's plain name ("Ancients", "Lone Star", "Renraku")."""

FACTION_SYSTEM = """You are a game master's prep assistant for a Shadowrun-style tabletop campaign. Write the \
private profile of one organization (a gang, corp, agency, syndicate or crew) so the GM can run it as a living \
actor: what it wants, how it operates, what it can bring to bear. Fit everything established about it and its \
members; add depth, not contradictions. One short sentence per field (under 25 words).

summary: what it is, in one line. reach: 1 a small crew, 2 a street gang, 3 a big gang or syndicate cell, 4 a \
city-wide syndicate or a Lone Star precinct, 5 Lone Star Seattle or a corp division, 6 a megacorporation. funds: \
nuyen it can realistically spend on street-level business like this (a gang a few thousand, a precinct tens of \
thousands, a corp division far more)."""

AGENT_SYSTEM = FICTION_NOTE + """ You are the offscreen mind of one NPC - or one organization - in a Shadowrun tabletop campaign, \
and the GM's assistant for what they do while the player characters aren't looking. The world keeps moving; \
decide what they do next, true to their persona and to what they actually know.

- They know only what they witnessed, heard, or discovered. HIDDEN TRUTH is listed so investigations resolve \
fairly: they do NOT know it. Only a successful step that could plausibly uncover it reveals it - then list those \
ids in learns_on_success.
- Be proportionate and in character. Many things aren't worth chasing, and decision "none" is often right. A \
missing commlink might be worth asking around, checking the cameras, calling in a favor - and if they find out who \
took it, a grudge that grows. Escalation follows from success and temperament, one step at a time.
- STORY TIME says what time it is and how long since their last move. One concrete step, achievable in that time \
and plausible at that hour (fixers sleep, shops close, a city-wide search takes hours). Third person, past tense, \
naming them.
- Uncertain steps get a test: a skill from the list and a threshold (1 easy, 2 average, 3 hard, 4 very hard). The \
engine rolls their real dice pool. Write on_success and on_failure as the memory of how it went (under 40 words \
each). No test: test_skill "" and on_success is what happened.
- Money is real: spend only nuyen they have. Hired help costs (street muscle 200-500 nuyen a head, elite operatives \
2,000+). Favors and threats cost nothing but carry risk.
- new_people: anyone they bring in (hired muscle, a fixer, a recruit) - name, short description, and the template \
from TEMPLATES that fits who they are: a doctor, lawyer, researcher or corporate specialist is expert, an ordinary \
person civilian. Only operative comes armed for war - it's for hired combat professionals. A newcomer's name and \
description are public the moment they're filed: never a real name or secret from GM NOTES ABOUT YOU in them.
- THINGS IN PLAY is the ledger: who holds what, and it is authoritative. Never claim to have taken, found or \
recovered an item unless you list it in acquire. acquire works only on items no player character holds - what the \
player characters carry can change hands only on screen, so make that a hook.
- whereabouts: where anyone this step physically moved ends up (yourself, your members, people you brought in) - \
"in Renraku's van heading for the arcology" - with place = the id of a known location or a district from PLACES \
(or ""). Leave it empty if nobody moved. WHERE YOU ARE says where they are now.
- Story time is narrative (a day and a part of it). Getting somewhere takes as long as the story needs - nobody \
counts minutes, so don't invent deadlines or countdowns.
- TABLE RULES are the players' own house rulings, and they outrank everything else you're shown - memories, notes, \
goals, hooks. Never plan around a time or deadline they rule out, never revive a storyline they closed, and never \
re-open what they settled; a goal of yours that does is over (decision "drop").
- People marked ON SCREEN are with the player characters right now and the GM is playing them: you can send them \
a message (a contact), but never narrate what they do, where they go or what happens to them.
- Never invent facts about the player characters - where they are, what they carry, who they are working for. A \
success can reveal what HIDDEN TRUTH shows; anything beyond that is a guess or a rumor, and the memory must say so.
- contacts: who they reach out to in this step - a call, a meeting, a message, an order to their own people. who = \
an id from PEOPLE YOU KNOW OF or ORGANIZATIONS, or for someone new a real name ("Benny Farrow") with description \
saying who they are and the template from TEMPLATES that fits them, as for new_people: contact is only a fixer, \
informant or broker - a nurse, doctor or lawyer is expert, a relative or a clerk civilian (for someone already known \
or a faction the template is ignored); kind npc or faction; says = what they tell or ask, in a sentence or two; \
shares = ids from WHAT YOU REMEMBER or WHAT YOU HEARD that they pass along. The other side hears it and may act on \
it. Never a \
player character - reaching a PC is a hook. Not every message needs an answer: if one just confirms or \
acknowledges, let it be.
- hook: if this step sets up something that could reach the player characters - someone coming for them, an offer, \
a trap, a warning, a favor, a door opening - tell the GM in one or two sentences: who, what, and when or where it \
could land. Hooks are how the world surprises the players; make them concrete and fair. hook_about = the ids it \
would land on. Empty if none.
- YOUR PENDING HOOKS are already queued for the GM. Don't repeat one; if this step changes or supersedes one, put \
its id in hook_replaces.
- feeling: if this changes how they feel about someone, give that id, an attitude from -3 to +3 and a one-sentence \
belief ("Kaz thinks Razor ..."). Otherwise feeling_about "".
- Waiting is a move: to hold position or wait for an answer, decision "continue" with action "" and wait_minutes - \
don't narrate "kept waiting" as a step.
- wait_minutes: roughly how long until their next move: 30 (soon), 240 (later today), 600 (overnight), 1440 (a \
day) or more. A short wait comes round in a turn or two; a long one when the story's day gets there.
- decision: none (let it go / nothing to do), start (a new agenda - give goal and targets), continue (an agenda \
they have - give agenda_id), done (achieved it, with a final step), drop (giving up)."""

FACTION_NOTE = """You are an ORGANIZATION, not one person. You act through people: send your members (a contact \
whose who is a member and whose says is their orders), or hire and recruit (new_people join you). Any test rolls \
your reach (reach x2 dice) - name the kind of effort in test_skill. Spend from your funds."""


def persona_schema() -> dict:
    s = {"type": "string"}
    props = {f: s for f in PERSONA_FIELDS}
    props["hooks"] = {"type": "array", "items": s}
    props["affiliations"] = {"type": "array", "items": {
        "type": "object", "properties": {"name": s, "role": s}, "required": ["name", "role"],
        "additionalProperties": False}}
    return {"type": "object", "properties": props, "required": list(PERSONA_FIELDS), "additionalProperties": False}


def faction_schema() -> dict:
    props = {f: {"type": "string"} for f in FACTION_FIELDS}
    props["reach"] = props["funds"] = {"type": "integer"}
    return {"type": "object", "properties": props, "required": list(FACTION_FIELDS), "additionalProperties": False}


def agent_schema() -> dict:
    s, i = {"type": "string"}, {"type": "integer"}
    ids = {"type": "array", "items": s}
    # (the template is one the engine has: a free word fell back to the armed operative block - flag #33, T113)
    person = {"type": "object", "properties": {"name": s, "description": s,
                                               "template": {"type": "string", "enum": list(sr_lite.NPC_TEMPLATES)}},
              "required": ["name", "description", "template"], "additionalProperties": False}
    # (someone new they reach gets a template too: every one came out of the armed 'contact' block - a night nurse, a
    # legal-aid advocate, a street doc each with a hold-out pistol; review 2026-10-27, flag #33)
    contact = {"type": "object", "properties": {"who": s, "kind": {"type": "string", "enum": ["npc", "faction"]},
                                                "says": s, "shares": ids, "description": s,
                                                "template": {"type": "string", "enum": list(sr_lite.NPC_TEMPLATES)}},
               "required": ["who", "kind", "says", "shares", "description", "template"], "additionalProperties": False}
    where = {"type": "object", "properties": {"who": s, "where": s, "place": s},
             "required": ["who", "where", "place"], "additionalProperties": False}
    props = {"decision": {"type": "string", "enum": ["none", "start", "continue", "done", "drop"]},
             "agenda_id": s, "goal": s, "targets": ids, "action": s, "test_skill": s, "test_threshold": i,
             "on_success": s, "on_failure": s, "learns_on_success": ids, "spend": i,
             "new_people": {"type": "array", "items": person}, "contacts": {"type": "array", "items": contact},
             "acquire": ids, "whereabouts": {"type": "array", "items": where},
             "hook": s, "hook_about": ids, "hook_replaces": ids,
             "feeling_about": s, "feeling_attitude": i, "feeling_belief": s, "wait_minutes": i}
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


@dataclass
class Job:
    kind: str                                  # persona | faction_persona | agent
    npc: str                                   # the actor (an NPC or a faction)
    user: str
    turn: int
    truth: list[str] = field(default_factory=list)       # hidden slices a success may reveal
    agendas: list[str] = field(default_factory=list)     # the actor's active agendas
    known: list[str] = field(default_factory=list)       # memories they may pass along
    inbox: list[int] = field(default_factory=list)       # messages this move answers
    things: list[str] = field(default_factory=list)      # items shown with their holders
    seq: int | None = None                               # the event log as of planning


def enabled(game) -> bool:
    return game.ledger.meta("world", "on") == "on"


def persona(ent: dict | None) -> dict | None:
    return (ent or {}).get("props", {}).get("persona")


def _clip(v, n: int = 240) -> str:
    v = (v or "").strip() if isinstance(v, str) else str(v or "")
    return v if len(v) <= n else v[:n - 10].rsplit(" ", 1)[0] + "..."


def _public(game, text, turn: int) -> str:
    """A description the world files, in the names the crew knows: it's public by birth (the dashboard's people, the
    art's story, !dossier), and the model that wrote it read the actor's GM notes - review 2026-10-28."""
    return spoilers.answer(game, _clip(text, 2000), "The offscreen world's description", turn,
                           "scrubbed before it was filed")


def persona_line(ent: dict) -> str | None:
    """The bible in one paragraph - it rides in the packet whenever they're on stage."""
    p = persona(ent)
    if not p:
        return None
    if ent["kind"] == "faction":
        parts = [_clip(p.get("summary")), f"Wants: {_clip(p.get('wants'))}", f"Methods: {_clip(p.get('methods'))}",
                 f"Resources: {_clip(p.get('resources'))}", f"Turf: {_clip(p.get('territory'))}",
                 f"Leaders: {_clip(p.get('leadership'))}", f"Rivals: {_clip(p.get('rivals'))}",
                 f"Secret: {_clip(p.get('secret'))}"]
    else:
        threads = "; ".join(h.strip().rstrip(".") for h in (p.get("hooks") or [])[:2])
        groups = ", ".join(f"{a['name']} ({a['role']})" for a in (p.get("affiliations") or []) if a.get("name"))
        parts = [_clip(p.get("temperament")), f"Wants: {_clip(p.get('motivations'))}", f"Won't: {_clip(p.get('lines'))}",
                 f"Prejudices: {_clip(p.get('prejudices'))}", f"Voice: {_clip(p.get('voice'))}",
                 f"Backstory: {_clip(p.get('backstory'))}", f"Threads: {threads}",
                 f"Can call on: {_clip(p.get('connections'))}", f"Member of: {groups}", f"Secret: {_clip(p.get('secret'))}"]
    return " ".join(x for x in parts if x and not x.rstrip().endswith(":"))


# ── factions ────────────────────────────────────────────────────────────

def ensure_faction(game, name: str, turn: int) -> str | None:
    """Find an organization by name, or bring it into the world (its profile is written next pass)."""
    raw = (name or "").strip()
    plain = raw[4:].strip() if raw.lower().startswith("the ") else raw
    if not plain:
        return None
    ent = game.ledger.find(plain) or game.ledger.find(raw)
    if ent:
        return ent["id"] if ent["kind"] == "faction" else None
    slip = spoilers.hits(game, raw)
    if slip:                # a name the table hasn't learned: the outfit it's the GM's name for, never a new public one
        return next((o for _, o in slip if o and (game.ledger.get(o) or {}).get("kind") == "faction"), None)
    eid, _ = game.introduce("faction", plain, "", aliases=[f"the {plain}"], turn=turn)
    return eid


def join_faction(game, npc: str, faction: str, role: str, turn: int) -> None:
    L, S = game.ledger, game.sub
    f = L.require(faction)
    S.ensure_entity(L.require(npc), turn)
    S.ensure_entity(f, turn)
    S.link(npc, faction, "member_of", 2.0, turn)
    roster = dict(f["props"].get("members") or {})
    roster[npc] = role or roster.get(npc) or "member"
    L.update_entity(faction, props={**f["props"], "members": roster})


def members_of(game, faction: str) -> list[tuple[dict, str]]:
    f = game.ledger.get(faction)
    out = []
    for eid, role in ((f or {}).get("props", {}).get("members") or {}).items():
        e = game.ledger.get(eid)
        if e and e["status"] == "active":
            out.append((e, role))
    return out


def factions_of(game, npc: str) -> list[tuple[dict, str]]:
    out = []
    for link in game.sub.links_of(npc):
        f = game.ledger.get(link["other"]) if link["kind"] == "member_of" else None
        if f and f["kind"] == "faction":
            out.append((f, (f["props"].get("members") or {}).get(npc, "member")))
    return out


# ── whereabouts and things ──────────────────────────────────────────────

def whereabouts(game, eid: str) -> str | None:
    """Where an offscreen NPC is: what their last move said, else the scene they were last left in."""
    L = game.ledger
    ent = L.get(eid) or {}
    w = (ent.get("props") or {}).get("whereabouts")
    if w:
        return f"{w['where']} (since {clock.short(w['time'])})"
    sid = L.scene_of(eid)
    if sid:
        sc = L.scene(sid)
        loc = L.get(sc["location_id"]) if sc and sc["location_id"] else None
        return f"{loc['name'] if loc else sc['title']} (where they were last seen)"
    return None


def move(game, eid: str, where: str, place: str | None = None) -> None:
    """An offscreen NPC goes somewhere: they leave the parked scene they were in, so when the party comes
    back to the bar later, the man who was extracted isn't still sitting in the booth. place pins it on
    the map: a known location's id, or a district."""
    L = game.ledger
    ent = L.require(eid)
    sid = L.scene_of(eid)
    if sid and sid != game.current_scene_id():
        L.leave(sid, [eid])
    spot = L.find(place) if place else None
    pin = spot["id"] if spot and spot["kind"] == "location" else geo.district(place) or (geo.districts_in(where) or [None])[0]
    L.update_entity(eid, props={**ent["props"], "whereabouts": {"where": _clip(where, 200), "time": game.clock(),
                                                                 "place": pin}})


def _holder_line(game, item: dict) -> str:
    L = game.ledger
    holders = [L.get(h) for h in L.holders(item["id"])]
    who = ", ".join(f"{h['name']}{' (PC)' if h['kind'] == 'pc' else ''}" for h in holders if h) or "nobody / lying somewhere"
    return f"{item['name']} [{item['id']}] - held by {who}"


def things_in_play(game, eid: str, subjects: list[str], remembered: list[dict]) -> list[dict]:
    """Items this actor has reason to think about: theirs, their members', the ones their agendas and news
    are about, and the ones in the moments they remember."""
    L, S = game.ledger, game.sub
    ids = [i["id"] for i in L.holdings(eid)]
    for m, _ in members_of(game, eid):
        ids += [i["id"] for i in L.holdings(m["id"])]
    ids += subjects
    for r in remembered:
        ids += [m for m, _ in S.members_of(r["id"])]
    items = [L.get(i) for i in dict.fromkeys(ids)]
    return [i for i in items if i and i["kind"] == "item" and i["tier"] >= 1][:8]


_STOP = {"the", "a", "an", "and", "to", "of", "his", "her", "their", "in", "on", "at", "for", "with", "while", "he",
         "she", "they", "was", "is", "it", "that", "from", "into", "kept", "still", "as", "by", "s"}


def _words(text: str) -> set[str]:
    import re
    return {w for w in re.findall(r"[a-z0-9']+", (text or "").lower()) if w not in _STOP and len(w) > 2}


def _echo(game, eid: str, text: str, threshold: float = 0.5) -> bool:
    """Does this step just repeat one of the actor's last few? (Waiting dressed up as action.)"""
    new = _words(text)
    if not new:
        return False
    for r in game.conn.execute("SELECT n.text FROM nodes n JOIN members m ON m.slice_id=n.id WHERE "
                               "n.visibility='offscreen' AND m.node_id=? AND m.role='actor' "
                               "ORDER BY n.created_turn DESC, n.rowid DESC LIMIT 3", (eid,)):
        old = _words(r["text"])
        if old and len(new & old) / len(new | old) >= threshold:
            return True
    return False


# ── agendas, hooks, messages ────────────────────────────────────────────

def add_agenda(game, npc: str, goal: str, targets, turn: int, by: str, due_in: int = 0) -> str:
    L, S = game.ledger, game.sub
    ent = L.require(npc)
    aid = S._next("A")
    S.create_node(aid, "agenda", f"{ent['name']} wants: {goal}", turn, visibility="gm")
    S.ensure_entity(ent, turn)
    S.link(aid, ent["id"], "wants", 2.0, turn)
    for x in targets:
        t = L.find(x)
        if t and t["id"] != ent["id"]:
            S.ensure_entity(t, turn)
            S.link(aid, t["id"], "about", 1.0, turn)
    game.conn.execute("INSERT INTO agendas(id, npc_id, goal, status, next_turn, next_time, created_turn, updated_turn, "
                      "by) VALUES(?,?,?,'active',?,?,?,?,?)",
                      (aid, ent["id"], goal, turn + (wait_turns(due_in) if due_in > 0 else 0),
                       game.clock() + max(0, due_in), turn, turn, by))
    return aid


def agendas_of(game, npc: str, status: str = "active") -> list[dict]:
    return [dict(r) for r in game.conn.execute(
        "SELECT * FROM agendas WHERE npc_id=? AND status=? ORDER BY created_turn", (npc, status))]


def agenda_targets(game, aid: str) -> list[str]:
    return [link["other"] for link in game.sub.links_of(aid) if link["kind"] == "about"]


def agenda_steps(game, aid: str) -> list[dict]:
    return [dict(r) for r in game.conn.execute(
        "SELECT n.* FROM nodes n JOIN links l ON (l.a=n.id AND l.b=?) OR (l.b=n.id AND l.a=?) "
        "WHERE l.kind='step' ORDER BY n.created_turn, n.rowid", (aid, aid))]


def add_hook(game, npc: str, agenda_id: str | None, text: str, about, turn: int) -> str:
    L, S = game.ledger, game.sub
    hid = S._next("H")
    S.create_node(hid, "hook", text, turn, visibility="gm")
    S.link(hid, npc, "from", 1.0, turn)
    if agenda_id:
        S.link(hid, agenda_id, "from", 1.0, turn)
    for x in about:
        t = L.find(x)
        if t:
            S.ensure_entity(t, turn)
            S.link(hid, t["id"], "about", 1.0, turn)
    game.conn.execute("INSERT INTO hooks(id, agenda_id, npc_id, status, created_turn) VALUES(?,?,?,'ready',?)",
                      (hid, agenda_id, npc, turn))
    return hid


def land_hook(game, hid: str, turn: int, how: str = "") -> bool:
    cur = game.conn.execute("UPDATE hooks SET status='landed', landed_turn=? WHERE id=? AND status='ready'",
                            (turn, hid.upper()))
    if cur.rowcount and how:
        game.sub.set_text(hid.upper(), game.sub.node(hid.upper())["text"] + f" [landed T{turn}: {how}]")
    return bool(cur.rowcount)


# The offscreen slices a goal's steps wrote (store.write_offscreen links each to its agenda, 'step').
STEP_SLICES = "SELECT CASE WHEN a=? THEN b ELSE a END FROM links WHERE kind='step' AND (a=? OR b=?)"


def retire(game, overs: list[dict], turn: int) -> list[str]:
    """Close goals (A#) and hooks (H#) a read-back found finished or overtaken - [{id, why}]. They're the engine's, so
    the frame and the canon close them themselves (live T161: Brask still had five active goals from Day 2, and three
    hooks waited to reopen a storyline the table had closed). A goal's messages still unread go with it - review of
    flag #42: A71 retired, its "before Thursday" message to Rook (W633) sat in his inbox and would wake him on the
    closed storyline at the next world pass. A tension (Q#) isn't closed: its deadline is lifted and
    the question stays open - the canon's answer to a due time a table ruling ruled out (flag #42: R11's timeline lock
    stood while Q1's noon deadline kept pressing). A job (J#) is the same: its deadline goes and the job stays (review
    2026-10-27 - THE JOB's deadline was one the engine held that nothing could lift). Returns one line per thing closed."""
    from .. import jobs
    from . import tensions
    done = []
    for o in overs:
        xid, why = str(o.get("id") or "").strip().upper(), str(o.get("why") or "").strip()
        if xid.startswith("A"):
            hit = game.conn.execute("UPDATE agendas SET status='done', updated_turn=? WHERE id=? AND status='active'",
                                    (turn, xid)).rowcount
            if hit:                                       # (and what its steps sent, still unread, wakes nobody)
                game.conn.execute(f"UPDATE world_inbox SET read=1 WHERE read=0 AND slice_id IN ({STEP_SLICES})",
                                  (xid, xid, xid))
        elif xid.startswith("H"):
            hit = game.conn.execute("UPDATE hooks SET status='stale' WHERE id=? AND status='ready'", (xid,)).rowcount
        elif xid.startswith("Q"):
            hit = tensions.lift_due(game, xid) is not None
        elif xid.startswith("J"):
            hit = jobs.lift_deadline(game, xid) is not None
        else:
            continue
        if hit:
            deadline = xid[0] in "QJ"
            game.ledger.log(turn, "retired", None, {"id": xid, "why": why, **({"what": "deadline"} if deadline else {})})
            done.append(xid + ("'s deadline" if deadline else "") + (f" ({why})" if why else ""))
    return done


def deadline_mark(game, xid: str) -> list | None:
    """A deadline the engine holds, as a read-back is shown it - a tension's [question, due time], an open job's [title,
    deadline] - or None when it holds none. The canon keeps one per deadline it lists, so a stale verdict never lifts
    one the GM moved or set while it read (review 2026-10-27: `tension Q1: ... | due day 6 evening` after the gather,
    and the read-back's `over` wiped it). The question or title is in it too: an undo hands a Q# out again."""
    from .. import jobs
    from . import tensions
    xid = (xid or "").strip().upper()
    if xid.startswith("Q"):
        t = tensions.get(game, xid)
        return [t["question"], t["due_time"]] if t and t["status"] != "resolved" and t["due_time"] is not None else None
    if xid.startswith("J"):
        j = jobs.get(game, xid)
        return [j["title"], j["deadline"]] if j and j["status"] in jobs.OPEN and (j["deadline"] or "").strip() else None
    return None


def reach_out(game, sender: str, other: str, says: str, shares, known, agenda: str | None, turn: int) -> str:
    """One actor reaches another offscreen: a slice they both witnessed, hearsay for what was passed
    along, and a message in the other's inbox that wakes them next pass."""
    L, S = game.ledger, game.sub
    a, b = L.require(sender), L.require(other)
    text = f"{a['name']} reached {b['name']}: {_clip(says, 400)}"
    wid = S.write_offscreen(turn, text, [(sender, "actor"), (other, "target")], agenda, story_time=game.clock())
    S.link(sender, other, "contact", 1.0, turn)
    for mem in shares or []:
        mem = mem.strip().upper()
        if mem in known and S.exists(mem) and not _witnessed(game, other, mem):
            S.add_knows(other, mem, "told", sender, turn)
    game.conn.execute("INSERT INTO world_inbox(npc_id, slice_id, from_id, turn) VALUES(?,?,?,?)",
                      (other, wid, sender, turn))
    return wid


def lately(game, eid: str, limit: int = 2, within: int = clock.DAY) -> list[dict]:
    """Offscreen moments this NPC lived recently (their own moves, calls they made or took)."""
    roles = game.settings.knobs.witness_roles
    rows = game.conn.execute(
        f"SELECT n.* FROM nodes n JOIN members m ON m.slice_id=n.id WHERE n.visibility='offscreen' AND m.node_id=? "
        f"AND m.role IN ({','.join('?' * len(roles))}) AND COALESCE(n.story_time, 0) >= ? "
        f"ORDER BY n.created_turn DESC, n.rowid DESC LIMIT ?", (eid, *roles, game.clock() - within, limit)).fetchall()
    return [dict(r) for r in reversed(rows)]


def section(game, subjects: set[str], turn_id: int, shown: set[str]) -> list[str]:
    """THE WORLD IN MOTION: agendas touching who/what is here, and hooks ready to land on them."""
    if not subjects:
        return []
    marks = ",".join("?" * len(subjects))
    rows = game.conn.execute(
        f"SELECT DISTINCT a.* FROM agendas a LEFT JOIN links l ON (l.a=a.id OR l.b=a.id) AND l.kind='about' "
        f"WHERE a.status='active' AND (a.npc_id IN ({marks}) OR l.a IN ({marks}) OR l.b IN ({marks})) "
        f"ORDER BY a.updated_turn DESC LIMIT 4", (*subjects, *subjects, *subjects)).fetchall()
    hooks = game.conn.execute(
        f"SELECT DISTINCT h.*, n.text FROM hooks h JOIN nodes n ON n.id=h.id JOIN links l ON (l.a=h.id OR l.b=h.id) "
        f"AND l.kind='about' WHERE h.status='ready' AND (l.a IN ({marks}) OR l.b IN ({marks})) "
        f"ORDER BY h.created_turn DESC, h.rowid DESC LIMIT 4", (*subjects, *subjects)).fetchall()
    if not rows and not hooks:
        return []
    L = game.ledger
    sc = L.current_scene()
    here_geo = geo.geo_of(game, sc["location_id"]) if sc and sc["location_id"] else None
    out = ["\n=== THE WORLD IN MOTION (offscreen - GM eyes only) ==="]
    for a in rows:
        who = L.get(a["npc_id"]) or {}
        at = whereabouts(game, a["npc_id"]) if who.get("kind") == "npc" else None
        gap = ""
        if at and here_geo and geo.geo_of(game, a["npc_id"]):
            gap = f" - {geo.describe(here_geo, geo.geo_of(game, a['npc_id']))} from here"
        tag = " (faction)" if who.get("kind") == "faction" else f" (now: {at}{gap})" if at else ""
        out.append(f"[{a['id']}] {who.get('name', a['npc_id'])}{tag} wants: {a['goal']} "
                   f"(since T{a['created_turn']}, {a['steps']} step(s))")
        steps = agenda_steps(game, a["id"])
        if steps:
            out.append("  Latest: " + slice_line(game, steps[-1], turn_id))
            shown.add(steps[-1]["id"])
        shown.add(a["id"])
    for h in hooks:
        who = (L.get(h["npc_id"]) or {}).get("name", h["npc_id"])
        out.append(f"[{h['id']}] READY HOOK (from {who}, T{h['created_turn']}): {h['text']}")
        shown.add(h["id"])
    if hooks:
        out.append("Land a hook when the story allows; then add `landed H#: how` to your <dm> block.")
    return out


# ── plan ────────────────────────────────────────────────────────────────

def _witnessed(game, eid: str, slice_id: str) -> bool:
    roles = game.settings.knobs.witness_roles
    return game.conn.execute(f"SELECT 1 FROM members WHERE slice_id=? AND node_id=? AND role IN "
                             f"({','.join('?' * len(roles))})", (slice_id, eid, *roles)).fetchone() is not None


def triggers(game, eid: str, since: int, now: int, since_seq: int | None = None) -> list[tuple[str, list[str]]]:
    """What happened to this actor since their last offscreen move: (what they'd notice, ids involved).
    Events are read by log sequence when we have it (something done to them later in the same pass still
    counts); hearsay by turn. Messages waiting in their inbox are read separately (see inbox)."""
    L, S = game.ledger, game.sub
    out: list[tuple[str, list[str]]] = []
    ent = L.get(eid) or {}
    crew = {m["id"] for m, _ in members_of(game, eid)} if ent.get("kind") == "faction" else set()
    who = (eid, *crew)
    window, args = ("seq>?", (since_seq,)) if since_seq is not None else ("turn_id>? AND turn_id<=?", (since, now))
    rows = game.conn.execute(f"SELECT * FROM events WHERE {window} AND (actor IN "
                             f"({','.join('?' * len(who))}) OR kind='scene_closed') ORDER BY seq",
                             (*args, *who)).fetchall()
    for r in rows:
        p, t = json.loads(r["payload"] or "{}"), r["turn_id"]
        if r["actor"] in crew:                                  # a faction notices what happens to its people
            if r["kind"] == "damage":
                m = L.get(r["actor"])
                out.append((f"Your {(ent['props'].get('members') or {}).get(r['actor'], 'member')} {m['name']} was "
                            f"hurt around T{t} (now {p.get('status')}).", [r["actor"]]))
            continue
        if r["kind"] == "transfer_item" and r["actor"] == eid and not _witnessed(game, eid, f"T{t}"):
            item = L.get(p.get("item", ""))
            if item and not L.holds(eid, item["id"]):
                out.append((f"Your {item['name']} is gone. It left your hands around T{t} and you didn't see it go.",
                            [item["id"], f"T{t}"]))         # (the moment it went: what an investigation can find)
        elif r["kind"] == "damage" and r["actor"] == eid:
            out.append((f"You were hurt at T{t} ({p.get('boxes')} boxes {p.get('type')} damage; now "
                        f"{p.get('status')}).", []))
        elif r["kind"] == "belief" and r["actor"] == eid and p.get("by") != "world" and abs(p.get("attitude", 0)) >= 2:
            about = L.get(p.get("about", ""))
            if about:
                out.append((f"You've come to feel strongly about {about['name']} (attitude {p['attitude']:+d}).",
                            [about["id"]]))
        elif r["kind"] == "scene_closed" and eid in p.get("left_behind", []):
            scene = L.scene(p.get("scene", 0))
            out.append((f"The player characters left \"{scene['title'] if scene else 'the scene'}\" around T{t}. "
                        "You're on your own time now.", []))
    for h in game.conn.execute("SELECT * FROM knows WHERE holder=? AND turn>? AND turn<=? AND how NOT IN "
                               "('discovered', 'told')", (eid, since, now)):
        node = S.node(h["node_id"])                             # (told-by-contact arrives with its message)
        if node:
            src = (L.get(h["source"]) or {}).get("name") if h["source"] else None
            out.append((f"You heard ({h['how']}{' via ' + src if src else ''}): {node['text'][:240]}",
                        [m for m, _ in S.members_of(node["id"]) if L.get(m)]))
    return out


def inbox(game, eid: str) -> list[dict]:
    return [dict(r) for r in game.conn.execute(
        "SELECT i.*, n.text, n.story_time FROM world_inbox i JOIN nodes n ON n.id=i.slice_id "
        "WHERE i.npc_id=? AND i.read=0 ORDER BY i.id", (eid,))]


def _truth(game, eid: str, subjects: list[str], limit: int = 4) -> list[dict]:
    """What really happened around the things this actor now cares about, which they never saw or heard.
    On-screen events only - another actor's offscreen moves are theirs to reveal."""
    subjects = [s for s in dict.fromkeys(subjects) if s and s != eid]
    if not subjects:
        return []
    marks = ",".join("?" * len(subjects))
    rows = game.conn.execute(                              # (a subject can be a moment itself: "it went at T4")
        f"SELECT DISTINCT n.* FROM nodes n LEFT JOIN members m ON m.slice_id=n.id AND m.role<>'recalled' "
        f"WHERE n.kind='slice' AND n.visibility IN ('public', 'private') "
        f"AND (m.node_id IN ({marks}) OR n.id IN ({marks})) "
        f"ORDER BY n.created_turn DESC LIMIT 30", subjects + subjects).fetchall()
    known = {r["node_id"] for r in game.conn.execute("SELECT node_id FROM knows WHERE holder=?", (eid,))}
    out = [dict(r) for r in rows if r["id"] not in known and not _witnessed(game, eid, r["id"])]
    return out[:limit]


def _persona_job(game, ent: dict, t: int) -> Job:
    L, S = game.ledger, game.sub
    eid = ent["id"]
    facts = S.facts_for(eid, 6)
    notes = S.notes_for(eid, 6)
    seen = sorted(S.witnessed_slices(eid, 30), key=lambda r: -r["created_turn"])[:6]
    beliefs = S.beliefs_of(eid)[:4]
    groups = ", ".join(e["name"] for e in L.entities(kind="faction"))
    if ent["kind"] == "faction":
        crew = members_of(game, eid)
        about = game.conn.execute("SELECT DISTINCT n.text FROM nodes n JOIN members m ON m.slice_id=n.id "
                                  "WHERE m.node_id=? AND n.visibility='public' ORDER BY n.created_turn DESC LIMIT 6",
                                  (eid,)).fetchall()
        user = (f"ORGANIZATION: {ent['name']} [{eid}]\nDESCRIPTION: {ent['description'] or '(none yet)'}\n"
                + ("\nKNOWN MEMBERS:\n" + "\n".join(f"- {m['name']} ({role}): {m['description']}" for m, role in crew)
                   + "\n" if crew else "")
                + ("\nESTABLISHED FACTS:\n" + "\n".join(f"- {f['text']}" for f in facts) + "\n" if facts else "")
                + ("\nGM NOTES:\n" + "\n".join(f"- {n['text']}" for n in notes) + "\n" if notes else "")
                + ("\nWHERE IT HAS COME UP:\n" + "\n".join(f"- {r['text']}" for r in about) + "\n" if about else ""))
        return Job("faction_persona", eid, user, t)
    user = (f"NPC: {ent['name']} [{eid}] - template {ent['props'].get('template', 'civilian')}\n"
            f"DESCRIPTION: {ent['description'] or '(none yet)'}\n\nSHEET:\n{sr_lite.sheet(L, eid, full=True)}\n"
            + ("\nESTABLISHED FACTS:\n" + "\n".join(f"- {f['text']}" for f in facts) + "\n" if facts else "")
            + ("\nGM NOTES (their secrets and plans - the persona must fit these):\n"
               + "\n".join(f"- {n['text']}" for n in notes) + "\n" if notes else "")
            + ("\nWHAT THEY'VE DONE ON SCREEN (newest first):\n" + "\n".join(f"- {s['text']}" for s in seen) + "\n"
               if seen else "")
            + ("\nHOW THEY FEEL:\n" + "\n".join(f"- {b['text']}" for b in beliefs) + "\n" if beliefs else "")
            + (f"\nORGANIZATIONS ALREADY IN THE WORLD: {groups}\n" if groups else ""))
    return Job("persona", eid, user, t)


def _agent_job(game, ent: dict, trig: list[tuple[str, list[str]]], mail: list[dict], last: dict, t: int) -> Job:
    L, S = game.ledger, game.sub
    eid, now = ent["id"], game.clock()
    is_faction = ent["kind"] == "faction"
    onscreen = set(L.roster(game.current_scene_id())) if game.current_scene_id() else set()
    active = agendas_of(game, eid)
    subjects = ([x for _, ids in trig for x in ids] + [m["from_id"] for m in mail]
                + [x for a in active for x in agenda_targets(game, a["id"])])
    truth = _truth(game, eid, subjects)
    scene = L.current_scene()
    where = L.get(scene["location_id"]) if scene and scene["location_id"] else None
    remembered = sorted(S.witnessed_slices(eid, 40), key=lambda r: -r["created_turn"])[:8]
    heard = S.heard(eid, 4)
    notes = S.notes_for(eid, 4)
    since = (f"Your last offscreen move was {clock.since(last['time'], now)}." if last.get("time") is not None
             else f"Your last offscreen move was at T{last['turn']}." if last.get("turn") else
             "This is your first offscreen move.")
    head = (f"FACTION: {ent['name']} [{eid}] - {ent['description']}" if is_faction else
            f"CHARACTER: {ent['name']} [{eid}] - NPC ({ent['props'].get('template', 'civilian')}) - {ent['description']}")
    lines = [head, f"{'PROFILE' if is_faction else 'PERSONA'}: {persona_line(ent)}",
             f"\nSHEET:\n{sr_lite.sheet(L, eid, full=True)}",
             f"\nSTORY TIME: {clock.fmt(now)}. {since}"
             + (f" The player characters are at {where['name'] if where else scene['title']}"
                + ("" if is_faction else "; you are not with them") + "." if scene else "")]
    lines += rulings.table_rules(game)         # (above the memories and goals they outrank - flag #42)
    if is_faction:
        lines.append(FACTION_NOTE)
        crew = members_of(game, eid)
        lines.append("\nYOUR MEMBERS: " + ("; ".join(
            f"{m['name']} [{m['id']}] ({role}" + (", " + sr_lite.condition(L, m["id"]) if m["kind"] == "npc" else "")
            + (", ON SCREEN" if m["id"] in onscreen else
               f", at {whereabouts(game, m['id'])}" if whereabouts(game, m["id"]) else "") + ")" for m, role in crew)
            or "none known yet - recruit or hire"))
    else:
        here_now = whereabouts(game, eid)
        if here_now:
            lines.append(f"WHERE YOU ARE: {here_now}")
        groups = factions_of(game, eid)
        if groups:
            lines.append("YOUR ORGANIZATIONS: " + ", ".join(f"{f['name']} [{f['id']}] ({role})" for f, role in groups))
    feelings = [f"- {b['text']} (attitude {int(L.stat(eid, 'attitude:' + about, 0)):+d} toward {about})"
                for b in S.beliefs_of(eid)[:5]
                for about in [next((x['other'] for x in S.links_of(b['id']) if x['kind'] == 'about'), '?')]]
    if feelings:
        lines.append("\nHOW YOU FEEL:\n" + "\n".join(feelings))
    if remembered:
        lines.append("\nWHAT YOU REMEMBER (first-hand, newest first):\n"
                     + "\n".join(f"- [{m['id']}] (T{m['created_turn']}) {m['text']}" for m in remembered))
    if heard:
        lines.append("\nWHAT YOU HEARD:\n" + "\n".join(f"- [{h['id']}] ({h['how']}) {h['text'][:200]}" for h in heard))
    if notes:
        lines.append("\nGM NOTES ABOUT YOU (your secrets and motives):\n" + "\n".join(f"- {n['text']}" for n in notes))
    news = [f"- {x}" for x, _ in trig] + [f"- MESSAGE ({clock.since(m['story_time'], now) if m['story_time'] is not None else 'just now'}): "
                                          f"{m['text']}" for m in mail]
    lines.append("\nWHAT JUST HAPPENED TO YOU:\n" + ("\n".join(news) if news else "- nothing new"))
    pending = game.conn.execute("SELECT h.id, n.text FROM hooks h JOIN nodes n ON n.id=h.id WHERE h.npc_id=? "
                                "AND h.status='ready' ORDER BY h.rowid", (eid,)).fetchall()
    if pending:
        lines.append("\nYOUR PENDING HOOKS (queued for the GM):\n" + "\n".join(f"- [{h['id']}] {h['text']}"
                                                                           for h in pending))
    if active:
        lines.append("\nYOUR AGENDAS:")
        for a in active:
            steps = agenda_steps(game, a["id"])
            due = a["next_time"] <= now or a["next_turn"] <= t
            lines.append(f"- [{a['id']}] {a['goal']} (since T{a['created_turn']}, {a['steps']} step(s), "
                         + ("due now" if due else "waiting") + ")")
            for s in steps[-3:]:
                lines.append(f"    T{s['created_turn']}: {s['text']}")
    me = geo.geo_of(game, eid) if not is_faction else None
    if me:
        spots = [m for r in remembered for m, _ in S.members_of(r["id"]) if (L.get(m) or {}).get("kind") == "location"]
        spots += [x for x in subjects if (L.get(x) or {}).get("kind") == "location"]
        spots += [r["id"] for r in game.conn.execute(
            "SELECT e.id FROM entities e JOIN energy en ON en.node_id=e.id WHERE e.kind='location' "
            "ORDER BY en.energy DESC LIMIT 5")]
        trips = geo.where_lines(game, me, spots, 6)
        if trips:
            lines.append("\nPLACES FROM WHERE YOU ARE (how far, in words):\n" + "\n".join(f"- {x}" for x in trips))
    things = things_in_play(game, eid, subjects, remembered)
    if things:
        lines.append("\nTHINGS IN PLAY (the ledger - authoritative):\n" + "\n".join(f"- {_holder_line(game, i)}"
                                                                                for i in things))
    if truth:
        lines.append("\nHIDDEN TRUTH (you do NOT know this; a successful step that could plausibly uncover it "
                     "reveals it - list its id in learns_on_success):\n"
                     + "\n".join(f"- [{r['id']}] (T{r['created_turn']}) {r['text']}" for r in truth))
    people = {e["id"]: e for e in L.entities(kind="pc")}
    for link in S.links_of(eid):
        o = L.get(link["other"])
        if o and o["kind"] in ("pc", "npc") and link["kind"] in ("assoc", "contact"):
            people[o["id"]] = o
    for m, _ in (members_of(game, eid) if is_faction else []):
        people[m["id"]] = m
    lines.append("\nPEOPLE YOU KNOW OF (ids): " + ", ".join(
        f"{e['name']} [{e['id']}]" + (" (PC)" if e["kind"] == "pc" else " (ON SCREEN)" if e["id"] in onscreen else "")
        for e in people.values()))
    orgs = [f for f in L.entities(kind="faction") if f["id"] != eid]
    if orgs:
        lines.append("ORGANIZATIONS: " + ", ".join(f"{f['name']} [{f['id']}]" for f in orgs))
    if not is_faction:
        lines.append(f"SKILLS: {', '.join(sr_lite.SKILLS)}")
    lines.append("TEMPLATES for new_people and someone new you contact: "
                 + "; ".join(f"{k} ({v})" for k, v in sr_lite.TEMPLATE_TEXT.items()))
    known = [m["id"] for m in remembered] + [h["id"] for h in heard]
    return Job("agent", eid, "\n".join(lines), t, [r["id"] for r in truth], [a["id"] for a in active],
               known, [m["id"] for m in mail], [i["id"] for i in things])


def plan(game) -> list[Job]:
    """Pick this pass's work. Reads only; cheap."""
    if not enabled(game):
        return []
    L, S, k = game.ledger, game.sub, game.settings.knobs
    t, now = game.turn_no(), game.clock()
    sid = game.current_scene_id()
    here = set(L.roster(sid)) if sid else set()
    actors = [e for kind in ACTORS for e in L.entities(kind=kind) if e["tier"] >= 1
              and (kind == "faction" or sr_lite.condition(L, e["id"]) != "dead")]
    heat = {e["id"]: S.energy_of(e["id"]) or 0.0 for e in actors}
    jobs = [_persona_job(game, e, t) for e in sorted((e for e in actors if not persona(e)),
                                                      key=lambda e: -heat[e["id"]])[:k.world_personas_per_pass]]
    picks = []
    for e in actors:
        # onscreen NPCs are the DM's to play; inhabited ones are a player's; the dying don't scheme;
        # and an actor acts in character only once it has one
        if e["kind"] == "npc" and (e["id"] in here or game.control_of(e["id"]) == "player"
                                   or sr_lite.condition(L, e["id"]) in ("unconscious", "dying")):
            continue
        if not persona(e):
            continue
        row = game.conn.execute("SELECT last_turn, last_time, last_seq FROM world_actors WHERE npc_id=?",
                                (e["id"],)).fetchone()
        last = {"turn": row["last_turn"] if row else 0, "time": row["last_time"] if row else None}
        trig = triggers(game, e["id"], last["turn"], t, row["last_seq"] if row else None)
        mail = inbox(game, e["id"])
        due = [a for a in agendas_of(game, e["id"]) if a["next_time"] <= now or a["next_turn"] <= t]
        if trig or mail or due:
            waited = (-1, -1) if not row else (last["turn"], last["time"] or 0)   # never moved: first in line
            picks.append(((waited, 0 if (trig or mail) else 1, -heat[e["id"]]), e, trig, mail, last))
    picks.sort(key=lambda p: p[0])                         # round-robin by turns, so nobody starves
    seq = game.conn.execute("SELECT COALESCE(MAX(seq), 0) FROM events").fetchone()[0]
    for _, e, trig, mail, last in picks[:k.world_agents_per_pass]:
        job = _agent_job(game, e, trig, mail, last, t)
        job.seq = seq                         # everything up to here is what this move responds to
        jobs.append(job)
    return jobs


# ── think ───────────────────────────────────────────────────────────────

def think(game, job: Job) -> dict:
    """The only slow part: one structured Haiku call. Touches no database."""
    system, schema = {"persona": (PERSONA_SYSTEM, persona_schema()),
                      "faction_persona": (FACTION_SYSTEM, faction_schema())}.get(job.kind, (AGENT_SYSTEM, agent_schema()))
    return game.llm.structured(game.settings.models.world, system, job.user, schema, max_tokens=4000,
                               effort=game.settings.models.world_effort, purpose="world")


# ── apply ───────────────────────────────────────────────────────────────

def apply(game, job: Job, data: dict) -> list[str]:
    L, t = game.ledger, game.turn_no()
    if job.kind in ("persona", "faction_persona"):
        ent = L.get(job.npc)
        if not ent or persona(ent):
            return []
        fields = FACTION_FIELDS if job.kind == "faction_persona" else PERSONA_FIELDS
        bible = {f: data.get(f, [] if f in ("hooks", "affiliations") else "") for f in fields}
        joined = []
        for a in (bible.get("affiliations") or [])[:2] if job.kind == "persona" else []:
            fid = ensure_faction(game, a.get("name", ""), t)
            if fid:                                   # canonical names, so "the Ancients" and "Ancients" are one gang
                joined.append({"name": L.get(fid)["name"], "role": a.get("role") or "member", "id": fid})
        if job.kind == "persona":
            bible["affiliations"] = [{"name": a["name"], "role": a["role"]} for a in joined]
        L.update_entity(ent["id"], props={**ent["props"], "persona": bible})
        # (a line that dates it: the graph log's minds tell a new party's catch-up personas from the world's before it
        # by where their line falls - review 2026-10-28, a persona wrote none and read as the world's)
        L.log(t, "persona", ent["id"], {"kind": job.kind, "by": "world"})
        if job.kind == "faction_persona":
            L.set_stat(ent["id"], "reach", max(1, min(6, int(data.get("reach") or 2))))
            L.set_stat(ent["id"], "nuyen", max(0, min(10_000_000, int(data.get("funds") or 10000))))
            if not ent["description"] and data.get("summary"):
                L.update_entity(ent["id"], description=_public(game, _clip(data["summary"], 300), t))
                game.sub.ensure_entity(L.get(ent["id"]), t)
            return [f"[WORLD] profile for {ent['name']} (reach {int(L.stat(ent['id'], 'reach'))}, "
                    f"{int(L.stat(ent['id'], 'nuyen')):,} nuyen): {_clip(data.get('summary'), 160)}"]
        lines = [f"[WORLD] persona for {ent['name']}: {_clip(data.get('temperament'), 160)}"]
        for a in joined:
            join_faction(game, ent["id"], a["id"], a["role"], t)
            lines.append(f"[WORLD]   {ent['name']} belongs to {a['name']} ({a['role']})")
        return lines
    return _apply_agent(game, job, data)


def _test(game, ent: dict, skill: str, thr: int, action: str, t: int) -> tuple[bool, str]:
    """An offscreen roll: an NPC's real pool, or a faction's reach x2."""
    L = game.ledger
    if ent["kind"] == "faction":
        pool = int(L.stat(ent["id"], "reach", 2)) * 2
        r = sr_lite.roll(game.dice, pool)
        ok = r.hits >= thr
        L.log(t, "test", ent["id"], {"skill": skill or "reach", "success": ok, "net": r.hits - thr, "by": "world"})
        return ok, f" (reach {pool}d6 vs {thr}: {r.hits} hit(s), {'success' if ok else 'failure'})"
    if skill not in sr_lite.SKILLS:
        skill = "streetwise"                    # an effort with no named skill: general street competence
    r = sr_lite.request_test(L, game.dice, t, ent["id"], skill, threshold=thr, reason=f"offscreen: {action}")
    return r["success"], f" ({sr_lite.nice(skill)} vs {thr}: {r['hits']} hit(s), {'success' if r['success'] else 'failure'})"


def _apply_agent(game, job: Job, d: dict) -> list[str]:
    L, S, k = game.ledger, game.sub, game.settings.knobs
    t, now = game.turn_no(), game.clock()
    ent = L.get(job.npc)
    sid = game.current_scene_id()
    if not ent or (ent["kind"] == "npc" and ((sid and ent["id"] in L.roster(sid))
                                             or game.control_of(ent["id"]) == "player")):
        return [f"[WORLD] {job.npc}: skipped (on screen now)"]
    eid, name = ent["id"], ent["name"]
    lines: list[str] = []
    decision = d.get("decision", "none")
    agenda = None
    if decision == "start" and (d.get("goal") or "").strip():
        agenda = add_agenda(game, eid, d["goal"].strip(), d.get("targets") or [], t, by="world")
        lines.append(f"[WORLD] {name} starts {agenda}: {d['goal'].strip()}")
    elif decision in ("continue", "done", "drop"):
        agenda = (d.get("agenda_id") or "").upper()
        if agenda not in job.agendas:
            agenda = job.agendas[0] if len(job.agendas) == 1 else None
    closed = None
    if agenda and decision != "start":
        # job.agendas is the list as planned, and think runs off the game thread (session._world_pass): a turn or an
        # aside that ran meanwhile can drop the goal (`fix A71: agenda`) or a read-back retire it. Review 2026-10-27:
        # the apply then set it back to 'active' and ran its step and hook - A71, R27's closed Osprey storyline, after
        # the table had seen the [FIX] card. A goal closed since it was planned stays closed: no step, no hook.
        row = game.conn.execute("SELECT status FROM agendas WHERE id=?", (agenda,)).fetchone()
        if not row or row["status"] != "active":
            closed = row["status"] if row else "gone"
            lines.append(f"[WORLD] {name}: {agenda} was {closed} while they thought - left alone")
            agenda = None
    wait = max(MIN_WAIT, min(MAX_WAIT, int(d.get("wait_minutes") or 30)))

    action = (d.get("action") or "").strip()
    if decision != "none" and agenda and action and _echo(game, eid, d.get("on_success") or action) \
            and not (d.get("new_people") or d.get("acquire") or d.get("learns_on_success")):
        action = ""                                       # the same move again is waiting, not news
        lines.append(f"[WORLD] {name} holds ({agenda}): nothing new")
    if decision != "none" and agenda and action:
        success, roll = True, ""
        skill = (d.get("test_skill") or "").strip().lower().replace(" ", "_")
        if skill:
            try:
                success, roll = _test(game, ent, skill, max(1, min(5, int(d.get("test_threshold") or 2))), action, t)
            except Exception as exc:                           # can't act (unconscious...): the step fails
                success, roll = False, f" (can't: {exc})"
        outcome = (d.get("on_success") if success else d.get("on_failure")) or action
        spend = max(0, int(d.get("spend") or 0))
        if success and spend:
            have = int(L.stat(eid, "nuyen"))
            if have < spend:
                success = False
                outcome = f"{name} tried to {action[0].lower() + action[1:]} but couldn't raise {spend:,} nuyen."
            else:
                L.add_stat(eid, "nuyen", -spend)
                L.log(t, "nuyen", eid, {"to": None, "amount": spend, "reason": f"offscreen: {action}", "by": "world"})
                roll += f" [-{spend:,} nuyen]"
        helpers = []
        if success:
            for p in (d.get("new_people") or [])[:3]:
                if not (p.get("name") or "").strip() or spoilers.hits(game, p["name"]):
                    continue                    # (a name is public by birth: never one the table hasn't learned)
                # an unknown word is a civilian, never the armed operative block (flags #33/#47: it armed a virologist)
                template = sr_lite.npc_template(p.get("template")) or "civilian"
                hid_, created = game.introduce("npc", p["name"].strip(), _public(game, p.get("description"), t),
                                               template, turn=t)
                helpers.append(hid_)
                if ent["kind"] == "faction":
                    join_faction(game, hid_, eid, "recruit", t)
                if created:
                    lines.append(f"[WORLD]   {name} brings in {p['name'].strip()} [{hid_}] ({template})")
        members = [(eid, "actor")] + [(h, "actor") for h in helpers]
        offstage = lambda x: not (sid and x in L.roster(sid))          # noqa: E731 (on screen: the DM's)
        crew = {m["id"] for m, _ in members_of(game, eid)}
        for x in game.resolve_mentions(outcome):                       # the members this step put to work
            if x in crew and offstage(x) and x not in dict(members):
                members.append((x, "actor"))
        for w in d.get("whereabouts") or []:
            mover = L.find(w.get("who") or "")
            if mover and mover["id"] in crew | {eid, *helpers} and offstage(mover["id"]) \
                    and mover["id"] not in dict(members):
                members.append((mover["id"], "present"))
        for x in agenda_targets(game, agenda):
            if x not in dict(members):
                members.append((x, "mentioned"))
        wid = S.write_offscreen(t, outcome, members, agenda, story_time=now)
        for h in helpers:
            S.link(agenda, h, "helps", 1.0, t)
        learned = []
        if success:
            for x in d.get("learns_on_success") or []:
                x = x.strip().upper()
                if x in job.truth and S.add_knows(eid, x, "discovered", None, t):
                    S.link(wid, x, "reveals", 1.0, t)
                    learned.append(x)
        taken = []
        if success:
            for x in (d.get("acquire") or [])[:2]:
                item = L.find(x)
                if not item or item["kind"] != "item":
                    continue
                holders = [L.get(h) for h in L.holders(item["id"])]
                if any(h["kind"] == "pc" or (sid and h["id"] in L.roster(sid)) for h in holders if h) \
                        or eid in [h["id"] for h in holders if h]:
                    lines.append(f"[WORLD]   {name} can't take {item['name']} offscreen (held on screen or by a PC)")
                    continue
                if holders:
                    state = L.take(holders[0]["id"], item["id"], 1)
                    L.log(t, "transfer_item", holders[0]["id"], {"item": item["id"], "to": eid, "qty": 1, "by": "world"})
                    L.give(eid, item["id"], 1, state)
                else:
                    L.give(eid, item["id"], 1)
                S.link(wid, item["id"], "member", 1.0, t)
                taken.append(item["name"])
        allowed_movers = {eid, *helpers} | {m["id"] for m, _ in members_of(game, eid)}
        for w in (d.get("whereabouts") or [])[:4]:
            mover = L.find(w.get("who") or "")
            if mover and mover["id"] in allowed_movers and mover["kind"] == "npc" and (w.get("where") or "").strip() \
                    and not (sid and mover["id"] in L.roster(sid)):          # on screen, the DM moves people
                move(game, mover["id"], w["where"], w.get("place"))
        reached = []                     # contacts happen even when the step goes badly: the call was made
        for c in (d.get("contacts") or [])[:MAX_CONTACTS]:
            other = L.find(c.get("who") or "")
            if other is None and (c.get("who") or "").strip():
                who = c["who"].strip()
                if " " not in who and "-" in who:          # a slug where a name should be: "old-precinct-partner"
                    who = who.replace("-", " ").title()
                if spoilers.hits(game, who) and c.get("kind") != "faction":
                    continue                               # (a GM-only name is never filed - spoilers.py)
                if c.get("kind") == "faction":
                    oid = ensure_faction(game, who, t)
                else:
                    # the block that fits who they are, a civilian for a word it doesn't know - never the armed contact
                    # block by default (review 2026-10-27, flag #33: 24 live contacts, nurses and lawyers among them,
                    # each with a hold-out pistol)
                    template = sr_lite.npc_template(c.get("template")) or "civilian"
                    oid, created = game.introduce("npc", who, _public(game, c.get("description"), t), template,
                                                  turn=t)
                    if created:
                        lines.append(f"[WORLD]   {name} reaches someone new: {who} [{oid}] ({template})")
                other = L.get(oid) if oid else None
            if not other or other["id"] == eid or other["kind"] not in ACTORS or not (c.get("says") or "").strip():
                continue
            if _echo(game, eid, f"{name} reached {other['name']}: {c['says']}", 0.6):
                continue                                  # the same message again is no message
            reach_out(game, eid, other["id"], c["says"], c.get("shares") or [], set(job.known), agenda, t)
            reached.append(other["name"])
        hook = None
        if success and (d.get("hook") or "").strip():
            for old in d.get("hook_replaces") or []:
                game.conn.execute("UPDATE hooks SET status='stale' WHERE id=? AND npc_id=? AND status='ready'",
                                  (old.strip().upper(), eid))
            hook = add_hook(game, eid, agenda, d["hook"].strip(), d.get("hook_about") or [], t)
            game.conn.execute(                      # an actor keeps at most a couple of live threads on the GM's desk
                "UPDATE hooks SET status='stale' WHERE npc_id=? AND status='ready' AND id NOT IN "
                "(SELECT id FROM hooks WHERE npc_id=? AND status='ready' ORDER BY rowid DESC LIMIT ?)",
                (eid, eid, MAX_READY_HOOKS))
        status = {"done": "done", "drop": "dropped"}.get(decision, "active")
        game.conn.execute("UPDATE agendas SET steps=steps+1, updated_turn=?, next_turn=?, next_time=?, status=? "
                          "WHERE id=? AND status='active'", (t, t + wait_turns(wait), now + wait, status, agenda))
        S.touch([wid, agenda] + ([hook] if hook else []), t, k.retrieval_quantum)
        lines.append(f"[WORLD] {name} ({agenda}): {action}{roll} -> {wid}: {outcome}"
                     + (f" | learns {', '.join(learned)}" if learned else "")
                     + (f" | takes {', '.join(taken)}" if taken else "")
                     + (f" | reached {', '.join(reached)}" if reached else "")
                     + (f" | hook {hook}" if hook else "") + (f" | {status}" if status != "active" else ""))
    elif agenda and decision in ("done", "drop"):
        game.conn.execute("UPDATE agendas SET status=?, updated_turn=? WHERE id=? AND status='active'",
                          ("done" if decision == "done" else "dropped", t, agenda))
        lines.append(f"[WORLD] {name} {'finished' if decision == 'done' else 'gave up on'} {agenda}")
    elif agenda:                                          # nothing to do yet: check back later
        game.conn.execute("UPDATE agendas SET next_time=?, next_turn=? WHERE id=? AND status='active'",
                          (now + wait, t + wait_turns(wait), agenda))
    elif not closed:
        lines.append(f"[WORLD] {name} lets it be")

    about = L.find(d.get("feeling_about") or "")
    if about and about["id"] != eid and about["kind"] in ("pc", "npc", "faction") \
            and (d.get("feeling_belief") or "").strip():
        att = max(-3, min(3, int(d.get("feeling_attitude") or 0)))
        bid = S.add_belief(eid, about["id"], d["feeling_belief"].strip(), t)
        L.set_stat(eid, f"attitude:{about['id']}", att)
        L.log(t, "belief", eid, {"about": about["id"], "attitude": att, "belief": bid, "by": "world"})
        lines.append(f"[WORLD]   {name} now feels {att:+d} about {about['name']}: {d['feeling_belief'].strip()}")
    if job.inbox:
        game.conn.execute(f"UPDATE world_inbox SET read=1 WHERE id IN ({','.join('?' * len(job.inbox))})", job.inbox)
    game.conn.execute("INSERT OR REPLACE INTO world_actors(npc_id, last_turn, last_time, last_seq) VALUES(?,?,?,?)",
                      (eid, t, now, job.seq))
    return lines


def apply_all(game, jobs: list[Job], results: list) -> list[str]:
    lines = []
    for job, res in zip(jobs, results):
        if isinstance(res, BaseException):
            lines.append(f"[WORLD] {job.kind} for {job.npc} failed: {res}")
            continue
        try:
            lines += apply(game, job, res)
        except Exception as exc:                             # one bad proposal never sinks the pass
            lines.append(f"[WORLD] {job.kind} for {job.npc} rejected: {exc}")
    return lines


def run_pass(game) -> list[str]:
    """plan -> think (in parallel) -> apply, synchronously. The console and tests use this; the
    Discord table runs the same three stages with the thinking off its game thread."""
    jobs = plan(game)
    if not jobs:
        return []

    def safe(job):
        try:
            return think(game, job)
        except Exception as exc:
            return exc
    with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        results = list(pool.map(safe, jobs))
    return apply_all(game, jobs, results)


def summary(game, limit: int = 8) -> str:
    """GM view: factions, active agendas, ready hooks, recent offscreen events."""
    L = game.ledger
    out = [f"Story time: {game.clock_line()}"]
    for f in L.entities(kind="faction"):
        crew = ", ".join(m["name"] for m, _ in members_of(game, f["id"]))
        out.append(f"{f['name']} [{f['id']}] faction, reach {int(L.stat(f['id'], 'reach', 2))}, "
                   f"{int(L.stat(f['id'], 'nuyen')):,} nuyen" + (f" - members: {crew}" if crew else ""))
    for a in game.conn.execute("SELECT * FROM agendas WHERE status='active' ORDER BY updated_turn DESC LIMIT ?",
                               (limit,)):
        who = (L.get(a["npc_id"]) or {}).get("name", a["npc_id"])
        at = whereabouts(game, a["npc_id"]) if (L.get(a["npc_id"]) or {}).get("kind") == "npc" else None
        out.append(f"[{a['id']}] {who}{f' (at {at})' if at else ''}: {a['goal']} (since T{a['created_turn']}, "
                   f"{a['steps']} step(s), next ~{clock.fmt(a['next_time'])})")
    for h in game.conn.execute("SELECT h.*, n.text FROM hooks h JOIN nodes n ON n.id=h.id WHERE h.status='ready' "
                               "ORDER BY h.created_turn DESC, h.rowid DESC LIMIT ?", (limit,)):
        out.append(f"[{h['id']}] hook from {(L.get(h['npc_id']) or {}).get('name', h['npc_id'])}: {h['text']}")
    for w in game.conn.execute("SELECT * FROM nodes WHERE kind='slice' AND visibility='offscreen' "
                               "ORDER BY created_turn DESC, rowid DESC LIMIT ?", (limit,)):
        when = clock.fmt(w["story_time"]) if w["story_time"] is not None else f"T{w['created_turn']}"
        out.append(f"[{w['id']}] {when}: {w['text']}")
    return "\n".join(out) if len(out) > 1 else out[0] + "\nThe world is quiet (no agendas, hooks or offscreen events yet)."
