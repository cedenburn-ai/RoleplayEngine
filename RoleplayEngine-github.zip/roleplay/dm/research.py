"""The GM's notebook (DESIGN.md §8d, built 2026-10-26): the record behind the packet's summaries.

A human GM flips back through their notes before an NPC brings something up - what was promised, who was told, how
two people got where they are. The packet is the page that's open, and the canon, the scene frame and the slice
summaries on it are all summaries. These are the rest of the notebook:
- read_turn: what was actually said - the players' posts and the narration word for word, and the rolls;
- recall: a memory's whole record (what superseded it, what it replaced), and a person's mind;
- search_memory: by words (names count), by who it involves, by kind and time, and in what was said;
- timeline: what has happened between people, oldest first.

Live, 188 turns used recall in 6 and search in 14: each lookup spent one of the turn's 8 tool steps, recall was capped
at 3 a turn, the narration and posts weren't searchable at all, and 'Bo' - the boy the Low Wharf storyline turns
on - was too short a word to search for. At T150 a player had to remind an NPC, in character, that she'd had Bo the
whole time. Lookups are free steps now, up to their own allowance (turn._dm_loop), and capped
per turn here (run).
"""
from __future__ import annotations

import json
import re

from ..engine import clock
from ..engine.rules import magic, matrix, sr_lite
from ..substrate.packet import _whisper, slice_line
from ..substrate.store import SEARCH_KINDS, norm_id, search_terms, term_re

RESEARCH = ("recall", "read_turn", "search_memory", "timeline")
READ_MAX = 6                 # turns one read_turn call reads
TURN_CHARS = 6000            # one turn's narration (the longest live one is ~4,200)
POST_CHARS = 1500            # one player's post
AROUND_RADIUS = 350          # read_turn around: characters either side of a match
AROUND_MOST = 3              # passages a turn
PASSAGE_MAX = 1600           # one passage, however many matches chain together
SNIPPET = 280                # a search hit's passage
SEARCH_LIMIT, SEARCH_MAX = 10, 20
TIMELINE_LIMIT, TIMELINE_MAX = 12, 30
TURN_MAX = 10 ** 9           # no turn number is larger: past it a ref is unreadable (SQLite's integers stop at 2^63;
                             # review 2026-10-26: read_turn T99999999999999999999 raised OverflowError, lost the turn)
RECALL_MAX = 8               # ids one recall opens
LINKED = 8                   # linked memories a recall lists
LINKED_KINDS = ("slice", "fact", "scene", "tension")
VIEWS, GOALS, HEARD, TOWARD = 8, 4, 4, 8
CANDIDATES = 40              # what research showed the GM, offered to the memory pass as 'recalled' candidates
ASIDE_SPENT = ("That's all the looking up for this aside ({cap} lookups) - answer now, from what you have. What you "
               "still couldn't check goes in fixes: `doubt <ids>: <both versions>`, so it's on your DOUBTS list next "
               "turn.")


def run(ctx, name: str, args: dict) -> str:
    """One lookup, within the turn's research cap (models.dm_research_calls)."""
    cap = ctx.game.settings.models.dm_research_calls
    ctx.research_calls += 1
    if ctx.research_calls > cap:
        if ctx.by == "aside":
            # (review 2026-10-26: the aside got the turn's words - "narrate", "the doubt tool", "your <dm> block" -
            # and it has no narration, no doubt tool and no <dm> block: its doubts are fix lines)
            return ASIDE_SPENT.format(cap=cap)
        # Review (2026-10-26): this said "leave yourself a note (annotate)" - a note only comes back with its target,
        # and research cut off is when an open question is likeliest. A doubt stays on the DOUBTS list until settled.
        return (f"Research budget for this turn is spent ({cap} lookups) - narrate with what you have, keeping clear "
                "of what you couldn't check. If it may not add up, raise it as a doubt (the doubt tool, or `doubt "
                "<ids>: ...` in your <dm> block) so it's on your DOUBTS list next turn.")
    return {"recall": recall, "read_turn": read_turn, "search_memory": search, "timeline": timeline}[name](ctx, args)


def candidates(ctx) -> set[str]:
    """What research put in front of the GM (search hits, timeline lines) - offered to the memory pass as 'recalled'
    candidates, the newest CANDIDATES of them (by latest sighting: _saw). Shown isn't used: only what the turn drew on
    gets touched (§8)."""
    return set(list(ctx.seen)[-CANDIDATES:])


def _saw(ctx, nid: str) -> None:
    """A lookup showed the GM nid: it moves to the newest end of ctx.seen. Review (2026-10-26): a plain assignment
    kept a key where it first went in, so a hit seen early and again on the last lookup could fall out of the 40."""
    ctx.seen.pop(nid, None)
    ctx.seen[nid] = None


# ── out of the story: look first, then answer (DESIGN.md §8e) ──────────
LAST_LOOK = "(Engine: that was the last lookup - answer now, from what you have.)"
# Final check (2026-10-26, RUN_LIVE): "no more lookups - write your answer now" still came back empty on Haiku 5.5 at
# low effort about one time in ten (6/64, a question saying "read T33 first"), and !askdm DM'd the player nothing.
# Saying it can't look and may say what it couldn't check: 0/96.
ANSWER_NOW = ("(Engine: you can't look anything up now - write your answer now, from what you have. If that isn't "
              "enough, say so in your answer, and what you couldn't check.)")
ANSWER_TRIES = 2             # times an empty tools-off answer is asked for again


def _said_text(msg) -> str:
    return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()


def consult(game, model: str, system: str, user: str, tools: list[dict], run, steps: int, schema: dict | None = None,
            **kw) -> tuple[str, str, int]:
    """A short research loop before an answer out of the story: the GM aside ("Hey DM, didn't we agree at T33...")
    and !askdm. Up to `steps` rounds of lookups - run(block) answers each call with a tool_result - then one more call
    with the tools off, so an answer always comes. A question that needs no lookup is the one call it always was.
    Returns (the answer's text, the stop reason, the rounds of lookups made). schema: the answer as JSON; kw goes to
    LLM.consult (max_tokens, effort, fallback, purpose)."""
    messages: list[dict] = [{"role": "user", "content": user}]
    for step in range(steps + 1):
        last = step >= steps
        msg = game.llm.consult(model, system, messages, tools, schema,
                               tool_choice={"type": "none"} if last else None, **kw)
        calls = [b for b in msg.content if getattr(b, "type", "") == "tool_use"]
        if calls and msg.stop_reason == "tool_use" and not last:
            messages.append({"role": "assistant", "content": msg.content})
            results = [run(b) for b in calls]
            if step == steps - 1:                        # (said with the results, so the answer comes next)
                results.append({"type": "text", "text": LAST_LOOK})
            messages.append({"role": "user", "content": results})
            continue
        answer = _said_text(msg)
        for _ in range(ANSWER_TRIES):
            if answer or msg.stop_reason != "end_turn":
                break
            # Live check (Haiku, 2026-10-26): with its tools off, a model that still wanted to look answered nothing
            # at all - an empty end_turn. Told again, it answers.
            messages.append({"role": "user", "content": ANSWER_NOW})
            msg = game.llm.consult(model, system, messages, tools, schema, tool_choice={"type": "none"}, **kw)
            answer = _said_text(msg)
        return answer, msg.stop_reason, step
    return "", "end_turn", steps                         # (not reached: the last call has its tools off)


# ── small helpers ───────────────────────────────────────────────────────

def _name(L, eid) -> str:
    e = L.get(eid) if eid else None
    return e["name"] if e else (eid or "?")


def _list(v) -> list[str]:
    if v is None:
        return []
    return [str(x) for x in ([v] if isinstance(v, (str, int)) else v) if str(x).strip()]


def _int(v) -> int | None:
    """from_turn / to_turn: 150, '150', 'T150'. Held to +-TURN_MAX, so a slip of twenty digits can't overflow SQLite."""
    try:
        n = None if v is None or v == "" else int(str(v).strip().lstrip("Tt"))
    except ValueError:
        return None
    return None if n is None else max(-TURN_MAX, min(TURN_MAX, n))


def _clip(text: str, n: int, more: str = "") -> str:
    text = text or ""
    return text if len(text) <= n else text[:n].rsplit(" ", 1)[0] + f"... [{len(text) - n:,} more chars]{more}"


def _resolve(ctx, ref: str) -> str | None:
    """A node id or a name on file -> the node/entity id."""
    nid = norm_id(str(ref))
    if ctx.game.sub.exists(nid):
        return nid
    ent = ctx.game.ledger.find(str(ref))
    return ent["id"] if ent else None


def _when(game, node: dict | None, turn: int | None = None) -> str:
    """Story time of a moment ('Day 3, morning'). A fight round writes no slice: then the last stamped one before it."""
    st = (node or {}).get("story_time")
    if st is not None:
        return clock.fmt(st)
    if turn is None:
        return ""
    row = game.conn.execute("SELECT story_time FROM nodes WHERE kind='slice' AND story_time IS NOT NULL AND "
                            "created_turn<=? ORDER BY created_turn DESC LIMIT 1", (turn,)).fetchone()
    return f"around {clock.fmt(row[0])}" if row else ""


def _posts(raw: str) -> list[tuple[str, str]]:
    try:
        rows = json.loads(raw or "[]")
    except ValueError:
        return []
    return [(str(r[0]), str(r[1])) for r in rows if isinstance(r, (list, tuple)) and len(r) >= 2]


def _who(game, handle: str) -> str:
    ch = game.character_for(handle)
    return f"{ch['name']} [{ch['id']}]" if ch else handle


def _heard_by(game, nid: str) -> str | None:
    """Who has heard of a moment second-hand since, how and from whom."""
    L = game.ledger
    rows = game.conn.execute("SELECT holder, how, source, turn FROM knows WHERE node_id=? ORDER BY turn",
                             (nid,)).fetchall()
    if not rows:
        return None
    how = {"told": "told by", "rumor": "a rumor via"}
    bits = [f"{_name(L, r['holder'])} (T{r['turn']}, " + (f"{how.get(r['how'], r['how'])} {_name(L, r['source'])}"
                                                          if r["source"] else r["how"]) + ")" for r in rows]
    return "Heard of it second-hand since: " + "; ".join(bits[:8]) + (f" (+{len(bits) - 8} more)" if len(bits) > 8
                                                                      else "")


def _superseded(S, nid: str) -> str:
    newer = S.newest(nid)
    return f"  (SUPERSEDED by [{newer}] - that's the current version)" if newer else ""


# ── at the table: what an aside may look up (DESIGN.md §8e) ─────────────
# Review (2026-10-26): the aside's answer is posted in the open channel, and its notebook was the GM's whole one -
# Ghost's player asked "what has Razor been up to?" and read_turn handed the aside Razor's whisper word for word ("You
# palm the maglock keycard..."), recall every DM note and persona in the campaign. At the table (ctx.for_table) a
# lookup reaches what the table has seen - public turns and canon, the asker's own whispers, the open questions and
# doubts the aside settles - and never another player's whisper, the offscreen world or the GM's private notebook.
NOT_AT_TABLE = ("note", "clarification", "belief", "agenda", "hook")   # (notes, pictures, minds, goals, hooks)
AWAY = "can't be looked up in an aside - it isn't something the table has seen"


def _theirs(ctx, nid: str, node: dict) -> bool:
    """A private memory of the asker's own: their whisper's slice, or what came out of it (linked `about` it)."""
    if not ctx.asker:
        return False
    mine = {f"T{r[0]}" for r in ctx.game.conn.execute("SELECT id FROM turns WHERE private=?", (ctx.asker,))}
    if node["kind"] == "slice":
        return nid in mine
    return any(x["kind"] == "about" and x["other"] in mine for x in ctx.game.sub.links_of(nid))


def hidden(ctx, nid: str, node: dict | None = None) -> bool:
    """At the table (ctx.for_table), a memory the table hasn't seen. Never, in the GM's own turn."""
    if not ctx.for_table:
        return False
    node = node or ctx.game.sub.node(nid)
    if not node:
        return False
    if node["kind"] in NOT_AT_TABLE or node["visibility"] == "offscreen":
        return True
    if node["kind"] == "entity":                         # who only a story seed's GM half knows yet (seed.py)
        from .. import seed
        if nid in seed.sealed_ids(ctx.game.conn):
            return True
    if node["kind"] == "doubt":                          # one out of a whisper or the offscreen world (doubts.secret)
        from . import doubts
        s = doubts.secret(ctx.game, doubts.get(ctx.game, nid) or {"id": nid})
        return bool(s["label"]) and (s["offscreen"] or ctx.asker not in s["who"])
    return node["visibility"] == "private" and not _theirs(ctx, nid, node)


def _hidden_turn(ctx, private: str | None) -> bool:
    """At the table, a turn the table didn't see: another player's whisper."""
    return bool(ctx.for_table and private and private != ctx.asker)


# ── passages ────────────────────────────────────────────────────────────

def snippet(text: str, terms: list[str], width: int = SNIPPET) -> str:
    """The stretch of text around its matched words - the window holding the most of them - not its first lines."""
    flat = " ".join((text or "").split())
    if len(flat) <= width:
        return flat
    spans = [(m.start(), t) for t in terms for m in term_re(t).finditer(flat)]
    if not spans:
        return flat[:width].rsplit(" ", 1)[0] + "..."
    lead = width // 3
    best = max(spans, key=lambda sp: (len({t for s, t in spans if sp[0] - lead <= s < sp[0] - lead + width}),
                                      -sp[0]))[0]
    a = max(0, min(best - lead, len(flat) - width))
    if a:
        sp = flat.find(" ", a, a + 30)
        a = sp + 1 if sp != -1 else a
    b = min(len(flat), a + width)
    if b < len(flat):
        sp = flat.rfind(" ", b - 30, b)
        b = sp if sp != -1 else b
    return ("..." if a else "") + flat[a:b] + ("..." if b < len(flat) else "")


def _spans(text: str, around: str) -> list[tuple[int, int, str]]:
    """Where `around` sits in text: the phrase itself (any case, any spacing, from the start of a word - and to the
    end of one, or its plural, when it ends on a short word: 'Bo' is not in 'boring', 'two ork' finds 'two orks'), else
    each of its words (term_re)."""
    words = around.split()
    hits = []
    if words:
        tail = r"(?:e?s)?(?![A-Za-z0-9])" if len(words[-1]) <= 3 else ""
        phrase = r"(?<![A-Za-z0-9])" + r"\s+".join(map(re.escape, words)) + tail
        hits = [(m.start(), m.end(), "") for m in re.finditer(phrase, text, re.I)]
    return hits or [(m.start(), m.end(), t) for t in search_terms(around) for m in term_re(t).finditer(text)]


def passages(text: str, around: str, radius: int = AROUND_RADIUS, most: int = AROUND_MOST) -> list[str]:
    """Up to `most` passages of text around the phrase (or its words) - the ones holding the most different words,
    then the most matches - in the order they come. Nearby matches share a passage up to PASSAGE_MAX."""
    spans = _spans(text, around)
    if not spans:
        return []
    clusters: list[list] = []                            # [start, end, words, matches]
    for s, e, t in sorted(spans):
        a, b = max(0, s - radius), min(len(text), e + radius)
        c = clusters[-1] if clusters else None
        if c and a <= c[1] and b - c[0] <= PASSAGE_MAX:
            c[1], c[3] = max(c[1], b), c[3] + 1
            c[2].add(t)
        else:
            clusters.append([max(a, c[1]) if c else a, b, {t}, 1])   # (never the same text twice)
    best = sorted(clusters, key=lambda c: (len(c[2]), c[3]), reverse=True)[:most]
    out = []
    for a, b, _, _ in sorted(best, key=lambda c: c[0]):
        chunk = " ".join(text[a:b].split())
        out.append(("..." if a else "") + chunk + ("..." if b < len(text) else ""))
    return out


# ── read_turn ───────────────────────────────────────────────────────────

_ONE = re.compile(r"^([TW]?)(\d+)$", re.I)
_RANGE = re.compile(r"^([TW]?)(\d+)(?:-|–|—|\.\.|to)([TW]?)(\d+)$", re.I)


def turn_refs(refs) -> tuple[list[str], list[str]]:
    """read_turn's ids: 'T150', '150', 't150', 'T148-T150', '148..150', 'W617' - a list, or commas in one string.
    Returns (the ids in order, the refs it couldn't read)."""
    ids, bad = [], []
    for raw in _list(refs):
        for part in raw.split(","):
            p = part.strip().strip("[]").replace(" ", "")
            if not p:
                continue
            m = _RANGE.match(p)
            if m:
                a, b = sorted((int(m[2]), int(m[4])))
                if b > TURN_MAX:                         # (no such turn - and too big for SQLite)
                    bad.append(part.strip())
                    continue
                kind = (m[1] or m[3] or "T").upper()
                ids += [f"{kind}{n}" for n in range(a, min(b, a + 50) + 1)]
                continue
            m = _ONE.match(p)
            if m and int(m[2]) <= TURN_MAX:
                ids.append(f"{(m[1] or 'T').upper()}{int(m[2])}")
            else:
                bad.append(part.strip())
    return list(dict.fromkeys(ids)), bad


def _offscreen_roll(r: dict) -> bool:
    try:
        return str(json.loads(r["spec"] or "{}").get("reason") or "").startswith("offscreen:")
    except ValueError:
        return False


def roll_line(L, r: dict, why: bool = True) -> str:
    """One tests row: who rolled what, the hits and the result (and why, as the GM gave it - the GM's words, so
    !askdm leaves them off: why=False)."""
    try:
        spec = json.loads(r["spec"] or "{}")
    except ValueError:
        spec = {}
    kind = spec.get("kind")
    if kind == "attack":
        what = f"attack on {_name(L, spec.get('target'))}" + (f" with {_name(L, spec['weapon'])}"
                                                               if spec.get("weapon") else "")
    elif kind == "cast":
        sp = (magic.SPELLS.get(spec.get("spell") or "") or {}).get("name") or spec.get("spell") or "a spell"
        what = f"casts {sp} at Force {spec.get('force')}" + (
            f" on {', '.join(_name(L, t) for t in spec['targets'])}" if spec.get("targets") else "")
    elif kind == "ram":
        what = "a ram " + (f"into {_name(L, spec['target'])}" if spec.get("target") else "into a barrier")
    elif kind == "matrix":
        return _matrix_roll_line(L, r, spec, why)
    else:
        what = (sr_lite.nice(spec["skill"]) if spec.get("skill")
                else " + ".join(str(a).title() for a in spec.get("attributes") or []) or "a test")
        opp = spec.get("opposed") or {}
        if opp.get("entity_id"):
            what += f" vs {_name(L, opp['entity_id'])}"
        elif spec.get("threshold"):
            what += f" ({spec['threshold']})"
        what += _team_text(L, spec)
    hits = r["hits"] or 0
    res = f"{hits} hit{'s' if hits != 1 else ''}, {'success' if r['success'] else 'failure'}"
    if kind != "cast":
        res += f" (net {(r['net'] or 0):+d})"
    res += ", CRITICAL GLITCH" if r["crit_glitch"] else ", glitch" if r["glitch"] else ""
    res += f" · Edge: {spec['edge']}" if spec.get("edge") else ""     # (what it did: request_test, magic._settle)
    reason = str(spec.get("reason") or "").removeprefix("offscreen: ") if why else ""
    return f"  - {_name(L, r['actor_id'])}: {what} -> {res}" + (f" - {_clip(reason, 160)}" if reason else "")


def _team_text(L, spec: dict) -> str:
    """A test's teamwork and who rolled it, as read_turn says it: ", Brask helping (0 hits) +0", "(capped at 3)", and
    "- rolled by the engine: the player called it" (flag #38: T128's row couldn't say whether anyone had helped)."""
    out = ""
    helped = [h for h in spec.get("helpers") or [] if isinstance(h, dict)]
    if helped:
        each = [f"{_name(L, h.get('id'))} ({h['hits']} hit{'s' if h['hits'] != 1 else ''})" if "hits" in h
                else f"{_name(L, h.get('id'))} (couldn't: {_clip(str(h.get('why') or ''), 60)})" for h in helped]
        out += f", {' and '.join(each)} helping: +{spec.get('teamwork', 0)}" + (
            f" (capped at {spec['cap']})" if spec.get("cap") else "")
    if spec.get("by") == "engine":
        out += " - rolled by the engine: the player called it and the GM wouldn't"
    return out


def _faces(dice) -> str:
    try:
        return " ".join(str(d) for d in sorted((int(x) for x in dice or []), reverse=True)) or "-"
    except (TypeError, ValueError):
        return "?"


def _matrix_roll_line(L, r: dict, spec: dict, why: bool) -> str:
    """A Matrix roll's row (matrix._record_roll), the way its card read: the beat and where, the decker's pool and
    dice, the host's or IC's side - its dice too, which is what the table asks to see (flag #25: "the KD-4 host's
    opposed defense roll for the T105 crack") - or the threshold, the Edge, and the result."""
    act = str(spec.get("action") or "beat").replace("_", " ")
    ic = spec.get("ic")
    head = (f"defends against {matrix.ic_name(ic)}" if act == "defend" and ic else f"Matrix {act}"
            + (f" ({sr_lite.nice(spec['skill'])})" if spec.get("skill") else ""))
    where = " in " + (_name(L, spec["host"]) if spec.get("host") else "the Matrix") + (
        f" at {spec['node']}" if spec.get("node") else "")
    try:
        dice = json.loads(r["dice"] or "[]")
    except (TypeError, ValueError):
        dice = []
    hits = r["hits"] or 0
    mine = f"{spec.get('pool', '?')} -> {_faces(dice)} -> {hits} hit{'s' if hits != 1 else ''}"
    if spec.get("vs"):
        theirs = (f" vs {spec['vs']} = {spec.get('vs_pool', '?')}d6 -> {_faces(spec.get('vs_dice'))} -> "
                  f"{spec.get('vs_hits', '?')} hits")
    elif spec.get("threshold") is not None:
        theirs = f" (threshold {spec['threshold']})"
    else:
        theirs = ""
    res = f"{'success' if r['success'] else 'failure'} (net {(r['net'] or 0):+d})"
    res += ", CRITICAL GLITCH" if r["crit_glitch"] else ", glitch" if r["glitch"] else ""
    extra = (f" · Edge: {spec['edge']}" if spec.get("edge") else "") + (
        f" · table {spec['table']}" if spec.get("table") else "")
    reason = str(spec.get("reason") or "") if why else ""
    return (f"  - {_name(L, r['actor_id'])}: {head}{where}: {mine}{theirs} -> {res}{extra}"
            + (f" - {_clip(reason, 160)}" if reason else ""))


def read_turn(ctx, args: dict) -> str:
    ids, bad = turn_refs(args.get("turn_ids") or args.get("turn_id"))
    around = str(args.get("around") or "").strip()
    if not ids:
        return ("Which turns? turn_ids like 'T150', '150' or a range 'T148-T150' (W# for an offscreen moment)."
                + (f" Couldn't read: {', '.join(bad)}." if bad else ""))
    out = [f"(couldn't read {', '.join(bad)} - give T#, a number or a range like T148-T150)"] if bad else []
    for ref in ids[:READ_MAX]:
        out.append(_read_offscreen(ctx, ref) if ref.startswith("W") else _read_one(ctx, int(ref[1:]), around))
    left = ids[READ_MAX:]
    if left:
        rest = ", ".join(left) if len(left) <= 4 else f"{left[0]} ... {left[-1]} ({len(left)})"
        out.append(f"(read_turn reads {READ_MAX} turns a call - left out: {rest}; ask for them next)")
    return "\n\n".join(out)


def _read_one(ctx, n: int, around: str) -> str:
    game, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    if n == ctx.turn_id:
        return f"[T{n}] is this turn - nothing's written yet."
    row = game.conn.execute("SELECT * FROM turns WHERE id=?", (n,)).fetchone()
    if not row or row["status"] not in ("committed", "seed"):
        return f"[T{n}] no such turn on file (not played yet, or taken back with !undo)."
    if _hidden_turn(ctx, row["private"]):
        return f"[T{n}] {AWAY}."
    node = S.node(f"T{n}")
    if node:
        ctx.expanded.add(node["id"])                     # (the GM opened it by id: it gets the retrieval touch)
    sc = L.scene(row["scene_id"]) if row["scene_id"] else None
    when = _when(game, node, n)
    head = " · ".join([f"T{n}"] + ([f"S{sc['id']} {sc['title']}"] if sc else []) + ([when] if when else []))
    lines = [f"=== {head} ==="]
    if row["private"]:
        lines.append(f"(WHISPER from {_name(L, row['private'])} - private: only they and whoever noticed know it)")
    if row["status"] == "seed":
        lines.append("(seeded history - no narration on file)")
    elif not node:
        lines.append("(a fight round - it's in the fight's log, not a turn memory of its own)")
    if node:
        lines.append(f"Summary: {node['text']}")
    for handle, text in _posts(row["inputs"]):
        lines.append(f"{_who(game, handle)} posted: {_clip(text, POST_CHARS)}")
    narr = row["narration"] or ""
    if narr and around:
        found = passages(narr, around)
        lines += ([f"Narration around \"{around}\" ({len(found)} passage{'s' if len(found) != 1 else ''} of a "
                   f"{len(narr):,}-char narration):"] + [f"  {p}" for p in found]
                  if found else [f"(nothing like \"{around}\" in this turn's narration)"])
    elif narr:
        lines.append("Narration (verbatim):\n" + _clip(narr, TURN_CHARS, " - read it again with around: a phrase"))
    rolls = [dict(r) for r in game.conn.execute("SELECT * FROM tests WHERE turn_id=? ORDER BY id", (n,))]
    table = [r for r in rolls if not _offscreen_roll(r)]
    if table:
        lines.append("Rolls:")
        lines += [roll_line(L, r) for r in table]
    if ctx.for_table:                                    # (the world's rolls and who heard what since: not the table's)
        return "\n".join(lines)
    if len(rolls) > len(table):
        lines.append(f"(+{len(rolls) - len(table)} offscreen roll(s) the world made after it - in the W# moments)")
    heard = _heard_by(game, f"T{n}") if node else None
    if heard:
        lines.append(heard)
    return "\n".join(lines)


def _read_offscreen(ctx, wid: str) -> str:
    game, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    node = S.node(wid)
    if not node or node["kind"] != "slice":
        return f"[{wid}] no such offscreen moment on file."
    if ctx.for_table:
        return f"[{wid}] {AWAY}."
    ctx.expanded.add(wid)
    members = S.members_of(wid)
    when = _when(game, node)
    lines = [f"=== {wid} · offscreen, no PC saw it · after T{node['created_turn']}" + (f" · {when}" if when else "")
             + " ===",
             "Who: " + ", ".join(f"{_name(L, m)} ({role})" for m, role in members if L.get(m)),
             node["text"]]
    actors = {m for m, _ in members}
    rolls = [dict(r) for r in game.conn.execute("SELECT * FROM tests WHERE turn_id=? ORDER BY id",
                                                (node["created_turn"],))]
    rolls = [r for r in rolls if _offscreen_roll(r) and r["actor_id"] in actors]
    if rolls:
        lines.append("Rolls (the world's, around then):")
        lines += [roll_line(L, r) for r in rolls]
    heard = _heard_by(game, wid)
    if heard:
        lines.append(heard)
    return "\n".join(lines)


# ── recall ──────────────────────────────────────────────────────────────

def recall(ctx, args: dict) -> str:
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    ids = _list(args["ids"])
    parts = []
    for ref in ids[:RECALL_MAX]:
        nid = norm_id(ref)
        node = S.node(nid)
        if node is None:
            ent = L.find(ref)
            if ent is None:
                parts.append(f"[{ref}] unknown id (search_memory finds things by name)")
                continue
            nid, node = ent["id"], S.node(ent["id"])
        if node is not None and hidden(ctx, nid, node):
            parts.append(f"[{nid}] {AWAY}.")
            continue
        ctx.expanded.add(nid)
        if node is None:                                 # an entity that has never been in a scene
            parts.append("\n".join([sr_lite.sheet(L, nid, full=True)] + ([] if ctx.for_table else _mind(ctx, nid))))
            continue
        parts.append("\n".join(_recall_node(ctx, nid, node)))
    if len(ids) > RECALL_MAX:
        parts.append(f"(recall opens {RECALL_MAX} ids a call - left out: {', '.join(ids[RECALL_MAX:])})")
    return "\n\n".join(parts)


def _recall_node(ctx, nid: str, node: dict) -> list[str]:
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    bits = [node["kind"], f"T{node['created_turn']}"] if node["kind"] != "entity" else [node["kind"]]
    if node.get("scene_id") and node["kind"] == "slice":
        bits.append(f"S{node['scene_id']}")
    when = _when(g, node) if node["kind"] in ("slice", "belief") else ""
    from . import doubts
    mark = (doubts.secret(g, doubts.get(g, nid) or {"id": nid})["label"] if node["kind"] == "doubt"
            else _whisper(g, node))                     # (a whisper's doubt is marked like its slice)
    lines = [f"[{nid}] ({', '.join(bits + ([when] if when else []))}) {mark}{node['text']}"]
    newer = S.superseded_by(nid)
    if newer:                                            # the diode, forward: never play an old version as current
        cur = S.newest(nid) or newer
        now = S.node(cur) or {}
        shown = "(not the table's to see)" if hidden(ctx, cur, now or None) else _clip(now.get("text", ""), 300)
        lines.append(f"  SUPERSEDED by [{newer}]" + (f", since by [{cur}]" if cur != newer else "")
                     + f" (T{now.get('created_turn')}) - that's the current version: {shown}")
    for old in S.replaced(nid)[-3:]:                     # ... and back: what this one replaced
        o = S.node(old)
        if o and not hidden(ctx, old, o):
            lines.append(f"  Replaces [{old}] (T{o['created_turn']}): {_clip(o['text'], 200)}")
    pic = None if ctx.for_table else S.clarification(nid)    # (the GM's picture of someone: not the table's)
    if pic:
        lines.append(f"  Current picture [{pic['id']}] (T{pic['created_turn']}): {pic['text']}")
    if node["kind"] == "tension":
        from . import tensions
        q = tensions.get(g, nid) or {}
        gm = not ctx.for_table                           # (its next step is the GM's: a story seed files secrets there)
        lines.append(f"  {q.get('status')}" + (f" · pressure {q.get('pressure', 0):.1f}" if gm else "")
                     + f" · stakes {q.get('stakes')}" + (f" · next: {q['next']}" if gm and q.get("next") else "")
                     + (f" · the PCs know: {q['public']}" if q.get("public") else "")
                     + (f" · resolved: {q['resolution']}" if q.get("resolution") else ""))
    if node["kind"] == "doubt":                          # the record's continuity: both sides are its links, below
        d = doubts.get(g, nid) or {}
        lines.append(f"  DOUBT {d.get('status')} · raised T{d.get('raised_turn')} by "
                     f"{doubts.BY.get(d.get('raised_by'), d.get('raised_by'))}"
                     + (f" ({d['times']}x)" if (d.get("times") or 1) > 1 else "")
                     + (f" · {d['status']} T{d['resolved_turn']}: {d['resolution']}" if d.get("resolution") else "")
                     + "  - on: " + (", ".join(f"{_name(L, a)} [{a}]" if L.get(a) else a
                                               for a in doubts.about(g.conn, nid)) or "nothing on file"))
        for a in doubts.about(g.conn, nid):              # each side, in its own words
            o = S.node(a) if not L.get(a) else None
            if o and hidden(ctx, a, o):
                lines.append(f"  Side [{a}] - {AWAY}")
            elif o:                                      # (a whisper's side says so, as everywhere else)
                kind = "picture" if o["kind"] == "clarification" else o["kind"]
                lines.append(f"  Side [{a}] ({kind}, T{o['created_turn']}) {_whisper(g, o)}{_clip(o['text'], 300)}"
                             + _superseded(S, a))
    else:                                                # (an open doubt about this memory or person)
        lines += doubts.recall_lines(g, nid, hide=lambda x: hidden(ctx, x))
    if node["kind"] == "entity":
        lines.append(sr_lite.sheet(L, nid, full=True))
        if ctx.for_table:
            lines.append("  (an aside is read by the whole table: their mind, persona, goals and your notes on them "
                         "aren't looked up here)")
        else:
            lines += _mind(ctx, nid)
    elif node["kind"] == "slice":
        who = [f"{_name(L, m)} ({role})" for m, role in S.members_of(nid)]
        lines.append("  Involved: " + ", ".join(who))
        if nid.startswith("T"):
            lines.append(f"  (read_turn {nid} for what was said, word for word)")
        heard = None if ctx.for_table else _heard_by(g, nid)
        if heard:
            lines.append("  " + heard)
    elif node["kind"] == "scene" and nid[1:].isdigit():
        r = g.conn.execute("SELECT MIN(created_turn), MAX(created_turn), COUNT(*) FROM nodes WHERE kind='slice' AND "
                           "scene_id=?", (int(nid[1:]),)).fetchone()
        if r[2]:
            lines.append(f"  Turns: T{r[0]}-T{r[1]} ({r[2]} on file)")
    else:
        people = _people(ctx, nid, node["kind"])
        if people:
            lines.append("  " + people)
    for n in [] if ctx.for_table and node["kind"] != "doubt" else S.notes_for(nid, 6, unfolded=bool(pic)):
        lines.append(f"  DM note [{n['id']}] (T{n['created_turn']}): {n['text']}")
    if node["kind"] != "doubt":                          # (a doubt's links are its sides, listed above)
        lines += _linked(ctx, nid)
    return lines


def _people(ctx, nid: str, kind: str) -> str | None:
    """Who a fact, belief, goal, hook, tension or note is about, held by, wanted by or from."""
    L, S = ctx.game.ledger, ctx.game.sub
    label = {"about": "about", "holds": "held by", "wants": "wanted by", "from": "from"}
    groups: dict[str, list[str]] = {}
    for link in S.links_of(nid):
        if link["kind"] in label and L.get(link["other"]):
            groups.setdefault(label[link["kind"]], []).append(_name(L, link["other"]))
    if kind in ("note", "clarification"):
        on = [r[0] for r in ctx.game.conn.execute("SELECT target_id FROM annotates WHERE note_id=?", (nid,))]
        if on:
            groups["on"] = [_name(L, t) if L.get(t) else t for t in on]
    return "; ".join(f"{k} {', '.join(v[:6])}" for k, v in groups.items()) or None


def _linked(ctx, nid: str) -> list[str]:
    """The strongest links to turns, facts, scenes and tensions - strength first, then the most recent (live: the
    old cut took the six strongest links of any kind and kept only those, so a person came back with two)."""
    g, S = ctx.game, ctx.game.sub
    found = []
    for link in S.links_of(nid):
        o = S.node(link["other"])
        if o and o["kind"] in LINKED_KINDS and not hidden(ctx, o["id"], o):
            found.append((link["strength"], o["created_turn"], o))
    found.sort(key=lambda x: (x[0], x[1]), reverse=True)
    out = []
    for _, _, o in found[:LINKED]:
        if o["kind"] == "slice":
            out.append("  Linked: " + slice_line(g, o, ctx.turn_id))
        else:
            out.append(f"  Linked: [{o['id']}] ({o['kind']}, T{o['created_turn']}) {_clip(o['text'], 200)}"
                       + _superseded(S, o["id"]))
    return out


def _mind(ctx, eid: str) -> list[str]:
    """A person's mind, as the GM keeps it: what they think of each person now (current views only - a superseded
    belief is history), their attitude numbers, their active goals, the last things they heard and from whom, where
    they are, and where others stand toward them. Live: recalling an NPC returned none of this."""
    from . import world
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    ent = L.get(eid)
    if not ent or ent["kind"] not in ("pc", "npc", "faction", "spirit"):
        return []
    lines = []
    if ent["kind"] in ("npc", "faction"):
        bible = world.persona_line(ent)
        if bible:
            lines.append(f"  Persona (GM-only): {bible}")
    atts = {r["key"].split(":", 1)[1]: int(r["value"]) for r in g.conn.execute(
        "SELECT key, value FROM stats WHERE entity_id=? AND key LIKE 'attitude:%'", (eid,))}
    views: dict[str, dict] = {}
    for b in S.beliefs_of(eid):                          # (current only, newest first)
        about = next((x["other"] for x in S.links_of(b["id"]) if x["kind"] == "about"), None)
        if about and about not in views:
            views[about] = b
    rows = []
    for a in list(dict.fromkeys(list(views) + list(atts)))[:VIEWS]:
        b, att = views.get(a), atts.get(a)
        rows.append(f"    {_name(L, a)} [{a}]" + (f" {att:+d}" if att is not None else "")
                    + (f" ([{b['id']}], since T{b['created_turn']}): {b['text']}" if b else " (no view on file)"))
    if rows:
        lines.append("  Mind - what they think of people now (attitude -3..+3; current views, the old ones superseded):")
        lines += rows
    goals = world.agendas_of(g, eid)
    if goals:
        lines.append("  Goals (active): " + "; ".join(f"[{a['id']}] {a['goal']} (since T{a['created_turn']}, "
                                                     f"{a['steps']} step{'s' if a['steps'] != 1 else ''})"
                                                     for a in goals[:GOALS]))
    heard = S.heard(eid, HEARD)
    if heard:
        how = {"told": "told by", "rumor": "a rumor via"}
        lines.append("  Heard lately (second-hand, newest first):")
        for h in heard:
            src = f"{how.get(h['how'], h['how'])} {_name(L, h['source'])}" if h.get("source") else h["how"]
            lines.append(f"    [{h['id']}] (T{h['heard_turn']}, {src}) {_clip(h['text'], 200)}")
    where = "here, in this scene" if L.scene_of(eid) == ctx.scene_id else world.whereabouts(g, eid)
    if where:
        lines.append(f"  Where: {where}")
    toward = g.conn.execute("SELECT entity_id, value FROM stats WHERE key=? AND value<>0 ORDER BY ABS(value) DESC, "
                            "entity_id LIMIT ?", (f"attitude:{eid}", TOWARD)).fetchall()
    if toward:
        lines.append("  Toward them: " + ", ".join(f"{_name(L, r['entity_id'])} {int(r['value']):+d}" for r in toward))
    return lines


# ── search_memory ───────────────────────────────────────────────────────

def search(ctx, args: dict) -> str:
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    query = str(args.get("query") or "")
    terms = search_terms(query)
    about, unknown = [], []
    for ref in _list(args.get("about")):
        nid = _resolve(ctx, ref)
        (about.append(nid) if nid else unknown.append(ref))
    kinds = [k.strip().lower() for k in _list(args.get("kinds"))]
    bad_kinds = [k for k in kinds if k not in SEARCH_KINDS]
    kinds = [k for k in kinds if k in SEARCH_KINDS]
    try:
        limit = max(1, min(SEARCH_MAX, int(args.get("limit") or SEARCH_LIMIT)))
    except (TypeError, ValueError):
        limit = SEARCH_LIMIT
    lo, hi = _int(args.get("from_turn")), _int(args.get("to_turn"))
    if unknown and not about:
        return f"Nobody on file as {', '.join(unknown)} - about takes ids or names on file."
    if not terms and not about:
        return ("Nothing to search for - give it words (names count, even short ones like 'Bo'), or about: who it "
                "involves.")
    rows = S.search(query, None if ctx.for_table else limit, kinds=kinds or None, about=about or None, from_turn=lo,
                    to_turn=hi)
    if ctx.for_table:                                    # (every match, then the table's: the limit is of those)
        rows = [r for r in rows if not hidden(ctx, r["id"], r)][:limit]
    said = _said(ctx, terms, about, lo, hi, limit) if args.get("in_narration") else []
    filters = ([f"words: {', '.join(terms)}"] if terms else []) + (
        [f"involving all of {', '.join(_name(L, a) for a in about)}"] if about else []) + (
        [f"kinds: {', '.join(kinds)}"] if kinds else []) + (
        [f"turns {lo if lo is not None else '...'}-{hi if hi is not None else 'now'}"] if lo is not None or hi is not None
        else [])
    out = [f"({'; '.join(filters)}"
           + (f"; not on file: {', '.join(unknown)}" if unknown else "")
           + (f"; unknown kinds left out: {', '.join(bad_kinds)} - kinds are {', '.join(SEARCH_KINDS)}" if bad_kinds
              else "") + ")"]
    for r in rows:
        out.append(_hit_line(ctx, r, terms))
        if r["kind"] != "note":
            _saw(ctx, r["id"])
    if not rows:
        out.append("No memories match." + ("" if args.get("in_narration") or not terms else
                                           " (in_narration: true also searches what was actually said)"))
    if args.get("in_narration"):
        out.append("In what was said (your narration and the players' posts):")
        out += said or ["  (nothing)"]
    return "\n".join(out)


def _hit_line(ctx, r: dict, terms: list[str]) -> str:
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    if r["kind"] == "slice":
        line = slice_line(g, {**r, "text": snippet(r["text"], terms, 420)}, ctx.turn_id)
    else:
        label = {"clarification": "picture"}.get(r["kind"], r["kind"])
        on = ""
        if r["kind"] in ("note", "clarification"):
            targets = [x[0] for x in g.conn.execute("SELECT target_id FROM annotates WHERE note_id=?", (r["id"],))]
            on = (" on " + ", ".join(_name(L, t) if L.get(t) else t for t in targets[:4])) if targets else ""
        turn = "" if r["kind"] == "entity" else f", T{r['created_turn']}"
        mark = ""
        if r["kind"] == "doubt":                         # open, or how it was settled - and a whisper's, marked
            from . import doubts
            d = doubts.get(g, r["id"]) or {}
            label = f"doubt, {d.get('status', '?')}"
            turn += f"; {d['status']} T{d['resolved_turn']}: {d['resolution'][:160]}" if d.get("resolution") else ""
            mark = doubts.secret(g, d or {"id": r["id"]})["label"]
        line = f"[{r['id']}] ({label}{on}{turn}) {mark}{snippet(r['text'], terms)}"
    if r.get("superseded_by"):
        line += f"  (SUPERSEDED by [{r['superseded_by']}] - that's the current version)"
    return line


def _said(ctx, terms: list[str], about: list[str], lo: int | None, hi: int | None, limit: int) -> list[str]:
    """search_memory in_narration: the turns whose narration or posts hold the words - every word first, then the
    most, then the newest - each with the turn and the passage around them."""
    if not terms:
        return []
    g, S = ctx.game, ctx.game.sub
    conds, args = ["status IN ('committed','seed')", "id<>?"], [ctx.turn_id]
    if ctx.for_table:                                    # (at the table: never another player's whisper)
        conds.append("(private IS NULL OR private=?)")
        args.append(ctx.asker)
    conds.append("(" + " OR ".join("lower(narration) LIKE ? OR lower(inputs) LIKE ?" for _ in terms) + ")")
    args += [x for t in terms for x in (f"%{t}%", f"%{t}%")]
    if lo is not None:
        conds.append("id>=?")
        args.append(lo)
    if hi is not None:
        conds.append("id<=?")
        args.append(hi)
    near = S.involving(about) if about else None
    pats = [(t, term_re(t)) for t in terms]
    hits = []
    for r in g.conn.execute(f"SELECT id, scene_id, inputs, narration, private FROM turns WHERE {' AND '.join(conds)}",
                            args):
        if near is not None and f"T{r['id']}" not in near:
            continue
        found, best = set(), None
        for label, text in [("narration", r["narration"] or "")] + [
                (f"{_who(g, h)}'s post", x) for h, x in _posts(r["inputs"])]:
            got = [t for t, p in pats if p.search(text)]
            found |= set(got)
            if got and (best is None or len(got) > len(best[2])):
                best = (label, text, got)
        if found:
            hits.append((len(found) == len(terms), len(found), r["id"], dict(r), best))
    hits.sort(key=lambda h: h[:3], reverse=True)
    out = []
    for _, _, tid, r, (label, text, got) in hits[:limit]:
        when = _when(g, S.node(f"T{tid}"), tid)
        where = ", ".join(x for x in (f"S{r['scene_id']}" if r["scene_id"] else "", when) if x)
        out.append(f"[T{tid}] ({where}){' WHISPER (private)' if r['private'] else ''} {label}: "
                   f"\"{snippet(text, got)}\"")
        _saw(ctx, f"T{tid}")
    return out


# ── timeline ────────────────────────────────────────────────────────────

def timeline(ctx, args: dict) -> str:
    g, L, S = ctx.game, ctx.game.ledger, ctx.game.sub
    ids, unknown = [], []
    for ref in _list(args.get("ids")):
        nid = _resolve(ctx, ref)
        (ids.append(nid) if nid else unknown.append(ref))
    ids = list(dict.fromkeys(ids))
    if not ids:
        return ("Whose timeline? ids: people (or a place, an item) by id or name."
                + (f" Not on file: {', '.join(unknown)}." if unknown else ""))
    try:
        limit = max(1, min(TIMELINE_MAX, int(args.get("limit") or TIMELINE_LIMIT)))
    except (TypeError, ValueError):
        limit = TIMELINE_LIMIT
    lo, hi = _int(args.get("from_turn")), _int(args.get("to_turn"))
    conds = ["n.kind='slice'"] + ["n.id IN (SELECT slice_id FROM members WHERE node_id=?)" for _ in ids]
    qargs: list = list(ids)
    if ctx.for_table:                                    # (at the table: public moments and the asker's own whispers)
        conds.append("(n.visibility='public' OR n.id IN (SELECT 'T' || id FROM turns WHERE private=?))")
        qargs.append(ctx.asker)
    if lo is not None:
        conds.append("n.created_turn>=?")
        qargs.append(lo)
    if hi is not None:
        conds.append("n.created_turn<=?")
        qargs.append(hi)
    where = " AND ".join(conds)
    total = g.conn.execute(f"SELECT COUNT(*) FROM nodes n WHERE {where}", qargs).fetchone()[0]
    rows = [dict(r) for r in g.conn.execute(f"SELECT n.* FROM nodes n WHERE {where} ORDER BY n.created_turn DESC, "
                                            f"n.rowid DESC LIMIT ?", (*qargs, limit))][::-1]
    names = " & ".join(_name(L, i) for i in ids)
    span = (f" in T{lo if lo is not None else 1}-T{hi if hi is not None else ctx.turn_id}"
            if lo is not None or hi is not None else "")
    note = f" (not on file: {', '.join(unknown)})" if unknown else ""
    if not rows:
        return f"Nothing on file involving {names}{span}.{note}"
    roles: dict[tuple, list[str]] = {}
    marks = ",".join("?" * len(rows))
    for m in g.conn.execute(f"SELECT slice_id, node_id, role FROM members WHERE slice_id IN ({marks}) AND node_id IN "
                            f"({','.join('?' * len(ids))})", (*[r["id"] for r in rows], *ids)):
        roles.setdefault((m["slice_id"], m["node_id"]), []).append(m["role"])
    out = [f"{names}: {total} moment{'s' if total != 1 else ''} on file{span}"
           + (f" - the last {len(rows)}, oldest first (from_turn / to_turn for earlier ones)" if total > len(rows)
              else ", oldest first") + f":{note}"]
    for r in rows:
        when = _when(g, r) or f"turn {r['created_turn']}"
        place = f"S{r['scene_id']}, " if r.get("scene_id") else ""
        line = f"[{r['id']}] ({place}{when}) {_whisper(g, r)}{r['text']}"
        if len(ids) > 1:
            line += "  (" + ", ".join(f"{_name(L, i)}: {'/'.join(roles[(r['id'], i)])}" for i in ids
                                      if (r["id"], i) in roles) + ")"
        out.append(line)
        _saw(ctx, r["id"])
    return "\n".join(out)
