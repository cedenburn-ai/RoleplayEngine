"""What one character could look up (!askdm, DESIGN.md §8e, built 2026-10-26): their own memories, never the GM's.

!askdm answers as the character's memory: "what did Kaz say the price was?" deserves the words, not the gist. It had
the eight witnessed moments its question's keywords ranked highest, and nothing to look further with. The GM's
notebook (research.py) can read every word, but it's full of what a character can't know: DM notes, current pictures,
NPC minds and goals, hooks, tensions, doubts, the offscreen world, other players' whispers. A Scope is the part of the
record one character holds, worked out once per question:
- witnessed: the T#/W# moments they were in, in a witness role (actor, target, present, location) - a public turn, an
  offscreen one they took part in (an NPC a player is inhabiting), and a whisper only if they sent it. A whisper's
  slice lists its target too, who may never have noticed ("Razor palms Kaz's keycard": Kaz is a member);
- heard: what they were told or overheard (knows) - the gist, second-hand, never the words;
- facts: canon, except what came out of a moment they weren't at (linked to it, or set down during it - a fight
  round too) and what the canon or an aside wrote between turns about no moment they hold;
- turns: what they can read word for word - witnessed public turns, their own whispers, the fight rounds they fought.
The three lookups (search_memory, read_turn, timeline) reach only that. Asking after anything else answers the same as
asking after nothing ("not a turn Razor was in", "Razor knows nobody by that name"), so a refusal never says a secret
is there. The fourth tool writes, but only to the GM: a doubt (doubts.py) when what they hold doesn't add up - linked
to what they hold, and answered the same whatever is on file.
"""
from __future__ import annotations

import json

from ..engine.ledger import LedgerError
from ..substrate.packet import _ago
from ..substrate.store import norm_id, search_terms, term_re
from .dmblock import between_turns
from .research import (READ_MAX, SEARCH_LIMIT, SEARCH_MAX, TIMELINE_LIMIT, TIMELINE_MAX, TURN_CHARS, POST_CHARS,
                       _clip, _int, _list, _name, _offscreen_roll, _posts, _when, _who, passages, roll_line, snippet,
                       turn_refs)

KINDS = ("slice", "fact", "scene")      # what a character's memory holds (notes, pictures, minds, doubts never)


def _tool(name: str, description: str, props: dict, required: list[str]) -> dict:
    return {"name": name, "description": description,
            "input_schema": {"type": "object", "properties": props, "required": required}}


_TURN = {"type": "integer", "description": "Only from / up to this turn number (150 for T150)."}
TOOLS = [
    _tool("search_memory", "Search what this character remembers - the moments they were there for, what they heard "
          "second-hand, the facts they'd know - by words (names count, even short ones like 'Bo'). Every word matched "
          "ranks first; each hit shows the passage around the words. in_narration also searches what was actually "
          "said in the turns they were in.",
          {"query": {"type": "string", "description": "The words to look for (names, a phrase)."},
           "about": {"type": "array", "items": {"type": "string"},
                     "description": "Only memories involving ALL of these people, places or things (names or ids)."},
           "from_turn": _TURN, "to_turn": _TURN,
           "in_narration": {"type": "boolean", "description": "Also search the narration and the players' posts of "
                                                              "the turns they were in, word for word."},
           "limit": {"type": "integer", "description": "How many hits (default 10, at most 20)."}},
          ["query"]),
    _tool("read_turn", "What was actually said in a turn this character was in: the players' posts, the narration word "
          "for word, the rolls - for the exact terms of a deal, a promise, who said what. Turns they weren't in can't "
          "be read.",
          {"turn_ids": {"type": "array", "items": {"type": "string"},
                        "description": "'T150', '150' or a range 'T148-T150' (6 turns a call at most)."},
           "around": {"type": "string", "description": "A phrase or a few words: only the passages of the narration "
                                                       "around them, not the whole turn."}},
          ["turn_ids"]),
    _tool("timeline", "What this character has been through with someone (or at a place, with an item): the moments "
          "they were in that involve ALL of the ids, oldest first - the most recent `limit` in the range.",
          {"ids": {"type": "array", "items": {"type": "string"}, "description": "People, places or things, by name or "
                                                                               "id."},
           "from_turn": _TURN, "to_turn": _TURN,
           "limit": {"type": "integer", "description": "How many moments (default 12, at most 30)."}},
          ["ids"]),
    _tool("doubt", "Set down for the GM something in this character's memory that doesn't add up: two memories that "
          "disagree, a memory against what was actually said, or something the player remembers that isn't there. It "
          "goes on the GM's list to sort out before it matters. It changes nothing now and answers the same whatever "
          "is on file, so tell the player what each version says either way.",
          {"ids": {"type": "array", "items": {"type": "string"},
                   "description": "The [id]s on both sides, as your lookups show them (T#, F#, people)."},
           "text": {"type": "string", "description": "What doesn't add up: both versions, where each one is, and what "
                                                     "the player remembers."}},
          ["text"]),
]
NAMES = tuple(t["name"] for t in TOOLS)
DOUBTS_MAX = 2              # doubts one question sets down
NOTED = "Set down for the GM to look into."           # (the same words whatever was on file: nothing to read in it)


class Scope:
    """The record as one character holds it (the module docstring). `now` is the next turn's number; `opened` collects
    what they read by id, for the lookup touch."""

    def __init__(self, game, eid: str):
        self.game, self.eid = game, eid
        self.name = (game.ledger.get(eid) or {}).get("name") or eid
        self.now = game.turn_no() + 1
        self.opened: set[str] = set()
        self.calls = self.doubts = 0
        conn, roles = game.conn, game.settings.knobs.witness_roles
        own = {r[0] for r in conn.execute("SELECT id FROM turns WHERE private=? AND status IN ('committed','seed')",
                                          (eid,))}
        self.witnessed: set[str] = set()
        self.scenes: set[str] = set()                    # (the scenes of the moments they were in)
        for r in conn.execute(f"SELECT DISTINCT n.id, n.visibility, n.scene_id FROM nodes n JOIN members m ON "
                              f"m.slice_id=n.id WHERE n.kind='slice' AND m.node_id=? AND m.role IN "
                              f"({','.join('?' * len(roles))})", (eid, *roles)):
            mine = r["id"][0] == "T" and r["id"][1:].isdigit() and int(r["id"][1:]) in own   # (a whisper they sent)
            if r["visibility"] != "private" or mine:
                self.witnessed.add(r["id"])
                if r["scene_id"] is not None:
                    self.scenes.add(f"S{r['scene_id']}")
        self.heard: dict[str, dict] = {}
        for r in conn.execute("SELECT k.node_id, k.how, k.source, k.turn FROM knows k JOIN nodes n ON n.id=k.node_id "
                              "WHERE k.holder=? AND n.kind IN ('slice','fact') AND n.visibility<>'gm' ORDER BY k.turn",
                              (eid,)):
            if r["node_id"] not in self.witnessed:
                self.heard[r["node_id"]] = dict(r)
        self.turns = {int(s[1:]) for s in self.witnessed if s[0] == "T" and s[1:].isdigit()} | own
        self.turns |= self._rounds()
        self.facts = self._facts()
        self._known: set[str] | None = None

    def _rounds(self) -> set[int]:
        """The fight rounds they fought: a round writes no slice of its own (its fight's log has it)."""
        out = set()
        fights = self.game.conn.execute("SELECT scene_id, started_turn, ended_turn, members, positions FROM encounters")
        for e in fights.fetchall():
            try:
                inside = self.eid in json.loads(e["members"] or "{}") or self.eid in json.loads(e["positions"] or "{}")
            except ValueError:
                inside = False
            if inside and e["started_turn"] is not None:
                out |= {r[0] for r in self.game.conn.execute(
                    "SELECT id FROM turns WHERE scene_id=? AND id BETWEEN ? AND ? AND private IS NULL AND "
                    "status='committed'", (e["scene_id"], e["started_turn"], e["ended_turn"] or self.now))}
        return out

    def _facts(self) -> set[str]:
        """Canon they'd know: a fact that came out of a moment (linked `about` its slice) if they were there or heard
        of it; a fact set down during a turn - the GM's, the memory pass's - if they were in that turn (one they
        witnessed, their own whisper, a fight round they fought); canon set down outside play (the campaign's setup);
        a fact a turn they were in drew on (its `recall` link - it came up in front of them); and any fact they were
        told. A fact the canon read-back or an aside wrote between turns (dmblock.between_turns) was set down in front
        of no one: it reaches them through the moment it names, or not at all.
        Review (2026-10-26): "set down during a turn" was read off the T# slices on file - and a fight round writes
        none, so a fact from a round (the GM's "Kaz took a bullet and is hiding it", the memory pass's own) counted as
        setup and every PC "remembered" it, one across town included; and a canon fix about a whisper inherited the
        last public turn's audience."""
        conn = self.game.conn
        source: dict[str, set[str]] = {}                 # fact -> the moment it came out of
        drawn: dict[str, set[str]] = {}                  # fact -> the later moments that drew on it
        for r in conn.execute("SELECT l.kind, x.id AS a, x.kind AS ak, y.id AS b FROM links l JOIN nodes x ON x.id=l.a "
                              "JOIN nodes y ON y.id=l.b WHERE l.kind IN ('about','recall') AND ((x.kind='fact' AND "
                              "y.kind='slice') OR (x.kind='slice' AND y.kind='fact'))"):
            f, s = (r["a"], r["b"]) if r["ak"] == "fact" else (r["b"], r["a"])
            (source if r["kind"] == "about" else drawn).setdefault(f, set()).add(s)
        seen = self.witnessed | set(self.heard)
        on_file = {r[0] for r in conn.execute("SELECT id FROM turns")}   # (played, seeded - or being played now)
        between = between_turns(conn)
        out = {f for f in self.heard if f.startswith("F")}
        for r in conn.execute("SELECT id, visibility, created_turn FROM nodes WHERE kind='fact' AND "
                              "visibility IN ('public','private')"):
            moments, born = source.get(r["id"]), r["created_turn"]
            if moments:
                known = bool(moments & seen)
            elif r["id"] in between:
                known = False
            else:
                known = r["visibility"] == "public" and (born in self.turns or born not in on_file)
            if known or (r["visibility"] == "public" and drawn.get(r["id"], set()) & self.witnessed):
                out.add(r["id"])
        return out

    def holds(self, nid: str) -> bool:
        return nid in self.witnessed or nid in self.heard or nid in self.facts or nid in self.scenes

    def latest(self, nid: str) -> str | None:
        """The newest version of nid they hold - the supersession chain walked a step at a time - or None when they
        hold nothing newer. Review (2026-10-26): only the chain's end was checked, so with F5 -> F6 -> F7 and F7 out
        of Ghost's whisper, Razor held F5 and its correction F6 and "remembered" both prices as current."""
        S, cur, seen, best = self.game.sub, nid, {nid}, None
        while True:
            nxt = S.superseded_by(cur)
            if not nxt or nxt in seen:
                return best
            seen.add(nxt)
            best = nxt if self.holds(nxt) else best
            cur = nxt

    def known(self) -> set[str]:
        """The people, places and things they've met: in a moment they hold, what a fact they know is about, who's
        in the room with them now, what they carry."""
        if self._known is None:
            g, conn = self.game, self.game.conn
            out = {self.eid}
            pool = list(self.witnessed | set(self.heard))
            for i in range(0, len(pool), 500):
                part = pool[i:i + 500]
                out |= {r[0] for r in conn.execute(f"SELECT node_id FROM members WHERE slice_id IN "
                                                   f"({','.join('?' * len(part))})", part)}
            facts = list(self.facts)
            for i in range(0, len(facts), 500):
                part = facts[i:i + 500]
                marks = ",".join("?" * len(part))
                out |= {r[0] for r in conn.execute(f"SELECT CASE WHEN a IN ({marks}) THEN b ELSE a END FROM links "
                                                   f"WHERE kind='about' AND (a IN ({marks}) OR b IN ({marks}))",
                                                   part * 3)}
            here = g.ledger.scene_of(self.eid)
            if here:
                out |= set(g.ledger.roster(here))
            out |= {i["id"] for i in g.ledger.holdings(self.eid)}
            self._known = {x for x in out if g.ledger.get(x)}
        return self._known

    def people(self, refs) -> tuple[list[str], list[str]]:
        """Names or ids -> (the ids they know, the refs they don't). Someone they never met reads as no one."""
        ids, unknown = [], []
        for ref in _list(refs):
            ent = self.game.ledger.find(str(ref).strip().strip("[]"))
            (ids.append(ent["id"]) if ent and ent["id"] in self.known() else unknown.append(str(ref)))
        return list(dict.fromkeys(ids)), unknown

    def involves(self, nid: str, kind: str, ids: list[str]) -> bool:
        """A moment with all of them in it, or a fact about all of them."""
        conn = self.game.conn
        if kind == "slice":
            have = {r[0] for r in conn.execute("SELECT node_id FROM members WHERE slice_id=?", (nid,))}
        else:
            have = {r["b"] if r["a"] == nid else r["a"] for r in conn.execute(
                "SELECT a, b FROM links WHERE (a=? OR b=?) AND kind='about'", (nid, nid))}
        return all(i in have for i in ids)


# ── the tools ───────────────────────────────────────────────────────────

def run(sc: Scope, name: str, args: dict) -> str:
    """One lookup, within the question's cap (models.askdm_research_calls) - or a doubt, outside it: what it found
    that doesn't add up is set down even when the looking up is done."""
    if name == "doubt":
        return doubt(sc, args)
    cap = sc.game.settings.models.askdm_research_calls
    sc.calls += 1
    if sc.calls > cap:
        return f"That's all the looking up for this question ({cap} lookups) - answer with what you have."
    fn = {"search_memory": search, "read_turn": read_turn, "timeline": timeline}.get(name)
    if fn is None:
        return f"No {name} here - only {', '.join(NAMES)}."
    return fn(sc, args)


def doubt(sc: Scope, args: dict) -> str:
    """What !askdm found disagreeing - two memories, a memory and the words said, or the player against the record -
    goes on the GM's DOUBTS list (doubts.raise_, by 'askdm'), never into the ether. The owner: "if the dm notices a story
    inconsistency we shouldn't let it go into the ether"; review (2026-10-26): !askdm read the bar turn's "Five hundred
    by Friday" beside a fact of a thousand, said so to one player in a DM, and nothing was kept. It links only what
    the character holds (and the character): an id they don't hold is left out unsaid, and the reply is the same
    whatever happened - new, raised again, settled long ago - so it can't tell them anything is there. It reopens
    nothing: one character's view isn't enough to overrule how the GM settled it."""
    from . import doubts
    text = " ".join(str(args.get("text") or "").split())
    if not text:
        return "Say what doesn't add up - both versions - in text."
    sc.doubts += 1
    if sc.doubts > DOUBTS_MAX:
        return f"(a question sets down {DOUBTS_MAX} doubts at most - fold the rest into those)"
    ids = [sc.eid]
    for ref in _list(args.get("ids")):
        nid = norm_id(str(ref).strip().strip("[]"))
        if sc.holds(nid):
            ids.append(nid)
        else:                                            # (a person they know, by name or id)
            ids += sc.people([ref])[0]
    r = doubts.raise_(sc.game, f"{sc.name}'s memory: {text}", list(dict.fromkeys(ids)), sc.now - 1, by="askdm")
    sc.game.out(f"[DOUBT] {r['id']} {r['status']} ({doubts.NAMED['askdm']}, {sc.name}): {text}")
    return NOTED


def tool_result(sc: Scope, block) -> dict:
    """A tool_use block -> its tool_result. Nothing here writes, so a slip is the model's to retry, never a flag."""
    try:
        args = block.input if isinstance(block.input, dict) else json.loads(block.input)
        return {"type": "tool_result", "tool_use_id": block.id, "content": run(sc, block.name, args)}
    except (LedgerError, KeyError, ValueError, TypeError, OverflowError) as exc:
        return {"type": "tool_result", "tool_use_id": block.id, "is_error": True,
                "content": f"Error: {exc if not isinstance(exc, KeyError) else f'missing field {exc}'}"}


def _rows(sc: Scope) -> list[dict]:
    """Every memory they hold, with its heat."""
    rows = sc.game.conn.execute(
        f"SELECT n.*, COALESCE(e.energy, 0) AS energy FROM nodes n LEFT JOIN energy e ON e.node_id=n.id "
        f"WHERE n.kind IN ({','.join('?' * len(KINDS))})", KINDS)
    return [dict(r) for r in rows if sc.holds(r["id"])]


def search(sc: Scope, args: dict) -> str:
    g = sc.game
    query = str(args.get("query") or "")
    terms = search_terms(query)
    about, unknown = sc.people(args.get("about"))
    try:
        limit = max(1, min(SEARCH_MAX, int(args.get("limit") or SEARCH_LIMIT)))
    except (TypeError, ValueError):
        limit = SEARCH_LIMIT
    lo, hi = _int(args.get("from_turn")), _int(args.get("to_turn"))
    if unknown and not about:
        return f"{sc.name} knows nobody by {', '.join(unknown)}."
    if not terms and not about:
        return "Nothing to search for - give it words (names count, even short ones like 'Bo'), or about: who."
    pats = [(t, term_re(t)) for t in terms]
    hits = []
    for r in _rows(sc):
        if (lo is not None and r["created_turn"] < lo) or (hi is not None and r["created_turn"] > hi):
            continue
        if about and not sc.involves(r["id"], r["kind"], about):
            continue
        r["terms"] = [t for t, p in pats if p.search(r["text"] or "")]
        if terms and not r["terms"]:
            continue
        r["newer"] = sc.latest(r["id"]) if r["kind"] == "fact" else None   # (corrected since - as far as they know)
        hits.append(r)
    if terms:
        hits.sort(key=lambda d: (len(d["terms"]) == len(terms), len(d["terms"]), d["newer"] is None, d["energy"],
                                 d["created_turn"]), reverse=True)
    else:
        hits.sort(key=lambda d: (d["created_turn"], d["energy"]), reverse=True)
    span = lo is not None or hi is not None
    head = ([f"words: {', '.join(terms)}"] if terms else []) + (
        [f"involving all of {', '.join(_name(g.ledger, a) for a in about)}"] if about else []) + (
        [f"turns {lo if lo is not None else '...'}-{hi if hi is not None else 'now'}"] if span else [])
    out = [f"(what {sc.name} remembers - {'; '.join(head)}"
           + (f"; knows nobody by {', '.join(unknown)}" if unknown else "") + ")"]
    out += [_hit(sc, r, terms) for r in hits[:limit]]
    if not hits:
        out.append(f"Nothing {sc.name} remembers matches." + ("" if args.get("in_narration") or not terms else
                                                              " (in_narration: true also searches what was said)"))
    if args.get("in_narration"):
        out.append("In what was said (the turns they were in):")
        out += _said(sc, terms, about, lo, hi, limit) or ["  (nothing)"]
    return "\n".join(out)


def _hit(sc: Scope, r: dict, terms: list[str]) -> str:
    g, L = sc.game, sc.game.ledger
    if r["kind"] == "slice":
        bits = ([f"S{r['scene_id']}"] if r.get("scene_id") else []) + [_ago(g, r, sc.now)]   # ("3 sessions ago")
        h = sc.heard.get(r["id"])
        if h:
            bits.append(_hearsay(L, h))
        elif r["visibility"] == "private":
            bits.append(f"{sc.name}'s whisper - private")
        elif r["visibility"] == "offscreen":
            bits.append(f"away from the others - {sc.name} was there")
        return f"[{r['id']}] ({', '.join(bits)}) {snippet(r['text'], terms, 420)}"
    if r["kind"] == "fact":
        h = sc.heard.get(r["id"])
        how = f", {_hearsay(L, h)}" if h else ""
        line = f"[{r['id']}] (fact, T{r['created_turn']}{how}) {snippet(r['text'], terms)}"
        return line + (f"  (since corrected: [{r['newer']}] is the current version)" if r.get("newer") else "")
    return f"[{r['id']}] (scene) {snippet(r['text'], terms)}"


def _hearsay(L, h: dict) -> str:
    how = {"told": "told by", "rumor": "a rumor via"}
    src = f" {how.get(h['how'], h['how'])} {_name(L, h['source'])}" if h.get("source") else f" {h['how']}"
    return f"heard second-hand at T{h['turn']} -{src}"


def _said(sc: Scope, terms: list[str], about: list[str], lo: int | None, hi: int | None, limit: int) -> list[str]:
    """in_narration over the turns they can read: every word first, then the most, then the newest."""
    if not terms or not sc.turns:
        return []
    g = sc.game
    turns = sorted(n for n in sc.turns if (lo is None or n >= lo) and (hi is None or n <= hi))
    if about:                                            # (a fight round has no slice to say who was in it)
        turns = [n for n in turns if g.sub.exists(f"T{n}") and sc.involves(f"T{n}", "slice", about)]
    pats = [(t, term_re(t)) for t in terms]
    hits = []
    for i in range(0, len(turns), 500):
        part = turns[i:i + 500]
        for r in g.conn.execute(f"SELECT id, scene_id, inputs, narration, private FROM turns WHERE id IN "
                                f"({','.join('?' * len(part))})", part):
            found, best = set(), None
            for label, text in [("narration", r["narration"] or "")] + [
                    (f"{_who(g, h)}'s post", x) for h, x in _posts(r["inputs"])]:
                got = [t for t, p in pats if p.search(text)]
                found |= set(got)
                if got and (best is None or len(got) > len(best[2])):
                    best = (label, text, got)
            if found:
                hits.append((len(found) == len(terms), len(found), r["id"], dict(r), best))
    hits.sort(key=lambda h: h[:3], reverse=True)
    out = []
    for _, _, tid, r, (label, text, got) in hits[:limit]:
        when = _when(g, g.sub.node(f"T{tid}"), tid)
        where = ", ".join(x for x in (f"S{r['scene_id']}" if r["scene_id"] else "", when) if x)
        out.append(f"[T{tid}] ({where}){' (their whisper)' if r['private'] else ''} {label}: \"{snippet(text, got)}\"")
    return out


def read_turn(sc: Scope, args: dict) -> str:
    ids, bad = turn_refs(args.get("turn_ids") or args.get("turn_id"))
    around = str(args.get("around") or "").strip()
    if not ids:
        return ("Which turns? turn_ids like 'T150', '150' or a range 'T148-T150'."
                + (f" Couldn't read: {', '.join(bad)}." if bad else ""))
    out = [f"(couldn't read {', '.join(bad)} - give T#, a number or a range like T148-T150)"] if bad else []
    for ref in ids[:READ_MAX]:
        n = int(ref[1:])
        if ref.startswith("W"):
            out.append(_read_away(sc, ref))
        elif n >= sc.now:
            out.append(f"[T{n}] hasn't been played yet.")
        elif n not in sc.turns:
            out.append(f"[T{n}] isn't a turn {sc.name} was in - only those can be read.")
        else:
            out.append(_read(sc, n, around))
    left = ids[READ_MAX:]
    if left:
        out.append(f"(read_turn reads {READ_MAX} turns a call - left out: {', '.join(left[:4])}"
                   + (f" ... {left[-1]}" if len(left) > 4 else "") + ")")
    return "\n\n".join(out)


def _read(sc: Scope, n: int, around: str) -> str:
    g, L = sc.game, sc.game.ledger
    row = g.conn.execute("SELECT * FROM turns WHERE id=?", (n,)).fetchone()
    if not row or row["status"] not in ("committed", "seed"):
        return f"[T{n}] isn't a turn {sc.name} was in - only those can be read."
    node = g.sub.node(f"T{n}")
    if node:
        sc.opened.add(node["id"])                        # (read by id: the lookup touch)
    scene = L.scene(row["scene_id"]) if row["scene_id"] else None
    when = _when(g, node, n)
    head = [f"T{n}"] + ([f"S{scene['id']} {scene['title']}"] if scene else []) + ([when] if when else [])
    lines = [f"=== {' · '.join(head)} ==="]
    if row["private"]:
        lines.append(f"({sc.name}'s whisper - private: only they and whoever noticed know it)")
    if row["status"] == "seed":
        lines.append("(from before play began - no narration on file)")
    elif not node:
        lines.append("(a fight round)")
    if node:
        lines.append(f"Summary: {node['text']}")
    for handle, text in _posts(row["inputs"]):
        lines.append(f"{_who(g, handle)} posted: {_clip(text, POST_CHARS)}")
    narr = row["narration"] or ""
    if narr and around:
        found = passages(narr, around)
        lines += ([f"Narration around \"{around}\" ({len(found)} passage{'s' if len(found) != 1 else ''}):"]
                  + [f"  {p}" for p in found] if found else [f"(nothing like \"{around}\" in this turn's narration)"])
    elif narr:
        lines.append("Narration (verbatim):\n" + _clip(narr, TURN_CHARS, " - read it again with around: a phrase"))
    rolls = [dict(r) for r in g.conn.execute("SELECT * FROM tests WHERE turn_id=? ORDER BY id", (n,))]
    rolls = [r for r in rolls if not _offscreen_roll(r)]  # (the world's offscreen rolls are nobody's at the table)
    if rolls:
        lines.append("Rolls:")
        lines += [roll_line(L, r, why=False) for r in rolls]
    return "\n".join(lines)


def _read_away(sc: Scope, wid: str) -> str:
    """A W# - a moment away from the table - only if they were in it (an NPC a player inhabits): the gist, no more."""
    node = sc.game.sub.node(wid)
    if not node or wid not in sc.witnessed:
        return f"[{wid}] isn't a moment {sc.name} was in."
    sc.opened.add(wid)
    when = _when(sc.game, node)
    return f"=== {wid} · after T{node['created_turn']}" + (f" · {when}" if when else "") + f" ===\n{node['text']}"


def timeline(sc: Scope, args: dict) -> str:
    g, L = sc.game, sc.game.ledger
    ids, unknown = sc.people(args.get("ids"))
    if not ids:
        return (f"Whose timeline? ids: people (or a place, an item) {sc.name} knows, by name or id."
                + (f" {sc.name} knows nobody by {', '.join(unknown)}." if unknown else ""))
    try:
        limit = max(1, min(TIMELINE_MAX, int(args.get("limit") or TIMELINE_LIMIT)))
    except (TypeError, ValueError):
        limit = TIMELINE_LIMIT
    lo, hi = _int(args.get("from_turn")), _int(args.get("to_turn"))
    conds = ["n.kind='slice'"] + ["n.id IN (SELECT slice_id FROM members WHERE node_id=?)" for _ in ids]
    qargs: list = list(ids)
    if lo is not None:
        conds.append("n.created_turn>=?")
        qargs.append(lo)
    if hi is not None:
        conds.append("n.created_turn<=?")
        qargs.append(hi)
    rows = [dict(r) for r in g.conn.execute(f"SELECT n.* FROM nodes n WHERE {' AND '.join(conds)} "
                                            f"ORDER BY n.created_turn, n.rowid", qargs) if r["id"] in sc.witnessed]
    names = " & ".join(_name(L, i) for i in ids)
    note = f" ({sc.name} knows nobody by {', '.join(unknown)})" if unknown else ""
    if not rows:
        return f"Nothing {sc.name} was there for involves {names}.{note}"
    total, rows = len(rows), rows[-limit:]
    roles: dict[tuple, list[str]] = {}
    for r in rows:
        for m in g.conn.execute("SELECT node_id, role FROM members WHERE slice_id=?", (r["id"],)):
            if m["node_id"] in ids:
                roles.setdefault((r["id"], m["node_id"]), []).append(m["role"])
    out = [f"{sc.name}'s moments with {names}: {total} on file"
           + (f" - the last {len(rows)}, oldest first (from_turn / to_turn for earlier ones)" if total > len(rows)
              else ", oldest first") + f":{note}"]
    for r in rows:
        bits = ([f"S{r['scene_id']}"] if r.get("scene_id") else []) + [_when(g, r) or _ago(g, r, sc.now)]
        if r["visibility"] == "private":
            bits.append("their whisper")
        line = f"[{r['id']}] ({', '.join(bits)}) {r['text']}"
        if len(ids) > 1:
            line += "  (" + ", ".join(f"{_name(L, i)}: {'/'.join(roles[(r['id'], i)])}" for i in ids
                                      if (r["id"], i) in roles) + ")"
        out.append(line)
    return "\n".join(out)
