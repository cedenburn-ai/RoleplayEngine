"""GM corrections (DESIGN.md §4): when the table and the GM agree the numbers are wrong, the GM sets them right - and
everyone sees it.

Live: the table retconned a KD-4 dive in the story, and the GM agreed in an aside to "reset the threat level" - but all
it could do was write a note. The engine still had Overwatch 33/40, a trace, a damaged deck and a host on full alert,
so the very next round rolled from those numbers and converged on the decker, against everything the GM had said.
Now the GM has the levers: the `correct` tool in a turn (called before any roll, so the round plays from the right
numbers) and `fix <id>: <what> [value]` lines in its <dm> block or a GM aside. Each one posts a [FIX] card to the
table, goes in the event log, and lands on the flag log - a correction means the engine got something wrong.

Only what the GM's other tools can't reach: `heal` heals, `transfer_nuyen` and `transfer_item` move money and gear,
`edge` refreshes Edge, `time` moves the clock, and `!undo` takes back recent turns whole.

The engine's own carry-overs are levers too (2026-10-27). A deadline the table ruled out (flag #42: R11's timeline lock,
and Q1's Day 5 noon still pressing at T147) is lifted with its question kept: `due` - a job's deadline too, by its J#
(review 2026-10-27: THE JOB's deadline was the one the engine held that nothing reached). A goal an NPC's offscreen mind keeps
pursuing past a ruling is dropped: `agenda`. And an NPC the engine built from the wrong block (flags #33/#47: a
virologist and a corporate liaison kitted out like soldiers - rifle, grenade, the heavy armor) gets the right one:
`template`.
"""
from __future__ import annotations

from ..engine import clock
from ..engine.ledger import LedgerError, RulesRefusal
from ..engine.rules import matrix, sr_lite

WHAT = {
    "overwatch": "a decker's Overwatch Score - value 0-39",
    "trace": "a decker's trace - value off (the host doesn't know where their body is) or on; it lasts the run",
    "deck": "a decker's deck damage - value 0 up to the deck's monitor",
    "jack_out": "take a decker out of the Matrix cleanly - no roll, no dumpshock (Overwatch back to 0)",
    "alert": "a host's alert - value 0 quiet, 1 noticed, 2 alert",
    "ic": "stand a host's IC down - all of it idle and undamaged",
    "hook": "drop a hook (target_id H#) so it never lands - for something that didn't happen after all",
    "agenda": "drop a goal an NPC or faction pursues offscreen (target_id A#) so it never moves again - one the table "
              "ruled out or the story left behind",
    "due": "lift a deadline the engine holds (target_id Q# for a tension's due time, J# for a job's deadline; value "
           "off) - the question or the job stays open; for a time the table ruled out (a timeline lock) or one nobody "
           "set",
    "template": "an NPC built from the wrong stat block - value the template it should be (" + ", ".join(
        sr_lite.NPC_TEMPLATES) + "); the old block's own gear comes off, its skills go",
}
NODES = ("hook", "agenda", "due")          # levers aimed at a node id (H#, A#, Q#) or a job's J#, not at someone on file
ALERTS = ("quiet", "noticed", "alert")


def _num(value, lo: int, hi: int, what: str) -> int:
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        raise LedgerError(f"{what} needs a number from {lo} to {hi}.") from None
    if not lo <= n <= hi:
        raise LedgerError(f"{what} is {lo} to {hi}.")
    return n


def _changes(before, after, line: str) -> None:
    """A correction that changes nothing is turned away, with what's actually there - live (flag #26, T106): a fix
    setting Filament's Overwatch from 0 to 0, since the trace had already landed, posted a [FIX] card, landed on the
    flag log, and left the trace it meant still showing on every later host. A RulesRefusal: the GM's to fix, so
    run_tool files no engine 'tool error' flag for it (review 2026-10-27: a plain LedgerError put every no-op on the
    flag log anyway)."""
    if before == after:
        _nothing(line)


def _nothing(line: str) -> None:
    raise RulesRefusal(f"correct: nothing to change - {line}")


def correct(game, turn: int | None, target: str, what: str, value=None, reason: str = "") -> str:
    """Make one correction; returns the [FIX] card line. Raises LedgerError on anything it can't do - and RulesRefusal
    on a correction that changes nothing (_changes), saying what's there and which lever it may have meant."""
    L = game.ledger
    what = what.strip().lower().replace(" ", "_").replace("-", "_")
    if what not in WHAT:
        raise LedgerError(f"correct: what is one of {', '.join(WHAT)}.")
    if not (reason or "").strip():
        raise LedgerError("correct: say why (the table sees it) - the retcon, or what the engine carried over.")
    why = f" - {reason.strip()}"

    if what == "hook":
        hid = target.strip().upper()
        row = game.conn.execute("SELECT status FROM hooks WHERE id=?", (hid,)).fetchone()
        if not row:
            raise LedgerError(f"No hook {hid}.")
        if row["status"] != "ready":
            raise LedgerError(f"{hid} is already {row['status']}.")
        game.conn.execute("UPDATE hooks SET status='stale' WHERE id=?", (hid,))
        line = f"[FIX] {hid} dropped - it won't land{why}"
        _logged(game, turn, hid, what, None, "dropped", reason, line)
        return line

    if what == "agenda":
        aid = target.strip().upper()
        row = game.conn.execute("SELECT status FROM agendas WHERE id=?", (aid,)).fetchone()
        if not row:
            raise LedgerError(f"No goal {aid} (an agenda's id is A#).")
        if row["status"] != "active":
            raise LedgerError(f"{aid} is already {row['status']} - it won't move again.")
        game.conn.execute("UPDATE agendas SET status='dropped', updated_turn=? WHERE id=?",
                          (turn if turn is not None else game.turn_no(), aid))
        line = f"[FIX] {aid} dropped - nobody pursues it offscreen now{why}"
        _logged(game, turn, aid, what, "active", "dropped", reason, line)
        return line

    if what == "due":
        from . import tensions
        qid = target.strip().upper()
        if qid.startswith("J"):
            return _job_due(game, turn, qid, value, why, reason)
        q = tensions.get(game, qid)
        if not q:
            raise LedgerError(f"No tension {qid} (a tension's id is Q#).")
        if str(value or "off").strip(" .").lower() not in tensions.NO_DUE:
            raise LedgerError(f"due: value off lifts {qid}'s deadline. To set or move one: "
                              f"`tension {qid}: <what moved> | due <when>`.")
        if q["status"] == "resolved":
            raise LedgerError(f"{qid} is resolved - nothing of it presses any more.")
        _changes(q["due_time"], None, f"{qid} has no deadline to lift.")
        was = tensions.lift_due(game, qid)
        known = f" ({q['public']})" if q.get("public") else ""            # (the question itself is the GM's)
        line = f"[FIX] {qid}{known}: no deadline now (it was {clock.fmt(was)}) - the question stays open{why}"
        _logged(game, turn, qid, what, was, None, reason, line)
        return line

    ent = L.require(target)
    if what == "template":
        if ent["kind"] != "npc":
            raise LedgerError(f"{ent['name']} isn't an NPC - only an NPC has a template.")
        new = sr_lite.npc_template(value)
        if not new:
            raise LedgerError(f"template: value is one of {', '.join(sr_lite.NPC_TEMPLATES)}.")
        before, raw = sr_lite.template_of(ent), ent["props"].get("template")
        _changes(before, new, f"{ent['name']} is already {new}" + (f" (on file as '{raw}')" if raw and raw != before
                                                                    else "") + ".")
        res = sr_lite.retemplate(L, ent["id"], new, turn or 0)
        own = f"{ent['name']}'s ".lower()
        took = [n[len(own):] if n.lower().startswith(own) else n for n in res["took"]]
        # (how hurt they are is said, on the new block's monitor - review 2026-10-27: the card said nothing while the
        # shrunken monitor quietly made a wounded NPC dying)
        hurt = res["condition"] != "ok"
        line = (f"[FIX] {ent['name']}: {new}, not {before or 'no template'} ({sr_lite.TEMPLATE_TEXT[new]})"
                + (f" - took off the {', '.join(took)}" if took else "")
                + (f" - still {res['condition']} ({sr_lite.condition_line(L, ent['id']).split(' (')[0]})" if hurt
                   else "") + why)
        _logged(game, turn, ent["id"], what, before, new, reason, line)
        return line

    if what in ("alert", "ic"):
        if ent["kind"] != "host":
            raise LedgerError(f"{ent['name']} isn't a host.")
        hp = dict(ent["props"])
        if what == "alert":
            n = _num(value, 0, 2, "A host's alert")
            before, hp["alert"] = int(hp.get("alert", 0)), n
            _changes(before, n, f"{ent['name']}'s alert is already {ALERTS[n]}.")
            line = f"[FIX] {ent['name']}: alert {ALERTS[min(before, 2)]} -> {ALERTS[n]}{why}"
        else:
            before = sum(1 for ic in hp.get("ic", []) if ic.get("active"))
            _changes(before, 0, f"no IC is awake in {ent['name']}.")
            hp["ic"] = [{**ic, "active": False, "damage": 0, "node": ic.get("home") or ic.get("node")}
                        for ic in hp.get("ic", [])]
            hp.pop("ic_launched_turn", None)             # (stood down: the host's one-IC-a-turn count starts over)
            n = 0
            line = f"[FIX] {ent['name']}: IC stood down ({before} active -> none){why}"
        L.update_entity(ent["id"], props=hp)
        _logged(game, turn, ent["id"], what, before, n, reason, line)
        return line

    st = matrix.state(L, ent["id"])
    name = ent["name"]
    # Overwatch and TRACED are the run's, so these two levers go by the run as every reader shows it (matrix.live,
    # current, traced_in). Review 2026-10-27: they read the raw record - 'trace on' was refused as "already traced"
    # on Filament's live Lim run, whose old plain True shows nowhere, and 'trace on' or 'overwatch 20' on a decker out
    # of the Matrix posted a [FIX] card and a flag, and changed nothing anyone reads (the next jack-in starts clean).
    run = matrix.live(L, ent["id"])
    hook_hint = " What a run set going in the world is a hook: what=hook, target_id H#."
    if what == "overwatch":
        n = _num(value, 0, matrix.CONVERGENCE - 1, "Overwatch")
        before = int(matrix.current(L, ent["id"]).get("overwatch", 0))
        trace_hint = (" A trace is its own lever: what=trace, value off - and what it set going in the world is a "
                      "hook: what=hook, target_id H#." if st.get("traced") else "")
        if not run:
            _nothing(f"{name}'s Overwatch is {'already ' if n == before else ''}{before} (they're not in a run: the "
                     "score dies with it)." + ("" if n == before else " A score set now would show nowhere - their "
                                               "next jack-in starts at 0.") + trace_hint)
        _changes(before, n, f"{name}'s Overwatch is already {n}." + trace_hint)
        st["overwatch"] = n
        line = f"[FIX] {name}: Overwatch {before} -> {n}{why}"
    elif what == "trace":
        on = str(value or "off").strip().lower() in ("on", "yes", "true", "1")
        if on:
            if not run:
                _nothing(f"{name} isn't in a run, and a trace lasts its run - the next jack-in starts untraced."
                         + hook_hint)
            before = matrix.traced_in(matrix.current(L, ent["id"]))       # (what shows: this run's trace only)
            _changes(before, on, f"{name} is already traced on this run.{hook_hint}")
            st["traced"] = run                         # TRACED belongs to the run (matrix.traced_in): this host
        else:
            # any trace on the record - an older record's plain True too: clearing it is flag #26's own remedy
            # (`fix filament: trace off - the KD-4 trace landed at T106 (H44)`)
            before = bool(st.get("traced"))
            _changes(before, on, f"{name} is not traced - the trace ends with the run.{hook_hint}")
            st["traced"] = False
        n = on
        line = f"[FIX] {name}: {'traced' if on else 'not traced - the host lost their body'}{why}"
    elif what == "deck":
        mon = matrix.deck_monitor(matrix.deck(L, ent["id"])[0])
        n = _num(value, 0, mon, "Deck damage")
        before, st["deck_damage"] = int(st.get("deck_damage", 0)), n
        _changes(before, n, f"{name}'s deck damage is already {n} (Deck {n}/{mon}).")
        line = f"[FIX] {name}: deck damage {before} -> {n} (Deck {n}/{mon}){why}"
    else:                                                  # jack_out
        if not st.get("host"):                             # (out already - the engine may have closed the run itself)
            _nothing(f"{name} isn't jacked in." + matrix.closed_note(st, turn))
        before, n = st["host"], None
        matrix._close(L, turn, ent["id"], st)              # a clean logout, both sides: the host stands its IC down
        line = f"[FIX] {name}: out of the Matrix, clean (no dumpshock){why}"
    L.update_entity(ent["id"], props={**L.require(ent["id"])["props"], "matrix": st})
    _logged(game, turn, ent["id"], what, before, n, reason, line)
    return line


def _job_due(game, turn, jid: str, value, why: str, reason: str) -> str:
    """`fix J#: due off` - a job's deadline lifted, the job kept. Review 2026-10-27: THE JOB's deadline is one the engine
    holds (the packet tells the GM to keep deadlines consistent with it), and no lever reached it - a time the table
    ruled out (the boy's transport, set for Day 4 23:00) kept pressing there."""
    from .. import jobs
    from . import tensions
    job = jobs.get(game, jid)
    if not job:
        raise LedgerError(f"No job {jid} (a job's id is J#, a tension's Q#).")
    if str(value or "off").strip(" .").lower() not in tensions.NO_DUE:
        raise LedgerError(f"due: value off lifts {jid}'s deadline - the story sets a new one (the memory pass files it).")
    if job["status"] not in jobs.OPEN:
        raise LedgerError(f"{jid} is {job['status']} - nothing of it presses any more.")
    _changes((job["deadline"] or "").strip() or None, None, f"{jid} has no deadline to lift.")
    was = jobs.lift_deadline(game, jid)
    line = f"[FIX] {jid} ({job['title']}): no deadline now (it was \"{was}\") - the job stays {job['status']}{why}"
    _logged(game, turn, jid, "due", was, None, reason, line)
    return line


def _logged(game, turn, target, what, before, after, reason, line) -> None:
    game.ledger.log(turn, "correct", target, {"what": what, "before": before, "after": after, "reason": reason})
    from .. import flags
    flags.record(game, "gm", "correction", line[6:], turn=turn)
