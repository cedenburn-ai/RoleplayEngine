"""Tensions (DESIGN.md §12c): the questions the story keeps pressing on.

Orchard holds a doubt as tension that never fully resolves. A game can close them, so here a tension is
a node (Q#) that carries *pressure* instead of heat. Everything else in the substrate cools when nobody
touches it; a tension the table leaves alone builds pressure, so the neglected ones rise to the top of the
GM's list and come back through the world. Play releases it, and resolving it closes it for good.
Pressure is its own number, not energy, so tensions can't distort the energy economy.

Scale-free: "will Dutch pay the 4,000 by noon?" (stakes 1, a due time) and "who is burying the Puyallup
shooting?" (stakes 3, no clock) are the same mechanism.
"""
from __future__ import annotations

import re

from ..engine import clock

MAX_PRESSURE = 3.0
RISE = 0.12                 # per turn the table leaves it alone, x stakes (shelved: half - it simmers)
ADDRESSED = 1.5             # the GM moved it on screen (a dm-block update)
GLANCED = 0.35              # someone it's about was in the thick of the turn
DUE_JUMP = 1.0              # its moment came
SHOWN = 4                   # open tensions in the packet
STATUSES = ("open", "shelved", "resolved")
# `due off`: the deadline lifted, the question kept. Live (flag #42, T147): R11's timeline lock ruled out every deadline
# but two, and Q1's Day 5 noon kept pressing - the GM could only resolve the question or move its time, never drop it.
LIFT = "off"
NO_DUE = ("off", "none", "no", "lifted", "lift", "never", "-")


def get(game, qid: str) -> dict | None:
    row = game.conn.execute("SELECT * FROM tensions WHERE id=?", (qid.upper(),)).fetchone()
    return dict(row) if row else None


def about(game, qid: str) -> list[str]:
    return [r["target_id"] for r in game.conn.execute("SELECT target_id FROM annotates WHERE note_id=?", (qid,))]


def open_tension(game, question: str, about_ids, turn: int, stakes: int = 2, next_: str | None = None,
                 public: str | None = None, due: int | str | None = None, by: str = "dm") -> str:
    S = game.sub
    due = None if due == LIFT else due
    qid = S._next("Q")
    S.create_node(qid, "tension", question.strip(), turn, visibility="gm", citizen=False)
    game.conn.execute("INSERT INTO tensions(id, question, stakes, next, public, due_time, created_turn, updated_turn, by) "
                      "VALUES(?,?,?,?,?,?,?,?,?)", (qid, question.strip(), max(1, min(3, int(stakes))), next_, public,
                                                    due, turn, turn, by))
    for a in about_ids:
        game.conn.execute("INSERT OR IGNORE INTO annotates(note_id, target_id) VALUES(?,?)", (qid, a))
    return qid


def _lifted(t: dict, pressure: float) -> dict:
    """The columns that lift t's deadline: no due time, not fired, and the jump its moment gave taken back - the
    deadline never was."""
    return {"due_time": None, "due_fired": 0,
            "pressure": round(max(0.0, pressure - (DUE_JUMP if t["due_fired"] else 0.0)), 3)}


def lift_due(game, qid: str) -> int | None:
    """Take an open (or shelved) tension's deadline away and keep the question - `fix Q#: due off`, `tension Q#: ...
    | due off`, the canon's read-back. Returns the due time it had, or None when it had none (nothing changed)."""
    t = get(game, qid or "")
    if not t or t["status"] == "resolved" or t["due_time"] is None:
        return None
    sets = _lifted(t, t["pressure"])
    game.conn.execute(f"UPDATE tensions SET {', '.join(k + '=?' for k in sets)} WHERE id=?", (*sets.values(), t["id"]))
    return t["due_time"]


def update(game, qid: str, turn: int, progress: str | None = None, next_: str | None = None,
           public: str | None = None, due: int | str | None = None, stakes: int | None = None) -> None:
    """The GM moved it: release pressure, record what moved (a note on the tension), reopen if shelved. due is a story
    time, or LIFT to take the deadline away."""
    t = get(game, qid)
    if not t or t["status"] == "resolved":
        return
    sets = {"status": "open", "updated_turn": turn, "pressure": max(0.0, t["pressure"] - ADDRESSED)}
    if next_ is not None:
        sets["next"] = next_
    if public is not None:
        sets["public"] = public
    if due == LIFT:
        sets.update(_lifted(t, sets["pressure"]))
    elif due is not None:
        sets.update(due_time=due, due_fired=0)
    if stakes is not None:
        sets["stakes"] = max(1, min(3, int(stakes)))
    game.conn.execute(f"UPDATE tensions SET {', '.join(k + '=?' for k in sets)} WHERE id=?", (*sets.values(), t["id"]))
    if progress:
        game.sub.add_note([t["id"]], progress, turn)


def resolve(game, qid: str, turn: int, how: str) -> bool:
    cur = game.conn.execute("UPDATE tensions SET status='resolved', pressure=0, resolved_turn=?, updated_turn=?, "
                            "resolution=? WHERE id=? AND status<>'resolved'", (turn, turn, how, qid.upper()))
    return cur.rowcount > 0


def shelve(game, qid: str, turn: int, why: str = "") -> bool:
    cur = game.conn.execute("UPDATE tensions SET status='shelved', updated_turn=? WHERE id=? AND status='open'",
                            (turn, qid.upper()))
    if cur.rowcount and why:
        game.sub.add_note([qid.upper()], f"Shelved: {why}", turn)
    return cur.rowcount > 0


def step(game, turn: int, members: dict[str, str], addressed: set[str]) -> list[str]:
    """After each turn: pressure rises on what the table left alone, eases on what it touched, and
    jumps when a tension's moment comes. Returns event lines."""
    now, events = game.clock(), []
    for t in [dict(r) for r in game.conn.execute("SELECT * FROM tensions WHERE status IN ('open', 'shelved')")]:
        p = t["pressure"]
        if t["id"] in addressed:
            pass                                       # (update() already released it)
        elif any(members.get(a) in ("actor", "target") for a in about(game, t["id"])):
            p -= GLANCED
        else:
            p += RISE * t["stakes"] * (0.5 if t["status"] == "shelved" else 1.0)
        fired = t["due_fired"]
        if t["due_time"] is not None and not fired and now >= t["due_time"]:
            p, fired = p + DUE_JUMP, 1
            events.append(f"TENSION {t['id']} is due: {t['question']}")
        p = round(max(0.0, min(MAX_PRESSURE, p)), 3)
        game.conn.execute("UPDATE tensions SET pressure=?, due_fired=? WHERE id=?", (p, fired, t["id"]))
    return events


def _due_text(t: dict, now: int) -> str:
    if t["due_time"] is None:
        return ""
    if now >= t["due_time"]:
        return f" · DUE NOW (it was due {clock.fmt(t['due_time'])})"
    return f" · due {clock.fmt(t['due_time'])} (it's {clock.fmt(now)} now)"


def _names(game, qid: str) -> str:
    L = game.ledger
    return ", ".join((L.get(a) or {}).get("name", a) for a in about(game, qid)[:4])


def packet_lines(game) -> list[str]:
    rows = [dict(r) for r in game.conn.execute("SELECT * FROM tensions WHERE status IN ('open', 'shelved')")]
    if not rows:
        return []
    now = game.clock()
    live = sorted((t for t in rows if t["status"] == "open"),
                  key=lambda t: (-(t["due_time"] is not None and now >= t["due_time"]), -t["pressure"]))
    out = ["\n=== OPEN TENSIONS (GM-only: the story's unanswered questions. Pressure rises while the table leaves "
           "one alone - bring a HIGH one back through the world when it fits; never force it) ==="]
    for t in live[:SHOWN]:
        level = "HIGH" if t["pressure"] >= 2 else "rising" if t["pressure"] >= 1 else "low"
        names = _names(game, t["id"])
        out.append(f"[{t['id']}] pressure {t['pressure']:.1f} {level} · stakes {t['stakes']}{_due_text(t, now)} - "
                   f"{t['question']}" + (f" Next: {t['next']}" if t["next"] else "")
                   + (f" (about {names})" if names else ""))
    rest = [t for t in live[SHOWN:]] + sorted((t for t in rows if t["status"] == "shelved"), key=lambda t: -t["pressure"])
    if rest:
        out.append("Also simmering: " + "; ".join(f"[{t['id']}]{' (shelved)' if t['status'] == 'shelved' else ''} "
                                                   f"{t['question'][:90]}" for t in rest[:4]))
    return out


def public_lines(game) -> list[str]:
    """What the PCs know of the open questions (the recap's 'where things stand')."""
    now = game.clock()
    return [t["public"] + (_due_text(t, now).replace(" · ", " - ") if t["due_time"] else "")
            for t in (dict(r) for r in game.conn.execute(
                "SELECT * FROM tensions WHERE status IN ('open', 'shelved') AND COALESCE(public, '') <> '' "
                "ORDER BY pressure DESC"))]


FIELD = re.compile(r"^\s*(stakes|due|next|public)\s*:?\s*(.+?)\s*$", re.IGNORECASE)
# `due off` with its reason - "due off - R11 locks the timeline", "due off (R11)", "due off per R11": review of flag
# #42, the GM writing the two forms the prompt shows side by side got neither - the line became a move, reopened the
# shelved Q1, and its Day 5 noon kept pressing.
LIFTED = re.compile(r"^(off|none|no|lifted|lift|never)\b\s*(?:[-–—(:;,]\s*(?P<why>.*?)[)\s]*|(?:per|by|for|as|because)\s+"
                    r"(?P<why2>.+))?$", re.IGNORECASE)
# The lift in words, as the line's own lead - "tension Q1: no deadline now - R11": the words the `fix Q1: due off` card
# itself prints ("no deadline now"), echoed back (review of flag #42: it became a move, and the noon kept pressing).
NO_DEADLINE = re.compile(r"^(?:no (?:more )?deadline(?: now| any ?more)?|(?:lift|drop|remove)(?:ed)? (?:the |its )?"
                         r"deadline|deadline (?:off|lifted|gone|dropped))\b\s*(?:[-–—(:;,.]\s*(?P<why>.*?)[)\s.]*)?$",
                         re.IGNORECASE)


def parse(text: str, now: int) -> dict:
    """'question | stakes 2 | due day 3 12:00 | next: ... | public: ...' -> fields (due in story minutes, or LIFT for
    `due off` / `due none`, with or without its reason: the deadline lifted, the question kept; why: that reason;
    bad_due: a due that's neither a time nor a lift - the GM is told, never a silent drop)."""
    out = {"main": "", "stakes": None, "due": None, "next": None, "public": None, "why": "", "bad_due": ""}
    for i, part in enumerate(p for p in text.split("|")):
        m = FIELD.match(part)
        lm = LIFTED.match(m.group(2).strip(" .")) if m and m.group(1).lower() == "due" else None
        lift = bool(m) and m.group(1).lower() == "due" and (m.group(2).strip(" .").lower() in NO_DUE or bool(lm))
        if m and (i > 0 or m.group(1).lower() in ("next", "public") or lift):      # (`tension Q1: due off` alone)
            key, val = m.group(1).lower(), m.group(2)
            if key == "stakes":
                digits = re.findall(r"\d", val)
                out["stakes"] = int(digits[0]) if digits else None
            elif lift:
                out["due"] = LIFT
                out["why"] = ((lm.group("why") or lm.group("why2") or "") if lm else "").strip(" .()")
            elif key == "due":
                try:
                    out["due"] = clock.parse(val, now)
                except ValueError:
                    out["bad_due"] = val
            else:
                out[key] = val
        elif not out["main"]:
            nd = NO_DEADLINE.match(part.strip()) if i == 0 else None
            if nd:                                       # ("no deadline now - R11": the lift, said in words)
                out["due"], out["why"] = LIFT, (nd.group("why") or "").strip(" .()")
            else:
                out["main"] = part.strip()
    return out
