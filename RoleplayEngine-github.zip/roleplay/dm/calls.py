"""Called rolls: the roll a player calls is the roll that's made (flags #38, #48-#52; the owner, 2026-10-27, decision 4:
"the engine enforces").

Live T155: a player called a teamwork Negotiation test with Magic leading (Charisma 4 + Negotiation 3) and Brask
helping, Edge on the misses if it came up short. The GM narrated Vandermeer's answer with no roll, then rolled Brask
(no Negotiation: 2 dice) instead of the leader he'd named, five `!undo`s running - however the player put it, the NPC
was the one who rolled. At T128 a teamwork Negotiation call with Magic in the lead went out with no helper rolled
(flag #38). The guard before this (turn.roll_asks and one send-back) only knew that the poster's character should roll
*something*: it fired once a turn, on a few words (never 'leads', 'helps', 'assists'), and never looked at the skill,
the helpers, or who led - a Perception roll of Magic's, or Brask rolling with Magic as her helper, satisfied it.

So a call is read whole at the start of the turn (read):
- who leads - the one the player names (leads, makes the roll, the one helped: "Ghost helps Brask" is Brask's roll); a
  group with no leader ("Razor and Kaz work the fixer together") goes to the highest pool for the skill rolled;
  nobody named, the poster's own character;
- the skill they name ("a Negotiation test", "Con + Charisma") - binding - or the skills their task points at ("to
  convince her": the social skills), the GM's to pick from;
- the helpers they name ("Brask helping", "with Kaz's help", "Ghost and Kaz assist") and whom it's aimed at;
- their Edge, as turn.edge_asks reads it.
From the words where they say it; where they leave it open (role words but no roll words, teamwork with no helper
named, a part given by a pronoun) a cheap model read (Haiku, low effort, a small schema) settles it - never for a post
that calls nothing.

And it's held in the engine:
- before the dice (check, from tools.run_tool): a request_test for the call with someone else rolling - an NPC, a
  lower-pool helper, the leader as a helper or as the other side - the wrong named skill, or a named helper left out
  is turned away with exactly what to roll (a RulesRefusal: nothing rolled). Twice; the third time the engine rolls
  the call itself, the GM's threshold, opposition and modifiers kept, so the wrong roll never reaches the record;
- after the narration (turn._dm_loop): narrating past an owed call is sent back, SEND_BACKS times; then the engine
  rolls it (engine_roll: the same sr_lite.request_test - leader, helpers, Edge, the GM's threshold if it tried one,
  else an opposed roll against the one it's aimed at, else the book's average 2) and the GM narrates from that
  result, never the version without it. An attack, a spell or a Matrix beat the engine doesn't play for the GM: the
  send-backs name it (a Matrix call the host the player named, tools.matrix_target), and a miss is flagged.

What it holds, it has to get right - review of P3 (2026-10-27), once a misread cost two send-backs and an engine
roll: a roll is the call's only where it's aimed where the call is (an NPC's own roll at someone else goes through);
every tool that rolls the call's skill meets it (a ram, First Aid, a thrown grenade, a compile, a rigger's drone); a
name leads only as its clause's subject, never an object or an off-scene NPC's alias; a hold the engine can't roll
ends, flagged; one engine roll answers every post it fits; one called Edge is one point; quoted speech, a roll
declined and everyday nouns ("the check", "a blood test") call nothing; and the engine never rolls for a player who
hasn't posted (turn.hands_off).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..engine.ledger import LedgerError, RulesRefusal
from ..engine.rules import matrix, sr_lite
from .prompts import FICTION_NOTE

SEND_BACKS = 2        # narrations past an owed call the GM is sent back from, a turn - then the engine rolls it
HARD_REFUSALS = 2     # rolls that give a call to someone else, turned away - the next one the engine rolls right
SOCIAL = ("negotiation", "con", "etiquette", "intimidation", "streetwise")
# Calls the other tools roll: met by that tool with the leader rolling (and a Matrix beat that rolls dice). The engine
# rolls only tests itself - never an attack, a spell or a Matrix beat for the GM. (Compiling is the sprite tool's -
# review of P3: it said 'spirit', and a technomancer's compile was sent back for "a spirit call".)
TOOL_FOR = {"firearms": "attack", "close_combat": "attack", "throwing": "attack", "sorcery": "cast",
            "conjuring": "spirit", "hacking": "matrix", "cybercombat": "matrix", "software": "thread",
            "compiling": "sprite"}
# Tools that roll a skill a test rolls too: a ram (crash: Piloting + Reaction), First Aid (heal how='first_aid'), a
# thrown grenade (explode thrown=True: Throwing). Each meets a call for that skill with the leader rolling - review of
# P3: none counted, so a ram the GM rolled right was rolled again by the engine (Razor's one called push spent twice,
# Edge 3 -> 1) and a bandage became a First Aid test opposed by the patient.
ALSO_BY = {"piloting": ("crash",), "first_aid": ("heal",), "throwing": ("explode",)}
ROLL_TOOLS = ("request_test", *TOOL_FOR.values(), *(t for ts in ALSO_BY.values() for t in ts))
# The book's opposition for a test aimed at someone (SR5 pp. 140, 98): what the engine rolls against the one a call is
# aimed at, when the GM never said - and only for these: a First Aid test "on Ghost" isn't opposed by Ghost.
OPPOSE = {"negotiation": ("negotiation", "charisma"), "con": ("con", "charisma"), "etiquette": ("perception", "charisma"),
          "intimidation": ("intimidation", "willpower"), "stealth": ("perception", "intuition")}


class Rolled(Exception):
    """The engine rolled the call itself in place of a roll it had turned away twice (check) - the tool result."""

    def __init__(self, content: str):
        super().__init__(content)
        self.content = content


@dataclass
class Call:
    poster: str                                   # the posting player's character
    name: str                                     # ... their name
    words: str                                    # the call in their words, for the GM
    owed: bool = True                             # a roll must be made; False: only its shape binds a roll that is
    leader: str | None = None                     # who they named to lead (None: `among`'s highest pool, else poster)
    among: list = field(default_factory=list)     # named in on it, part unsaid: the highest pool leads, the rest help
    helpers: list = field(default_factory=list)   # the helpers they named
    skill: str | None = None                      # the skill they named - binding
    attributes: list = field(default_factory=list)  # an attribute-only test they named
    task: str | None = None                       # the skill their task points at (its family binds; the GM picks)
    against: str | None = None                    # whom it's aimed at ("convince Kaz")
    teamwork: bool = False                        # they called teamwork
    named: list = field(default_factory=list)     # everyone the call's own sentences name (a leader-less call holds
                                                  # only their rolls - review of P3: live T17's "I try to assist her"
                                                  # refused Juno's unrelated Perception, forever)
    firm: bool = True                             # asked unmistakably (a roll word, a named skill, Edge): a cheap read
                                                  # can't say it isn't a call; False - a cue word only, or a "no roll"
    loose_lead: bool = False                      # the leader is only a lowercase alias or name word: dropped unless
                                                  # the read names them too
    how: str = "words"                            # words, or model: the cheap read settled what the words left open
    vague: bool = False                           # a part came from a he/she/they, or leaders disagree: the read's
    unknown: bool = False                         # the roll is a he/she/they's nobody's named: the read names them,
                                                  # or it's no call (never the poster's on a guess)
    refusals: int = 0                             # rolls turned away for giving it to someone else, the wrong skill...
    nudged: bool = False                          # the one soft reminder (teamwork with no helper, say) was given
    tried: dict | None = None                     # the GM's last request_test for it that was turned away
    met: bool = False
    by_engine: bool = False
    given_up: bool = False                        # owed, but nothing the engine can roll (an attack...): flagged
    post: str = ""                                # the whole post, quotes blanked (the skill read, the helpers picked)
    lead_rank: int = 0                            # how the leader was named (_roles: 3 by their own words) - a cheap
                                                  # read never replaces a rank-3 leader (review of flag #48)
    hint: str | None = None                       # a task word further off in the post ("Then I make the offer", two
                                                  # sentences on): never binding, only the engine's pick if it rolls
    excluded: list = field(default_factory=list)  # named out of it: "not Brask", "Brask will be told not to speak"
    only: bool = False                            # "only magic is making this roll": nobody else rolls it
    mentioned: list = field(default_factory=list)  # who the post names outside quotes (in the scene, by name)
    picked: bool = False                          # the helpers are the engine's pick from the post (flag #38: T128's
                                                  # teamwork named nobody to help; the read named nobody either)
    seen: dict | None = None                      # the turn's last roll that went through while it was owed, by
                                                  # someone not in on it (an NPC pitching on her own) - what the engine
                                                  # takes the skill and the opposition from when the call names none
    asked_skill: bool = False                     # the cheap read was asked for the skill at the backstop
    why_not: str = ""                             # why the engine couldn't roll it (the table is told)

    def quoted(self, n: int | None = None) -> str:
        """The call in their words for a send-back, a refusal or a flag: "...<words>...", cut to n - its own full
        stop off, so a call that ends on one never reads "...test...." (review 2026-10-28)."""
        return "..." + (self.words if n is None else self.words[:n]).rstrip(" .!?;,") + "..."

    @property
    def plain(self) -> bool:
        """Just 'a roll' - no skill, task, helpers or group: any roll of the leader's answers it (as before)."""
        return not (self.skill or self.attributes or self.task or self.helpers or self.among or self.teamwork)

    def participants(self) -> set:
        return {x for x in (self.leader, self.poster, *self.among, *self.helpers) if x}

    @property
    def shaped(self) -> bool:
        """Whether the call says what's rolled - a skill, attributes or a task - so the engine can roll it itself."""
        return bool(self.skill or self.attributes or self.task)


# ── reading the post ────────────────────────────────────────────────────
_WORD = re.compile(r"[A-Za-z][\w'’-]*")
TITLES = frozenset(("dr", "mr", "mrs", "ms", "miss", "mister", "doc", "the", "old", "big", "little", "sir", "lady",
                    "officer", "detective", "agent", "captain"))
_SKILL_WORDS = {s.replace("_", " "): s for s in sr_lite.SKILLS} | {"close-combat": "close_combat",
                                                                   "first-aid": "first_aid"}
_SK = "|".join(sorted(map(re.escape, _SKILL_WORDS), key=len, reverse=True))
_ATTR = "|".join(sr_lite.ATTRIBUTES)
_ART = r"(?:(?:a|an|the|his|her|their|my|our|this|that)\s+)?"
# 'roll' as the dice, never the prose: "rolls his eyes", "the van rolls to a stop", "rolls out", "a roll of tape".
NOT_PROSE_ROLL = (r"(?!\s+of\b)(?!\s+(?:(?:his|her|their|my|its|our|your|the|a)\s+)?(?:eyes|shoulders?|neck|head|window|"
                  r"sleeves?|joint|cigarette|car|van|truck|bike|body)\b)(?!\s+(?:up|down|over|out|in|into|onto|away|back|"
                  r"off|across|along|through|past|around|aside|forward|under|clear|free|to a (?:stop|halt))\b)")
ROLL_WORD = re.compile(r"\b(?:re-?)?roll(?:s|ed|ing)?\b" + NOT_PROSE_ROLL, re.I)
# ... nor an idiom: live T140's "She helped us get this rolling" (its shape) was a roll Pembrook helped with.
ROLL_IDIOM = re.compile(r"\b(?:get|gets|getting|got|keep|keeps|keeping|kept|set|sets|start|starts|started)\s+(?:it|this|"
                        r"that|things|the ball|everything|us|him|her|them)\s+rolling\b|\brolling\s+(?:in|along|with the "
                        r"punches)\b|\bheads?\s+(?:will\s+|would\s+|are\s+going\s+to\s+)?roll\b|\bready\s+to\s+roll\b|"
                        r"\blet['’]?s\s+roll\b|\brock\s+(?:and|n['’]?|&)\s+roll\b|\broll(?:s|ing)?\s+with\s+(?:it|that|"
                        r"this|the\s+punches)\b", re.I)
# A roll declined isn't a roll asked for: live T102 "No roll or system check" (R16 backs it), "without a roll",
# "doesn't need to roll" - review of P3: each became an owed call, two send-backs, and once an engine roll whose card
# quoted the player saying no roll. Read in the roll word's own clause.
NO_ROLL = re.compile(r"(?:\b(?:no|not|never|without|nor|cannot|can['’]?t|don['’]?t|doesn['’]?t|didn['’]?t|won['’]?t|"
                     r"isn['’]?t|aren['’]?t|shouldn['’]?t|needn['’]?t)|\bno\s+need\s+(?:to|for))\s+(?:[\w'’-]+\s+){0,2}$",
                     re.I)
_CLAUSE_START = re.compile(r"[,;:.!?()\n]|\s[-–—]+\s")


def _declined(text: str, at: int) -> bool:
    """Whether the roll word at `at` is declined in its clause ("No roll needed", "without a roll")."""
    a = max([m.end() for m in _CLAUSE_START.finditer(text, 0, at)] or [0])
    return bool(NO_ROLL.search(text[a:at]))


def roll_word(text: str, pattern: re.Pattern = ROLL_WORD) -> re.Match | None:
    """The first match of pattern that isn't inside a roll idiom ("get this rolling", "let's roll") or declined ("no
    roll needed")."""
    idioms = [m.span() for m in ROLL_IDIOM.finditer(text)]
    return next((m for m in pattern.finditer(text) if not any(a <= m.start() < b for a, b in idioms)
                 and not _declined(text, m.start())), None)


_TEST = r"(?:check|test|roll)"
# The other ways a post asks for the dice ("Make an Etiquette test", "a Leadership test with Kaz assisting",
# "Negotiation + Charisma, Kaz helps" - review of flag #51: each was missed). Never the everyday nouns - review of P3:
# "asks for the check" (a bill), "wants a blood test", "the background check", "runs his tests against the samples"
# each became an owed call in a campaign about virologists. So a bare check or test needs a verb that makes one
# ("make a check", "request the test"); one with a word before it needs that word to be a skill or a mechanic ("a
# Negotiation test", "a social check", "a hard test") or a skill's capitalised name the engine doesn't keep ("a
# Leadership test"); and a second chance or a push is Edge's (turn.edge_asks reads those).
_ASKS = r"(?:make[s]?|making|made|requests?|requesting|attempts?|do(?:es)?|doing|call(?:s|ing)?\s+for|ask(?:s|ing)?\s+for)"
_ARTS = r"(?:a|an|the|this|that|my|his|her|their|our)"
CUE = re.compile(
    # (the noun, never the verb: live T118 "The group checks each other out" asked for nothing - and first, so "a
    # teamwork check" is that, not a bare "teamwork")
    rf"\b(?:skill|social|opposed|group|teamwork|attribute)\s+{_TEST}\b(?!\s+(?:each|on|in|out|if|whether|the|a|an|"
    r"his|her|their|my|our|it|them|him|over)\b)"
    r"|\b(?:teamwork|team roll|push(?:es|ing)? the limit|dice pool)\b"
    rf"|\b(?:make[s]?|making|made|requests?|requesting|attempts?)\s+{_ARTS}\s+(?:test|check)\b"
    r"(?!\s+(?:out|payable|results?)\b)"
    # (live T85: "do a continual skill check on this")
    rf"|\b{_ASKS}\s+{_ARTS}\s+(?:(?:(?-i:[A-Z][a-z]+)|quick|hard|easy|simple|opposed|group|team|teamwork|skill|social|"
    rf"attribute|extended|continual|continuous)[\s-]+){{1,2}}{_TEST}\b"
    rf"|\b(?:{_SK})s?\s+{_TEST}s?\b"
    rf"|\b(?:roll(?:s|ing)?|test(?:ing)?)\s+(?:vs|versus)\b|\broll(?:s|ing)?\s+against\b"
    rf"|\b(?:{_ATTR})\s*\+\s*(?:{_ATTR}|{_SK})\b|\b(?:{_SK})\s*\+\s*(?:{_ATTR})\b", re.I)
# The cue words that ask only loosely - a bare "teamwork" ("nice teamwork back there"), "make a check" (a bill): the
# cheap read can veto them. A skill's test, a social check, a Leadership test, Charisma + Con are firm asks.
LOOSE_CUE = re.compile(r"teamwork|team roll|(?:make[s]?|making|made|requests?|requesting|attempts?)\s+\w+\s+(?:test|check)",
                       re.I)


def cue(text: str) -> re.Match | None:
    """The first CUE match that isn't declined ("no Perception test needed")."""
    return next((m for m in CUE.finditer(text) if not _declined(text, m.start())), None)
NAMED_SKILL = re.compile(
    rf"\b(?P<a>{_SK})s?(?=\s*(?:\+|(?:test|check|roll|pool|skill|dice)\b))"
    rf"|\b(?:roll(?:s|ing)?|test(?:s|ing)?|teamwork|opposed)\s+{_ART}(?:teamwork\s+)?(?P<b>{_SK})s?\b"
    rf"|\b(?:using|uses|use|with)\s+(?:(?:his|her|their|my|our)\s+)?(?P<c>{_SK})\b"   # "uses Con to...", not "with
    r"(?=\s*(?:$|[,.;:!?)]|skill\b|to\b|and\b|on\b|against\b|vs\b))"                  # survival gear"
    rf"|\b(?:{_ATTR})\s*\+\s*(?P<d>{_SK})s?\b", re.I)
ATTR_ONLY = re.compile(rf"\b(?P<x>{_ATTR})\s*\+\s*(?P<y>{_ATTR})\b", re.I)
SKILL_NOUN = re.compile(rf"\b(?P<s>{_SK})s?\b", re.I)
# A social skill said as a noun is a task ("this negotiation", "the con"); others are gear as often as not - live T172
# "Lou uses throwing weapons" isn't Magic's spell being a throw.
SOCIAL_NOUN = re.compile(r"\b(?P<s>negotiation|etiquette|intimidation|streetwise|con)s?\b", re.I)
MECH = re.compile(rf"\b(?:dice|pool|skill|teamwork)\b|\b(?:{_SK})s?\b", re.I)
TEAMWORK = re.compile(r"\bteam(?:work|[- ]?roll|ing up|s up| up)\b|\btogether\b", re.I)
TEAM_WORD = re.compile(r"\bteam(?:work|[- ]?roll|ing up|s up| up)\b|\bgroup\s+(?:check|test|roll)\b", re.I)
EDGE_WORD = re.compile(r"\bedge\b", re.I)
# What a task points at, read in the call's own sentences: the family binds (convince: the social skills), the skill
# is the engine's pick only when it has to roll the call itself.
# (Review of flag #51: "a teamwork persuasion roll", "gets Vandermeer on board" and "Brask does the talking" pointed at
# nothing - 'persuad' missed 'persuasion' - so the engine had no skill to roll when the GM narrated past them.)
TASKS = [(re.compile(p, re.I), skill) for p, skill in (
    (r"\b(?:convinc\w*|persua\w*|pitch(?:es|ed|ing)?(?!\s+in\b)|negotiat\w*|bargain\w*|haggl\w*|sway\w*|plead\w*|"
     r"win(?:s|ning)?\s+(?:him|her|them|[\w'’-]+)\s+over|talk(?:s|ing)?\s+(?:him|her|them|[\w'’-]+)\s+(?:into|out of|"
     r"down|round|around)|reason(?:s|ing)?\s+with|make[s]?\s+(?:the|an?|our|his|her|my)\s+(?:offer|case|pitch|deal)|"
     r"(?:get|gets|getting|got|bring|brings|bringing)\s+(?:him|her|them|[\w'’-]+(?:\s+[\w'’-]+)?)\s+on\s*board|"
     r"(?:do|does|doing|did)\s+(?:all\s+)?the\s+talking)\b",
     "negotiation"),
    (r"\b(?:bluff\w*|fast[- ]talk\w*|lie[sd]?\s+to|lying\s+to|con(?:s|ning|ned)?(?=\s+(?:him|her|them|the|a|an)\b)|"
     r"decei\w*|trick(?:s|ing)?\s+(?:him|her|them))\b", "con"),
    (r"\b(?:intimidat\w*|threaten\w*|menac\w*|lean(?:s|ing)?\s+on)\b", "intimidation"),
    (r"\b(?:blend(?:s|ing)?\s+in|fit(?:s|ting)?\s+in|smooth(?:s|ing)?\s+(?:it|things|this)\s+over|"
     r"pass(?:es|ing)?\s+(?:for|as))\b", "etiquette"),
    (r"\b(?:ask(?:s|ing)?\s+around|work(?:s|ing)?\s+the\s+street)\b", "streetwise"),
    (r"\b(?:sneak\w*|slip(?:s|ping)?\s+(?:past|by|in|out))\b", "stealth"),
    (r"\b(?:spot(?:s|ting)?(?!\s+(?:on|of)\b)|notic\w*|search(?:es|ing)?|look(?:s|ing)?\s+(?:for|around)|scan(?:s|ning)?|"
     r"listen(?:s|ing)?\s+for|perceiv\w*)\b", "perception"),
    (r"\b(?:patch(?:es|ing)?\s+(?:him|her|them|[\w'’-]+)\s+up|stabiliz\w*|bandag\w*|diagnos\w*)\b", "first_aid"),
    # (no climbing: live T95 "Climb into admin" is a decker's, not an Athletics test)
    (r"\b(?:pick(?:s|ing)?\s+the\s+lock|disarm\w*|bypass\w*|rewir\w*)\b", "engineering"),
    (r"\b(?:hack(?:s|ed|ing)?|brute[- ]?forc\w*)\b", "hacking"),
)]
_AUX = (r"(?:(?:is|are|was|will|would|should|can|could|must|gets?\s+to|has\s+to|have\s+to|is\s+going\s+to|wants?\s+to|"
        r"['’](?:s|ll|re|d|m))\s+)?(?:also\s+|then\s+|just\s+|probably\s+|actually\s+)?"
        r"(?:(?:try|tries|trying|attempts?|attempting|offers?|offering)\s+to\s+)?")   # (live T17: "I try to assist her")
LEAD_AFTER = re.compile(
    r"\s*,?\s*" + _AUX + r"(?:lead(?:s|ing)?\b(?!\s+(?:the way|(?:[\w'’-]+\s+){0,2}(?:down|up|into|out|through|away|"
    r"back|across|inside|outside|over|around|off)\b))"
    r"|takes?\s+the\s+lead|taking\s+the\s+lead|takes?\s+point|taking\s+point|(?:be|is|are)\s+the\s+lead(?:er)?\b"
    r"|(?:in|as)\s+(?:the\s+)?lead(?:er)?\b"
    r"|(?:makes?|making|takes?|taking|does|doing|rolls?|rolling|has|gets?)\s+(?:this|the|that|a|an|his|her|their|my|"
    r"our)\s+(?:[\w-]+\s+){0,2}(?:roll|test|check)\b"
    r"|(?:roll(?:s|ing)?|is\s+rolling|are\s+rolling)\b" + NOT_PROSE_ROLL + r")", re.I)
HELP_AFTER = re.compile(
    r"(?:['’]s\s+(?:help|backing|support|assistance)\b|\s*,?\s*" + _AUX + r"(?P<verb>help(?:s|ing|ed)?|"
    r"assist(?:s|ing|ed)?|aid(?:s|ing)?|support(?:s|ing)?)\b|\s*,?\s*" + _AUX + r"(?:backs?\s+(?:[\w'’]+\s+)?up|"
    r"backing(?:\s+(?:[\w'’]+\s+)?up)?|chip(?:s|ping)?\s+in|pitch(?:es|ing)?\s+in|lend(?:s|ing)?\s+a\s+hand|"
    # ("Brask as helper", no article - review 2026-10-28 of flag #51: Brask went unread, and the teamwork's picked
    # helpers took in Vandermeer, the one the pitch was aimed at)
    r"add(?:s|ing)?\s+(?:(?:his|her|their|my|its)\s+)?(?:dice|hits|pool)|(?:is|are|as)\s+(?:(?:a|the|his|her|their|"
    r"my)\s+)?helpers?)\b)", re.I)
# A help that's a hand, not a roll: "helps her into the van", "helps him up", "helps him out of the car", "helps
# himself to a drink".
HELP_PROSE = re.compile(r"\s+(?:(?:him|her|them|me|us|it|[\w'’-]+)\s+)?(?:up|down|into|onto|off|inside|outside|"
                        r"out\s+of|to\s+(?:his|her|their|my)\s+feet)\b|\s+(?:carry|lift|load|unload|dress|stand)\b"
                        r"|\s+(?:him|her|them|my|your|our)sel(?:f|ves)\b", re.I)
# Beside the call (not in its own sentence), a help counts only bare: "Brask helps.", "Kaz helping (teamwork)", "Kaz
# helps with the roll" - never "Kaz helps the bartender with the kegs".
BARE_HELP = re.compile(r"\s*(?:$|[,;:()\-]|out\b|(?:him|her|them|me|us)\s*(?:$|[,;:()\-]|out\b)|(?:with|on)\s+(?:it|this|"
                       r"that|the\s+(?:roll|test|check|pitch|teamwork)|(?:his|her|their|my)\s+(?:roll|test|check|pitch))\b|"
                       r"by\s+adding\b)", re.I)
HELP_BEFORE = re.compile(r"(?:\bwith\s+(?:the\s+)?help\s+(?:of|from)|\bhelp\s+(?:of|from)|\bhelped\s+by|\bassisted\s+by|"
                         r"\bbacked(?:\s+up)?\s+by|\bsupport(?:ed)?\s+(?:from|by)|\bhelpers?\s*(?:are|is|:|-|=)?|"
                         r"\bteamwork\s+(?:with|from)|\bteam(?:s|ing|ed)?\s+up\s+with|\btogether\s+with|\balongside)"
                         r"\s*$", re.I)
LEAD_BEFORE = re.compile(r"(?:\bled\s+by|\bleader\s*(?:is|:|-|=)|\blead\s*(?::|-|=))\s*$", re.I)
# A list's head and its parts in brackets - review of flag #38: "Leader: Magic. Helpers: Filament, Lou." and
# "Teamwork Negotiation: Magic (lead), Filament, Lou." lost every helper after the first (a bare comma joins no
# group), and the second its leader too; with the read failed, the words' reading stood with nobody helping.
HELP_HEAD = re.compile(r"(?:\bhelpers?\s*(?:are|is|:|-|=)|\bhelped\s+by|\bassisted\s+by|\bbacked(?:\s+up)?\s+by)\s*$",
                       re.I)
PAREN_ROLE = re.compile(r"\s*\(\s*(?:(?P<lead>lead(?:s|er|ing)?)|(?P<help>help(?:s|er|ing)?|assist(?:s|ing|ant)?|"
                        r"support(?:s|ing)?))\s*\)", re.I)
_LIST_GAP = re.compile(r"\s*(?:\(\s*[\w\s]+\)\s*)?,\s*")
_LIST_END = re.compile(r"\s*(?:$|[,;:.!?()]|\band\b|\s[-–—]+\s)", re.I)
# A name's own lead or help words count only where it's the subject of its clause: at the start, after a break or a
# joining word ("...and only magic is making this roll", "she leads", "Kaz helping"), or "with Magic leading". Never an
# object: review of P3 - "Lou ghosts up behind the guard, rolling Stealth", "Magic slips by the nurse, rolls Con" and
# "I stay silent, rolling Stealth" each made the guard, the nurse or Quiet Lou the leader, and the engine rolled it.
_SUBJECT = re.compile(r"(?:(?:^|[,;:()]|\s[-–—]+|\b(?:and|but|or|so|then|now|next|meanwhile|finally|first|instead|later|"
                      r"plus|also|while|when|because|ok|okay|alright|ooc|teamwork|team roll|let|lets|think|thinks|say|"
                      r"says|suggest|suggests|reckon|guess|figure)(?:\s+that)?)\s*(?:(?:only|just|also|even|then|now|"
                      r"probably|maybe|perhaps|first|certainly)\s+)*(?:the\s+)?|\bwith\s+)$", re.I)
# ... but the roll said to be theirs is theirs wherever it stands: "that should have been Magic's roll" (live T33).
OWN_ROLL = re.compile(r"['’]s\s+(?:[\w-]+\s+)?(?:roll|test|check)\b", re.I)
_OPEN = re.compile(r"^[\W_]*(?:(?:then|now|so|ok|okay|alright|and|but|also|ooc|teamwork|team roll)\b[\W_]*)*$", re.I)
# Names joined into one group: "Kaz and Ghost", "Kaz & Ghost" - a bare comma only inside a list that ends in one
# ("Kaz, Ghost and Razor help"): "led by Magic, Brask helping" is two parts, not a pair.
_CHAIN = re.compile(r"\s*,?\s*(?:\band\b|&|\+|\bor\b)\s*", re.I)
_COMMA = re.compile(r"\s*,\s*")
# Sentence breaks - but not the period of "Dr. A. Brask" or "vs.". A possessive's is one ("This is Magic's roll, not
# Brask's. Brask can help." - review of flag #52: the "'s" read as an initial, and the help fell into the call's
# sentence).
_BREAK = re.compile(r"(?<!\bdr)(?<!\bmr)(?<!\bms)(?<!\bmrs)(?<!\bst)(?<!\bjr)(?<!\bvs)(?:(?<!\b[a-z])|(?<=['’]s))[.!?;]+"
                    r"|\n+", re.I)
_VS = re.compile(r"\b(?:vs\.?|versus|against)\s+", re.I)
_QUOTED = re.compile(r"\"[^\"\n]*\"|“[^”\n]*”")
_PRONOUNS = {"i": "me", "me": "me", "my": "me", "myself": "me",
             "he": "3", "him": "3", "his": "3", "she": "3", "her": "3", "they": "3", "them": "3", "their": "3"}
_PRONOUN = re.compile(r"\b(?:" + "|".join(_PRONOUNS) + r")\b", re.I)


@dataclass
class _M:                       # one mention: a name or a pronoun, and who it is
    start: int
    end: int
    id: str | None
    kind: str                   # name, me (I/my), 3 (he/she/they: resolved to the nearest name before it)
    loose: bool = False         # someone else's alias or name word written lowercase ("the guard", "stay silent"):
                                # a part it's given is the cheap read's to check, like a he/she/they's
    far: bool = False           # an alias of someone not in the scene: whom a call is aimed at, never a part in it


def _cast(game, me: dict, scene_id) -> list[tuple[str, str, bool, bool]]:
    """(phrase, id, full, far) a post can name someone by, longest first: anyone on file by their full name or an
    alias; a player's character, the poster and whoever is in the scene by each word of their name too ("Brask" for Dr.
    A. Brask). full: the full name; far: an alias of an NPC who isn't in the scene - it can say whom a call is aimed at,
    never who leads or helps (review of P3: the live world's 'Guard', 'Nurse', 'Fenn' and 'Rook', none of them there,
    made an object of the post the leader of its roll)."""
    L = game.ledger
    here = set(L.roster(scene_id)) if scene_id else set()
    out: dict[str, tuple[str, bool, bool]] = {}

    def words(names, eid, force=False):
        for n in names:
            for w in _WORD.findall(n):
                w = w.lower().rstrip(".")
                if len(w) >= 3 and w not in TITLES:
                    if force:
                        out[w] = (eid, False, False)
                    else:
                        out.setdefault(w, (eid, False, False))
    for kind in ("pc", "npc", "spirit"):
        for e in L.entities(kind=kind):
            near = kind == "pc" or e["id"] in here
            for i, n in enumerate([e["name"], *(e.get("aliases") or [])]):
                k = " ".join(n.lower().split())
                if len(k) >= 3:
                    out.setdefault(k, (e["id"], i == 0, i > 0 and not near))
            if near:
                words([e["name"], *(e.get("aliases") or [])], e["id"])
    mine = [me["name"], *(me.get("aliases") or [])]
    for i, n in enumerate(mine):                         # (the poster's own name is theirs, whoever shares it)
        out[" ".join(n.lower().split())] = (me["id"], i == 0, False)
    words(mine, me["id"], force=True)
    return sorted(((k, *v) for k, v in out.items()), key=lambda kv: -len(kv[0]))


def _mentions(text: str, cast: list, me: str) -> list[_M]:
    """Every name and pronoun in the post, in order. A he/she/they is the nearest name before it - none, and it's
    nobody yet (live T127: "She should probably roll a check" was the doctor's roll, not the poster's)."""
    low, taken, out = text.lower(), [False] * len(text), []
    for phrase, eid, full, far in cast:
        for m in re.finditer(rf"(?<![\w'’-]){re.escape(phrase)}(?![\w-])", low):
            if any(taken[m.start():m.end()]):
                continue
            taken[m.start():m.end()] = [True] * (m.end() - m.start())
            said = text[m.start():m.end()]                 # ("magic" is a word before it's Magic; "quiet lou" is him)
            out.append(_M(m.start(), m.end(), eid, "name", far=far,
                          loose=eid != me and said == said.lower() and (not full or " " not in phrase)))
    for m in _PRONOUN.finditer(text):
        if not any(taken[m.start():m.end()]):
            out.append(_M(m.start(), m.end(), me if _PRONOUNS[m.group().lower()] == "me" else None,
                          _PRONOUNS[m.group().lower()]))
    out.sort(key=lambda x: x.start)
    for i, m in enumerate(out):
        if m.kind == "3":
            m.id = next((p.id for p in reversed(out[:i]) if p.kind == "name"), None)
    return out


def _unquote(text: str) -> str:
    """What the character says out loud isn't the call: "We need to talk, we can help" (live T128) helps nobody."""
    return _QUOTED.sub(lambda m: " " * len(m.group()), text)


def _sentences(text: str) -> list[tuple[int, int]]:
    spans, a = [], 0
    for m in _BREAK.finditer(text):
        if m.start() > a:
            spans.append((a, m.start()))
        a = m.end()
    if a < len(text):
        spans.append((a, len(text)))
    return spans


def _ended(text: str, a: int, b: int) -> str:
    """One of _sentences' spans with the end that closes it ('.', '?!', ';') - for quoting the post as written."""
    end = _BREAK.match(text, b)
    return text[a:end.end() if end else b]


def _groups(text: str, ms: list[_M], a: int, b: int) -> list[list[_M]]:
    """The mentions in text[a:b], chained ("Kaz and Ghost help": one group)."""
    groups: list[list[_M]] = []
    for m in (x for x in ms if a <= x.start < b):
        if groups and _CHAIN.fullmatch(text[groups[-1][-1].end:m.start]):
            groups[-1].append(m)
        else:
            groups.append([m])
    out: list[list[_M]] = []
    for g in reversed(groups):                           # "Kaz, Ghost and Razor": the comma joins a list that ends
        if out and len(out[-1]) >= 2 and _COMMA.fullmatch(text[g[-1].end:out[-1][0].start]):
            out[-1][:0] = g
        else:
            out.append(g)
    return list(reversed(out))


def _roles(text: str, a: int, b: int, ms: list[_M], strict: bool = False) -> list[tuple[str, str, int]]:
    """(part, id, rank) for one sentence: lead, help or among. Rank 3 a name (or I) with its own lead or help words, 2
    the one a named helper helps ("Ghost helps Brask": Brask), 1 a part given by a he/she/they, 0 by a lowercase alias
    or name word ("quiet and silent, makes a Stealth test") - the cheap read checks those, and a 0 lead it doesn't
    confirm is dropped. A group at the start with no part said ("Razor and Kaz work the fixer together") is among.
    strict: a sentence beside the call, not its own - only a bare help counts there (BARE_HELP), and no group."""
    out = []
    prev = None                                          # (where the last group with a part ended, and the part)
    for g in _groups(text, ms, a, b):
        if any(m.far for m in g):
            continue                                     # (someone not in the scene, by an alias: no part in it)
        after, before = text[g[-1].end:b], text[a:g[0].start]
        rank = 0 if any(m.loose for m in g) else 1 if any(m.kind == "3" for m in g) else 3
        ids = [m.id for m in g if m.id] or [None]          # (None: a he/she/they with nobody named before it)
        subject = bool(_SUBJECT.search(before))          # (its own lead or help words only as the clause's subject)
        lm, hm = (LEAD_AFTER.match(after), HELP_AFTER.match(after)) if subject else (OWN_ROLL.match(after), None)
        pm = PAREN_ROLE.match(after)                     # "Magic (lead)", "Lou (helping)"
        if hm and hm.group("verb") and HELP_PROSE.match(after, hm.end()):
            hm = None                                    # (a hand, not a roll: "helps her into the van")
        obj = None
        if hm and hm.group("verb"):                      # the one they help is the one rolling: "Ghost helps Brask"
            gap = re.match(r"\s+(?:out\s+)?", after[hm.end():])
            at = g[-1].end + hm.end() + (gap.end() if gap else 0)
            obj = next((m for m in ms if m.start == at and m.kind == "name" and m.id), None)
        if hm and strict and not obj and not BARE_HELP.match(after, hm.end()):
            hm = None                                    # (beside the call: "Kaz helps the bartender" helps no roll)
        # the rest of a list whose head gave a part: "Helpers: Filament, Lou", "Magic (lead), Filament, Lou"
        # - a bare name in it, never one with a verb of its own ("Filament helps, Lou watches the door")
        listed = prev and _LIST_GAP.fullmatch(text[prev[0]:g[0].start]) and _LIST_END.match(after) and (
            prev[1] == "help" or (prev[1] == "lead" and prev[2] and TEAMWORK.search(text, a, b)))
        if (pm and pm["lead"]) or lm or LEAD_BEFORE.search(before):
            part = "among" if len(ids) > 1 else "lead"
            out += [(part, i, rank) for i in ids]
            prev = (g[-1].end, part, bool(pm))
        elif (pm and pm["help"]) or hm or (HELP_BEFORE.search(before) and not strict) or HELP_HEAD.search(before) \
                or listed:
            out += [("help", i, rank) for i in ids]
            if obj:
                out.append(("lead", obj.id, 2))
            prev = (g[-1].end, "help", True)
        elif len(ids) > 1 and _OPEN.match(before) and not strict and TEAMWORK.search(text, a, b):
            out += [("among", i, rank) for i in ids]     # (only with teamwork said: "Razor and Kaz head in" isn't)
            prev = None
        else:
            prev = None
    return out


def _skills(text: str) -> tuple[list[str], list[str]]:
    """(the skills named for the roll, an attribute pair named with no skill)."""
    named = []
    for m in NAMED_SKILL.finditer(text):
        s = _SKILL_WORDS[next(g for g in m.groups() if g).lower()]
        if s not in named:
            named.append(s)
    pair = [] if named else next(([m["x"].lower(), m["y"].lower()] for m in ATTR_ONLY.finditer(text)
                                  if m["x"].lower() != m["y"].lower()), [])
    return named, pair


def _task(text: str) -> tuple[str | None, int]:
    """The skill the first task word points at, and where that word ends (whom it's aimed at follows)."""
    best = None
    for rx, skill in TASKS:
        m = rx.search(text)
        if m and (best is None or m.start() < best[1]):
            best = (skill, m.start(), m.end())
    if best:
        return best[0], best[2]
    m = SOCIAL_NOUN.search(text)                         # "this negotiation", "the con"
    return (_SKILL_WORDS[m["s"].lower()], -1) if m else (None, -1)


# What stands between a task word and whom it's aimed at: "convince the ...", "plead to ...", "pitches the deal to ..."
_TO_TARGET = re.compile(r"\s*(?:(?:the|an?|his|her|our|my|their)\s+(?:deal|offer|case|plan|pitch|idea|proposal)\s+to\s+"
                        r"|(?:the|to)\s+)?", re.I)


def _target(clean: str, a: int, b: int, ms: list[_M], skill: str) -> str | None:
    """Whom a task word for `skill` in clean[a:b] is aimed at: the name inside it ("gets Vandermeer on board", "talks
    Kaz into it") or right after it ("convince Kaz", "pitch to Vandermeer") - any of that task's words, not only the
    first (never another task's: in "sneaks past Joey and convinces Kaz" the Stealth isn't aimed at Kaz). Review
    2026-10-28 of flag #51: in "teamwork negotiation roll to convince Vandermeer" only 'negotiation' was looked
    behind, so the pitch was aimed at nobody and the teamwork's picked helpers took Vandermeer in."""
    hits = sorted((m for rx, s in TASKS if s == skill for m in rx.finditer(clean, a, b)), key=lambda m: m.start())
    for t in hits:
        inside = next((x for x in ms if x.kind == "name" and x.id and t.start() < x.start < t.end()), None)
        if inside:
            return inside.id
        at = t.end() + len(_TO_TARGET.match(clean[t.end():b]).group())
        who = next((x for x in ms if x.start == at and x.kind == "name" and x.id), None)
        if who:
            return who.id
    return None


SKILL_CHECK = re.compile(r"\bskill\s+(?:check|test|roll)s?\b", re.I)
TASK_LINE = 6         # words: a task said on its own beside the call ("Persuade Vandermeer.") is part of the call
# Someone named out of the roll: "Magic is making this roll, not Brask", "Brask stays quiet until Magic has her
# convinced" (live T155's shape). Their roll in the leader's place is a give-away whatever the call's shape
# (review of flag #49: "Magic is making this roll, not Brask" with no skill named let Brask's pitch through every time).
NOT_BEFORE = re.compile(r"\b(?:not|never|nor|instead\s+of|rather\s+than)\s+(?:by\s+|with\s+|for\s+)?(?:the\s+)?$", re.I)
NOT_AFTER = re.compile(
    r"^(?:['’]s)?\s+(?:will\s+be|is|gets?|has\s+been|should\s+be|was)\s+(?:instructed|told|asked|ordered)\s+(?:to\s+)?"
    r"(?:not|never|keep\s+(?:quiet|out))\b|^(?:['’]s)?\s+(?:won['’]t|doesn['’]t|does\s+not|will\s+not|shouldn['’]t|"
    r"should\s+not|mustn['’]t|must\s+not|isn['’]t|is\s+not|can['’]t|cannot|never)\s+(?:be\s+)?(?:roll\w*|speak\w*|talk\w*|"
    r"say\w*|pitch\w*|mak\w*|do(?:es|ing)?|lead\w*|negotiat\w*|chim\w*|get\w*\s+involved)\b"
    r"|^\s+(?:stays?|keeps?)\s+(?:out\s+of\s+it|quiet|silent|her\s+mouth\s+shut|his\s+mouth\s+shut)\b", re.I)


# The leader said to be the only one rolling: "only magic is making this roll" (live T155), "Magic alone rolls",
# "nobody else rolls" - then anyone not in on it rolling in their place is the call given away.
ONLY_BEFORE = re.compile(r"\b(?:only|just|solely)\s+(?:the\s+)?$", re.I)
ONLY_WORDS = re.compile(r"\b(?:no\s*one|nobody|none)\s+else\b|\balone\b|\bonly\s+(?:he|she|they|him|her)\b", re.I)


def _only(clean: str, spans: list, ms: list[_M], leader: str | None, used: list) -> bool:
    """Whether the call's own sentences say the leader is the only one rolling it."""
    if not leader:
        return False
    for a, b in (r["span"] for r in used):
        if ONLY_WORDS.search(clean, a, b):
            return True
        if any(m.id == leader and a <= m.start < b and ONLY_BEFORE.search(clean[a:m.start]) for m in ms):
            return True
    return False


def _excluded(clean: str, spans: list, ms: list[_M], me: str) -> list[str]:
    """Who the post names out of the roll (NOT_BEFORE / NOT_AFTER) - never the poster's own."""
    out = []
    for m in ms:
        if m.kind != "name" or not m.id or m.id == me or m.far:
            continue
        a, b = next(((x, y) for x, y in spans if x <= m.start < y), (0, len(clean)))
        if NOT_BEFORE.search(clean[a:m.start]) or NOT_AFTER.match(clean[m.end:b]):
            out.append(m.id)
    return list(dict.fromkeys(out))


def _read_post(game, ch: dict, text: str, scene_id, asked: tuple | None, edge: tuple | None) -> tuple[Call | None, bool]:
    """(the call one post makes, or None; whether the words settle it). A post calls a roll when it asks for the dice
    (turn.roll_asks, an Edge call, CUE) or sets up who leads and who helps with something mechanical ("Kaz assists by
    adding dice to his pool"); role words on a task alone ("Razor convinces the fixer with Kaz backing him up") leave
    it open - the cheap read decides."""
    me = ch["id"]
    clean = _unquote(text)
    spans = _sentences(clean)
    ms = _mentions(clean, _cast(game, ch, scene_id), me)
    rows = []
    for a, b in spans:
        s = clean[a:b]
        c = cue(s)
        firm = bool(roll_word(s) or NAMED_SKILL.search(s) or ATTR_ONLY.search(s) or (edge and EDGE_WORD.search(s))
                    or (c and not LOOSE_CUE.fullmatch(c.group())))
        roles = _roles(clean, a, b, ms)
        rows.append({"span": (a, b), "cue": firm or bool(c), "firm": firm, "roles": roles,
                     "mech": bool(roles and MECH.search(s)), "task": _task(s)[0],
                     "bare": _roles(clean, a, b, ms, strict=True)})
    strong = bool(asked or edge) or any(r["cue"] or r["mech"] for r in rows)
    # Firm: a roll word, a named skill or pair, a skill's test, Edge, or a part given with dice, a skill or teamwork
    # ("Ghost helps Razor with the pitch (teamwork)") - the read can't call that no roll. A bare "teamwork" or "make a
    # check" is the read's to veto, and without a read it's no call (review of P3: "Nice teamwork back there, Brask"
    # stayed owed though the read said called: false). A "no roll" anywhere sends the post to the read.
    firm = bool(edge) or any(r["firm"] or r["mech"] for r in rows)
    declined = any(_declined(clean, m.start()) for m in re.finditer(r"\b(?:re-?)?(?:roll|check|test)", clean, re.I))
    weak = any(r["roles"] and (r["task"] or SKILL_NOUN.search(clean[r["span"][0]:r["span"][1]])) for r in rows)
    if not strong and not weak:
        return None, True
    keys = [i for i, r in enumerate(rows) if r["cue"] or r["mech"]]
    # the call's sentences: those that ask, a short role line beside one ("Brask helps." - bare roles only there), or -
    # nothing asking - the role sentences themselves. A role further off is prose (live T155: "I'm helping her shorten
    # her timeline", two sentences on from the roll, isn't Magic helping anyone roll).
    use = set(keys)
    for _ in range(3):                                   # (a role line beside a role line beside the ask: "Negotiation
        grew = False                                     # teamwork test. Leader: Magic. Helpers: Filament, Lou.")
        for i, r in enumerate(rows):
            n = len(_WORD.findall(clean[slice(*r["span"])]))
            near = any(abs(i - k) == 1 for k in use)
            if i not in use and r["bare"] and near and n <= 12:
                use.add(i)
                r["roles"] = r["bare"]
                grew = True
            elif i not in use and near and keys and r["task"] and not r["roles"] and n <= TASK_LINE:
                # (a short task line between: "Magic leads, Brask helps. Persuade Vandermeer. Teamwork." - review
                # 2026-10-28 of flag #51: the role line two sentences off was lost, Magic's lead with it)
                use.add(i)
                grew = True
        if not grew:
            break
    if not keys:
        use = {i for i, r in enumerate(rows) if r["roles"]}
    used = [rows[i] for i in sorted(use)]
    body = " ".join(clean[slice(*r["span"])] for r in used)
    unknown = any(p == "lead" and x is None for r in used for p, x, _ in r["roles"])   # "She should roll a check"
    leads = [(rk, n, x) for n, r in enumerate(used) for p, x, rk in r["roles"] if p == "lead" and x]
    helps = [x for r in used for p, x, rk in r["roles"] if p == "help" and x]
    among = [x for r in used for p, x, rk in r["roles"] if p == "among" and x]
    vague = unknown or any(rk <= 1 for r in used for _, _, rk in r["roles"])
    top = max((rk for rk, _, _ in leads), default=0)
    firsts = list(dict.fromkeys(x for rk, _, x in sorted(leads, key=lambda t: (-t[0], t[1])) if rk == top))
    leader = firsts[0] if firsts else None
    vague = vague or len(firsts) > 1
    helpers = list(dict.fromkeys(h for h in helps if h != leader))
    among = list(dict.fromkeys(x for x in among if x != leader and x not in helpers))
    if leader and among:                                 # (a leader named: the rest of the group helps)
        helpers += among
        among = []
    if len(among) == 1:
        among = []
    named, pair = _skills(body)
    task, against = None, None
    # the task, and whom it's aimed at: the call's sentences first, then one right beside them ("Razor bluffs Kaz
    # about the chip. I roll Con, Edge if I miss.")
    beside = [rows[i] for i in sorted({i + d for i in use for d in (-1, 1)} - use) if 0 <= i < len(rows)]
    for r in used + beside:
        a, b = r["span"]
        t, end = _task(clean[a:b])
        if t and not task:
            task = t
        if t and end > 0 and not against:                # "convince Kaz", "bluffs Kaz", "gets Vandermeer on board"
            against = _target(clean, a, b, ms, t)
        vs = _VS.search(clean, a, b)
        if vs and not against:                           # "vs Kaz", "against Vandermeer"
            who = next((m for m in ms if m.start == vs.end() and m.kind == "name"), None)
            against = who.id if who else None
    # (the call's own sentences, each with its own end - joined bare, the send-back quoted "...Brask helping He uses
    # edge..." - review 2026-10-28)
    # (a sentence a line break ended keeps a ';' in the quote, never joined bare: "...the pitch; Brask helps...")
    said = " ".join(p if i == len(used) - 1 or re.search(r"[.!?;:,]\s*$", p) else p.rstrip() + ";"
                    for i, p in enumerate(_ended(clean, *r["span"]) for r in used))
    words = " ".join(said.split()) or (asked[1] if asked else edge[2] if edge else "")
    call = Call(me, ch["name"], words if len(words) <= 200 else words[:197].rsplit(" ", 1)[0],
                owed=strong, leader=leader, among=among, helpers=helpers,
                skill=named[0] if len(named) == 1 else None, attributes=pair if not named else [],
                task=(named[0] if len(named) == 1 else task) if len(named) <= 1 else None,
                teamwork=bool(TEAMWORK.search(clean)))
    if against and against not in call.participants():
        call.against = against
    if call.leader is None and me in call.helpers:       # "with my help, Razor..." - whose roll it is, they didn't say:
        vague = True                                     # the GM's pick (leader() None), the read's to settle
    if call.leader and call.leader != me and (game.ledger.get(call.leader) or {}).get("kind") != "pc":
        vague = True                                     # (an NPC leading a player's call: the read checks it's meant)
    call.named = list(dict.fromkeys(m.id for m in ms if m.id and any(a <= m.start < b for a, b in
                                                                     (r["span"] for r in used))))
    call.loose_lead = bool(call.leader) and top == 0
    call.firm = firm
    call.post = clean
    call.lead_rank = top if call.leader else 0
    if not call.shaped:                                  # (a task further off: the engine's pick if it rolls, no more)
        call.hint = next((t for t in (_task(clean[a:b])[0] for a, b in spans) if t), None)
    call.excluded = _excluded(clean, spans, ms, me)
    call.only = _only(clean, spans, ms, call.leader or (me if not call.helpers and not call.among else None), used)
    here = set(game.ledger.roster(scene_id)) if scene_id else set()
    call.mentioned = list(dict.fromkeys(
        m.id for m in ms if m.kind == "name" and m.id and m.id != me and not m.far and not m.loose
        and ((game.ledger.get(m.id) or {}).get("kind") == "pc" or m.id in here)))
    # Teamwork or helpers with no skill said ("a teamwork skill check, Magic leading, Brask helping" - review of flag
    # #51), or a bare "skill check": the read names the skill, so the engine can roll it if it has to. Teamwork with
    # nobody named to help: the read names them (and failing that, read() picks them from the post).
    sure = (strong and firm and not vague and not declined and not (call.teamwork and not call.helpers and not call.among)
            and not (not call.shaped and (not call.plain or SKILL_CHECK.search(body))))
    call.vague = vague
    call.unknown = unknown and call.leader is None
    return call, sure


# ── the cheap read, when the words leave it open ────────────────────────
READ_SYSTEM = FICTION_NOTE + """ You read one post from a player in a Shadowrun tabletop game run by an AI game \
master, and say whether it calls for a dice roll, and its shape. called: true when the player asks for the dice (a \
roll, a test, a check, a pool, Edge), or sets up who leads and who helps on something the dice decide (teamwork); \
false for plain story ("Kaz helps her into the van", "Razor leads them down the stairs"). leader: the id of the \
character the player says makes the roll or leads it ("Magic makes this roll", "she leads", "Ghost helps Brask" - \
Brask) - "" when they don't say. helpers: the ids of those they say help, assist, back the leader up or add dice - \
never someone told to stay out of it; when they call teamwork without naming helpers, the helpers are the crew \
members the post has contributing (speaking up, gesturing, backing the pitch). skill: the skill they name for the \
roll, else the one that fits what they're doing (talking someone round is negotiation; "" if nothing does); \
named_skill: true only when the post names it. against: the id of whoever the roll is aimed at (convince her, bluff \
the guard), "" if unclear. Use only the ids listed."""


def read_schema() -> dict:
    return {"type": "object", "properties": {
        "called": {"type": "boolean"}, "leader": {"type": "string"},
        "helpers": {"type": "array", "items": {"type": "string"}},
        "skill": {"type": "string", "enum": [""] + sorted(sr_lite.SKILLS)}, "named_skill": {"type": "boolean"},
        "against": {"type": "string"}},
        "required": ["called", "leader", "helpers", "skill", "named_skill", "against"], "additionalProperties": False}


def _model_read(game, ch: dict, text: str, scene_id, context: str = "") -> dict | None:
    """Haiku's read of a post the words leave open, or None (no read: the words' reading stands). context: what the
    GM narrated past the call, when the engine asks only for the skill (skill_read)."""
    L = game.ledger
    ids = list(dict.fromkeys([ch["id"], *(L.roster(scene_id) if scene_id else []),
                              *(e["id"] for e in L.entities(kind="pc"))]))
    people = []
    for i in ids[:30]:
        e = L.get(i)
        if e and e["kind"] in ("pc", "npc", "spirit"):
            al = [a for a in e.get("aliases") or [] if a != e["name"]]
            people.append(f"- {i}: {e['name']}" + (f" ({', '.join(al)})" if al else "")
                          + (" - the poster" if i == ch["id"] else ""))
    user = (f"CALLED ROLL READ\nThe poster plays {ch['name']} [{ch['id']}].\nCharacters (id: name):\n"
            + "\n".join(people) + f"\n\nTHE POST:\n{text}"
            + (f"\n\nWHAT THE GM NARRATED (it skipped the roll - say which skill the post's roll is):\n{context[:1500]}"
               if context else ""))
    try:
        game.progress("🎲 reading the roll they called", "callread")
        d = game.llm.structured(game.settings.models.commit, READ_SYSTEM, user, read_schema(), max_tokens=400,
                                effort="low", purpose="calls")
    except Exception as exc:                             # (no read: the words' reading stands - never costs a turn)
        print(f"[calls] the read failed: {exc}", flush=True)
        return None
    if not isinstance(d, dict) or not isinstance(d.get("called"), bool):
        return None
    ok = {i for i in ids}
    pick = lambda v: v if isinstance(v, str) and v in ok else None          # noqa: E731
    return {"called": d["called"], "leader": pick(d.get("leader")),
            "helpers": [h for h in (d.get("helpers") or []) if pick(h)],
            "skill": d.get("skill") if d.get("skill") in sr_lite.SKILLS else None,
            "named": bool(d.get("named_skill")), "against": pick(d.get("against"))}


def _merge(call: Call, d: dict, strong: bool) -> Call | None:
    """The read fills what the words left open; what they did say stands. strong: the words ask for the dice firmly
    (Call.firm) - only then does a read that says it's no call not drop it."""
    if not d["called"] and not strong:
        return None
    call.owed = call.owed or d["called"]
    # (a leader the words named by their own lead words - the poster too - stands: review of flag #48, "Teamwork
    # Negotiation test to convince her, Magic leads." came out Brask's on a read that named her)
    if d["leader"] and (call.leader is None or call.vague or call.lead_rank < 3):
        call.leader = d["leader"]
    if d["helpers"]:
        call.helpers = list(dict.fromkeys([*call.helpers, *(h for h in d["helpers"] if h != call.leader)]))
        call.among = [x for x in call.among if x not in call.helpers and x != call.leader]
    if call.leader in call.helpers:
        call.helpers.remove(call.leader)
    if d["skill"] and not call.skill:
        if d["named"]:
            call.skill, call.task = d["skill"], d["skill"]
        elif not call.task:
            call.task = d["skill"]
    if d["against"] and not call.against and d["against"] not in call.participants():
        call.against = d["against"]
    call.how = "model"
    return call


def _pick_helpers(game, call: Call, quiet) -> None:
    """Teamwork called and nobody named to help - not by the words, not by the read: the helpers are the crew the
    post has pitching in, the ones it names (outside quotes) who are in the scene, never the leader, the one it's
    aimed at, someone named out of it, or a player's character whose player didn't post (quiet: turn.hands_off - each
    player decides for their own). Flag #38: live T128 called a teamwork Negotiation check with Magic in the lead,
    Filament and Lou speaking up beside him - the live read gave helpers [] three times of three, and Magic rolled
    alone."""
    L = game.ledger
    lead = call.leader or call.poster
    out = []
    for x in call.mentioned:
        e = L.get(x)
        if (not e or x in (lead, call.against) or x in call.excluded or e["kind"] not in ("pc", "npc", "spirit")
                or (e["kind"] == "pc" and e["name"] in (quiet or ()))):
            continue
        out.append(x)
    if out:
        call.helpers, call.picked = out, True


def read(game, inputs: list[tuple[str, str]], scene_id, asked: dict, edge: dict, quiet=None) -> list[Call]:
    """The calls this turn's posts make. asked: turn.roll_asks; edge: turn.edge_asks (both by pc id); quiet: whose
    players didn't post (turn.hands_off) - never a helper the engine picks."""
    out = []
    for handle, text in inputs:
        ch = game.character_for(handle)
        if not ch or not text or text.lstrip().startswith(("((", "!ooc")):
            continue
        call, sure = _read_post(game, ch, text, scene_id, asked.get(ch["id"]), edge.get(ch["id"]))
        if call is None and not sure:
            continue
        if call is not None and not sure:
            d = _model_read(game, ch, text, scene_id)
            strong = call.owed
            lead = call.leader if call.loose_lead else None
            if d is not None:
                call = _merge(call, d, strong and call.firm)
            elif not strong or not call.firm:
                call = None                              # (no read, no firm ask - roll words, a skill, Edge: no call)
            if call is not None and lead and call.leader == lead and not (d and d["leader"] == lead):
                call.leader = None                       # ("quiet and silent, makes a Stealth test" isn't Quiet Lou's
                call.loose_lead = False                  # on the words alone - review of P3)
        if call is not None and call.unknown and call.leader is None:
            call = None                                  # (whose roll it is, nobody can say - not the poster's)
        if call is not None and not call.helpers and not call.among and call.owed and TEAM_WORD.search(call.words):
            _pick_helpers(game, call, quiet)             # (teamwork said in the call itself - not a "together")
        if call is not None:
            out.append(call)
    return out


# ── who rolls ───────────────────────────────────────────────────────────
def _ref(L, ref) -> str | None:
    e = L.find(str(ref or "")) if ref else None
    return e["id"] if e else None


def _nm(L, eid) -> str:
    return (L.get(eid or "") or {}).get("name") or str(eid)


def _and(names: list[str]) -> str:
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def _pool(L, eid: str, skill: str | None, attribute: str | None = None, attrs=None) -> int:
    try:
        if attrs:
            return sr_lite.attribute_pool(L, eid, attrs)[0]
        if skill:
            return sr_lite.build_pool(L, eid, skill, attribute)[0]
    except BAD_ARGS:
        return -1
    return 0


# What a GM's malformed arguments raise in the guard - never past it (review of P3: an opposed_by sent as a JSON
# string raised AttributeError out of run_tool, and a threshold of '3 (hard)' raised ValueError out of the backstop;
# run_turn undid the whole turn each time, where the same arguments with no call were a tool error to fix).
BAD_ARGS = (LedgerError, KeyError, ValueError, TypeError, AttributeError, OverflowError)


def _low(v) -> str | None:
    """A GM's string argument, lowercased - None for anything else."""
    return (v.strip().lower() or None) if isinstance(v, str) else None


def _dict(v) -> dict:
    return v if isinstance(v, dict) else {}


def _list(v) -> list:
    return v if isinstance(v, list) else []


def _helped(L, args: dict) -> list[str]:
    return [x for x in (_ref(L, h.get("id")) for h in _list(args.get("helpers")) if isinstance(h, dict)) if x]


def _group(call: Call) -> list[str]:
    """Who's in on a call nobody was named to lead: the group they named (among), else the poster and the helpers
    they named ("Teamwork Stealth test, Lou helping": Magic and Lou)."""
    if len(call.among) >= 2:
        return list(call.among)
    return list(dict.fromkeys([call.poster, *call.helpers]))


def leader(L, call: Call, skill: str | None = None, attribute: str | None = None, attrs=None) -> str | None:
    """Who rolls the call: the one the player named; else the highest pool for the skill rolled among those named in
    on it - the group, or the poster and the helpers they named (the owner, 2026-10-27, decision 4: "the highest pool among
    the named participants if nobody is named as leader"; ties: the poster's own, then the first named) - unless the
    poster named themselves a helper of someone they didn't name ("With my help, Razor picks it"): None, the GM's
    pick. Review of flag #48: "Teamwork Stealth test to sneak past the guards, Lou helping" was Magic's 2 untrained
    dice by default, Lou's 9 helping at +1 - and the engine refused the GM's Lou-led roll and rolled Magic's itself."""
    if call.leader:
        return call.leader
    if call.poster in call.helpers and len(call.among) < 2:
        return None
    group = _group(call)
    if len(group) < 2:
        return call.poster
    a = attrs or call.attributes
    s = None if a else (call.skill or (skill if skill and _fits(call, skill, []) else None) or call.task or skill)
    return max(group, key=lambda e: (_pool(L, e, s, attribute, a), e == call.poster, -group.index(e)))


def helpers_for(L, call: Call, lead: str | None) -> list[str]:
    """Who helps: the helpers named (or picked) and the rest of the group - the poster too, when the highest pool
    took the lead from them - anyone who can still act."""
    group = [*call.helpers, *call.among] + ([call.poster] if not call.leader and len(call.among) < 2 else [])
    out = [h for h in dict.fromkeys(group) if h != lead and L.get(h)]
    return [h for h in out if sr_lite.condition(L, h) not in sr_lite.OUT]


def family(call: Call) -> set | None:
    """The skills a roll for the call may use: the one named, or the task's family; None - anything."""
    if call.skill:
        return {call.skill}
    if call.attributes:
        return set()
    if call.task:
        return set(SOCIAL) if call.task in SOCIAL else {call.task}
    return None


def _fits(call: Call, skill: str | None, attrs: list) -> bool:
    fam = family(call)
    if fam is None:
        return True
    if call.attributes:
        return sorted(attrs) == sorted(call.attributes)
    return bool(skill) and skill in fam


def _why_lead(L, call: Call, lead: str | None, skill: str | None) -> str:
    if lead is None:
        return f"whoever {call.name} helps - their player didn't say who"
    if call.leader == lead:
        return "the one their player named to lead"
    group = _group(call)
    if len(group) >= 2:
        return (f"the highest pool for {sr_lite.nice(call.skill or skill or call.task or 'it')} of "
                f"{_and([_nm(L, x) for x in group])} - nobody was named to lead")
    return "their player's own character"


def _edge_spent(ctx, pc: str) -> bool:
    """Whether pc has spent a point of Edge this turn already (the ledger's edge events)."""
    tid = getattr(ctx, "turn_id", None)
    return tid is not None and any(e["kind"] == "edge" and e["actor"] == pc for e in ctx.game.ledger.events(tid))


def _edge_mode(ctx, call: Call, lead: str) -> str | None:
    """The Edge the poster called rides only their own roll (R14) - None otherwise, or when the mode wasn't said, or
    once a point of it is spent this turn: one call is one point (review of P3: the GM pushed it on Razor's Perception,
    then the engine pushed it again on his called Con - Edge 3 -> 1)."""
    asked = (getattr(ctx, "edge_asks", None) or {}).get(call.poster)
    if not asked or lead != call.poster or _edge_spent(ctx, call.poster):
        return None
    if asked[1] == "push" and _edge_left(ctx, call.poster) <= 0:
        return None                                      # (no point to push with: the roll goes without - flag #50)
    return asked[1]


def _edge_left(ctx, pc: str) -> int:
    try:
        return int(ctx.game.ledger.stat(pc, "edge_points"))
    except BAD_ARGS:
        return 0


def _seated(ctx, call: Call, lead: str | None) -> bool:
    """lead is someone a human plays whose player didn't post this turn (turn.hands_off), named by another player:
    their roll isn't owed, the engine never rolls it, and only their own roll is held to the call's shape (review of
    P3: Ghost's "Razor makes a Perception test, I help" had the engine roll for Razor's silent player; each player
    decides only for their own character)."""
    quiet = getattr(ctx, "hands_off", None) or []
    return bool(lead and lead != call.poster and quiet and _nm(ctx.game.ledger, lead) in quiet)


def _matrix_hint(ctx, decker: str | None = None) -> str:
    """P2's hook (tools.matrix_target): the host the player named for this decker's dive, for a call made in the
    Matrix - never another decker's, or a host they ruled out (review of flag #36)."""
    from .tools import matrix_target
    t = matrix_target(ctx, decker)
    if not t:
        return ""
    L = ctx.game.ledger
    out = (f" - into the host they named, {_nm(L, t['host'])} [{t['host']}]" if t["host"]
           else f" - against the rating {t['rating']} target they named (a host no harder)" if t["rating"] is not None
           else "")
    return out + (f" - not {_and([_nm(L, h) for h in t['avoid']])}, which they ruled out" if t["avoid"] else "")


def instruction(ctx, call: Call, args: dict | None = None) -> str:
    """Exactly what to roll for the call."""
    L = ctx.game.ledger
    a = args or call.tried or {}
    gm = _low(a.get("skill"))
    skill = call.skill or (gm if gm and _fits(call, gm, []) else None) or call.task
    lead = leader(L, call, skill, None, call.attributes or None)
    tool = TOOL_FOR.get(call.skill or call.task or "")
    also = ALSO_BY.get(call.skill or call.task or "", ())
    if tool and tool != "request_test" and not gm:
        who = f"{_nm(L, lead)} [{lead}]" if lead else "the one they help"
        return (f"{'an' if tool[0] in 'aeiou' else 'a'} {tool} call"
                + (f" (or {' or '.join(also)}, thrown=true, for a grenade)" if "explode" in also else "")
                + f" with {who} rolling ({_why_lead(L, call, lead, skill)})"
                + (_matrix_hint(ctx, lead) if tool == "matrix" else "")
                + (f", edge='{_edge_mode(ctx, call, lead)}' as they said it" if _edge_mode(ctx, call, lead) else ""))
    bits = [f"actor_id='{lead}' ({_nm(L, lead)}: {_why_lead(L, call, lead, skill)})" if lead
            else f"the actor: {_why_lead(L, call, lead, skill)}"]
    if call.skill:
        bits.append(f"skill='{call.skill}' (they named it)")
    elif call.attributes:
        bits.append(f"attributes={call.attributes} (they named them)")
    elif call.task:
        fam = "a social skill" if call.task in SOCIAL else f"skill='{call.task}'"
        bits.append(f"{fam} for what they're doing ({sr_lite.nice(call.task)} fits)")
    elif call.hint:
        bits.append(f"the skill that fits what they're doing ({sr_lite.nice(call.hint)}, by their post)")
    else:
        bits.append("the skill that fits what they're doing")
    hs = helpers_for(L, call, lead)
    if hs:
        bits.append("helpers=[" + ", ".join(f"{{'id': '{h}'}}" for h in hs) + "] (" + _and([_nm(L, h) for h in hs])
                    + ")")
    elif call.teamwork:
        bits.append("helpers: whoever is pitching in (they called teamwork)")
    mode = _edge_mode(ctx, call, lead)
    if mode:
        bits.append(f"edge='{mode}' as they said it")
    if call.against and call.against != lead and (skill or "") in OPPOSE and not (a.get("opposed_by")
                                                                                 or a.get("threshold")):
        bits.append(f"opposed_by {{'entity_id': '{call.against}'}} ({_nm(L, call.against)}) if they resist")
    out = "request_test " + ", ".join(bits)
    if "crash" in also:
        out += " - or, for a ram, the crash tool with them driving"
    elif "heal" in also:
        out += f" - or heal how='first_aid' with healer_id='{lead}'" if lead else " - or heal how='first_aid'"
    return out


# ── holding the GM to it ────────────────────────────────────────────────
def _tool_verdict(ctx, call: Call, name: str, args: dict, rollers: list[str]):
    """A roll tool other than request_test: ('meets', '') when it rolls the call's skill with the leader rolling -
    TOOL_FOR's tool, or ALSO_BY's (a ram, First Aid, a thrown grenade) - else None."""
    L = ctx.game.ledger
    s = call.skill or call.task or ""
    if name not in (TOOL_FOR.get(s), *ALSO_BY.get(s, ())):
        return None
    if name == "crash" and not (args.get("into_id") or (args.get("barrier_of") and args.get("driver_id"))):
        return None                                      # (only a ram rolls the driver's Piloting)
    if (name == "heal" and args.get("how") != "first_aid") or (name == "explode" and not args.get("thrown")) or (
            name == "sprite" and args.get("action") != "compile"):
        return None                                      # (care, a planted charge, a sprite's task: not this roll)
    lead = leader(L, call, s or None) or call.poster
    who = {_ref(L, r) for r in rollers}
    if name in ("attack", "crash"):                      # (the attacker's roll, not the dodge of the one attacked)
        who -= {_ref(L, args.get("target_id")), _ref(L, args.get("into_id"))} | {
            _ref(L, m.get("target_id")) for m in _list(args.get("more")) if isinstance(m, dict)}
    if lead not in who:
        return None
    if name == "matrix" and not matrix.edge_rides(L, lead, str(args.get("action") or ""), args.get("target_id"),
                                                  args.get("node"), bool(args.get("forced"))):
        return None                                      # (a jack-in rolls nothing: the hack is still owed)
    return ("meets", "")


def _verdict(ctx, call: Call, name: str, args: dict, rollers: list[str]):
    """How one tool call stands to one call: ('meets', ...), ('hard', problem), ('soft', problem, then) or None (it
    isn't this call's roll). then: what a soft one is once the GM repeats it - 'meets' or None. A roll is the call's
    only where it's aimed where the call is: review of P3 - Joey's Perception against Ghost sneaking in, and Joey
    leaning on Razor during Razor's haggle with Tanaka, were each turned away twice and then rolled as Razor's call."""
    L = ctx.game.ledger
    if name != "request_test":
        return _tool_verdict(ctx, call, name, args, rollers)
    actor = _ref(L, args.get("actor_id"))
    if not actor:
        return None
    runs = [x for x in (_ref(L, r) for r in rollers) if x and x != actor]
    if (L.get(actor) or {}).get("kind") in sr_lite.MACHINES and runs:
        actor = runs[0]                                  # (a drone its rigger runs rolls the rigger's skill: theirs)
    skill = _low(args.get("skill"))
    attrs = sorted(x for x in (_low(v) for v in _list(args.get("attributes"))) if x)
    helped = _helped(L, args)
    opp = _dict(args.get("opposed_by"))
    other = _ref(L, opp.get("entity_id"))
    lead = leader(L, call, skill, _low(args.get("attribute")), attrs or None)
    if lead and (not L.get(lead) or sr_lite.condition(L, lead) in sr_lite.OUT or lead in getattr(ctx, "refused", ())):
        return None                                      # (a leader who can't act: answered, as unmet has it - review
        #                                                   of P3: the named helper taking the pitch over was refused
        #                                                   forever, and told to roll the unconscious leader's)
    people = call.participants()
    fits = _fits(call, skill, attrs)
    rolled = sr_lite.nice(skill) if skill else " + ".join(x.title() for x in attrs) or "it"
    # aimed at someone who isn't the one the call is aimed at, nor in on it: another roll ("haggle Tanaka down" isn't
    # rolled against Joey)
    elsewhere = bool(other and call.against and other != call.against and other not in people)
    if lead is None:                                     # (the GM picks who they help: only the helpers are held)
        if actor not in call.named and not set(helped) & people:
            return None                                  # (nobody the post named: not the one they help - live T17)
        if not fits and not set(helped) & people:
            return None
        missing = [h for h in helpers_for(L, call, None) if h not in helped and h != actor]
        if missing and not attrs:
            names = _and([_nm(L, h) for h in missing])
            return ("hard", f"{names} {'are' if len(missing) > 1 else 'is'} helping, as their player said, and this "
                            f"roll leaves {'them' if len(missing) > 1 else names} out")
        return ("meets", "")
    ln = _nm(L, lead)
    if actor == lead:
        if not fits and not set(helped) & people:
            return None                                  # another roll of theirs (a Perception on the way in)
        if elsewhere:
            return None                                  # (theirs, at someone else: the call's is still owed)
        if call.skill and skill != call.skill:
            return ("hard", f"they named {sr_lite.nice(call.skill)}, and this rolls {rolled}")
        if call.attributes and attrs != sorted(call.attributes):
            return ("hard", f"they named {' + '.join(x.title() for x in call.attributes)}, and this rolls {rolled}")
        missing = [h for h in helpers_for(L, call, lead) if h not in helped]
        if missing and not attrs:
            names = _and([_nm(L, h) for h in missing])
            them = 'them' if len(missing) > 1 else names
            if call.picked:                              # (flag #38: the post has them pitching in on the teamwork)
                return ("hard", f"they called teamwork and their post has {names} pitching in, and this roll leaves "
                                f"{them} out")
            if call.poster in missing and call.poster not in call.helpers:
                return ("hard", f"{names} {'are' if len(missing) > 1 else 'is'} in on it, as their player said - the "
                                f"highest pool leads and the rest help - and this roll leaves {them} out")
            return ("hard", f"they named {names} helping, and this roll leaves {them} out")
        if call.teamwork and not helped and not attrs:
            return ("soft", f"they called teamwork, and this roll of {ln}'s has nobody helping", "meets", "alone")
        return ("meets", "")
    if _seated(ctx, call, lead):
        return None                                      # (their player didn't post: only their own roll is held)
    an = _nm(L, actor)
    fam = family(call)
    social = bool(fam and fam & set(SOCIAL))
    kin = social and skill in SOCIAL                     # another social skill on a social call: Etiquette for the pitch
    npc = (L.get(actor) or {}).get("kind") not in ("pc", None)
    at_pc = bool(other and (L.get(other) or {}).get("kind") == "pc")
    at_them = bool(other and other != lead and other not in people and (
        other == call.against or (call.against is None and not at_pc)))   # (where the call is aimed, or at an NPC)
    if lead in helped and not elsewhere and (fits or kin):
        # (review of flag #48: Brask's Etiquette at Vandermeer, Magic as her helper, went through on a called
        # Negotiation - the skill didn't fit, so it wasn't the call's; it's the call given away all the same)
        return ("hard", f"this has {an} rolling and {ln} helping - it's {ln}'s roll ({_why_lead(L, call, lead, skill)})")
    theirs = _low(opp.get("skill"))
    if other == lead and fam is not None and call.against in (None, actor) and (
            fits or _fits(call, theirs, [])):
        # (the call's own test run from the other side - Kaz's Perception against Razor's called Con: his Edge can't
        # ride it. Not a plain call's: Joey spotting Razor isn't Razor's "push the limit on the shot"; nor, with the
        # call aimed at Tanaka, Joey's own Intimidation on Razor)
        return ("hard", f"this has {an} rolling against {ln} - {ln} rolls it, {an} is the other side")
    if (other and other not in people and other != lead and other != call.against and fam is not None and theirs
            and _fits(call, theirs, []) and not (fits or kin) and (L.get(other) or {}).get("kind") != "pc"
            and (actor == call.against or (call.against is None and npc))):
        # (the pitch made by someone not in on it, from the other side - review of flag #48: Vandermeer's read
        # "opposed by Brask's Negotiation" was Brask pitching in Magic's place, and went through)
        on = _nm(L, other)
        return ("hard", f"this has {on} making the {sr_lite.nice(theirs)} side of it against {an} - that's the roll "
                        f"their player called for {ln}; {on} can help, never roll it in their place")
    if actor in people and (fits or kin) and not elsewhere:
        part = "a helper they named" if actor in call.helpers else "in on it"
        return ("hard", f"{an} is {part} - the roll is {ln}'s ({_why_lead(L, call, lead, skill)})")
    if fam is not None and (fits or (kin and npc and other)) and actor not in people and not (
            actor in call.excluded and other is None and not npc):
        if other is None:
            if social and npc:
                # (live T155: Brask's lone pitch "at threshold 3" is still Magic's - review of flag #52: a soft miss let
                # her repeat reach the record beside the engine's roll for Magic)
                return ("hard", f"{an} is making the {rolled} roll their player called for {ln} - {an} can help, "
                                "never roll it in their place")
            return ("soft", f"{an} rolls {rolled} while the roll {ln}'s player called is still owed", None)
        if at_them and (social or other == call.against):
            # (live T155: Brask pitching Vandermeer is Magic's pitch. An NPC's roll at a player's character - Joey
            # spotting Ghost slip in - is the NPC's own, as is any roll aimed past the one the call is aimed at)
            return ("hard", f"{an} is making the {rolled} roll their player called for {ln} - {an} can help, never "
                            "roll it in their place")
    if actor in call.excluded and not at_pc and (fits or kin or fam is None or at_them):
        # (live T155: "Brask will be instructed to not speak" - her "science" roll at Vandermeer is her speaking)
        return ("hard", f"their player named {an} out of it (\"{call.quoted(80)}\") - it's {ln}'s roll")
    if call.only and npc and actor not in people and not at_pc and (fits or kin or fam is None) and (
            other is None or at_them) and lead not in getattr(ctx, "rolled", ()):
        # ("only magic is making this roll" - live T155, word for word: anyone else's pitch is his given away)
        return ("hard", f"their player said only {ln} makes this roll, and this has {an} making it")
    if fam is None and npc and actor not in people and not at_pc and lead not in getattr(ctx, "rolled", ()) and (
            other is None or at_them):
        # A call that names no skill: an NPC rolling while the leader hasn't is the call given away as often as not
        # (review of flags #49/#52: "Magic is making this roll" with Brask pitching Vandermeer went through three times
        # and the engine had nothing to roll) - turned away once, and kept (tried) so the engine can roll it right.
        return ("soft", f"{an} rolls {rolled} while {ln} hasn't rolled the roll their player called", None)
    return None


def check(ctx, name: str, args: dict, rollers: list[str]) -> list[Call]:
    """Before the dice (tools.run_tool): the calls this tool call answers - marked met once it has rolled - if any.
    (Two players calling the one roll - "Razor makes it, Ghost helps" and "Ghost helps Razor" - are both met by it.)
    A roll that gives a call to someone else, the wrong named skill, or leaves out a named helper is a RulesRefusal
    naming exactly what to roll; the third such try the engine rolls the call itself (Rolled). A soft miss (teamwork
    with nobody helping, an NPC rolling the call's skill on its own) is turned away once - repeated, it goes."""
    open_ = [c for c in getattr(ctx, "calls", None) or [] if not c.met and not c.given_up]
    if not open_ or name not in ROLL_TOOLS:
        return []
    seen = [(c, _verdict(ctx, c, name, args, rollers)) for c in open_]
    meets = [c for c, v in seen if v and v[0] == "meets"]
    if meets:
        return meets
    for c, v in seen:
        if v and v[0] == "hard":
            if name == "request_test":
                c.tried = dict(args)
            c.refusals += 1
            if c.refusals > HARD_REFUSALS:
                card = engine_roll(ctx, c, args)
                if card:
                    ctx.game.out(f"[GUARD] the GM gave {c.name}'s called roll away a third time - the engine rolled it")
                    raise Rolled(f"(Engine: {v[1]}. Turned away {HARD_REFUSALS} times, so the engine rolled the call "
                                 "itself, the way their player called it, with your threshold or opposition and "
                                 f"modifiers:)\n{card}\n(Narrate from this result.)")
                # Nothing the engine can roll (nobody to lead it, a leader who can't act, a bad argument): the hold
                # ends here - the GM's roll goes through and the table hears the call was never made. (Review of P3:
                # it refused the same roll again on every try for the rest of the turn.)
                _give_up(ctx, c, f"the GM gave it away {c.refusals} times and the engine couldn't roll it itself")
                continue
            ctx.game.out(f"[GUARD] a roll that isn't the one {c.name}'s player called - turned away ({c.refusals}/"
                         f"{HARD_REFUSALS})")
            raise RulesRefusal(f"{c.name}'s player called this roll (\"{c.quoted()}\"): {v[1]}. Roll it as they "
                               f"called it - {instruction(ctx, c, args)}; keep your threshold or opposition and "
                               "modifiers. Nothing was rolled."
                               + (" Next time the engine rolls it that way itself." if c.refusals == HARD_REFUSALS
                                  else ""))
    for c, v in seen:
        if v and v[0] == "soft":
            if c.nudged:
                if v[2] == "meets":
                    if v[3:] == ("alone",):              # (flag #38: never a teamwork call rolled solo unflagged)
                        from .. import flags
                        flags.record(ctx.game, "engine", "teamwork called, nobody helped", f"{c.name}'s player "
                                     f"called teamwork (\"{c.quoted()}\") and the roll went out with nobody helping",
                                     turn=getattr(ctx, "turn_id", None))
                    return [c]
                if name == "request_test":
                    c.seen = dict(args)                  # (it goes through - and the engine knows what it was)
                return []
            c.nudged = True
            if name == "request_test":
                c.tried = dict(args)
            raise RulesRefusal(f"{c.name}'s player called a roll (\"{c.quoted()}\"): {v[1]}. The roll they called "
                               f"is {instruction(ctx, c, args)}. If this one is really what you mean, call it again "
                               "and it goes through. Nothing was rolled.")
    if name == "request_test":                           # a roll going through while a call with no skill is owed
        L = ctx.game.ledger
        actor = _ref(L, args.get("actor_id"))
        other = _ref(L, _dict(args.get("opposed_by")).get("entity_id"))
        for c in open_:                                  # (an NPC's own roll at a runner is the NPC's, never kept)
            if (not c.shaped and actor and actor not in c.participants() and _low(args.get("skill"))
                    and (L.get(actor) or {}).get("kind") not in ("pc", None)
                    and (L.get(other or "") or {}).get("kind") != "pc"):
                c.seen = dict(args)
    return []


def unmet(ctx) -> list[Call]:
    """The calls still owed a roll. A plain one is answered by any roll of the leader's (ctx.rolled); one turned away
    for want of an Action Phase is answered (ctx.refused - asking again would only meet the same refusal); so is one
    whose leader can't act, and one whose leader's player didn't post (_seated: never the engine's to roll for them)."""
    L, out = ctx.game.ledger, []
    for c in getattr(ctx, "calls", None) or []:
        if c.met or c.given_up or not c.owed:
            continue
        lead = leader(L, c, c.skill or c.task, None, c.attributes or None) or c.poster
        if c.plain and lead in ctx.rolled:
            c.met = True
            continue
        if lead in ctx.refused or not L.get(lead) or sr_lite.condition(L, lead) in sr_lite.OUT or _seated(ctx, c, lead):
            continue
        if c.leader is None and c.poster in c.helpers and any(_seated(ctx, c, x) for x in c.named):
            continue                                     # ("Razor talks Kaz down, I help" - Razor's player silent)
        out.append(c)
    return out


def send_back(ctx, due: list[Call]) -> str:
    """The send-back: what each call is, exactly, and what follows if the GM narrates past it again."""
    n = ctx.call_sendbacks
    said = " ".join(f"{c.name}'s player called a roll (\"{c.quoted()}\") and you narrated without it. Roll it "
                    f"now: {instruction(ctx, c)}." for c in due)
    can = {rollable(c) for c in due}
    then = ("the engine rolls it itself" if can == {"yes"} else
            "the engine can't play it for you - the table is told the roll wasn't made" if can == {"no"} else
            "the engine rolls it itself if it can tell the skill from their post - the table is told if it can't")
    return (f"(Engine: {said} A called roll is binding: the one they named (or the highest pool of those they named) "
            "rolls it - never an NPC in the scene in their place; an expert in the room is a helper. Then write the "
            "whole narration again from the result. "
            + (f"Sent back {n} of {SEND_BACKS}; after that {then}." if n < SEND_BACKS
               else f"Narrate past it once more and {then}.") + ")")


def skill_read(ctx, call: Call, narration: str = "") -> str | None:
    """The skill a call that names none means, asked of the cheap read once (the post, and the narration that skipped
    it) - review of flag #51: "a teamwork skill check, Magic leading, Brask helping" read as sure, nobody asked which
    skill, and the engine had nothing to roll. None: no read, or no skill the engine rolls."""
    if call.asked_skill:
        return None
    call.asked_skill = True
    g = ctx.game
    ch = g.ledger.get(call.poster)
    if not ch:
        return None
    d = _model_read(g, ch, call.post or call.words, getattr(ctx, "scene_id", None), narration)
    s = (d or {}).get("skill")
    return s if s and not TOOL_FOR.get(s) else None


# A flat modifier standing in for teamwork (live: "Magic's coaching (teamwork)" +2; flag #38's probe: "teamwork:
# Filament and Lou back him (R8)" +4) skips the helpers' rolls and the book's cap on what they add (decision 3).
TEAM_MOD = re.compile(r"\b(?:team\s*work|team\s+(?:roll|effort)|helpers?|helping|help\s+(?:from|of)|assist\w*|R8)\b",
                      re.I)


def team_mods(mods) -> list[str]:
    """The labels of the modifiers that stand in for teamwork (TEAM_MOD)."""
    return [str(m.get("label")) for m in _list(mods) if isinstance(m, dict) and TEAM_MOD.search(str(m.get("label") or ""))]


def _opp_bad(L, opp: dict | None, skill: str | None) -> str | None:
    """Why an opposition won't roll (the pool sr_lite.request_test would build for it), or None."""
    if not opp:
        return None
    try:
        o = L.require(str(opp.get("entity_id") or ""))
        if opp.get("attributes") and not opp.get("skill"):
            sr_lite.attribute_pool(L, o["id"], opp["attributes"])
        else:
            s = opp.get("skill") or "perception"
            if o["kind"] in sr_lite.MACHINES and (skill or "").lower() in sr_lite.MATRIX_SKILLS:
                s = "hacking"
            sr_lite.build_pool(L, o["id"], s, opp.get("attribute"))
    except BAD_ARGS as exc:
        return str(exc) or type(exc).__name__
    return None


def engine_roll(ctx, call: Call, args: dict | None = None, narration: str = "") -> str | None:
    """The engine rolls a call itself, through sr_lite.request_test: the leader, the helpers, their Edge as they
    called it; the GM's skill (within the call's), threshold, opposition and modifiers when it tried one - an
    opposition that had the leader as the other side is turned round - else an opposed roll against the one it's
    aimed at (OPPOSE), else the book's average 2. A call that names no skill takes it from the roll the GM gave away
    (tried, or seen: an NPC's that went through), else a task word further off in the post (hint), else the cheap
    read's (skill_read, with the narration that skipped it). If the GM's own shape won't roll (an opposition the
    engine rejects), it's rolled in the call's own shape instead - flag #50: a malformed opposition, or a called push
    at 0 Edge, made the engine give up and the skipped narration stand. Returns the card (also on ctx.cards), or None
    when there's nothing a test can roll: an attack, a spell, a Matrix beat - or a leader who can't act, or whose
    player didn't post, or a skill nobody can tell (call.why_not says which). The roll answers every other open call
    it fits too (_settle: two posts calling one pitch)."""
    g, L = ctx.game, ctx.game.ledger
    a = _dict(args or call.tried or call.seen)
    gm = _low(a.get("skill"))
    gm_attrs = [x for x in (_low(v) for v in _list(a.get("attributes"))) if x]
    if call.skill:
        skill, attrs = call.skill, None
    elif call.attributes:
        skill, attrs = None, list(call.attributes)
    elif gm and _fits(call, gm, []) and not TOOL_FOR.get(gm):
        skill, attrs = gm, None
    elif gm_attrs and family(call) is None:
        skill, attrs = None, gm_attrs
    elif not a and (call.leader or call.poster) in ctx.rolled and call.task not in SOCIAL and call.task:
        # (a guessed task off the social skills - "searches" is Perception, or the GM's Electronics was it - and the
        # leader did roll something: never pile a guess on top. A social task is no guess: "to convince her" is the
        # pitch, and live T155's narration of Vandermeer agreeing stood with only a read of her rolled - review of P3)
        call.why_not = f"the leader rolled something else, and the {sr_lite.nice(call.task)} would be a guess"
        return None
    else:
        skill, attrs = call.task or call.hint, None
    if not skill and not attrs:
        skill = skill_read(ctx, call, narration)
        if not skill:
            call.why_not = "nobody could tell which skill it is (their post names none)"
            return None
    if skill and TOOL_FOR.get(skill):
        call.why_not = f"it's {'an' if TOOL_FOR[skill][0] in 'aeiou' else 'a'} {TOOL_FOR[skill]} - the GM's to play"
        return None
    attribute = _low(a.get("attribute")) if skill and skill == gm else None
    lead = leader(L, call, skill, attribute, attrs)
    if not lead or not L.get(lead) or sr_lite.condition(L, lead) in sr_lite.OUT or _seated(ctx, call, lead):
        call.why_not = "there's nobody the engine can have roll it"
        return None                                      # (nobody to lead it the engine could pick, or can't act)
    hs = helpers_for(L, call, lead)
    helpers = [] if attrs else [{"id": h} for h in hs] + [
        dict(h, id=_ref(L, h.get("id"))) for h in _list(a.get("helpers"))
        if isinstance(h, dict) and _ref(L, h.get("id")) not in (None, lead, *hs)]
    gm_actor = _ref(L, a.get("actor_id"))
    opp, threshold = _dict(a.get("opposed_by")) or None, a.get("threshold")
    try:
        threshold = None if threshold in (None, "") else int(threshold)
    except BAD_ARGS:
        threshold = None                                 # (a '3 (hard)' the guard turned away before it was checked)
    if opp:
        o = _ref(L, opp.get("entity_id"))
        theirs = _low(opp.get("skill"))
        if o == lead:                                    # (the GM had the other side roll against the leader)
            opp = ({"entity_id": gm_actor} | ({"skill": gm} if gm else {})
                   | ({"attribute": _low(a.get("attribute"))} if _low(a.get("attribute")) else {})
                   if gm_actor and gm_actor not in call.participants() and call.against in (None, gm_actor) else None)
        elif (o and o not in call.participants() and gm_actor and gm_actor != lead
              and gm_actor not in call.participants() and theirs and _fits(call, theirs, [])
              and not (gm and _fits(call, gm, [])) and (L.get(gm_actor) or {}).get("kind") != "pc"):
            # (the GM had someone not in on it make the call's side, against its own actor - live T155's take:
            # Vandermeer weighing Brask's case. The leader makes the pitch; the GM's actor is the one resisting it)
            opp = {"entity_id": gm_actor} | ({"skill": gm} if gm else {"attributes": gm_attrs} if gm_attrs else {})
        elif o and o not in call.participants() and (o == call.against or (
                call.against is None and (L.get(o) or {}).get("kind") != "pc")):
            opp = dict(opp, entity_id=o)
        else:                                            # (never an opposition the call isn't aimed at - review of P3:
            opp = None                                   # Razor's scan came out "vs Ghost", his own teammate)
    if not opp and threshold is None and call.against and call.against != lead and (skill or "") in OPPOSE:
        o_skill, o_attr = OPPOSE[skill]
        opp = {"entity_id": call.against, "skill": o_skill, "attribute": o_attr}
    mode = _edge_mode(ctx, call, lead)
    asked = (getattr(ctx, "edge_asks", None) or {}).get(call.poster) if lead == call.poster else None
    spent = bool(asked) and not mode and _edge_spent(ctx, call.poster)
    broke = bool(asked) and not mode and not spent and asked[1] == "push"     # (a push with no point left: flag #50)
    # (never a flat teamwork modifier on top of the helpers' own rolls - decision 3's cap)
    mods = [m for m in _list(a.get("modifiers")) if isinstance(m, dict) and not team_mods([m])] or None
    # (the GM's reason only for the leader's own roll: "Joey spots Ghost slipping in" isn't why Razor scans the bar)
    reason = a.get("reason") if isinstance(a.get("reason"), str) and a.get("reason") and gm_actor == lead else \
        f"the roll {call.name}'s player called"
    own = None                                           # (why the GM's shape was dropped, for the card)
    bad = _opp_bad(L, opp, skill)
    if bad:                                              # (checked before the dice: a push spends its point first)
        own = f"its opposition: {bad}"
        opp = ({"entity_id": call.against, "skill": OPPOSE[skill][0], "attribute": OPPOSE[skill][1]}
               if call.against and call.against != lead and (skill or "") in OPPOSE else None)
        threshold = threshold if threshold is not None else (None if opp else 2)
    try:
        res = sr_lite.request_test(L, g.dice, ctx.turn_id, lead, skill, attribute, None if opp else threshold, opp,
                                   mods, reason, edge=mode, helpers=helpers, attributes=attrs, by="engine")
    except BAD_ARGS as exc:
        # The GM's opposition, modifiers or extra helpers won't roll (flag #50: an opposed_by with three attributes
        # passed the schema and failed in the pool): roll the call in its own shape - the leader, the helpers named,
        # the skill, against the one it's aimed at (the book's opposition) or the book's average 2.
        own = str(exc)
        helpers = [] if attrs else [{"id": h} for h in hs]
        opp = ({"entity_id": call.against, "skill": OPPOSE[skill][0], "attribute": OPPOSE[skill][1]}
               if call.against and call.against != lead and (skill or "") in OPPOSE else None)
        try:
            res = sr_lite.request_test(L, g.dice, ctx.turn_id, lead, skill, None, None if opp else 2, opp, None,
                                       f"the roll {call.name}'s player called", edge=mode, helpers=helpers,
                                       attributes=attrs, by="engine")
            threshold = None if opp else 2
        except BAD_ARGS as exc2:
            g.out(f"[GUARD] the engine couldn't roll {call.name}'s called roll: {exc}; {exc2}")
            call.why_not = f"the engine couldn't roll it ({exc2})"
            return None
    lines = res["card"].split("\n")
    lines.insert(1, f"  Called {call.name}'s player called it (\"{call.quoted(120)}\") - the engine rolled it")
    if spent:
        lines.insert(2, "  Edge   the Edge they called was spent on another roll this turn - not again")
    elif broke:
        lines.insert(2, "  Edge   no points left - rolled without the push they called")
    if own:
        lines.insert(2, f"  Engine the GM's version wouldn't roll ({own[:120]}) - rolled as their player called it")
    solo = bool(TEAM_WORD.search(call.words or "")) and not helpers and not attrs     # (teamwork said in the call)
    if solo:
        # (flag #38: never a teamwork call rolled solo in silence - review 2026-10-28: the GM's solo roll was filed,
        # the engine's own wasn't. Nobody on file could help: the crew the post names are players' own, unposted)
        lines.insert(2, "  Team   nobody to help - no one in the scene the engine may pick (another player's character "
                        "helps once that player posts)")
    card = "\n".join(lines)
    if solo:
        from .. import flags
        flags.record(g, "engine", "teamwork called, nobody helped", f"{call.name}'s player called teamwork "
                     f"(\"{call.quoted()}\") and the engine rolled it with nobody helping",
                     turn=getattr(ctx, "turn_id", None))
    ctx.cards.append(card)
    g.out(card)
    ctx.events.append(f"TEST {lines[0][7:]} -> {'success' if res['success'] else 'failure'} (net {res['net']:+d}"
                      f"{', glitch' if res['glitch'] else ''}) - the engine rolled the roll the player called")
    ctx.rolled.add(lead)
    if mode:
        ctx.edge_settled.add(call.poster)
    call.met = call.by_engine = True
    _settle(ctx, {"actor_id": lead, "skill": skill, "attributes": attrs or [], "helpers": helpers,
                  "opposed_by": opp or {}, "threshold": threshold}, lead)
    return card


def _settle(ctx, rolled: dict, lead: str) -> None:
    """The engine's roll answers every open call it fits, as the GM's own roll does (check). Review of P3: two posts
    calling one pitch - the engine's roll met only the first, so the GM was sent back for the other and rolled the
    pitch a second time (or the backstop did, and flagged the second as never made)."""
    for c in getattr(ctx, "calls", None) or []:
        if not c.met and not c.given_up:
            v = _verdict(ctx, c, "request_test", rolled, [lead])
            if v and v[0] == "meets":
                c.met = c.by_engine = True


def tell_table(ctx, call: Call, why: str) -> None:
    """The table hears a called roll wasn't made - never a narration that skipped it, committed in silence (review of
    flag #51: the only trace was a developer flag). A [CALL] line is a notice the channel shows."""
    ctx.game.out(f"[CALL] The roll {call.name}'s player called (\"{call.quoted(100)}\") wasn't made - {why}. "
                 "Say the skill and post again, or !undo.")


def _give_up(ctx, call: Call, why: str) -> None:
    """A call the engine can't roll for the GM: let it go, tell the table, and file it (flags: 'called roll never
    made')."""
    from .. import flags
    call.given_up = True
    ctx.game.out(f"[GUARD] {call.name}'s called roll - {why}; letting it go")
    tell_table(ctx, call, call.why_not or why)
    flags.record(ctx.game, "engine", "called roll never made", f"{call.name}'s player called a roll and {why}: "
                 f"\"{call.quoted()}\"", turn=getattr(ctx, "turn_id", None))


def backstop(ctx, due: list[Call], narration: str = "") -> list[str]:
    """After the send-backs: the engine rolls every owed call it can - one an earlier engine roll here already answered
    is skipped. One it can't (an attack, a spell, a Matrix beat - or a skill nobody can tell) is given up on: the
    table is told it wasn't made (tell_table), and turn._dm_loop flags it. narration: what the GM wrote past it - the
    skill read's context."""
    cards = []
    for c in due:
        if c.met:
            continue
        card = engine_roll(ctx, c, narration=narration)
        if card:
            cards.append(card)
        else:
            c.given_up = True
            tell_table(ctx, c, c.why_not or "the engine can't roll that one itself")
    return cards


def rollable(call: Call) -> str:
    """Whether the engine could roll the call itself if the GM won't - 'yes', 'maybe' (no skill said: only if the
    read can tell it) or 'no' (an attack, a spell, a Matrix beat) - so a send-back never promises what it can't do
    (review of flag #51: "Narrate past it once more and the engine rolls it itself", and then it didn't)."""
    s = call.skill or call.task or call.hint or _low(_dict(call.tried or call.seen).get("skill"))
    if s and TOOL_FOR.get(s):
        return "no"
    return "yes" if s or call.attributes or _dict(call.tried or call.seen).get("attributes") else "maybe"


def lines(ctx) -> str:
    """The turn message's CALLED ROLLS section: each call as the engine reads it, so the first roll is the right one."""
    L = ctx.game.ledger
    rows = []
    for c in getattr(ctx, "calls", None) or []:
        bits = []
        group = _group(c)
        if c.leader:
            bits.append(f"{_nm(L, c.leader)} [{c.leader}] leads (they named them)")
        elif c.poster in c.helpers and len(c.among) < 2:
            bits.append(f"whoever {c.name} helps rolls (they didn't say who)")
        elif len(group) >= 2:
            lead = leader(L, c, c.skill or c.task)
            bits.append(f"nobody named to lead: the highest pool of {_and([f'{_nm(L, x)} [{x}]' for x in group])} "
                        "for the skill you roll leads, the others help"
                        + (f" ({_nm(L, lead)} [{lead}] for {sr_lite.nice(c.skill or c.task)})"
                           if lead and (c.skill or c.task) else ""))
        else:
            bits.append(f"{c.name} [{c.poster}] rolls")
        hs = [h for h in c.helpers if h != c.leader and (c.leader or len(group) < 2)]
        if hs:
            bits.append(_and([f"{_nm(L, h)} [{h}]" for h in hs]) + (" helps" if len(hs) == 1 else " help")
                        + (" (their post has them pitching in - teamwork)" if c.picked else ""))
        elif c.teamwork and len(group) < 2:
            bits.append("teamwork - name whoever pitches in as helpers")
        if c.skill:
            bits.append(f"{sr_lite.nice(c.skill)} (they named it)")
        elif c.attributes:
            bits.append(" + ".join(x.title() for x in c.attributes) + " (they named it)")
        elif c.task:
            bits.append(("a social skill" if c.task in SOCIAL else sr_lite.nice(c.task))
                        + f" for what they're doing ({sr_lite.nice(c.task)} fits)")
        if c.against:
            bits.append(f"aimed at {_nm(L, c.against)} [{c.against}]")
        mode = _edge_mode(ctx, c, leader(L, c, c.skill or c.task))
        if mode:
            bits.append(f"Edge: {mode}")
        if TOOL_FOR.get(c.skill or c.task or "") == "matrix":
            bits.append("a Matrix beat" + _matrix_hint(ctx, leader(L, c, c.skill or c.task)))
        seated = _seated(ctx, c, c.leader)
        if seated:
            bits.append(f"{_nm(L, c.leader)}'s own player hasn't posted, so it isn't owed - their choice, not yours")
        can = rollable(c)
        if c.owed and not seated and can != "yes":
            bits.append("the engine can't roll this one for you - make it" if can == "no" else
                        "no skill said: pick the one that fits - the engine can roll it only if it can tell which")
        rows.append(f"- {c.name}'s player{'' if c.owed and not seated else ' (if you roll it)'}: " + " · ".join(bits)
                    + f' - "{c.quoted(160)}"')
    if not rows:
        return ""
    return ("CALLED ROLLS (binding - the engine checks your roll against each before the dice: one that gives it to "
            "someone else, the wrong skill or drops a helper they named is turned away; narrate past one and you're "
            "sent back; in the end the engine rolls it itself):\n" + "\n".join(rows) + "\n")
