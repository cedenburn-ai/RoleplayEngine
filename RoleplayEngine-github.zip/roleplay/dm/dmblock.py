"""The <dm> block: notes and facts appended to the final narration instead of an extra tool round trip.

    <dm>
    note kaz, sgt-danjuma: Kaz will sell the 520 info if the bar takes damage.
    fact tanaka: Tanaka agreed to pay 14,000 nuyen for the chip.
    fact kaz, razor (replaces F2): Kaz and Razor are square now.
    agenda kaz: find out who has been asking Lone Star about the bar.
    landed H3: the hired crew caught up with Razor outside the noodle bar.
    time: evening              (or later, tonight, tomorrow morning, day 3 night, 3 days later, evening, 6 months
                                later - moves the story clock; a line it can't read is shown at the table's next turn)
    karma razor, ghost: +3 pulled off the extraction clean
    ruling: Grenades bounced down a stairwell count as near for everyone on the next landing.
    ruling R3: (revises R3)
    ruled: Granted, once - everyone's Edge is back to full for the run on Kessler.   (a player's !ruling request)
    name ration-man: Pruett   (the story revealed their name: on file as Pruett, the old name kept as an alias)
    flag: The cast tool said Magic doesn't know Stunbolt, but it's on his sheet.   (for the developers, never shown)
    fix filament: overwatch 0 - the T45 dive was retconned   (the numbers, set right; the table sees it - see correct)
    clarify dutch: Trusts Rage again since she burned her copy; owes her 4,000 by noon Day 3; still won't name the buyer.
    tension dutch, rage: Will Dutch pay the 4,000? | stakes 1 | due day 3 12:00 | next: he calls after the dawn meet | public: Dutch owes you 4,000 by noon
    tension Q3: the buyer moved the meet to 05:00 | next: Dutch goes quiet
    tension Q3: due off        (the deadline lifted, the question kept - or `fix Q3: due off - why`, which the table sees)
    resolve Q3: Dutch paid in full at 11:40.
    shelve Q2: the table walked away from the GLASSWING thread
    doubt C35, juno, liesl-kovacs: C35 calls Liesl's daughter Juno - Juno is Bo's mother, an ork in her twenties
    doubt X3, T52: T52's narration names the daughter too   (more on an open doubt: X3 stays open, T52 joins it)
    resolve X3: Liesl's daughter is unnamed; "Juno" in C35 was a slip   (+ the fix lines: clarify liesl-kovacs: ...)
    dismiss X4: not a contradiction - Bo has two inhalers, one at the clinic
    ooc                        (a whispered rules question: answered, then taken back out of the story)
    </dm>

Ids are the [id]s from the packet, comma-separated. Spaces and `Name [id]` are read too (resolve_ids), but a name is
never split into its words, and a line naming no one on file (or in no line's form at all) is kept on ctx.unplaced -
never quietly reported done.
"""
from __future__ import annotations

import json
import re

from .. import rulings
from ..engine import clock
from ..engine.ledger import LedgerError, RulesRefusal
from ..engine.rules import sr_lite
from ..substrate.store import norm_id
from . import doubts, spoilers, tensions, world

BLOCK = re.compile(r"<dm>(.*?)(?:</dm>|$)", re.DOTALL | re.IGNORECASE)
LINE = re.compile(r"^\s*[-*]?\s*(note|fact|agenda|landed|karma|clarify|tension|resolve|shelve|doubt|dismiss|zone|ambush)\s+([^:]+?)\s*(?:\(\s*replaces\s+([A-Za-z]\d+)\s*\))?\s*:\s*(.+)$",
                  re.IGNORECASE)
RULING = re.compile(r"^\s*[-*]?\s*ruling\s*(R\d+)?\s*:\s*(.+?)\s*$", re.IGNORECASE)
FLAG = re.compile(r"^\s*[-*]?\s*flag\s*:\s*(.+?)\s*$", re.IGNORECASE)   # the engine got something wrong
# (the why's dash may be an en or em dash - review of flag #42: "fix Q1: due off — R11 locks the timeline" was unplaced)
FIX = re.compile(r"^\s*[-*]?\s*fix\s+([^:]+?)\s*:\s*(jack[ _]out|\w+)(?:\s+(?![-–—])(\S+))?(?:\s*[-–—(]+\s*(.*?)\)?)?\s*$",
                 re.IGNORECASE)                                            # fix <id>: <what> [value] - why
NARRATIVE = re.compile(r"^\s*[-*]?\s*narrative\s+(D\s*\d+|\d+)\s*:\s*(.+?)\s*$", re.IGNORECASE)   # a direction landed
NAME = re.compile(r"^\s*[-*]?\s*name\s+([^:]+?)\s*:\s*(.+?)\s*$", re.IGNORECASE)   # a name revealed ([id] or name too)
RULED = re.compile(r"^\s*[-*]?\s*ruled\s*:\s*(.+?)\s*$", re.IGNORECASE)   # the GM's answer to a !ruling request
TIME = re.compile(r"^\s*[-*]?\s*(?:time|clock)\s*:\s*(.+?)\s*$", re.IGNORECASE)
BATTLE = re.compile(r"^\s*[-*]?\s*battle\s*(end)?\s*:\s*(.+?)\s*$", re.IGNORECASE)   # zones, or how it ended
OOC = re.compile(r"^\s*[-*]?\s*ooc\b", re.IGNORECASE)          # a whispered rules question: not a story beat
BARE_TENSION = re.compile(r"^\s*[-*]?\s*tension\s*:\s*(.+?)\s*$", re.IGNORECASE)   # a tension about no one in particular
BARE_DOUBT = re.compile(r"^\s*[-*]?\s*doubt\s*:\s*(.+?)\s*$", re.IGNORECASE)       # a doubt with no ids (still kept)
CLOCK_MISS = clock.MISS             # meta: {turn, text, clock} of a time: line the clock couldn't read
# Lines that can wait for the memory pass: a note on someone this very turn introduces lands once commit has put them
# on file (live T8: the GM's note on Liesl Kovacs was dropped, and commit created her a moment later).
LATE = ("note", "fact", "agenda", "clarify", "karma", "landed", "doubt")
UNREAD = "unread"                   # a line in the block that's no line at all ("note: ...", a dash for the colon)
# The LATE lines the table could read anyway: a held one keeps its words in ENGINE EVENTS (a fact the pass mustn't
# extract again, karma's card). The rest - a note, a picture, a goal, a hook landing, a doubt - are the GM's own.
PUBLIC_LATE = ("fact", "karma")
# Who writes to the record between turns (TurnContext.by): their lines land on the last turn's number, but nobody at
# that turn saw them written. Review (2026-10-26): the canon's fix "Razor holds Kaz's maglock keycard (lifted T4)" -
# T4 a whisper - reached whoever was at the last public turn, as their own memory (!askdm, witness.Scope).
BETWEEN_TURNS = ("canon", "aside")


class GmOnly(str):
    """An ENGINE EVENTS line whose words are the GM's alone - a goal, a doubt, a tension, a hook landing, a line
    waiting: as written, for the record and the log, with `public` (its kind and ids) for the memory pass, which writes
    the public summary (for_memory). Review 2026-10-28 (the first seed's rehearsal): a waiting note's words reached the
    pass, and its summary named a sealed NPC by his GM-only name."""
    public: str


def gm_only(line: str, public: str) -> str:
    s = GmOnly(line)
    s.public = public
    return s


def for_memory(game, events: list[str]) -> str:
    """ENGINE EVENTS as the memory pass reads them: a GM-only line by its kind and ids, the rest whole - and every line
    in the names the crew knows (spoilers.scrub: a card can quote the GM too)."""
    return "\n".join(spoilers.scrub(game, getattr(e, "public", e))[0] for e in events)


def _on(game, raw_ids) -> str:
    """A line's ids as the memory pass may see them: what's on file by its id - someone with a GM-only name by what
    the crew calls them - and the rest only counted (a name not on file yet may be the GM's alone)."""
    found, unknown = resolve_ids(game, ", ".join(raw_ids))
    secret = {s.id for s in spoilers.guard(game).secrets}
    shown = [game.ledger.get(x)["name"] if x in secret and game.ledger.get(x) else x for x in found]
    if unknown:
        shown.append(f"{len(unknown)} not on file yet")
    return ", ".join(shown)


def between_turns(conn) -> set[str]:
    """The facts the canon read-back or an aside wrote between turns (logged by apply): set down in front of no one,
    so a character knows one only through the moment it names (witness.Scope)."""
    return {r[0] for r in conn.execute(
        f"SELECT json_extract(payload, '$.fact') FROM events WHERE kind='fact' AND json_extract(payload, '$.by') IN "
        f"({','.join('?' * len(BETWEEN_TURNS))})", BETWEEN_TURNS)}


def _entry(line: str) -> dict | None:
    """One line of the block -> its entry, or None."""
    rm = RULING.match(line)
    if rm:
        return {"kind": "ruling", "ids": [], "replaces": rm.group(1), "text": rm.group(2)}
    fx = FIX.match(line)
    if fx:
        return {"kind": "fix", "ids": [fx.group(1)], "replaces": None, "text": fx.group(4) or "",
                "what": fx.group(2), "value": fx.group(3)}
    nv = NARRATIVE.match(line)
    if nv:
        return {"kind": "narrative", "ids": [nv.group(1)], "replaces": None, "text": nv.group(2)}
    fl = FLAG.match(line)
    if fl:
        return {"kind": "flag", "ids": [], "replaces": None, "text": fl.group(1)}
    nm = NAME.match(line)
    if nm:
        return {"kind": "name", "ids": [nm.group(1)], "replaces": None, "text": nm.group(2)}
    rd = RULED.match(line)
    if rd:
        return {"kind": "ruled", "ids": [], "replaces": None, "text": rd.group(1)}
    tm = TIME.match(line)
    if tm:
        return {"kind": "time", "ids": [], "replaces": None, "text": tm.group(1)}
    bt = BATTLE.match(line)
    if bt:
        return {"kind": "battle_end" if bt.group(1) else "battle", "ids": [], "replaces": None, "text": bt.group(2)}
    if OOC.match(line):
        return {"kind": "ooc", "ids": [], "replaces": None, "text": ""}
    bm = BARE_TENSION.match(line)
    if bm:
        return {"kind": "tension", "ids": [], "replaces": None, "text": bm.group(1)}
    bd = BARE_DOUBT.match(line)
    if bd:
        return {"kind": "doubt", "ids": [], "replaces": None, "text": bd.group(1)}
    lm = LINE.match(line)
    if lm:
        kind, ids, replaces, text = lm.groups()
        return {"kind": kind.lower(), "ids": [i.strip() for i in ids.split(",") if i.strip()],
                "replaces": replaces, "text": text.strip()}
    return None


def split(narration: str) -> tuple[str, list[dict]]:
    """Return (narration without the block, parsed entries). Each entry keeps its source `line`, so a line the
    record couldn't take can be shown as written. A line in no form we know (`note: ...` with no ids, a dash where
    the colon goes) comes back as UNREAD, for apply to report - it used to vanish here, so a canon fix written
    `note kaz - alive after all` was lost without a word and the next pass read the conflict as resolved (T181)."""
    entries = []
    for m in BLOCK.finditer(narration):
        for line in m.group(1).splitlines():
            e = _entry(line)
            if e is None and re.search(r"\w", line):              # (blank lines and fences aren't lines)
                e = {"kind": UNREAD, "ids": [], "replaces": None, "text": line.strip()}
            if e:
                e["line"] = line.strip()
                entries.append(e)
    clean = BLOCK.sub("", narration).rstrip()
    return clean, entries


# ── who a line is about ─────────────────────────────────────────────────
BRACKET = re.compile(r"([^\[\]]*)\[([^\[\]]+)\]")     # "Name [id]": the bracket is the id, the name just its label
JOINERS = {"and", "&", "+", "/", "with"}
NODE_ID = re.compile(r"^[A-Z]\d+$")


def _one(game, ref: str) -> str | None:
    """A whole ref -> its id: a node (T165, Q3, H5, F2, N40) or an entity by id, name or alias. As written first,
    then without a trailing '.': 'Sergeant P.' is a name on file (live), 'filament.' a slip."""
    L, S = game.ledger, game.sub
    ref = ref.strip().strip("[]").strip()
    for r in dict.fromkeys((ref, ref.rstrip(". ").strip())):
        if not r:
            continue
        nid = norm_id(r)
        if S.exists(nid) and not L.get(nid):
            return nid
        ent = L.find(r)
        if ent:
            return ent["id"]
    return None


def _word(game, w: str) -> str | None:
    """One word of a space-separated list: an exact id on file (case and all) or a node id - never a name, whose
    words can be other people (live: 'anton' beside 'Anton Salgado', 'crows' beside 'Crows Biker Fenn')."""
    w = w.strip().strip("[]").rstrip(".")
    if not w:
        return None
    if game.ledger.get(w):
        return w
    nid = norm_id(w)
    return nid if NODE_ID.match(nid) and game.sub.exists(nid) else None


def _chunk(game, text: str) -> tuple[list[str], list[str]]:
    """One comma-separated piece: whole first (an id, a name like 'Quiet Lou' or 'Dr. A. Brask', an alias), else
    word by word - but only exact ids ('quiet-lou filament', 'Q3 Q4'). Anything else: the whole piece is unknown."""
    words = text.split()
    while words and words[-1].lower() in JOINERS:          # ('Quiet Lou and' - what's left before 'Razor [razor]')
        words.pop()
    while words and words[0].lower() in JOINERS:
        words.pop(0)
    text = " ".join(words)
    if not text:
        return [], []
    x = _one(game, text)
    if x:
        return [x], []
    words = [w for w in text.split() if w.lower() not in JOINERS]
    got = [_word(game, w) for w in words]
    return (got, []) if words and all(got) else ([], [text])


def resolve_ids(game, raw: str) -> tuple[list[str], list[str]]:
    """The ids before a <dm> line's colon -> (ids on file, the parts that match no one). Commas and semicolons
    separate; a `Name [id]` pair counts by its bracket; a piece is read whole before it's read word by word, so a
    name is never split into other people. Live T181/T188: the canon pass wrote `note quiet-lou filament: ...` and
    `note pastor-garvey crows-biker-fenn: ...` - read as one name nobody had, and both fixes were lost."""
    raw = (raw or "").strip()
    whole = _one(game, raw)                    # (a name with a comma in it: 'Vandermeer Lab, UW HMHVV Variants Unit')
    if whole:
        return [whole], []
    found, unknown = [], []
    for chunk in re.split(r"[,;]", raw):
        ids, miss = [], []
        pairs = BRACKET.findall(chunk)
        for label, tag in pairs:
            x = _one(game, tag)
            if x:
                more, left = _chunk(game, _label_rest(game, label, x))   # ('T165 Quiet Lou [quiet-lou]': T165 too)
                ids += more + [x]
                miss += left
                continue
            x = _one(game, label) if label.strip() else None              # (a slip in the bracket, the name right)
            if x:
                ids.append(x)
            else:
                miss.append(f"{label.strip()} [{tag.strip()}]" if label.strip() else tag.strip())
        more, left = _chunk(game, BRACKET.sub(" ", chunk) if pairs else chunk)   # (what follows the last bracket)
        for x in ids + more:
            if x not in found:
                found.append(x)
        unknown += miss + left
    return found, unknown


def _label_rest(game, label: str, x: str) -> str:
    """What a bracket's label holds besides x's own name: '' for 'Quiet Lou [quiet-lou]' or 'Lou [quiet-lou]',
    'T165' for 'T165 Quiet Lou [quiet-lou]', and the whole label when it isn't x's name at all ('kaz [razor]').
    The rest is read on, so ids written in front of a pair land and words that match no one are reported - before,
    everything ahead of a bracket that resolved was dropped without a word."""
    label = label.strip()
    if not label or _one(game, label) == x:
        return ""
    ent = game.ledger.get(x) or {}
    names = {n.strip().lower() for n in [x, ent.get("name"), *(ent.get("aliases") or [])] if n and n.strip()}
    own = {w.strip(".'\"") for n in names for w in n.split()}
    low = label.lower()
    if all(w.strip(".'\"") in own for w in low.split()):  # the name or part of it ('Lou', 'Liesl' for Liesl Kovacs)
        return ""
    for name in sorted(names, key=len, reverse=True):
        if low.endswith(" " + name):                       # something in front of the name
            return label[:len(label) - len(name)].strip()
    return label


def _miss(ctx, e: dict, why: str) -> None:
    """A line the record couldn't take: logged, and kept on ctx.unplaced so nobody reports it as done."""
    ctx.unplaced.append(e)
    ctx.game.out(f"  (dm block: {why})")


def _held(ctx, e: dict) -> None:
    """A LATE line waiting for the memory pass (quiet). The pass still reads it in ENGINE EVENTS: before it waited,
    the GM's fact was there and in FACTS ALREADY KNOWN, so the pass didn't extract it a second time (store.add_fact
    keeps both copies). Only a public line's words, though (PUBLIC_LATE): a note, a picture, a goal, a hook landing or
    a doubt says only that a GM-only line waits - review 2026-10-28: a note waiting on a tension's Q# and a name not
    on file put its GM-only words in the pass's prompt, and the public summary named a sealed NPC by them. Nor a fact
    that says a GM-only name: it's filed as a GM note when it lands (apply), so its words are the GM's too - scrubbed,
    its plot still reached the pass (review of the fix)."""
    ctx.held.append(e)
    on, kind = _on(ctx.game, e["ids"]) or "no one on file yet", e["kind"].upper()
    if e["kind"] in PUBLIC_LATE and not spoilers.hits(ctx.game, e["text"]):
        ctx.events.append(f"{kind} on {on} (the GM's own, recorded once this pass is done - not one to extract again): "
                          f"{spoilers.scrub(ctx.game, e['text'])[0]}")
        return
    ctx.events.append(gm_only(f"{kind} on {', '.join(e['ids'])} (waiting for the memory pass): {e['text']}",
                              f"{kind} on {on}: a GM-only line, recorded once this pass is done - not one to "
                              "extract again"))


def apply(ctx, entries: list[dict], quiet: bool = False) -> list[str]:
    """Record the entries through the same paths as the tools. A line that can't be placed is skipped, never fatal,
    and lands on ctx.unplaced. `quiet` is the turn's first pass, before the memory pass: a LATE line naming anyone
    not on file yet waits on ctx.held, unlogged, for the retry after commit (turn.run_turn)."""
    g, L, S, t = ctx.game, ctx.game.ledger, ctx.game.sub, ctx.turn_id
    made, settles, held = [], [], len(ctx.held)
    # (a `name` line first: a fact beside it may say the name it reveals - once it's on file, and only then. Review
    # 2026-10-28: a name line that landed nowhere still let its name into a public fact)
    entries = [e for e in entries if e["kind"] == "name"] + [e for e in entries if e["kind"] != "name"]
    for e in entries:
        if e["kind"] == UNREAD:
            _miss(ctx, e, f"can't read '{e['line']}' - not recorded (a line is `note <id>, <id>: ...`)")
            continue
        if e["kind"] == "ruling":
            if e["replaces"] and e["text"].strip(" .").lower() in ("drop", "retire", "retired", "remove", "gone"):
                try:                                       # `ruling R9: drop` - one that's no longer needed
                    r = rulings.retire(g, e["replaces"], "dropped", "gm")
                except Exception as exc:
                    _miss(ctx, e, f"ruling not dropped - {exc}")
                    continue
                line = f"[RULING] {r['id']} dropped - it's no longer needed"
                ctx.cards.append(line)
                g.out(line)
                ctx.events.append(line)
                continue
            try:
                r = rulings.add(g, e["text"], "gm", e["replaces"])
            except Exception as exc:                       # (full, or a bad id): tell the log, keep going
                _miss(ctx, e, f"ruling not recorded - {exc}")
                continue
            line = (f"[RULING] {r['id']}" + (f" (revises {r['replaces']})" if r["replaces"] else "")
                    + f": {r['text']}  - `!ruling veto {r['id']}` to object")
            ctx.cards.append(line)
            g.out(line)
            ctx.events.append(line)
            continue
        if e["kind"] == "fix":                            # the numbers set right - the table sees it
            from . import corrections
            targets, _ = resolve_ids(g, e["ids"][0])       # (`fix [filament]: ...`, `fix Quiet Lou: ...`)
            from .. import jobs
            if not targets and jobs.get(g, e["ids"][0]):    # (a job's J# is no node or entity: `fix J2: due off`)
                targets = [e["ids"][0].strip().upper()]
            if not targets:
                _miss(ctx, e, f"no one on file is '{e['ids'][0]}' - fix not made")
                continue
            done = 0
            for x in targets:
                try:
                    line = corrections.correct(g, t, x, e["what"], e["value"],
                                               e["text"] or "the GM set the record straight")
                except LedgerError as exc:
                    g.out(f"  (dm block: fix not made - {exc})")
                    continue
                done += 1
                ctx.cards.append(line)
                g.out(line)
                ctx.events.append(line)
            if not done:
                ctx.unplaced.append(e)
            continue
        if e["kind"] == "narrative":                      # a table direction has landed - the table sees it go
            from .. import narrative
            if e["text"].strip(" .!").lower() not in ("done", "landed", "complete", "completed", "fulfilled"):
                continue                                   # (only the table writes directions)
            try:
                r = narrative.close(g, e["ids"][0], "done", "gm")
            except LedgerError as exc:
                _miss(ctx, e, str(exc))
                continue
            line = f"[STORY] {r['id']} done: {r['text']}  - `!narrative add` it again if it hasn't landed"
            ctx.cards.append(line)
            g.out(line)
            ctx.events.append(line)
            continue
        if e["kind"] == "flag":                           # for the developers - the table never sees it
            from .. import flags
            flags.record(g, "gm", "gm flag", e["text"], turn=t, context={"scene": ctx.scene_id})
            continue
        if e["kind"] == "name":
            from . import speakers
            who = [x for x in resolve_ids(g, e["ids"][0])[0] if L.get(x)]   # (`name [id]: ...`, `name Quiet Lou: ...`)
            if len(who) != 1:                             # (the ref may be the hidden name itself: never logged so)
                _miss(ctx, e, f"name not changed - '{spoilers.scrub(g, e['ids'][0])[0]}' is "
                      + ("no one on file" if not who else "more than one person"))
                continue
            why = spoilers.bad_name(g, who[0], e["text"], between=ctx.by in BETWEEN_TURNS)
            if why:                                       # (a wrong id would hand someone else's name over for good)
                from .. import flags
                flags.record(g, "engine", "spoiler", f"A name line from {doubts.NAMED.get(ctx.by, ctx.by)} on "
                              f"{L.get(who[0])['name']} [{who[0]}] wasn't taken: {why}", turn=t)
                _miss(ctx, e, f"name not changed for {L.get(who[0])['name']} [{who[0]}] - {why}")
                continue
            try:
                line = "[NAME] " + speakers.rename(g, who[0], e["text"], t)
            except Exception as exc:
                _miss(ctx, e, f"name not changed - {exc}")
                continue
            ctx.cards.append(line)
            g.out(line)
            ctx.events.append(line[7:])
            continue
        if e["kind"] == "ruled":                           # out of character, on its own line - not the story's
            line = f"[GM RULING] {e['text']}"
            ctx.cards.append(line)
            g.out(line)
            continue
        if e["kind"] == "ooc":
            ctx.ooc = True
            continue
        if e["kind"] in ("battle", "battle_end") and not ctx.private:
            from .. import encounters
            if e["kind"] == "battle_end":
                try:
                    encounters.request_end(g, e["text"])
                except RulesRefusal as exc:                # "not yet - fight continues" (live T174): it goes on
                    ctx.events.append(f"FIGHT GOES ON (`battle end: {e['text']}` - {exc})")
                    g.out(f"  (dm block: battle end not taken - {exc})")
                continue
            zones = []
            for part in e["text"].split("|"):
                m = re.match(r"\s*(.+?)\s*(?:\((none|light|hard)[^)]*\))?\s*$", part, re.IGNORECASE)
                if m and m.group(1):
                    zones.append({"name": m.group(1), "cover": (m.group(2) or "none").lower()})
            enc = encounters.active(g)
            if enc:
                encounters.set_zones(enc, zones)
                encounters.save(g, enc)
            else:
                _, card = encounters.start(g, t, zones, reason="battle line")
                if card:
                    ctx.cards.append(card)
                    g.out(card)
            continue
        if e["kind"] == "time":
            try:
                g.set_clock(clock.parse(e["text"], g.clock()))     # (a line that reads clears the miss)
            except ValueError as exc:
                # live T162: "3 days later, evening" went to the log alone, and the GM narrated on from a clock three
                # days behind. The table's next packet tells it (packet.py) - while the clock still stands here.
                L.set_meta(CLOCK_MISS, json.dumps({"turn": t, "text": e["text"], "clock": g.clock()}))
                _miss(ctx, e, str(exc))
                continue
            ctx.clock_set = True
            ctx.events.append(f"TIME set to {g.clock_line()}")
            continue
        targets, unknown = resolve_ids(g, ", ".join(e["ids"]))
        if quiet and unknown and e["kind"] in LATE:
            _held(ctx, e)                                 # (maybe someone this turn introduces: after commit, again)
            continue
        for x in targets:
            ent = L.get(x)
            if ent:
                S.ensure_entity(ent, t)
        if targets and unknown:
            g.out(f"  (dm block: no one on file is {', '.join(repr(u) for u in unknown)} - "
                  f"'{e['kind']}' went on {', '.join(targets)})")
        # resolve is a prefix's: X# a doubt, Q# a tension (`resolve Q3, X5: ...` settles both). A doubt is settled
        # once the rest of the block is in (_settle, below): the fix lines beside it are what make it true.
        xs = [x for x in targets if doubts.is_doubt(g, x)]
        if e["kind"] == "doubt":
            made += _doubt(ctx, e, targets, unknown)
            continue
        if e["kind"] == "dismiss" or (e["kind"] == "resolve" and xs):
            if xs:
                settles.append((e, xs))
            else:
                _miss(ctx, e, "dismiss needs a doubt id like X3 - skipped")
            targets = [x for x in targets if x not in xs]
            if e["kind"] != "resolve" or not targets:
                continue
        if e["kind"] in ("tension", "resolve", "shelve"):
            made += _tension(ctx, e, targets)
            continue
        if not targets:
            _miss(ctx, e, f"no known ids in '{', '.join(e['ids'])}' - skipped")
            continue
        if e["kind"] in ("zone", "ambush") and not ctx.private:
            from .. import encounters
            if e["kind"] == "ambush":
                on = encounters.active(g)                  # (mid-fight, the ambushers join it: §6a)
                card = (encounters.join(g, t, on, ambushers=targets) if on
                        else encounters.start(g, t, ambushers=targets, reason=e["text"])[1])
                if card:
                    ctx.cards.append(card)
                    g.out(card)
                continue
            enc = encounters.active(g)
            if enc:
                for x in targets:
                    encounters.move(enc, x, e["text"])
                encounters.save(g, enc)
            continue
        if e["kind"] == "clarify" and len(targets) > 1:
            e = {**e, "kind": "note"}                     # one whole picture can't be two people's: a note on each
        if e["kind"] == "clarify":
            cid = S.clarify(targets[0], e["text"], t, by="dm")
            ctx.events.append(f"CLARIFY {cid} on {targets[0]}")
            made.append(cid)
            continue
        if e["kind"] == "karma":
            m = re.match(r"\s*([+-]?\d+)\s*(.*)", e["text"])
            pcs = [pc for pc in targets if (L.get(pc) or {}).get("kind") == "pc"]
            if not m or not pcs:      # ("three for the clean extraction", karma for an NPC): nothing moved, so an
                why = "write the amount in digits (`karma <id>: +3 why`)" if not m else "only player characters earn it"
                _miss(ctx, e, f"no karma awarded - {why}")             # aside mustn't call it fixed
                continue
            for pc in pcs:
                line = sr_lite.award_karma(L, t, pc, int(m.group(1)), m.group(2).strip(" -:"))
                ctx.cards.append(line)
                g.out(line)
                ctx.events.append(line)
            continue
        if e["kind"] == "landed":
            for h in targets:
                if world.land_hook(g, h, t, e["text"]):
                    ctx.events.append(gm_only(f"HOOK LANDED {h}: {e['text']}", f"HOOK LANDED {h} (GM-only)"))
                    made.append(h.upper())
            continue
        if e["kind"] == "agenda":
            for npc in targets:
                if (L.get(npc) or {}).get("kind") in world.ACTORS:
                    aid = world.add_agenda(g, npc, e["text"], [], t, by="dm", due_in=10)
                    ctx.events.append(gm_only(f"AGENDA {aid} for {npc}: {e['text']}",
                                              f"AGENDA {aid} for {_on(g, [npc])} (GM-only)"))
                    made.append(aid)
            continue
        if e["kind"] == "note":
            nid = S.add_note(targets, e["text"], t)
            ctx.events.append(f"NOTE {nid} on {targets}")
            made.append(nid)
        else:
            slip = spoilers.hits(g, e["text"])
            if slip:                                   # a public fact can't say a name the table hasn't learned
                nid = S.add_note(targets, f"(Kept GM-only: a public fact can't say a name the table hasn't "
                                          f"learned.) {e['text']}", t)
                ctx.events.append(gm_only(f"NOTE {nid} on {targets} (a fact kept GM-only): {e['text']}",
                                          f"NOTE {nid} on {_on(g, targets)} (GM-only)"))
                spoilers.flag(g, "spoiler", f"A fact line from {doubts.NAMED.get(ctx.by, ctx.by)}", slip, t,
                              "kept as a GM note, not a public fact")
                g.out(f"  (dm block: a fact said a GM-only name ({spoilers.who(g, slip)}) - kept as a GM note)")
                made.append(nid)
                continue
            # A T#/W# among its ids is the moment it came out of (linked `about`, as the memory pass links its own):
            # who was there is who knows it - the canon's "fact razor, kaz, T4: ..." stays with T4's witnesses.
            moments = [x for x in targets if not L.get(x) and (S.node(x) or {}).get("kind") == "slice"]
            fid = S.add_fact(e["text"], [x for x in targets if L.get(x)] + moments, t, replaces=e["replaces"],
                             confidence=0.9, by="dm")
            if moments and all(S.node(m)["visibility"] == "private" for m in moments):
                S.set_visibility(fid, "private")          # (out of a whisper: the whisper's, as the memory pass marks
                #                                            its own - no recap, rumor or picture repeats it)
            if ctx.by in BETWEEN_TURNS:
                L.log(t, "fact", None, {"fact": fid, "by": ctx.by})
            ctx.expanded.add(fid)
            ctx.events.append(f"FACT {fid}: {e['text']}")
            made.append(fid)
    if settles:
        lost = [x["line"] for x in entries if x["kind"] in FIXING and any(x is u for u in ctx.unplaced)]
        if quiet and len(ctx.held) > held:            # (a line waits for the memory pass: the settle waits with it)
            for e, _ in settles:
                e["lost"] = e.get("lost", []) + lost
                ctx.held.append(e)
        else:
            made += _settle(ctx, settles, lost)
    return made


SETTLED = {"resolve": "resolved", "dismiss": "dismissed"}
FIXING = ("fact", "note", "clarify", UNREAD)   # the lines that set the record right - what a resolve beside them needs


def _settle(ctx, settles: list[tuple[dict, list[str]]], lost: list[str]) -> list[str]:
    """`resolve X3: what's true` / `dismiss X3: why`, once every other line of the block is in. A resolve beside a fix
    line that didn't land - naming no one on file, in no line's form - leaves the doubt open, with a note saying why,
    as the doubt tool and the canon do: the record still says otherwise. Review (2026-10-26): `resolve X1` beside
    `fact kaz-the-barman (replaces F2): ...` closed X1 while F2 stood, and the only trace was a log line. One that
    changes nothing (already settled) is unplaced: an aside mustn't tell the table it fixed anything."""
    g, t = ctx.game, ctx.turn_id
    done = []
    for e, xs in settles:
        how = SETTLED[e["kind"]]
        gone = lost + e.get("lost", [])
        if e["kind"] == "resolve" and gone:
            still = [x for x in xs if (doubts.get(g, x) or {}).get("status") == "open"]
            for x in still:
                doubts.work(g, x, f"Not resolved: its answer ({e['text']}) came with fix lines that didn't land - "
                                  f"{' | '.join(gone)}", t, by=ctx.by)
            _miss(ctx, e, f"{', '.join(still or xs)} left open - the fix lines beside '{e['line']}' didn't land: "
                          f"{' | '.join(gone)}")
            continue
        changed = [x for x in xs if doubts.settle(g, x, t, e["text"], how, ctx.by)]
        for x in changed:
            ctx.events.append(gm_only(f"DOUBT {x} {how}: {e['text']}", f"DOUBT {x} {how} (GM-only)"))
        if not changed:
            _miss(ctx, e, f"{', '.join(xs)} was already settled - '{e['line']}' changed nothing")
        done += changed
    return done


def _doubt(ctx, e: dict, targets: list[str], unknown: list[str]) -> list[str]:
    """Raise one (ids: everything involved, both sides), or add to one (`doubt X3, T52: what you found` - a settled one
    reopens). Whoever wrote the line - the GM, the canon read-back, the aside - is ctx.by. A doubt naming no one on
    file is raised all the same, the names kept in its words: it's the one line that must never be lost. The same one
    raised again after it was settled reopens, its old answer kept in a note (doubts.REOPENS: the canon only a
    resolved one); one that stays settled is unplaced, so an aside never tells the table a doubt is being looked into.
    (Settling one: _settle, after the block's other lines.)"""
    g, t = ctx.game, ctx.turn_id
    xs = [x for x in targets if doubts.is_doubt(g, x)]
    if xs:
        for x in xs:
            doubts.work(g, x, e["text"], t, [i for i in targets if i not in xs], ctx.by)
            ctx.events.append(gm_only(f"DOUBT {x} worked on: {e['text']}", f"DOUBT {x} worked on (GM-only)"))
        return xs
    text = e["text"] + (f" (also named, not on file: {', '.join(unknown)})" if unknown else "")
    r = doubts.raise_(g, text, targets, t, ctx.by, reopen=doubts.REOPENS.get(ctx.by, ()))
    if r["status"] == "settled":
        d = r["doubt"]
        _miss(ctx, e, f"{r['id']} was {d['status']} T{d['resolved_turn']} - {d['resolution']} - not reopened")
        return []
    said = {"new": "raised", "bumped": "raised again", "reopened": "reopened (it was settled)"}[r["status"]]
    ctx.events.append(gm_only(f"DOUBT {r['id']} {said}: {e['text']}", f"DOUBT {r['id']} {said} (GM-only)"))
    g.out(f"[DOUBT] {r['id']} {r['status']} ({doubts.NAMED.get(ctx.by, ctx.by)}): {e['text']}")
    return [r["id"]]


def _tension(ctx, e: dict, targets: list[str]) -> list[str]:
    """Open one (ids are who it's about), move one (`tension Q3: ...`), or close/shelve one."""
    g, t = ctx.game, ctx.turn_id
    qs = [x for x in targets if x.startswith("Q") and tensions.get(g, x)]
    if e["kind"] in ("resolve", "shelve"):
        done = []
        for q in qs:
            if (tensions.resolve if e["kind"] == "resolve" else tensions.shelve)(g, q, t, e["text"]):
                ctx.tensions_touched.add(q)
                ctx.events.append(gm_only(f"TENSION {q} {e['kind']}d: {e['text']}",
                                          f"TENSION {q} {e['kind']}d (GM-only)"))
                done.append(q)
        if not qs:
            _miss(ctx, e, f"{e['kind']} needs a tension id like Q3" + (" (or a doubt's, X3)" if e["kind"] == "resolve"
                                                                         else "") + " - skipped")
        return done
    f = tensions.parse(e["text"], g.clock())
    if f.get("public"):                                  # (the recap's: what the crew knows, in the names they know)
        f["public"], slip = spoilers.scrub(g, f["public"])
        if slip:
            spoilers.flag(g, "spoiler", "An open question's public line", slip, t,
                          "scrubbed to the names the crew knows")
    if f.get("bad_due"):                                 # (review of flag #42: a due nothing could read was dropped)
        _miss(ctx, e, f"can't read the due '{f['bad_due']}' - a story time (`due day 5 12:00`, `due tonight`) or "
                      "`due off` (with its reason after a dash) - the deadline wasn't changed")
    if qs and f["due"] == tensions.LIFT and not any((f["main"], f["next"], f["public"], f["stakes"])):
        # `tension Q1: due off` alone - or with its reason, "due off - R11 locks the timeline" - lifts the deadline and
        # keeps the question as it stands - nothing moved on screen, so a shelved one stays shelved (flag #42: R11's
        # timeline lock, and Q1's noon still pressing)
        if tensions.lift_due(g, qs[0]) is None:
            _miss(ctx, e, f"{qs[0]} has no deadline to lift")
            return []
        ctx.events.append(gm_only(f"TENSION {qs[0]}: deadline lifted - the question stays open"
                                  + (f" ({f['why']})" if f.get("why") else ""),
                                  f"TENSION {qs[0]}: deadline lifted (GM-only)"))
        return [qs[0]]
    if qs:
        tensions.update(g, qs[0], t, f["main"] or None, f["next"], f["public"], f["due"], f["stakes"])
        ctx.tensions_touched.add(qs[0])
        ctx.events.append(gm_only(f"TENSION {qs[0]} moved: {f['main']}"
                                  + (" (deadline lifted - the question stays open)" if f["due"] == tensions.LIFT
                                     else ""), f"TENSION {qs[0]} moved (GM-only)"))
        return [qs[0]]
    if not f["main"]:
        return []
    about = [x for x in targets if ctx.game.ledger.get(x)]
    # (the question shows on the dashboard, as the seed's review knows: in the names the crew knows, its words on a
    # note on it)
    question, slip = spoilers.scrub(g, f["main"])
    q = tensions.open_tension(g, question, about, t, f["stakes"] or 2, f["next"], f["public"], f["due"])
    if slip:
        g.sub.add_note([q], f"The question in full: {f['main']}", t)
    ctx.tensions_touched.add(q)
    on = _on(g, about)
    ctx.events.append(gm_only(f"TENSION {q} opened: {f['main']}", f"TENSION {q} opened" + (f" on {on}" if on else "")
                              + " (GM-only)"))
    return [q]
