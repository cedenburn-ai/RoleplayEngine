"""NPC minds: reflection turns what an NPC witnessed and heard into how they feel (DESIGN.md §10).

Runs at scene close and every few turns inside a long scene, one cheap Haiku call per NPC - side by side.
Each NPC's view of each person is a belief node; a changed view supersedes the old one through
a diode, so the chain of how Kaz came to distrust Razor stays in the graph. The attitude is
also a hard number in the ledger (attitude:<id>, -3..+3) the DM can use for social modifiers.

Grudges move on news, not on rereading (2026-10-16). Reflecting again on the same memories used to ratchet a view a
notch at a time - October's Tamsin went -1, -2, -3 over seven turns on one killing and a phone call, and -3 had no
way back. Now an NPC reflects about someone only when something new involves them (seen, or heard since the last
view), the prompt marks what the old view already counts, one reflection moves an attitude at most two steps, and
strong feelings cool with time apart (`cool`).
"""
from __future__ import annotations

import json

from .llm import fan_out
from .prompts import FICTION_NOTE

REFLECT_SYSTEM = FICTION_NOTE + """ You are the private inner voice of a non-player character in a Shadowrun tabletop game. Given \
who they are, what they personally witnessed and heard, their secrets and agenda (the GM's notes), and how they \
felt before, decide how they NOW feel about each listed person and what they want from them. Stay grounded in \
what this character actually experienced - they can be biased, wrong, self-interested or scared, but they only \
know what they saw or were told. attitude runs from -3 (would hurt them) through 0 (indifferent) to +3 (would \
take a bullet for them). belief: one or two sentences in the character's own frame of mind (third person, e.g. \
"Kaz thinks Razor ..."), including what they intend to do about it if anything. changed: false if nothing \
meaningful shifted since the previous belief.
How they felt before already counts everything marked (already counted) - don't weigh it again. Move an attitude \
only for what's NEW: usually one step, two only for something that truly lands (a killing, a betrayal, a rescue), \
and keep the view (changed: false) when nothing new touches that person. Rumors are second-hand and partial: they \
count for less than what the character saw, and the character knows they don't have the whole story."""
MAX_STEP = 2                     # one reflection moves an attitude at most this far
COOL_EVERY = 2 * 24 * 60         # story minutes apart for a strong feeling to fade a step toward neutral (never past 1)


def reflect_schema() -> dict:
    return {"type": "object", "properties": {"beliefs": {"type": "array", "items": {
        "type": "object",
        "properties": {"about": {"type": "string"}, "attitude": {"type": "integer"},
                       "belief": {"type": "string"}, "changed": {"type": "boolean"}},
        "required": ["about", "attitude", "belief", "changed"], "additionalProperties": False}}},
        "required": ["beliefs"], "additionalProperties": False}


def _shared(game, a: str, b: str) -> int:
    roles = game.settings.knobs.witness_roles
    q = (f"SELECT COUNT(*) FROM members x JOIN members y ON x.slice_id=y.slice_id WHERE x.node_id=? AND y.node_id=? "
         f"AND x.role IN ({','.join('?' * len(roles))}) AND y.role IN ({','.join('?' * len(roles))})")
    return game.conn.execute(q, (a, b, *roles, *roles)).fetchone()[0]


def _involves(game, slice_id: str, eid: str) -> bool:
    return game.conn.execute("SELECT 1 FROM members WHERE slice_id=? AND node_id=?", (slice_id, eid)).fetchone() \
        is not None


def reflect_scene(game, scene_id: int, turn: int, fought: set[str] | frozenset = frozenset()) -> list[str]:
    """Reflect every NPC with enough first-hand experience in this scene - about the people something new has
    happened with since their last view. Returns new belief ids.

    `fought` = the people in a fight that just ended: the whole fight is one memory, and that's enough to reflect on.
    """
    L, S, k = game.ledger, game.sub, game.settings.knobs
    roles = k.witness_roles
    marks = ",".join("?" * len(roles))
    rows = game.conn.execute(                              # (a voice on the line takes part too - from what it heard)
        f"SELECT m.node_id, COUNT(*) AS n FROM members m JOIN nodes s ON s.id=m.slice_id "
        f"WHERE s.scene_id=? AND s.kind='slice' AND m.role IN ({marks}, 'remote') GROUP BY m.node_id",
        (scene_id, *roles)).fetchall()
    witnessed = {r["node_id"]: r["n"] for r in rows}
    jobs = []                                                # (npc, subjects, prompt) - read now, think side by side
    for eid, n in witnessed.items():
        npc = L.get(eid)
        if not npc or npc["kind"] != "npc" or npc["tier"] < 1 or (n < k.reflect_min_witnessed and eid not in fought):
            continue
        from ..engine.rules.sr_lite import condition
        if condition(L, eid) == "dead":
            continue
        # minds focus on the PCs; another NPC only earns a belief after real shared history
        # (otherwise every mook in a strike team reflects about every other mook)
        subjects = [s for s in witnessed if s != eid and (L.get(s) or {}).get("kind") == "pc"]
        for s in witnessed:
            if s != eid and (L.get(s) or {}).get("kind") == "npc" and _shared(game, eid, s) >= 4:
                subjects.append(s)
        seen = game.conn.execute(
            f"SELECT n.id, n.text, n.created_turn FROM nodes n WHERE n.scene_id=? AND n.kind='slice' AND n.id IN "
            f"(SELECT slice_id FROM members WHERE node_id=? AND role IN ({marks})) "
            f"ORDER BY n.created_turn DESC", (scene_id, eid, *roles)).fetchall()
        heard = S.heard(eid, 6)
        views = {s: S.current_belief(eid, s) for s in subjects}
        since = {s: views[s]["created_turn"] if views[s] else -1 for s in subjects}
        # only the people something new has happened with: first impressions, or news since the last view
        subjects = [s for s in subjects if not views[s]
                    or any(r["created_turn"] > since[s] and _involves(game, r["id"], s) for r in seen)
                    or any((h["heard_turn"] or 0) > since[s] and _involves(game, h["id"], s) for h in heard)]
        if not subjects:
            continue
        counted = -1 if any(not views[s] for s in subjects) else min(since[s] for s in subjects)
        tag = lambda t: "" if t > counted else "(already counted) "            # noqa: E731
        before = []
        for s in subjects:
            b = views[s]
            att = int(L.stat(eid, f"attitude:{s}", 0))
            before.append(f"- {L.get(s)['name']} [{s}]: attitude {att:+d}; "
                          + (f"{b['text']} (their view since T{b['created_turn']})" if b else "no settled view yet"))
        notes = S.notes_for(eid, 4)

        def told(h) -> str:
            src = L.get(h["source"]) if h.get("source") else None
            how = {"rumor": "a rumor", "on the line": "on the line (heard, didn't see)"}.get(h["how"], h["how"])
            return (f"- {tag(h['heard_turn'] or 0)}{how}"
                    + (f" via {src['name']}" if src else "") + f": {h['text'][:200]}")
        user = (f"CHARACTER: {npc['name']} - {npc['description']}\n\n"
                + ("GM NOTES (their secrets/agenda):\n" + "\n".join(f"- {x['text']}" for x in notes) + "\n\n" if notes else "")
                + "WHAT THEY WITNESSED (newest first):\n"
                + "\n".join(f"- {tag(r['created_turn'])}[{r['id']}] {r['text']}" for r in seen[:10])
                + ("\n\nWHAT THEY HEARD (second-hand):\n" + "\n".join(told(h) for h in heard) if heard else "")
                + "\n\nHOW THEY FELT BEFORE:\n" + "\n".join(before)
                + "\n\nReturn one belief per person listed (use the ids in brackets).")
        jobs.append((npc, subjects, user))
    # one Haiku call per NPC, side by side: a crowded scene (ten NPCs at the chop yard) took 60-90 s one at a time.
    # Each NPC's prompt is only its own experience and its own old views, so none waits on another's answer.
    answers = fan_out(lambda user: game.llm.structured(game.settings.models.commit, REFLECT_SYSTEM, user,
                                                       reflect_schema(), max_tokens=3000, effort="low",
                                                       purpose="minds"), [j[2] for j in jobs])
    made = []
    for (npc, subjects, _), data in zip(jobs, answers):
        eid = npc["id"]
        if isinstance(data, Exception):
            game.out(f"  (reflection for {npc['name']} failed: {data})")
            continue
        for b in data.get("beliefs", []):
            about = L.find(b.get("about", ""))
            if not about or about["id"] not in subjects:
                continue
            prev = S.current_belief(eid, about["id"])
            if prev and not b.get("changed", True):
                continue
            att = max(-3, min(3, int(b.get("attitude", 0))))
            if prev:                                         # a view moves, it doesn't flip on one reflection
                was = int(L.stat(eid, f"attitude:{about['id']}", 0))
                att = max(was - MAX_STEP, min(was + MAX_STEP, att))
            bid = S.add_belief(eid, about["id"], b["belief"], turn, scene_id, story_time=game.clock())
            L.set_stat(eid, f"attitude:{about['id']}", att)
            L.log(turn, "belief", eid, {"about": about["id"], "attitude": att, "belief": bid})
            made.append(bid)
        if npc["tier"] < 2 and any(S.current_belief(eid, s) for s in subjects):
            L.update_entity(eid, tier=2)                     # it earned a mind
    if made:
        S.touch(made, turn, 0.5)
        game.out(f"[MINDS] {len(made)} NPC belief(s) updated: " + ", ".join(made))
    return made


def formed_at(game, belief_id: str) -> int | None:
    """When (story minutes) a view was formed: its own stamp, or the story clock of its turn for older beliefs."""
    row = game.conn.execute("SELECT created_turn, story_time FROM nodes WHERE id=?", (belief_id,)).fetchone()
    if not row:
        return None
    if row["story_time"] is not None:
        return row["story_time"]
    return game.conn.execute("SELECT MAX(story_time) FROM nodes WHERE kind='slice' AND created_turn<=?",
                             (row["created_turn"],)).fetchone()[0]


def view_attitude(game, belief_id: str) -> int | None:
    """The attitude a belief was formed with (the ledger's number may have cooled since)."""
    row = game.conn.execute("SELECT payload FROM events WHERE kind='belief' AND json_extract(payload, '$.belief')=? "
                            "ORDER BY seq DESC LIMIT 1", (belief_id,)).fetchone()
    return int(json.loads(row["payload"])["attitude"]) if row else None


def cool(game, turn: int | None = None) -> list[str]:
    """Strong feelings fade with time apart: one step toward neutral for every COOL_EVERY of story time since the NPC
    last saw, heard of, or made up their mind about the person - never past +/-1 (they still remember). New contact
    starts the clock again. Runs when a scene closes."""
    L, c = game.ledger, game.conn
    roles = game.settings.knobs.witness_roles
    marks = ",".join("?" * len(roles))
    now, lines = game.clock(), []
    for r in c.execute("SELECT entity_id, key, value FROM stats WHERE key LIKE 'attitude:%' AND ABS(value) >= 2").fetchall():
        eid, about, att = r["entity_id"], r["key"].split(":", 1)[1], int(r["value"])
        view = game.sub.current_belief(eid, about)
        base = view_attitude(game, view["id"]) if view else None
        if base is None or base * att <= 0:
            continue                                         # (no view of record, or something else set the number)
        seen = c.execute(f"SELECT MAX(n.story_time) FROM nodes n JOIN members a ON a.slice_id=n.id AND a.node_id=? "
                         f"AND a.role IN ({marks}) JOIN members o ON o.slice_id=n.id AND o.node_id=? "
                         f"WHERE n.kind='slice'", (eid, *roles, about)).fetchone()[0]
        heard = c.execute("SELECT MAX(n.story_time) FROM knows k JOIN nodes n ON n.id=k.node_id JOIN members o "
                          "ON o.slice_id=n.id AND o.node_id=? WHERE k.holder=?", (about, eid)).fetchone()[0]
        last = max((t for t in (formed_at(game, view["id"]), seen, heard) if t is not None), default=None)
        if last is None:
            continue
        steps = max(0, now - last) // COOL_EVERY
        target = (1 if base > 0 else -1) * max(1, abs(base) - steps)
        if abs(target) < abs(att):
            L.set_stat(eid, f"attitude:{about}", target)
            L.log(turn, "attitude_cooled", eid, {"about": about, "from": att, "to": target})
            lines.append(f"{(L.get(eid) or {}).get('name', eid)} -> {(L.get(about) or {}).get('name', about)} "
                         f"{att:+d} to {target:+d}")
    if lines:
        game.out("[MINDS] time cooled: " + "; ".join(lines))
    return lines
