"""The character ledger (DESIGN.md §7e): player characters that outlive any one story.

A runner is saved once and checked out to one world at a time, like a library book. While checked out, the
world's copy is the live one; progress (karma, nuyen, gear, chrome, spells) syncs back on save, on `!leave`,
at each new session, and on return. Returning writes a few sentences of backstory from the world's *public*
record - the next world's GM knows it as history, never the old world's secrets or NPC relationships.

Names are unique across the whole ledger (case-insensitive, first come first served). The ledger is one
SQLite file next to the campaigns (`character_ledger.db`), with portraits in `character_ledger/`.

Runners are never deleted from here: `hide` puts one away (off the list, the checkout menu and autocomplete) and
`unhide` brings them back, sheet, portrait and backstory intact - and the name stays taken while they're away.
"""
from __future__ import annotations

import json
import re
import shutil
import sqlite3
from contextlib import closing
from pathlib import Path

from .engine.ledger import LedgerError
from .engine.rules import machines, sr_lite
from .dm.prompts import FICTION_NOTE

SCHEMA = """
CREATE TABLE IF NOT EXISTS runners(
    slug TEXT PRIMARY KEY, name TEXT NOT NULL, owner_id TEXT NOT NULL, owner_name TEXT,
    shared INTEGER NOT NULL DEFAULT 0,             -- 1: anyone may check them out
    data TEXT NOT NULL,                            -- the sheet: stats, props, gear, drones, description
    portrait TEXT, backstory TEXT NOT NULL DEFAULT '[]',
    campaign TEXT, entity_id TEXT,                 -- checked out to (NULL: on the shelf)
    created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_runner_name ON runners(lower(name));
"""
KEEP_STATS = set(sr_lite.ATTRIBUTES) | set(sr_lite.SKILLS) | {"essence", "nuyen", "karma"}
KEEP_PROPS = ("archetype", "metatype", "pronouns", "concept", "spells", "forms")
GEAR_KEYS = ("dv", "armor", "deck", "bonus", "control_rig", "augmentation", "explosive")   # what counts as kit
BACKSTORY_KEEP = 3

DIGEST_SYSTEM = FICTION_NOTE + """ You write a runner's backstory for a Shadowrun campaign. You get the public record of one story \
they lived through. Write 2-3 sentences, past tense, third person, naming the people and places that mattered and \
how it left them (owed, hunted, richer, scarred). Use {pronouns} for them. Only what the record says - no secrets, \
no invention."""


def path(game) -> Path:
    return game.path.parent / "character_ledger.db"


def _db(game) -> sqlite3.Connection:
    c = sqlite3.connect(str(path(game)), timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode = WAL")
    c.execute("PRAGMA synchronous = NORMAL")               # (see db.connect)
    c.executescript(SCHEMA)
    try:                                                   # (ledgers from before hiding)
        c.execute("ALTER TABLE runners ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    return c


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "runner"


def _row(r) -> dict | None:
    if not r:
        return None
    d = dict(r)
    d["data"] = json.loads(d["data"])
    d["backstory"] = json.loads(d["backstory"] or "[]")
    return d


def get(game, name: str) -> dict | None:
    with closing(_db(game)) as c:
        return _row(c.execute("SELECT * FROM runners WHERE lower(name)=? OR slug=?",
                              (name.strip().lower(), slug(name))).fetchone())


def taken(game, name: str) -> bool:
    return get(game, name) is not None


def runners(game, hidden: bool = False) -> list[dict]:
    """Who's on the list (or, hidden=True, who's been put away)."""
    with closing(_db(game)) as c:
        return [_row(r) for r in c.execute("SELECT * FROM runners WHERE hidden=? ORDER BY lower(name)", (int(hidden),))]


def set_hidden(game, name: str, uid: str, hidden: bool, admin: bool = False) -> dict:
    """Put a runner away, or bring them back - never a delete. Their player or the campaign owner can; a runner who's
    out playing a world comes home first (`release`), so nobody vanishes mid-story."""
    r = get(game, name)
    if not r:
        raise LedgerError(f"No {name} in the character ledger.")
    if r["owner_id"] != uid and not admin:
        raise LedgerError(f"{r['name']} is {r['owner_name'] or 'someone else'}'s to {'hide' if hidden else 'bring back'}.")
    if hidden and r["campaign"]:
        raise LedgerError(f"{r['name']} is playing in **{r['campaign']}** - `!characterledger release {r['name']}` "
                          "brings them back to the shelf first.")
    if bool(r["hidden"]) == hidden:
        raise LedgerError(f"{r['name']} is already {'hidden' if hidden else 'on the list'}.")
    with closing(_db(game)) as c:
        c.execute("UPDATE runners SET hidden=?, updated_at=CURRENT_TIMESTAMP WHERE slug=?", (int(hidden), r["slug"]))
        c.commit()
    return get(game, name)


def linked(game, eid: str) -> str | None:
    """The ledger slug a world's character belongs to, if any."""
    ent = game.ledger.get(eid)
    return (ent or {}).get("props", {}).get("ledger")


# ── world -> ledger ─────────────────────────────────────────────────────

def export(game, eid: str) -> dict:
    """The parts of a character that travel: the sheet, kit, chrome, drones - not damage, not story items."""
    L = game.ledger
    ent = L.require(eid)
    stats = {k: v for k, v in L.stats(eid).items() if k in KEEP_STATS}
    props = {k: ent["props"][k] for k in KEEP_PROPS if k in ent["props"]}
    items = []
    for i in L.holdings(eid):
        p = i["props"] or {}
        if not any(k in p for k in GEAR_KEYS) or p.get("file") or sr_lite.arriving(i):
            continue                      # keycards, datachips, paydata stay in their story (and what's still with a
        name = i["name"].split("'s ", 1)[1] if i["name"].startswith(ent["name"] + "'s ") else i["name"]   # courier)
        items.append({"name": name, "description": i["description"], "props": p, "qty": i["qty"]})
    drones = [{"name": m["name"].split("'s ", 1)[-1], "model": m["props"].get("model"), **_drone_kit(L, m)}
              for m in machines.owned_by(L, eid) if m["props"].get("model") and not sr_lite.arriving(m)]
    return {"name": ent["name"], "description": ent["description"], "stats": stats, "props": props,
            "items": items, "drones": drones}


DRONE_KIT = GEAR_KEYS + ("autosoft", "mount")


def _drone_kit(L, m: dict) -> dict:
    """What a drone was fitted with - since 2026-10-24 drones are bought as bare frames, so the model alone no longer
    says what a runner's drone carries: its autosofts, its mounts, and the guns, grenades and loaded autosofts aboard
    (and kit stowed as cargo, still cargo). What's still with a courier stays behind, like the runner's own (review
    E2: frags bought onto a Fly-Spy went to the next world still 'on their way', where nothing would ever deliver
    them)."""
    return {"autosofts": dict(m["props"].get("autosofts") or {}), "mounts": machines._base_mounts(L, m),
            "items": [{"name": i["name"].rsplit("'s ", 1)[-1], "props": i["props"], "qty": i["qty"]}
                      | ({"cargo": True} if i["state"].get(machines.CARGO) else {})
                      for i in L.holdings(m["id"])
                      if any(k in (i["props"] or {}) for k in DRONE_KIT) and not sr_lite.arriving(i)]}


def _portrait(game, eid: str, key: str) -> str | None:
    art = game.art.latest(game.conn, eid, ready_only=True)
    if not art or not Path(art["path"]).exists():
        return None
    dest = (path(game).parent / "character_ledger" / f"{key}{Path(art['path']).suffix}").resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if Path(art["path"]).resolve() != dest.resolve():
        shutil.copyfile(art["path"], dest)
    return str(dest)


def register(game, eid: str, owner_id: str, owner_name: str) -> str:
    """Put a world's character into the ledger, checked out to that world (it's playing there now)."""
    L = game.ledger
    ent = L.require(eid)
    if ent["kind"] != "pc":
        raise LedgerError("Only player characters go in the character ledger.")
    if linked(game, eid):
        return linked(game, eid)
    existing = get(game, ent["name"])
    if existing:
        raise LedgerError(f"There's already a {existing['name']} in the character ledger "
                          f"({existing['owner_name'] or 'someone'}'s) - names are unique across every world.")
    key = slug(ent["name"])
    with closing(_db(game)) as c:
        c.execute("INSERT INTO runners(slug, name, owner_id, owner_name, data, portrait, campaign, entity_id) "
                  "VALUES(?,?,?,?,?,?,?,?)", (key, ent["name"], owner_id, owner_name, json.dumps(export(game, eid)),
                                              _portrait(game, eid, key), game.path.stem, eid))
        c.commit()
    L.update_entity(eid, props={**ent["props"], "ledger": key})
    return key


def sync(game, eid: str) -> bool:
    """Write a checked-out character's progress back to the ledger."""
    key = linked(game, eid)
    if not key:
        return False
    with closing(_db(game)) as c:
        r = c.execute("SELECT campaign, entity_id FROM runners WHERE slug=?", (key,)).fetchone()
        if not r or r["campaign"] != game.path.stem or r["entity_id"] != eid:
            return False                                  # (not this world's to write - it was returned or released)
        c.execute("UPDATE runners SET data=?, portrait=COALESCE(?, portrait), updated_at=CURRENT_TIMESTAMP "
                  "WHERE slug=?", (json.dumps(export(game, eid)), _portrait(game, eid, key), key))
        c.commit()
    return True


def digest(game, eid: str) -> str:
    """A few sentences of backstory from the public record of this world (never whispers or GM notes)."""
    S, ent = game.sub, game.ledger.require(eid)
    mems = [m for m in S.witnessed_slices(eid, 80) if (S.node(m["id"]) or {}).get("visibility") == "public"]
    if not mems:
        return ""
    mems.sort(key=lambda m: m["created_turn"])
    record = "\n".join(f"- {m['text']}" for m in mems[-40:])
    system = DIGEST_SYSTEM.format(pronouns=ent["props"].get("pronouns") or "they/them")
    try:
        text = game.llm.text(game.settings.models.commit, system, f"{ent['name']}'s story:\n{record}",
                             max_tokens=2500, effort=game.settings.models.commit_effort, purpose="ledger").strip()
        return text.split("\n\n", 1)[0].strip()          # the backstory only - never any commentary after it
    except Exception as exc:
        game.out(f"  (ledger: no backstory digest - {exc})")
        return ""


def check_in(game, eid: str, write_backstory: bool = True) -> str:
    """Return a character to the shelf: final sync, a backstory paragraph, and they leave this world's story."""
    key = linked(game, eid)
    if not key or not sync(game, eid):
        raise LedgerError("That character isn't checked out to this world.")
    story = digest(game, eid) if write_backstory else ""
    with closing(_db(game)) as c:
        back = json.loads(c.execute("SELECT backstory FROM runners WHERE slug=?", (key,)).fetchone()[0] or "[]")
        if story:
            back.append({"world": game.path.stem, "text": story})
        c.execute("UPDATE runners SET campaign=NULL, entity_id=NULL, backstory=?, updated_at=CURRENT_TIMESTAMP "
                  "WHERE slug=?", (json.dumps(back[-6:]), key))
        c.commit()
    L = game.ledger
    for sid in [r[0] for r in game.conn.execute("SELECT scene_id FROM scene_roster WHERE entity_id=?", (eid,))]:
        L.leave(sid, [eid])
    L.update_entity(eid, status="departed")
    L.log(game.turn_no(), "departed", eid, {"to": "the character ledger", "ledger": key})   # (the graph log's why)
    game.conn.execute("DELETE FROM players WHERE handle=?", (L.get(eid)["player"],))
    return story


def release(game, name: str, owner_id: str, admin: bool = False) -> dict:
    """The owner - or the campaign owner, cleaning up after a world nobody plays - puts a runner back on the shelf
    from wherever it's stuck (its last saved progress stands)."""
    r = get(game, name)
    if not r:
        raise LedgerError(f"No {name} in the character ledger.")
    if r["owner_id"] != owner_id and not admin:
        raise LedgerError(f"{r['name']} is {r['owner_name']}'s to release.")
    with closing(_db(game)) as c:
        c.execute("UPDATE runners SET campaign=NULL, entity_id=NULL WHERE slug=?", (r["slug"],))
        c.commit()
    return r


def set_shared(game, name: str, owner_id: str, shared: bool) -> dict:
    r = get(game, name)
    if not r or r["owner_id"] != owner_id:
        raise LedgerError(f"You don't have a {name} in the character ledger.")
    with closing(_db(game)) as c:
        c.execute("UPDATE runners SET shared=? WHERE slug=?", (int(shared), r["slug"]))
        c.commit()
    return r


# ── ledger -> world ─────────────────────────────────────────────────────

def check_out(game, name: str, uid: str, turn: int) -> tuple[str, bool]:
    """Bring a runner into this world (or back into it). Returns (entity id, came back to an old copy)."""
    L = game.ledger
    r = get(game, name)
    if not r:
        raise LedgerError(f"No {name} in the character ledger - `!characterledger` lists who's there.")
    if r["hidden"]:
        raise LedgerError(f"{r['name']} is put away - `!characterledger unhide {r['name']}` brings them back first.")
    if r["owner_id"] != uid and not r["shared"]:
        raise LedgerError(f"{r['name']} is {r['owner_name']}'s - they can `!characterledger share {r['name']}`.")
    if r["campaign"] and r["campaign"] != game.path.stem:
        raise LedgerError(f"{r['name']} is checked out to **{r['campaign']}** - return them there first "
                          f"(or the owner can `!characterledger release {r['name']}`).")
    if r["campaign"] == game.path.stem and r["entity_id"] and L.get(r["entity_id"]):
        return r["entity_id"], True                       # already here
    d = r["data"]
    old = next((e for e in L.entities(kind="pc", status=None) if e["props"].get("ledger") == r["slug"]), None)
    waiting = []                                          # (kit on its way to an old drone: onto the new one, below)
    if old:                                               # back to a world they left: same entity, newer sheet
        eid = old["id"]
        # What's still with a courier stayed behind and isn't in the record (export), so it isn't swapped for the
        # record's kit: review E2, a jacket and a Steel Lynx bought for delivery (26,000¥) were taken and departed on
        # the way back in, then announced as arrivals into nobody's hands.
        for i in L.holdings(eid):
            if (any(k in (i["props"] or {}) for k in GEAR_KEYS) and not (i["props"] or {}).get("file")
                    and not sr_lite.arriving(i)):
                L.take(eid, i["id"], i["qty"])
        for m in machines.owned_by(L, eid):
            if sr_lite.arriving(m):
                continue
            for i in L.holdings(m["id"]):
                if sr_lite.arriving(i):
                    waiting.append((m["name"], i["id"], i["qty"], L.take(m["id"], i["id"], i["qty"])))
            L.update_entity(m["id"], status="departed")
        L.update_entity(eid, status="active", description=d["description"],
                        props={**old["props"], **d["props"], "ledger": r["slug"]})
        L.log(turn, "returned", eid, {"from": "the character ledger", "ledger": r["slug"]})
    else:
        clash = L.find(d["name"])
        if clash:
            raise LedgerError(f"This world already has someone called {clash['name']} - {d['name']} can't join "
                              "under that name here.")
        eid = L.create_entity("pc", d["name"], d["description"], tier=2, player=r["slug"],
                              props={**d["props"], "ledger": r["slug"]}, turn=turn)
    for k, v in d["stats"].items():
        L.set_stat(eid, k, v)
    L.set_stat(eid, "physical_damage", 0)
    L.set_stat(eid, "stun_damage", 0)
    L.set_stat(eid, "edge_points", d["stats"].get("edge", 1))
    for item in d["items"]:
        iid = L.create_entity("item", f"{d['name']}'s {item['name']}", item["description"], tier=0,
                              props=item["props"], turn=turn)
        cap = item["props"].get("ammo_capacity")
        L.give(eid, iid, item["qty"], {"loaded": cap} if cap else {})
    built = {}
    for m in d["drones"]:
        kit = "autosofts" in m                            # (an export from before frames: the old fitted model)
        mid = machines.build_machine(L, f"{d['name']}'s {m['name']}", m["model"], eid, turn, equipped=not kit)
        built.setdefault(L.require(mid)["name"], mid)
        if kit:
            L.update_entity(mid, props={**L.require(mid)["props"], "autosofts": dict(m["autosofts"]),
                                        "mounts": list(m.get("mounts") or [])})
            for it in m.get("items") or []:
                iid = L.create_entity("item", f"{d['name']}'s {m['name']}'s {it['name']}", it["name"], tier=0,
                                      props=it["props"], turn=turn)
                cap = it["props"].get("ammo_capacity")
                L.give(mid, iid, it.get("qty", 1), ({"loaded": cap} if cap else {})
                       | ({machines.CARGO: True} if it.get("cargo") else {}))
    for name, iid, qty, state in waiting:                 # onto the same drone come back, if it fits, else to them
        mid = built.get(name)
        if mid:
            try:
                machines.check_load(L, L.require(mid), L.require(iid))
            except LedgerError:
                mid = None
        L.give(mid or eid, iid, qty, state)
    if r["portrait"] and Path(r["portrait"]).exists() and not game.art.latest(game.conn, eid, ready_only=True):
        dest = game.art.dir / f"{eid}{Path(r['portrait']).suffix}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(r["portrait"], dest)
        game.conn.execute("INSERT INTO art(entity_id, version, path, status, caption, created_turn) "
                          "VALUES(?,?,?,?,?,?)", (eid, 1, str(dest), "ready", "from the character ledger", turn))
    game.sub.ensure_entity(L.get(eid), turn)
    if not old:
        for b in r["backstory"][-BACKSTORY_KEEP:]:
            game.sub.add_fact(f"{d['name']}'s past ({b['world']}): {b['text']}", [eid], turn)
    with closing(_db(game)) as c:
        c.execute("UPDATE runners SET campaign=?, entity_id=? WHERE slug=?", (game.path.stem, eid, r["slug"]))
        c.commit()
    return eid, bool(old)


def let_go(game, eid: str, write_backstory: bool = True) -> str | None:
    """A new party in this world (newparty.py): the runner's last progress and a backstory go home, and the ledger lets
    them go - back on the shelf for other worlds - but they stay in this one, as the GM's character. The world's copy
    is unlinked for good: it never syncs again, and check_out turns the name away here (this world has someone called
    that). Returns the backstory written ("" for none), or None when this world doesn't hold their checkout (never
    in the ledger, or released from somewhere else) - unlinked either way."""
    key = linked(game, eid)
    story = None
    if key and sync(game, eid):
        story = digest(game, eid) if write_backstory else ""
        with closing(_db(game)) as c:
            back = json.loads(c.execute("SELECT backstory FROM runners WHERE slug=?", (key,)).fetchone()[0] or "[]")
            if story:
                back.append({"world": game.path.stem, "text": story})
            c.execute("UPDATE runners SET campaign=NULL, entity_id=NULL, backstory=?, updated_at=CURRENT_TIMESTAMP "
                      "WHERE slug=?", (json.dumps(back[-6:]), key))
            c.commit()
    ent = game.ledger.get(eid)
    if ent and "ledger" in ent["props"]:
        game.ledger.update_entity(eid, props={k: v for k, v in ent["props"].items() if k != "ledger"})
    return story


def raw_rows(game, slugs) -> list[dict]:
    """The runners' rows as stored - what a rollback writes back (put_rows)."""
    slugs = [s for s in dict.fromkeys(slugs) if s]
    if not slugs:
        return []
    with closing(_db(game)) as c:
        return [dict(r) for r in c.execute(f"SELECT * FROM runners WHERE slug IN ({','.join('?' * len(slugs))})", slugs)]


def put_rows(game, rows: list[dict]) -> None:
    """Rows from raw_rows (or a backup's copy of the ledger) back as they were: the sheet, the backstory, the checkout."""
    with closing(_db(game)) as c:
        for r in rows:
            c.execute("UPDATE runners SET data=?, backstory=?, portrait=?, campaign=?, entity_id=?, updated_at=? "
                      "WHERE slug=?", (r["data"], r["backstory"], r["portrait"], r["campaign"], r["entity_id"],
                                       r["updated_at"], r["slug"]))
        c.commit()


def summary(r: dict) -> str:
    p = r["data"]["props"]
    what = " ".join(x for x in (p.get("metatype"), (p.get("archetype") or "runner").replace("_", " ")) if x)
    where = (f"checked out to *{r['campaign']}*" if r["campaign"] else "put away (hidden)" if r.get("hidden")
             else "on the shelf")
    return (f"**{r['name']}** - {what} · {r['owner_name'] or 'someone'}'s{' · shared' if r['shared'] else ''} · "
            f"{where} · karma {int(r['data']['stats'].get('karma', 0))}")
