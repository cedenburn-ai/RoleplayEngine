"""The party roster (DESIGN.md §12b): the whole crew on one card, for the table - `!party` / `/party`.

One strip per runner: the portrait framed in the colour of their condition, who they are and who plays them,
Physical and Stun as box tracks with the wound penalty, Edge as pips, and the kit at a glance - armor worn, the best
weapon with its dice and ammo, explosives, spells being sustained (and on whom), Essence / Magic, nuyen and karma -
and where they are (their zone, in a fight). Everything comes from the ledger, like the sheet (sheetart.py, whose
look it shares).

It reads through a connection of its own (`view`), so the table can check on the crew while the GM is mid-turn.
"""
from __future__ import annotations

from pathlib import Path

from PIL import ImageDraw, ImageOps

from .engine import clock
from .engine.rules import magic, sr_lite
from .sheetart import (AMBER, CYAN, DIM, FAINT, GREEN, INK, LINE, MAGENTA, PANEL, RED, W, _boxes, _canvas, _pool,
                       _portrait, _save, _short, _topbar, font, mono)

STRIP = 262                       # one runner
GAP = 16
TOP = 72
GONE = (120, 124, 134)            # the dead
COLOR = 0x50DCFF


def view(game, conn):
    """The game, read through another connection (Game.on)."""
    return game.on(conn)


def crew(game) -> list[dict]:
    """The party: each seated player's character (a PC, or an NPC they inhabit) in the order they sat down, then any
    PC nobody has claimed (the GM plays them)."""
    seats, seen = [], set()
    for r in game.conn.execute("SELECT handle, name, afk FROM players ORDER BY rowid"):
        ch = game.character_for(r["handle"])
        if ch and ch["id"] not in seen:
            seen.add(ch["id"])
            seats.append((ch["id"], r["name"] or r["handle"], bool(r["afk"])))
    for pc in game.ledger.entities(kind="pc"):
        if pc["id"] not in seen:
            seen.add(pc["id"])
            seats.append((pc["id"], None, False))
    return [member(game, eid, player, away) for eid, player, away in seats]


def _where(game, eid: str) -> tuple[str | None, str | None]:
    """The place they're in (their scene's location), and their zone if a fight is on there."""
    L = game.ledger
    row = game.conn.execute(
        "SELECT r.scene_id FROM scene_roster r JOIN scenes s ON s.id=r.scene_id WHERE r.entity_id=? "
        "ORDER BY (s.status='active') DESC, r.scene_id DESC LIMIT 1", (eid,)).fetchone()
    if not row:
        return None, None
    scene = L.scene(row["scene_id"])
    place = (L.get(scene["location_id"]) or {}).get("name") if scene and scene["location_id"] else None
    from . import encounters
    fight = encounters.active(game, row["scene_id"])
    zone = (fight.get("positions") or {}).get(eid) if fight else None
    return place or (scene["title"] if scene else None), zone


def member(game, eid: str, player: str | None = None, away: bool = False) -> dict:
    """One runner's numbers, straight from the ledger (the picture and the text fallback both draw from this)."""
    L = game.ledger
    ent = L.require(eid)
    s = L.stats(eid)
    p = ent["props"]
    pmax, smax = sr_lite.monitor_max(L, eid)
    items = L.holdings(eid)
    guns = [i for i in items if "dv" in i["props"] and not i["props"].get("explosive")]
    weapon = None
    if guns:
        n, w = max(((_pool(L, eid, g["props"].get("skill", "firearms"))[0], g) for g in guns), key=lambda t: t[0])
        pp = w["props"]
        weapon = {"name": _short(w["name"]), "pool": n, "more": len(guns) - 1,
                  "ammo": (f"{w['state'].get('loaded', pp['ammo_capacity'])}/{pp['ammo_capacity']}"
                           if "ammo_capacity" in pp else None)}
    held = []
    for h in p.get("sustained") or []:
        spell = magic.SPELLS.get(h.get("spell"), {}).get("name", h.get("spell", "?"))
        on = h.get("target")
        # 'Force 5', not 'F5': next to the sheets' drain codes (Physical Barrier F-1) 'F5' reads as one
        held.append(spell + (f" Force {h['force']}" if h.get("force") else "")
                    + (f" on {(L.get(on) or {}).get('name', on)}" if on and on != eid else ""))
    place, zone = _where(game, eid)
    role = (p.get("archetype") or p.get("template") or "").replace("_", " ")
    return {
        "id": eid, "name": ent["name"], "kind": ent["kind"], "player": player, "away": away,
        "role": " ".join(x for x in (p.get("metatype", ""), role) if x).title(), "pronouns": p.get("pronouns"),
        "status": sr_lite.condition(L, eid), "penalty": sr_lite.wound_penalty(L, eid),
        "physical": (int(s.get("physical_damage", 0)), pmax), "stun": (int(s.get("stun_damage", 0)), smax),
        "edge": (int(s.get("edge_points", 0)), int(s.get("edge", 0))),
        "armor": sr_lite.best_armor(L, eid)[0], "essence": s.get("essence"),
        "magic": int(s.get("magic", 0)), "resonance": int(s.get("resonance", 0)),
        "nuyen": int(s.get("nuyen", 0)), "karma": int(s.get("karma", 0)),
        "weapon": weapon,
        "explosives": [(f"{i['qty']}× " if i["qty"] > 1 else "") + _short(i["name"])
                       for i in items if i["props"].get("explosive")],
        "sustained": held, "where": place, "zone": zone,
        "portrait": (game.art.latest(game.conn, eid, ready_only=True) or {}).get("path"),
    }


def _status_color(m: dict):
    return {"dead": GONE, "dying": RED, "unconscious": RED}.get(m["status"]) or (AMBER if m["penalty"] or
                                                                                 m["status"] == "wounded" else GREEN)


def _fit(text: str, f, width: float) -> str:
    if f.getlength(text) <= width:
        return text
    while text and f.getlength(text + "...") > width:
        text = text[:-1]
    return text.rstrip(" ·,") + "..."


def _strip(img, d: ImageDraw.ImageDraw, m: dict, y: int) -> None:
    x0, x1 = 40, W - 40
    col = _status_color(m)
    c = 16
    d.polygon([(x0, y), (x1 - c, y), (x1, y + c), (x1, y + STRIP), (x0 + c, y + STRIP), (x0, y + STRIP - c)],
              fill=PANEL, outline=LINE)
    d.rectangle([x0, y, x0 + 6, y + STRIP - c], fill=col)

    # the portrait, framed in their condition's colour (grey for the dead)
    pw, ph = 196, STRIP - 32
    pic = _portrait(Path(m["portrait"]) if m["portrait"] else None, pw, ph)
    if m["status"] == "dead":
        pic = ImageOps.grayscale(pic).convert("RGB")
    img.paste(pic, (x0 + 22, y + 16))
    d.rectangle([x0 + 22, y + 16, x0 + 22 + pw, y + 16 + ph], outline=col, width=3)

    # who: name, role, who plays them - and how they're doing, on the right of the column
    tx, ax = x0 + 22 + pw + 30, 1066
    state = "AWAY" if m["away"] and m["status"] == "ok" else m["status"].upper()
    state_f = font(34, "Bold")
    d.text((ax, y + 18), state, font=state_f, fill=AMBER if state == "AWAY" else col, anchor="rt")
    d.text((ax, y + 60), f"-{m['penalty']} to every pool" if m["penalty"] else "no wound penalty",
           font=font(19), fill=RED if m["penalty"] else DIM, anchor="rt")
    name_f = font(48, "Bold SemiCondensed")
    d.text((tx, y + 12), _fit(m["name"].upper(), name_f, ax - tx - state_f.getlength(state) - 30), font=name_f, fill=INK)
    sub_f = font(22, "SemiBold")
    sub = m["role"] or m["kind"].upper()
    d.text((tx, y + 72), sub, font=sub_f, fill=CYAN)
    who = (f"played by {m['player']}" + ("  ·  stepped away" if m["away"] else "") if m["player"]
           else "the GM plays them" if m["kind"] == "pc" else "")
    who = "  ·  ".join(x for x in (m["pronouns"], who) if x)
    if who:
        d.text((tx + sub_f.getlength(sub) + 16, y + 76), _fit("·  " + who, font(19), ax - 300 - tx),
               font=font(19), fill=DIM)

    # condition monitors
    for row, (label, (dmg, size), colr) in enumerate((("PHYSICAL", m["physical"], RED), ("STUN", m["stun"], AMBER))):
        ty = y + 116 + row * 46
        d.text((tx, ty + 15), label, font=font(19, "SemiBold"), fill=DIM, anchor="lm")
        end = _boxes(d, tx + 110, ty, dmg, size, colr, box=30, gap=5, ticks=False)
        d.text((end + 12, ty + 15), f"{dmg}/{size}", font=mono(21, True), fill=INK if dmg else FAINT, anchor="lm")

    # chips: Edge (as pips), armor, essence, the gift, nuyen, karma
    chips = [("EDGE", m["edge"], AMBER), ("ARMOR", str(m["armor"]), INK),
             ("ESSENCE", f"{m['essence']:g}" if m["essence"] is not None else "-", INK)]
    if m["magic"]:
        chips.append(("MAGIC", str(m["magic"]), MAGENTA))
    elif m["resonance"]:
        chips.append(("RESONANCE", str(m["resonance"]), MAGENTA))
    chips += [("NUYEN", f"¥{m['nuyen']:,}", INK)] + ([("KARMA", str(m["karma"]), AMBER)] if m["kind"] == "pc" else [])
    bx0, bx1, cw, chh = 1094, x1 - 24, 0.0, 74
    cw = (bx1 - bx0 - 2 * 10) / 3
    for i, (label, value, vc) in enumerate(chips[:6]):
        cx, cy = bx0 + (i % 3) * (cw + 10), y + 16 + (i // 3) * (chh + 10)
        d.rounded_rectangle([cx, cy, cx + cw, cy + chh], 10, fill=(13, 19, 30), outline=LINE, width=2)
        d.text((cx + 14, cy + 12), label, font=font(16, "SemiBold"), fill=DIM)
        if label == "EDGE":
            have, rating = value
            for j in range(min(rating, 7)):
                px, py = cx + 22 + j * 22, cy + 50
                d.ellipse([px - 8, py - 8, px + 8, py + 8], fill=vc if j < have else None,
                          outline=vc if j < have else FAINT, width=2)
            d.text((cx + cw - 14, cy + 21), f"{have}/{rating}", font=mono(18, True), fill=DIM, anchor="rm")
        else:
            d.text((cx + 14, cy + 32), _fit(value, font(30, "Bold"), cw - 26), font=font(30, "Bold"), fill=vc)

    # the kit and the place, one line along the bottom
    segs = []
    if m["weapon"]:
        w = m["weapon"]
        segs.append(("WEAPON", f"{w['name']}  {w['pool']} dice" + (f"  {w['ammo']} rds" if w["ammo"] else "")
                     + (f"  (+{w['more']} more)" if w["more"] else "")))
    if m["explosives"]:
        segs.append(("BOOM", ", ".join(m["explosives"])))
    if m["sustained"]:
        segs.append(("SUSTAINING", ", ".join(m["sustained"]) + f"  (-{2 * len(m['sustained'])} dice)"))
    if m["where"]:
        segs.append(("WHERE", m["where"] + (f"  ·  {m['zone']}" if m["zone"] else "")))
    lx, ly, right = tx, y + STRIP - 34, x1 - 24
    lab_f, val_f = font(16, "SemiBold"), font(21)
    for label, value in segs:
        if lx > right - 120:
            break
        d.text((lx, ly), label, font=lab_f, fill=FAINT, anchor="lm")
        lx += lab_f.getlength(label) + 10
        value = _fit(value, val_f, right - lx)
        d.text((lx, ly), value, font=val_f, fill=INK, anchor="lm")
        lx += val_f.getlength(value) + 34


def render(game, people: list[dict], out: Path) -> Path:
    n = max(1, len(people))
    h = TOP + n * (STRIP + GAP) + 18
    img = _canvas(h)
    d = ImageDraw.Draw(img)
    scene = game.ledger.current_scene()
    here = (game.ledger.get(scene["location_id"]) or {}).get("name") if scene and scene["location_id"] else None
    _topbar(d, "SHADOWRUN  //  THE CREW", "  ·  ".join(x for x in (game.path.stem, clock.short(game.clock()), here) if x))
    for i, m in enumerate(people):
        _strip(img, d, m, TOP + i * (STRIP + GAP))
    if not people:
        d.text((W / 2, TOP + STRIP / 2), "Nobody's playing yet - !join <character> or !newchar", font=font(34, "SemiBold"),
               fill=DIM, anchor="mm")
    return _save(img, out)


def _track(dmg: int, size: int) -> str:
    return "▰" * dmg + "▱" * max(0, size - dmg)


def text(m: dict) -> str:
    """One runner as text - the fallback if drawing fails."""
    (pd, ps), (sd, ss), (eh, er) = m["physical"], m["stun"], m["edge"]
    lines = [f"**{m['name']}** - {m['role'] or m['kind']}" + (f" · played by {m['player']}" if m["player"] else "")
             + f" · **{('away' if m['away'] and m['status'] == 'ok' else m['status']).upper()}**"
             + (f" (-{m['penalty']} to every pool)" if m["penalty"] else ""),
             f"Physical `{_track(pd, ps)}` {pd}/{ps} · Stun `{_track(sd, ss)}` {sd}/{ss}",
             f"Edge {eh}/{er} · Armor {m['armor']}" + (f" · Magic {m['magic']}" if m["magic"] else "")
             + f" · ¥{m['nuyen']:,}" + (f" · karma {m['karma']}" if m["kind"] == "pc" else "")]
    if m["weapon"]:
        w = m["weapon"]
        lines.append(f"{w['name']} ({w['pool']} dice" + (f", {w['ammo']} rds" if w["ammo"] else "") + ")"
                     + (f" · {', '.join(m['explosives'])}" if m["explosives"] else ""))
    if m["sustained"]:
        lines.append("Sustaining " + ", ".join(m["sustained"]))
    if m["where"]:
        lines.append(f"📍 {m['where']}" + (f" · {m['zone']}" if m["zone"] else ""))
    return "\n".join(lines)


def cards(game) -> list[dict]:
    """The roster as one picture for the channel - or, if drawing fails, as text."""
    people = crew(game)
    footer = "!party any time · !sheet for your full sheet (by DM)"
    try:
        path = render(game, people, game.path.parent / "sheets" / f"{game.path.stem}_party.png")
        return [{"title": "🛡️ The crew", "color": COLOR, "image": str(path), "footer": footer}]
    except Exception as exc:
        print(f"[{game.path.stem}] (party roster art failed, sending text: {exc})", flush=True)
        return [{"title": "🛡️ The crew", "color": COLOR, "footer": footer,
                 "description": "\n\n".join(text(m) for m in people) or "Nobody's playing yet - `!join <character>`."}]
